import Vermilion.Obligations

set_option linter.unusedVariables false
set_option linter.style.nameCheck false
set_option linter.dupNamespace false

inductive core.option.Option (V : Type) where
  | None
  | Some (_0 : V)
deriving Inhabited

@[simp, grind] def core.option.Option.is_None {V : Type} : (core.option.Option V) → Prop
  | .None => True
  | .Some _ => False
instance {V : Type} (x : (core.option.Option V)) : Decidable (core.option.Option.is_None x) := by
  cases x <;> first | exact isTrue trivial | exact isFalse (by simp)

@[simp, grind] def core.option.Option.is_Some {V : Type} : (core.option.Option V) → Prop
  | .None => False
  | .Some _ => True
instance {V : Type} (x : (core.option.Option V)) : Decidable (core.option.Option.is_Some x) := by
  cases x <;> first | exact isTrue trivial | exact isFalse (by simp)

@[simp, grind] def core.option.Option.get_Some__0 {V : Type} [Inhabited V] : (core.option.Option V) → V
  | .None => default
  | .Some _0 => _0

-- vrml:spec verified.valid_permutation examples/chelis-campaign-509eee221613/verified.rs:6:5
def verified.valid_permutation (axes : (Vermilion.Seq Int)) (rank : Int) : Prop :=
  ((Vermilion.Seq.len axes = rank) ∧ (∀ (i : Int), (((0 ≤ i) ∧ (i < rank)) → (Vermilion.Seq.index axes i < rank)))) ∧ (∀ (i : Int) (j : Int), ((((0 ≤ i) ∧ (i < j)) ∧ (j < rank)) → (¬ (Vermilion.Seq.index axes i = Vermilion.Seq.index axes j))))

-- vrml:spec vstd.slice.len_returns_clause_autospec vstd/slice.rs:83:1
def vstd.slice.len_returns_clause_autospec {T : Type} [Inhabited T] (slice : (Vermilion.Seq T)) : Int :=
  Vermilion.Seq.len slice

-- vrml:spec verified.normalized_axis_model examples/chelis-campaign-509eee221613/verified.rs:12:5
def verified.normalized_axis_model (rank : Int) (raw : Int) : (core.option.Option Int) :=
  (Vermilion.iteP (rank > 9223372036854775807) (core.option.Option.None (V := Int)) (Vermilion.iteP ((0 ≤ (Vermilion.iteP (raw < 0) (raw + rank) raw)) ∧ ((Vermilion.iteP (raw < 0) (raw + rank) raw) < rank)) (core.option.Option.Some ((Vermilion.iteP (raw < 0) (raw + rank) raw) % 18446744073709551616)) (core.option.Option.None (V := Int))))

-- vrml:spec verified.survivor_at examples/chelis-campaign-509eee221613/verified.rs:91:5
def verified.survivor_at (axis : Int) (output_index : Int) : Int :=
  (Vermilion.iteP (output_index < axis) output_index (output_index + 1))

namespace verified.is_permutation

-- vrml:begin verified.is_permutation.ensures_1 c0cedc559e99f6da
/--
Generated VC `verified.is_permutation.ensures_1`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:28:17-28:56`
- Rust/SST construct: function postcondition (`ensures`)
- AssertId: `1`
- Statement hash: `c0cedc559e99f6da`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩
-/
def ensures_1_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 28
  startColumn := 17
  endLine := 28
  endColumn := 56
  assertId := "1"
  functionName := "verified.is_permutation"
  kind := "ensures"
  statementHash := "c0cedc559e99f6da"
}
@[vrml_obligation] theorem ensures_1
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (requires_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (requires_1 : Vermilion.inUnsignedRange 64 rank)
    (assume_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (branch_0 : Vermilion.Seq.len axes ≠ rank) :
    False ↔ verified.valid_permutation axes rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.ensures_1

-- vrml:begin verified.is_permutation.invariant_entry_0_0 7e87853d68cd99f4
/--
Generated VC `verified.is_permutation.invariant_entry_0_0`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:36:17-36:26`
- Rust/SST construct: loop invariant on entry
- AssertId: `0_0`
- Statement hash: `7e87853d68cd99f4`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩
-/
def invariant_entry_0_0_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 36
  startColumn := 17
  endLine := 36
  endColumn := 26
  assertId := "0_0"
  functionName := "verified.is_permutation"
  kind := "invariant_entry"
  statementHash := "7e87853d68cd99f4"
}
@[vrml_obligation] theorem invariant_entry_0_0
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (requires_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (requires_1 : Vermilion.inUnsignedRange 64 rank)
    (assume_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (then_0_assume_4 : (Vermilion.Seq.len axes ≠ rank) → False)
    (then_0_assume_5 : (Vermilion.Seq.len axes ≠ rank) → False) :
    0 ≤ rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.invariant_entry_0_0

-- vrml:begin verified.is_permutation.invariant_entry_0_1 274bd4907a4c6a84
/--
Generated VC `verified.is_permutation.invariant_entry_0_1`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:37:17-37:35`
- Rust/SST construct: loop invariant on entry
- AssertId: `0_1`
- Statement hash: `274bd4907a4c6a84`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩
-/
def invariant_entry_0_1_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 37
  startColumn := 17
  endLine := 37
  endColumn := 35
  assertId := "0_1"
  functionName := "verified.is_permutation"
  kind := "invariant_entry"
  statementHash := "274bd4907a4c6a84"
}
@[vrml_obligation] theorem invariant_entry_0_1
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (requires_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (requires_1 : Vermilion.inUnsignedRange 64 rank)
    (assume_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (then_0_assume_4 : (Vermilion.Seq.len axes ≠ rank) → False)
    (then_0_assume_5 : (Vermilion.Seq.len axes ≠ rank) → False) :
    vstd.slice.len_returns_clause_autospec axes = rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.invariant_entry_0_1

-- vrml:begin verified.is_permutation.invariant_entry_0_2 9e2208562c6f34ca
/--
Generated VC `verified.is_permutation.invariant_entry_0_2`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:38:17-38:69`
- Rust/SST construct: loop invariant on entry
- AssertId: `0_2`
- Statement hash: `9e2208562c6f34ca`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes vrml_i0⟩
-/
def invariant_entry_0_2_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 38
  startColumn := 17
  endLine := 38
  endColumn := 69
  assertId := "0_2"
  functionName := "verified.is_permutation"
  kind := "invariant_entry"
  statementHash := "9e2208562c6f34ca"
}
@[vrml_obligation] theorem invariant_entry_0_2
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (requires_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (requires_1 : Vermilion.inUnsignedRange 64 rank)
    (assume_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (then_0_assume_4 : (Vermilion.Seq.len axes ≠ rank) → False)
    (then_0_assume_5 : (Vermilion.Seq.len axes ≠ rank) → False) :
    (∀ (k : Int), (((0 ≤ k) ∧ (k < 0)) → (Vermilion.Seq.index axes k < rank))) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.invariant_entry_0_2

-- vrml:begin verified.is_permutation.invariant_entry_0_3 a6a3f71a06ef268e
/--
Generated VC `verified.is_permutation.invariant_entry_0_3`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:39:17-39:86`
- Rust/SST construct: loop invariant on entry
- AssertId: `0_3`
- Statement hash: `a6a3f71a06ef268e`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes vrml_i0⟩
-/
def invariant_entry_0_3_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 39
  startColumn := 17
  endLine := 39
  endColumn := 86
  assertId := "0_3"
  functionName := "verified.is_permutation"
  kind := "invariant_entry"
  statementHash := "a6a3f71a06ef268e"
}
@[vrml_obligation] theorem invariant_entry_0_3
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (requires_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (requires_1 : Vermilion.inUnsignedRange 64 rank)
    (assume_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (then_0_assume_4 : (Vermilion.Seq.len axes ≠ rank) → False)
    (then_0_assume_5 : (Vermilion.Seq.len axes ≠ rank) → False) :
    (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < 0)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.invariant_entry_0_3

-- vrml:begin verified.is_permutation.assert_2 319fb04ed08077b0
/--
Generated VC `verified.is_permutation.assert_2`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:42:16-42:23`
- Rust/SST construct: precondition not met: index in bounds for this access
- AssertId: `2`
- Statement hash: `319fb04ed08077b0`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩
-/
def assert_2_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 42
  startColumn := 16
  endLine := 42
  endColumn := 23
  assertId := "2"
  functionName := "verified.is_permutation"
  kind := "assert"
  statementHash := "319fb04ed08077b0"
}
@[vrml_obligation] theorem assert_2
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (loop_0_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_0_iteration_3 : Vermilion.inUnsignedRange 64 i)
    (loop_0_iteration_4 : i ≤ rank)
    (loop_0_iteration_5 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_0_iteration_6 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_0_iteration_7 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_0_iteration_8 : i < rank) :
    (0 ≤ i) ∧ (i < Vermilion.Seq.len axes) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.assert_2

-- vrml:begin verified.is_permutation.ensures_3 3ab21662a45cb22c
/--
Generated VC `verified.is_permutation.ensures_3`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:28:17-28:56`
- Rust/SST construct: function postcondition (`ensures`)
- AssertId: `3`
- Statement hash: `3ab21662a45cb22c`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩
-/
def ensures_3_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 28
  startColumn := 17
  endLine := 28
  endColumn := 56
  assertId := "3"
  functionName := "verified.is_permutation"
  kind := "ensures"
  statementHash := "3ab21662a45cb22c"
}
@[vrml_obligation] theorem ensures_3
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (loop_0_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_0_iteration_3 : Vermilion.inUnsignedRange 64 i)
    (loop_0_iteration_4 : i ≤ rank)
    (loop_0_iteration_5 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_0_iteration_6 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_0_iteration_7 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_0_iteration_8 : i < rank)
    (assert_2 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (branch_1 : Vermilion.Seq.index axes i ≥ rank) :
    False ↔ verified.valid_permutation axes rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.ensures_3

-- vrml:begin verified.is_permutation.invariant_entry_1_0 1ab8a50bdec50081
/--
Generated VC `verified.is_permutation.invariant_entry_1_0`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:48:21-48:27`
- Rust/SST construct: loop invariant on entry
- AssertId: `1_0`
- Statement hash: `1ab8a50bdec50081`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩
-/
def invariant_entry_1_0_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 48
  startColumn := 21
  endLine := 48
  endColumn := 27
  assertId := "1_0"
  functionName := "verified.is_permutation"
  kind := "invariant_entry"
  statementHash := "1ab8a50bdec50081"
}
@[vrml_obligation] theorem invariant_entry_1_0
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (loop_0_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_0_iteration_3 : Vermilion.inUnsignedRange 64 i)
    (loop_0_iteration_4 : i ≤ rank)
    (loop_0_iteration_5 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_0_iteration_6 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_0_iteration_7 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_0_iteration_8 : i < rank)
    (assert_2 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (then_1_assume_11 : (Vermilion.Seq.index axes i ≥ rank) → False)
    (then_1_assume_12 : (Vermilion.Seq.index axes i ≥ rank) → False) :
    0 ≤ i := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.invariant_entry_1_0

-- vrml:begin verified.is_permutation.invariant_entry_1_1 a6b0e751f5fb0d70
/--
Generated VC `verified.is_permutation.invariant_entry_1_1`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:49:21-49:29`
- Rust/SST construct: loop invariant on entry
- AssertId: `1_1`
- Statement hash: `a6b0e751f5fb0d70`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩
-/
def invariant_entry_1_1_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 49
  startColumn := 21
  endLine := 49
  endColumn := 29
  assertId := "1_1"
  functionName := "verified.is_permutation"
  kind := "invariant_entry"
  statementHash := "a6b0e751f5fb0d70"
}
@[vrml_obligation] theorem invariant_entry_1_1
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (loop_0_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_0_iteration_3 : Vermilion.inUnsignedRange 64 i)
    (loop_0_iteration_4 : i ≤ rank)
    (loop_0_iteration_5 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_0_iteration_6 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_0_iteration_7 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_0_iteration_8 : i < rank)
    (assert_2 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (then_1_assume_11 : (Vermilion.Seq.index axes i ≥ rank) → False)
    (then_1_assume_12 : (Vermilion.Seq.index axes i ≥ rank) → False) :
    i < rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.invariant_entry_1_1

-- vrml:begin verified.is_permutation.invariant_entry_1_2 2910af22d8e6e8d4
/--
Generated VC `verified.is_permutation.invariant_entry_1_2`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:50:21-50:39`
- Rust/SST construct: loop invariant on entry
- AssertId: `1_2`
- Statement hash: `2910af22d8e6e8d4`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩
-/
def invariant_entry_1_2_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 50
  startColumn := 21
  endLine := 50
  endColumn := 39
  assertId := "1_2"
  functionName := "verified.is_permutation"
  kind := "invariant_entry"
  statementHash := "2910af22d8e6e8d4"
}
@[vrml_obligation] theorem invariant_entry_1_2
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (loop_0_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_0_iteration_3 : Vermilion.inUnsignedRange 64 i)
    (loop_0_iteration_4 : i ≤ rank)
    (loop_0_iteration_5 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_0_iteration_6 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_0_iteration_7 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_0_iteration_8 : i < rank)
    (assert_2 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (then_1_assume_11 : (Vermilion.Seq.index axes i ≥ rank) → False)
    (then_1_assume_12 : (Vermilion.Seq.index axes i ≥ rank) → False) :
    vstd.slice.len_returns_clause_autospec axes = rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.invariant_entry_1_2

-- vrml:begin verified.is_permutation.invariant_entry_1_3 17514723874e1a63
/--
Generated VC `verified.is_permutation.invariant_entry_1_3`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:51:21-51:43`
- Rust/SST construct: loop invariant on entry
- AssertId: `1_3`
- Statement hash: `17514723874e1a63`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩
-/
def invariant_entry_1_3_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 51
  startColumn := 21
  endLine := 51
  endColumn := 43
  assertId := "1_3"
  functionName := "verified.is_permutation"
  kind := "invariant_entry"
  statementHash := "17514723874e1a63"
}
@[vrml_obligation] theorem invariant_entry_1_3
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (loop_0_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_0_iteration_3 : Vermilion.inUnsignedRange 64 i)
    (loop_0_iteration_4 : i ≤ rank)
    (loop_0_iteration_5 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_0_iteration_6 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_0_iteration_7 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_0_iteration_8 : i < rank)
    (assert_2 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (then_1_assume_11 : (Vermilion.Seq.index axes i ≥ rank) → False)
    (then_1_assume_12 : (Vermilion.Seq.index axes i ≥ rank) → False) :
    Vermilion.Seq.index axes i < rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.invariant_entry_1_3

-- vrml:begin verified.is_permutation.invariant_entry_1_4 0b563cee3fc994a1
/--
Generated VC `verified.is_permutation.invariant_entry_1_4`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:52:21-52:73`
- Rust/SST construct: loop invariant on entry
- AssertId: `1_4`
- Statement hash: `0b563cee3fc994a1`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩
-/
def invariant_entry_1_4_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 52
  startColumn := 21
  endLine := 52
  endColumn := 73
  assertId := "1_4"
  functionName := "verified.is_permutation"
  kind := "invariant_entry"
  statementHash := "0b563cee3fc994a1"
}
@[vrml_obligation] theorem invariant_entry_1_4
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (loop_0_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_0_iteration_3 : Vermilion.inUnsignedRange 64 i)
    (loop_0_iteration_4 : i ≤ rank)
    (loop_0_iteration_5 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_0_iteration_6 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_0_iteration_7 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_0_iteration_8 : i < rank)
    (assert_2 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (then_1_assume_11 : (Vermilion.Seq.index axes i ≥ rank) → False)
    (then_1_assume_12 : (Vermilion.Seq.index axes i ≥ rank) → False) :
    (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.invariant_entry_1_4

-- vrml:begin verified.is_permutation.invariant_entry_1_5 0ffe521067c60f4f
/--
Generated VC `verified.is_permutation.invariant_entry_1_5`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:53:21-53:90`
- Rust/SST construct: loop invariant on entry
- AssertId: `1_5`
- Statement hash: `0ffe521067c60f4f`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩
-/
def invariant_entry_1_5_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 53
  startColumn := 21
  endLine := 53
  endColumn := 90
  assertId := "1_5"
  functionName := "verified.is_permutation"
  kind := "invariant_entry"
  statementHash := "0ffe521067c60f4f"
}
@[vrml_obligation] theorem invariant_entry_1_5
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (loop_0_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_0_iteration_3 : Vermilion.inUnsignedRange 64 i)
    (loop_0_iteration_4 : i ≤ rank)
    (loop_0_iteration_5 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_0_iteration_6 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_0_iteration_7 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_0_iteration_8 : i < rank)
    (assert_2 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (then_1_assume_11 : (Vermilion.Seq.index axes i ≥ rank) → False)
    (then_1_assume_12 : (Vermilion.Seq.index axes i ≥ rank) → False) :
    (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.invariant_entry_1_5

-- vrml:begin verified.is_permutation.invariant_entry_1_6 769934c34333d230
/--
Generated VC `verified.is_permutation.invariant_entry_1_6`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:54:21-54:85`
- Rust/SST construct: loop invariant on entry
- AssertId: `1_6`
- Statement hash: `769934c34333d230`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩
-/
def invariant_entry_1_6_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 54
  startColumn := 21
  endLine := 54
  endColumn := 85
  assertId := "1_6"
  functionName := "verified.is_permutation"
  kind := "invariant_entry"
  statementHash := "769934c34333d230"
}
@[vrml_obligation] theorem invariant_entry_1_6
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (loop_0_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_0_iteration_3 : Vermilion.inUnsignedRange 64 i)
    (loop_0_iteration_4 : i ≤ rank)
    (loop_0_iteration_5 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_0_iteration_6 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_0_iteration_7 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_0_iteration_8 : i < rank)
    (assert_2 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (then_1_assume_11 : (Vermilion.Seq.index axes i ≥ rank) → False)
    (then_1_assume_12 : (Vermilion.Seq.index axes i ≥ rank) → False) :
    (∀ (k : Int), (((0 ≤ k) ∧ (k < 0)) → (¬ (Vermilion.Seq.index axes k = Vermilion.Seq.index axes i)))) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.invariant_entry_1_6

-- vrml:begin verified.is_permutation.assert_4 c3a15d16a9313f98
/--
Generated VC `verified.is_permutation.assert_4`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:57:20-57:27`
- Rust/SST construct: precondition not met: index in bounds for this access
- AssertId: `4`
- Statement hash: `c3a15d16a9313f98`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes k⟩
-/
def assert_4_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 57
  startColumn := 20
  endLine := 57
  endColumn := 27
  assertId := "4"
  functionName := "verified.is_permutation"
  kind := "assert"
  statementHash := "c3a15d16a9313f98"
}
@[vrml_obligation] theorem assert_4
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (j : Int)
    (loop_1_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_1_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_1_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_1_iteration_3 : Vermilion.inUnsignedRange 64 j)
    (loop_1_iteration_4 : j ≤ i)
    (loop_1_iteration_5 : i < rank)
    (loop_1_iteration_6 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_1_iteration_7 : Vermilion.Seq.index axes i < rank)
    (loop_1_iteration_8 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_1_iteration_9 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_1_iteration_10 : (∀ (k : Int), (((0 ≤ k) ∧ (k < j)) → (¬ (Vermilion.Seq.index axes k = Vermilion.Seq.index axes i)))))
    (loop_1_iteration_11 : j < i) :
    (0 ≤ j) ∧ (j < Vermilion.Seq.len axes) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.assert_4

-- vrml:begin verified.is_permutation.assert_5 ec1ad0cea0435f0e
/--
Generated VC `verified.is_permutation.assert_5`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:57:31-57:38`
- Rust/SST construct: precondition not met: index in bounds for this access
- AssertId: `5`
- Statement hash: `ec1ad0cea0435f0e`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes k⟩
-/
def assert_5_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 57
  startColumn := 31
  endLine := 57
  endColumn := 38
  assertId := "5"
  functionName := "verified.is_permutation"
  kind := "assert"
  statementHash := "ec1ad0cea0435f0e"
}
@[vrml_obligation] theorem assert_5
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (j : Int)
    (loop_1_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_1_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_1_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_1_iteration_3 : Vermilion.inUnsignedRange 64 j)
    (loop_1_iteration_4 : j ≤ i)
    (loop_1_iteration_5 : i < rank)
    (loop_1_iteration_6 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_1_iteration_7 : Vermilion.Seq.index axes i < rank)
    (loop_1_iteration_8 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_1_iteration_9 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_1_iteration_10 : (∀ (k : Int), (((0 ≤ k) ∧ (k < j)) → (¬ (Vermilion.Seq.index axes k = Vermilion.Seq.index axes i)))))
    (loop_1_iteration_11 : j < i)
    (assert_4 : (0 ≤ j) ∧ (j < Vermilion.Seq.len axes)) :
    (0 ≤ i) ∧ (i < Vermilion.Seq.len axes) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.assert_5

-- vrml:begin verified.is_permutation.ensures_6 9f552896408bc47a
/--
Generated VC `verified.is_permutation.ensures_6`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:28:17-28:56`
- Rust/SST construct: function postcondition (`ensures`)
- AssertId: `6`
- Statement hash: `9f552896408bc47a`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes k⟩
-/
def ensures_6_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 28
  startColumn := 17
  endLine := 28
  endColumn := 56
  assertId := "6"
  functionName := "verified.is_permutation"
  kind := "ensures"
  statementHash := "9f552896408bc47a"
}
@[vrml_obligation] theorem ensures_6
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (j : Int)
    (loop_1_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_1_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_1_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_1_iteration_3 : Vermilion.inUnsignedRange 64 j)
    (loop_1_iteration_4 : j ≤ i)
    (loop_1_iteration_5 : i < rank)
    (loop_1_iteration_6 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_1_iteration_7 : Vermilion.Seq.index axes i < rank)
    (loop_1_iteration_8 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_1_iteration_9 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_1_iteration_10 : (∀ (k : Int), (((0 ≤ k) ∧ (k < j)) → (¬ (Vermilion.Seq.index axes k = Vermilion.Seq.index axes i)))))
    (loop_1_iteration_11 : j < i)
    (assert_4 : (0 ≤ j) ∧ (j < Vermilion.Seq.len axes))
    (assert_5 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (branch_2 : Vermilion.Seq.index axes j = Vermilion.Seq.index axes i) :
    False ↔ verified.valid_permutation axes rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.ensures_6

-- vrml:begin verified.is_permutation.assert_7 b11a3d84357ec00f
/--
Generated VC `verified.is_permutation.assert_7`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:60:17-60:23`
- Rust/SST construct: possible arithmetic underflow/overflow
- AssertId: `7`
- Statement hash: `b11a3d84357ec00f`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes k⟩
-/
def assert_7_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 60
  startColumn := 17
  endLine := 60
  endColumn := 23
  assertId := "7"
  functionName := "verified.is_permutation"
  kind := "assert"
  statementHash := "b11a3d84357ec00f"
}
@[vrml_obligation] theorem assert_7
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (j : Int)
    (loop_1_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_1_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_1_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_1_iteration_3 : Vermilion.inUnsignedRange 64 j)
    (loop_1_iteration_4 : j ≤ i)
    (loop_1_iteration_5 : i < rank)
    (loop_1_iteration_6 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_1_iteration_7 : Vermilion.Seq.index axes i < rank)
    (loop_1_iteration_8 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_1_iteration_9 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_1_iteration_10 : (∀ (k : Int), (((0 ≤ k) ∧ (k < j)) → (¬ (Vermilion.Seq.index axes k = Vermilion.Seq.index axes i)))))
    (loop_1_iteration_11 : j < i)
    (assert_4 : (0 ≤ j) ∧ (j < Vermilion.Seq.len axes))
    (assert_5 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (then_2_assume_15 : (Vermilion.Seq.index axes j = Vermilion.Seq.index axes i) → False)
    (then_2_assume_16 : (Vermilion.Seq.index axes j = Vermilion.Seq.index axes i) → False) :
    Vermilion.inUnsignedRange 64 (j + 1) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.assert_7

-- vrml:begin verified.is_permutation.invariant_preserve_1_0 7080423f4f5b35b3
/--
Generated VC `verified.is_permutation.invariant_preserve_1_0`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:48:21-48:27`
- Rust/SST construct: loop invariant preserved by the body
- AssertId: `1_0`
- Statement hash: `7080423f4f5b35b3`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes k⟩
-/
def invariant_preserve_1_0_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 48
  startColumn := 21
  endLine := 48
  endColumn := 27
  assertId := "1_0"
  functionName := "verified.is_permutation"
  kind := "invariant_preserve"
  statementHash := "7080423f4f5b35b3"
}
@[vrml_obligation] theorem invariant_preserve_1_0
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (j : Int)
    (loop_1_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_1_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_1_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_1_iteration_3 : Vermilion.inUnsignedRange 64 j)
    (loop_1_iteration_4 : j ≤ i)
    (loop_1_iteration_5 : i < rank)
    (loop_1_iteration_6 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_1_iteration_7 : Vermilion.Seq.index axes i < rank)
    (loop_1_iteration_8 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_1_iteration_9 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_1_iteration_10 : (∀ (k : Int), (((0 ≤ k) ∧ (k < j)) → (¬ (Vermilion.Seq.index axes k = Vermilion.Seq.index axes i)))))
    (loop_1_iteration_11 : j < i)
    (assert_4 : (0 ≤ j) ∧ (j < Vermilion.Seq.len axes))
    (assert_5 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (then_2_assume_15 : (Vermilion.Seq.index axes j = Vermilion.Seq.index axes i) → False)
    (then_2_assume_16 : (Vermilion.Seq.index axes j = Vermilion.Seq.index axes i) → False)
    (assert_7 : Vermilion.inUnsignedRange 64 (j + 1)) :
    ((j + 1) % 18446744073709551616) ≤ i := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.invariant_preserve_1_0

-- vrml:begin verified.is_permutation.invariant_preserve_1_1 798cdba6ce0e1c6f
/--
Generated VC `verified.is_permutation.invariant_preserve_1_1`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:49:21-49:29`
- Rust/SST construct: loop invariant preserved by the body
- AssertId: `1_1`
- Statement hash: `798cdba6ce0e1c6f`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes k⟩
-/
def invariant_preserve_1_1_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 49
  startColumn := 21
  endLine := 49
  endColumn := 29
  assertId := "1_1"
  functionName := "verified.is_permutation"
  kind := "invariant_preserve"
  statementHash := "798cdba6ce0e1c6f"
}
@[vrml_obligation] theorem invariant_preserve_1_1
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (j : Int)
    (loop_1_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_1_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_1_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_1_iteration_3 : Vermilion.inUnsignedRange 64 j)
    (loop_1_iteration_4 : j ≤ i)
    (loop_1_iteration_5 : i < rank)
    (loop_1_iteration_6 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_1_iteration_7 : Vermilion.Seq.index axes i < rank)
    (loop_1_iteration_8 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_1_iteration_9 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_1_iteration_10 : (∀ (k : Int), (((0 ≤ k) ∧ (k < j)) → (¬ (Vermilion.Seq.index axes k = Vermilion.Seq.index axes i)))))
    (loop_1_iteration_11 : j < i)
    (assert_4 : (0 ≤ j) ∧ (j < Vermilion.Seq.len axes))
    (assert_5 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (then_2_assume_15 : (Vermilion.Seq.index axes j = Vermilion.Seq.index axes i) → False)
    (then_2_assume_16 : (Vermilion.Seq.index axes j = Vermilion.Seq.index axes i) → False)
    (assert_7 : Vermilion.inUnsignedRange 64 (j + 1)) :
    i < rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.invariant_preserve_1_1

-- vrml:begin verified.is_permutation.invariant_preserve_1_2 50cc3955cbba60ff
/--
Generated VC `verified.is_permutation.invariant_preserve_1_2`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:50:21-50:39`
- Rust/SST construct: loop invariant preserved by the body
- AssertId: `1_2`
- Statement hash: `50cc3955cbba60ff`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes k⟩
-/
def invariant_preserve_1_2_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 50
  startColumn := 21
  endLine := 50
  endColumn := 39
  assertId := "1_2"
  functionName := "verified.is_permutation"
  kind := "invariant_preserve"
  statementHash := "50cc3955cbba60ff"
}
@[vrml_obligation] theorem invariant_preserve_1_2
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (j : Int)
    (loop_1_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_1_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_1_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_1_iteration_3 : Vermilion.inUnsignedRange 64 j)
    (loop_1_iteration_4 : j ≤ i)
    (loop_1_iteration_5 : i < rank)
    (loop_1_iteration_6 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_1_iteration_7 : Vermilion.Seq.index axes i < rank)
    (loop_1_iteration_8 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_1_iteration_9 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_1_iteration_10 : (∀ (k : Int), (((0 ≤ k) ∧ (k < j)) → (¬ (Vermilion.Seq.index axes k = Vermilion.Seq.index axes i)))))
    (loop_1_iteration_11 : j < i)
    (assert_4 : (0 ≤ j) ∧ (j < Vermilion.Seq.len axes))
    (assert_5 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (then_2_assume_15 : (Vermilion.Seq.index axes j = Vermilion.Seq.index axes i) → False)
    (then_2_assume_16 : (Vermilion.Seq.index axes j = Vermilion.Seq.index axes i) → False)
    (assert_7 : Vermilion.inUnsignedRange 64 (j + 1)) :
    vstd.slice.len_returns_clause_autospec axes = rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.invariant_preserve_1_2

-- vrml:begin verified.is_permutation.invariant_preserve_1_3 4301e2af8f1c469a
/--
Generated VC `verified.is_permutation.invariant_preserve_1_3`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:51:21-51:43`
- Rust/SST construct: loop invariant preserved by the body
- AssertId: `1_3`
- Statement hash: `4301e2af8f1c469a`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes k⟩
-/
def invariant_preserve_1_3_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 51
  startColumn := 21
  endLine := 51
  endColumn := 43
  assertId := "1_3"
  functionName := "verified.is_permutation"
  kind := "invariant_preserve"
  statementHash := "4301e2af8f1c469a"
}
@[vrml_obligation] theorem invariant_preserve_1_3
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (j : Int)
    (loop_1_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_1_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_1_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_1_iteration_3 : Vermilion.inUnsignedRange 64 j)
    (loop_1_iteration_4 : j ≤ i)
    (loop_1_iteration_5 : i < rank)
    (loop_1_iteration_6 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_1_iteration_7 : Vermilion.Seq.index axes i < rank)
    (loop_1_iteration_8 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_1_iteration_9 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_1_iteration_10 : (∀ (k : Int), (((0 ≤ k) ∧ (k < j)) → (¬ (Vermilion.Seq.index axes k = Vermilion.Seq.index axes i)))))
    (loop_1_iteration_11 : j < i)
    (assert_4 : (0 ≤ j) ∧ (j < Vermilion.Seq.len axes))
    (assert_5 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (then_2_assume_15 : (Vermilion.Seq.index axes j = Vermilion.Seq.index axes i) → False)
    (then_2_assume_16 : (Vermilion.Seq.index axes j = Vermilion.Seq.index axes i) → False)
    (assert_7 : Vermilion.inUnsignedRange 64 (j + 1)) :
    Vermilion.Seq.index axes i < rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.invariant_preserve_1_3

-- vrml:begin verified.is_permutation.invariant_preserve_1_4 92cc4737e5ff4bd6
/--
Generated VC `verified.is_permutation.invariant_preserve_1_4`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:52:21-52:73`
- Rust/SST construct: loop invariant preserved by the body
- AssertId: `1_4`
- Statement hash: `92cc4737e5ff4bd6`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes k⟩
-/
def invariant_preserve_1_4_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 52
  startColumn := 21
  endLine := 52
  endColumn := 73
  assertId := "1_4"
  functionName := "verified.is_permutation"
  kind := "invariant_preserve"
  statementHash := "92cc4737e5ff4bd6"
}
@[vrml_obligation] theorem invariant_preserve_1_4
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (j : Int)
    (loop_1_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_1_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_1_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_1_iteration_3 : Vermilion.inUnsignedRange 64 j)
    (loop_1_iteration_4 : j ≤ i)
    (loop_1_iteration_5 : i < rank)
    (loop_1_iteration_6 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_1_iteration_7 : Vermilion.Seq.index axes i < rank)
    (loop_1_iteration_8 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_1_iteration_9 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_1_iteration_10 : (∀ (k : Int), (((0 ≤ k) ∧ (k < j)) → (¬ (Vermilion.Seq.index axes k = Vermilion.Seq.index axes i)))))
    (loop_1_iteration_11 : j < i)
    (assert_4 : (0 ≤ j) ∧ (j < Vermilion.Seq.len axes))
    (assert_5 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (then_2_assume_15 : (Vermilion.Seq.index axes j = Vermilion.Seq.index axes i) → False)
    (then_2_assume_16 : (Vermilion.Seq.index axes j = Vermilion.Seq.index axes i) → False)
    (assert_7 : Vermilion.inUnsignedRange 64 (j + 1)) :
    (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.invariant_preserve_1_4

-- vrml:begin verified.is_permutation.invariant_preserve_1_5 8e603adcbe1ce40e
/--
Generated VC `verified.is_permutation.invariant_preserve_1_5`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:53:21-53:90`
- Rust/SST construct: loop invariant preserved by the body
- AssertId: `1_5`
- Statement hash: `8e603adcbe1ce40e`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes k⟩
-/
def invariant_preserve_1_5_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 53
  startColumn := 21
  endLine := 53
  endColumn := 90
  assertId := "1_5"
  functionName := "verified.is_permutation"
  kind := "invariant_preserve"
  statementHash := "8e603adcbe1ce40e"
}
@[vrml_obligation] theorem invariant_preserve_1_5
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (j : Int)
    (loop_1_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_1_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_1_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_1_iteration_3 : Vermilion.inUnsignedRange 64 j)
    (loop_1_iteration_4 : j ≤ i)
    (loop_1_iteration_5 : i < rank)
    (loop_1_iteration_6 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_1_iteration_7 : Vermilion.Seq.index axes i < rank)
    (loop_1_iteration_8 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_1_iteration_9 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_1_iteration_10 : (∀ (k : Int), (((0 ≤ k) ∧ (k < j)) → (¬ (Vermilion.Seq.index axes k = Vermilion.Seq.index axes i)))))
    (loop_1_iteration_11 : j < i)
    (assert_4 : (0 ≤ j) ∧ (j < Vermilion.Seq.len axes))
    (assert_5 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (then_2_assume_15 : (Vermilion.Seq.index axes j = Vermilion.Seq.index axes i) → False)
    (then_2_assume_16 : (Vermilion.Seq.index axes j = Vermilion.Seq.index axes i) → False)
    (assert_7 : Vermilion.inUnsignedRange 64 (j + 1)) :
    (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.invariant_preserve_1_5

-- vrml:begin verified.is_permutation.invariant_preserve_1_6 9b0860b7dae748a8
/--
Generated VC `verified.is_permutation.invariant_preserve_1_6`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:54:21-54:85`
- Rust/SST construct: loop invariant preserved by the body
- AssertId: `1_6`
- Statement hash: `9b0860b7dae748a8`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes k⟩
-/
def invariant_preserve_1_6_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 54
  startColumn := 21
  endLine := 54
  endColumn := 85
  assertId := "1_6"
  functionName := "verified.is_permutation"
  kind := "invariant_preserve"
  statementHash := "9b0860b7dae748a8"
}
@[vrml_obligation] theorem invariant_preserve_1_6
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (j : Int)
    (loop_1_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_1_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_1_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_1_iteration_3 : Vermilion.inUnsignedRange 64 j)
    (loop_1_iteration_4 : j ≤ i)
    (loop_1_iteration_5 : i < rank)
    (loop_1_iteration_6 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_1_iteration_7 : Vermilion.Seq.index axes i < rank)
    (loop_1_iteration_8 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_1_iteration_9 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_1_iteration_10 : (∀ (k : Int), (((0 ≤ k) ∧ (k < j)) → (¬ (Vermilion.Seq.index axes k = Vermilion.Seq.index axes i)))))
    (loop_1_iteration_11 : j < i)
    (assert_4 : (0 ≤ j) ∧ (j < Vermilion.Seq.len axes))
    (assert_5 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (then_2_assume_15 : (Vermilion.Seq.index axes j = Vermilion.Seq.index axes i) → False)
    (then_2_assume_16 : (Vermilion.Seq.index axes j = Vermilion.Seq.index axes i) → False)
    (assert_7 : Vermilion.inUnsignedRange 64 (j + 1)) :
    (∀ (k : Int), (((0 ≤ k) ∧ (k < ((j + 1) % 18446744073709551616))) → (¬ (Vermilion.Seq.index axes k = Vermilion.Seq.index axes i)))) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.invariant_preserve_1_6

-- vrml:begin verified.is_permutation.assert_1_decreases a0d130dfe34126cc
/--
Generated VC `verified.is_permutation.assert_1_decreases`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:55:27-55:32`
- Rust/SST construct: loop termination measure must decrease
- AssertId: `1_decreases`
- Statement hash: `a0d130dfe34126cc`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes k⟩
-/
def assert_1_decreases_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 55
  startColumn := 27
  endLine := 55
  endColumn := 32
  assertId := "1_decreases"
  functionName := "verified.is_permutation"
  kind := "assert"
  statementHash := "a0d130dfe34126cc"
}
@[vrml_obligation] theorem assert_1_decreases
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (j : Int)
    (loop_1_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_1_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_1_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_1_iteration_3 : Vermilion.inUnsignedRange 64 j)
    (loop_1_iteration_4 : j ≤ i)
    (loop_1_iteration_5 : i < rank)
    (loop_1_iteration_6 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_1_iteration_7 : Vermilion.Seq.index axes i < rank)
    (loop_1_iteration_8 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_1_iteration_9 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_1_iteration_10 : (∀ (k : Int), (((0 ≤ k) ∧ (k < j)) → (¬ (Vermilion.Seq.index axes k = Vermilion.Seq.index axes i)))))
    (loop_1_iteration_11 : j < i)
    (assert_4 : (0 ≤ j) ∧ (j < Vermilion.Seq.len axes))
    (assert_5 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (then_2_assume_15 : (Vermilion.Seq.index axes j = Vermilion.Seq.index axes i) → False)
    (then_2_assume_16 : (Vermilion.Seq.index axes j = Vermilion.Seq.index axes i) → False)
    (assert_7 : Vermilion.inUnsignedRange 64 (j + 1)) :
    ((0 ≤ (i - ((j + 1) % 18446744073709551616))) ∧ ((i - ((j + 1) % 18446744073709551616)) < (i - j))) ∨ (((i - ((j + 1) % 18446744073709551616)) = (i - j)) ∧ False) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.assert_1_decreases

-- vrml:begin verified.is_permutation.assert_8 d7b4e048fa9787ee
/--
Generated VC `verified.is_permutation.assert_8`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:62:13-62:19`
- Rust/SST construct: possible arithmetic underflow/overflow
- AssertId: `8`
- Statement hash: `d7b4e048fa9787ee`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes k⟩
-/
def assert_8_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 62
  startColumn := 13
  endLine := 62
  endColumn := 19
  assertId := "8"
  functionName := "verified.is_permutation"
  kind := "assert"
  statementHash := "d7b4e048fa9787ee"
}
@[vrml_obligation] theorem assert_8
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (j : Int)
    (loop_0_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_0_iteration_3 : Vermilion.inUnsignedRange 64 i)
    (loop_0_iteration_4 : i ≤ rank)
    (loop_0_iteration_5 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_0_iteration_6 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_0_iteration_7 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_0_iteration_8 : i < rank)
    (assert_2 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (then_1_assume_11 : (Vermilion.Seq.index axes i ≥ rank) → False)
    (then_1_assume_12 : (Vermilion.Seq.index axes i ≥ rank) → False)
    (loop_1_exit_0 : Vermilion.inUnsignedRange 64 j)
    (loop_1_exit_1 : j ≤ i)
    (loop_1_exit_2 : i < rank)
    (loop_1_exit_3 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_1_exit_4 : Vermilion.Seq.index axes i < rank)
    (loop_1_exit_5 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_1_exit_6 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_1_exit_7 : (∀ (k : Int), (((0 ≤ k) ∧ (k < j)) → (¬ (Vermilion.Seq.index axes k = Vermilion.Seq.index axes i)))))
    (loop_1_exit_8 : (¬ (j < i))) :
    Vermilion.inUnsignedRange 64 (i + 1) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.assert_8

-- vrml:begin verified.is_permutation.invariant_preserve_0_0 0c42d1d41a62937d
/--
Generated VC `verified.is_permutation.invariant_preserve_0_0`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:36:17-36:26`
- Rust/SST construct: loop invariant preserved by the body
- AssertId: `0_0`
- Statement hash: `0c42d1d41a62937d`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes k⟩
-/
def invariant_preserve_0_0_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 36
  startColumn := 17
  endLine := 36
  endColumn := 26
  assertId := "0_0"
  functionName := "verified.is_permutation"
  kind := "invariant_preserve"
  statementHash := "0c42d1d41a62937d"
}
@[vrml_obligation] theorem invariant_preserve_0_0
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (j : Int)
    (loop_0_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_0_iteration_3 : Vermilion.inUnsignedRange 64 i)
    (loop_0_iteration_4 : i ≤ rank)
    (loop_0_iteration_5 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_0_iteration_6 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_0_iteration_7 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_0_iteration_8 : i < rank)
    (assert_2 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (then_1_assume_11 : (Vermilion.Seq.index axes i ≥ rank) → False)
    (then_1_assume_12 : (Vermilion.Seq.index axes i ≥ rank) → False)
    (loop_1_exit_0 : Vermilion.inUnsignedRange 64 j)
    (loop_1_exit_1 : j ≤ i)
    (loop_1_exit_2 : i < rank)
    (loop_1_exit_3 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_1_exit_4 : Vermilion.Seq.index axes i < rank)
    (loop_1_exit_5 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_1_exit_6 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_1_exit_7 : (∀ (k : Int), (((0 ≤ k) ∧ (k < j)) → (¬ (Vermilion.Seq.index axes k = Vermilion.Seq.index axes i)))))
    (loop_1_exit_8 : (¬ (j < i)))
    (assert_8 : Vermilion.inUnsignedRange 64 (i + 1)) :
    ((i + 1) % 18446744073709551616) ≤ rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.invariant_preserve_0_0

-- vrml:begin verified.is_permutation.invariant_preserve_0_1 1911aa413b0fe585
/--
Generated VC `verified.is_permutation.invariant_preserve_0_1`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:37:17-37:35`
- Rust/SST construct: loop invariant preserved by the body
- AssertId: `0_1`
- Statement hash: `1911aa413b0fe585`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes k⟩
-/
def invariant_preserve_0_1_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 37
  startColumn := 17
  endLine := 37
  endColumn := 35
  assertId := "0_1"
  functionName := "verified.is_permutation"
  kind := "invariant_preserve"
  statementHash := "1911aa413b0fe585"
}
@[vrml_obligation] theorem invariant_preserve_0_1
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (j : Int)
    (loop_0_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_0_iteration_3 : Vermilion.inUnsignedRange 64 i)
    (loop_0_iteration_4 : i ≤ rank)
    (loop_0_iteration_5 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_0_iteration_6 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_0_iteration_7 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_0_iteration_8 : i < rank)
    (assert_2 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (then_1_assume_11 : (Vermilion.Seq.index axes i ≥ rank) → False)
    (then_1_assume_12 : (Vermilion.Seq.index axes i ≥ rank) → False)
    (loop_1_exit_0 : Vermilion.inUnsignedRange 64 j)
    (loop_1_exit_1 : j ≤ i)
    (loop_1_exit_2 : i < rank)
    (loop_1_exit_3 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_1_exit_4 : Vermilion.Seq.index axes i < rank)
    (loop_1_exit_5 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_1_exit_6 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_1_exit_7 : (∀ (k : Int), (((0 ≤ k) ∧ (k < j)) → (¬ (Vermilion.Seq.index axes k = Vermilion.Seq.index axes i)))))
    (loop_1_exit_8 : (¬ (j < i)))
    (assert_8 : Vermilion.inUnsignedRange 64 (i + 1)) :
    vstd.slice.len_returns_clause_autospec axes = rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.invariant_preserve_0_1

-- vrml:begin verified.is_permutation.invariant_preserve_0_2 e5a357a0d59eb383
/--
Generated VC `verified.is_permutation.invariant_preserve_0_2`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:38:17-38:69`
- Rust/SST construct: loop invariant preserved by the body
- AssertId: `0_2`
- Statement hash: `e5a357a0d59eb383`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes k⟩
-/
def invariant_preserve_0_2_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 38
  startColumn := 17
  endLine := 38
  endColumn := 69
  assertId := "0_2"
  functionName := "verified.is_permutation"
  kind := "invariant_preserve"
  statementHash := "e5a357a0d59eb383"
}
@[vrml_obligation] theorem invariant_preserve_0_2
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (j : Int)
    (loop_0_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_0_iteration_3 : Vermilion.inUnsignedRange 64 i)
    (loop_0_iteration_4 : i ≤ rank)
    (loop_0_iteration_5 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_0_iteration_6 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_0_iteration_7 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_0_iteration_8 : i < rank)
    (assert_2 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (then_1_assume_11 : (Vermilion.Seq.index axes i ≥ rank) → False)
    (then_1_assume_12 : (Vermilion.Seq.index axes i ≥ rank) → False)
    (loop_1_exit_0 : Vermilion.inUnsignedRange 64 j)
    (loop_1_exit_1 : j ≤ i)
    (loop_1_exit_2 : i < rank)
    (loop_1_exit_3 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_1_exit_4 : Vermilion.Seq.index axes i < rank)
    (loop_1_exit_5 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_1_exit_6 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_1_exit_7 : (∀ (k : Int), (((0 ≤ k) ∧ (k < j)) → (¬ (Vermilion.Seq.index axes k = Vermilion.Seq.index axes i)))))
    (loop_1_exit_8 : (¬ (j < i)))
    (assert_8 : Vermilion.inUnsignedRange 64 (i + 1)) :
    (∀ (k : Int), (((0 ≤ k) ∧ (k < ((i + 1) % 18446744073709551616))) → (Vermilion.Seq.index axes k < rank))) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.invariant_preserve_0_2

-- vrml:begin verified.is_permutation.invariant_preserve_0_3 db5710a38ecd279b
/--
Generated VC `verified.is_permutation.invariant_preserve_0_3`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:39:17-39:86`
- Rust/SST construct: loop invariant preserved by the body
- AssertId: `0_3`
- Statement hash: `db5710a38ecd279b`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes k⟩
-/
def invariant_preserve_0_3_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 39
  startColumn := 17
  endLine := 39
  endColumn := 86
  assertId := "0_3"
  functionName := "verified.is_permutation"
  kind := "invariant_preserve"
  statementHash := "db5710a38ecd279b"
}
@[vrml_obligation] theorem invariant_preserve_0_3
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (j : Int)
    (loop_0_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_0_iteration_3 : Vermilion.inUnsignedRange 64 i)
    (loop_0_iteration_4 : i ≤ rank)
    (loop_0_iteration_5 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_0_iteration_6 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_0_iteration_7 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_0_iteration_8 : i < rank)
    (assert_2 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (then_1_assume_11 : (Vermilion.Seq.index axes i ≥ rank) → False)
    (then_1_assume_12 : (Vermilion.Seq.index axes i ≥ rank) → False)
    (loop_1_exit_0 : Vermilion.inUnsignedRange 64 j)
    (loop_1_exit_1 : j ≤ i)
    (loop_1_exit_2 : i < rank)
    (loop_1_exit_3 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_1_exit_4 : Vermilion.Seq.index axes i < rank)
    (loop_1_exit_5 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_1_exit_6 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_1_exit_7 : (∀ (k : Int), (((0 ≤ k) ∧ (k < j)) → (¬ (Vermilion.Seq.index axes k = Vermilion.Seq.index axes i)))))
    (loop_1_exit_8 : (¬ (j < i)))
    (assert_8 : Vermilion.inUnsignedRange 64 (i + 1)) :
    (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < ((i + 1) % 18446744073709551616))) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.invariant_preserve_0_3

-- vrml:begin verified.is_permutation.assert_0_decreases e563d3261292d846
/--
Generated VC `verified.is_permutation.assert_0_decreases`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:40:23-40:31`
- Rust/SST construct: loop termination measure must decrease
- AssertId: `0_decreases`
- Statement hash: `e563d3261292d846`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩ ⟨Vermilion.Seq.index axes k⟩
-/
def assert_0_decreases_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 40
  startColumn := 23
  endLine := 40
  endColumn := 31
  assertId := "0_decreases"
  functionName := "verified.is_permutation"
  kind := "assert"
  statementHash := "e563d3261292d846"
}
@[vrml_obligation] theorem assert_0_decreases
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (j : Int)
    (loop_0_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (loop_0_iteration_3 : Vermilion.inUnsignedRange 64 i)
    (loop_0_iteration_4 : i ≤ rank)
    (loop_0_iteration_5 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_0_iteration_6 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_0_iteration_7 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_0_iteration_8 : i < rank)
    (assert_2 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (then_1_assume_11 : (Vermilion.Seq.index axes i ≥ rank) → False)
    (then_1_assume_12 : (Vermilion.Seq.index axes i ≥ rank) → False)
    (loop_1_exit_0 : Vermilion.inUnsignedRange 64 j)
    (loop_1_exit_1 : j ≤ i)
    (loop_1_exit_2 : i < rank)
    (loop_1_exit_3 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_1_exit_4 : Vermilion.Seq.index axes i < rank)
    (loop_1_exit_5 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_1_exit_6 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_1_exit_7 : (∀ (k : Int), (((0 ≤ k) ∧ (k < j)) → (¬ (Vermilion.Seq.index axes k = Vermilion.Seq.index axes i)))))
    (loop_1_exit_8 : (¬ (j < i)))
    (assert_8 : Vermilion.inUnsignedRange 64 (i + 1)) :
    ((0 ≤ (rank - ((i + 1) % 18446744073709551616))) ∧ ((rank - ((i + 1) % 18446744073709551616)) < (rank - i))) ∨ (((rank - ((i + 1) % 18446744073709551616)) = (rank - i)) ∧ False) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.assert_0_decreases

-- vrml:begin verified.is_permutation.ensures_9 5674282dd1e7e12c
/--
Generated VC `verified.is_permutation.ensures_9`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:28:17-28:56`
- Rust/SST construct: function postcondition (`ensures`)
- AssertId: `9`
- Statement hash: `5674282dd1e7e12c`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes a, Vermilion.Seq.index axes b⟩
-/
def ensures_9_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 28
  startColumn := 17
  endLine := 28
  endColumn := 56
  assertId := "9"
  functionName := "verified.is_permutation"
  kind := "ensures"
  statementHash := "5674282dd1e7e12c"
}
@[vrml_obligation] theorem ensures_9
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (i : Int)
    (requires_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (requires_1 : Vermilion.inUnsignedRange 64 rank)
    (assume_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len axes))
    (then_0_assume_4 : (Vermilion.Seq.len axes ≠ rank) → False)
    (then_0_assume_5 : (Vermilion.Seq.len axes ≠ rank) → False)
    (loop_0_exit_0 : Vermilion.inUnsignedRange 64 i)
    (loop_0_exit_1 : i ≤ rank)
    (loop_0_exit_2 : vstd.slice.len_returns_clause_autospec axes = rank)
    (loop_0_exit_3 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index axes k < rank))))
    (loop_0_exit_4 : (∀ (a : Int) (b : Int), ((((0 ≤ a) ∧ (a < b)) ∧ (b < i)) → (¬ (Vermilion.Seq.index axes a = Vermilion.Seq.index axes b)))))
    (loop_0_exit_5 : (¬ (i < rank))) :
    True ↔ verified.valid_permutation axes rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.is_permutation.ensures_9

end verified.is_permutation

namespace verified.normalize_axis

-- vrml:begin verified.normalize_axis.ensures_0_0 7ac35a39f60ad73b
/--
Generated VC `verified.normalize_axis.ensures_0_0`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:71:13-71:57`
- Rust/SST construct: function postcondition (`ensures`)
- AssertId: `0_0`
- Statement hash: `7ac35a39f60ad73b`
-/
def ensures_0_0_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 71
  startColumn := 13
  endLine := 71
  endColumn := 57
  assertId := "0_0"
  functionName := "verified.normalize_axis"
  kind := "ensures"
  statementHash := "7ac35a39f60ad73b"
}
@[vrml_obligation] theorem ensures_0_0
    (rank : Int)
    (raw : Int)
    (requires_0 : Vermilion.inUnsignedRange 64 rank)
    (requires_1 : Vermilion.inSignedRange 64 raw)
    (branch_0 : (rank % 340282366920938463463374607431768211456) > (9223372036854775807 % 340282366920938463463374607431768211456)) :
    core.option.Option.None (V := Int) = verified.normalized_axis_model rank raw := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.normalize_axis.ensures_0_0

-- vrml:begin verified.normalize_axis.ensures_0_1 757dc380c5cafb47
/--
Generated VC `verified.normalize_axis.ensures_0_1`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:72:30-72:40`
- Rust/SST construct: function postcondition (`ensures`)
- AssertId: `0_1`
- Statement hash: `757dc380c5cafb47`
-/
def ensures_0_1_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 72
  startColumn := 30
  endLine := 72
  endColumn := 40
  assertId := "0_1"
  functionName := "verified.normalize_axis"
  kind := "ensures"
  statementHash := "757dc380c5cafb47"
}
@[vrml_obligation] theorem ensures_0_1
    (rank : Int)
    (raw : Int)
    (requires_0 : Vermilion.inUnsignedRange 64 rank)
    (requires_1 : Vermilion.inSignedRange 64 raw)
    (branch_0 : (rank % 340282366920938463463374607431768211456) > (9223372036854775807 % 340282366920938463463374607431768211456)) :
    ((core.option.Option.is_Some (core.option.Option.None (V := Int)) ∧ True) → (core.option.Option.get_Some__0 (core.option.Option.None (V := Int)) < rank)) ∧ ((¬ (core.option.Option.is_Some (core.option.Option.None (V := Int)) ∧ True)) → True) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.normalize_axis.ensures_0_1

-- vrml:begin verified.normalize_axis.assert_1 03f61d9554aa0988
/--
Generated VC `verified.normalize_axis.assert_1`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:79:22-79:34`
- Rust/SST construct: possible arithmetic underflow/overflow
- AssertId: `1`
- Statement hash: `03f61d9554aa0988`
-/
def assert_1_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 79
  startColumn := 22
  endLine := 79
  endColumn := 34
  assertId := "1"
  functionName := "verified.normalize_axis"
  kind := "assert"
  statementHash := "03f61d9554aa0988"
}
@[vrml_obligation] theorem assert_1
    (rank : Int)
    (raw : Int)
    (requires_0 : Vermilion.inUnsignedRange 64 rank)
    (requires_1 : Vermilion.inSignedRange 64 raw)
    (then_0_assume_3 : ((rank % 340282366920938463463374607431768211456) > (9223372036854775807 % 340282366920938463463374607431768211456)) → False)
    (then_0_assume_4 : ((rank % 340282366920938463463374607431768211456) > (9223372036854775807 % 340282366920938463463374607431768211456)) → False)
    (branch_1 : raw < 0) :
    Vermilion.inSignedRange 64 (0 - Vermilion.sclip 64 rank) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.normalize_axis.assert_1

-- vrml:begin verified.normalize_axis.ensures_2_0 d39edad90c28de71
/--
Generated VC `verified.normalize_axis.ensures_2_0`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:71:13-71:57`
- Rust/SST construct: function postcondition (`ensures`)
- AssertId: `2_0`
- Statement hash: `d39edad90c28de71`
-/
def ensures_2_0_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 71
  startColumn := 13
  endLine := 71
  endColumn := 57
  assertId := "2_0"
  functionName := "verified.normalize_axis"
  kind := "ensures"
  statementHash := "d39edad90c28de71"
}
@[vrml_obligation] theorem ensures_2_0
    (rank : Int)
    (raw : Int)
    (requires_0 : Vermilion.inUnsignedRange 64 rank)
    (requires_1 : Vermilion.inSignedRange 64 raw)
    (then_0_assume_3 : ((rank % 340282366920938463463374607431768211456) > (9223372036854775807 % 340282366920938463463374607431768211456)) → False)
    (then_0_assume_4 : ((rank % 340282366920938463463374607431768211456) > (9223372036854775807 % 340282366920938463463374607431768211456)) → False)
    (branch_1 : raw < 0)
    (assert_1 : Vermilion.inSignedRange 64 (0 - Vermilion.sclip 64 rank))
    (branch_2 : raw < Vermilion.sclip 64 (0 - Vermilion.sclip 64 rank)) :
    core.option.Option.None (V := Int) = verified.normalized_axis_model rank raw := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.normalize_axis.ensures_2_0

-- vrml:begin verified.normalize_axis.ensures_2_1 9f904e3092e72385
/--
Generated VC `verified.normalize_axis.ensures_2_1`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:72:30-72:40`
- Rust/SST construct: function postcondition (`ensures`)
- AssertId: `2_1`
- Statement hash: `9f904e3092e72385`
-/
def ensures_2_1_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 72
  startColumn := 30
  endLine := 72
  endColumn := 40
  assertId := "2_1"
  functionName := "verified.normalize_axis"
  kind := "ensures"
  statementHash := "9f904e3092e72385"
}
@[vrml_obligation] theorem ensures_2_1
    (rank : Int)
    (raw : Int)
    (requires_0 : Vermilion.inUnsignedRange 64 rank)
    (requires_1 : Vermilion.inSignedRange 64 raw)
    (then_0_assume_3 : ((rank % 340282366920938463463374607431768211456) > (9223372036854775807 % 340282366920938463463374607431768211456)) → False)
    (then_0_assume_4 : ((rank % 340282366920938463463374607431768211456) > (9223372036854775807 % 340282366920938463463374607431768211456)) → False)
    (branch_1 : raw < 0)
    (assert_1 : Vermilion.inSignedRange 64 (0 - Vermilion.sclip 64 rank))
    (branch_2 : raw < Vermilion.sclip 64 (0 - Vermilion.sclip 64 rank)) :
    ((core.option.Option.is_Some (core.option.Option.None (V := Int)) ∧ True) → (core.option.Option.get_Some__0 (core.option.Option.None (V := Int)) < rank)) ∧ ((¬ (core.option.Option.is_Some (core.option.Option.None (V := Int)) ∧ True)) → True) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.normalize_axis.ensures_2_1

-- vrml:begin verified.normalize_axis.assert_3 3d524b5807f48a5b
/--
Generated VC `verified.normalize_axis.assert_3`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:82:25-82:44`
- Rust/SST construct: possible arithmetic underflow/overflow
- AssertId: `3`
- Statement hash: `3d524b5807f48a5b`
-/
def assert_3_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 82
  startColumn := 25
  endLine := 82
  endColumn := 44
  assertId := "3"
  functionName := "verified.normalize_axis"
  kind := "assert"
  statementHash := "3d524b5807f48a5b"
}
@[vrml_obligation] theorem assert_3
    (rank : Int)
    (raw : Int)
    (requires_0 : Vermilion.inUnsignedRange 64 rank)
    (requires_1 : Vermilion.inSignedRange 64 raw)
    (then_0_assume_3 : ((rank % 340282366920938463463374607431768211456) > (9223372036854775807 % 340282366920938463463374607431768211456)) → False)
    (then_0_assume_4 : ((rank % 340282366920938463463374607431768211456) > (9223372036854775807 % 340282366920938463463374607431768211456)) → False)
    (branch_1 : raw < 0)
    (assert_1 : Vermilion.inSignedRange 64 (0 - Vermilion.sclip 64 rank))
    (then_2_assume_7 : (raw < Vermilion.sclip 64 (0 - Vermilion.sclip 64 rank)) → False)
    (then_2_assume_8 : (raw < Vermilion.sclip 64 (0 - Vermilion.sclip 64 rank)) → False) :
    Vermilion.inSignedRange 64 (raw + Vermilion.sclip 64 rank) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.normalize_axis.assert_3

-- vrml:begin verified.normalize_axis.ensures_4_0 243349815a97efe4
/--
Generated VC `verified.normalize_axis.ensures_4_0`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:71:13-71:57`
- Rust/SST construct: function postcondition (`ensures`)
- AssertId: `4_0`
- Statement hash: `243349815a97efe4`
-/
def ensures_4_0_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 71
  startColumn := 13
  endLine := 71
  endColumn := 57
  assertId := "4_0"
  functionName := "verified.normalize_axis"
  kind := "ensures"
  statementHash := "243349815a97efe4"
}
@[vrml_obligation] theorem ensures_4_0
    (rank : Int)
    (raw : Int)
    (requires_0 : Vermilion.inUnsignedRange 64 rank)
    (requires_1 : Vermilion.inSignedRange 64 raw)
    (then_0_assume_3 : ((rank % 340282366920938463463374607431768211456) > (9223372036854775807 % 340282366920938463463374607431768211456)) → False)
    (then_0_assume_4 : ((rank % 340282366920938463463374607431768211456) > (9223372036854775807 % 340282366920938463463374607431768211456)) → False)
    (branch_1 : raw < 0)
    (assert_1 : Vermilion.inSignedRange 64 (0 - Vermilion.sclip 64 rank))
    (then_2_assume_7 : (raw < Vermilion.sclip 64 (0 - Vermilion.sclip 64 rank)) → False)
    (then_2_assume_8 : (raw < Vermilion.sclip 64 (0 - Vermilion.sclip 64 rank)) → False)
    (assert_3 : Vermilion.inSignedRange 64 (raw + Vermilion.sclip 64 rank)) :
    core.option.Option.Some ((Vermilion.sclip 64 (raw + Vermilion.sclip 64 rank)) % 18446744073709551616) = verified.normalized_axis_model rank raw := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.normalize_axis.ensures_4_0

-- vrml:begin verified.normalize_axis.ensures_4_1 f94686916f565d60
/--
Generated VC `verified.normalize_axis.ensures_4_1`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:72:30-72:40`
- Rust/SST construct: function postcondition (`ensures`)
- AssertId: `4_1`
- Statement hash: `f94686916f565d60`
-/
def ensures_4_1_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 72
  startColumn := 30
  endLine := 72
  endColumn := 40
  assertId := "4_1"
  functionName := "verified.normalize_axis"
  kind := "ensures"
  statementHash := "f94686916f565d60"
}
@[vrml_obligation] theorem ensures_4_1
    (rank : Int)
    (raw : Int)
    (requires_0 : Vermilion.inUnsignedRange 64 rank)
    (requires_1 : Vermilion.inSignedRange 64 raw)
    (then_0_assume_3 : ((rank % 340282366920938463463374607431768211456) > (9223372036854775807 % 340282366920938463463374607431768211456)) → False)
    (then_0_assume_4 : ((rank % 340282366920938463463374607431768211456) > (9223372036854775807 % 340282366920938463463374607431768211456)) → False)
    (branch_1 : raw < 0)
    (assert_1 : Vermilion.inSignedRange 64 (0 - Vermilion.sclip 64 rank))
    (then_2_assume_7 : (raw < Vermilion.sclip 64 (0 - Vermilion.sclip 64 rank)) → False)
    (then_2_assume_8 : (raw < Vermilion.sclip 64 (0 - Vermilion.sclip 64 rank)) → False)
    (assert_3 : Vermilion.inSignedRange 64 (raw + Vermilion.sclip 64 rank)) :
    ((core.option.Option.is_Some (core.option.Option.Some ((Vermilion.sclip 64 (raw + Vermilion.sclip 64 rank)) % 18446744073709551616)) ∧ True) → (core.option.Option.get_Some__0 (core.option.Option.Some ((Vermilion.sclip 64 (raw + Vermilion.sclip 64 rank)) % 18446744073709551616)) < rank)) ∧ ((¬ (core.option.Option.is_Some (core.option.Option.Some ((Vermilion.sclip 64 (raw + Vermilion.sclip 64 rank)) % 18446744073709551616)) ∧ True)) → True) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.normalize_axis.ensures_4_1

-- vrml:begin verified.normalize_axis.ensures_5_0 75d2864fa95946df
/--
Generated VC `verified.normalize_axis.ensures_5_0`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:71:13-71:57`
- Rust/SST construct: function postcondition (`ensures`)
- AssertId: `5_0`
- Statement hash: `75d2864fa95946df`
-/
def ensures_5_0_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 71
  startColumn := 13
  endLine := 71
  endColumn := 57
  assertId := "5_0"
  functionName := "verified.normalize_axis"
  kind := "ensures"
  statementHash := "75d2864fa95946df"
}
@[vrml_obligation] theorem ensures_5_0
    (rank : Int)
    (raw : Int)
    (requires_0 : Vermilion.inUnsignedRange 64 rank)
    (requires_1 : Vermilion.inSignedRange 64 raw)
    (then_0_assume_3 : ((rank % 340282366920938463463374607431768211456) > (9223372036854775807 % 340282366920938463463374607431768211456)) → False)
    (then_0_assume_4 : ((rank % 340282366920938463463374607431768211456) > (9223372036854775807 % 340282366920938463463374607431768211456)) → False)
    (then_1_assert_1 : (raw < 0) → Vermilion.inSignedRange 64 (0 - Vermilion.sclip 64 rank))
    (then_1_then_2_assume_7 : (raw < 0) → ((raw < Vermilion.sclip 64 (0 - Vermilion.sclip 64 rank)) → False))
    (then_1_then_2_assume_8 : (raw < 0) → ((raw < Vermilion.sclip 64 (0 - Vermilion.sclip 64 rank)) → False))
    (then_1_assert_3 : (raw < 0) → Vermilion.inSignedRange 64 (raw + Vermilion.sclip 64 rank))
    (then_1_assume_9 : (raw < 0) → False)
    (then_1_assume_10 : (raw < 0) → False) :
    (Vermilion.iteP (raw ≥ Vermilion.sclip 64 rank) (core.option.Option.None (V := Int)) (core.option.Option.Some (raw % 18446744073709551616))) = verified.normalized_axis_model rank raw := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.normalize_axis.ensures_5_0

-- vrml:begin verified.normalize_axis.ensures_5_1 ebf0975187481270
/--
Generated VC `verified.normalize_axis.ensures_5_1`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:72:30-72:40`
- Rust/SST construct: function postcondition (`ensures`)
- AssertId: `5_1`
- Statement hash: `ebf0975187481270`
-/
def ensures_5_1_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 72
  startColumn := 30
  endLine := 72
  endColumn := 40
  assertId := "5_1"
  functionName := "verified.normalize_axis"
  kind := "ensures"
  statementHash := "ebf0975187481270"
}
@[vrml_obligation] theorem ensures_5_1
    (rank : Int)
    (raw : Int)
    (requires_0 : Vermilion.inUnsignedRange 64 rank)
    (requires_1 : Vermilion.inSignedRange 64 raw)
    (then_0_assume_3 : ((rank % 340282366920938463463374607431768211456) > (9223372036854775807 % 340282366920938463463374607431768211456)) → False)
    (then_0_assume_4 : ((rank % 340282366920938463463374607431768211456) > (9223372036854775807 % 340282366920938463463374607431768211456)) → False)
    (then_1_assert_1 : (raw < 0) → Vermilion.inSignedRange 64 (0 - Vermilion.sclip 64 rank))
    (then_1_then_2_assume_7 : (raw < 0) → ((raw < Vermilion.sclip 64 (0 - Vermilion.sclip 64 rank)) → False))
    (then_1_then_2_assume_8 : (raw < 0) → ((raw < Vermilion.sclip 64 (0 - Vermilion.sclip 64 rank)) → False))
    (then_1_assert_3 : (raw < 0) → Vermilion.inSignedRange 64 (raw + Vermilion.sclip 64 rank))
    (then_1_assume_9 : (raw < 0) → False)
    (then_1_assume_10 : (raw < 0) → False) :
    ((core.option.Option.is_Some (Vermilion.iteP (raw ≥ Vermilion.sclip 64 rank) (core.option.Option.None (V := Int)) (core.option.Option.Some (raw % 18446744073709551616))) ∧ True) → (core.option.Option.get_Some__0 (Vermilion.iteP (raw ≥ Vermilion.sclip 64 rank) (core.option.Option.None (V := Int)) (core.option.Option.Some (raw % 18446744073709551616))) < rank)) ∧ ((¬ (core.option.Option.is_Some (Vermilion.iteP (raw ≥ Vermilion.sclip 64 rank) (core.option.Option.None (V := Int)) (core.option.Option.Some (raw % 18446744073709551616))) ∧ True)) → True) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.normalize_axis.ensures_5_1

end verified.normalize_axis

namespace verified.reduction_survivors

-- vrml:begin verified.reduction_survivors.ensures_0 1d035484275540be
/--
Generated VC `verified.reduction_survivors.ensures_0`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:99:17-99:21`
- Rust/SST construct: function postcondition (`ensures`)
- AssertId: `0`
- Statement hash: `1d035484275540be`
- Triggers (Verus, for future e-matching): ⟨verified.survivor_at axis k⟩
-/
def ensures_0_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 99
  startColumn := 17
  endLine := 99
  endColumn := 21
  assertId := "0"
  functionName := "verified.reduction_survivors"
  kind := "ensures"
  statementHash := "1d035484275540be"
}
@[vrml_obligation] theorem ensures_0
    (rank : Int)
    (axis : Int)
    (requires_0 : Vermilion.inUnsignedRange 64 rank)
    (requires_1 : Vermilion.inUnsignedRange 64 axis)
    (branch_0 : axis ≥ rank) :
    (core.option.Option.is_None (core.option.Option.None (V := (Vermilion.Seq Int))) → (axis ≥ rank)) ∧ ((¬ core.option.Option.is_None (core.option.Option.None (V := (Vermilion.Seq Int)))) → (((axis < rank) ∧ (Vermilion.Seq.len (core.option.Option.get_Some__0 (core.option.Option.None (V := (Vermilion.Seq Int)))) = (rank - 1))) ∧ (∀ (k : Int), (((0 ≤ k) ∧ (k < Vermilion.Seq.len (core.option.Option.get_Some__0 (core.option.Option.None (V := (Vermilion.Seq Int)))))) → (Vermilion.Seq.index (core.option.Option.get_Some__0 (core.option.Option.None (V := (Vermilion.Seq Int)))) k = verified.survivor_at axis k))))) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.reduction_survivors.ensures_0

-- vrml:begin verified.reduction_survivors.invariant_entry_0_0 17a1f5c5e8b27170
/--
Generated VC `verified.reduction_survivors.invariant_entry_0_0`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:115:17-115:28`
- Rust/SST construct: loop invariant on entry
- AssertId: `0_0`
- Statement hash: `17a1f5c5e8b27170`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index tmp_ vrml_i0⟩
-/
def invariant_entry_0_0_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 115
  startColumn := 17
  endLine := 115
  endColumn := 28
  assertId := "0_0"
  functionName := "verified.reduction_survivors"
  kind := "invariant_entry"
  statementHash := "17a1f5c5e8b27170"
}
@[vrml_obligation] theorem invariant_entry_0_0
    (rank : Int)
    (axis : Int)
    (tmp_ : (Vermilion.Seq Int))
    (requires_0 : Vermilion.inUnsignedRange 64 rank)
    (requires_1 : Vermilion.inUnsignedRange 64 axis)
    (then_0_assume_3 : (axis ≥ rank) → False)
    (then_0_assume_4 : (axis ≥ rank) → False)
    (call_new_ensures_0 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (call_new_ensures_1 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (call_new_ensures_2 : tmp_ = (Vermilion.Seq.empty : Vermilion.Seq Int)) :
    axis < rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.reduction_survivors.invariant_entry_0_0

-- vrml:begin verified.reduction_survivors.invariant_entry_0_1 a021ea66b6915815
/--
Generated VC `verified.reduction_survivors.invariant_entry_0_1`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:116:17-116:26`
- Rust/SST construct: loop invariant on entry
- AssertId: `0_1`
- Statement hash: `a021ea66b6915815`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index tmp_ vrml_i0⟩
-/
def invariant_entry_0_1_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 116
  startColumn := 17
  endLine := 116
  endColumn := 26
  assertId := "0_1"
  functionName := "verified.reduction_survivors"
  kind := "invariant_entry"
  statementHash := "a021ea66b6915815"
}
@[vrml_obligation] theorem invariant_entry_0_1
    (rank : Int)
    (axis : Int)
    (tmp_ : (Vermilion.Seq Int))
    (requires_0 : Vermilion.inUnsignedRange 64 rank)
    (requires_1 : Vermilion.inUnsignedRange 64 axis)
    (then_0_assume_3 : (axis ≥ rank) → False)
    (then_0_assume_4 : (axis ≥ rank) → False)
    (call_new_ensures_0 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (call_new_ensures_1 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (call_new_ensures_2 : tmp_ = (Vermilion.Seq.empty : Vermilion.Seq Int)) :
    1 ≤ rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.reduction_survivors.invariant_entry_0_1

-- vrml:begin verified.reduction_survivors.invariant_entry_0_2 a857e1b426cbb1f4
/--
Generated VC `verified.reduction_survivors.invariant_entry_0_2`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:117:17-117:86`
- Rust/SST construct: loop invariant on entry
- AssertId: `0_2`
- Statement hash: `a857e1b426cbb1f4`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index tmp_ vrml_i0⟩
-/
def invariant_entry_0_2_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 117
  startColumn := 17
  endLine := 117
  endColumn := 86
  assertId := "0_2"
  functionName := "verified.reduction_survivors"
  kind := "invariant_entry"
  statementHash := "a857e1b426cbb1f4"
}
@[vrml_obligation] theorem invariant_entry_0_2
    (rank : Int)
    (axis : Int)
    (tmp_ : (Vermilion.Seq Int))
    (requires_0 : Vermilion.inUnsignedRange 64 rank)
    (requires_1 : Vermilion.inUnsignedRange 64 axis)
    (then_0_assume_3 : (axis ≥ rank) → False)
    (then_0_assume_4 : (axis ≥ rank) → False)
    (call_new_ensures_0 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (call_new_ensures_1 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (call_new_ensures_2 : tmp_ = (Vermilion.Seq.empty : Vermilion.Seq Int)) :
    Vermilion.Seq.len tmp_ = (Vermilion.iteP (1 ≤ axis) 1 (1 - 1)) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.reduction_survivors.invariant_entry_0_2

-- vrml:begin verified.reduction_survivors.invariant_entry_0_3 fb74030daac8fcbb
/--
Generated VC `verified.reduction_survivors.invariant_entry_0_3`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:118:17-119:69`
- Rust/SST construct: loop invariant on entry
- AssertId: `0_3`
- Statement hash: `fb74030daac8fcbb`
- Triggers (Verus, for future e-matching): ⟨verified.survivor_at axis k⟩ ⟨Vermilion.Seq.index tmp_ vrml_i0⟩
-/
def invariant_entry_0_3_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 118
  startColumn := 17
  endLine := 119
  endColumn := 69
  assertId := "0_3"
  functionName := "verified.reduction_survivors"
  kind := "invariant_entry"
  statementHash := "fb74030daac8fcbb"
}
@[vrml_obligation] theorem invariant_entry_0_3
    (rank : Int)
    (axis : Int)
    (tmp_ : (Vermilion.Seq Int))
    (requires_0 : Vermilion.inUnsignedRange 64 rank)
    (requires_1 : Vermilion.inUnsignedRange 64 axis)
    (then_0_assume_3 : (axis ≥ rank) → False)
    (then_0_assume_4 : (axis ≥ rank) → False)
    (call_new_ensures_0 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (call_new_ensures_1 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (call_new_ensures_2 : tmp_ = (Vermilion.Seq.empty : Vermilion.Seq Int)) :
    (∀ (k : Int), (((0 ≤ k) ∧ (k < Vermilion.Seq.len tmp_)) → (Vermilion.Seq.index tmp_ k = verified.survivor_at axis k))) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.reduction_survivors.invariant_entry_0_3

-- vrml:begin verified.reduction_survivors.assert_3 21e880a05edc2250
/--
Generated VC `verified.reduction_survivors.assert_3`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:125:13-125:19`
- Rust/SST construct: possible arithmetic underflow/overflow
- AssertId: `3`
- Statement hash: `21e880a05edc2250`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index tmp_ vrml_i0⟩ ⟨Vermilion.Seq.index positions vrml_i0⟩ ⟨verified.survivor_at axis k⟩ ⟨Vermilion.Seq.index tmp__post vrml_i0⟩ ⟨Vermilion.Seq.index positions_2 vrml_i0⟩
-/
def assert_3_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 125
  startColumn := 13
  endLine := 125
  endColumn := 19
  assertId := "3"
  functionName := "verified.reduction_survivors"
  kind := "assert"
  statementHash := "21e880a05edc2250"
}
@[vrml_obligation] theorem assert_3
    (rank : Int)
    (axis : Int)
    (tmp_ : (Vermilion.Seq Int))
    (positions : (Vermilion.Seq Int))
    (i : Int)
    (positions_2 : (Vermilion.Seq Int))
    (tmp__post : (Vermilion.Seq Int))
    (loop_0_iteration_0 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 axis)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (loop_0_iteration_3 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (loop_0_iteration_4 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len positions))
    (loop_0_iteration_5 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len positions)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index positions vrml_i0))))
    (loop_0_iteration_6 : Vermilion.inUnsignedRange 64 i)
    (loop_0_iteration_7 : axis < rank)
    (loop_0_iteration_8 : i ≤ rank)
    (loop_0_iteration_9 : Vermilion.Seq.len positions = (Vermilion.iteP (i ≤ axis) i (i - 1)))
    (loop_0_iteration_10 : (∀ (k : Int), (((0 ≤ k) ∧ (k < Vermilion.Seq.len positions)) → (Vermilion.Seq.index positions k = verified.survivor_at axis k))))
    (loop_0_iteration_11 : i < rank)
    (then_1_assume_13 : (i ≠ axis) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post))
    (then_1_assume_14 : (i ≠ axis) → (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post vrml_i0))))
    (then_1_call_push_ensures_0 : (i ≠ axis) → (tmp__post = Vermilion.Seq.push positions i))
    (then_1_assume_16 : (i ≠ axis) → (positions_2 = tmp__post))
    (else_1_assume_13 : (¬ (i ≠ axis)) → (positions_2 = positions))
    (assume_17 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len positions_2))
    (assume_18 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len positions_2)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index positions_2 vrml_i0)))) :
    Vermilion.inUnsignedRange 64 (i + 1) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.reduction_survivors.assert_3

-- vrml:begin verified.reduction_survivors.invariant_preserve_0_0 764aa7f09bfdd960
/--
Generated VC `verified.reduction_survivors.invariant_preserve_0_0`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:115:17-115:28`
- Rust/SST construct: loop invariant preserved by the body
- AssertId: `0_0`
- Statement hash: `764aa7f09bfdd960`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index tmp_ vrml_i0⟩ ⟨Vermilion.Seq.index positions vrml_i0⟩ ⟨verified.survivor_at axis k⟩ ⟨Vermilion.Seq.index tmp__post vrml_i0⟩ ⟨Vermilion.Seq.index positions_2 vrml_i0⟩
-/
def invariant_preserve_0_0_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 115
  startColumn := 17
  endLine := 115
  endColumn := 28
  assertId := "0_0"
  functionName := "verified.reduction_survivors"
  kind := "invariant_preserve"
  statementHash := "764aa7f09bfdd960"
}
@[vrml_obligation] theorem invariant_preserve_0_0
    (rank : Int)
    (axis : Int)
    (tmp_ : (Vermilion.Seq Int))
    (positions : (Vermilion.Seq Int))
    (i : Int)
    (positions_2 : (Vermilion.Seq Int))
    (tmp__post : (Vermilion.Seq Int))
    (loop_0_iteration_0 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 axis)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (loop_0_iteration_3 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (loop_0_iteration_4 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len positions))
    (loop_0_iteration_5 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len positions)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index positions vrml_i0))))
    (loop_0_iteration_6 : Vermilion.inUnsignedRange 64 i)
    (loop_0_iteration_7 : axis < rank)
    (loop_0_iteration_8 : i ≤ rank)
    (loop_0_iteration_9 : Vermilion.Seq.len positions = (Vermilion.iteP (i ≤ axis) i (i - 1)))
    (loop_0_iteration_10 : (∀ (k : Int), (((0 ≤ k) ∧ (k < Vermilion.Seq.len positions)) → (Vermilion.Seq.index positions k = verified.survivor_at axis k))))
    (loop_0_iteration_11 : i < rank)
    (then_1_assume_13 : (i ≠ axis) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post))
    (then_1_assume_14 : (i ≠ axis) → (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post vrml_i0))))
    (then_1_call_push_ensures_0 : (i ≠ axis) → (tmp__post = Vermilion.Seq.push positions i))
    (then_1_assume_16 : (i ≠ axis) → (positions_2 = tmp__post))
    (else_1_assume_13 : (¬ (i ≠ axis)) → (positions_2 = positions))
    (assume_17 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len positions_2))
    (assume_18 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len positions_2)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index positions_2 vrml_i0))))
    (assert_3 : Vermilion.inUnsignedRange 64 (i + 1)) :
    axis < rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.reduction_survivors.invariant_preserve_0_0

-- vrml:begin verified.reduction_survivors.invariant_preserve_0_1 79d000d1ff44a4d6
/--
Generated VC `verified.reduction_survivors.invariant_preserve_0_1`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:116:17-116:26`
- Rust/SST construct: loop invariant preserved by the body
- AssertId: `0_1`
- Statement hash: `79d000d1ff44a4d6`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index tmp_ vrml_i0⟩ ⟨Vermilion.Seq.index positions vrml_i0⟩ ⟨verified.survivor_at axis k⟩ ⟨Vermilion.Seq.index tmp__post vrml_i0⟩ ⟨Vermilion.Seq.index positions_2 vrml_i0⟩
-/
def invariant_preserve_0_1_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 116
  startColumn := 17
  endLine := 116
  endColumn := 26
  assertId := "0_1"
  functionName := "verified.reduction_survivors"
  kind := "invariant_preserve"
  statementHash := "79d000d1ff44a4d6"
}
@[vrml_obligation] theorem invariant_preserve_0_1
    (rank : Int)
    (axis : Int)
    (tmp_ : (Vermilion.Seq Int))
    (positions : (Vermilion.Seq Int))
    (i : Int)
    (positions_2 : (Vermilion.Seq Int))
    (tmp__post : (Vermilion.Seq Int))
    (loop_0_iteration_0 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 axis)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (loop_0_iteration_3 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (loop_0_iteration_4 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len positions))
    (loop_0_iteration_5 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len positions)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index positions vrml_i0))))
    (loop_0_iteration_6 : Vermilion.inUnsignedRange 64 i)
    (loop_0_iteration_7 : axis < rank)
    (loop_0_iteration_8 : i ≤ rank)
    (loop_0_iteration_9 : Vermilion.Seq.len positions = (Vermilion.iteP (i ≤ axis) i (i - 1)))
    (loop_0_iteration_10 : (∀ (k : Int), (((0 ≤ k) ∧ (k < Vermilion.Seq.len positions)) → (Vermilion.Seq.index positions k = verified.survivor_at axis k))))
    (loop_0_iteration_11 : i < rank)
    (then_1_assume_13 : (i ≠ axis) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post))
    (then_1_assume_14 : (i ≠ axis) → (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post vrml_i0))))
    (then_1_call_push_ensures_0 : (i ≠ axis) → (tmp__post = Vermilion.Seq.push positions i))
    (then_1_assume_16 : (i ≠ axis) → (positions_2 = tmp__post))
    (else_1_assume_13 : (¬ (i ≠ axis)) → (positions_2 = positions))
    (assume_17 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len positions_2))
    (assume_18 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len positions_2)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index positions_2 vrml_i0))))
    (assert_3 : Vermilion.inUnsignedRange 64 (i + 1)) :
    ((i + 1) % 18446744073709551616) ≤ rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.reduction_survivors.invariant_preserve_0_1

-- vrml:begin verified.reduction_survivors.invariant_preserve_0_2 c6877216856ed806
/--
Generated VC `verified.reduction_survivors.invariant_preserve_0_2`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:117:17-117:86`
- Rust/SST construct: loop invariant preserved by the body
- AssertId: `0_2`
- Statement hash: `c6877216856ed806`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index tmp_ vrml_i0⟩ ⟨Vermilion.Seq.index positions vrml_i0⟩ ⟨verified.survivor_at axis k⟩ ⟨Vermilion.Seq.index tmp__post vrml_i0⟩ ⟨Vermilion.Seq.index positions_2 vrml_i0⟩
-/
def invariant_preserve_0_2_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 117
  startColumn := 17
  endLine := 117
  endColumn := 86
  assertId := "0_2"
  functionName := "verified.reduction_survivors"
  kind := "invariant_preserve"
  statementHash := "c6877216856ed806"
}
@[vrml_obligation] theorem invariant_preserve_0_2
    (rank : Int)
    (axis : Int)
    (tmp_ : (Vermilion.Seq Int))
    (positions : (Vermilion.Seq Int))
    (i : Int)
    (positions_2 : (Vermilion.Seq Int))
    (tmp__post : (Vermilion.Seq Int))
    (loop_0_iteration_0 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 axis)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (loop_0_iteration_3 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (loop_0_iteration_4 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len positions))
    (loop_0_iteration_5 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len positions)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index positions vrml_i0))))
    (loop_0_iteration_6 : Vermilion.inUnsignedRange 64 i)
    (loop_0_iteration_7 : axis < rank)
    (loop_0_iteration_8 : i ≤ rank)
    (loop_0_iteration_9 : Vermilion.Seq.len positions = (Vermilion.iteP (i ≤ axis) i (i - 1)))
    (loop_0_iteration_10 : (∀ (k : Int), (((0 ≤ k) ∧ (k < Vermilion.Seq.len positions)) → (Vermilion.Seq.index positions k = verified.survivor_at axis k))))
    (loop_0_iteration_11 : i < rank)
    (then_1_assume_13 : (i ≠ axis) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post))
    (then_1_assume_14 : (i ≠ axis) → (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post vrml_i0))))
    (then_1_call_push_ensures_0 : (i ≠ axis) → (tmp__post = Vermilion.Seq.push positions i))
    (then_1_assume_16 : (i ≠ axis) → (positions_2 = tmp__post))
    (else_1_assume_13 : (¬ (i ≠ axis)) → (positions_2 = positions))
    (assume_17 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len positions_2))
    (assume_18 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len positions_2)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index positions_2 vrml_i0))))
    (assert_3 : Vermilion.inUnsignedRange 64 (i + 1)) :
    Vermilion.Seq.len positions_2 = (Vermilion.iteP (((i + 1) % 18446744073709551616) ≤ axis) ((i + 1) % 18446744073709551616) (((i + 1) % 18446744073709551616) - 1)) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.reduction_survivors.invariant_preserve_0_2

-- vrml:begin verified.reduction_survivors.invariant_preserve_0_3 e1a09664e344d1b9
/--
Generated VC `verified.reduction_survivors.invariant_preserve_0_3`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:118:17-119:69`
- Rust/SST construct: loop invariant preserved by the body
- AssertId: `0_3`
- Statement hash: `e1a09664e344d1b9`
- Triggers (Verus, for future e-matching): ⟨verified.survivor_at axis k⟩ ⟨Vermilion.Seq.index tmp_ vrml_i0⟩ ⟨Vermilion.Seq.index positions vrml_i0⟩ ⟨verified.survivor_at axis k⟩ ⟨Vermilion.Seq.index tmp__post vrml_i0⟩ ⟨Vermilion.Seq.index positions_2 vrml_i0⟩
-/
def invariant_preserve_0_3_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 118
  startColumn := 17
  endLine := 119
  endColumn := 69
  assertId := "0_3"
  functionName := "verified.reduction_survivors"
  kind := "invariant_preserve"
  statementHash := "e1a09664e344d1b9"
}
@[vrml_obligation] theorem invariant_preserve_0_3
    (rank : Int)
    (axis : Int)
    (tmp_ : (Vermilion.Seq Int))
    (positions : (Vermilion.Seq Int))
    (i : Int)
    (positions_2 : (Vermilion.Seq Int))
    (tmp__post : (Vermilion.Seq Int))
    (loop_0_iteration_0 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 axis)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (loop_0_iteration_3 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (loop_0_iteration_4 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len positions))
    (loop_0_iteration_5 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len positions)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index positions vrml_i0))))
    (loop_0_iteration_6 : Vermilion.inUnsignedRange 64 i)
    (loop_0_iteration_7 : axis < rank)
    (loop_0_iteration_8 : i ≤ rank)
    (loop_0_iteration_9 : Vermilion.Seq.len positions = (Vermilion.iteP (i ≤ axis) i (i - 1)))
    (loop_0_iteration_10 : (∀ (k : Int), (((0 ≤ k) ∧ (k < Vermilion.Seq.len positions)) → (Vermilion.Seq.index positions k = verified.survivor_at axis k))))
    (loop_0_iteration_11 : i < rank)
    (then_1_assume_13 : (i ≠ axis) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post))
    (then_1_assume_14 : (i ≠ axis) → (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post vrml_i0))))
    (then_1_call_push_ensures_0 : (i ≠ axis) → (tmp__post = Vermilion.Seq.push positions i))
    (then_1_assume_16 : (i ≠ axis) → (positions_2 = tmp__post))
    (else_1_assume_13 : (¬ (i ≠ axis)) → (positions_2 = positions))
    (assume_17 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len positions_2))
    (assume_18 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len positions_2)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index positions_2 vrml_i0))))
    (assert_3 : Vermilion.inUnsignedRange 64 (i + 1)) :
    (∀ (k : Int), (((0 ≤ k) ∧ (k < Vermilion.Seq.len positions_2)) → (Vermilion.Seq.index positions_2 k = verified.survivor_at axis k))) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.reduction_survivors.invariant_preserve_0_3

-- vrml:begin verified.reduction_survivors.assert_0_decreases eaab588684d212bd
/--
Generated VC `verified.reduction_survivors.assert_0_decreases`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:120:23-120:31`
- Rust/SST construct: loop termination measure must decrease
- AssertId: `0_decreases`
- Statement hash: `eaab588684d212bd`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index tmp_ vrml_i0⟩ ⟨Vermilion.Seq.index positions vrml_i0⟩ ⟨verified.survivor_at axis k⟩ ⟨Vermilion.Seq.index tmp__post vrml_i0⟩ ⟨Vermilion.Seq.index positions_2 vrml_i0⟩
-/
def assert_0_decreases_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 120
  startColumn := 23
  endLine := 120
  endColumn := 31
  assertId := "0_decreases"
  functionName := "verified.reduction_survivors"
  kind := "assert"
  statementHash := "eaab588684d212bd"
}
@[vrml_obligation] theorem assert_0_decreases
    (rank : Int)
    (axis : Int)
    (tmp_ : (Vermilion.Seq Int))
    (positions : (Vermilion.Seq Int))
    (i : Int)
    (positions_2 : (Vermilion.Seq Int))
    (tmp__post : (Vermilion.Seq Int))
    (loop_0_iteration_0 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 axis)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (loop_0_iteration_3 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (loop_0_iteration_4 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len positions))
    (loop_0_iteration_5 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len positions)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index positions vrml_i0))))
    (loop_0_iteration_6 : Vermilion.inUnsignedRange 64 i)
    (loop_0_iteration_7 : axis < rank)
    (loop_0_iteration_8 : i ≤ rank)
    (loop_0_iteration_9 : Vermilion.Seq.len positions = (Vermilion.iteP (i ≤ axis) i (i - 1)))
    (loop_0_iteration_10 : (∀ (k : Int), (((0 ≤ k) ∧ (k < Vermilion.Seq.len positions)) → (Vermilion.Seq.index positions k = verified.survivor_at axis k))))
    (loop_0_iteration_11 : i < rank)
    (then_1_assume_13 : (i ≠ axis) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post))
    (then_1_assume_14 : (i ≠ axis) → (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post vrml_i0))))
    (then_1_call_push_ensures_0 : (i ≠ axis) → (tmp__post = Vermilion.Seq.push positions i))
    (then_1_assume_16 : (i ≠ axis) → (positions_2 = tmp__post))
    (else_1_assume_13 : (¬ (i ≠ axis)) → (positions_2 = positions))
    (assume_17 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len positions_2))
    (assume_18 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len positions_2)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index positions_2 vrml_i0))))
    (assert_3 : Vermilion.inUnsignedRange 64 (i + 1)) :
    ((0 ≤ (rank - ((i + 1) % 18446744073709551616))) ∧ ((rank - ((i + 1) % 18446744073709551616)) < (rank - i))) ∨ (((rank - ((i + 1) % 18446744073709551616)) = (rank - i)) ∧ False) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.reduction_survivors.assert_0_decreases

-- vrml:begin verified.reduction_survivors.ensures_4 84bd908967b19a13
/--
Generated VC `verified.reduction_survivors.ensures_4`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:99:17-99:21`
- Rust/SST construct: function postcondition (`ensures`)
- AssertId: `4`
- Statement hash: `84bd908967b19a13`
- Triggers (Verus, for future e-matching): ⟨verified.survivor_at axis k⟩ ⟨Vermilion.Seq.index tmp_ vrml_i0⟩ ⟨Vermilion.Seq.index positions vrml_i0⟩ ⟨verified.survivor_at axis k⟩
-/
def ensures_4_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 99
  startColumn := 17
  endLine := 99
  endColumn := 21
  assertId := "4"
  functionName := "verified.reduction_survivors"
  kind := "ensures"
  statementHash := "84bd908967b19a13"
}
@[vrml_obligation] theorem ensures_4
    (rank : Int)
    (axis : Int)
    (tmp_ : (Vermilion.Seq Int))
    (positions : (Vermilion.Seq Int))
    (i : Int)
    (requires_0 : Vermilion.inUnsignedRange 64 rank)
    (requires_1 : Vermilion.inUnsignedRange 64 axis)
    (then_0_assume_3 : (axis ≥ rank) → False)
    (then_0_assume_4 : (axis ≥ rank) → False)
    (call_new_ensures_0 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (call_new_ensures_1 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (call_new_ensures_2 : tmp_ = (Vermilion.Seq.empty : Vermilion.Seq Int))
    (loop_0_exit_0 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len positions))
    (loop_0_exit_1 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len positions)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index positions vrml_i0))))
    (loop_0_exit_2 : Vermilion.inUnsignedRange 64 i)
    (loop_0_exit_3 : axis < rank)
    (loop_0_exit_4 : i ≤ rank)
    (loop_0_exit_5 : Vermilion.Seq.len positions = (Vermilion.iteP (i ≤ axis) i (i - 1)))
    (loop_0_exit_6 : (∀ (k : Int), (((0 ≤ k) ∧ (k < Vermilion.Seq.len positions)) → (Vermilion.Seq.index positions k = verified.survivor_at axis k))))
    (loop_0_exit_7 : (¬ (i < rank))) :
    (core.option.Option.is_None (core.option.Option.Some positions) → (axis ≥ rank)) ∧ ((¬ core.option.Option.is_None (core.option.Option.Some positions)) → (((axis < rank) ∧ (Vermilion.Seq.len (core.option.Option.get_Some__0 (core.option.Option.Some positions)) = (rank - 1))) ∧ (∀ (k : Int), (((0 ≤ k) ∧ (k < Vermilion.Seq.len (core.option.Option.get_Some__0 (core.option.Option.Some positions)))) → (Vermilion.Seq.index (core.option.Option.get_Some__0 (core.option.Option.Some positions)) k = verified.survivor_at axis k))))) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.reduction_survivors.ensures_4

end verified.reduction_survivors

namespace verified.checked_inverse

-- vrml:begin verified.checked_inverse.ensures_1 466919438e640e0e
/--
Generated VC `verified.checked_inverse.ensures_1`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:135:17-135:21`
- Rust/SST construct: function postcondition (`ensures`)
- AssertId: `1`
- Statement hash: `466919438e640e0e`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes i⟩ ⟨Vermilion.Seq.index axes vrml_i0⟩
-/
def ensures_1_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 135
  startColumn := 17
  endLine := 135
  endColumn := 21
  assertId := "1"
  functionName := "verified.checked_inverse"
  kind := "ensures"
  statementHash := "466919438e640e0e"
}
@[vrml_obligation] theorem ensures_1
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (requires_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (requires_1 : Vermilion.inUnsignedRange 64 rank)
    (branch_0 : (¬ verified.valid_permutation axes rank)) :
    (core.option.Option.is_None (core.option.Option.None (V := (Vermilion.Seq Int))) → (¬ verified.valid_permutation axes rank)) ∧ ((¬ core.option.Option.is_None (core.option.Option.None (V := (Vermilion.Seq Int)))) → ((verified.valid_permutation axes rank ∧ (Vermilion.Seq.len (core.option.Option.get_Some__0 (core.option.Option.None (V := (Vermilion.Seq Int)))) = rank)) ∧ (∀ (i : Int), (((0 ≤ i) ∧ (i < rank)) → (Vermilion.Seq.index (core.option.Option.get_Some__0 (core.option.Option.None (V := (Vermilion.Seq Int)))) (Vermilion.Seq.index axes i) = (i % 18446744073709551616)))))) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.checked_inverse.ensures_1

-- vrml:begin verified.checked_inverse.invariant_entry_0_0 c7f71d96181c1f9d
/--
Generated VC `verified.checked_inverse.invariant_entry_0_0`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:148:23-148:35`
- Rust/SST construct: loop invariant on entry
- AssertId: `0_0`
- Statement hash: `c7f71d96181c1f9d`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index tmp_ vrml_i0⟩
-/
def invariant_entry_0_0_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 148
  startColumn := 23
  endLine := 148
  endColumn := 35
  assertId := "0_0"
  functionName := "verified.checked_inverse"
  kind := "invariant_entry"
  statementHash := "c7f71d96181c1f9d"
}
@[vrml_obligation] theorem invariant_entry_0_0
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (tmp_ : (Vermilion.Seq Int))
    (requires_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (requires_1 : Vermilion.inUnsignedRange 64 rank)
    (then_0_assume_3 : (¬ verified.valid_permutation axes rank) → False)
    (then_0_assume_4 : (¬ verified.valid_permutation axes rank) → False)
    (call_new_ensures_0 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (call_new_ensures_1 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (call_new_ensures_2 : tmp_ = (Vermilion.Seq.empty : Vermilion.Seq Int)) :
    0 ≤ rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.checked_inverse.invariant_entry_0_0

-- vrml:begin verified.checked_inverse.invariant_entry_0_1 8f437bce4a916ce4
/--
Generated VC `verified.checked_inverse.invariant_entry_0_1`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:148:37-148:58`
- Rust/SST construct: loop invariant on entry
- AssertId: `0_1`
- Statement hash: `8f437bce4a916ce4`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index tmp_ vrml_i0⟩
-/
def invariant_entry_0_1_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 148
  startColumn := 37
  endLine := 148
  endColumn := 58
  assertId := "0_1"
  functionName := "verified.checked_inverse"
  kind := "invariant_entry"
  statementHash := "8f437bce4a916ce4"
}
@[vrml_obligation] theorem invariant_entry_0_1
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (tmp_ : (Vermilion.Seq Int))
    (requires_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (requires_1 : Vermilion.inUnsignedRange 64 rank)
    (then_0_assume_3 : (¬ verified.valid_permutation axes rank) → False)
    (then_0_assume_4 : (¬ verified.valid_permutation axes rank) → False)
    (call_new_ensures_0 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (call_new_ensures_1 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (call_new_ensures_2 : tmp_ = (Vermilion.Seq.empty : Vermilion.Seq Int)) :
    Vermilion.Seq.len tmp_ = 0 := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.checked_inverse.invariant_entry_0_1

-- vrml:begin verified.checked_inverse.assert_4 2694c02ebb0c832d
/--
Generated VC `verified.checked_inverse.assert_4`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:152:13-152:22`
- Rust/SST construct: possible arithmetic underflow/overflow
- AssertId: `4`
- Statement hash: `2694c02ebb0c832d`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index tmp_ vrml_i0⟩ ⟨Vermilion.Seq.index inverse vrml_i0⟩ ⟨Vermilion.Seq.index tmp__post vrml_i0⟩
-/
def assert_4_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 152
  startColumn := 13
  endLine := 152
  endColumn := 22
  assertId := "4"
  functionName := "verified.checked_inverse"
  kind := "assert"
  statementHash := "2694c02ebb0c832d"
}
@[vrml_obligation] theorem assert_4
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (tmp_ : (Vermilion.Seq Int))
    (inverse : (Vermilion.Seq Int))
    (fill : Int)
    (tmp__post : (Vermilion.Seq Int))
    (loop_0_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (loop_0_iteration_3 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (loop_0_iteration_4 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse))
    (loop_0_iteration_5 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse vrml_i0))))
    (loop_0_iteration_6 : Vermilion.inUnsignedRange 64 fill)
    (loop_0_iteration_7 : fill ≤ rank)
    (loop_0_iteration_8 : Vermilion.Seq.len inverse = fill)
    (loop_0_iteration_9 : fill < rank)
    (assume_10 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post))
    (assume_11 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post vrml_i0))))
    (call_push_ensures_0 : tmp__post = Vermilion.Seq.push inverse 0) :
    Vermilion.inUnsignedRange 64 (fill + 1) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.checked_inverse.assert_4

-- vrml:begin verified.checked_inverse.invariant_preserve_0_0 fcf4726a8a3a0ac6
/--
Generated VC `verified.checked_inverse.invariant_preserve_0_0`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:148:23-148:35`
- Rust/SST construct: loop invariant preserved by the body
- AssertId: `0_0`
- Statement hash: `fcf4726a8a3a0ac6`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index tmp_ vrml_i0⟩ ⟨Vermilion.Seq.index inverse vrml_i0⟩ ⟨Vermilion.Seq.index tmp__post vrml_i0⟩
-/
def invariant_preserve_0_0_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 148
  startColumn := 23
  endLine := 148
  endColumn := 35
  assertId := "0_0"
  functionName := "verified.checked_inverse"
  kind := "invariant_preserve"
  statementHash := "fcf4726a8a3a0ac6"
}
@[vrml_obligation] theorem invariant_preserve_0_0
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (tmp_ : (Vermilion.Seq Int))
    (inverse : (Vermilion.Seq Int))
    (fill : Int)
    (tmp__post : (Vermilion.Seq Int))
    (loop_0_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (loop_0_iteration_3 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (loop_0_iteration_4 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse))
    (loop_0_iteration_5 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse vrml_i0))))
    (loop_0_iteration_6 : Vermilion.inUnsignedRange 64 fill)
    (loop_0_iteration_7 : fill ≤ rank)
    (loop_0_iteration_8 : Vermilion.Seq.len inverse = fill)
    (loop_0_iteration_9 : fill < rank)
    (assume_10 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post))
    (assume_11 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post vrml_i0))))
    (call_push_ensures_0 : tmp__post = Vermilion.Seq.push inverse 0)
    (assert_4 : Vermilion.inUnsignedRange 64 (fill + 1)) :
    ((fill + 1) % 18446744073709551616) ≤ rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.checked_inverse.invariant_preserve_0_0

-- vrml:begin verified.checked_inverse.invariant_preserve_0_1 6f4fcd9f966d0c1c
/--
Generated VC `verified.checked_inverse.invariant_preserve_0_1`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:148:37-148:58`
- Rust/SST construct: loop invariant preserved by the body
- AssertId: `0_1`
- Statement hash: `6f4fcd9f966d0c1c`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index tmp_ vrml_i0⟩ ⟨Vermilion.Seq.index inverse vrml_i0⟩ ⟨Vermilion.Seq.index tmp__post vrml_i0⟩
-/
def invariant_preserve_0_1_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 148
  startColumn := 37
  endLine := 148
  endColumn := 58
  assertId := "0_1"
  functionName := "verified.checked_inverse"
  kind := "invariant_preserve"
  statementHash := "6f4fcd9f966d0c1c"
}
@[vrml_obligation] theorem invariant_preserve_0_1
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (tmp_ : (Vermilion.Seq Int))
    (inverse : (Vermilion.Seq Int))
    (fill : Int)
    (tmp__post : (Vermilion.Seq Int))
    (loop_0_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (loop_0_iteration_3 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (loop_0_iteration_4 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse))
    (loop_0_iteration_5 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse vrml_i0))))
    (loop_0_iteration_6 : Vermilion.inUnsignedRange 64 fill)
    (loop_0_iteration_7 : fill ≤ rank)
    (loop_0_iteration_8 : Vermilion.Seq.len inverse = fill)
    (loop_0_iteration_9 : fill < rank)
    (assume_10 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post))
    (assume_11 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post vrml_i0))))
    (call_push_ensures_0 : tmp__post = Vermilion.Seq.push inverse 0)
    (assert_4 : Vermilion.inUnsignedRange 64 (fill + 1)) :
    Vermilion.Seq.len tmp__post = ((fill + 1) % 18446744073709551616) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.checked_inverse.invariant_preserve_0_1

-- vrml:begin verified.checked_inverse.assert_0_decreases f8d2ef4eb8ce5237
/--
Generated VC `verified.checked_inverse.assert_0_decreases`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:149:23-149:34`
- Rust/SST construct: loop termination measure must decrease
- AssertId: `0_decreases`
- Statement hash: `f8d2ef4eb8ce5237`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index tmp_ vrml_i0⟩ ⟨Vermilion.Seq.index inverse vrml_i0⟩ ⟨Vermilion.Seq.index tmp__post vrml_i0⟩
-/
def assert_0_decreases_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 149
  startColumn := 23
  endLine := 149
  endColumn := 34
  assertId := "0_decreases"
  functionName := "verified.checked_inverse"
  kind := "assert"
  statementHash := "f8d2ef4eb8ce5237"
}
@[vrml_obligation] theorem assert_0_decreases
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (tmp_ : (Vermilion.Seq Int))
    (inverse : (Vermilion.Seq Int))
    (fill : Int)
    (tmp__post : (Vermilion.Seq Int))
    (loop_0_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_0_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_0_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (loop_0_iteration_3 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (loop_0_iteration_4 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse))
    (loop_0_iteration_5 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse vrml_i0))))
    (loop_0_iteration_6 : Vermilion.inUnsignedRange 64 fill)
    (loop_0_iteration_7 : fill ≤ rank)
    (loop_0_iteration_8 : Vermilion.Seq.len inverse = fill)
    (loop_0_iteration_9 : fill < rank)
    (assume_10 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post))
    (assume_11 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post vrml_i0))))
    (call_push_ensures_0 : tmp__post = Vermilion.Seq.push inverse 0)
    (assert_4 : Vermilion.inUnsignedRange 64 (fill + 1)) :
    ((0 ≤ (rank - ((fill + 1) % 18446744073709551616))) ∧ ((rank - ((fill + 1) % 18446744073709551616)) < (rank - fill))) ∨ (((rank - ((fill + 1) % 18446744073709551616)) = (rank - fill)) ∧ False) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.checked_inverse.assert_0_decreases

-- vrml:begin verified.checked_inverse.invariant_entry_1_0 d97429c288f75f5e
/--
Generated VC `verified.checked_inverse.invariant_entry_1_0`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:157:17-157:26`
- Rust/SST construct: loop invariant on entry
- AssertId: `1_0`
- Statement hash: `d97429c288f75f5e`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index tmp_ vrml_i0⟩ ⟨Vermilion.Seq.index inverse vrml_i0⟩
-/
def invariant_entry_1_0_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 157
  startColumn := 17
  endLine := 157
  endColumn := 26
  assertId := "1_0"
  functionName := "verified.checked_inverse"
  kind := "invariant_entry"
  statementHash := "d97429c288f75f5e"
}
@[vrml_obligation] theorem invariant_entry_1_0
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (tmp_ : (Vermilion.Seq Int))
    (inverse : (Vermilion.Seq Int))
    (fill : Int)
    (requires_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (requires_1 : Vermilion.inUnsignedRange 64 rank)
    (then_0_assume_3 : (¬ verified.valid_permutation axes rank) → False)
    (then_0_assume_4 : (¬ verified.valid_permutation axes rank) → False)
    (call_new_ensures_0 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (call_new_ensures_1 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (call_new_ensures_2 : tmp_ = (Vermilion.Seq.empty : Vermilion.Seq Int))
    (loop_0_exit_0 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse))
    (loop_0_exit_1 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse vrml_i0))))
    (loop_0_exit_2 : Vermilion.inUnsignedRange 64 fill)
    (loop_0_exit_3 : fill ≤ rank)
    (loop_0_exit_4 : Vermilion.Seq.len inverse = fill)
    (loop_0_exit_5 : (¬ (fill < rank))) :
    0 ≤ rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.checked_inverse.invariant_entry_1_0

-- vrml:begin verified.checked_inverse.invariant_entry_1_1 95a115dc62794667
/--
Generated VC `verified.checked_inverse.invariant_entry_1_1`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:158:17-158:47`
- Rust/SST construct: loop invariant on entry
- AssertId: `1_1`
- Statement hash: `95a115dc62794667`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index tmp_ vrml_i0⟩ ⟨Vermilion.Seq.index inverse vrml_i0⟩
-/
def invariant_entry_1_1_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 158
  startColumn := 17
  endLine := 158
  endColumn := 47
  assertId := "1_1"
  functionName := "verified.checked_inverse"
  kind := "invariant_entry"
  statementHash := "95a115dc62794667"
}
@[vrml_obligation] theorem invariant_entry_1_1
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (tmp_ : (Vermilion.Seq Int))
    (inverse : (Vermilion.Seq Int))
    (fill : Int)
    (requires_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (requires_1 : Vermilion.inUnsignedRange 64 rank)
    (then_0_assume_3 : (¬ verified.valid_permutation axes rank) → False)
    (then_0_assume_4 : (¬ verified.valid_permutation axes rank) → False)
    (call_new_ensures_0 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (call_new_ensures_1 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (call_new_ensures_2 : tmp_ = (Vermilion.Seq.empty : Vermilion.Seq Int))
    (loop_0_exit_0 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse))
    (loop_0_exit_1 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse vrml_i0))))
    (loop_0_exit_2 : Vermilion.inUnsignedRange 64 fill)
    (loop_0_exit_3 : fill ≤ rank)
    (loop_0_exit_4 : Vermilion.Seq.len inverse = fill)
    (loop_0_exit_5 : (¬ (fill < rank))) :
    verified.valid_permutation axes rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.checked_inverse.invariant_entry_1_1

-- vrml:begin verified.checked_inverse.invariant_entry_1_2 bd281d6d0afe6055
/--
Generated VC `verified.checked_inverse.invariant_entry_1_2`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:159:17-159:38`
- Rust/SST construct: loop invariant on entry
- AssertId: `1_2`
- Statement hash: `bd281d6d0afe6055`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index tmp_ vrml_i0⟩ ⟨Vermilion.Seq.index inverse vrml_i0⟩
-/
def invariant_entry_1_2_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 159
  startColumn := 17
  endLine := 159
  endColumn := 38
  assertId := "1_2"
  functionName := "verified.checked_inverse"
  kind := "invariant_entry"
  statementHash := "bd281d6d0afe6055"
}
@[vrml_obligation] theorem invariant_entry_1_2
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (tmp_ : (Vermilion.Seq Int))
    (inverse : (Vermilion.Seq Int))
    (fill : Int)
    (requires_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (requires_1 : Vermilion.inUnsignedRange 64 rank)
    (then_0_assume_3 : (¬ verified.valid_permutation axes rank) → False)
    (then_0_assume_4 : (¬ verified.valid_permutation axes rank) → False)
    (call_new_ensures_0 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (call_new_ensures_1 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (call_new_ensures_2 : tmp_ = (Vermilion.Seq.empty : Vermilion.Seq Int))
    (loop_0_exit_0 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse))
    (loop_0_exit_1 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse vrml_i0))))
    (loop_0_exit_2 : Vermilion.inUnsignedRange 64 fill)
    (loop_0_exit_3 : fill ≤ rank)
    (loop_0_exit_4 : Vermilion.Seq.len inverse = fill)
    (loop_0_exit_5 : (¬ (fill < rank))) :
    Vermilion.Seq.len inverse = rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.checked_inverse.invariant_entry_1_2

-- vrml:begin verified.checked_inverse.invariant_entry_1_3 4b3d26f69f614103
/--
Generated VC `verified.checked_inverse.invariant_entry_1_3`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:160:17-161:64`
- Rust/SST construct: loop invariant on entry
- AssertId: `1_3`
- Statement hash: `4b3d26f69f614103`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index tmp_ vrml_i0⟩ ⟨Vermilion.Seq.index inverse vrml_i0⟩
-/
def invariant_entry_1_3_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 160
  startColumn := 17
  endLine := 161
  endColumn := 64
  assertId := "1_3"
  functionName := "verified.checked_inverse"
  kind := "invariant_entry"
  statementHash := "4b3d26f69f614103"
}
@[vrml_obligation] theorem invariant_entry_1_3
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (tmp_ : (Vermilion.Seq Int))
    (inverse : (Vermilion.Seq Int))
    (fill : Int)
    (requires_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (requires_1 : Vermilion.inUnsignedRange 64 rank)
    (then_0_assume_3 : (¬ verified.valid_permutation axes rank) → False)
    (then_0_assume_4 : (¬ verified.valid_permutation axes rank) → False)
    (call_new_ensures_0 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (call_new_ensures_1 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (call_new_ensures_2 : tmp_ = (Vermilion.Seq.empty : Vermilion.Seq Int))
    (loop_0_exit_0 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse))
    (loop_0_exit_1 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse vrml_i0))))
    (loop_0_exit_2 : Vermilion.inUnsignedRange 64 fill)
    (loop_0_exit_3 : fill ≤ rank)
    (loop_0_exit_4 : Vermilion.Seq.len inverse = fill)
    (loop_0_exit_5 : (¬ (fill < rank))) :
    (∀ (k : Int), (((0 ≤ k) ∧ (k < 0)) → (Vermilion.Seq.index inverse (Vermilion.Seq.index axes k) = (k % 18446744073709551616)))) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.checked_inverse.invariant_entry_1_3

-- vrml:begin verified.checked_inverse.assert_5 f792deb406c77d56
/--
Generated VC `verified.checked_inverse.assert_5`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:164:21-164:28`
- Rust/SST construct: precondition not met: index in bounds for this access
- AssertId: `5`
- Statement hash: `f792deb406c77d56`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index tmp_ vrml_i0⟩ ⟨Vermilion.Seq.index tmp__post vrml_i0⟩ ⟨Vermilion.Seq.index inverse vrml_i0⟩ ⟨Vermilion.Seq.index inverse_2 vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index tmp__post_2 vrml_i0⟩
-/
def assert_5_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 164
  startColumn := 21
  endLine := 164
  endColumn := 28
  assertId := "5"
  functionName := "verified.checked_inverse"
  kind := "assert"
  statementHash := "f792deb406c77d56"
}
@[vrml_obligation] theorem assert_5
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (tmp_ : (Vermilion.Seq Int))
    (inverse : (Vermilion.Seq Int))
    (fill : Int)
    (inverse_2 : (Vermilion.Seq Int))
    (i : Int)
    (tmp__post_2 : (Vermilion.Seq Int))
    (loop_1_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_1_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_1_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (loop_1_iteration_3 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (loop_1_iteration_4 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post))
    (loop_1_iteration_5 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post vrml_i0))))
    (loop_1_iteration_6 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse))
    (loop_1_iteration_7 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse vrml_i0))))
    (loop_1_iteration_8 : Vermilion.inUnsignedRange 64 fill)
    (loop_1_iteration_9 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse_2))
    (loop_1_iteration_10 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse_2)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse_2 vrml_i0))))
    (loop_1_iteration_11 : Vermilion.inUnsignedRange 64 i)
    (loop_1_iteration_12 : i ≤ rank)
    (loop_1_iteration_13 : verified.valid_permutation axes rank)
    (loop_1_iteration_14 : Vermilion.Seq.len inverse_2 = rank)
    (loop_1_iteration_15 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index inverse_2 (Vermilion.Seq.index axes k) = (k % 18446744073709551616)))))
    (loop_1_iteration_16 : i < rank)
    (assume_17 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post_2))
    (assume_18 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post_2)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post_2 vrml_i0)))) :
    (0 ≤ i) ∧ (i < Vermilion.Seq.len axes) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.checked_inverse.assert_5

-- vrml:begin verified.checked_inverse.call_requires_6 ad49698917a4317d
/--
Generated VC `verified.checked_inverse.call_requires_6`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:164:13-164:29`
- Rust/SST construct: call vec_index_mut
- AssertId: `6`
- Statement hash: `ad49698917a4317d`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index tmp_ vrml_i0⟩ ⟨Vermilion.Seq.index tmp__post vrml_i0⟩ ⟨Vermilion.Seq.index inverse vrml_i0⟩ ⟨Vermilion.Seq.index inverse_2 vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index tmp__post_2 vrml_i0⟩
-/
def call_requires_6_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 164
  startColumn := 13
  endLine := 164
  endColumn := 29
  assertId := "6"
  functionName := "verified.checked_inverse"
  kind := "call_requires"
  statementHash := "ad49698917a4317d"
}
@[vrml_obligation] theorem call_requires_6
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (tmp_ : (Vermilion.Seq Int))
    (inverse : (Vermilion.Seq Int))
    (fill : Int)
    (inverse_2 : (Vermilion.Seq Int))
    (i : Int)
    (tmp__post_2 : (Vermilion.Seq Int))
    (tmp__post_3 : Int)
    (loop_1_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_1_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_1_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (loop_1_iteration_3 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (loop_1_iteration_4 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post))
    (loop_1_iteration_5 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post vrml_i0))))
    (loop_1_iteration_6 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse))
    (loop_1_iteration_7 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse vrml_i0))))
    (loop_1_iteration_8 : Vermilion.inUnsignedRange 64 fill)
    (loop_1_iteration_9 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse_2))
    (loop_1_iteration_10 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse_2)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse_2 vrml_i0))))
    (loop_1_iteration_11 : Vermilion.inUnsignedRange 64 i)
    (loop_1_iteration_12 : i ≤ rank)
    (loop_1_iteration_13 : verified.valid_permutation axes rank)
    (loop_1_iteration_14 : Vermilion.Seq.len inverse_2 = rank)
    (loop_1_iteration_15 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index inverse_2 (Vermilion.Seq.index axes k) = (k % 18446744073709551616)))))
    (loop_1_iteration_16 : i < rank)
    (assume_17 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post_2))
    (assume_18 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post_2)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post_2 vrml_i0))))
    (assert_5 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (assume_20 : Vermilion.inUnsignedRange 64 tmp__post_3) :
    Vermilion.Seq.index axes i < Vermilion.Seq.len inverse_2 := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.checked_inverse.call_requires_6

-- vrml:begin verified.checked_inverse.assert_7 96668c3902aedcc9
/--
Generated VC `verified.checked_inverse.assert_7`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:165:13-165:19`
- Rust/SST construct: possible arithmetic underflow/overflow
- AssertId: `7`
- Statement hash: `96668c3902aedcc9`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index tmp_ vrml_i0⟩ ⟨Vermilion.Seq.index tmp__post vrml_i0⟩ ⟨Vermilion.Seq.index inverse vrml_i0⟩ ⟨Vermilion.Seq.index inverse_2 vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index tmp__post_2 vrml_i0⟩
-/
def assert_7_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 165
  startColumn := 13
  endLine := 165
  endColumn := 19
  assertId := "7"
  functionName := "verified.checked_inverse"
  kind := "assert"
  statementHash := "96668c3902aedcc9"
}
@[vrml_obligation] theorem assert_7
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (tmp_ : (Vermilion.Seq Int))
    (inverse : (Vermilion.Seq Int))
    (fill : Int)
    (inverse_2 : (Vermilion.Seq Int))
    (i : Int)
    (tmp__post_2 : (Vermilion.Seq Int))
    (tmp__post_3 : Int)
    (tmp__2 : Int)
    (loop_1_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_1_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_1_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (loop_1_iteration_3 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (loop_1_iteration_4 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post))
    (loop_1_iteration_5 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post vrml_i0))))
    (loop_1_iteration_6 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse))
    (loop_1_iteration_7 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse vrml_i0))))
    (loop_1_iteration_8 : Vermilion.inUnsignedRange 64 fill)
    (loop_1_iteration_9 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse_2))
    (loop_1_iteration_10 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse_2)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse_2 vrml_i0))))
    (loop_1_iteration_11 : Vermilion.inUnsignedRange 64 i)
    (loop_1_iteration_12 : i ≤ rank)
    (loop_1_iteration_13 : verified.valid_permutation axes rank)
    (loop_1_iteration_14 : Vermilion.Seq.len inverse_2 = rank)
    (loop_1_iteration_15 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index inverse_2 (Vermilion.Seq.index axes k) = (k % 18446744073709551616)))))
    (loop_1_iteration_16 : i < rank)
    (assume_17 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post_2))
    (assume_18 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post_2)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post_2 vrml_i0))))
    (assert_5 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (assume_20 : Vermilion.inUnsignedRange 64 tmp__post_3)
    (call_vec_index_mut_ensures_0 : Vermilion.inUnsignedRange 64 tmp__2)
    (call_vec_index_mut_ensures_1 : tmp__2 = Vermilion.Seq.index inverse_2 (Vermilion.Seq.index axes i))
    (call_vec_index_mut_ensures_2 : tmp__post_2 = Vermilion.Seq.update inverse_2 (Vermilion.Seq.index axes i) tmp__post_3)
    (call_vec_index_mut_ensures_3 : tmp__post_3 = Vermilion.Seq.index tmp__post_2 (Vermilion.Seq.index axes i))
    (assume_25 : tmp__post_3 = i) :
    Vermilion.inUnsignedRange 64 (i + 1) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.checked_inverse.assert_7

-- vrml:begin verified.checked_inverse.invariant_preserve_1_0 e0ca4498efee8cb1
/--
Generated VC `verified.checked_inverse.invariant_preserve_1_0`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:157:17-157:26`
- Rust/SST construct: loop invariant preserved by the body
- AssertId: `1_0`
- Statement hash: `e0ca4498efee8cb1`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index tmp_ vrml_i0⟩ ⟨Vermilion.Seq.index tmp__post vrml_i0⟩ ⟨Vermilion.Seq.index inverse vrml_i0⟩ ⟨Vermilion.Seq.index inverse_2 vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index tmp__post_2 vrml_i0⟩
-/
def invariant_preserve_1_0_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 157
  startColumn := 17
  endLine := 157
  endColumn := 26
  assertId := "1_0"
  functionName := "verified.checked_inverse"
  kind := "invariant_preserve"
  statementHash := "e0ca4498efee8cb1"
}
@[vrml_obligation] theorem invariant_preserve_1_0
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (tmp_ : (Vermilion.Seq Int))
    (inverse : (Vermilion.Seq Int))
    (fill : Int)
    (inverse_2 : (Vermilion.Seq Int))
    (i : Int)
    (tmp__post_2 : (Vermilion.Seq Int))
    (tmp__post_3 : Int)
    (tmp__2 : Int)
    (loop_1_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_1_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_1_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (loop_1_iteration_3 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (loop_1_iteration_4 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post))
    (loop_1_iteration_5 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post vrml_i0))))
    (loop_1_iteration_6 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse))
    (loop_1_iteration_7 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse vrml_i0))))
    (loop_1_iteration_8 : Vermilion.inUnsignedRange 64 fill)
    (loop_1_iteration_9 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse_2))
    (loop_1_iteration_10 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse_2)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse_2 vrml_i0))))
    (loop_1_iteration_11 : Vermilion.inUnsignedRange 64 i)
    (loop_1_iteration_12 : i ≤ rank)
    (loop_1_iteration_13 : verified.valid_permutation axes rank)
    (loop_1_iteration_14 : Vermilion.Seq.len inverse_2 = rank)
    (loop_1_iteration_15 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index inverse_2 (Vermilion.Seq.index axes k) = (k % 18446744073709551616)))))
    (loop_1_iteration_16 : i < rank)
    (assume_17 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post_2))
    (assume_18 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post_2)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post_2 vrml_i0))))
    (assert_5 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (assume_20 : Vermilion.inUnsignedRange 64 tmp__post_3)
    (call_vec_index_mut_ensures_0 : Vermilion.inUnsignedRange 64 tmp__2)
    (call_vec_index_mut_ensures_1 : tmp__2 = Vermilion.Seq.index inverse_2 (Vermilion.Seq.index axes i))
    (call_vec_index_mut_ensures_2 : tmp__post_2 = Vermilion.Seq.update inverse_2 (Vermilion.Seq.index axes i) tmp__post_3)
    (call_vec_index_mut_ensures_3 : tmp__post_3 = Vermilion.Seq.index tmp__post_2 (Vermilion.Seq.index axes i))
    (assume_25 : tmp__post_3 = i)
    (assert_7 : Vermilion.inUnsignedRange 64 (i + 1)) :
    ((i + 1) % 18446744073709551616) ≤ rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.checked_inverse.invariant_preserve_1_0

-- vrml:begin verified.checked_inverse.invariant_preserve_1_1 f4c3f179731b10b4
/--
Generated VC `verified.checked_inverse.invariant_preserve_1_1`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:158:17-158:47`
- Rust/SST construct: loop invariant preserved by the body
- AssertId: `1_1`
- Statement hash: `f4c3f179731b10b4`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index tmp_ vrml_i0⟩ ⟨Vermilion.Seq.index tmp__post vrml_i0⟩ ⟨Vermilion.Seq.index inverse vrml_i0⟩ ⟨Vermilion.Seq.index inverse_2 vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index tmp__post_2 vrml_i0⟩
-/
def invariant_preserve_1_1_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 158
  startColumn := 17
  endLine := 158
  endColumn := 47
  assertId := "1_1"
  functionName := "verified.checked_inverse"
  kind := "invariant_preserve"
  statementHash := "f4c3f179731b10b4"
}
@[vrml_obligation] theorem invariant_preserve_1_1
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (tmp_ : (Vermilion.Seq Int))
    (inverse : (Vermilion.Seq Int))
    (fill : Int)
    (inverse_2 : (Vermilion.Seq Int))
    (i : Int)
    (tmp__post_2 : (Vermilion.Seq Int))
    (tmp__post_3 : Int)
    (tmp__2 : Int)
    (loop_1_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_1_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_1_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (loop_1_iteration_3 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (loop_1_iteration_4 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post))
    (loop_1_iteration_5 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post vrml_i0))))
    (loop_1_iteration_6 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse))
    (loop_1_iteration_7 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse vrml_i0))))
    (loop_1_iteration_8 : Vermilion.inUnsignedRange 64 fill)
    (loop_1_iteration_9 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse_2))
    (loop_1_iteration_10 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse_2)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse_2 vrml_i0))))
    (loop_1_iteration_11 : Vermilion.inUnsignedRange 64 i)
    (loop_1_iteration_12 : i ≤ rank)
    (loop_1_iteration_13 : verified.valid_permutation axes rank)
    (loop_1_iteration_14 : Vermilion.Seq.len inverse_2 = rank)
    (loop_1_iteration_15 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index inverse_2 (Vermilion.Seq.index axes k) = (k % 18446744073709551616)))))
    (loop_1_iteration_16 : i < rank)
    (assume_17 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post_2))
    (assume_18 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post_2)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post_2 vrml_i0))))
    (assert_5 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (assume_20 : Vermilion.inUnsignedRange 64 tmp__post_3)
    (call_vec_index_mut_ensures_0 : Vermilion.inUnsignedRange 64 tmp__2)
    (call_vec_index_mut_ensures_1 : tmp__2 = Vermilion.Seq.index inverse_2 (Vermilion.Seq.index axes i))
    (call_vec_index_mut_ensures_2 : tmp__post_2 = Vermilion.Seq.update inverse_2 (Vermilion.Seq.index axes i) tmp__post_3)
    (call_vec_index_mut_ensures_3 : tmp__post_3 = Vermilion.Seq.index tmp__post_2 (Vermilion.Seq.index axes i))
    (assume_25 : tmp__post_3 = i)
    (assert_7 : Vermilion.inUnsignedRange 64 (i + 1)) :
    verified.valid_permutation axes rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.checked_inverse.invariant_preserve_1_1

-- vrml:begin verified.checked_inverse.invariant_preserve_1_2 2e6609d707f46596
/--
Generated VC `verified.checked_inverse.invariant_preserve_1_2`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:159:17-159:38`
- Rust/SST construct: loop invariant preserved by the body
- AssertId: `1_2`
- Statement hash: `2e6609d707f46596`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index tmp_ vrml_i0⟩ ⟨Vermilion.Seq.index tmp__post vrml_i0⟩ ⟨Vermilion.Seq.index inverse vrml_i0⟩ ⟨Vermilion.Seq.index inverse_2 vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index tmp__post_2 vrml_i0⟩
-/
def invariant_preserve_1_2_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 159
  startColumn := 17
  endLine := 159
  endColumn := 38
  assertId := "1_2"
  functionName := "verified.checked_inverse"
  kind := "invariant_preserve"
  statementHash := "2e6609d707f46596"
}
@[vrml_obligation] theorem invariant_preserve_1_2
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (tmp_ : (Vermilion.Seq Int))
    (inverse : (Vermilion.Seq Int))
    (fill : Int)
    (inverse_2 : (Vermilion.Seq Int))
    (i : Int)
    (tmp__post_2 : (Vermilion.Seq Int))
    (tmp__post_3 : Int)
    (tmp__2 : Int)
    (loop_1_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_1_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_1_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (loop_1_iteration_3 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (loop_1_iteration_4 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post))
    (loop_1_iteration_5 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post vrml_i0))))
    (loop_1_iteration_6 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse))
    (loop_1_iteration_7 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse vrml_i0))))
    (loop_1_iteration_8 : Vermilion.inUnsignedRange 64 fill)
    (loop_1_iteration_9 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse_2))
    (loop_1_iteration_10 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse_2)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse_2 vrml_i0))))
    (loop_1_iteration_11 : Vermilion.inUnsignedRange 64 i)
    (loop_1_iteration_12 : i ≤ rank)
    (loop_1_iteration_13 : verified.valid_permutation axes rank)
    (loop_1_iteration_14 : Vermilion.Seq.len inverse_2 = rank)
    (loop_1_iteration_15 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index inverse_2 (Vermilion.Seq.index axes k) = (k % 18446744073709551616)))))
    (loop_1_iteration_16 : i < rank)
    (assume_17 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post_2))
    (assume_18 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post_2)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post_2 vrml_i0))))
    (assert_5 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (assume_20 : Vermilion.inUnsignedRange 64 tmp__post_3)
    (call_vec_index_mut_ensures_0 : Vermilion.inUnsignedRange 64 tmp__2)
    (call_vec_index_mut_ensures_1 : tmp__2 = Vermilion.Seq.index inverse_2 (Vermilion.Seq.index axes i))
    (call_vec_index_mut_ensures_2 : tmp__post_2 = Vermilion.Seq.update inverse_2 (Vermilion.Seq.index axes i) tmp__post_3)
    (call_vec_index_mut_ensures_3 : tmp__post_3 = Vermilion.Seq.index tmp__post_2 (Vermilion.Seq.index axes i))
    (assume_25 : tmp__post_3 = i)
    (assert_7 : Vermilion.inUnsignedRange 64 (i + 1)) :
    Vermilion.Seq.len tmp__post_2 = rank := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.checked_inverse.invariant_preserve_1_2

-- vrml:begin verified.checked_inverse.invariant_preserve_1_3 06d0c4d17f7a46ec
/--
Generated VC `verified.checked_inverse.invariant_preserve_1_3`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:160:17-161:64`
- Rust/SST construct: loop invariant preserved by the body
- AssertId: `1_3`
- Statement hash: `06d0c4d17f7a46ec`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index tmp_ vrml_i0⟩ ⟨Vermilion.Seq.index tmp__post vrml_i0⟩ ⟨Vermilion.Seq.index inverse vrml_i0⟩ ⟨Vermilion.Seq.index inverse_2 vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index tmp__post_2 vrml_i0⟩
-/
def invariant_preserve_1_3_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 160
  startColumn := 17
  endLine := 161
  endColumn := 64
  assertId := "1_3"
  functionName := "verified.checked_inverse"
  kind := "invariant_preserve"
  statementHash := "06d0c4d17f7a46ec"
}
@[vrml_obligation] theorem invariant_preserve_1_3
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (tmp_ : (Vermilion.Seq Int))
    (inverse : (Vermilion.Seq Int))
    (fill : Int)
    (inverse_2 : (Vermilion.Seq Int))
    (i : Int)
    (tmp__post_2 : (Vermilion.Seq Int))
    (tmp__post_3 : Int)
    (tmp__2 : Int)
    (loop_1_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_1_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_1_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (loop_1_iteration_3 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (loop_1_iteration_4 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post))
    (loop_1_iteration_5 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post vrml_i0))))
    (loop_1_iteration_6 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse))
    (loop_1_iteration_7 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse vrml_i0))))
    (loop_1_iteration_8 : Vermilion.inUnsignedRange 64 fill)
    (loop_1_iteration_9 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse_2))
    (loop_1_iteration_10 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse_2)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse_2 vrml_i0))))
    (loop_1_iteration_11 : Vermilion.inUnsignedRange 64 i)
    (loop_1_iteration_12 : i ≤ rank)
    (loop_1_iteration_13 : verified.valid_permutation axes rank)
    (loop_1_iteration_14 : Vermilion.Seq.len inverse_2 = rank)
    (loop_1_iteration_15 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index inverse_2 (Vermilion.Seq.index axes k) = (k % 18446744073709551616)))))
    (loop_1_iteration_16 : i < rank)
    (assume_17 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post_2))
    (assume_18 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post_2)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post_2 vrml_i0))))
    (assert_5 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (assume_20 : Vermilion.inUnsignedRange 64 tmp__post_3)
    (call_vec_index_mut_ensures_0 : Vermilion.inUnsignedRange 64 tmp__2)
    (call_vec_index_mut_ensures_1 : tmp__2 = Vermilion.Seq.index inverse_2 (Vermilion.Seq.index axes i))
    (call_vec_index_mut_ensures_2 : tmp__post_2 = Vermilion.Seq.update inverse_2 (Vermilion.Seq.index axes i) tmp__post_3)
    (call_vec_index_mut_ensures_3 : tmp__post_3 = Vermilion.Seq.index tmp__post_2 (Vermilion.Seq.index axes i))
    (assume_25 : tmp__post_3 = i)
    (assert_7 : Vermilion.inUnsignedRange 64 (i + 1)) :
    (∀ (k : Int), (((0 ≤ k) ∧ (k < ((i + 1) % 18446744073709551616))) → (Vermilion.Seq.index tmp__post_2 (Vermilion.Seq.index axes k) = (k % 18446744073709551616)))) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.checked_inverse.invariant_preserve_1_3

-- vrml:begin verified.checked_inverse.assert_1_decreases 28431c720444b22a
/--
Generated VC `verified.checked_inverse.assert_1_decreases`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:162:23-162:31`
- Rust/SST construct: loop termination measure must decrease
- AssertId: `1_decreases`
- Statement hash: `28431c720444b22a`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index tmp_ vrml_i0⟩ ⟨Vermilion.Seq.index tmp__post vrml_i0⟩ ⟨Vermilion.Seq.index inverse vrml_i0⟩ ⟨Vermilion.Seq.index inverse_2 vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩ ⟨Vermilion.Seq.index tmp__post_2 vrml_i0⟩
-/
def assert_1_decreases_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 162
  startColumn := 23
  endLine := 162
  endColumn := 31
  assertId := "1_decreases"
  functionName := "verified.checked_inverse"
  kind := "assert"
  statementHash := "28431c720444b22a"
}
@[vrml_obligation] theorem assert_1_decreases
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (tmp_ : (Vermilion.Seq Int))
    (inverse : (Vermilion.Seq Int))
    (fill : Int)
    (inverse_2 : (Vermilion.Seq Int))
    (i : Int)
    (tmp__post_2 : (Vermilion.Seq Int))
    (tmp__post_3 : Int)
    (tmp__2 : Int)
    (loop_1_iteration_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (loop_1_iteration_1 : Vermilion.inUnsignedRange 64 rank)
    (loop_1_iteration_2 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (loop_1_iteration_3 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (loop_1_iteration_4 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post))
    (loop_1_iteration_5 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post vrml_i0))))
    (loop_1_iteration_6 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse))
    (loop_1_iteration_7 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse vrml_i0))))
    (loop_1_iteration_8 : Vermilion.inUnsignedRange 64 fill)
    (loop_1_iteration_9 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse_2))
    (loop_1_iteration_10 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse_2)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse_2 vrml_i0))))
    (loop_1_iteration_11 : Vermilion.inUnsignedRange 64 i)
    (loop_1_iteration_12 : i ≤ rank)
    (loop_1_iteration_13 : verified.valid_permutation axes rank)
    (loop_1_iteration_14 : Vermilion.Seq.len inverse_2 = rank)
    (loop_1_iteration_15 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index inverse_2 (Vermilion.Seq.index axes k) = (k % 18446744073709551616)))))
    (loop_1_iteration_16 : i < rank)
    (assume_17 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp__post_2))
    (assume_18 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp__post_2)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp__post_2 vrml_i0))))
    (assert_5 : (0 ≤ i) ∧ (i < Vermilion.Seq.len axes))
    (assume_20 : Vermilion.inUnsignedRange 64 tmp__post_3)
    (call_vec_index_mut_ensures_0 : Vermilion.inUnsignedRange 64 tmp__2)
    (call_vec_index_mut_ensures_1 : tmp__2 = Vermilion.Seq.index inverse_2 (Vermilion.Seq.index axes i))
    (call_vec_index_mut_ensures_2 : tmp__post_2 = Vermilion.Seq.update inverse_2 (Vermilion.Seq.index axes i) tmp__post_3)
    (call_vec_index_mut_ensures_3 : tmp__post_3 = Vermilion.Seq.index tmp__post_2 (Vermilion.Seq.index axes i))
    (assume_25 : tmp__post_3 = i)
    (assert_7 : Vermilion.inUnsignedRange 64 (i + 1)) :
    ((0 ≤ (rank - ((i + 1) % 18446744073709551616))) ∧ ((rank - ((i + 1) % 18446744073709551616)) < (rank - i))) ∨ (((rank - ((i + 1) % 18446744073709551616)) = (rank - i)) ∧ False) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.checked_inverse.assert_1_decreases

-- vrml:begin verified.checked_inverse.ensures_8 a8ee678b261944dd
/--
Generated VC `verified.checked_inverse.ensures_8`.

- Rust source: `examples/chelis-campaign-509eee221613/verified.rs:135:17-135:21`
- Rust/SST construct: function postcondition (`ensures`)
- AssertId: `8`
- Statement hash: `a8ee678b261944dd`
- Triggers (Verus, for future e-matching): ⟨Vermilion.Seq.index axes i⟩ ⟨Vermilion.Seq.index axes vrml_i0⟩ ⟨Vermilion.Seq.index tmp_ vrml_i0⟩ ⟨Vermilion.Seq.index inverse vrml_i0⟩ ⟨Vermilion.Seq.index inverse_2 vrml_i0⟩ ⟨Vermilion.Seq.index axes k⟩
-/
def ensures_8_meta : Vermilion.ObligationMeta := {
  rustFile := "examples/chelis-campaign-509eee221613/verified.rs"
  startLine := 135
  startColumn := 17
  endLine := 135
  endColumn := 21
  assertId := "8"
  functionName := "verified.checked_inverse"
  kind := "ensures"
  statementHash := "a8ee678b261944dd"
}
@[vrml_obligation] theorem ensures_8
    (axes : (Vermilion.Seq Int))
    (rank : Int)
    (tmp_ : (Vermilion.Seq Int))
    (inverse : (Vermilion.Seq Int))
    (fill : Int)
    (inverse_2 : (Vermilion.Seq Int))
    (i : Int)
    (requires_0 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len axes)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index axes vrml_i0))))
    (requires_1 : Vermilion.inUnsignedRange 64 rank)
    (then_0_assume_3 : (¬ verified.valid_permutation axes rank) → False)
    (then_0_assume_4 : (¬ verified.valid_permutation axes rank) → False)
    (call_new_ensures_0 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len tmp_))
    (call_new_ensures_1 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len tmp_)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index tmp_ vrml_i0))))
    (call_new_ensures_2 : tmp_ = (Vermilion.Seq.empty : Vermilion.Seq Int))
    (loop_0_exit_0 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse))
    (loop_0_exit_1 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse vrml_i0))))
    (loop_0_exit_2 : Vermilion.inUnsignedRange 64 fill)
    (loop_0_exit_3 : fill ≤ rank)
    (loop_0_exit_4 : Vermilion.Seq.len inverse = fill)
    (loop_0_exit_5 : (¬ (fill < rank)))
    (loop_1_exit_0 : Vermilion.inUnsignedRange 64 (Vermilion.Seq.len inverse_2))
    (loop_1_exit_1 : (∀ (vrml_i0 : Int), (((0 ≤ vrml_i0) ∧ (vrml_i0 < Vermilion.Seq.len inverse_2)) → Vermilion.inUnsignedRange 64 (Vermilion.Seq.index inverse_2 vrml_i0))))
    (loop_1_exit_2 : Vermilion.inUnsignedRange 64 i)
    (loop_1_exit_3 : i ≤ rank)
    (loop_1_exit_4 : verified.valid_permutation axes rank)
    (loop_1_exit_5 : Vermilion.Seq.len inverse_2 = rank)
    (loop_1_exit_6 : (∀ (k : Int), (((0 ≤ k) ∧ (k < i)) → (Vermilion.Seq.index inverse_2 (Vermilion.Seq.index axes k) = (k % 18446744073709551616)))))
    (loop_1_exit_7 : (¬ (i < rank))) :
    (core.option.Option.is_None (core.option.Option.Some inverse_2) → (¬ verified.valid_permutation axes rank)) ∧ ((¬ core.option.Option.is_None (core.option.Option.Some inverse_2)) → ((verified.valid_permutation axes rank ∧ (Vermilion.Seq.len (core.option.Option.get_Some__0 (core.option.Option.Some inverse_2)) = rank)) ∧ (∀ (i : Int), (((0 ≤ i) ∧ (i < rank)) → (Vermilion.Seq.index (core.option.Option.get_Some__0 (core.option.Option.Some inverse_2)) (Vermilion.Seq.index axes i) = (i % 18446744073709551616)))))) := by
  vrml [verified.valid_permutation, vstd.slice.len_returns_clause_autospec, verified.normalized_axis_model, verified.survivor_at]
-- vrml:end verified.checked_inverse.ensures_8

end verified.checked_inverse

