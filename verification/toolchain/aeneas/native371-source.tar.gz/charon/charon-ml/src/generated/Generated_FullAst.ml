(** WARNING: this file is partially auto-generated. Do not edit `FullAst.ml` by
    hand. Edit `templates/FullAst.ml` instead, or improve the code generation
    tool so avoid the need for hand-writing things.

    `templates/FullAst.ml` contains the manual definitions and some `(*
    __REPLACEn__ *)` comments. These comments are replaced by auto-generated
    definitions by running `make generate-ml` in the crate root. The
    code-generation code is in `charon/src/bin/generate-ml`. *)

open Generated_GAst
open Generated_UllbcAst
open Generated_LlbcAst
open Generated_Types
open Generated_Values
open Generated_Expressions
open Generated_Meta
open Identifiers

(** The body of a function. *)
type body =
  | UnstructuredBody of Generated_UllbcAst.block list gexpr_body
      (** Body represented as a CFG. This is what ullbc is made of, and what we
          get after translating MIR. *)
  | StructuredBody of Generated_LlbcAst.block gexpr_body
      (** Body represented with structured control flow. This is what llbc is
          made of. We restructure the control flow in the [ullbc_to_llbc] pass.
      *)
  | TargetDispatchBody of (string * fun_decl_ref) list
      (** A façade body that dispatches to one of several per-target function
          bodies. Created during multi-target merging for functions with the
          same signature but different bodies across targets. *)
  | TraitMethodWithoutDefaultBody
      (** The body of the function item we add for each trait method
          declaration, if the trait doesn't provide a default for that method.
      *)
  | ExternBody of string
      (** Function declared in an [extern { ... }] block. The string is the
          foreign symbol name. *)
  | IntrinsicBody of string * string option list
      (** Rust intrinsic function.

          Fields:
          - [name]: The intrinsic name.
          - [arg_names]: The argument names, None if not available. *)
  | OpaqueBody
      (** A body that the user chose not to translate, based on opacity settings
          like [--include]/[--opaque]. *)
  | MissingBody
      (** A body that was not available. Typically that's function bodies for
          non-generic and non-inlineable std functions, as these are not present
          in the compiled standard library [.rmeta] file shipped with a rust
          toolchain. *)
  | ErrorBody of error
      (** We encountered an error while translating this body. *)

and cli_options = {
  ullbc : bool;
      (** Extract the unstructured LLBC (i.e., don't reconstruct the
          control-flow) *)
  precise_drops : bool;
      (** Whether to precisely translate drops and drop-related code. For this,
          we add explicit [Destruct] bounds to all generic parameters, set the
          MIR level to at least [elaborated], and attempt to retrieve drop glue
          for all types.

          This option is known to cause panics inside rustc, because their drop
          handling is not design to work on polymorphic types. To silence the
          warning, pass appropriate
          [--opaque '{impl core::marker::Destruct for some::Type}'] options.

          Without this option, drops may be "conditional" and we may lack
          information about what code is run on drop in a given polymorphic
          function body. *)
  skip_borrowck : bool;
      (** If activated, this skips borrow-checking of the crate. *)
  mir : mir_level option;
      (** The MIR stage to extract. For dependencies, [promoted] is available
          when charon compiled them; otherwise (e.g. the standard library), and
          at other stages, only MIR optimized is. *)
  rustc_args : string list;  (** Extra flags to pass to rustc. *)
  targets : string list;
      (** A list of target architectures to translate for. Charon will run the
          compiler once for each target and aggregate the results, which is
          useful if the code includes [#[cfg(..)]] filters. Warning: this is an
          initial implementation which is extremely slow. *)
  monomorphize : bool;
      (** Monomorphize the items encountered when possible. Generic items found
          in the crate are skipped. To only translate a particular call graph,
          use [--start-from]. Note: this doesn't currently support [dyn Trait].
      *)
  monomorphize_mut : monomorphize_mut option;
      (** Partially monomorphize items to make it so that no item is ever
          monomorphized with a mutable reference (or type containing one); said
          differently, so that the presence of mutable references in a type is
          independent of its generics. This is used by Aeneas. *)
  start_from : string list;
      (** A list of item paths to use as starting points for the translation. We
          will translate these items and any items they refer to, according to
          the opacity rules. When absent, we start from the path [crate] (which
          translates the whole crate). *)
  start_from_if_exists : string list;
      (** Same as --start-from, but won't raise an error if a pattern doesn't
          match any item. This is useful when the patterns are generated by a
          build script and may be out of sync with the code. *)
  start_from_attribute : string option;
      (** Use all the items annotated with the given attribute as starting
          points for translation (except modules). If an attribute name is not
          specified, [verify::start_from] is used. *)
  start_from_pub : bool;
      (** Use all the [pub] items as starting points for translation (except
          modules). *)
  included : string list;
      (** Whitelist of items to translate. These use the name-matcher syntax. *)
  opaque : string list;
      (** Blacklist of items to keep opaque. Works just like [--include], see
          the doc there. *)
  exclude : string list;
      (** Blacklist of items to not translate at all. Works just like
          [--include], see the doc there. *)
  extract_opaque_bodies : bool;
      (** Usually we skip the bodies of foreign methods and structs with private
          fields. When this flag is on, we don't. *)
  translate_all_methods : bool;
      (** Usually we skip the provided methods that aren't used. When this flag
          is on, we translate them all. *)
  doc_comments : bool;
      (** Translate doc comments ([/// ...]) into [DocComment] attributes. They
          are omitted by default: they carry no semantics and take a noticeable
          part of the llbc of large crates. *)
  lift_associated_types : string list;
      (** Transform the associate types of traits to be type parameters instead.
          This takes a list of name patterns of the traits to transform, using
          the same syntax as [--include]. *)
  hide_marker_traits : bool;
      (** Whether to hide various marker traits such as [Sized], [Sync], [Send]
          and [Destruct] anywhere they show up. This can considerably speed up
          translation. *)
  remove_adt_clauses : bool;
      (** Remove trait clauses from type declarations. Must be combined with
          [--remove-associated-types] for type declarations that use trait
          associated types in their fields, otherwise this will result in
          errors. *)
  hide_allocator : bool;
      (** Hide the [A] type parameter on standard library containers ([Box],
          [Vec], etc). *)
  remove_unused_self_clauses : bool;
      (** Trait method declarations take a [Self: Trait] clause as parameter, so
          that they can be reused by multiple trait impls. This however causes
          trait definitions to be mutually recursive with their method
          declarations. This flag removes [Self] clauses that aren't used to
          break this mutual recursion when possible. *)
  desugar_drops : bool;
      (** Transform precise drops to the equivalent [drop_in_place(&raw mut p)]
          call. *)
  ops_to_function_calls : bool;
      (** Transform array-to-slice unsizing, repeat expressions, and raw pointer
          construction into builtin functions in ULLBC. *)
  index_to_function_calls : bool;
      (** Transform array/slice indexing into builtin functions in ULLBC. Note
          that this may introduce UB since it creates references that were not
          normally created, including when indexing behind a raw pointer. *)
  treat_box_as_builtin : bool;
      (** Treat [Box<T>] as if it was a built-in type. *)
  raw_consts : bool;  (** Do not inline or evaluate constants. *)
  unsized_strings : bool;
      (** Replace string literal constants with a constant u8 array that gets
          unsized, expliciting the fact a string constant has a hidden
          reference. *)
  reconstruct_fallible_operations : bool;
      (** Replace "bound checks followed by UB-on-overflow operation" with the
          corresponding panic-on-overflow operation. This loses unwinding
          information. *)
  reconstruct_asserts : bool;
      (** Replace [if x { panic() }] with [assert(x)]. *)
  unbind_item_vars : bool;
      (** Use [DeBruijnVar::Free] for the variables bound in item signatures,
          instead of [DeBruijnVar::Bound] everywhere. This simplifies the
          management of generics for projects that don't intend to manipulate
          them too much. *)
  print_original_ullbc : bool;
      (** Pretty-print the ULLBC immediately after extraction from MIR. *)
  print_ullbc : bool;
      (** Pretty-print the ULLBC after applying the micro-passes (before
          serialization/control-flow reconstruction). *)
  print_built_llbc : bool;
      (** Pretty-print the LLBC just after we built it (i.e., immediately after
          loop reconstruction). *)
  print_llbc : bool;
      (** Pretty-print the final LLBC (after all the cleaning micro-passes). *)
  dest_dir : path_buf option;
      (** The destination directory. Files will be generated as
          [<dest_dir>/<crate_name>.{u}llbc], unless [dest_file] is set.
          [dest_dir] defaults to the current directory. *)
  dest_file : path_buf option;
      (** The destination file. By default [<dest_dir>/<crate_name>.llbc]. If
          this is set we ignore [dest_dir]. *)
  no_dedup_serialized_ast : bool;
      (** Don't deduplicate values (types, trait refs) in the .(u)llbc file.
          This makes the file easier to inspect. *)
  no_serialize : bool;  (** Don't serialize the final (U)LLBC to a file. *)
  no_typecheck : bool;  (** Skip the typecheck passes. *)
  no_normalize : bool;  (** Don't normalize associated types. *)
  abort_on_error : bool;
      (** Panic on the first error. This is useful for debugging. *)
  error_on_warnings : bool;  (** Consider any warnings to be errors. *)
  preset : preset option;  (** Named builtin sets of options. *)
}

(** A (group of) top-level declaration(s), properly reordered. *)
and declaration_group =
  | TypeGroup of type_decl_id g_declaration_group
      (** A type declaration group *)
  | FunGroup of fun_decl_id g_declaration_group
      (** A function declaration group *)
  | GlobalGroup of global_decl_id g_declaration_group
      (** A global declaration group *)
  | TraitDeclGroup of trait_decl_id g_declaration_group
  | TraitImplGroup of trait_impl_id g_declaration_group
  | MixedGroup of item_id g_declaration_group
      (** Anything that doesn't fit into these categories. *)

(** A function definition *)
and fun_decl = {
  def_id : fun_decl_id;
  item_meta : item_meta;  (** The meta data associated with the declaration. *)
  generics : generic_params;
  signature : fun_sig;
      (** The signature contains the inputs/output types *with* non-erased
          regions. It also contains the list of region and type parameters. *)
  src : item_source;
      (** The function kind: "regular" function, trait method declaration, etc.
      *)
  is_global_initializer : global_decl_id option;
      (** Whether this function is in fact the body of a constant/static that we
          turned into an initializer function. *)
  body : body;  (** The function body. *)
}

(** A (group of) top-level declaration(s), properly reordered. "G" stands for
    "generic" *)
and 'a0 g_declaration_group =
  | NonRecGroup of 'a0  (** A non-recursive declaration *)
  | RecGroup of 'a0 list  (** A (group of mutually) recursive declaration(s) *)

(** The MIR stage to use. For dependencies, promoted MIR is available when
    charon compiled them; otherwise, and at other stages, only mir optimized is
    (or mir elaborated for consts). *)
and mir_level =
  | Built  (** The MIR just after MIR lowering. *)
  | Promoted
      (** The MIR after const promotion. This is the MIR used by the
          borrow-checker. *)
  | Elaborated
      (** The MIR after drop elaboration. This is the first MIR to include all
          the runtime information. *)
  | Optimized
      (** The MIR after optimizations. Charon disables all the optimizations it
          can, so this is sensibly the same MIR as the elaborated MIR. *)

and monomorphize_mut =
  | All  (** Monomorphize any item instantiated with [&mut]. *)
  | ExceptTypes
      (** Monomorphize all non-typedecl items instantiated with [&mut]. *)

(** Presets to make it easier to tweak options without breaking dependent
    projects. Eventually we should define semantically-meaningful presets
    instead of project-specific ones. *)
and preset =
  | OldDefaults
      (** The default translation used before May 2025. After that, many passes
          were made optional and disabled by default. *)
  | RawMir
      (** Emit the MIR as unmodified as possible. This is very imperfect for
          now, we should make more passes optional. *)
  | Fast  (** Skip as many optional transformations as possible. *)
  | Aeneas
  | Eurydice
  | Soteria
  | Tests

and target_info = {
  target_pointer_size : int;  (** The pointer size of the target in bytes. *)
  is_little_endian : bool;
      (** Whether the target platform uses little endian byte order. *)
}

(** The data of a translated crate. *)
and translated_crate = {
  crate_name : string;  (** The name of the crate. *)
  options : cli_options;
      (** The options used when calling Charon. It is useful for the
          applications which consumed the serialized code, to check that Charon
          was called with the proper options. *)
  target_information : (string * target_info) list;
      (** Information about each target platform. When translating a crate
          normally this will have a single entry; when using [--targets] this
          will have one entry per chosen target. *)
  files : file list;
      (** The translated files. This field must come before any field containing
          spans, as the OCaml deserialization of spans requires the files to be
          deserialized already. *)
  item_names : (item_id * name) list;
      (** The names of all registered items. Available so we can know the names
          even of items that failed to translate. Invariant: after translation,
          any existing [ItemId] must have an associated name, even if the
          corresponding item wasn't translated. *)
  short_names : (item_id * name) list;
      (** Short names, for items whose last PathElem is unique. *)
  type_decls : type_decl option list;  (** The translated type definitions *)
  fun_decls : fun_decl option list;  (** The translated function definitions *)
  global_decls : global_decl option list;
      (** The translated global definitions *)
  trait_decls : trait_decl option list;
      (** The translated trait declarations *)
  trait_impls : trait_impl option list;
      (** The translated trait declarations *)
  unit_metadata : global_decl_ref option;
      (** A [const UNIT: () = ();] used whenever we make a thin
          pointer/reference to avoid creating a local [let unit = ();] variable.
          It is always [Some]. *)
  ordered_decls : declaration_group list option;
      (** The re-ordered groups of declarations, initialized as empty. *)
}
[@@deriving show]
