open Interp
open Types
open Values
open LlbcAst
open Contexts
open Builtin
module SA = SymbolicAst
module Micro = PureMicroPasses
module SC = SeparateCompilation
open TranslateCore
open Errors
open Parallel

(** The local logger *)
let log = TranslateCore.log

(** The result of running the symbolic interpreter on a function:
    - the list of symbolic values used for the input values
    - the generated symbolic AST *)
type symbolic_fun_translation = symbolic_value list * SA.expr

(** Execute the symbolic interpreter on a function to generate a list of
    symbolic ASTs, for the forward function and the backward functions. *)
let translate_function_to_symbolics (trans_ctx : trans_ctx)
    (marked_ids : marked_ids) (fdef : fun_decl) :
    symbolic_fun_translation option =
  (* Debug *)
  [%ltrace name_to_string trans_ctx fdef.item_meta.name];

  match fdef.body with
  | StructuredBody _ ->
      (* Evaluate - note that [evaluate_function_symbolic synthesize] catches
         exceptions to at least generate a dummy body if we do not abort on failure. *)
      let synthesize = true in
      let inputs, symb =
        (* ```ocaml *)
        try evaluate_function_symbolic synthesize trans_ctx marked_ids fdef
        with failure ->
          let trace = Printexc.get_raw_backtrace () in
          (try
             if !Config.print_error_diagnostics || !Config.print_error_emitters then
               Printf.eprintf
                 "Failed symbolic function:\nname=%s\ndeclaration-id=%s\nsource-span=%s\n%!"
                 (name_to_string trans_ctx fdef.item_meta.name)
                 (FunDeclId.to_string fdef.def_id)
                 (Errors.span_to_string fdef.item_meta.span)
           with _ -> ());
          Printexc.raise_with_backtrace failure trace
        (* ``` *)
      in
      Some (inputs, Option.get symb)
  | _ -> None

(** Sanity check helper.

    Check that all the variables in a function declaration:
    - are bound variables
    - are well-bound *)
let check_fun_decl_vars_are_well_bound (trans_ctx : trans_ctx)
    (f : Pure.fun_decl) : unit =
  let span = f.item_meta.span in

  if !Config.sanity_checks then (
    match f.body with
    | None -> ()
    | Some body ->
        (* First, check the function without meta information *)
        let fmt_env = PrintPure.decls_ctx_to_fmt_env trans_ctx in
        (let f =
           {
             f with
             body =
               Option.map
                 (fun (body : Pure.fun_body) ->
                   { body with body = PureUtils.remove_meta body.body })
                 f.body;
           }
         in

         [%ldebug PrintPure.fun_decl_to_string fmt_env f];
         let fvars = PureUtils.texpr_get_fvars body.body in
         if not (Pure.FVarId.Set.is_empty fvars) then
           [%craise] span
             ("Internal errors: found unexpected fvars: "
             ^ Pure.FVarId.Set.to_string None fvars));

        [%ldebug PrintPure.fun_decl_to_string fmt_env f];
        let fvars = PureUtils.texpr_get_fvars body.body in
        if not (Pure.FVarId.Set.is_empty fvars) then
          [%craise] span
            ("Internal errors: found unexpected fvars: "
            ^ Pure.FVarId.Set.to_string None fvars);

        (* Open all the free variables: if there is a bound variable which is not well-bound,
           this will raise an exception *)
        let _, fresh_fvar_id = Pure.FVarId.fresh_stateful_generator () in
        let _ = PureUtils.open_all_fun_body fresh_fvar_id span body in
        ())
  else ()

(** Translate a function, by generating its forward and backward translations.

    [fun_sigs]: maps the forward/backward functions to their signatures. In case
    of backward functions, we also provide names for the outputs. TODO: maybe we
    should introduce a record for this. *)
let translate_function_to_pure_aux (trans_ctx : trans_ctx)
    (marked_ids : marked_ids)
    (pure_type_decls : Pure.type_decl Pure.TypeDeclId.Map.t)
    (pure_global_decls : Pure.global_decl GlobalDeclId.Map.t)
    (fun_sigs : SymbolicToPureCore.fun_sigs FunDeclId.Map.t) (fdef : fun_decl) :
    pure_fun_translation_no_loops =
  (* Debug *)
  [%ltrace
    name_to_string trans_ctx fdef.item_meta.name
    ^ ":\n"
    ^ fun_sig_to_string trans_ctx
        {
          item_binder_params = fdef.generics;
          item_binder_value = fdef.signature;
        }];

  (* Compute the symbolic ASTs, if the function is transparent *)
  let symbolic_trans =
    translate_function_to_symbolics trans_ctx marked_ids fdef
  in

  (* Convert the symbolic ASTs to pure ASTs: *)

  (* Initialize the context *)
  let sv_to_var = SymbolicValueId.Map.empty in
  let fvars = Pure.FVarId.Map.empty in
  let fvars_tys = Pure.FVarId.Map.map (fun (v : Pure.fvar) -> v.ty) fvars in

  let calls = FunCallId.Map.empty in
  let recursive_type_decls =
    TypeDeclId.Set.of_list
      (List.filter_map
         (fun (tid, g) ->
           match g with
           | Charon.GAst.NonRecGroup _ -> None
           | RecGroup _ -> Some tid)
         (TypeDeclId.Map.bindings trans_ctx.type_ctx.type_decls_groups))
  in
  let type_ctx =
    {
      SymbolicToPureCore.type_infos = trans_ctx.type_ctx.type_infos;
      llbc_type_decls = trans_ctx.type_ctx.type_decls;
      type_decls = pure_type_decls;
      recursive_decls = recursive_type_decls;
    }
  in
  let fun_ctx =
    {
      SymbolicToPureCore.llbc_fun_decls = trans_ctx.fun_ctx.fun_decls;
      fun_infos = trans_ctx.fun_ctx.fun_infos;
    }
  in

  (* Compute the set of loops, and find better ids for them (starting at 0). *)
  let loop_ids_map =
    match symbolic_trans with
    | None -> LoopId.Map.empty
    | Some (_, ast) ->
        let m = ref LoopId.Map.empty in
        let _, fresh_loop_id = Pure.LoopId.fresh_stateful_generator () in

        let visitor =
          object
            inherit [_] SA.iter_expr as super

            method! visit_loop env loop =
              let _ =
                match LoopId.Map.find_opt loop.loop_id !m with
                | Some _ -> ()
                | None -> m := LoopId.Map.add loop.loop_id (fresh_loop_id ()) !m
              in
              super#visit_loop env loop
          end
        in
        visitor#visit_expr () ast;
        !m
  in

  (* The expanded references and the ADTs expanded without branching (see
     [bs_ctx.expanded_refs] and [bs_ctx.expanded_adts]) *)
  let expanded_refs, expanded_adts =
    match symbolic_trans with
    | None -> (SymbolicValueId.Map.empty, SymbolicValueId.Map.empty)
    | Some (_, ast) ->
        let refs = ref SymbolicValueId.Map.empty in
        let adts = ref SymbolicValueId.Map.empty in
        let visitor =
          object
            inherit [_] SA.iter_expr as super

            method! visit_Expansion env p sv exp =
              (match exp with
              | SA.ExpandNoBranch ((SeMutRef (_, nsv) | SeSharedRef (_, nsv)), _)
                ->
                  refs := SymbolicValueId.Map.add sv.sv_id nsv.sv_id !refs
              | SA.ExpandAdt [ (variant_id, svl, _) ] ->
                  adts :=
                    SymbolicValueId.Map.add sv.sv_id (variant_id, svl) !adts
              | _ -> ());
              super#visit_Expansion env p sv exp
          end
        in
        visitor#visit_expr () ast;
        (!refs, !adts)
  in

  let sg =
    SymbolicToPureTypes.translate_fun_sig_from_decl_to_decomposed trans_ctx fdef
  in

  let _, fresh_fvar_id = Pure.FVarId.fresh_stateful_generator () in
  let ctx =
    {
      SymbolicToPureCore.span = fdef.item_meta.span;
      decls_ctx = trans_ctx;
      trans_global_decls = pure_global_decls;
      bid = None;
      sg;
      fun_sigs;
      (* Will need to be updated for the backward functions *)
      sv_to_var;
      (*
```ocaml
      *)
      symbolic_producers = SymbolicValueId.Map.empty;
      (* ```ocaml *)
      stage_header_values = ValuesUtils.SymbolicPendingSlotMap.empty;
      (* ``` *)
      (*
```ocaml
      *)
      received_projection_values = InterpBorrowsCore.NormSymbProjMap.empty;
      (*
```
      *)
      (*
```
      *)
      owned_state_roots = [];
      owned_state_recovery = PureUtils.TExprMap.empty;
      fresh_fvar_id;
      fvars;
      fvars_tys;
      type_ctx;
      fun_ctx;
      fun_decl = fdef;
      forward_inputs = [];
      (* Initialized just below *)
      backward_inputs = RegionGroupId.Map.empty;
      early_backward_inputs = RegionGroupId.Map.empty;
      backward_outputs = Collections.IntMap.empty;
      deferred_backward_outputs = Collections.IntMap.empty;
      synth_ended = [];
      (* Empty for now *)
      calls;
      loop_ids_map;
      mk_return = None;
      mk_panic = None;
      mk_continue = None;
      mk_break = [];
      mk_join = Contexts.SymbolicExprId.Map.empty;
      observe_loop_exit = None;
      mut_borrow_to_original = BorrowId.Map.empty;
      mut_borrow_to_consumed = BorrowId.Map.empty;
      shared_loan_ctxs = BorrowId.Map.empty;
      shared_borrow_values = BorrowId.Map.empty;
      var_id_to_default = Pure.FVarId.Map.empty;
      abs_id_to_info = AbsId.Map.empty;
      fun_call_stages = AbsId.Map.empty;
      staged_conts = AbsId.Map.empty;
      level1_staged_abs = AbsId.Set.empty;
      promised_fvars = Pure.FVarId.Set.empty;
      deferred_lets = [];
      unavailable_svs = SymbolicValueId.Map.empty;
      kstage_carriers = false;
      expanded_refs;
      expanded_adts;
      dropped_twin_scope = None;
      ignored_abs_ids = AbsId.Set.empty;
      meta_symb_places = SymbolicToPureCore.MetaSymbPlaceSet.empty;
      join_snapshots =
        {
          snapshots = AbsId.Set.empty;
          stale = AbsId.Set.empty;
          may_snapshot = AbsId.Set.empty;
          unreconciled = AbsId.Set.empty;
          applied_in = [];
          joins = [];
          loops = [];
          renamings = [];
        };
    }
  in

  (* Add the forward inputs (the initialized input variables for the forward
     function)
  *)
  let ctx =
    match (LlbcAstUtils.body_as_body fdef.body, symbolic_trans) with
    | None, None -> ctx
    | Some body, Some (input_svs, _) ->
        let forward_input_vars = LlbcAstUtils.fun_body_get_input_vars body in
        let forward_input_varnames =
          List.map (fun (v : local) -> v.name) forward_input_vars
        in
        let input_svs = List.combine forward_input_varnames input_svs in
        let ctx, forward_inputs =
          SymbolicToPureValues.fresh_named_vars_for_symbolic_values input_svs
            ctx
        in
        let owned_state_roots =
          List.map
            (fun (index, _) ->
              ( index,
                PureUtils.mk_texpr_from_fvar (List.nth forward_inputs index) ))
            sg.fun_ty.state_outputs
        in
        let owned_state_recovery =
          PureUtils.TExprMap.of_list
            (List.map
               (fun (_, input) ->
                 (input, SymbolicToPureCore.UnavailableOwnedState))
               owned_state_roots)
        in
        { ctx with forward_inputs; owned_state_roots; owned_state_recovery }
    | _ -> [%craise] fdef.item_meta.span "Unreachable"
  in

  (* Add the backward inputs *)
  let ctx = { ctx with backward_inputs = RegionGroupId.Map.of_list [] } in

  (* Translate the function *)
  let f =
    match symbolic_trans with
    | None -> SymbolicToPure.translate_fun_decl ctx None
    | Some (_, ast) -> SymbolicToPure.translate_fun_decl ctx (Some ast)
  in

  (* Sanity check:
     - there are no free variables appearing in the body
     - all the variables are properly bound *)
  check_fun_decl_vars_are_well_bound trans_ctx f;

  (* *)
  f

let translate_function_to_pure (trans_ctx : trans_ctx) (marked_ids : marked_ids)
    (pure_type_decls : Pure.type_decl Pure.TypeDeclId.Map.t)
    (pure_global_decls : Pure.global_decl Pure.GlobalDeclId.Map.t)
    (fun_sigs : SymbolicToPureCore.fun_sigs FunDeclId.Map.t) (fdef : fun_decl) :
    pure_fun_translation_no_loops option =
  try
    Some
      ([%recover_internal_errors] fdef.item_meta.span (fun () ->
           translate_function_to_pure_aux trans_ctx marked_ids pure_type_decls
             pure_global_decls fun_sigs fdef))
  with CFailure error ->
    let name = name_to_string trans_ctx fdef.item_meta.name in
    let name_pattern =
      name_to_pattern_string_for_error (Some fdef.item_meta.span) trans_ctx
        fdef.item_meta.name
    in
    [%warn_recovered_opt_span] error.span
      ("Could not translate the function '" ^ name
     ^ " because of previous error.\nName pattern: '" ^ name_pattern ^ "'"
     ^ "\nDefinition span: "
      ^ Errors.raw_span_to_string fdef.item_meta.span
      ^ compute_local_uses_error_message trans_ctx (IdFun fdef.def_id));
    None

type translated_crate = {
  type_decls : Pure.type_decl list;
  builtin_fun_sigs : Pure.fun_sig BuiltinFunIdMap.t;
  fun_decls : pure_fun_translation list;
  global_decls : Pure.global_decl list;
  trait_decls : Pure.trait_decl list;
  trait_impls : Pure.trait_impl list;
}

(* TODO: factor out the return type *)
let translate_crate_to_pure (crate : crate) (marked_ids : marked_ids) :
    trans_ctx * translated_crate =
  (* Debug *)
  [%ltrace ""];

  (* Compute the translation context *)
  let trans_ctx = compute_contexts crate in

  (* Translate all the type definitions *)
  let type_decls = SymbolicToPure.translate_type_decls trans_ctx in

  (* Compute the type definition map *)
  let type_decls_map =
    Pure.TypeDeclId.Map.of_list
      (List.map (fun (def : Pure.type_decl) -> (def.def_id, def)) type_decls)
  in

  (* Translate the globals (remark: this does not translate their *bodies* (i.e.:
     their initialization functions), that are translated later, at the same time
     as the "regular" functions) *)
  let global_decls =
    let num_decls = GlobalDeclId.Map.cardinal crate.global_decls in
    ProgressBar.with_reporter num_decls "Translated globals: " (fun report ->
        List.filter_map
          (fun (global : global_decl) ->
            try
              let g =
                [%recover_internal_errors] global.item_meta.span (fun () ->
                    SymbolicToPure.translate_global trans_ctx global)
              in
              report 1;
              Some g
            with CFailure error ->
              let name = name_to_string trans_ctx global.item_meta.name in
              let name_pattern =
                name_to_pattern_string_for_error (Some global.item_meta.span)
                  trans_ctx global.item_meta.name
              in
              [%warn_recovered_opt_span] error.span
                ("Could not translate the global declaration '" ^ name
               ^ " because of previous error\nName pattern: '" ^ name_pattern
               ^ "'" ^ "\nDefinition span: "
                ^ Errors.raw_span_to_string global.item_meta.span
                ^ compute_local_uses_error_message trans_ctx
                    (IdGlobal global.def_id));
              None)
          (GlobalDeclId.Map.values trans_ctx.global_decls_to_extract))
  in
  let global_decls_map =
    GlobalDeclId.Map.of_list
      (List.map (fun (d : Pure.global_decl) -> (d.def_id, d)) global_decls)
  in

  (* Compute the fun sigs for the whole crate *)
  let fun_sigs =
    FunDeclId.Map.of_list
      (List.filter_map
         (fun (fdef : LlbcAst.fun_decl) ->
           try
             [%recover_internal_errors] fdef.item_meta.span (fun () ->
                 [%ltrace
                   "Translating the signature of: "
                   ^ name_to_string trans_ctx fdef.item_meta.name];
                 let open SymbolicToPureCore in
                 let open SymbolicToPureTypes in
                 let dsg =
                   translate_fun_sig_from_decl_to_decomposed trans_ctx fdef
                 in
                 let sg = translate_fun_sig_from_decomposed dsg in
                 let ty = PureUtils.mk_arrows sg.inputs sg.output in
                 let sg : fun_sigs = { dsg; sg; ty } in
                 Some (fdef.def_id, sg))
           with CFailure error ->
             let name = name_to_string trans_ctx fdef.item_meta.name in
             let name_pattern =
               name_to_pattern_string_for_error (Some fdef.item_meta.span)
                 trans_ctx fdef.item_meta.name
             in
             [%warn_recovered_opt_span] error.span
               ("Could not translate the function signature of '" ^ name
              ^ " because of previous error\nName pattern: '" ^ name_pattern
              ^ "'" ^ "\nDefinition span: "
               ^ Errors.raw_span_to_string fdef.item_meta.span
               ^ compute_local_uses_error_message trans_ctx (IdFun fdef.def_id)
               );
             None)
         (FunDeclId.Map.values trans_ctx.fun_ctx.to_extract))
  in

  (* Translate the signatures of the builtin functions *)
  let builtin_fun_sigs =
    BuiltinFunIdMap.map
      (fun (info : builtin_fun_info) ->
        SymbolicToPureTypes.translate_fun_sig trans_ctx (FBuiltin info.fun_id)
          info.fun_sig
          (List.map (fun _ -> None) info.fun_sig.item_binder_value.inputs))
      builtin_fun_infos
  in

  (* Translate all the functions.

     Remark: [translate_function_to_pure] catches errors of type [CFailure]
     to allow the compilation to make progress.

     We do it in two steps: the opaque functions first, then the transparent functions.
  *)
  let pure_translations =
    let funs = FunDeclId.Map.values trans_ctx.fun_ctx.to_extract in
    (* Split between opaque and transparent *)
    let opaque, transparent =
      List.partition
        (fun (d : fun_decl) -> not (LlbcAstUtils.body_is_known d.body))
        funs
    in

    (* Reorder the transparent functions to have the biggest first:
       because the execution is parallel, we want to start processing the bigger
       functions as early as possible.

       TODO: this doesn't seem to have much effect.
    *)
    let transparent =
      if !Config.parallel then
        let funs =
          List.map
            (fun f -> (f, LlbcAstUtils.compute_fun_decl_size f))
            transparent
        in
        List.map fst (List.sort (fun (_, n) (_, n') -> n' - n) funs)
      else transparent
    in

    (* Assign size-based ranks (rank 1 = biggest):
       transparent functions are already sorted by decreasing size *)
    let n_transparent = List.length transparent in
    let transparent_ranked = List.mapi (fun i f -> (i + 1, f)) transparent in
    let opaque_ranked =
      List.mapi (fun i f -> (n_transparent + i + 1, f)) opaque
    in

    let diagnose_transl_data : (string * float * int * int) list ref = ref [] in
    let diagnose_transl_mutex = Mutex.create () in

    (* Process a function *)
    let process (kind : string) (funs : (int * fun_decl) list) =
      let num_decls = List.length funs in
      ProgressBar.with_parallel_reporter num_decls
        ("Translated " ^ kind ^ " functions: ")
        (fun report ->
          parallel_filter_map
            (fun (rank, x) ->
              let start =
                if !Config.diagnose_translation then Unix.gettimeofday ()
                else 0.0
              in
              let f =
                translate_function_to_pure trans_ctx marked_ids type_decls_map
                  global_decls_map fun_sigs x
              in
              if !Config.diagnose_translation then begin
                let elapsed = Unix.gettimeofday () -. start in
                let fname = name_to_string trans_ctx x.item_meta.name in
                let size = LlbcAstUtils.compute_fun_decl_size x in
                Mutex.lock diagnose_transl_mutex;
                diagnose_transl_data :=
                  (fname, elapsed, size, rank) :: !diagnose_transl_data;
                Mutex.unlock diagnose_transl_mutex
              end;
              report 1;
              f)
            funs)
    in

    let opaque = process "opaque" opaque_ranked in
    let transparent = process "transparent" transparent_ranked in

    (* Print -diagnose-translation results *)
    if !Config.diagnose_translation then begin
      let sorted =
        List.sort
          (fun (_, t1, _, _) (_, t2, _, _) -> Float.compare t2 t1)
          !diagnose_transl_data
      in
      let limit = !Config.diagnose_limit in
      let to_print =
        if limit >= 0 then Collections.List.prefix limit sorted else sorted
      in
      Printf.printf "\n=== Translation time per function ===\n";
      List.iter
        (fun (name, time, size, rank) ->
          Printf.printf "  %s: %.4fs (size: %d, rank: %d)\n" name time size rank)
        to_print
    end;

    opaque @ transparent
  in

  (* Translate the trait declarations *)
  let trait_decls =
    let num_decls = TraitDeclId.Map.cardinal crate.trait_decls in
    ProgressBar.with_reporter num_decls "Translated trait declarations: "
      (fun report ->
        List.filter_map
          (fun (d : trait_decl) ->
            try
              let d =
                [%recover_internal_errors] d.item_meta.span (fun () ->
                    SymbolicToPure.translate_trait_decl trans_ctx d)
              in
              report 1;
              Some d
            with CFailure error ->
              let name = name_to_string trans_ctx d.item_meta.name in
              let name_pattern =
                name_to_pattern_string_for_error (Some d.item_meta.span)
                  trans_ctx d.item_meta.name
              in
              [%warn_recovered_opt_span] error.span
                ("Could not translate the trait declaration '" ^ name
               ^ " because of previous error\nName pattern: '" ^ name_pattern
               ^ "'" ^ "\nDefinition span: "
                ^ Errors.raw_span_to_string d.item_meta.span
                ^ compute_local_uses_error_message trans_ctx
                    (IdTraitDecl d.def_id));
              None)
          (TraitDeclId.Map.values trans_ctx.trait_decls_to_extract))
  in

  (* Translate the trait implementations *)
  let trait_impls =
    let num_decls = TraitImplId.Map.cardinal crate.trait_impls in
    ProgressBar.with_reporter num_decls "Translated trait impls: "
      (fun report ->
        List.filter_map
          (fun (d : trait_impl) ->
            try
              let d =
                [%recover_internal_errors] d.item_meta.span (fun () ->
                    SymbolicToPure.translate_trait_impl trans_ctx d)
              in
              report 1;
              Some d
            with CFailure error ->
              let name = name_to_string trans_ctx d.item_meta.name in
              let name_pattern =
                name_to_pattern_string_for_error (Some d.item_meta.span)
                  trans_ctx d.item_meta.name
              in
              [%warn_recovered_opt_span] error.span
                ("Could not translate the trait instance '" ^ name
               ^ " because of previous error\nName pattern: '" ^ name_pattern
               ^ "'" ^ "\nDefinition span: "
                ^ Errors.raw_span_to_string d.item_meta.span
                ^ compute_local_uses_error_message trans_ctx
                    (IdTraitImpl d.def_id));
              None)
          (TraitImplId.Map.values trans_ctx.trait_impls_to_extract))
  in

  (* Apply the micro-passes *)
  let pure_translations =
    Micro.apply_passes_to_pure_fun_translations crate trans_ctx builtin_fun_sigs
      type_decls trait_impls pure_translations
  in
  let trait_decls, trait_impls =
    Micro.prune_unused_provided_fields crate trait_decls trait_impls
      pure_translations
  in
  let trait_decls, trait_impls =
    Micro.apply_external_trait_fields trait_decls trait_impls pure_translations
  in
  (* Use carriers for the collections nested in recursive types: Lean rejects
     [Vec], slices and arrays there (their invariant depends on the elements) *)
  let type_decls, pure_translations =
    if Config.backend () = Lean then
      PureNestedCollections.apply trans_ctx type_decls pure_translations
    else (type_decls, pure_translations)
  in

  (* Return *)
  ( trans_ctx,
    {
      type_decls;
      builtin_fun_sigs;
      fun_decls = pure_translations;
      global_decls;
      trait_decls;
      trait_impls;
    } )

type gen_ctx = ExtractBase.extraction_ctx

type gen_config = {
  extract_types : bool;
  extract_decreases_clauses : bool;
  extract_template_decreases_clauses : bool;
  extract_fun_decls : bool;
  extract_trait_decls : bool;
  extract_trait_impls : bool;
  extract_transparent : bool;
      (** If [true], extract the transparent declarations, otherwise ignore. *)
  extract_opaque : bool;
      (** If [true], extract the opaque declarations, otherwise ignore.

          For now, this controls only the opaque *functions*, not the opaque
          globals or types. TODO: update this. This is not trivial if we want to
          extract the opaque types in an opaque module, because some non-opaque
          types may refer to opaque types and vice-versa. *)
  extract_globals : bool;
      (** If [true], generate a definition/declaration for top-level (global)
          declarations *)
  interface : bool;
      (** [true] if we generate an interface file, [false] otherwise. For now,
          this only impacts whether we use [val] or [assume val] for the opaque
          definitions. In the future, we might want to extract all the
          declarations in an interface file, together with an implementation
          file if needed. *)
}

(** Returns the pair: (has opaque type decls, has opaque fun decls), where an
    opaque fun decl is one the external functions file declares: a function
    whose translation has no body.

    [filter_builtin]: if [true], do not consider as opaque the external
    definitions that we will map to definitions from the standard library. *)
let crate_has_opaque_non_builtin_decls (ctx : gen_ctx) (filter_builtin : bool) :
    bool * bool =
  (* The declarations of external items are emitted by other chunks *)
  let types, funs =
    LlbcAstUtils.crate_get_opaque_non_builtin_decls ctx.crate filter_builtin
      (TypeDeclId.Map.filter
         (fun id _ -> not (SC.is_external (IdType id)))
         ctx.trans_ctx.type_ctx.to_extract)
      (FunDeclId.Map.filter
         (fun id _ -> not (SC.is_external (IdFun id)))
         ctx.trans_ctx.fun_ctx.to_extract)
  in
  (* A function without a Rust body can be given one by the translation: the
     partial-monomorphization instances of modeled functions at a borrowing
     state are the model at an extended state (see
     [ModelStateABI.threaded_instance_of_decl]). Only the functions whose
     translation has no body are holes of the external functions file (a
     function whose translation failed is not emitted at all). *)
  let funs =
    List.filter
      (fun (d : fun_decl) ->
        match FunDeclId.Map.find_opt d.def_id ctx.trans_funs with
        | Some trans -> Option.is_none trans.f.body
        | None -> false)
      funs
  in
  [%ldebug
    "- opaque types:\n"
    ^ String.concat "\n\n"
        (List.map
           (fun (d : type_decl) ->
             name_to_string ctx.trans_ctx d.item_meta.name)
           types)
    ^ "\n\n- opaque funs:\n"
    ^ String.concat "\n\n"
        (List.map
           (fun (d : fun_decl) -> name_to_string ctx.trans_ctx d.item_meta.name)
           funs)];
  (types <> [], funs <> [])

(** {1 Separate compilation}

    The interface of a declaration, as seen by the other chunks: a fingerprint
    of its translation, printed with the (structural) Rust names of the items it
    refers to. The fingerprint recorded by the owner chunk must be the one
    computed from the external view in the other chunks, whose translation does
    not see the bodies (see [SeparateCompilation.fun_facts]). *)

let sc_env (ctx : gen_ctx) (generics : Pure.generic_params) : PrintPure.fmt_env
    =
  { (ExtractBase.extraction_ctx_to_fmt_env ctx) with generics = [ generics ] }

let sc_fun_sig_fingerprint (ctx : gen_ctx) (sg : Pure.fun_sig) : string =
  let env = sc_env ctx sg.generics in
  String.concat "\n"
    [
      PrintPure.fun_sig_to_string env sg;
      PrintPure.predicates_to_string env sg.preds;
      Pure.show_explicit_info sg.explicit_info;
      Pure.show_known_info sg.known_from_trait_refs;
      Pure.show_fun_sig_info sg.fwd_info;
      String.concat ";"
        (List.map
           (fun (id, info) ->
             RegionGroupId.to_string id ^ ":" ^ Pure.show_fun_effect_info info)
           (RegionGroupId.Map.bindings sg.back_effect_info));
    ]

let sc_type_fingerprint (ctx : gen_ctx) (d : Pure.type_decl) : string =
  PrintPure.type_decl_to_string (sc_env ctx d.generics) d

let sc_global_fingerprint (ctx : gen_ctx) (d : Pure.global_decl) : string =
  let env = sc_env ctx d.generics in
  String.concat "\n"
    [
      PrintPure.generic_params_to_string env d.generics;
      PrintPure.predicates_to_string env d.preds;
      Pure.show_explicit_info d.explicit_info;
      PrintPure.ty_to_string env false d.ty;
      string_of_bool d.can_fail;
    ]

(** The interface of a trait declaration without its methods, and the
    signatures of its methods. The partially monomorphized copies of a foreign
    trait keep the methods which their chunk uses: another chunk may see only
    some of the methods of the owner's copy (see [sc_check_external_views]). *)
let sc_trait_decl_parts (ctx : gen_ctx) (d : Pure.trait_decl) :
    string * string list =
  let env = sc_env ctx d.generics in
  let method_sig (name, (m : Pure.fun_decl_ref Pure.binder)) =
    name ^ " : "
    ^
    match FunDeclId.Map.find_opt m.binder_value.fun_id ctx.trans_funs with
    | Some trans -> sc_fun_sig_fingerprint ctx trans.f.signature
    | None -> "<untranslated>"
  in
  ( String.concat "\n"
      ([
         PrintPure.generic_params_to_string env d.generics;
         PrintPure.predicates_to_string env d.preds;
         Pure.show_explicit_info d.explicit_info;
       ]
      @ List.map (PrintPure.trait_clause_to_string env) d.parent_clauses
      @ List.map
          (fun (name, ty) -> name ^ " : " ^ PrintPure.ty_to_string env false ty)
          d.consts
      @ d.types),
    List.map method_sig d.methods )

let sc_trait_decl_fingerprint (ctx : gen_ctx) (d : Pure.trait_decl) : string =
  let header, methods = sc_trait_decl_parts ctx d in
  String.concat "\n" (header :: methods)

(** The interface of a trait implementation without its methods (which are
    functions with their own interfaces), and the names of its methods *)
let sc_trait_impl_parts (ctx : gen_ctx) (d : Pure.trait_impl) :
    string * string list =
  let env = sc_env ctx d.generics in
  ( String.concat "\n"
      ([
         PrintPure.trait_decl_ref_to_string env false d.impl_trait;
         PrintPure.generic_params_to_string env d.generics;
         PrintPure.predicates_to_string env d.preds;
         Pure.show_explicit_info d.explicit_info;
       ]
      @ List.map (PrintPure.trait_ref_to_string env false) d.parent_trait_refs
      @ List.map fst d.consts
      @ List.map
          (fun (name, ty) -> name ^ " = " ^ PrintPure.ty_to_string env false ty)
          d.types),
    List.map fst d.methods )

let sc_trait_impl_fingerprint (ctx : gen_ctx) (d : Pure.trait_impl) : string =
  let header, methods = sc_trait_impl_parts ctx d in
  String.concat "\n" (header :: methods)

let sc_digest (s : string) : string = Digest.to_hex (Digest.string s)

(** The top-level Lean names of the translation of a Rust function *)
let sc_fun_lean_names (ctx : gen_ctx) (trans : pure_fun_translation) :
    string list =
  List.map
    (fun (d : Pure.fun_decl) ->
      ExtractBase.ctx_get None
        (FunId (FromLlbc (FunId (FRegular d.def_id), d.loop_id)))
        ctx)
    ((trans.f :: trans.loops) @ trans.bodies)

let sc_fun_facts (ctx : gen_ctx) (id : FunDeclId.id) : SC.fun_facts =
  let decl = FunDeclId.Map.find id ctx.trans_ctx.fun_ctx.fun_decls in
  match FunDeclId.Map.find_opt id ctx.trans_ctx.fun_ctx.fun_infos with
  | Some info ->
      {
        can_fail = info.can_fail;
        stateful = info.stateful;
        can_diverge = info.can_diverge;
        is_rec = info.is_rec;
        state_inputs = ModelStateInputs.for_decl ctx.crate decl;
        canonical_body =
          ModelStateInputs.canonical_body_state_inputs ctx.crate decl;
        collection_obligations = CollectionContracts.manifest_obligations id;
      }
  | None ->
      [%craise] decl.item_meta.span
        "Separate compilation: missing function analysis"

(** The interface of the translation of an item, as seen by the other chunks *)
type sc_interface = {
  lean_names : string list;
  fingerprint : string;  (** Before its digest *)
  facts : SC.fun_facts option;
  methods : string list option;
      (** Trait declarations: the fields of the structure; implementations:
          the methods they define *)
  members : (string * string list option) option;
      (** Trait declarations and implementations: the interface without the
          methods, and the signatures of the [methods] of a declaration (none
          for an implementation, whose methods are functions with their own
          interfaces) *)
}

(** The interface of the translation of an item, if it was translated *)
let sc_item_interface (ctx : gen_ctx) (id : item_id) : sc_interface option =
  let simple lean_names fingerprint facts =
    { lean_names; fingerprint; facts; methods = None; members = None }
  in
  match id with
  | IdType tid ->
      Option.map
        (fun d ->
          simple
            [ ExtractBase.ctx_get None (TypeId (TAdtId tid)) ctx ]
            (sc_type_fingerprint ctx d) None)
        (Pure.TypeDeclId.Map.find_opt tid ctx.trans_types)
  | IdFun fid ->
      Option.map
        (fun (trans : pure_fun_translation) ->
          simple
            (sc_fun_lean_names ctx trans)
            (sc_fun_sig_fingerprint ctx trans.f.signature)
            (Some (sc_fun_facts ctx fid)))
        (FunDeclId.Map.find_opt fid ctx.trans_funs)
  | IdGlobal gid ->
      Option.map
        (fun (d : Pure.global_decl) ->
          simple
            [ ExtractBase.ctx_get None (GlobalId gid) ctx ]
            (sc_global_fingerprint ctx d)
            (Some (sc_fun_facts ctx d.body_id)))
        (GlobalDeclId.Map.find_opt gid ctx.trans_globals)
  | IdTraitDecl tid ->
      Option.map
        (fun (d : Pure.trait_decl) ->
          let header, sigs = sc_trait_decl_parts ctx d in
          {
            lean_names = [ ExtractBase.ctx_get None (TraitDeclId tid) ctx ];
            fingerprint = sc_trait_decl_fingerprint ctx d;
            facts = None;
            methods = Some (List.map fst d.methods);
            members = Some (header, Some sigs);
          })
        (TraitDeclId.Map.find_opt tid ctx.trans_trait_decls)
  | IdTraitImpl tid ->
      Option.map
        (fun (d : Pure.trait_impl) ->
          let header, methods = sc_trait_impl_parts ctx d in
          {
            lean_names = [ ExtractBase.ctx_get None (TraitImplId tid) ctx ];
            fingerprint = sc_trait_impl_fingerprint ctx d;
            facts = None;
            methods = Some methods;
            members = Some (header, None);
          })
        (TraitImplId.Map.find_opt tid ctx.trans_trait_impls)

(** Record a declaration emitted in the current module *)
let sc_record (ctx : gen_ctx) (id : item_id) : unit =
  if SC.enabled () then
    match
      (SC.item_key ctx.crate id, !SC.current_module, sc_item_interface ctx id)
    with
    | Some key, Some lean_module, Some i ->
        SC.record
          {
            key;
            lean_module;
            lean_names = i.lean_names;
            fingerprint = sc_digest i.fingerprint;
            facts = i.facts;
            methods = i.methods;
            members =
              Option.map
                (fun (header, sigs) : SC.members ->
                  {
                    header = sc_digest header;
                    method_fingerprints =
                      List.map sc_digest (Option.value sigs ~default:[]);
                  })
                i.members;
            sort_order = None;
          }
    | _ ->
        [%craise_opt_span] None
          "Separate compilation: cannot record a declaration"

(** Whether the view of a trait declaration or implementation in this chunk
    keeps a subset of the methods of the owner's, with the same interface
    otherwise: the partially monomorphized copy of a foreign trait (e.g.
    [Iterator::<IterMut<'a, T>, &'a mut T>]) keeps the methods which its
    chunk uses, and the view of an external declaration keeps at most the
    owner's fields ([PureMicroPasses.apply_external_trait_fields]). The chunk
    does not emit the declaration: it refers to the owner's structure (and
    instance) by its Lean name, and projects only fields of its view, each of
    which the owner emits with the same signature (equal digests); the rest of
    the interface (parameters, predicates, parent clauses, constants and types)
    has the same digest. Lean checks these references when the chunks are
    compiled together. *)
let sc_members_subset (i : sc_interface) (e : SC.entry) : bool =
  match (i.methods, i.members, e.methods, e.members) with
  | Some methods, Some (header, sigs), Some methods', Some members' -> (
      sc_digest header = members'.header
      && List.for_all (fun m -> List.mem m methods') methods
      &&
      match sigs with
      | None -> true
      | Some sigs ->
          List.length members'.method_fingerprints = List.length methods'
          &&
          let owner_sig =
            List.combine methods' members'.method_fingerprints
          in
          List.for_all2
            (fun m s -> List.assoc_opt m owner_sig = Some (sc_digest s))
            methods sigs)
  | _ -> false

(** The external items used by this chunk must be seen exactly as their owner
    emitted them: same Lean names, same interface (up to the methods which a
    copy of a foreign trait does not use, see [sc_members_subset]). *)
let sc_check_external_views (ctx : gen_ctx) : unit =
  let check_view (id : item_id) =
    match SC.external_entry id with
    | None -> ()
    | Some e -> (
        match sc_item_interface ctx id with
        | None -> ()
        | Some i -> (
            let main = List.hd i.lean_names in
            if main <> List.hd e.lean_names then
              SC.fail
                ("Separate compilation: the Lean name of [" ^ e.key ^ "] is "
               ^ main ^ " in this chunk but " ^ List.hd e.lean_names
               ^ " in its owner module " ^ e.lean_module);
            let subset = lazy (sc_members_subset i e) in
            if sc_digest i.fingerprint <> e.fingerprint && not (Lazy.force subset)
            then
              SC.fail
                ("Separate compilation: the interface of [" ^ e.key
               ^ "] in this chunk differs from the one emitted by its owner \
                  module " ^ e.lean_module ^ ". Interface in this chunk:\n"
               ^ i.fingerprint);
            match (i.methods, e.methods) with
            | Some l, Some l' when l <> l' && not (Lazy.force subset) ->
                SC.fail
                  ("Separate compilation: the fields of [" ^ e.key
                 ^ "] differ from the ones of its owner module " ^ e.lean_module
                  )
            | _ -> ()))
  in
  (* A view which cannot be computed because of a previous error (which is
     registered: the run fails) is not checked *)
  let checked = Hashtbl.create 64 in
  let check (id : item_id) =
    Hashtbl.replace checked id ();
    try [%recover_internal_errors_opt_span] None (fun () -> check_view id)
    with CFailure _ -> ()
  in
  List.iter
    (fun g ->
      List.iter
        (fun id ->
          match id with
          | IdFun fid -> (
              match FunDeclId.Map.find_opt fid ctx.trans_funs with
              | Some trans
                when trans.f.is_global_decl_body
                     ||
                     match trans.f.src with
                     | TraitDeclItem (_, _, false) -> true
                     | _ -> false -> ()
              | _ -> check id)
          | _ -> check id)
        (Charon.GAstUtils.declaration_group_to_list g))
    ctx.crate.declarations;
  (* A sort admission used the derived-order evidence of the owner of these
     external types (see [SortContracts]). The fields of each type in this
     chunk must be the fields of the owner's view, which the derived impls
     compare. *)
  List.iter
    (fun id ->
      let translated =
        match id with
        | IdType tid -> Pure.TypeDeclId.Map.mem tid ctx.trans_types
        | _ -> false
      in
      if not translated then
        SC.fail
          ("Separate compilation: a sort admission depends on the view of ["
          ^ Option.value (SC.item_key ctx.crate id) ~default:"<unnamed>"
          ^ "], but this chunk does not translate it")
      else if not (Hashtbl.mem checked id) then check id)
    !SC.sort_order_views

(** Export a type declaration.

    It may happen that we have to extract extra information/instructions. For
    instance, we might need to define some projector notations. This is why we
    have the two booleans [extract_decl] and [extract_extra_info]. If
    [extract_decl] is [true], then we extract the type declaration. If
    [extract_extra_info] is [true], we extract this extra information (after the
    declaration, if both booleans are [true]). *)
let export_type (fmt : Format.formatter) (config : gen_config) (ctx : gen_ctx)
    (type_decl_group : Pure.TypeDeclId.Set.t) (kind : ExtractBase.decl_kind)
    (def : Pure.type_decl) (extract_decl : bool) (extract_extra_info : bool) :
    unit =
  (* Update the kind, if the type is opaque *)
  let is_opaque, kind =
    match def.kind with
    | Enum _ | Struct _ -> (false, kind)
    | Opaque ->
        let kind =
          if config.interface then ExtractBase.Declared else ExtractBase.Builtin
        in
        (true, kind)
  in
  (* Extract, if the config instructs to do so (depending on whether the type
     is opaque or not). Remark: we don't check if the definitions are builtin
     here but in the function [export_types_group]: the reason is that if one
     definition in the group is builtin, then we must check that all the
     definitions are marked builtin *)
  let extract =
    (is_opaque && config.extract_opaque)
    || ((not is_opaque) && config.extract_transparent)
  in
  if extract then (
    if extract_decl then
      Extract.extract_type_decl ctx fmt type_decl_group kind def;
    if extract_extra_info then
      Extract.extract_type_decl_extra_info ctx fmt kind def)

(** Export a group of types.

    [is_rec]: [true] if the types are recursive. Necessarily [true] if there is
    > 1 type to extract. *)
let export_types_group (fmt : Format.formatter) (config : gen_config)
    (ctx : gen_ctx) (is_rec : bool) (ids : Pure.TypeDeclId.id list) : unit =
  assert (ids <> []);
  let export_type = export_type fmt config ctx in
  let ids_set = Pure.TypeDeclId.Set.of_list ids in
  let export_type_decl kind id = export_type ids_set kind id true false in
  let export_type_extra_info kind id = export_type ids_set kind id false true in

  (* Rem.: we shouldn't have (mutually) recursive opaque types *)
  let num_decls = List.length ids in
  let is_mut_rec = num_decls > 1 in
  let kind_from_index i =
    if not is_mut_rec then
      if is_rec then ExtractBase.SingleRec else ExtractBase.SingleNonRec
    else if i = 0 then ExtractBase.MutRecFirst
    else if i = num_decls - 1 then ExtractBase.MutRecLast
    else ExtractBase.MutRecInner
  in

  (* Retrieve the declarations - note that some of them might have been ignored in
     case of errors *)
  let defs =
    List.filter_map
      (fun id -> Pure.TypeDeclId.Map.find_opt id ctx.trans_types)
      ids
  in

  (* Check if the definition are builtin - if yes they must be ignored.
     Note that if one definition in the group is builtin, then all the
     definitions must be builtin *)
  let builtin =
    let open ExtractBuiltin in
    let types_map = builtin_types_map () in
    List.map
      (fun (def : Pure.type_decl) ->
        match_name_find_opt ctx.trans_ctx def.item_meta.name types_map <> None)
      defs
  in

  let dont_extract (d : Pure.type_decl) : bool =
    match d.kind with
    | Enum _ | Struct _ -> not config.extract_transparent
    | Opaque -> not config.extract_opaque
  in
  let contains_opaque =
    List.exists (fun (d : Pure.type_decl) -> d.kind = Opaque) defs
  in

  if List.exists (fun b -> b) builtin then
    (* Sanity check *)
    assert (List.for_all (fun b -> b) builtin)
  else if List.exists dont_extract defs then
    (* Check if we have to ignore declarations *)
    (* Sanity check *)
    assert (List.for_all dont_extract defs)
  else (
    (* Extract the type declarations. *)

    (* Save the fact that we extract opaque definitions, if we do *)
    ctx.extracted_opaque := contains_opaque || !(ctx.extracted_opaque);

    (* Because some declaration groups are delimited, we wrap the declarations
       between [{start,end}_type_decl_group].

       Ex.:
       ====
       When targeting HOL4, the calls to [{start,end}_type_decl_group] would generate
       the [Datatype] and [End] delimiters in the snippet of code below:

       {[
         Datatype:
           tree =
             TLeaf 'a
           | TNode node ;

           node =
             Node (tree list)
         End
       ]}
    *)
    Extract.start_type_decl_group ctx fmt is_rec defs;
    List.iteri
      (fun i def ->
        let kind = kind_from_index i in
        export_type_decl kind def)
      defs;
    Extract.end_type_decl_group fmt is_rec defs;

    (* Export the extra information (ex.: [Arguments] instructions in Coq) *)
    List.iteri
      (fun i def ->
        let kind = kind_from_index i in
        export_type_extra_info kind def)
      defs;
    List.iter
      (fun (def : Pure.type_decl) -> sc_record ctx (IdType def.def_id))
      defs)

(** Utility.

    Export a group of functions, used by {!export_functions_group}.

    We need this because for every function in Rust we may generate several
    functions in the translation (a forward function, several backward
    functions, loop functions, etc.). Those functions might call each other in
    different ways. In particular, they may be mutually recursive, in which case
    we might be able to group them into several groups of mutually recursive
    definitions, etc. For this reason, {!export_functions_group} computes the
    dependency graph of the functions as well as their strongly connected
    components, and gives each SCC at a time to {!export_functions_group_scc}.

    Rem.: this function only extracts the function *declarations*. It doesn't
    extract the decrease clauses, nor does it extract the unit tests.

    Rem.: this function doesn't check [config.extract_fun_decls]: it should have
    been checked by the caller. *)
(** Whether the recursion of a group of functions goes through a knot (see
    [builtin_trait_decl_info.knot]) into a method of a generic dictionary.

    This is the case when a body of the group calls a method of a builtin trait
    through a trait clause (a generic parameter, or one of its parent clauses)
    and passes it, at a knot position, a dictionary built from an
    implementation of the group (see [inline_trait_impls]). For instance:
    [serializer.serialize_field(&self.children)] in the derived [Serialize] of
    a recursive type. The method is then an arbitrary function of a dictionary
    which holds the functions being defined, so the functional of the group
    need not be monotone: the group is extracted in fuel form (see
    [Extract.fuel_mode]) instead of with [partial_fixpoint]. *)
let fun_group_recurses_through_knot (ctx : gen_ctx) (decls : Pure.fun_decl list)
    : bool =
  let open Pure in
  let members =
    List.fold_left
      (fun s (d : fun_decl) -> PureUtils.FunLoopIdSet.add (d.def_id, d.loop_id) s)
      PureUtils.FunLoopIdSet.empty decls
  in
  let member_impl (id : TraitImplId.id) : bool =
    match TraitImplId.Map.find_opt id ctx.inline_trait_impls with
    | Some impl ->
        List.exists
          (fun (_, (m : fun_decl_ref binder)) ->
            PureUtils.FunLoopIdSet.mem (m.binder_value.fun_id, None) members)
          impl.methods
    | None -> false
  in
  let rec ref_mentions (tr : trait_ref) : bool =
    inst_mentions tr.trait_id
    || generics_mention tr.trait_decl_ref.decl_generics
  and inst_mentions (id : trait_instance_id) : bool =
    match id with
    | TraitImpl (id, generics) -> member_impl id || generics_mention generics
    | ParentClause (id, _, _) -> inst_mentions id
    | _ -> false
  and generics_mention (generics : generic_args) : bool =
    List.exists ref_mentions generics.trait_refs
  in
  let rec clause_rooted (id : trait_instance_id) : bool =
    match id with
    | Clause _ -> true
    | ParentClause (id, _, _) -> clause_rooted id
    | _ -> false
  in
  let builtin_info (id : TraitDeclId.id) =
    match TraitDeclId.Map.find_opt id ctx.trans_trait_decls with
    | Some { builtin_info = Some info; _ } -> Some info
    | _ -> None
  in
  let found = ref false in
  let visitor =
    object
      inherit [_] iter_expr

      method! visit_qualif _ (q : qualif) =
        match q.id with
        | FunOrOp (Fun (FromLlbc (TraitMethod (trait_ref, _, _), _)))
          when Option.is_some
                 (builtin_info trait_ref.trait_decl_ref.trait_decl_id)
               && clause_rooted trait_ref.trait_id ->
            if
              List.exists
                (fun (tr : trait_ref) ->
                  (match builtin_info tr.trait_decl_ref.trait_decl_id with
                  | Some { knot = Some _; _ } -> true
                  | _ -> false)
                  && ref_mentions tr)
                q.generics.trait_refs
            then found := true
        | _ -> ()
    end
  in
  List.iter
    (fun (d : fun_decl) ->
      Option.iter (fun (b : fun_body) -> visitor#visit_texpr () b.body) d.body)
    decls;
  !found

let export_functions_group_scc (fmt : Format.formatter) (config : gen_config)
    (ctx : gen_ctx) (is_rec : bool) (decls : Pure.fun_decl list) : unit =
  let ctx0 = ctx in
  let fuel =
    Config.backend () = Lean && is_rec && fun_group_recurses_through_knot ctx decls
  in
  let ctx =
    if Config.backend () = Lean && is_rec then
      let local_function_refs =
        List.fold_left
          (fun refs (def : Pure.fun_decl) ->
            PureUtils.FunLoopIdSet.add (def.def_id, def.loop_id) refs)
          PureUtils.FunLoopIdSet.empty decls
      in
      let fuel_function_refs =
        if fuel then local_function_refs else PureUtils.FunLoopIdSet.empty
      in
      { ctx with local_function_refs; fuel_function_refs }
    else ctx
  in
  (* Utility to check whether a function has a decrease clause *)
  let has_decreases_clause (def : Pure.fun_decl) : bool =
    PureUtils.FunLoopIdSet.mem (def.def_id, def.loop_id)
      ctx.functions_with_decreases_clause
  in

  (* Extract the function declarations *)
  (* Check if the functions are mutually recursive *)
  let is_mut_rec = List.length decls > 1 in
  assert ((not is_mut_rec) || is_rec);
  let decls_length = List.length decls in
  (* We open and close the declaration group with [{start, end}_fun_decl_group].

     Some backends require the groups to be delimited. For instance, if we target
     HOL4, the calls to [{start, end}_fun_decl_group] would generate the
     [val ... = Define `] and [`] delimiters in the snippet of code below:

     {[
       val ... = Define `
         (even (i : num) : bool result = if i = 0 then Return T else odd (i - 1)) /\
         (odd (i : num) : bool result = if i = 0 then Return F else even (i - 1))
       `
     ]}

     TODO: in practice splitting the code this way doesn't work so well: merge
     the start/end decl group functions with the extract_fun_decl function?
  *)
  (* Filter the definitions - we generate a list of continuations *)
  let extract_defs =
    List.mapi
      (fun i (def : Pure.fun_decl) ->
        [%ltrace name_to_string ctx.trans_ctx def.Pure.item_meta.name];
        let is_opaque = Option.is_none def.Pure.body in
        let kind =
          if is_opaque then
            if config.interface then ExtractBase.Declared
            else ExtractBase.Builtin
          else if not is_rec then ExtractBase.SingleNonRec
          else if is_mut_rec then
            (* If the functions are mutually recursive, we need to distinguish:
             * - the first of the group
             * - the last of the group
             * - the inner functions
             *)
            if i = 0 then ExtractBase.MutRecFirst
            else if i = decls_length - 1 then ExtractBase.MutRecLast
            else ExtractBase.MutRecInner
          else ExtractBase.SingleRec
        in
        let has_decr_clause =
          (not fuel) && has_decreases_clause def
          && config.extract_decreases_clauses
        in
        (* Check if the definition needs to be filtered or not *)
        if
          ((not is_opaque) && config.extract_transparent)
          || (is_opaque && config.extract_opaque)
        then
          Some
            (fun () ->
              Extract.extract_fun_decl
                ~fuel:(if fuel then Extract.FuelVersion else Extract.NoFuel)
                ctx fmt kind has_decr_clause def)
        else None)
      decls
  in
  let extract_defs = List.filter_map (fun x -> x) extract_defs in
  if extract_defs <> [] then (
    (* Save the fact that we extract opaque definitions, if we do *)
    let contains_opaque =
      List.exists (fun (d : Pure.fun_decl) -> Option.is_none d.body) decls
    in
    ctx.extracted_opaque := contains_opaque || !(ctx.extracted_opaque);

    Extract.start_fun_decl_group ctx fmt is_rec decls;
    List.iter (fun f -> f ()) extract_defs;
    Extract.end_fun_decl_group fmt is_rec decls;
    (* The functions of a group in fuel form: the first defined result of
       their fuel versions *)
    if fuel then
      List.iter
        (fun (def : Pure.fun_decl) ->
          if Option.is_some def.body && config.extract_transparent then
            Extract.extract_fun_decl ~fuel:Extract.FuelWrapper ctx0 fmt
              ExtractBase.SingleNonRec false def)
        decls)

(** Export a global declaration.

    The functions introduced for the loops of its initializer are exported
    first: the global body calls them.

    TODO: check correct behavior with opaque globals. *)
let export_global (fmt : Format.formatter) (config : gen_config) (ctx : gen_ctx)
    (id : GlobalDeclId.id) : unit =
  let global_decls = ctx.trans_ctx.crate.global_decls in
  let global = GlobalDeclId.Map.find id global_decls in
  let trans =
    [%silent_unwrap_opt_span] None
      (FunDeclId.Map.find_opt global.init ctx.trans_funs)
  in
  let body = trans.f in

  let is_opaque = Option.is_none body.Pure.body in

  (* Check if we extract the global *)
  let extract =
    config.extract_globals
    && (((not is_opaque) && config.extract_transparent)
       || (is_opaque && config.extract_opaque))
  in
  (* Check if it is a builtin global - if yes, we ignore it because we
     map the definition to one in the standard library *)
  let open ExtractBuiltin in
  let extract =
    extract
    && match_name_find_opt ctx.trans_ctx global.item_meta.name
         (builtin_globals_map ())
       = None
  in
  if extract then (
    (* Save the fact that we extract opaque definitions, if we do *)
    ctx.extracted_opaque := is_opaque || !(ctx.extracted_opaque);
    (* We don't wrap global declaration groups between calls to functions
       [{start, end}_global_decl_group] (which don't exist): global declaration
       groups are always singletons, so the [extract_global_decl] function
       takes care of generating the delimiters.
    *)
    let loops = trans.loops @ trans.bodies in
    List.iter
      (fun (is_rec, decls) ->
        export_functions_group_scc fmt config ctx is_rec decls)
      (ReorderDecls.group_reorder_fun_decls
         ~inline_trait_impls:ctx.inline_trait_impls loops);
    let global = GlobalDeclId.Map.find_opt id ctx.trans_globals in
    Extract.extract_global_decl ctx fmt global body config.interface;
    sc_record ctx (IdGlobal id))

(** Export a group of function declarations.

    In case of (non-mutually) recursive functions, we use a simple procedure to
    check if the forward and backward functions are mutually recursive. *)
let export_functions_group (fmt : Format.formatter) (config : gen_config)
    (ctx : gen_ctx) (pure_ls : pure_fun_translation list) : unit =
  (* Check if the definition are builtin - if yes they must be ignored.
     Note that if one definition in the group is builtin, then all the
     definitions must be builtin *)
  let builtin =
    let mctx = NameMatcher.ctx_from_crate ctx.trans_ctx.crate in
    List.map
      (fun (trans : pure_fun_translation) ->
        ExtractBuiltin.mem_fun mctx trans.f.def_id trans.f.item_meta.name)
      pure_ls
  in

  if List.exists (fun b -> b) builtin then
    (* Sanity check *)
    assert (List.for_all (fun b -> b) builtin)
  else
    (* Utility to check a function has a decrease clause *)
    let has_decreases_clause (def : Pure.fun_decl) : bool =
      PureUtils.FunLoopIdSet.mem (def.def_id, def.loop_id)
        ctx.functions_with_decreases_clause
    in

    (* Extract the decrease clauses template bodies *)
    if config.extract_template_decreases_clauses then
      List.iter
        (fun f ->
          (* We only generate decreases clauses for the forward functions, because
             the termination argument should only depend on the forward inputs.
             The backward functions thus use the same decreases clauses as the
             forward function.

             Rem.: we might filter backward functions in {!PureMicroPasses}, but
             we don't remove forward functions. Instead, we remember if we should
             filter those functions at extraction time with a boolean (see the
             type of the [pure_ls] input parameter).
          *)
          let extract_decrease decl =
            let has_decr_clause = has_decreases_clause decl in
            if has_decr_clause then
              match Config.backend () with
              | Lean ->
                  Extract.extract_template_lean_termination_and_decreasing ctx
                    fmt decl
              | FStar ->
                  Extract.extract_template_fstar_decreases_clause ctx fmt decl
              | Coq ->
                  raise
                    (Failure "Coq doesn't have decreases/termination clauses")
              | HOL4 ->
                  raise
                    (Failure "HOL4 doesn't have decreases/termination clauses")
          in
          extract_decrease f.f;
          List.iter extract_decrease f.loops)
        pure_ls;

    (* Flatten the translated functions (concatenate the functions with
       the declarations introduced for the loops) *)
    let decls =
      List.concat
        (List.map (fun f -> List.append (f.loops @ f.bodies) [ f.f ]) pure_ls)
    in

    (* Extract the function definitions *)
    if config.extract_fun_decls then (
      (* Group the mutually recursive definitions *)
      let subgroups =
        ReorderDecls.group_reorder_fun_decls
          ~inline_trait_impls:ctx.inline_trait_impls decls
      in

      (* Extract the subgroups *)
      let export_subgroup (is_rec : bool) (decls : Pure.fun_decl list) : unit =
        export_functions_group_scc fmt config ctx is_rec decls
      in
      List.iter (fun (is_rec, decls) -> export_subgroup is_rec decls) subgroups;
      (* Record the Rust functions whose definition was emitted *)
      List.iter
        (fun (trans : pure_fun_translation) ->
          let is_opaque = Option.is_none trans.f.body in
          if
            ((not is_opaque) && config.extract_transparent)
            || (is_opaque && config.extract_opaque)
          then sc_record ctx (IdFun trans.f.def_id))
        pure_ls);

    (* Insert unit tests for functions marked with #[verify::test] *)
    List.iter
      (fun trans -> Extract.extract_unit_test_if_marked ctx fmt trans.f)
      pure_ls

(* A trait declaration or implementation whose translation failed has no entry
   in the translated context: its error was reported when its translation
   failed, and it is not exported (as a function whose translation failed). *)
let trait_decl_is_builtin (ctx : gen_ctx) (id : Pure.trait_decl_id) : bool =
  match TraitDeclId.Map.find_opt id ctx.trans_trait_decls with
  | Some trait_decl -> Option.is_some trait_decl.builtin_info
  | None -> false

let trait_impl_is_builtin (ctx : gen_ctx) (id : Pure.trait_impl_id) : bool =
  match TraitImplId.Map.find_opt id ctx.trans_trait_impls with
  | Some trait_impl -> Option.is_some trait_impl.builtin_info
  | None -> false

(** Export a trait declaration. *)
let export_trait_decl (fmt : Format.formatter) (_config : gen_config)
    (ctx : gen_ctx) (trait_decl_id : Pure.trait_decl_id) (extract_decl : bool)
    (extract_extra_info : bool) : unit =
  match TraitDeclId.Map.find_opt trait_decl_id ctx.trans_trait_decls with
  | None -> ()
  | Some trait_decl ->
      (* A declaration one of whose methods could not be translated (its error
         was reported) is not exported either: its structure would lack the
         method's field *)
      let methods_translated =
        List.for_all
          (fun (_, (m : Pure.fun_decl_ref Pure.binder)) ->
            FunDeclId.Map.mem m.binder_value.fun_id ctx.trans_funs)
          trait_decl.methods
      in
      (* Check if the trait declaration is builtin, in which case we ignore it *)
      if Option.is_none trait_decl.builtin_info && methods_translated then (
        let ctx = { ctx with trait_decl_id = Some trait_decl.def_id } in
        if extract_decl then (
          Extract.extract_trait_decl ctx fmt trait_decl;
          sc_record ctx (IdTraitDecl trait_decl_id));
        if extract_extra_info then
          Extract.extract_trait_decl_extra_info ctx fmt trait_decl)

(** Export a trait implementation. *)
let export_trait_impl (fmt : Format.formatter) (_config : gen_config)
    (ctx : gen_ctx) ~(is_rec : bool) (trait_impl_id : Pure.trait_impl_id) : unit
    =
  match TraitImplId.Map.find_opt trait_impl_id ctx.trans_trait_impls with
  | None -> ()
  | Some trait_impl ->
      if Option.is_none trait_impl.builtin_info then (
        let ctx =
          if is_rec then
            {
              ctx with
              local_trait_impl_refs = TraitImplId.Set.singleton trait_impl_id;
            }
          else ctx
        in
        Extract.extract_trait_impl ctx fmt ~is_rec trait_impl;
        sc_record ctx (IdTraitImpl trait_impl_id))

(** A generic utility to generate the extracted definitions: as we may want to
    split the definitions between different files (or not), we can control what
    is precisely extracted. *)
let extract_definitions ?(on_group_done : unit -> unit = fun () -> ())
    (fmt : Format.formatter) (config : gen_config) (ctx : gen_ctx) : unit =
  (* Export the definition groups to the file, in the proper order.
     - [extract_decl]: extract the type declaration (if not filtered)
     - [extract_extra_info]: extra the extra type information (e.g.,
       the [Arguments] information in Coq).
  *)
  let export_funs ctx = export_functions_group fmt config ctx in
  let export_global = export_global fmt config ctx in
  let export_types_group = export_types_group fmt config ctx in
  let export_trait_decl_group id =
    export_trait_decl fmt config ctx id true false
  in
  let export_trait_decl_group_extra_info id =
    export_trait_decl fmt config ctx id false true
  in
  let export_impl ctx ~is_rec = export_trait_impl fmt config ctx ~is_rec in

  let export_decl_group (dg : declaration_group) : unit =
    match dg with
    | TypeGroup (NonRecGroup id) ->
        if config.extract_types then export_types_group false [ id ]
    | TypeGroup (RecGroup ids) ->
        if config.extract_types then export_types_group true ids
    | FunGroup (NonRecGroup id) -> (
        (* Lookup - the translated function may not be in the map if we had
           to ignore it because of errors *)
        let pure_fun = FunDeclId.Map.find_opt id ctx.trans_funs in
        (* Special case: we skip trait method *declarations* (we will
           extract their type directly in the records we generate for
           the trait declarations themselves, there is no point in having
           separate type definitions) *)
        match pure_fun with
        | Some pure_fun -> (
            match pure_fun.f.Pure.src with
            | TraitDeclItem (_, _, false) -> ()
            (* Global initializers are translated along with the global definition *)
            | _ when pure_fun.f.is_global_decl_body -> ()
            | _ ->
                (* Translate *)
                export_funs ctx [ pure_fun ])
        | None -> ())
    | FunGroup (RecGroup ids) ->
        (* General case of mutually recursive functions *)
        (* Lookup *)
        let pure_funs =
          List.filter_map
            (fun id -> FunDeclId.Map.find_opt id ctx.trans_funs)
            ids
        in
        if List.exists (fun pf -> pf.f.is_global_decl_body) pure_funs then
          [%craise_opt_span] None "Mutually recursive globals are not supported"
        else (* Translate *)
          export_funs ctx pure_funs
    | GlobalGroup (NonRecGroup id) -> export_global id
    | GlobalGroup (RecGroup _ids) ->
        [%craise_opt_span] None "Mutually recursive globals are not supported"
    | TraitDeclGroup (RecGroup ids) ->
        (* Only print the warning if we actually extract the group *)
        let extract =
          config.extract_trait_decls && config.extract_transparent
        in
        if extract then
          (* Lookup the trait decls to print a nice error message *)
          let to_string (id : trait_decl_id) : string =
            match TraitDeclId.Map.find_opt id ctx.trans_trait_decls with
            | None ->
                "unknown trait (lookup failed, probably because of a previous \
                 error"
            | Some d ->
                "'"
                ^ name_to_string ctx.trans_ctx d.item_meta.name
                ^ "', source: "
                ^ Errors.raw_span_to_string d.item_meta.span
          in
          let decls = List.map to_string ids in
          if not (List.for_all (trait_decl_is_builtin ctx) ids) then (
            if List.length decls = 1 then
              [%warn_opt_span] None
                ("Recursive trait declarations are not supported; the \
                  following recursive trait is going to be extracted but its \
                  model will not type-check:\n" ^ String.concat "\n" decls)
            else
              [%warn_opt_span] None
                ("Mutually recursive trait declarations are not supported; the \
                  following group of mutually recursive traits is going to be \
                  extracted but their model will not type-check:\n"
               ^ String.concat "\n" decls);
            (* We still extract something so that the user can look at it and
             eventually fix it *)
            (* TODO: update to extract groups *)
            List.iter
              (fun id ->
                export_trait_decl_group id;
                export_trait_decl_group_extra_info id)
              ids)
    | TraitDeclGroup (NonRecGroup id) ->
        (* TODO: update to extract groups *)
        if config.extract_trait_decls && config.extract_transparent then (
          export_trait_decl_group id;
          export_trait_decl_group_extra_info id)
    | TraitImplGroup (NonRecGroup id) ->
        if config.extract_trait_impls && config.extract_transparent then
          export_impl ctx ~is_rec:false id
    | TraitImplGroup (RecGroup ids) ->
        (* Only print the warning if we extract the impl group *)
        let extract =
          config.extract_trait_impls && config.extract_transparent
        in
        if extract then
          (* Lookup the trait impls to print a nice error message *)
          let to_string (id : trait_impl_id) : string =
            match TraitImplId.Map.find_opt id ctx.trans_trait_impls with
            | None ->
                "unknown trait (lookup failed, probably because of a previous \
                 error"
            | Some d ->
                "'"
                ^ name_to_string ctx.trans_ctx d.item_meta.name
                ^ "', source: "
                ^ Errors.raw_span_to_string d.item_meta.span
          in
          let decls = List.map to_string ids in
          if not (List.for_all (trait_impl_is_builtin ctx) ids) then (
            (* We actually have a special elaboration in Lean that allows us
               to support recursive trait impls *)
            if List.length decls = 1 then
              if Config.backend () = Lean then ()
              else
                [%warn_opt_span] None
                  ("Recursive trait implementations are not supported; the \
                    following recursive impl is going to be extracted but its \
                    model will not type-check:\n" ^ String.concat "\n" decls)
            else
              [%warn_opt_span] None
                ("Mutually recursive trait implementations are not supported; \
                  the following group of mutually recursive impls is going to \
                  be extracted but their model will not type-check:\n"
               ^ String.concat "\n" decls);
            (* We still extract something so that the user can look at it and
               eventually fix it *)
            (* TODO: update to extract groups *)
            (* We mark the definition as recursive only if the group is a
               singleton and we extract for Lean: Lean's special elaboration
               doesn't work for mutually recursive impls. *)
            let is_rec = List.length decls = 1 && Config.backend () = Lean in
            List.iter (fun id -> export_impl ctx ~is_rec id) ids)
    | MixedGroup (RecGroup ids as group)
      when LlbcAstUtils.mixed_declaration_group_is_supported group ->
        (* Tie the recursive functions, not a cyclic record value. Reconstruct
           dictionaries from those functions at their uses, then publish the
           ordinary dictionaries after the functions have been defined. *)
        let inline_trait_impls =
          List.fold_left
            (fun impls -> function
              | IdTraitImpl id -> (
                  match TraitImplId.Map.find_opt id ctx.trans_trait_impls with
                  | Some impl when Option.is_none impl.builtin_info ->
                      TraitImplId.Map.add id impl impls
                  | _ -> impls)
              | _ -> impls)
            TraitImplId.Map.empty ids
        in
        let ctx = { ctx with inline_trait_impls } in
        let funs =
          List.filter_map
            (function
              | IdFun id -> FunDeclId.Map.find_opt id ctx.trans_funs
              | _ -> None)
            ids
        in
        if List.exists (fun f -> f.f.is_global_decl_body) funs then
          [%craise_opt_span] None "Mutually recursive globals are not supported";
        export_funs ctx funs;
        if config.extract_trait_impls && config.extract_transparent then
          List.iter
            (function
              | IdTraitImpl id -> export_impl ctx ~is_rec:false id
              | _ -> ())
            ids
    | MixedGroup _ ->
        [%craise_opt_span] None
          "Mixed-recursive declaration groups are not supported"
  in
  (* Separate compilation: the groups of external items are emitted by their
     owner chunk. A group cannot be split between chunks. *)
  let export_decl_group (dg : declaration_group) : unit =
    (* Trait method declarations are not emitted on their own *)
    let ids =
      List.filter
        (function
          | IdFun id -> (
              match FunDeclId.Map.find_opt id ctx.crate.fun_decls with
              | Some { src = TraitDeclItem (_, _, false); _ } -> false
              | _ -> true)
          | _ -> true)
        (Charon.GAstUtils.declaration_group_to_list dg)
    in
    match List.partition SC.is_external ids with
    | [], _ -> export_decl_group dg
    | _, [] -> ()
    | external_ids, _ ->
        let keys =
          List.filter_map (fun id -> SC.item_key ctx.crate id) external_ids
        in
        [%craise_opt_span] None
          ("Separate compilation: a recursive declaration group contains items \
            emitted by another chunk: " ^ String.concat ", " keys)
  in

  List.iter
    (fun g ->
      let span =
        match Charon.GAstUtils.declaration_group_to_list g with
        | id :: _ ->
            Option.map
              (fun (meta : item_meta) -> meta.span)
              (LlbcAstUtils.crate_get_item_meta ctx.crate id)
        | [] -> None
      in
      (try
         [%recover_internal_errors_opt_span] span (fun () ->
             export_decl_group g)
       with CFailure _ ->
         (* An exception was raised: ignore it *)
         ());
      on_group_done ())
    ctx.crate.declarations

type extract_file_info = {
  filename : string;
  namespace : string;
  in_namespace : bool;
  open_namespace : bool;
  crate_name : string;
  rust_module_name : string;
  module_name : string;
  custom_msg : string;
  custom_imports : string list;
  custom_includes : string list;
  noncomputable : bool;
      (** If [true] we insert a [noncomputable section] instruction at the top
          of the file *)
}

(** Separate compilation: the Lean modules imported by every generated file (the
    owners of the external items) *)
let sc_imports : string list ref = ref []

(** Separate compilation: the Lean modules are named after their path relative
    to the destination directory (the Lean source root). *)
let sc_dest_dir : string ref = ref ""

let sc_lean_module_of_file (filename : string) : string =
  let dir = !sc_dest_dir in
  let prefix = if String.ends_with ~suffix:"/" dir then dir else dir ^ "/" in
  let rel =
    if String.starts_with ~prefix filename then
      String.sub filename (String.length prefix)
        (String.length filename - String.length prefix)
    else filename
  in
  let rel =
    Option.value (Filename.chop_suffix_opt ~suffix:".lean" rel) ~default:rel
  in
  String.concat "." (List.filter (( <> ) "") (String.split_on_char '/' rel))

(** Set the module which owns the declarations emitted from now on *)
let sc_enter_file (filename : string) : unit =
  if SC.enabled () then (
    let m = sc_lean_module_of_file filename in
    if List.mem m !sc_imports then
      SC.fail
        ("Separate compilation: the module " ^ m
       ^ " is generated by this chunk but owns external items (a manifest of \
          this chunk was given with -external)");
    SC.current_module := Some m)

(** Print the module header: imports, options and the opened namespace. *)
let write_file_header (out : out_channel) (fi : extract_file_info) : unit =

  (* Print the headers.
   * Note that we don't use the OCaml formatter for purpose: we want to control
   * line insertion (we have to make sure that some instructions like [open MODULE]
   * are printed on one line!).
   * This is ok as long as we end up with a line break, so that the formatter's
   * internal count is consistent with the state of the file.
   *)
  (* Create the header *)
  (match Config.backend () with
  | Lean ->
      Printf.fprintf out "-- THIS FILE WAS AUTOMATICALLY GENERATED BY AENEAS\n";
      Printf.fprintf out "-- [%s]%s\n" fi.rust_module_name fi.custom_msg
  | Coq | FStar | HOL4 ->
      Printf.fprintf out
        "(** THIS FILE WAS AUTOMATICALLY GENERATED BY AENEAS *)\n";
      Printf.fprintf out "(** [%s]%s *)\n" fi.rust_module_name fi.custom_msg);
  (* Generate the imports *)
  (match Config.backend () with
  | FStar ->
      Printf.fprintf out "module %s\n" fi.module_name;
      Printf.fprintf out "open Primitives\n";
      (* Add the custom imports *)
      List.iter (fun m -> Printf.fprintf out "open %s\n" m) fi.custom_imports;
      (* Add the custom includes *)
      List.iter
        (fun m -> Printf.fprintf out "include %s\n" m)
        fi.custom_includes;
      (* Z3 options - note that we use fuel 1 because it its useful for the decrease clauses *)
      Printf.fprintf out "\n#set-options \"--z3rlimit 50 --fuel 1 --ifuel 1\"\n"
  | Coq ->
      Printf.fprintf out "Require Import Primitives.\n";
      Printf.fprintf out "Import Primitives.\n";
      Printf.fprintf out "Require Import Coq.ZArith.ZArith.\n";
      Printf.fprintf out "Require Import List.\n";
      Printf.fprintf out "Import ListNotations.\n";
      Printf.fprintf out "Local Open Scope Primitives_scope.\n";

      (* Add the custom imports *)
      List.iter
        (fun m -> Printf.fprintf out "Require Import %s.\n" m)
        fi.custom_imports;
      (* Add the custom includes *)
      List.iter
        (fun m ->
          (* TODO: I don't really understand how the "Require Export",
             "Require Import", "Include" work.
             I used to have:
             {[
               Require Export %s.
               Import %s.
             ]}

             I now have:
             {[
               Require Import %s.
               Include %s.
             ]}
          *)
          Printf.fprintf out "Require Import %s.\n" m;
          Printf.fprintf out "Include %s.\n" m)
        fi.custom_includes;
      Printf.fprintf out "Module %s.\n" fi.module_name
  | Lean ->
      Printf.fprintf out "import Aeneas\n";
      (* Separate compilation: the modules owning the external items *)
      List.iter (fun m -> Printf.fprintf out "import %s\n" m) !sc_imports;
      (* Add the custom imports *)
      List.iter (fun m -> Printf.fprintf out "import %s\n" m) fi.custom_imports;
      (* Add the custom includes *)
      List.iter (fun m -> Printf.fprintf out "import %s\n" m) fi.custom_includes;
      (* Always open the Primitives namespace *)
      Printf.fprintf out "open Aeneas Aeneas.Std Result ControlFlow Error\n";
      (* It happens that we generate duplicated namespaces, like `betree.betree`.
         We deactivate the linter for this, because otherwise it leads to too much
         noise. *)
      Printf.fprintf out "set_option linter.dupNamespace false\n";
      (* The mathlib linter generates warnings when we use hash commands like `#assert`:
         we deactivate this linter. *)
      Printf.fprintf out "set_option linter.hashCommand false\n";
      (* Definitions often contain unused variables: deactivate the corresponding linter *)
      Printf.fprintf out "set_option linter.unusedVariables false\n";
      (* Max heart beats *)
      Printf.fprintf out
        "\n\
         /- You can set the `maxHeartbeats` value with the `-max-heartbeats` \
         CLI option -/\n";
      Printf.fprintf out "set_option maxHeartbeats %d\n" !Config.max_heartbeats;
      (* Declare the definitions as being noncomputable if needs be *)
      if fi.noncomputable then
        Printf.fprintf out
          "\n\
           /- You can remove the following line by using the CLI option \
           `-all-computable`: -/\n\
           noncomputable section\n";
      (* If we are inside the namespace: declare it (with [-canonical-names],
         there might be no namespace) *)
      if fi.in_namespace && fi.namespace <> "" then
        Printf.fprintf out "\nnamespace %s\n" fi.namespace;
      (* We might need to open the namespace *)
      if fi.open_namespace && fi.namespace <> "" then
        Printf.fprintf out "open %s\n" fi.namespace
  | HOL4 ->
      Printf.fprintf out "open primitivesLib divDefLib\n";
      (* Add the custom imports and includes *)
      let imports = fi.custom_imports @ fi.custom_includes in
      (* The imports are a list of module names: we need to add a "Theory" suffix *)
      let imports = List.map (fun s -> s ^ "Theory") imports in
      if imports <> [] then
        let imports = String.concat " " imports in
        Printf.fprintf out "open %s\n\n" imports
      else Printf.fprintf out "\n";
      (* Initialize the theory *)
      Printf.fprintf out "val _ = new_theory \"%s\"\n\n" fi.module_name);
  ()

(** Close the namespace or module opened by [write_file_header]. *)
let write_file_footer (out : out_channel) (fi : extract_file_info) : unit =
  match Config.backend () with
  | FStar -> ()
  | Lean ->
      if fi.in_namespace && fi.namespace <> "" then
        Printf.fprintf out "end %s\n" fi.namespace
  | HOL4 -> Printf.fprintf out "val _ = export_theory ()\n"
  | Coq -> Printf.fprintf out "End %s.\n" fi.module_name

let log_generated (filename : string) : unit =
  if !Errors.error_list <> [] then
    log#linfo
      (lazy
        ("Generated the partial file (because of "
        ^ string_of_int (List.length !Errors.error_list)
        ^ " errors, including "
        ^ string_of_int (Errors.FileLineMap.cardinal !Errors.unique_errors)
        ^ " unique errors): " ^ filename))
  else log#linfo (lazy ("Generated: " ^ filename))

let extract_file (config : gen_config) (ctx : gen_ctx) (fi : extract_file_info)
    : unit =
  (* Open the file and create the formatter *)
  let out = open_out fi.filename in
  sc_enter_file fi.filename;
  let fmt = Format.formatter_of_out_channel out in
  (* The header is printed without the formatter: some instructions like
     [open MODULE] must be printed on one line. This is ok as long as the header
     ends with a line break, so that the formatter's internal count is
     consistent with the state of the file. *)
  write_file_header out fi;
  (* From now onwards, we use the formatter *)
  Format.pp_set_margin fmt 80;
  (* Create a vertical box *)
  Format.pp_open_vbox fmt 0;
  (* Extract the definitions *)
  extract_definitions fmt config ctx;
  (* Close the box and end the formatting *)
  Format.pp_close_box fmt ();
  Format.pp_print_newline fmt ();
  write_file_footer out fi;
  log_generated fi.filename;
  (* Flush and close the file *)
  close_out out

(** Like [extract_file], but write the definitions to a chain of modules
    [part 1], [part 2], ... each importing its predecessor (the first one
    imports [fi]'s includes). A new module starts at a declaration-group
    boundary once the current one holds more than [chunk_bytes] bytes, so no
    group is split and every module only depends on earlier ones. Finally
    [fi.filename] is written as a module that imports the last part, so the
    importers of [fi.module_name] are unaffected. *)
let extract_file_chunked (config : gen_config) (ctx : gen_ctx)
    (fi : extract_file_info) ~(chunk_bytes : int)
    ~(part : int -> string * string) : unit =
  let current : out_channel option ref = ref None in
  let current_info : extract_file_info option ref = ref None in
  let written = ref 0 in
  let index = ref 0 in
  let output s pos len =
    match !current with
    | Some out ->
        output_substring out s pos len;
        written := !written + len
    | None -> [%craise_opt_span] None "chunked extraction: no open module"
  in
  let flush () = Option.iter flush !current in
  let fmt = Format.make_formatter output flush in
  Format.pp_set_margin fmt 80;
  (* Every part holds one top-level vertical box that is closed (by a flush)
     at each declaration-group boundary and reopened afterwards. *)
  let open_part () =
    incr index;
    let filename, module_name = part !index in
    sc_enter_file filename;
    let custom_includes =
      if !index = 1 then fi.custom_includes else [ snd (part (!index - 1)) ]
    in
    let info = { fi with filename; module_name; custom_includes } in
    let out = open_out filename in
    write_file_header out info;
    current := Some out;
    current_info := Some info;
    written := 0
  in
  (* Requires the formatter to be flushed. *)
  let finish_part () =
    match (!current, !current_info) with
    | Some out, Some info ->
        write_file_footer out info;
        log_generated info.filename;
        close_out out;
        current := None;
        current_info := None
    | _ -> [%craise_opt_span] None "chunked extraction: no open module"
  in
  open_part ();
  Format.pp_open_vbox fmt 0;
  let on_group_done () =
    (* The pending formatter content belongs to the group just exported. *)
    Format.pp_print_flush fmt ();
    if !written > chunk_bytes then (
      finish_part ();
      open_part ());
    Format.pp_open_vbox fmt 0
  in
  extract_definitions ~on_group_done fmt config ctx;
  Format.pp_close_box fmt ();
  Format.pp_print_newline fmt ();
  Format.pp_print_flush fmt ();
  finish_part ();
  (* The entry module only re-exports the last part. *)
  let out = open_out fi.filename in
  write_file_header out
    {
      fi with
      custom_includes = [ snd (part !index) ];
      in_namespace = false;
      open_namespace = false;
      noncomputable = false;
    };
  log_generated fi.filename;
  close_out out

let extract_translated_crate (filename : string) (dest_dir : string)
    (subdir : string option) (crate : crate) (trans_ctx : trans_ctx)
    (trans_crate : translated_crate) (extracted_opaque : bool ref) : unit =
  let {
    type_decls = trans_types;
    builtin_fun_sigs = builtin_sigs;
    fun_decls = trans_funs;
    global_decls = trans_globals;
    trait_decls = trans_trait_decls;
    trait_impls = trans_trait_impls;
  } =
    trans_crate
  in
  (* Initialize the names map by registering the keywords used in the
     language, as well as some primitive names ("u32", etc.).
     We insert the names of the local declarations later. *)
  let names_maps = Extract.initialize_names_maps () in

  (* We need to compute which functions are recursive, in order to know
   * whether we should generate a decrease clause or not. *)
  let rec_functions =
    List.map
      (fun trans ->
        let f =
          if trans.f.Pure.signature.fwd_info.effect_info.is_rec then
            [ (trans.f.def_id, None) ]
          else []
        in
        let loops =
          List.map
            (fun (def : Pure.fun_decl) -> [ (def.def_id, def.loop_id) ])
            trans.loops
        in
        f :: loops)
      trans_funs
  in
  let rec_functions : PureUtils.fun_loop_id list =
    List.concat (List.concat rec_functions)
  in
  let rec_functions = PureUtils.FunLoopIdSet.of_list rec_functions in

  (* Put the translated definitions in maps *)
  let trans_types =
    Pure.TypeDeclId.Map.of_list
      (List.map (fun (d : Pure.type_decl) -> (d.def_id, d)) trans_types)
  in
  let trans_funs : pure_fun_translation FunDeclId.Map.t =
    FunDeclId.Map.of_list
      (List.map
         (fun (trans : pure_fun_translation) -> (trans.f.def_id, trans))
         trans_funs)
  in

  (* Put everything in the context *)
  let ctx =
    let trans_globals =
      GlobalDeclId.Map.of_list
        (List.map (fun (d : Pure.global_decl) -> (d.def_id, d)) trans_globals)
    in
    let trans_trait_decls =
      TraitDeclId.Map.of_list
        (List.map
           (fun (d : Pure.trait_decl) -> (d.def_id, d))
           trans_trait_decls)
    in
    let trans_trait_impls =
      TraitImplId.Map.of_list
        (List.map
           (fun (d : Pure.trait_impl) -> (d.def_id, d))
           trans_trait_impls)
    in
    {
      ExtractBase.crate;
      trans_ctx;
      names_maps;
      indent_incr = 2;
      use_dep_ite =
        Config.backend () = Lean && !Config.extract_decreases_clauses;
      trait_decl_id = None (* None by default *);
      trans_trait_decls;
      trans_trait_impls;
      model_marker_fields =
        ModelStateABI.collect_marker_fields trans_ctx trans_trait_decls trans_trait_impls;
      trans_types;
      trans_funs;
      builtin_sigs;
      trans_globals;
      functions_with_decreases_clause = rec_functions;
      local_function_refs = PureUtils.FunLoopIdSet.empty;
      fuel_function_refs = PureUtils.FunLoopIdSet.empty;
      local_trait_impl_refs = Pure.TraitImplId.Set.empty;
      inline_trait_impls = Pure.TraitImplId.Map.empty;
      inline_trait_impl_stack = Pure.TraitImplId.Set.empty;
      extract_inline_trait_impl = Extract.extract_inline_trait_impl;
      types_filter_type_args_map = Pure.TypeDeclId.Map.empty;
      funs_filter_type_args_map = Pure.FunDeclId.Map.empty;
      funs_filter_trait_clauses_map = Pure.FunDeclId.Map.empty;
      trait_impls_filter_type_args_map = Pure.TraitImplId.Map.empty;
      trait_impls_filter_trait_clauses_map = Pure.TraitImplId.Map.empty;
      extracted_opaque;
    }
  in

  (* Register unique names for all the top-level types, globals, functions...

     Note that the order in which we generate the names **matter**: we detect
     name classes between ADT methods and ADT fields, and rename the methods
     appropriately.

     For instance, the field and method [len] might clash in the below code:
     {[
       struct Struct { len : usize }

       impl Struct { fn len(&self) -> usize { self.len } }
     ]}

     For this reason, we need to generate names for the types *before* generating
     names for the functions (which include the method definitions). *)
  let ctx =
    List.fold_left
      (fun ctx (def : Pure.type_decl) ->
        try
          [%recover_internal_errors] def.item_meta.span (fun () ->
              Extract.extract_type_decl_register_names ctx def)
        with CFailure error ->
          (* An exception was raised: ignore it *)
          let name = name_to_string trans_ctx def.item_meta.name in
          let name_pattern =
            name_to_pattern_string_for_error (Some def.item_meta.span) trans_ctx
              def.item_meta.name
          in
          [%warn_recovered_opt_span] error.span
            ("Could not generate names for the type declaration '" ^ name
           ^ " because of previous error\nName pattern: '" ^ name_pattern ^ "'"
           ^ "\nDefinition span: "
            ^ Errors.raw_span_to_string def.item_meta.span
            ^ compute_local_uses_error_message trans_ctx (IdType def.def_id));
          ctx)
      ctx
      (Pure.TypeDeclId.Map.values trans_types)
  in

  let ctx =
    List.fold_left
      (fun ctx (trans : pure_fun_translation) ->
        try
          [%recover_internal_errors] trans.f.item_meta.span (fun () ->
              (* If requested by the user, register termination measures and
                 decreases proofs for all the recursive functions *)
              let gen_decr_clause (def : Pure.fun_decl) =
                !Config.extract_decreases_clauses
                && PureUtils.FunLoopIdSet.mem
                     (def.Pure.def_id, def.Pure.loop_id)
                     rec_functions
              in
              (* Register the names (for a global body: only its loops - the
                 global itself is handled later) *)
              Extract.extract_fun_decl_register_names ctx gen_decr_clause trans)
        with CFailure error ->
          (* An exception was raised: ignore it *)
          let name = name_to_string trans_ctx trans.f.item_meta.name in
          let name_pattern =
            name_to_pattern_string_for_error (Some trans.f.item_meta.span)
              trans_ctx trans.f.item_meta.name
          in
          [%warn_recovered_opt_span] error.span
            ("Could not generate names for the function declaration '" ^ name
           ^ " because of previous error\nName pattern: '" ^ name_pattern ^ "'"
           ^ "\nDefinition span: "
            ^ Errors.raw_span_to_string trans.f.item_meta.span
            ^ compute_local_uses_error_message trans_ctx (IdFun trans.f.def_id)
            );
          ctx)
      ctx
      (FunDeclId.Map.values trans_funs)
  in

  let ctx =
    List.fold_left
      (fun ctx (def : Pure.global_decl) ->
        try
          [%recover_internal_errors] def.item_meta.span (fun () ->
              Extract.extract_global_decl_register_names ctx def)
        with CFailure error ->
          (* An exception was raised: ignore it *)
          let name = name_to_string trans_ctx def.item_meta.name in
          let name_pattern =
            name_to_pattern_string_for_error (Some def.item_meta.span) trans_ctx
              def.item_meta.name
          in
          [%warn_recovered_opt_span] error.span
            ("Could not generate names for the global declaration '" ^ name
           ^ " because of previous error\nName pattern: '" ^ name_pattern ^ "'"
           ^ "\nDefinition span: "
            ^ Errors.raw_span_to_string def.item_meta.span
            ^ compute_local_uses_error_message trans_ctx (IdGlobal def.def_id));
          ctx)
      ctx trans_globals
  in

  let ctx =
    List.fold_left
      (fun ctx (def : Pure.trait_decl) ->
        try
          [%recover_internal_errors] def.item_meta.span (fun () ->
              Extract.extract_trait_decl_register_names ctx def)
        with CFailure error ->
          (* An exception was raised: ignore it *)
          let name = name_to_string trans_ctx def.item_meta.name in
          let name_pattern =
            name_to_pattern_string_for_error (Some def.item_meta.span) trans_ctx
              def.item_meta.name
          in
          [%warn_recovered_opt_span] error.span
            ("Could not generate names for the trait declaration '" ^ name
           ^ " because of previous error\nName pattern: '" ^ name_pattern ^ "'"
           ^ "\nDefinition span: "
            ^ Errors.raw_span_to_string def.item_meta.span
            ^ compute_local_uses_error_message trans_ctx
                (IdTraitDecl def.def_id));
          ctx)
      ctx trans_trait_decls
  in

  let ctx =
    List.fold_left
      (fun ctx (def : Pure.trait_impl) ->
        try
          [%recover_internal_errors] def.item_meta.span (fun () ->
              Extract.extract_trait_impl_register_names ctx def)
        with CFailure error ->
          (* An exception was raised: ignore it *)
          let name = name_to_string trans_ctx def.item_meta.name in
          let name_pattern =
            name_to_pattern_string_for_error (Some def.item_meta.span) trans_ctx
              def.item_meta.name
          in
          [%warn_recovered_opt_span] error.span
            ("Could not generate names for the trait implementation '" ^ name
           ^ " because of previous error\nName pattern: '" ^ name_pattern ^ "'"
           ^ "\nDefinition span: "
            ^ Errors.raw_span_to_string def.item_meta.span
            ^ compute_local_uses_error_message trans_ctx
                (IdTraitImpl def.def_id));
          ctx)
      ctx trans_trait_impls
  in

  (* Collection obligations (see [CollectionContracts]): the propositions of the
     generated code that admitted collections rely on *)
  (match !Config.emit_collection_obligations with
  | None -> ()
  | Some file ->
      (* The proposition is named by its declaration's full Lean name (as
         [Name.toString] prints it, e.g. for a closure audit), not by the
         [_root_]-escaped reference syntax of the generated code. *)
      let obligation id =
        let impl = TraitImplId.Map.find id crate.trait_impls in
        let prop =
          (match ExtractBase.extraction_namespace ctx with
          | Some namespace -> namespace ^ "."
          | None -> "")
          ^ ExtractBase.ctx_get_trait_impl ~as_reference:false
              impl.item_meta.span id ctx
          ^ ".size_hint_total"
        in
        `Assoc
          [
            ("kind", `String "iterator_size_hint_total");
            ("impl", `String (name_to_string trans_ctx impl.item_meta.name));
            ("proposition", `String prop);
          ]
      in
      Yojson.Basic.to_file file
        (`Assoc
           [
             ("version", `Int 1);
             ( "obligations",
               `List
                 (List.map obligation
                    (TraitImplId.Set.elements
                       !CollectionContracts.size_hint_obligations)) );
           ]));

  (* Separate compilation: check the external views, and import their owners *)
  sc_dest_dir := dest_dir;
  if SC.enabled () then (
    sc_check_external_views ctx;
    sc_imports :=
      SC.modules_of
        (List.concat_map Charon.GAstUtils.declaration_group_to_list
           ctx.crate.declarations));

  let module_delimiter =
    match Config.backend () with
    | FStar -> "."
    | Coq -> "_"
    | Lean -> "."
    | HOL4 -> "_"
  in
  let file_delimiter =
    if Config.backend () = Lean then "/" else module_delimiter
  in

  (* Open the output file *)
  (* First compute the filename by replacing the extension and converting the
   * case (rust module names are snake case) *)
  let namespace, crate_name, full_dest_dir, extract_filebasename =
    match Filename.chop_suffix_opt ~suffix:".llbc" filename with
    | None ->
        (* Note that we already checked the suffix upon opening the file *)
        raise (Failure "Unreachable")
    | Some filename ->
        (* Retrieve the file basename *)
        let basename = Filename.basename filename in
        (* Convert the case *)
        let crate_name = StringUtils.to_camel_case basename in
        let crate_name =
          if Config.backend () = HOL4 then
            StringUtils.lowercase_first_letter crate_name
          else crate_name
        in
        (* We use the raw crate name for the namespaces, unless the user
           has provided one (with [-canonical-names], there is no namespace
           unless the user provided one) *)
        let namespace =
          Option.value (ExtractBase.lean_namespace crate.name) ~default:""
        in
        let full_dest_dir =
          match subdir with
          | None -> dest_dir
          | Some subdir -> Filename.concat dest_dir subdir
        in
        (*
           If the backend is Lean the module names depends on the path,
           so we generate names of the shape [Types.lean], [Funs.lean], etc.
           because those files should be placed in the proper sub-folder.

           Otherwise, we prepend the crate name to generate, e.g.,
           [Foo_Types.fst], [Foo_Funs.fst], etc.
         *)
        let filebasename =
          if !Config.split_files then
            if Config.backend () = Lean then full_dest_dir ^ "/"
            else Filename.concat full_dest_dir crate_name ^ module_delimiter
          else Filename.concat full_dest_dir crate_name
        in

        (* Concatenate *)
        (namespace, crate_name, full_dest_dir, filebasename)
  in
  [%ltrace
    "namespace: " ^ namespace ^ "\n- crate_name: " ^ crate_name
    ^ "\n- full_dest_dir: " ^ full_dest_dir ^ "\n- extract_filebasename: "
    ^ extract_filebasename];

  let mkdir_if dest_dir =
    if not (Sys.file_exists dest_dir) then (
      log#linfo (lazy ("Creating missing directory: " ^ dest_dir));
      (* Create a directory with *default* permissions *)
      Core_unix.mkdir_p dest_dir)
  in

  (* Create the directory, if necessary *)
  mkdir_if full_dest_dir;

  let needs_clauses_module =
    !Config.extract_decreases_clauses
    && not (PureUtils.FunLoopIdSet.is_empty rec_functions)
  in

  (* Copy the "Primitives" file, if necessary *)
  let _ =
    (* Retrieve the executable's directory *)
    let exe_dir = Filename.dirname Sys.argv.(0) in
    let primitives_src_dest =
      match Config.backend () with
      | FStar -> Some ("/backends/fstar/Primitives.fst", "Primitives.fst")
      | Coq -> Some ("/backends/coq/Primitives.v", "Primitives.v")
      | Lean -> None
      | HOL4 -> None
    in
    match primitives_src_dest with
    | None -> ()
    | Some (primitives_src, primitives_destname) -> (
        try
          (* TODO: stop copying the primitives file *)
          let src = open_in (exe_dir ^ primitives_src) in
          let tgt_filename = Filename.concat dest_dir primitives_destname in
          let tgt = open_out tgt_filename in
          (* Very annoying: I couldn't find a "cp" function in the OCaml libraries... *)
          try
            while true do
              (* We copy line by line *)
              let line = input_line src in
              Printf.fprintf tgt "%s\n" line
            done
          with End_of_file ->
            close_in src;
            close_out tgt;
            log#linfo (lazy ("Copied:    " ^ tgt_filename))
        with Sys_error _ ->
          [%warn_opt_span] None
            ("Could not copy the primitives file: " ^ primitives_src
           ^ ".\nYou will have to copy it/set up the project by hand."))
  in

  (* Extract the file(s) *)
  let import_prefix =
    match !Config.subdir with
    | None -> crate_name
    | Some subdir ->
        String.concat module_delimiter
          (List.filter (fun s -> s <> "") (String.split_on_char '/' subdir))
  in
  let import_prefix = import_prefix ^ module_delimiter in
  [%ltrace "import_prefix: " ^ import_prefix];

  (* File extension for the "regular" modules *)
  let ext =
    match Config.backend () with
    | FStar -> ".fst"
    | Coq -> ".v"
    | Lean -> ".lean"
    | HOL4 -> "Script.sml"
  in
  (* File extension for the opaque module *)
  let opaque_ext =
    match Config.backend () with
    | FStar -> ".fsti"
    | Coq -> ".v"
    | Lean -> ".lean"
    | HOL4 -> "Script.sml"
  in

  (* Check if there are opaque types and functions (we need this to know whether
     we need to generate interface files, etc.) *)
  let has_opaque_types, has_opaque_funs =
    crate_has_opaque_non_builtin_decls ctx true
  in
  let has_opaque = has_opaque_types || has_opaque_funs in

  (* Extract one or several files, depending on the configuration *)
  (if !Config.split_files then (
     let base_gen_config =
       {
         extract_types = false;
         extract_decreases_clauses = !Config.extract_decreases_clauses;
         extract_template_decreases_clauses = false;
         extract_fun_decls = false;
         extract_trait_decls = false;
         extract_trait_impls = false;
         extract_transparent = true;
         extract_opaque = false;
         extract_globals = false;
         interface = false;
       }
     in

     (*
      * Extract the types
      *)
     (* If there are opaque types, we extract in an interface *)
     (* Extract the opaque type declarations, if needed *)
     let opaque_types_module =
       if has_opaque_types then (
         (* For F*, we generate an .fsti, and let the user write the .fst.
            For the other backends, we generate a template file as a model
            for the file the user has to provide. *)
         let module_suffix, opaque_imported_suffix, custom_msg =
           match Config.backend () with
           | FStar ->
               ("TypesExternal", "TypesExternal", ": external type declarations")
           | HOL4 | Coq | Lean ->
               ( (* The name of the file we generate *)
                 "TypesExternal_Template",
                 (* The name of the file that will be imported by the Types
                    module, and that the user has to provide. *)
                 "TypesExternal",
                 ": external types.\n\
                  -- This is a template file: rename it to \"TypesExternal"
                 ^ ext ^ "\" and fill the holes." )
         in
         let opaque_filename =
           extract_filebasename ^ module_suffix ^ opaque_ext
         in
         let opaque_module = import_prefix ^ module_suffix in
         let opaque_imported_module = import_prefix ^ opaque_imported_suffix in
         let opaque_config =
           {
             base_gen_config with
             extract_opaque = true;
             extract_transparent = false;
             extract_types = true;
             extract_trait_decls = true;
             interface = true;
           }
         in
         let file_info =
           {
             filename = opaque_filename;
             namespace;
             in_namespace = false;
             open_namespace = false;
             crate_name;
             rust_module_name = crate.name;
             module_name = opaque_module;
             custom_msg;
             custom_imports = [];
             custom_includes = [];
             noncomputable = false;
           }
         in
         extract_file opaque_config ctx file_info;
         (* Return the additional dependencies *)
         [ opaque_imported_module ])
       else []
     in

     (* Extract the non opaque types *)
     let types_filename_ext =
       match Config.backend () with
       | FStar -> ".fst"
       | Coq -> ".v"
       | Lean -> ".lean"
       | HOL4 -> "Script.sml"
     in
     let types_filename = extract_filebasename ^ "Types" ^ types_filename_ext in
     let types_module = import_prefix ^ "Types" in
     let types_config =
       {
         base_gen_config with
         extract_types = true;
         extract_trait_decls = true;
         extract_opaque = false;
         interface = has_opaque_types;
       }
     in
     let file_info =
       {
         filename = types_filename;
         namespace;
         in_namespace = true;
         open_namespace = false;
         crate_name;
         rust_module_name = crate.name;
         module_name = types_module;
         custom_msg = ": type definitions";
         custom_imports = [];
         custom_includes = opaque_types_module;
         noncomputable = false;
       }
     in
     extract_file types_config ctx file_info;

     (* Extract the template clauses *)
     (if needs_clauses_module && !Config.extract_template_decreases_clauses then
        let template_clauses_filename =
          extract_filebasename ^ "Clauses" ^ file_delimiter ^ "Template" ^ ext
        in
        let template_clauses_module =
          import_prefix ^ "Clauses" ^ module_delimiter ^ "Template"
        in
        let template_clauses_config =
          { base_gen_config with extract_template_decreases_clauses = true }
        in
        let file_info =
          {
            filename = template_clauses_filename;
            namespace;
            in_namespace = true;
            open_namespace = false;
            crate_name;
            rust_module_name = crate.name;
            module_name = template_clauses_module;
            custom_msg = ": templates for the decreases clauses";
            custom_imports = [ types_module ];
            custom_includes = [];
            noncomputable = false;
          }
        in
        extract_file template_clauses_config ctx file_info);

     (* Extract the opaque fun declarations, if needed *)
     let opaque_funs_module =
       if has_opaque_funs then (
         (* For F*, we generate an .fsti, and let the user write the .fst.
            For the other backends, we generate a template file as a model
            for the file the user has to provide. *)
         let module_suffix, opaque_imported_suffix, custom_msg =
           match Config.backend () with
           | FStar ->
               ( "FunsExternal",
                 "FunsExternal",
                 ": external function declarations" )
           | HOL4 | Coq | Lean ->
               ( (* The name of the file we generate *)
                 "FunsExternal_Template",
                 (* The name of the file that will be imported by the Funs
                    module, and that the user has to provide. *)
                 "FunsExternal",
                 ": external functions.\n\
                  -- This is a template file: rename it to \
                  \"FunsExternal.lean\" and fill the holes." )
         in
         let opaque_filename =
           extract_filebasename ^ module_suffix ^ opaque_ext
         in
         let opaque_module = import_prefix ^ module_suffix in
         let opaque_imported_module = import_prefix ^ opaque_imported_suffix in
         let opaque_config =
           {
             base_gen_config with
             extract_fun_decls = true;
             extract_trait_impls = true;
             extract_globals = true;
             extract_transparent = false;
             extract_opaque = true;
             interface = true;
           }
         in
         let file_info =
           {
             filename = opaque_filename;
             namespace;
             in_namespace = false;
             open_namespace = true;
             crate_name;
             rust_module_name = crate.name;
             module_name = opaque_module;
             custom_msg;
             custom_imports = [];
             custom_includes = [ types_module ];
             noncomputable = false;
           }
         in
         extract_file opaque_config ctx file_info;
         (* Return the additional dependencies *)
         [ opaque_imported_module ])
       else []
     in

     (* Extract the functions *)
     let fun_filename = extract_filebasename ^ "Funs" ^ ext in
     let fun_module = import_prefix ^ "Funs" in
     let fun_config =
       {
         base_gen_config with
         extract_fun_decls = true;
         extract_trait_impls = true;
         extract_globals = true;
       }
     in
     let clauses_module =
       if needs_clauses_module then
         let clauses_submodule =
           if Config.backend () = Lean then "Clauses" ^ module_delimiter else ""
         in
         [ import_prefix ^ clauses_submodule ^ "Clauses" ]
       else []
     in
     let file_info =
       {
         filename = fun_filename;
         namespace;
         in_namespace = true;
         open_namespace = false;
         crate_name;
         rust_module_name = crate.name;
         module_name = fun_module;
         custom_msg = ": function definitions";
         custom_imports = [];
         custom_includes =
           [ types_module ] @ opaque_funs_module @ clauses_module;
         noncomputable = has_opaque && not !Config.all_computable;
       }
     in
     if Config.backend () = Lean && !Config.lean_funs_chunk_bytes > 0 then
       let part i =
         let suffix = "FunsPart" ^ string_of_int i in
         (extract_filebasename ^ suffix ^ ext, import_prefix ^ suffix)
       in
       extract_file_chunked fun_config ctx file_info
         ~chunk_bytes:!Config.lean_funs_chunk_bytes ~part
     else extract_file fun_config ctx file_info)
   else
     let gen_config =
       {
         extract_types = true;
         extract_decreases_clauses = !Config.extract_decreases_clauses;
         extract_template_decreases_clauses =
           !Config.extract_template_decreases_clauses;
         extract_fun_decls = true;
         extract_trait_decls = true;
         extract_trait_impls = true;
         extract_transparent = true;
         extract_opaque = true;
         extract_globals = true;
         interface = false;
       }
     in
     let file_info =
       {
         filename = extract_filebasename ^ ext;
         namespace;
         in_namespace = true;
         open_namespace = false;
         crate_name;
         rust_module_name = crate.name;
         module_name = crate_name;
         custom_msg = "";
         custom_imports = [];
         custom_includes = [];
         noncomputable = has_opaque && not !Config.all_computable;
       }
     in
     extract_file gen_config ctx file_info);

  (* Separate compilation: reject the declarations already emitted elsewhere *)
  if SC.enabled () then SC.check_emitted ();

  (* Generate the build file *)
  match Config.backend () with
  | Coq | FStar | HOL4 ->
      ()
      (* Nothing to do - TODO: we might want to generate the _CoqProject file for Coq.
         But then we can't modify it if we want to add more files for the proofs
         for instance. But we might want to put the proofs elsewhere anyway.
         Remark: there is the same problem for Lean actually.
         Maybe generate it if the user asks for it?
      *)
  | Lean ->
      (*
       * Generate the library entry point, if the crate is split between
       * different files.
       *)
      if !Config.split_files && !Config.generate_lib_entry_point then (
        let filename = Filename.concat dest_dir (crate_name ^ ".lean") in
        let out = open_out filename in
        (* Write *)
        Printf.fprintf out "import %s.Funs\n" crate_name;
        (* Flush and close the file, log *)
        close_out out;
        log#linfo (lazy ("Generated: " ^ filename)));

      (*
       * Generate the lakefile.lean file, if the user asks for it
       *)
      if !Config.lean_gen_lakefile then (
        (* Open the file *)
        let filename = Filename.concat dest_dir "lakefile.lean" in
        let out = open_out filename in

        (* Generate the content *)
        Printf.fprintf out "import Lake\nopen Lake DSL\n\n";
        Printf.fprintf out "require mathlib from git\n";
        Printf.fprintf out
          "  \"https://github.com/leanprover-community/mathlib4.git\"\n\n";

        let package_name = StringUtils.to_snake_case crate_name in
        Printf.fprintf out "package «%s» {}\n\n" package_name;

        Printf.fprintf out "@[default_target]\nlean_lib «%s» {}\n" crate_name;

        (* No default target for now.
           Format would be:
           {[
             @[default_target]
               lean_exe «package_name» {
               root := `Main
             }
           ]}
        *)

        (* Flush and close the file *)
        close_out out;

        (* Logging *)
        log#linfo (lazy ("Generated: " ^ filename)))

(** Translate a crate and write the synthesized code to an output file. *)
let translate_crate (filename : string) (dest_dir : string)
    (subdir : string option) (crate : crate) (extracted_opaque : bool ref)
    (marked_ids : marked_ids) : unit =
  [%ltrace
    "- filename: " ^ filename ^ "\n- dest_dir: " ^ dest_dir ^ "\n- subdir: "
    ^ Print.option_to_string (fun x -> x) subdir];

  (* Translate the module to the pure AST *)
  let trans_ctx, trans_crate = translate_crate_to_pure crate marked_ids in

  extract_translated_crate filename dest_dir subdir crate trans_ctx trans_crate
    extracted_opaque
