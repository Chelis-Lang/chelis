(** This file implements various substitution utilities to instantiate types,
    function bodies, etc. *)

include Charon.Substitute
open Charon.TypesUtils
open Types
open Values
open LlbcAst

(** Erase the runtime regions of a type: free, static and body regions become
    [RErased]. A region bound by a binder of the type itself (a higher-ranked
    trait clause, a function pointer or item signature) quantifies that binder
    rather than denoting storage, so it is kept, as in
    [Charon.Substitute.erase_regions]: an erased type refreshed with new regions
    then keeps its binders closed instead of turning their variables into
    fresh free regions. The environment is the number of enclosing binders. *)
class ['self] erase_runtime_regions_visitor =
  object (_self : 'self)
    inherit [_] map_ty as super

    method! visit_binder visit_value depth x =
      super#visit_binder visit_value (depth + 1) x

    method! visit_region_binder visit_value depth x =
      super#visit_region_binder visit_value (depth + 1) x

    method! visit_region depth r =
      match r with
      | RVar (Bound (db, _)) when db < depth -> r
      | _ -> RErased
  end


(* Fails if the variable is bound *)
let expect_free_var span (var : 'id de_bruijn_var) : 'id =
  match var with
  | Bound _ -> [%craise_opt_span] span "Found unexpected bound variable"
  | Free id -> id

(** Generate fresh regions for region variables. *)
let fresh_regions_with_substs (region_vars : RegionId.id list)
    (fresh_region_id : unit -> region_id) : RegionId.id -> RegionId.id =
  (* Map each region var id to a fresh region *)
  let rid_map =
    RegionId.Map.of_list
      (List.map (fun var -> (var, fresh_region_id ())) region_vars)
  in
  fun id -> RegionId.Map.find id rid_map

let make_subst_from_generics file line span (params : generic_params)
    (args : generic_args) (tr_self : trait_ref_kind) : subst =
  try subst_free_vars (make_sb_subst_from_generics params args tr_self)
  with Invalid_argument _ when not !Config.fail_hard ->
    Errors.internal_error_opt_span file line span

let fresh_regions_with_substs_from_vars (region_vars : region_param list)
    (fresh_region_id : unit -> region_id) : RegionId.id -> RegionId.id =
  fresh_regions_with_substs
    (List.map (fun (r : region_param) -> r.index) region_vars)
    fresh_region_id

(** Substitute a function signature, together with the regions hierarchy
    associated to that signature. *)
let substitute_signature (asubst : RegionGroupId.id -> AbsId.id)
    (r_id_subst : RegionId.id -> RegionId.id) (ty_sb_subst : TypeVarId.id -> ty)
    (cg_sb_subst : ConstGenericVarId.id -> constant_expr_kind)
    (tr_sb_subst : TraitClauseId.id -> trait_ref_kind)
    (tr_sb_self : trait_ref_kind) (sg : bound_fun_sig)
    (regions_hierarchy : region_var_groups) : inst_fun_sig =
  let { item_binder_params = generics; item_binder_value = sg } = sg in
  let r_sb_subst id = RVar (Free (r_id_subst id)) in
  let subst =
    subst_free_vars
      { r_sb_subst; ty_sb_subst; cg_sb_subst; tr_sb_subst; tr_sb_self }
  in
  let inputs = List.map (ty_substitute subst) sg.inputs in
  let output = ty_substitute subst sg.output in
  let subst_abs_region_group (rg : region_var_group) : abs_region_group =
    let id = asubst rg.id in
    let regions = List.map r_id_subst rg.regions in
    let parents = List.map asubst rg.parents in
    ({ id; regions; parents } : abs_region_group)
  in
  let abs_regions_hierarchy =
    List.map subst_abs_region_group regions_hierarchy
  in
  let subst_region_group (rg : region_var_group) : region_var_group =
    let id = rg.id in
    let regions = List.map r_id_subst rg.regions in
    let parents = rg.parents in
    ({ id; regions; parents } : region_var_group)
  in
  let regions_hierarchy = List.map subst_region_group regions_hierarchy in
  let trait_type_constraints =
    List.map
      (st_substitute_visitor#visit_region_binder
         trait_type_constraint_substitute subst)
      generics.trait_type_constraints
  in
  {
    inputs;
    output;
    regions_hierarchy;
    abs_regions_hierarchy;
    trait_type_constraints;
(* ```ocaml *)
    declaration_regions = generics.regions;
    declaration_region_subst = subst.r_subst;
    body_region_map = RegionId.Map.empty;
(* ``` *)
    metadata_bindings = RegionId.Map.empty;
  }

type id_subst = {
  r_subst : RegionId.id -> RegionId.id;
  ty_subst : TypeVarId.id -> TypeVarId.id;
  cg_subst : ConstGenericVarId.id -> ConstGenericVarId.id;
  ssubst : SymbolicValueId.id -> SymbolicValueId.id;
  bsubst : BorrowId.id -> BorrowId.id;
  sbsubst : SharedBorrowId.id -> SharedBorrowId.id;
  asubst : AbsId.id -> AbsId.id;
}

let empty_id_subst =
  {
    r_subst = (fun x -> x);
    ty_subst = (fun x -> x);
    cg_subst = (fun x -> x);
    ssubst = (fun x -> x);
    bsubst = (fun x -> x);
    sbsubst = (fun x -> x);
    asubst = (fun x -> x);
  }

let no_abs_id_subst span =
  let asubst _ = [%craise] span "Unreachable" in
  { empty_id_subst with asubst }

(** Memoization is only valid for pure substitutions. Its tables belong to this
    operation, so mapped types and expressions do not outlive the traversal. *)
(*
```ocaml
*)
(* ```ocaml *)
let rec subst_ids_visitor ?(memoize = false) ?metadata_policy ?runtime_owned
    ?projection_regions ?metadata_rsubst ?stored_metadata_types
    (subst : id_subst) =
(* ``` *)

  let evalues = if memoize then Some (EvalueTbl.create 16) else None in
  (* Equal rebuilt annotations have identical substitutions. Identity keys
     hash them into one bucket and make long context rewrites quadratic. *)
  let types = if memoize then Some (TyCache.create 16) else None in
  let ancestry_cache = if memoize then Some (ref []) else None in

  (*
```ocaml
  *)
  let declarations =
    Option.map
      (fun r_subst ->
        subst_ids_visitor ~memoize ?metadata_policy ?projection_regions
          { subst with r_subst })
      metadata_rsubst
  in
  (*
```
  *)

  object (self : 'self)
    inherit [_] map_env as super
    method! visit_type_var_id _ id = subst.ty_subst id
    method! visit_const_generic_var_id _ id = subst.cg_subst id
    method! visit_region_id _ rid = subst.r_subst rid
    (* ```ocaml *)
    method! visit_region_id_set _ regions =
      RegionId.Set.map subst.r_subst regions
    (* ``` *)
    (* ```ocaml *)
(*
```ocaml
*)
    method! visit_physical_input_ancestry env ancestry =
      let map_hierarchy region hierarchy =
        let rec members original =
          match original with
          | [] -> original
          | id :: rest ->
              let mapped = region id in
              let mapped_rest = members rest in
              if mapped = id && mapped_rest == rest then original
              else mapped :: mapped_rest in
        let rec groups original =
          match original with
          | [] -> original
          | (group : region_var_group) :: rest ->
              let regions = members group.regions in
              let mapped_rest = groups rest in
              if regions == group.regions && mapped_rest == rest then original
              else
                let mapped = if regions == group.regions then group
                  else { group with regions } in
                mapped :: mapped_rest in
        groups hierarchy in
      let map () =
        let source_region id =
          match declarations with
          | None -> self#visit_region_id env id
          | Some declarations -> declarations#visit_region_id env id in
        let source_hierarchy = map_hierarchy source_region ancestry.source_hierarchy in
        let body_hierarchy = map_hierarchy (self#visit_region_id env) ancestry.body_hierarchy in
        if source_hierarchy == ancestry.source_hierarchy
           && body_hierarchy == ancestry.body_hierarchy then ancestry
        else { source_hierarchy; body_hierarchy } in
      match ancestry_cache with
      | None -> map ()
      | Some cache ->
          let rec find = function
            | (original, mapped) :: _ when original == ancestry -> mapped
            | _ :: rest -> find rest
            | [] ->
                let mapped = map () in
                cache := (ancestry, mapped) :: !cache;
                mapped in
          find !cache
(*
```
*)
    method private visit_selected_regions env original mapped selected =
      match projection_regions with
      | None -> self#visit_region_id_set env selected
      | Some transport -> transport original mapped selected

    method private visit_retained_symbolic_value env value =
      match declarations with
      | None -> self#visit_symbolic_value env value
      | Some declarations -> declarations#visit_symbolic_value env value


    method private visit_retained_origin_role env role =
      match declarations with
      | None -> self#visit_carrier_origin_role env role
      | Some declarations -> declarations#visit_carrier_origin_role env role




    method! visit_carrier_origin env origin =
      let original_root = self#visit_retained_symbolic_value env origin.original_root in

      (* ```ocaml *)
      let original_mask =
        try
          self#visit_selected_regions env origin.original_root.sv_ty
            original_root.sv_ty origin.original_mask
        with error ->
          let backtrace = Printexc.get_raw_backtrace () in
          Printf.eprintf
            "Carrier origin stored-selection failure: coordinate-role=original_mask source-owner=%s original-root=%s mapped-root=%s transport-root=%s\n%!"
            (AbsId.to_string origin.source_owner)
            (SymbolicValueId.to_string origin.original_root.sv_id)
            (SymbolicValueId.to_string original_root.sv_id)
            (SymbolicValueId.to_string origin.transport_root.sv_id);
          let raw = show_carrier_origin origin in
          let shown = Stdlib.min 65536 (String.length raw) in
          Printf.eprintf "raw carrier origin bytes=%d shown=%d:\n%s\n%!"
            (String.length raw) shown (String.sub raw 0 shown);
          Printexc.raise_with_backtrace error backtrace
      in
      (* ``` *)
      {
        source_owner = self#visit_abs_id env origin.source_owner;
        region_group = self#visit_region_group_id env origin.region_group;
        (*
```ocaml
        *)
        source_role = self#visit_retained_origin_role env origin.source_role;
        (*
```
        *)
        original_root;
        (*
```ocaml
        *)
        transport_root = self#visit_symbolic_value env origin.transport_root;
        (*
```
        *)
        original_mask;
      }
    method! visit_abs_regions _ regions =
      match runtime_owned with
      | None -> { owned = RegionId.Set.map subst.r_subst regions.owned }
      | Some _ -> regions
    (* ``` *)

    (* ``` *)
    method! visit_region _ = function
      (* ```ocaml *)
      | RVar (Free rid) -> RVar (Free (subst.r_subst rid))

      (* ``` *)
      | region -> region
    method! visit_TFnPtr env signature =
      match metadata_policy with
      | Some _ -> TFnPtr signature
      | None -> super#visit_TFnPtr env signature
    method! visit_TFnDef env function_ref =
      match metadata_policy with
      | Some _ -> TFnDef function_ref
      | None -> super#visit_TFnDef env function_ref
    method! visit_TAdt env tref =
      match metadata_policy, tref.id with
      | Some metadata_policy, TAdtId id ->
          let metadata_regions, metadata_type_params = metadata_policy in
          let generics = tref.generics in
          let regions =
            RegionId.mapi
              (fun index original ->
                metadata_regions id index original (self#visit_region env original))
              tref.generics.regions
          in
          let types =
            TypeVarId.mapi
              (fun index original ->
                if metadata_type_params id index then original
                else
                  match declarations, stored_metadata_types with
                  | Some declarations, Some stored when stored id index ->
                      declarations#visit_ty env original
                  | _ -> self#visit_ty env original)

              generics.types
          in
          TAdt { tref with generics =
            { regions;
              types;
              const_generics = List.map (self#visit_constant_expr env) generics.const_generics;
              trait_refs = List.map (self#visit_trait_ref env) generics.trait_refs } }
      | _ -> super#visit_TAdt env tref
    method! visit_borrow_id _ bid = subst.bsubst bid
    method! visit_shared_borrow_id _ sid = subst.sbsubst sid
    method! visit_loan_id _ bid = subst.bsubst bid
    method! visit_symbolic_value_id _ id = subst.ssubst id

(*
```ocaml
*)
    method! visit_carrier_return_source env source =
      match source with
      | SymbolicCarrierReturn route ->
          SymbolicCarrierReturn (self#visit_input_return_route env route)
      | PhysicalCarrierReturn receipts ->
          PhysicalCarrierReturn
            (List.map (self#visit_input_physical_return env) receipts)

    method! visit_carrier_coordinate_transport env transport =
      let receiver = self#visit_symbolic_proj env transport.receiver in
      let current = self#visit_symbolic_value env transport.current in
      { receiver;
        receiver_regions = self#visit_selected_regions env
          transport.receiver.proj_ty receiver.proj_ty transport.receiver_regions;
        current;
        current_regions = self#visit_selected_regions env
          transport.current.sv_ty current.sv_ty transport.current_regions;
        return_source = self#visit_carrier_return_source env transport.return_source }
(*
```
*)

    (* ```ocaml *)
    method! visit_abs env abs =
      match runtime_owned with
      | None ->
          let call_scopes =
            List.map (self#visit_call_scope env) abs.call_scopes
          in
          let mapped = super#visit_abs env abs in
(*
```ocaml
*)
          { mapped with call_scopes }
(*
```
*)
      | Some runtime_owned ->
          let owned = runtime_owned abs in
          (* Owned keys do not cover unowned live occurrences. Visit the
             complete abstraction before any identity decision. *)
          let call_scopes =
            List.map (self#visit_call_scope env) abs.call_scopes
          in
          let mapped = super#visit_abs env abs in
          let regions =
            if RegionId.Set.equal owned mapped.regions.owned then mapped.regions
            else { owned }
          in
          if call_scopes == mapped.call_scopes && regions == mapped.regions
          then mapped
(*
```ocaml
*)
          else { mapped with call_scopes; regions }
(*
```
*)
    (* ``` *)


    method! visit_call_endpoint_witnesses env witnesses =
      let roots =
        List.map
          (fun (from_input, original, actual) ->
            (from_input, self#visit_tavalue env original,


             self#visit_tavalue env actual))
          witnesses.roots
      in
      let map_expansion = function
        | SeLiteral value -> SeLiteral (self#visit_literal env value)
        | SeAdt (variant, fields) ->
            SeAdt (variant, List.map (self#visit_symbolic_value env) fields)


        | SeMutRef (bid, child) ->
            SeMutRef (self#visit_borrow_id env bid,
                      self#visit_symbolic_value env child)


        | SeSharedRef (bid, child) ->
            SeSharedRef (self#visit_borrow_id env bid,
                         self#visit_symbolic_value env child)


      in
      let expansions =
        List.map
          (fun (source, expansion) ->
            (self#visit_symbolic_value env source, map_expansion expansion))


          witnesses.expansions
      in
      let projections =
        List.map
          (* ```ocaml *)
          (fun (source, mask, actual) ->
            let projected = self#visit_symbolic_proj env source in
            let actual = self#visit_tavalue env actual in
            (projected,
             self#visit_selected_regions env source.proj_ty projected.proj_ty mask,
             actual))
          (* ``` *)
          witnesses.projections
      in
      let carrier_origins = List.map (self#visit_carrier_origin env) witnesses.carrier_origins in
      let input_correspondences =
        List.map (self#visit_call_input_correspondence env) witnesses.input_correspondences in


(* ```ocaml *)
      let carrier_conversions =
        List.map (self#visit_input_carrier_conversion env) witnesses.carrier_conversions in
(* ``` *)
      let physical_returns =
        List.map (self#visit_input_physical_return env) witnesses.physical_returns in
      (*
```ocaml
      *)
(* ```ocaml *)
      { roots; expansions; projections; carrier_origins; input_correspondences; carrier_conversions; physical_returns;
(* ``` *)
(*
```ocaml
*)
        return_routes = List.map (self#visit_input_return_route env) witnesses.return_routes;
(*
```
*)
        parent_carriers =
          List.map
            (fun (branch, parent, mask, regions, producer) ->
              (branch, self#visit_borrow_id env parent, mask,
               self#visit_region_id_set env regions,
               self#visit_tevalue env producer))
            witnesses.parent_carriers }
      (*
```
      *)

    method! visit_ECallEndpoints env witnesses body =
      ECallEndpoints (self#visit_call_endpoint_witnesses env witnesses,
                      self#visit_tevalue env body)
(*
```ocaml
*)
    method! visit_symbolic_pending_slot env slot =
      let proj_ty = self#visit_ty env slot.proj_ty in
      { slot with
        root_sv_id = self#visit_symbolic_value_id env slot.root_sv_id;
        proj_ty;
        proj_regions = self#visit_selected_regions env slot.proj_ty
          proj_ty slot.proj_regions }
(*
```
*)

    method! visit_msymbolic_value_id _ id = subst.ssubst id

    (* ```ocaml *)
    method! visit_mconsumed_symb env (source : mconsumed_symb) : mconsumed_symb =
      match declarations with
      | Some declarations -> declarations#visit_mconsumed_symb env source
      | None ->
      let proj_ty = self#visit_ty env source.proj_ty in
      {
        sv_id = self#visit_symbolic_value_id env source.sv_id;
        proj_ty;
        proj_regions = self#visit_selected_regions env source.proj_ty
          proj_ty source.proj_regions;
      }
    (* ``` *)

    method! visit_mgiven_back_symb env (source : mgiven_back_symb) : mgiven_back_symb =
      match declarations with
      | Some declarations -> declarations#visit_mgiven_back_symb env source
      | None ->
      {
        sv_id = self#visit_symbolic_value_id env source.sv_id;
        proj_ty = self#visit_ty env source.proj_ty;
      }

    method! visit_ty env ty =
      match types with
      | None -> super#visit_ty env ty
      | Some types -> (
          match TyCache.find_opt types ty with
          | Some mapped -> if TyCacheKey.equal ty mapped then ty else mapped
          | None ->
              let mapped = super#visit_ty env ty in
              let mapped = if TyCacheKey.equal ty mapped then ty else mapped in
              TyCache.add types ty mapped;
              mapped)

    method! visit_tevalue env value =
      match evalues with
      | None -> super#visit_tevalue env value
      | Some evalues -> (
          match EvalueTbl.find_opt evalues value with
          | Some mapped -> mapped
          | None ->
              let mapped = super#visit_tevalue env value in
              EvalueTbl.add evalues value mapped;
              mapped)

    (** We *do* visit meta-values *)
    method! visit_msymbolic_value env sv =
      match declarations with
      | Some declarations -> declarations#visit_symbolic_value env sv
      | None -> self#visit_symbolic_value env sv

    (** We *do* visit meta-values *)
    method! visit_mvalue env v =
      match declarations with
      | Some declarations -> declarations#visit_tvalue env v
      | None -> self#visit_tvalue env v

    method! visit_abs_id _ id = subst.asubst id
  end
(*
```
*)

let tvalue_subst_ids (subst : id_subst) (v : tvalue) : tvalue =
  let vis = subst_ids_visitor subst in
  vis#visit_tvalue () v

let ty_subst_ids (subst : id_subst) (x : ty) : ty =
  let vis = subst_ids_visitor subst in
  vis#visit_ty () x

let tvalue_subst_rids (span : Meta.span) (r_subst : RegionId.id -> RegionId.id)
    (v : tvalue) : tvalue =
  tvalue_subst_ids { (no_abs_id_subst span) with r_subst } v

let ty_subst_rids (span : Meta.span) (r_subst : RegionId.id -> RegionId.id)
    (x : ty) : ty =
  ty_subst_ids { (no_abs_id_subst span) with r_subst } x

let abs_subst_ids (subst : id_subst) (x : abs) : abs =
  let vis = subst_ids_visitor subst in
  vis#visit_abs () x

let env_subst_ids (subst : id_subst) (x : env) : env =
  let vis = subst_ids_visitor subst in
  vis#visit_env () x

let tavalue_subst_rids (span : Meta.span) (r_subst : RegionId.id -> RegionId.id)
    (x : tavalue) : tavalue =
  let vis = subst_ids_visitor { (no_abs_id_subst span) with r_subst } in
  vis#visit_tavalue () x

(*
```ocaml
*)
(* ```ocaml *)
let env_subst_rids ?runtime_owned ?metadata_rsubst ?stored_metadata_types
    projection_regions metadata_policy
    (r_subst : RegionId.id -> RegionId.id) (x : env) : env =

  (* Runtime ownership substitution retains callable metadata and complete
     declared nominal metadata arguments. The policy uses operation-scoped
     region and type-parameter predicates. *)
  let vis =
    subst_ids_visitor ~memoize:true ~metadata_policy
      ~projection_regions ?runtime_owned ?metadata_rsubst ?stored_metadata_types

      { empty_id_subst with r_subst }
  in
  vis#visit_env () x
(* ``` *)

(*
```
*)

let generic_args_of_params_erase_regions (span : Meta.span option)
    (generics : generic_params) : generic_args =
  let generics = Charon.TypesUtils.generic_args_of_params span generics in
  (* The declaration's free regions become runtime regions, but locally
     quantified regions still refer to their higher-ranked binder. *)
  let regions = List.map (fun _ -> RErased) generics.regions in
  let erase =
    object
      inherit [_] map_ty
      method! visit_region_param _ param = param

      method! visit_region _ =
        function
        | RVar (Bound _) as region -> region
        | _ -> RErased
    end
  in
  let trait_refs = List.map (erase#visit_trait_ref ()) generics.trait_refs in
  { generics with regions; trait_refs }
