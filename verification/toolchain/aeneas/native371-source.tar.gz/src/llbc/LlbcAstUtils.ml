open Types
open LlbcAst
include Charon.LlbcAstUtils
open Collections

(** Lean lowers function/implementation recursion through recursive method
    functions. Other mixed declaration kinds remain unsupported. *)
let mixed_declaration_group_is_supported (group : mixed_declaration_group) :
    bool =
  Config.backend () = Config.Lean
  &&
  match group with
  | RecGroup ids ->
      List.for_all
        (function
          | IdFun _ | IdTraitImpl _ -> true
          | _ -> false)
        ids
  | NonRecGroup _ -> false

module FunIdOrderedType : OrderedType with type t = fun_id = struct
  type t = fun_id

  let compare = compare_fun_id
  let to_string = show_fun_id
  let pp_t = pp_fun_id
  let show_t = show_fun_id
end

module FunIdMap = Collections.MakeMap (FunIdOrderedType)
module FunIdSet = Collections.MakeSet (FunIdOrderedType)

let body_as_body = Charon.LlbcAstUtils.body_as_structured

let body_as_body_exn file line f =
  match body_as_body f with
  | Some body -> body
  | None -> Errors.craise_opt_span file line None "Not a LLBC body"

let body_is_known (b : body) : bool = Option.is_some (body_as_body b)

let lookup_fun_sig (fun_id : fun_id) (fun_decls : fun_decl FunDeclId.Map.t) :
    bound_fun_sig =
  match fun_id with
  | FRegular id ->
      let fun_decl = FunDeclId.Map.find id fun_decls in
      bound_fun_sig_of_decl fun_decl
  | FBuiltin aid -> Builtin.get_builtin_fun_sig aid

(** Return the opaque declarations found in the crate, which are also *not
    builtin*.

    [filter_builtin]: if [true], do not consider as opaque the external
    definitions that we will map to definitions from the standard library.

    Remark: the list of functions also contains the list of opaque global
    bodies. *)
let crate_get_opaque_non_builtin_decls (k : crate) (filter_builtin : bool)
    (type_decls : type_decl TypeDeclId.Map.t)
    (fun_decls : fun_decl FunDeclId.Map.t) : type_decl list * fun_decl list =
  let open ExtractBuiltin in
  let ctx = Charon.NameMatcher.ctx_from_crate k in
  let is_opaque_fun (d : fun_decl) : bool =
    (not (body_is_known d.body))
    (* Something to pay attention to: we must ignore trait method *declarations*
       (which don't have a body but must not be considered as opaque) *)
    && (match d.src with
       | TraitDeclItem (_, _, false) -> false
       | _ -> true)
    && ((not filter_builtin)
       || (not
             (NameMatcherMap.mem ctx d.item_meta.name (builtin_globals_map ())))
          && not (mem_fun ctx d.def_id d.item_meta.name)
       )
  in
  let is_opaque_type (d : type_decl) : bool =
    d.kind = Opaque
    && ((not filter_builtin)
       || not (NameMatcherMap.mem ctx d.item_meta.name (builtin_types_map ())))
  in
  (* Note that by checking the function bodies we also the globals *)
  ( List.filter is_opaque_type (TypeDeclId.Map.values type_decls),
    List.filter is_opaque_fun (FunDeclId.Map.values fun_decls) )

(** Return true if the crate contains opaque declarations, ignoring the builtin
    definitions. *)
let crate_has_opaque_non_builtin_decls (k : crate) (filter_builtin : bool)
    (type_decls : type_decl TypeDeclId.Map.t)
    (fun_decls : fun_decl FunDeclId.Map.t) : bool =
  crate_get_opaque_non_builtin_decls k filter_builtin type_decls fun_decls
  <> ([], [])

let name_to_pattern (span : Meta.span option) (ctx : Charon.NameMatcher.ctx)
    (c : Charon.NameMatcher.to_pat_config) (n : name) =
  if !Config.fail_hard then Charon.NameMatcher.name_to_pattern ctx c n
  else
    try Charon.NameMatcher.name_to_pattern ctx c n
    with Not_found ->
      [%craise_opt_span] span
        "Could not convert the name to a pattern because of missing \
         definition(s)"

let name_with_crate_to_pattern_string (span : Meta.span option)
    (crate : LlbcAst.crate) (n : Types.name) : string =
  let mctx = Charon.NameMatcher.ctx_from_crate crate in
  let c : Charon.NameMatcher.to_pat_config =
    {
      tgt = TkPattern;
      use_trait_decl_refs = Config.match_patterns_with_trait_decl_refs;
    }
  in
  let pat = name_to_pattern span mctx c n in
  Charon.NameMatcher.pattern_to_string { tgt = TkPattern } pat

let name_with_generics_to_pattern (span : Meta.span option)
    (ctx : Charon.NameMatcher.ctx) (c : Charon.NameMatcher.to_pat_config)
    (params : generic_params) (n : Charon.Types.name) (args : generic_args) =
  if !Config.fail_hard then
    Charon.NameMatcher.name_with_generics_to_pattern ctx c params n args
  else
    try Charon.NameMatcher.name_with_generics_to_pattern ctx c params n args
    with Not_found ->
      [%craise_opt_span] span
        "Could not convert the name to a pattern because of missing \
         definition(s)"

let name_with_generics_crate_to_pattern_string (span : Meta.span option)
    (crate : LlbcAst.crate) (n : Types.name) (params : Types.generic_params)
    (args : Types.generic_args) : string =
  let mctx = Charon.NameMatcher.ctx_from_crate crate in
  let c : Charon.NameMatcher.to_pat_config =
    {
      tgt = TkPattern;
      use_trait_decl_refs = Config.match_patterns_with_trait_decl_refs;
    }
  in
  let pat = name_with_generics_to_pattern span mctx c params n args in
  Charon.NameMatcher.pattern_to_string { tgt = TkPattern } pat

(** The name pattern of a declaration in a message which reports that its
    translation failed ([pattern] computes it). Reporting an error must not
    raise: when the pattern cannot be computed, we describe why instead. This
    happens when the pattern is itself the subject of an error (a [CFailure],
    which is already reported), and when the name matcher raises, e.g., on the
    names of the partially monomorphized instances of trait implementations,
    for which its round-trip check ([name_with_generics_to_pattern]) fails. *)
let name_pattern_for_error_message (pattern : unit -> string) : string =
  try pattern () with
  | (Out_of_memory | Sys.Break) as e -> raise e
  | Errors.CFailure _ ->
      "(could not compute the name pattern due to a different error)"
  | e ->
      "(could not compute the name pattern: uncaught exception "
      ^ Printexc.exn_slot_name e ^ ")"

let trait_impl_with_crate_to_pattern_string (span : Meta.span option)
    (crate : LlbcAst.crate) (trait_decl : LlbcAst.trait_decl)
    (trait_impl : LlbcAst.trait_impl) : string =
  name_with_generics_crate_to_pattern_string span crate
    trait_decl.item_meta.name trait_decl.generics trait_impl.impl_trait.generics

(** Compute the size of a function body - we count the number of statements and
    blocks *)
let compute_body_size (b : body) : int =
  let size = ref 0 in
  let incr () = size := !size + 1 in
  let visitor =
    object
      inherit [_] iter_statement as super

      method! visit_statement env st =
        incr ();
        super#visit_statement env st

      method! visit_block env st =
        incr ();
        super#visit_block env st
    end
  in
  let () =
    match b with
    | StructuredBody body -> visitor#visit_block () body.body
    | _ -> ()
  in
  !size

(** Compute the size of a function - we count the number of statements and
    blocks *)
let compute_fun_decl_size (f : fun_decl) : int = compute_body_size f.body
