open Types
open LlbcAst
open Substitute
open Charon.TypesUtils
open SCC

let log = Logging.types_analysis_log

type subtype_info = {
  under_borrow : bool;  (** Are we inside a borrow? *)
  under_mut_borrow : bool;  (** Are we inside a mut borrow? *)
}
[@@deriving show]

(** See {!type_decl_info} *)
type type_param_info = subtype_info [@@deriving show]

type expl_info = subtype_info [@@deriving show]

type type_borrows_info = {
  contains_static : bool;
      (** Does the type (transitively) contain a static borrow? *)
  contains_borrow : bool;  (** Does the type (transitively) contain a borrow? *)
  contains_mut_borrow : bool;
      (** Does the type (transitively) contain a mutable borrow? *)
  contains_nested_borrows : bool;
      (** Does the type (transitively) contain nested borrows? *)
  contains_borrow_under_mut : bool;
  contains_nested_mut : bool;
}
[@@deriving show]

(** Generic definition *)
type 'p g_type_info = {
  borrows_info : type_borrows_info;
      (** Various informations about the borrows *)
  param_infos : 'p;  (** Gives information about the type parameters *)
  is_tuple_struct : bool;
      (** If true, it means the type is a record that we should extract as a
          tuple. This field is only valid for type declarations. *)
  stored_regions : RegionId.Set.t;
      (** Declaration region indices that contribute stored references. *)
  stored_type_params : TypeVarId.Set.t;
      (** Declaration type indices that contribute stored values. *)
  metadata_regions : RegionId.Set.t;
      (** Declaration region indices needed by preserved field metadata. *)
  metadata_type_params : TypeVarId.Set.t;
      (** Declaration type indices needed by preserved field metadata. *)
  mut_regions : RegionId.Set.t;
      (** The set of regions used in mutable borrows *)
  unfrozen_mut_regions : RegionId.Set.t;
      (** The subset of [mut_regions] used in mutable borrows which are not
          below a shared borrow: the mutable borrows below a shared borrow are
          frozen, and a value of the type gives nothing back to them (e.g., the
          region ['n] of [struct View<'a, 'n> { c: &'a Checker<'n> }] where
          [Checker<'n>] holds a [&'n mut u32], or of a closure capturing
          [&'a Checker<'n>]). For the opaque types: [mut_regions]. *)
  is_rec : bool;  (** This field is only meaningful for type definitions *)
}
[@@deriving show]

(** Information about a type definition. *)
type type_decl_info = type_param_info list g_type_info [@@deriving show]

(** Information about a type. *)
type ty_info = type_borrows_info [@@deriving show]

(** Helper definition.

    Allows us to factorize code: {!analyze_full_ty} is used both to analyze type
    definitions and types. *)
type partial_type_info = type_param_info list option g_type_info
[@@deriving show]

type type_infos = type_decl_info TypeDeclId.Map.t [@@deriving show]

let expl_info_init = { under_borrow = false; under_mut_borrow = false }

let type_borrows_info_init : type_borrows_info =
  {
    contains_static = false;
    contains_borrow = false;
    contains_mut_borrow = false;
    contains_nested_borrows = false;
    contains_borrow_under_mut = false;
    contains_nested_mut = false;
  }

(** Return true if a type declaration is a structure with unnamed fields.

    Note that there are two possibilities:
    - either all the fields are named
    - or none of the fields are named *)
let type_decl_is_tuple_struct (x : type_decl) : bool =
  match x.kind with
  | Struct fields -> List.for_all (fun f -> f.field_name = None) fields
  | _ -> false

let initialize_g_type_info (is_tuple_struct : bool) ~(is_rec : bool)
    ~(stored_regions : RegionId.Set.t) ~(mut_regions : RegionId.Set.t)
    ~(stored_type_params : TypeVarId.Set.t)
    ~(metadata_regions : RegionId.Set.t)
    ~(metadata_type_params : TypeVarId.Set.t) (param_infos : 'p) :
    'p g_type_info =
  {
    borrows_info = type_borrows_info_init;
    is_tuple_struct;
    param_infos;
    mut_regions;
    unfrozen_mut_regions = mut_regions;
    is_rec;
    stored_regions;
    stored_type_params;
    metadata_regions;
    metadata_type_params;
  }

exception FoundRegion

(** Visit only generic arguments that contribute runtime storage. *)
let iter_stored_generic_args (infos : type_infos)
    (visit_region : region -> unit) (visit_ty : ty -> unit)
    (tref : type_decl_ref) : unit =
  match tref.id with
  | TTuple | TBuiltin _ ->
      List.iter visit_region tref.generics.regions;
      List.iter visit_ty tref.generics.types
  | TAdtId id ->
      let info = TypeDeclId.Map.find id infos in
      RegionId.iteri
        (fun index r ->
          if RegionId.Set.mem index info.stored_regions then visit_region r)
        tref.generics.regions;
      TypeVarId.iteri
        (fun index ty ->
          if TypeVarId.Set.mem index info.stored_type_params then visit_ty ty)
        tref.generics.types

(** A storage visitor does not inspect signature or witness metadata. *)
class ['self] iter_storage_ty (infos : type_infos) =
  object (self : 'self)
    inherit [_] iter_ty as super
    method! visit_TFnDef _ _ = ()
    method! visit_TFnPtr _ _ = ()
    method! visit_trait_ref _ _ = ()

    method! visit_TAdt env tref =
      iter_stored_generic_args infos (self#visit_region env)
        (self#visit_ty env) tref

    method! visit_TDynTrait env tr =
      if Config.type_analysis_ignore_dyn then ()
      else super#visit_TDynTrait env tr
  end

(** Whether a type holds storage regions, including erased regions.
    Trait references and callable signatures are not storage.
    Trait objects follow the configured type analysis policy. *)
let ty_has_storage_regions (infos : type_infos) (ty : ty) : bool =
  let visitor =
    object
      inherit [_] iter_storage_ty infos
      method! visit_region _ _ = raise FoundRegion
    end
  in
  try
    visitor#visit_ty () ty;
    false
  with FoundRegion -> true


let initialize_type_decl_info (span : Meta.span option) (crate : crate)
    ~(is_rec : bool) (def : type_decl) : type_decl_info =
  let param_info = { under_borrow = false; under_mut_borrow = false } in
  let param_infos = List.map (fun _ -> param_info) def.generics.types in
  let is_tuple_struct =
    !Config.use_tuple_structs && (not is_rec) && type_decl_is_tuple_struct def
  in
  let stored_regions, stored_type_params =
    match def.kind with
    | Opaque ->
        ( RegionId.Set.of_list
            (List.map (fun (p : region_param) -> p.index) def.generics.regions),
          TypeVarId.Set.of_list
            (List.map (fun (p : type_param) -> p.index) def.generics.types) )
    | _ -> (RegionId.Set.empty, TypeVarId.Set.empty)
  in
  let name_matcher_ctx : Charon.NameMatcher.ctx =
    Charon.NameMatcher.ctx_from_crate crate
  in
  (* We have some specialized knowledge of some library types; we don't
     have any more custom treatment than this, and these types can be modeled
     suitably in the backend libraries, rather than special-casing for them all the
     way. *)
  let get_builtin_info () : Pure.builtin_type_info option =
    let open ExtractBuiltin in
    NameMatcherMap.find_opt name_matcher_ctx def.item_meta.name
      (builtin_types_map ())
  in
  let name_to_string () =
    let env = Charon.Print.crate_to_fmt_env crate in
    Charon.Print.name_to_string env def.item_meta.name
  in

  (* We initialize the mutable regions differently depending on whether the
     type is opaque or not *)
  let mut_regions =
    match def.kind with
    | Opaque -> (
        (* Try to lookup the builtin information, if there is *)
        match get_builtin_info () with
        | Some info ->
            (* *)
            let len = List.length def.generics.regions in
            if List.for_all (fun i -> i < len) info.mut_regions then
              RegionId.Set.of_list
                (List.map
                   (fun i ->
                     (Collections.List.nth def.generics.regions i).index)
                   info.mut_regions)
            else (
              [%warn_opt_span] span
                ("Found invalid builtin information for a type declaration: \
                  the indices used for the mutable regions are out of bounds.\n\
                  Type: " ^ name_to_string ());
              RegionId.Set.empty)
        | None ->
            (* No builtin information: print a warning if the type contains region
               parameters *)
            if def.generics.regions <> [] then
              [%warn_opt_span] span
                ("Found an unknown type declaration with region parameters: as \
                  we can not know whether the regions are used in mutable \
                  borrows or not the extracted code may be incorrect.\n\
                  Type: " ^ name_to_string ());
            if Config.opaque_types_have_mut_regions_by_default then
              RegionId.Set.of_list
                (List.map
                   (fun (r : region_param) -> r.index)
                   def.generics.regions)
            else RegionId.Set.empty)
    | _ -> RegionId.Set.empty
  in
  initialize_g_type_info is_tuple_struct ~is_rec ~stored_regions ~mut_regions
    ~stored_type_params ~metadata_regions:stored_regions
    ~metadata_type_params:stored_type_params param_infos

let type_decl_info_to_partial_type_info (info : type_decl_info) :
    partial_type_info =
  {
    borrows_info = info.borrows_info;
    is_tuple_struct = info.is_tuple_struct;
    param_infos = Some info.param_infos;
    mut_regions = info.mut_regions;
    unfrozen_mut_regions = info.unfrozen_mut_regions;
    is_rec = info.is_rec;
    stored_regions = info.stored_regions;
    stored_type_params = info.stored_type_params;
    metadata_regions = info.metadata_regions;
    metadata_type_params = info.metadata_type_params;
  }

let partial_type_info_to_type_decl_info (info : partial_type_info) :
    type_decl_info =
  {
    borrows_info = info.borrows_info;
    is_tuple_struct = info.is_tuple_struct;
    param_infos = Option.get info.param_infos;
    mut_regions = info.mut_regions;
    unfrozen_mut_regions = info.unfrozen_mut_regions;
    is_rec = info.is_rec;
    stored_regions = info.stored_regions;
    stored_type_params = info.stored_type_params;
    metadata_regions = info.metadata_regions;
    metadata_type_params = info.metadata_type_params;
  }

let partial_type_info_to_ty_info (info : partial_type_info) : ty_info =
  info.borrows_info

let rec trait_instance_id_reducible (span : Meta.span option)
    (id : trait_ref_kind) : bool =
  match id with
  | BuiltinOrAuto _ | TraitImpl _ -> true
  | Self | Clause _ -> false
  | ParentClause (tref, _) -> trait_instance_id_reducible span tref.kind
  | Dyn -> [%craise_opt_span] span "Unreachable"
  | ItemClause _ | UnknownTrait _ -> false

let analyze_full_ty (span : Meta.span option) (updated : bool ref)
    (infos : type_infos) (ty_info : partial_type_info) (ty : ty) :
    partial_type_info =
  (* Small utility *)
  let check_update_bool (original : bool) (nv : bool) : bool =
    if nv && not original then (
      updated := true;
      nv)
    else original
  in
  let r_is_static (r : region) : bool = r = RStatic in
  let add_stored_region (info : partial_type_info) r =
    match r with
    | RVar (Free rid) when not (RegionId.Set.mem rid info.stored_regions) ->
        updated := true;
        { info with stored_regions = RegionId.Set.add rid info.stored_regions }
    | _ -> info
  in
  let add_stored_type_param (info : partial_type_info) id =
    if TypeVarId.Set.mem id info.stored_type_params then info
    else (
      updated := true;
      { info with
        stored_type_params = TypeVarId.Set.add id info.stored_type_params })
  in
  let update_mut_regions_with_rid mut_regions rid =
    if RegionId.Set.mem rid mut_regions then mut_regions
    else (
      updated := true;
      RegionId.Set.add rid mut_regions)
  in
  let update_mut_regions mut_regions mut_region =
    match mut_region with
    | RStatic | RVar (Bound _) | RErased ->
        mut_regions (* We can have bound vars because of arrows *)
    | RVar (Free rid) -> update_mut_regions_with_rid mut_regions rid
    | RBody _ -> [%craise_opt_span] span "unsupported: Body region"
  in

  (* Update a partial_type_info, while registering if we actually performed an update *)
  let update_ty_info (ty_info : partial_type_info) (mut_region : region option)
      (ty_b_info : type_borrows_info) : partial_type_info =
    let original = ty_info.borrows_info in
    let contains_static =
      check_update_bool original.contains_static ty_b_info.contains_static
    in
    let contains_borrow =
      check_update_bool original.contains_borrow ty_b_info.contains_borrow
    in
    let contains_mut_borrow =
      check_update_bool original.contains_mut_borrow
        ty_b_info.contains_mut_borrow
    in
    let contains_nested_borrows =
      check_update_bool original.contains_nested_borrows
        ty_b_info.contains_nested_borrows
    in
    let contains_borrow_under_mut =
      check_update_bool original.contains_borrow_under_mut
        ty_b_info.contains_borrow_under_mut
    in
    let contains_nested_mut =
      check_update_bool original.contains_nested_mut
        ty_b_info.contains_nested_mut
    in
    let updated_borrows_info =
      {
        contains_static;
        contains_borrow;
        contains_mut_borrow;
        contains_nested_borrows;
        contains_borrow_under_mut;
        contains_nested_mut;
      }
    in
    (* Add the region *)
    let updated_mut_regions =
      match mut_region with
      | None -> ty_info.mut_regions
      | Some mut_region -> update_mut_regions ty_info.mut_regions mut_region
    in
    {
      ty_info with
      borrows_info = updated_borrows_info;
      mut_regions = updated_mut_regions;
    }
  in

  (* Register a region used in a mutable borrow which is not below a shared
     borrow (see [unfrozen_mut_regions]) *)
  let add_unfrozen_region (ty_info : partial_type_info) (r : region) :
      partial_type_info =
    match r with
    | RVar (Free rid)
      when not (RegionId.Set.mem rid ty_info.unfrozen_mut_regions) ->
        updated := true;
        {
          ty_info with
          unfrozen_mut_regions =
            RegionId.Set.add rid ty_info.unfrozen_mut_regions;
        }
    | _ -> ty_info
  in

  (* The recursive function which explores the type. [frozen]: whether we are
     below a shared borrow. *)
  let rec analyze (span : Meta.span option) (expl_info : expl_info)
      ~(frozen : bool) (ty_info : partial_type_info) (ty : ty) :
      partial_type_info =
    match ty with
    | TLiteral _ | TNever | TDynTrait _ -> ty_info
    | TTraitType (tref, _) ->
        (* TODO: normalize the trait types.
           For now we only emit a warning because it makes some tests fail. *)
        [%cassert_warn_opt_span] span
          (not (trait_instance_id_reducible span tref.kind))
          "Found an unexpected trait impl associated type which was not \
           inlined while analyzing a type. This is a case we currently do not \
           handle in all generality. As a result,the consumed/given back \
           values computed for the generated backward functions may be \
           incorrect.";
        let info = ref ty_info in
        let dependencies =
          object
            inherit [_] iter_ty
            method! visit_region _ r = info := add_stored_region !info r
            method! visit_TVar _ = function
              | Free id ->
                  info := analyze span expl_info ~frozen !info (TVar (Free id))
              | Bound _ -> ()
          end
        in
        dependencies#visit_trait_ref () tref;
        !info
    | TVar var_id -> (
        (* Update the information for the proper parameter, if necessary *)
        match ty_info.param_infos with
        | None -> ty_info
        | Some param_infos ->
            let param_info =
              TypeVarId.nth param_infos (expect_free_var span var_id)
            in
            (* Set [under_borrow] *)
            let under_borrow =
              check_update_bool param_info.under_borrow expl_info.under_borrow
            in
            (* Set [under_nested_borrows] *)
            let under_mut_borrow =
              check_update_bool param_info.under_mut_borrow
                expl_info.under_mut_borrow
            in
            (* Update param_info *)
            let param_info = { under_borrow; under_mut_borrow } in
            let param_infos =
              TypeVarId.update_nth param_infos
                (expect_free_var span var_id)
                param_info
            in
            let param_infos = Some param_infos in
            let ty_info =
              add_stored_type_param ty_info (expect_free_var span var_id)
            in
            { ty_info with param_infos })
    | TRef (r, rty, rkind) ->
        let ty_info = add_stored_region ty_info r in
        (* Update the type info *)
        let contains_static = r_is_static r in
        let contains_borrow = true in
        let is_mut, region =
          match rkind with
          | RMut -> (true, Some r)
          | RShared -> (false, None)
        in
        let contains_mut_borrow = is_mut in
        let contains_nested_borrows = expl_info.under_borrow in
        let contains_borrow_under_mut = expl_info.under_mut_borrow in
        let contains_nested_mut = expl_info.under_mut_borrow && is_mut in
        let ty_b_info =
          {
            contains_static;
            contains_borrow;
            contains_mut_borrow;
            contains_nested_borrows;
            contains_borrow_under_mut;
            contains_nested_mut;
          }
        in
        let ty_info = update_ty_info ty_info region ty_b_info in
        let ty_info =
          if is_mut && not frozen then add_unfrozen_region ty_info r
          else ty_info
        in
        (* Update the exploration info *)
        let expl_info =
          {
            under_borrow = true;
            under_mut_borrow = expl_info.under_mut_borrow || rkind = RMut;
          }
        in
        (* Continue exploring *)
        analyze span expl_info ~frozen:(frozen || rkind = RShared) ty_info rty
    | TRawPtr (rty, _) ->
        (* TODO: not sure what to do here *)
        analyze span expl_info ~frozen ty_info rty
    | TArray (ty, _) | TSlice ty ->
        (* Nothing to update: just explore the type parameters *)
        analyze span expl_info ~frozen ty_info ty
    | TAdt { id = TTuple | TBuiltin (TBox | TStr); generics } ->
        (* Nothing to update: just explore the type parameters *)
        List.fold_left
          (fun ty_info ty -> analyze span expl_info ~frozen ty_info ty)
          ty_info generics.types
    | TAdt { id = TAdtId adt_id; generics } ->
        (* Lookup the information for this type definition *)
        let adt_info =
          [%silent_unwrap_opt_span] span (TypeDeclId.Map.find_opt adt_id infos)
        in
        (* Update the type info with the information from the adt *)
        let ty_info = update_ty_info ty_info None adt_info.borrows_info in
        (* Only stored arguments contribute region and static evidence. *)
        let rec analyze_regions index found_static ty_info = function
          | [] -> (found_static, ty_info)
          | r :: rest ->
              if RegionId.Set.mem (RegionId.of_int index)
                   adt_info.stored_regions then
                analyze_regions (index + 1) (found_static || r_is_static r)
                  (add_stored_region ty_info r) rest
              else analyze_regions (index + 1) found_static ty_info rest
        in
        let found_static, ty_info =
          analyze_regions 0 false ty_info generics.regions
        in
        let borrows_info = ty_info.borrows_info in
        let borrows_info =
          {
            borrows_info with
            contains_borrow =
              check_update_bool borrows_info.contains_borrow
                (not (RegionId.Set.is_empty adt_info.stored_regions));
            contains_static =
              check_update_bool borrows_info.contains_static found_static;
          }
        in
        let ty_info = { ty_info with borrows_info } in
        (* For every instantiated type parameter: update the exploration info
           then explore the type *)
        let analyze_param ty_info param_info ty =
              (* Update the type info *)
              (* Below: we use only the information which we learn only
               * by taking the type parameter into account. *)
              let contains_static = false in
              let contains_borrow = param_info.under_borrow in
              let contains_mut_borrow = param_info.under_mut_borrow in
              (* The borrows of the ADT at the positions of the parameter are
                 nested in the borrows which the ADT is under only if the
                 instantiation brings its own regions: a borrow of a value of
                 a type without regions (e.g., a type variable, whose values
                 hold no borrows the body can see) is nested in the enclosing
                 borrows exactly like the borrows of the region parameters of
                 the ADT (see below), which do not count as nested borrows.
                 The borrows inside an instantiation with regions are found by
                 exploring it below. *)
              let param_nests = ty_has_storage_regions infos ty in
              let contains_nested_borrows =
                param_nests && expl_info.under_borrow && param_info.under_borrow
              in
              let contains_borrow_under_mut =
                param_nests && expl_info.under_mut_borrow
                && param_info.under_borrow
              in
              let contains_nested_mut =
                param_nests && expl_info.under_mut_borrow
                && param_info.under_mut_borrow
              in
              let ty_b_info =
                {
                  contains_static;
                  contains_borrow;
                  contains_mut_borrow;
                  contains_nested_borrows;
                  contains_borrow_under_mut;
                  contains_nested_mut;
                }
              in
              let ty_info = update_ty_info ty_info None ty_b_info in
              (* Update the exploration info *)
              let expl_info =
                {
                  under_borrow =
                    expl_info.under_borrow || param_info.under_borrow;
                  under_mut_borrow =
                    expl_info.under_mut_borrow || param_info.under_mut_borrow;
                }
              in
              (* Continue exploring (the parameters of the ADT below its shared
                 borrows count as unfrozen: an over-approximation) *)
              analyze span expl_info ~frozen ty_info ty
        in
        let rec analyze_params index ty_info param_infos tys =
          match (param_infos, tys) with
          | [], [] -> ty_info
          | param_info :: params, ty :: tys ->
              let ty_info =
                if TypeVarId.Set.mem (TypeVarId.of_int index)
                     adt_info.stored_type_params then
                  analyze_param ty_info param_info ty
                else ty_info
              in
              analyze_params (index + 1) ty_info params tys
          | _ -> invalid_arg "List.combine"
        in
        let ty_info =
          analyze_params 0 ty_info adt_info.param_infos generics.types
        in
        (* For every region parameter: do the same *)
        let mut_regions =
          List.fold_left
            (fun mut_regions (adt_rid, r) ->
              (* Check if the region is a variable and is used for mutable borrows *)
              match r with
              | RStatic | RVar (Bound _) | RErased -> mut_regions
              (* We can have bound vars because of arrows, and erased regions
                 when analyzing types appearing in function bodies *)
              | RVar (Free rid) ->
                  if RegionId.Set.mem adt_rid adt_info.mut_regions then
                    update_mut_regions_with_rid mut_regions rid
                  else mut_regions
              | RBody _ -> [%craise_opt_span] span "unsupported: Body region")
            ty_info.mut_regions
            (RegionId.mapi (fun adt_rid r -> (adt_rid, r)) generics.regions)
        in
        let ty_info = { ty_info with mut_regions } in
        (* The unfrozen ones *)
        if frozen then ty_info
        else
          List.fold_left
            (fun ty_info (adt_rid, r) ->
              if RegionId.Set.mem adt_rid adt_info.unfrozen_mut_regions then
                add_unfrozen_region ty_info r
              else ty_info)
            ty_info
            (RegionId.mapi (fun adt_rid r -> (adt_rid, r)) generics.regions)
    | TFnPtr _ | TFnDef _ ->
        (* Function pointers and items store no signature borrows.
           Signature borrows belong to call arguments and results. *)
        ty_info
    | TPtrMetadata _ -> [%craise_opt_span] span "unsupported: PtrMetadata"
    | TError _ ->
        [%craise_opt_span] span "Found type error in the output of charon"
  in
  (* Explore *)
  analyze span expl_info_init ~frozen:false ty_info ty

let type_decl_is_opaque (d : type_decl) : bool =
  match d.kind with
  | Opaque -> true
  | _ -> false

(** Track declaration arguments needed by metadata in instantiated fields.
    Storage and metadata usage can overlap without adding runtime ownership. *)
let analyze_metadata_usage (updated : bool ref) (infos : type_infos)
    (info : partial_type_info) (ty : ty) : partial_type_info =
  let info = ref info in
  let visitor =
    object (self)
      inherit [_] iter_ty as super

      method! visit_region metadata = function
        | RVar (Free id)
          when metadata
               && not (RegionId.Set.mem id (!info).metadata_regions) ->
            updated := true;
            info := { !info with
              metadata_regions = RegionId.Set.add id (!info).metadata_regions }
        | _ -> ()

      method! visit_TVar metadata = function
        | Free id
          when metadata
               && not (TypeVarId.Set.mem id (!info).metadata_type_params) ->
            updated := true;
            info := { !info with
              metadata_type_params =
                TypeVarId.Set.add id (!info).metadata_type_params }
        | _ -> ()

      method! visit_TFnPtr _ signature = super#visit_TFnPtr true signature
      method! visit_TFnDef _ fn = super#visit_TFnDef true fn
      method! visit_trait_ref _ tr = super#visit_trait_ref true tr
      method! visit_TDynTrait _ tr = super#visit_TDynTrait true tr

      method! visit_TAdt metadata tref =
        if metadata then super#visit_TAdt true tref
        else begin
          match tref.id with
          | TTuple | TBuiltin _ -> super#visit_TAdt false tref
          | TAdtId id ->
              let child = TypeDeclId.Map.find id infos in
              RegionId.iteri
                (fun index r ->
                  self#visit_region
                    (not (RegionId.Set.mem index child.stored_regions)
                     || RegionId.Set.mem index child.metadata_regions) r)
                tref.generics.regions;
              TypeVarId.iteri
                (fun index ty ->
                  self#visit_ty
                    (not (TypeVarId.Set.mem index child.stored_type_params)
                     || TypeVarId.Set.mem index child.metadata_type_params) ty)
                tref.generics.types;
              List.iter (self#visit_constant_expr true)
                tref.generics.const_generics;
              List.iter (self#visit_trait_ref true) tref.generics.trait_refs
        end
    end
  in
  visitor#visit_ty false ty;
  !info

let fold_type_decl_field_types (def : type_decl) f init =
  let fold_fields =
    List.fold_left (fun acc (field : field) -> f acc field.field_ty)
  in
  match def.kind with
  | Struct fields -> fold_fields init fields
  | Enum variants ->
      List.fold_left (fun acc variant -> fold_fields acc variant.fields)
        init variants
  | Alias _ ->
      [%craise] def.item_meta.span
        "type aliases should have been removed earlier"
  | Union _ -> [%craise] def.item_meta.span "unions are not supported"
  | Opaque | TDeclError _ -> [%craise] def.item_meta.span "unreachable"

let analyze_type_decl (updated : bool ref) (infos : type_infos)
    (def : type_decl) : type_infos =
  (* We analyze the type declaration only if it is not opaque (we need to explore
   * the variants of the ADTs *)
  if type_decl_is_opaque def then infos
  else
    (* Explore the types and accumulate information *)
    let type_decl_info = TypeDeclId.Map.find def.def_id infos in
    let type_decl_info = type_decl_info_to_partial_type_info type_decl_info in
    let type_decl_info =
      fold_type_decl_field_types def
        (analyze_full_ty (Some def.item_meta.span) updated infos) type_decl_info
    in
    let type_decl_info = partial_type_info_to_type_decl_info type_decl_info in
    (* Update the information for the type definition we explored *)
    let infos = TypeDeclId.Map.add def.def_id type_decl_info infos in
    (* Return *)
    infos

let analyze_type_decl_metadata (updated : bool ref) (infos : type_infos)
    (def : type_decl) : type_infos =
  if type_decl_is_opaque def then infos
  else
    let info =
      type_decl_info_to_partial_type_info
        (TypeDeclId.Map.find def.def_id infos)
    in
    let info =
      fold_type_decl_field_types def (analyze_metadata_usage updated infos)
        info
    in
    TypeDeclId.Map.add def.def_id (partial_type_info_to_type_decl_info info)
      infos

let analyze_type_declaration_group (span : Meta.span option) (crate : crate)
    (infos : type_infos) (decl : type_declaration_group) : type_infos =
  (* Collect the identifiers used in the declaration group *)
  let is_rec, ids =
    match decl with
    | NonRecGroup id -> (false, [ id ])
    | RecGroup ids -> (true, ids)
  in
  (* Retrieve the type definitions *)
  let decl_defs =
    List.map
      (fun id ->
        [%unwrap_opt_span] None
          (TypeDeclId.Map.find_opt id crate.type_decls)
          ("Internal error: please report an issue. Missing type declaration \
            of id: " ^ TypeDeclId.to_string id))
      ids
  in
  (* Initialize the type information for the current definitions *)
  let infos =
    List.fold_left
      (fun infos (def : type_decl) ->
        TypeDeclId.Map.add def.def_id
          (initialize_type_decl_info ~is_rec span crate def)
          infos)
      infos decl_defs
  in
  (* Analyze the types - this function simply computes a fixed-point *)
  let updated : bool ref = ref false in
  let rec analyze (infos : type_infos) : type_infos =
    let infos =
      List.fold_left
        (fun infos def -> analyze_type_decl updated infos def)
        infos decl_defs
    in
    if !updated then (
      updated := false;
      analyze infos)
    else infos
  in
  let infos = analyze infos in
  (* Storage usage must stabilize before preserved metadata uses its complement. *)
  let rec analyze_metadata infos =
    let infos =
      List.fold_left
        (fun infos def -> analyze_type_decl_metadata updated infos def)
        infos decl_defs
    in
    if !updated then (
      updated := false;
      analyze_metadata infos)
    else infos
  in
  analyze_metadata infos

let ty_replace_body_regions_with_free_regions (ty : ty) : ty =
  (* Find the maximum free region id *)
  let max = ref (-1) in
  let visitor =
    object
      inherit [_] iter_ty

      method! visit_RVar _ r =
        match r with
        | Bound _ -> ()
        | Free rid ->
            let rid = RegionId.to_int rid in
            max := if rid > !max then rid else !max
    end
  in
  visitor#visit_ty () ty;
  (* Create a generator *)
  let _, fresh_fid =
    RegionId.mk_stateful_generator_starting_at_id (RegionId.of_int (!max + 1))
  in
  (* Replace *)
  let map = ref RegionId.Map.empty in
  let visitor =
    object
      inherit [_] map_ty

      method! visit_RBody _ rid =
        match RegionId.Map.find_opt rid !map with
        | None ->
            let fid = fresh_fid () in
            map := RegionId.Map.add rid fid !map;
            RVar (Free rid)
        | Some rid -> RVar (Free rid)
    end
  in
  visitor#visit_ty () ty

(** Analyze a type to check whether it contains borrows, etc., provided we have
    already analyzed the type definitions in the context. *)
let analyze_ty (span : Meta.span option) (infos : type_infos) (ty : ty) :
    ty_info =
  [%ltrace "ty:\n" ^ show_ty ty];
  (* Replace the body regions with fresh free regions - this makes the
     implementation easier *)
  let ty = ty_replace_body_regions_with_free_regions ty in
  (* We don't use [updated] but need to give it as parameter *)
  let updated = ref false in
  (* We don't need to compute whether the type contains 'static or not *)
  let ty_info =
    initialize_g_type_info false ~is_rec:false
      ~stored_regions:RegionId.Set.empty ~mut_regions:RegionId.Set.empty
      ~stored_type_params:TypeVarId.Set.empty
      ~metadata_regions:RegionId.Set.empty
      ~metadata_type_params:TypeVarId.Set.empty None
  in
  let ty_info = analyze_full_ty span updated infos ty_info ty in
  (* Convert the ty_info *)
  partial_type_info_to_ty_info ty_info

(** Small helper *)
type region_kind = RkMarked | RkOutlives | RkStatic | RkDefault

(** Given a projection type and a set of regions [regions], compute the set of
    regions which outlive [regions] in this type.

    Note that we ignore the static regions: static regions outlive all other
    regions so in theory we should include them in the outlive type, but in
    practice for now we handle them differently.

    Ex.: compute_outlive_ty {'a} (&'a mut T) = ∅ (the original projection
    projects the borrow, the set of outlive regions is empty)

    compute_outlive_ty {'a} (&'a mut &'b mut T) = {'b} (the original
    projection projects the *outer* borrow, the set of outlive regions
    contains the region of the *inner* borrow)

    compute_outlive_ty {'a} (&'a (Wrapper<'b, T>)) = {'b}
      where struct Wrapper<'a, T>(&'a mut T)
      (the outlive projection projects the region of the borrows inside the ADT) *)
let compute_outlive_proj_ty (span : Meta.span option)
    (type_decls : type_decl TypeDeclId.Map.t) (infos : type_infos)
    (regions : RegionId.Set.t) (ty : ty) : RegionId.Set.t =
  (* The method is as follows:

     1. We visit the type to  compute an "outlive" graph. From the outlive graph
     we can determine whether a region outlives static or a projected region. Note
     that computing this outlive graph is necessary to properly handle outlive
     constraints that are implied, for instance, by ADTs.

     2. From this graph, we then compute the set of regions which outlive a projected region
     and don't outlive 'static ('static has its own treatment).
  *)
  (* The graph contains every participating region, not just the projected ones.
     An edge r0 -> r1 means r0 outlives r1. Repeated occurrences contribute
     additional edges to the same node. *)
  let graph = ref RegionMap.empty in
  (* Predicate-only regions can prove edges but cannot own runtime storage. *)
  let storage_regions = ref RegionSet.empty in

  let add_region (r : region) : unit =
    (match r with
    | RErased -> [%craise_opt_span] span "Expected a type with regions"
    | RVar (Bound _) -> [%craise_opt_span] span "Not handled yet"
    | RBody _ -> [%craise_opt_span] span "unsupported: Body region"
    | RVar (Free _) | RStatic -> ());
    if not (RegionMap.mem r !graph) then
      graph := RegionMap.add r RegionSet.empty !graph
  in

  (* r0 outlives r1 *)
  let add_outlive (r0 : region) (r1 : region) =
    (* Substituted ADT constraints may introduce either endpoint. *)
    add_region r0;
    add_region r1;
    graph :=
      RegionMap.update r0
        (fun s ->
          let s = Option.get s in
          Some (RegionSet.add r1 s))
        !graph
  in

  (* [r] outlives the regions in [outlived] *)
  let add_outlives r (outlived : region list) =
    List.iter (fun r' -> add_outlive r r') outlived
  in

  (* Visit to compute the constraints *)
  let visitor =
    object (self)
      inherit [_] iter_ty as super

      (* Register all regions and the constraints contributed by this occurrence.
         Selection is used only when classifying the completed graph. *)
      method! visit_region outer r =
        add_region r;
        storage_regions := RegionSet.add r !storage_regions;
        add_outlives r outer

      method! visit_generic_args outer generics =
        (* Trait dictionaries are type evidence, not stored borrows. Keep them
           for substituting declaration predicates, but do not add their call
           lifetimes to the runtime storage graph. *)
        List.iter (self#visit_region outer) generics.regions;
        List.iter (self#visit_ty outer) generics.types;
        List.iter (self#visit_constant_expr outer) generics.const_generics

      method! visit_ty outer ty =
        match ty with
        | TAdt adt -> begin
            match adt.id with
            | TAdtId id ->
                (* Lookup the declaration and use the region constraints
                   to check which regions outlive the projected regions. *)
                let decl =
                  [%silent_unwrap_opt_span] span
                    (TypeDeclId.Map.find_opt id type_decls)
                in
                iter_stored_generic_args infos (self#visit_region outer)
                  (self#visit_ty outer) adt;

                (* Substitute in the constraints *)
                let subst =
                  Charon.Substitute.make_subst_from_generics decl.generics
                    adt.generics Self
                in
                let params =
                  Charon.Substitute.predicates_substitute subst decl.generics
                in

                (* Update the graph following the outlive *)
                let {
                  regions = _;
                  types = _;
                  const_generics = _;
                  trait_clauses = _;
                  regions_outlive;
                  types_outlive;
                  trait_type_constraints = _;
                } =
                  params
                in

                (* [r0] outlives [r1] *)
                let visit_region_register_outlive r0 r1 =
                  match r1 with
                  | RVar (Bound _) ->
                      [%craise_opt_span] span
                        "Bound regions are not handled yet"
                  | RVar (Free _) -> add_outlives r0 [ r1 ]
                  | RStatic | RErased | RBody _ ->
                      [%internal_error_opt_span] span
                in

                let outlive_visitor =
                  object
                    inherit [_] iter_storage_ty infos

                    (* [r1] outlives [r0] *)
                    method! visit_region r0 r1 =
                      visit_region_register_outlive r1 r0
                  end
                in

                (* Visit the region outlives constraints (the first region outlives the second)  *)
                List.iter
                  (fun (pred : (region, region) outlives_pred region_binder) ->
                    [%cassert_opt_span] span (pred.binder_regions = [])
                      "Bound regions are not supported yet";
                    let r0, r1 = pred.binder_value in
                    visit_region_register_outlive r0 r1)
                  regions_outlive;

                (* Visit the type outlives constraints (the type outlives the region) *)
                List.iter
                  (fun (pred : (ty, region) outlives_pred region_binder) ->
                    [%cassert_opt_span] span (pred.binder_regions = [])
                      "Bound regions are not supported yet";
                    let ty, r = pred.binder_value in
                    outlive_visitor#visit_ty r ty)
                  types_outlive
            | TTuple -> super#visit_ty outer ty
            | TBuiltin builtin_ty -> (
                match builtin_ty with
                | TBox | TStr -> super#visit_ty outer ty)
          end
        | TArray _ | TSlice _ -> super#visit_ty outer ty
        | TVar _ | TLiteral _ | TNever | TFnDef _ | TFnPtr _ -> ()
        | TRef (r, ref_ty, _) ->
            self#visit_region outer r;
            let outer = r :: outer in
            self#visit_ty outer ref_ty
        | TTraitType (tref, _) ->
            (* TODO: normalize the trait types.
               For now we only emit a warning because it makes some tests fail. *)
            [%cassert_warn_opt_span] span
              (not (trait_instance_id_reducible span tref.kind))
              "Found an unexpected trait impl associated type which was not \
               inlined while analyzing a type. This is a case we currently do \
               not handle in all generality. As a result,the consumed/given \
               back values computed for the generated backward functions may \
               be incorrect.";
            ()
        | TRawPtr _ | TDynTrait _ | TPtrMetadata _ | TError _ ->
            (* Don't know what to do *)
            [%craise_opt_span] span "Not handled yet"
    end
  in
  visitor#visit_ty [] ty;

  (* Classify SCCs by whether they contain a selected or static region, then
     propagate that information along the outlives edges. *)
  let module Scc = SCC.Make (RegionOrderedType) in
  let sccs = Scc.compute (RegionMap.bindings !graph) in

  (* Compute, for each SCC whether it contains a marked region or a static region *)
  let scc_kind =
    SccId.Map.map
      (fun ls ->
        let has_marked = ref false in
        let has_static = ref false in
        List.iter
          (fun r ->
            match r with
            | RVar (Free rid) ->
                if RegionId.Set.mem rid regions
                   && RegionSet.mem r !storage_regions then
                  has_marked := true
            | RStatic -> has_static := true
            | _ -> ())
          ls;
        let has_marked = !has_marked in
        let has_static = !has_static in
        [%cassert_opt_span] span
          ((not has_marked) || not has_static)
          "A projected region cannot outlive 'static";
        if has_marked then RkMarked
        else if has_static then RkStatic
        else RkDefault)
      sccs.sccs
  in

  (* Compute, for each SCC, whether it outlives an SCC containing a projected or static region *)
  let scc_kind_full = ref SccId.Map.empty in
  let rec compute_kind (id : SccId.id) : region_kind =
    match SccId.Map.find_opt id !scc_kind_full with
    | Some kind -> kind
    | None ->
        let deps_kinds =
          List.map compute_kind
            (SccId.Set.elements (SccId.Map.find id sccs.scc_deps))
        in
        let kind = SccId.Map.find id scc_kind in
        let has_marked = ref false in
        let has_static = ref false in
        let outlives_marked = ref false in
        List.iter
          (fun k ->
            match k with
            | RkMarked | RkOutlives -> outlives_marked := true
            | RkStatic -> has_static := true
            | RkDefault -> ())
          deps_kinds;
        begin
          match kind with
          | RkMarked -> has_marked := true
          | RkOutlives -> [%internal_error_opt_span] span
          | RkStatic -> has_static := true
          | RkDefault -> ()
        end;

        let has_marked = !has_marked in
        let has_static = !has_static in
        let outlives_marked = !outlives_marked in
        [%cassert_opt_span] span
          ((not has_marked) || not has_static)
          "A projected region cannot outlive 'static";
        let kind =
          if has_static then RkStatic
          else if has_marked then RkMarked
          else if outlives_marked then RkOutlives
          else RkDefault
        in
        scc_kind_full := SccId.Map.add id kind !scc_kind_full;
        kind
  in
  SccId.Map.iter
    (fun id _ ->
      let _ = compute_kind id in
      ())
    scc_kind;
  let scc_kind_full = !scc_kind_full in

  (* Compute the outlive regions *)
  let outlive_regions = ref RegionSet.empty in
  SccId.Map.iter
    (fun id component_regions ->
      let kind = SccId.Map.find id scc_kind_full in
      match kind with
      | RkMarked | RkOutlives ->
          (* An SCC may contain both selected and unselected regions. Its
             unselected members still outlive the selected members. *)
          List.iter
            (fun r ->
              match r with
              | RVar (Free rid)
                when not (RegionId.Set.mem rid regions)
                     && RegionSet.mem r !storage_regions ->
                  outlive_regions := RegionSet.add r !outlive_regions
              | RVar (Free _) -> ()
              | _ -> [%internal_error_opt_span] span)
            component_regions
      (* Static and static-equivalent regions have their own treatment; they
         must not be returned as ordinary outliving ownership positions. *)
      | RkStatic | RkDefault -> ())
    sccs.sccs;
  let outlive_regions =
    RegionId.Set.of_list
      (List.map
         (fun r ->
           match r with
           | RVar (Free rid) -> rid
           | _ -> [%internal_error_opt_span] span)
         (RegionSet.elements !outlive_regions))
  in

  [%sanity_check_opt_span] span
    (RegionId.Set.inter outlive_regions regions = RegionId.Set.empty);

  outlive_regions
