open Types
open Values
include Charon.LlbcAst

type bound_fun_sig = Charon.TypesUtils.bound_fun_sig
type abs_region_group = (RegionId.id, AbsId.id) g_region_group [@@deriving show]
type abs_region_groups = abs_region_group list [@@deriving show]

(** A function signature, after instantiation *)
type inst_fun_sig = {
  regions_hierarchy : region_var_groups;
      (** **WARNING**: the region ids in those groups should have been
          substituted with fresh regions. *)
  abs_regions_hierarchy : abs_region_groups;
  trait_type_constraints : trait_type_constraint region_binder list;
  inputs : rty list;
  output : rty;
(* ```ocaml *)
  declaration_regions : region_param list;
  declaration_region_subst : region_id de_bruijn_var -> region;
  body_region_map : region_id RegionId.Map.t;
(* ``` *)
      (** Reuse declaration substitution and operational input transport. *)
  metadata_bindings : region_metadata_bindings
      (** Execution types retain fresh stored regions.
          Erasure uses this separate source metadata view. *)
}
[@@deriving show]
