(** The items Charon started the translation from.

    Charon records its start-from options in the LLBC ([--start-from] and
    [--start-from-file], [--start-from-if-exists], [--start-from-attribute],
    [--start-from-pub]), but not the items they selected. We select them again
    on the translated crate, with Charon's own pattern language: the syntax of
    charon/src/name_matcher/parser.rs and the name matching of
    [Pattern::matches] and [StartFrom::matches] (charon/src/name_matcher/mod.rs,
    charon/src/options.rs). This is not the syntax of charon-ml's
    [NameMatcher]: Charon's canonical patterns (e.g. the roots of
    [CHARON_CALLGRAPH]) use impl elements [{impl a::T}] and
    [{impl a::Tr<u8> for a::T}], disambiguated identifiers [_#1] and
    [closure#12], and plain identifiers match every disambiguator.

    Charon resolves a pattern without disambiguators as a rustc path first,
    which follows re-exports; names do not. A pattern that designates an item
    through a re-export selects nothing here. *)

open Types
open LlbcAst

type pat_elem =
  | Ident of string * pat_ty list * int option
      (** A name, its generic arguments (for a trait, the implemented type
          first) and its disambiguator: [None] matches every disambiguator. *)
  | Impl of pattern
      (** An inherent impl (the pattern of its type) or a trait impl (the
          pattern of the trait, the implemented type as first argument). *)
  | Glob  (** [_] or [*] *)

and pat_ty =
  | Pat of pattern
  | Ref of ref_kind * pat_ty
  | Var  (** [@]: a type parameter *)

and pattern = pat_elem list

type t = Pattern of pattern | Attribute of string | Pub

(** The identifiers Charon gives to unnamed path elements ([SPECIAL_IDENTS]). *)
let special_idents =
  [
    "{use}";
    "{const}";
    "{promoted_const}";
    "{vtable}";
    "{vtable_method}";
    "{vtable_drop_shim}";
    "{vtable_drop_preshim}";
    "{vtable_method_preshim}";
  ]

(** A recoverable parse error: the next alternative is tried (nom's [Error]). *)
exception Backtrack

(** An unrecoverable parse error (nom's [Failure], after [cut]). *)
exception Cut

(** Parse a pattern like [Pattern::parse]; [None] if it is not one. *)
let parse (s : string) : pattern option =
  let n = String.length s in
  let pos = ref 0 in
  let tag (t : string) : unit =
    let l = String.length t in
    if !pos + l <= n && String.sub s !pos l = t then pos := !pos + l
    else raise Backtrack
  in
  let is_space c = c = ' ' || c = '\t' || c = '\n' || c = '\r' in
  let is_digit c = c >= '0' && c <= '9' in
  (* Rust's [char::is_alphanumeric] or ['_']; every non-ASCII byte is part of
     a UTF-8 character, which we accept like a letter. *)
  let is_ident c =
    (c >= 'a' && c <= 'z')
    || (c >= 'A' && c <= 'Z')
    || is_digit c || c = '_' || Char.code c >= 128
  in
  let take_while (f : char -> bool) : string =
    let start = !pos in
    while !pos < n && f s.[!pos] do
      incr pos
    done;
    String.sub s start (!pos - start)
  in
  let take_while1 f =
    let x = take_while f in
    if x = "" then raise Backtrack else x
  in
  let space0 () = ignore (take_while is_space) in
  let space1 () = ignore (take_while1 is_space) in
  let opt p =
    let start = !pos in
    try Some (p ())
    with Backtrack ->
      pos := start;
      None
  in
  let rec alt ps =
    match ps with
    | [] -> raise Backtrack
    | p :: ps -> (
        let start = !pos in
        try p ()
        with Backtrack ->
          pos := start;
          alt ps)
  in
  let cut p = try p () with Backtrack -> raise Cut in
  (* [separated_list0] *)
  let separated_list0 sep elem =
    match opt elem with
    | None -> []
    | Some first ->
        let rec rest acc =
          match
            opt (fun () ->
                sep ();
                elem ())
          with
          | Some e -> rest (e :: acc)
          | None -> List.rev acc
        in
        rest [ first ]
  in
  (* An optional [#N] suffix *)
  let disambiguator () : int option =
    opt (fun () ->
        tag "#";
        match int_of_string_opt (take_while1 is_digit) with
        | Some d -> d
        | None -> raise Backtrack)
  in
  let rec pattern () : pattern =
    separated_list0
      (fun () ->
        tag "::";
        space0 ())
      pat_elem
  and pat_elem () : pat_elem = alt [ glob; special_ident; impl_elem; simple_elem ]
  and glob () =
    tag "*";
    Glob
  and special_ident () =
    tag "{";
    let ident =
      take_while1 (fun c -> c = '_' || (is_ident c && Char.code c < 128))
    in
    tag "}";
    let name = "{" ^ ident ^ "}" in
    if not (List.mem name special_idents) then raise Backtrack;
    let d = disambiguator () in
    space0 ();
    Ident (name, [], d)
  and impl_elem () =
    tag "{";
    space0 ();
    cut (fun () ->
        ignore
          (opt (fun () ->
               tag "impl";
               cut space1));
        let pat = pattern () in
        space0 ();
        let for_ty =
          opt (fun () ->
              tag "for";
              space1 ();
              let ty = pat_ty () in
              space0 ();
              ty)
        in
        tag "}";
        match for_ty with
        | None -> Impl pat
        | Some ty -> (
            (* The implemented type is the first argument of the trait. *)
            match List.rev pat with
            | Ident (name, generics, d) :: rest ->
                Impl (List.rev (Ident (name, ty :: generics, d) :: rest))
            | _ -> raise Cut))
  and simple_elem () =
    let ident = take_while is_ident in
    let d = disambiguator () in
    space0 ();
    if ident = "_" && d = None then Glob
    else
      let generics =
        opt (fun () ->
            tag "<";
            space0 ();
            let args =
              separated_list0
                (fun () ->
                  tag ",";
                  space0 ())
                (fun () ->
                  let ty = pat_ty () in
                  space0 ();
                  ty)
            in
            tag ">";
            args)
      in
      Ident (ident, Option.value generics ~default:[], d)
  and pat_ty () : pat_ty =
    alt
      [
        (fun () ->
          tag "&";
          space0 ();
          let kind =
            match
              opt (fun () ->
                  tag "mut";
                  space0 ())
            with
            | Some () -> RMut
            | None -> RShared
          in
          Ref (kind, pat_ty ()));
        (fun () ->
          tag "@";
          Var);
        (fun () -> Pat (pattern ()));
      ]
  in
  try
    let p = pattern () in
    if !pos = n then Some p else None
  with Backtrack | Cut -> None

(** Split a start-from option into its patterns, at the commas outside
    brackets ([split_patterns] in charon/src/options.rs). *)
let split_patterns (list : string) : string list =
  let depth = ref 0 in
  let start = ref 0 in
  let parts = ref [] in
  String.iteri
    (fun i c ->
      match c with
      | '<' | '{' | '(' | '[' -> incr depth
      | '>' | '}' | ')' | ']' -> depth := max 0 (!depth - 1)
      | ',' when !depth = 0 ->
          parts := String.sub list !start (i - !start) :: !parts;
          start := i + 1
      | _ -> ())
    list;
  parts := String.sub list !start (String.length list - !start) :: !parts;
  List.filter (fun p -> p <> "") (List.rev_map String.trim !parts)

(** The start-from selections of the options Charon recorded, or [Error] with
    a pattern that does not parse. Without any, Charon starts from the local
    crate: [[]]. *)
let of_options (options : cli_options) : (t list, string) result =
  let patterns =
    List.concat_map split_patterns
      (options.start_from @ options.start_from_if_exists)
  in
  let rec parse_all acc = function
    | [] -> Ok (List.rev acc)
    | p :: ps -> (
        match parse p with
        | Some pat -> parse_all (Pattern pat :: acc) ps
        | None -> Error p)
  in
  Result.map
    (fun patterns ->
      patterns
      @ (match options.start_from_attribute with
        | Some attr -> [ Attribute attr ]
        | None -> [])
      @ if options.start_from_pub then [ Pub ] else [])
    (parse_all [] patterns)

let builtin_name (b : builtin_ty) : name =
  let path =
    match b with
    | TBox -> [ "alloc"; "boxed"; "Box" ]
    | TStr -> [ "Str" ]
  in
  List.map (fun s -> PeIdent (s, Disambiguator.zero)) path

(** [Pattern::matches_with_generics]: a pattern matches a name when it matches
    a prefix of it. The arguments are those of the last name element. *)
let rec matches_name (crate : crate) (p : pattern) (name : name)
    (args : generic_args option) : bool =
  let name, args =
    match List.rev name with
    | PeInstantiated binder :: rest -> (List.rev rest, Some binder.binder_value)
    | _ -> (name, args)
  in
  (* A pattern that starts with an impl matches it anywhere: from the
     rightmost impl of the name. *)
  let name =
    match p with
    | Impl _ :: _ ->
        let rec from_last_impl found = function
          | [] -> found
          | (PeImpl _ :: _ as rest) -> from_last_impl rest (List.tl rest)
          | _ :: rest -> from_last_impl found rest
        in
        from_last_impl name name
    | _ -> name
  in
  let rec go (p : pattern) (name : name) =
    match (p, name) with
    | [], _ -> true
    | _ :: _, [] -> false
    | [ pe ], [ ne ] -> matches_elem crate pe ne args
    | pe :: p, ne :: name -> matches_elem crate pe ne None && go p name
  in
  go p name

and matches_elem (crate : crate) (pe : pat_elem) (ne : path_elem)
    (args : generic_args option) : bool =
  match (pe, ne) with
  | Glob, _ -> true
  | Ident (pid, generics, d), PeIdent (id, ed) ->
      (pid = id || (pid = "crate" && id = crate.name))
      && (match d with
         | None -> true
         | Some d -> d = Disambiguator.to_int ed)
      && matches_generics crate generics args
  | Impl p, PeImpl (ImplElemTy ty) -> matches_ty crate p ty.binder_value
  | Impl p, PeImpl (ImplElemTrait impl_id) -> (
      match TraitImplId.Map.find_opt impl_id crate.trait_impls with
      | None -> false
      | Some timpl -> (
          match
            TraitDeclId.Map.find_opt timpl.impl_trait.id crate.trait_decls
          with
          | None -> false
          | Some tdecl ->
              let tname = tdecl.item_meta.name in
              (* An instantiated trait's name carries its arguments. *)
              let args =
                match List.rev tname with
                | PeInstantiated _ :: _ -> None
                | _ -> Some timpl.impl_trait.generics
              in
              matches_name crate p tname args))
  | _ -> false

and matches_generics (crate : crate) (pats : pat_ty list)
    (args : generic_args option) : bool =
  match args with
  | None -> true
  | Some _ when pats = [] -> true
  | Some g ->
      (* Patterns do not mention regions. Charon matched the patterns before
         [--lift-associated-types] appended type parameters to the items that
         need associated types (e.g. [Fn<Args>] became [Fn<Args, Output>]):
         then the pattern's types spell out a prefix of the types. *)
      let nconsts = List.length g.const_generics in
      let ntype_pats = List.length pats - nconsts in
      let ntypes = List.length g.types in
      (ntype_pats = ntypes
      || crate.options.lift_associated_types <> []
         && 0 <= ntype_pats && ntype_pats < ntypes)
      &&
      let type_pats, const_pats = Collections.List.split_at pats ntype_pats in
      let types, _ = Collections.List.split_at g.types ntype_pats in
      List.for_all2 (matches_pat_ty crate) type_pats types
      (* Charon only implements the glob pattern for constants. *)
      && List.for_all (fun pat -> pat = Pat [ Glob ]) const_pats

and matches_ty (crate : crate) (p : pattern) (ty : ty) : bool =
  p = [ Glob ]
  ||
  let ident s = [ PeIdent (s, Disambiguator.zero) ] in
  match ty with
  | TAdt { id = TAdtId id; generics } -> (
      match TypeDeclId.Map.find_opt id crate.type_decls with
      | Some d -> matches_name crate p d.item_meta.name (Some generics)
      | None -> false)
  | TAdt { id = TBuiltin b; generics } ->
      matches_name crate p (builtin_name b) (Some generics)
  | TAdt { id = TTuple; generics } -> (
      (* Tuples are [Tuple<A, B, ..>], with every argument spelled out. *)
      match p with
      | [ Ident ("Tuple", pats, None) ] ->
          List.length pats = List.length generics.types
          && List.for_all2 (matches_pat_ty crate) pats generics.types
      | _ -> false)
  | TArray (ty, len) ->
      matches_name crate p (ident "Array")
        (Some { TypesUtils.empty_generic_args with types = [ ty ]; const_generics = [ len ] })
  | TSlice ty ->
      matches_name crate p (ident "Slice")
        (Some { TypesUtils.empty_generic_args with types = [ ty ] })
  | TLiteral lit ->
      matches_name crate p
        (ident (Charon.Print.literal_type_to_string lit))
        (Some TypesUtils.empty_generic_args)
  | _ -> false

and matches_pat_ty (crate : crate) (pt : pat_ty) (ty : ty) : bool =
  match (pt, ty) with
  | Pat p, _ -> matches_ty crate p ty
  | Ref (kind, pt), TRef (_, ty, kind') -> kind = kind' && matches_pat_ty crate pt ty
  | Var, TVar _ -> true
  | _ -> false

(** [StartFrom::matches]: whether the selection selects the item (or an item
    it is named under). *)
let matches (crate : crate) (selection : t) (meta : item_meta) : bool =
  match selection with
  | Pattern p -> matches_name crate p meta.name None
  | Attribute attr ->
      List.exists
        (function
          | Meta.AttrUnknown raw -> raw.path = attr
          | _ -> false)
        meta.attr_info.attributes
  | Pub -> meta.attr_info.public
