(** Admission for the value-only collection models. Rust's collectors observe
    size_hint at allocation/specialization-dependent points. Erasing capacity is
    sound only when those calls are total and unobservable and the selected
    consumer has the same callback schedule as repeated next. This is a closed
    provenance check, not an effect guess based on a method's name or body.

    A generic function may collect from an iterator dictionary it receives as
    a trait clause. Its admission is deferred: the dictionary, expressed in the
    function's own generics, becomes an obligation of the function, and every
    call instantiates it and checks the instance (or defers it further to the
    caller's clauses). Only reviewed iterators, and crate iterators that define
    nothing but next and size_hint, ever discharge an obligation, so the
    next-driven models are used exactly where every native consumer path (next,
    fold, for_each, try_fold, size_hint) agrees with them: see [LawfulIterator]
    in the Lean library. A crate iterator's own size_hint leaves a collection
    obligation, its totality, stated in the generated Lean and listed by
    [-emit-collection-obligations] for a checked theorem to prove.

    A trait method's implementation is also called through generic
    dictionaries, which do not name it. Its obligations on the clauses of its
    implementation are therefore discharged wherever the implementation's
    dictionary is built; obligations on the method's own parameters could only
    be discharged at a call that names the implementation, so they are
    rejected (except for the reviewed collectors FromIterator::from_iter and
    Extend::extend, whose generic dispatch is itself rejected). Across chunks,
    the obligations of an earlier chunk's functions come from its manifest
    facts. *)

open Types
open Expressions
open LlbcAst
open Errors

type obligation =
  | Iter of trait_ref  (** Must resolve to a reviewed iterator. *)
  | Into of trait_ref  (** An [IntoIterator] whose iterator is reviewed. *)

let prefix = "_root_.Aeneas.Std."
let iterator = prefix ^ "core.iter.traits.iterator.Iterator"
let into_iterator = prefix ^ "core.iter.traits.collect.IntoIterator"
let from_iterator = prefix ^ "core.iter.traits.collect.FromIterator"
let extend = prefix ^ "core.iter.traits.collect.Extend"
let step = prefix ^ "core.iter.range.Step"
let double_ended = prefix ^ "core.iter.traits.double_ended.DoubleEndedIterator"

(*
```ocaml
*)
let iterator_auxiliary :
    (trait_ref -> Pure.iterator_auxiliary option) ref =
  ref (fun _ -> None)

let rec copy_ty (ty : ty) =
  match ty with
  | TLiteral _ | TRef (_, _, RShared) -> true
  | TAdt { id = TTuple; generics } -> List.for_all copy_ty generics.types
  | TArray (ty, _) -> copy_ty ty
  | _ -> false
(*
```
*)

(*
```ocaml
*)
module NativeLayouts = struct
  type layout = { rust_type : Yojson.Basic.t; size : int; alignment : int }

  let invalid message =
    invalid_arg ("Native collection layouts: " ^ message)

  let field key json =
    match json with
    | `Assoc fields ->
        (match List.filter (fun (name, _) -> name = key) fields with
         | [ (_, value) ] -> value
         | _ -> invalid ("missing or duplicate field " ^ key))
    | _ -> invalid "expected an object"

  let text = function `String value -> value | _ -> invalid "expected a string"
  let integer = function `Int value -> value | _ -> invalid "expected an integer"
  let array = function `List values -> values | _ -> invalid "expected an array"

  let rec canonical = function
    | `Assoc fields ->
        `Assoc (List.sort compare
          (List.map (fun (name, value) -> (name, canonical value)) fields))
    | `List values -> `List (List.map canonical values)
    | value -> value

  let sha256 path =
    let channel =
      Unix.open_process_args_in "/usr/bin/shasum"
        [| "/usr/bin/shasum"; "-a"; "256"; "--"; path |]
    in
    let line =
      try input_line channel
      with exception_ ->
        ignore (Unix.close_process_in channel);
        raise exception_
    in
    let status = Unix.close_process_in channel in
    if status <> Unix.WEXITED 0 || String.length line < 64 then
      invalid ("cannot hash " ^ path);
    String.sub line 0 64

  let read_file path =
    let channel = open_in_bin path in
    Fun.protect ~finally:(fun () -> close_in channel)
      (fun () -> really_input_string channel (in_channel_length channel))

  let check_identity identity =
    let path = text (field "path" identity) in
    let expected_bytes = integer (field "bytes" identity) in
    let expected_sha = text (field "sha256" identity) in
    if Filename.is_relative path || expected_bytes < 0
       || String.length expected_sha <> 64
       || (Unix.stat path).Unix.st_size <> expected_bytes
       || sha256 path <> expected_sha then
      invalid ("stale or unbound file identity: " ^ path);
    path

  let check_sources sources =
    let root = text (field "root" sources) in
    if Filename.is_relative root then invalid "source root must be absolute";
    let manifest = check_identity (field "manifest" sources) in
    let files = Yojson.Basic.from_file manifest in
    match files with
    | `Assoc files when files <> [] ->
        List.iter
          (fun (relative, identity) ->
            if not (Filename.is_relative relative)
               || List.mem ".." (String.split_on_char '/' relative) then
              invalid "source path leaves its declared root";
            let path = Filename.concat root relative in
            let full_identity =
              `Assoc [
                ("path", `String path);
                ("bytes", field "bytes" identity);
                ("sha256", field "sha256" identity) ]
            in
            ignore (check_identity full_identity))
          files
    | _ -> invalid "source manifest must contain file identities"

  let check_profile profile =
    let manifest = check_identity (field "manifest" profile) in
    let recorded = Yojson.Basic.from_file manifest in
    if canonical recorded <> canonical (field "configuration" profile) then
      invalid "feature profile differs from its recorded configuration";
    let configuration = field "configuration" profile in
    ignore (text (field "cargo_profile" configuration));
    ignore (field "rustflags" configuration);
    let packages = array (field "packages" configuration) in
    if packages = [] then invalid "feature chain has no packages";
    List.iter
      (fun package ->
        ignore (text (field "package_id" package));
        ignore (text (field "crate_name" package));
        List.iter (fun feature -> ignore (text feature))
          (array (field "features" package)))
      packages

  (* ```ocaml *)
  let rec closed_native_type (evidence : crate) json =
    match text (field "kind" json) with
    | "scalar" ->
        let name = text (field "name" json) in
        if not (List.mem name
          ["bool"; "char"; "u8"; "u16"; "u32"; "u64"; "u128"; "usize";
           "i8"; "i16"; "i32"; "i64"; "i128"; "isize"; "f32"; "f64"])
        then invalid "layout scalar is not a closed Rust type";
        name
    | "tuple" ->
        let fields = List.map (closed_native_type evidence) (array (field "types" json)) in
        "(" ^ String.concat ", " fields
        ^ (if List.length fields = 1 then ",)" else ")")
    | "adt" ->
        let name = text (field "name" json) in
        let arguments = array (field "types" json) in
        let declarations = TypeDeclId.Map.bindings evidence.type_decls
          |> List.filter (fun (_, (declaration : type_decl)) ->
            List.for_all (function PeIdent _ -> true | _ -> false)
              declaration.item_meta.name
            && Print.name_to_string (Print.crate_to_fmt_env evidence)
              declaration.item_meta.name = name) in
        (match declarations with
         | [ (_, declaration) ]
           when declaration.generics.regions = []
                && declaration.generics.const_generics = []
                && List.length declaration.generics.types = List.length arguments
                && array (field "consts" json) = [] -> ()
         | _ -> invalid "layout ADT has no unique complete declaration");
        let arguments = List.map (closed_native_type evidence) arguments in
        name ^ (if arguments = [] then ""
          else "<" ^ String.concat ", " arguments ^ ">")
    | _ -> invalid "layout row is not a closed Rust type"
  (* ``` *)

  (* ```ocaml *)
  let check_capture json =
    let receipt = Yojson.Basic.from_file
      (check_identity (field "extraction_receipt" json)) in
    if field "core_stable" receipt <> `Bool true then
      invalid "native capture has no stable production source";
    let same_file first second =
      let first = check_identity first and second = check_identity second in
      if sha256 first <> sha256 second then
        invalid "native capture identity differs from its certificate" in
    same_file (field "llbc_input" receipt) (field "llbc_input" json);
    same_file (field "feature_chain" receipt)
      (field "manifest" (field "feature_chain" json));
    same_file (field "root_sources" receipt)
      (field "manifest" (field "root_sources" json));
    let before = Yojson.Basic.from_file (check_identity (field "core_before" receipt)) in
    let after = Yojson.Basic.from_file (check_identity (field "core_after" receipt)) in
    if canonical before <> canonical after then
      invalid "native capture source manifests differ";
    let digest = text (field "source_tree_sha256" before) in
    if String.length digest <> 64 then invalid "native capture has no source tree digest";
    let sources = Yojson.Basic.from_file
      (check_identity (field "root_sources" receipt)) in
    let files = match sources with
      | `Assoc files -> `Assoc (List.map (fun (name, identity) ->
          (name, field "sha256" identity)) files)
      | _ -> invalid "native capture source manifest is not an object" in
    if canonical files <> canonical (field "files" before) then
      invalid "native layout sources differ from the extracted source";
    (* ```ocaml *)
    let () = List.iter (fun key -> ignore (check_identity (field key receipt)))
      ["roots"; "native_shell"; "extraction_command"; "native_command"; "public_probe_source"] in
    receipt
    (* ``` *)
  (* ``` *)

  let rec native_declarations (evidence : crate) rust_type =

    match text (field "kind" rust_type) with

    | "scalar" -> []

    | "tuple" ->
        List.concat_map (native_declarations evidence) (array (field "types" rust_type))

    | "adt" ->
        let name = text (field "name" rust_type) in

        let declarations = TypeDeclId.Map.bindings evidence.type_decls
          |> List.filter (fun (_, (declaration : type_decl)) ->

            Print.name_to_string (Print.crate_to_fmt_env evidence)
              declaration.item_meta.name = name) in

        (match declarations with
         | [(_, declaration)] ->

             declaration :: List.concat_map (native_declarations evidence)
               (array (field "types" rust_type))

         | _ -> invalid "native supplier has no unique complete declaration")

    | _ -> invalid "native supplier type is not closed"

  let check_supplier evidence json profile receipt source_package rust_type =

    let declarations = native_declarations evidence rust_type in

    let () = if declarations = [] then invalid "native package supplier has no declaration" in

    let packages = List.filter (fun package ->
      text (field "package_id" package) = source_package)
      (array (field "packages" profile)) in

    let package = match packages with
      | [package] -> package
      | _ -> invalid "native supplier package is missing or ambiguous" in

    let crate_name = text (field "crate_name" package) in

    let units = List.filter (fun unit ->
      text (field "package_id" unit) = source_package

      && text (field "name" (field "target" unit)) = crate_name

      && canonical (field "kind" (field "target" unit))
         = canonical (field "target_kind" package)

      && canonical (field "features" unit) = canonical (field "features" package)

      && canonical (field "profile" unit) = canonical (field "profile" package)

      && canonical (field "filenames" unit) = canonical (field "filenames" package)

      && field "src_path" (field "target" unit) = field "source_path" package)
      (array (field "native_artifacts" profile)) in

    let unit = match units with
      | [unit] -> unit
      | _ -> invalid "native supplier artifact unit is missing or ambiguous" in

    let command = Yojson.Basic.from_file
      (check_identity (field "native_command" receipt)) in

    let () = if integer (field "exit" command) <> 0 then invalid "native supplier command failed" in

    let arguments = List.map text (array (field "command" command)) in

    let rec option_value name = function
      | key :: value :: _ when key = name -> Some value

      | _ :: rest -> option_value name rest
      | [] -> None in

    let () = if option_value "--target" arguments <> Some (text (field "target" profile)) then
      invalid "native supplier target differs from its profile" in

    let events = String.split_on_char '\n'
      (read_file (check_identity (field "log" command)))

      |> List.filter_map (fun line ->
        if not (String.starts_with ~prefix:"{" line) then None

        else try Some (Yojson.Basic.from_string line) with Yojson.Json_error _ -> None) in

    let () = if List.length (List.filter (fun event -> canonical event = canonical unit) events) <> 1 then

      invalid "native supplier artifact unit has no unique command receipt" in

    let metadata = Yojson.Basic.from_file (check_identity (field "metadata" profile)) in

    let metadata_packages = List.filter (fun package ->
      text (field "id" package) = source_package)
      (array (field "packages" metadata)) in

    let metadata_package = match metadata_packages with
      | [package] -> package
      | _ -> invalid "native supplier has no unique Cargo package" in

    let () = if field "manifest_path" metadata_package <> field "manifest_path" unit

       || not (List.exists (fun target ->
         canonical target = canonical (field "target" unit))
         (array (field "targets" metadata_package))) then

      invalid "native supplier source target differs from Cargo metadata" in

    let root = text (field "root" (field "root_sources" json)) in

    let sources = Yojson.Basic.from_file
      (check_identity (field "manifest" (field "root_sources" json))) in

    let manifest_directory = Filename.dirname (text (field "manifest_path" unit)) in

    let () = List.iter (fun (declaration : type_decl) ->

      let file = declaration.item_meta.span.data.file in

      let () = if file.crate_name <> crate_name then
        invalid "complete declaration belongs to a different native supplier" in

      let source = match file.name with
        | Meta.Local path ->

            Unix.realpath (if Filename.is_relative path then Filename.concat root path else path)

        | _ -> invalid "native declaration has no authenticated local source" in

      let () = if not (String.starts_with ~prefix:(manifest_directory ^ "/") source) then
        invalid "complete declaration source is outside its native package" in

      let relative = if String.starts_with ~prefix:(root ^ "/") source then

          String.sub source (String.length root + 1)
            (String.length source - String.length root - 1)

        else invalid "native declaration source is outside the source manifest" in

      let () = ignore (field relative sources) in

      match file.contents with
      | Some contents when contents <> read_file source ->
          invalid "complete declaration source differs from the native source"

      | _ -> ()) declarations in

    crate_name

  (*
```ocaml
  *)
  let optional_field key = function
    | `Assoc fields ->
        (match List.filter (fun (name, _) -> name = key) fields with
         | [] -> None
         | [(_, value)] -> Some value
         | _ -> invalid ("duplicate field " ^ key))
    | _ -> invalid "expected an object"

  let successful_command identity =
    let command = Yojson.Basic.from_file (check_identity identity) in
    if integer (field "exit" command) <> 0 then
      invalid "standard supplier command failed";
    let log = check_identity (field "log" command) in
    (command, log)
  (*
```
  *)

  (*
```ocaml
  *)
  let check_standard_supplier (evidence : crate) json receipt row rust_type supplier =
    let expected_type = `Assoc [
      ("kind", `String "adt"); ("name", `String "alloc::string::String");
      ("types", `List []); ("consts", `List []) ] in
    if rust_type <> canonical expected_type
       || text (field "crate_name" supplier) <> "alloc"
       || text (field "native_type" row) <> "std::string::String" then
      invalid "standard supplier does not own the complete String declaration";
    let native = field "native" json in
    let compiler_identity = field "compiler" native in
    if canonical (field "compiler" supplier) <> canonical compiler_identity then
      invalid "standard supplier uses another compiler";
    let compiler = check_identity compiler_identity in
    let target = text (field "target" native) in
    if text (field "target" supplier) <> target then
      invalid "standard supplier uses another target";
    let capture = Yojson.Basic.from_file
      (check_identity (field "native_capture" receipt)) in
    let commands = field "commands" capture in
    let query key command_name print =
      let identity = field key supplier in
      if canonical identity <> canonical (field command_name commands) then
        invalid "standard query differs from its actual native capture";
      let command, log = successful_command identity in
      if array (field "command" command)
         <> List.map (fun value -> `String value)
              [compiler; "--print"; print; "--target"; target] then
        invalid "standard query uses another compiler or target";
      match String.split_on_char '\n' (read_file log) with
      | [directory; ""] when not (Filename.is_relative directory) -> directory
      | [directory] when not (Filename.is_relative directory) -> directory
      | _ -> invalid "standard query has no exact absolute directory output"
    in
    let directory = query "target_libdir_command" "native-target-libdir" "target-libdir" in
    let sysroot = query "sysroot_command" "native-sysroot" "sysroot" in
    if directory <> Filename.concat sysroot ("lib/rustlib/" ^ target ^ "/lib") then
      invalid "standard target directory differs from its actual sysroot";
    let check_artifact key crate_name =
      let artifact = check_identity (field key supplier) in
      let candidates = Array.to_list (Sys.readdir directory)
        |> List.filter (fun name ->
          String.starts_with ~prefix:("lib" ^ crate_name ^ "-") name
          && Filename.check_suffix name ".rlib")
        |> List.map (Filename.concat directory) in
      if candidates <> [artifact] || Filename.dirname artifact <> directory then
        invalid "standard supplier has no unique actual target artifact"
    in
    check_artifact "artifact" "alloc";
    check_artifact "public_artifact" "std";
    let public_identity = field "public_probe_command" receipt in
    if canonical public_identity <> canonical (field "native-public-compile" commands) then
      invalid "standard public probe differs from its actual capture";
    let public_command, _ = successful_command public_identity in
    let public_arguments = List.map text (array (field "command" public_command)) in
    let rec option_value name = function
      | option :: value :: _ when option = name -> Some value
      | _ :: rest -> option_value name rest
      | [] -> None
    in
    if public_arguments = [] || List.hd public_arguments <> compiler
       || option_value "--sysroot" public_arguments <> Some sysroot
       || option_value "--target" public_arguments <> Some target then
      invalid "standard public probe uses another compiler target supplier";
    let public_layouts, _ = successful_command (field "native-public-layouts" commands) in
    if canonical (field "artifact" (field "evidence" row))
       <> canonical (field "log" public_layouts) then
      invalid "standard layout does not use its actual public probe output";
    let archive_identity = field "source_archive" supplier in
    let archive = check_identity archive_identity in
    if text (field "sha256" archive_identity)
       <> "5a9993673ce40804e6b50300df59ecb3d13942c1c89cd11e76acf705b331f982" then
      invalid "standard source archive differs from the pinned compiler commit";
    let download, download_log = successful_command
      (field "source_archive_command" supplier) in
    let url = "https://codeload.github.com/rust-lang/rust/tar.gz/"
      ^ text (field "commit" native) in
    let arguments = List.map text (array (field "command" download)) in
    if arguments = [] || List.hd (List.rev arguments) <> url
       || option_value "--output" arguments <> Some archive
       || not (List.mem (url ^ " 200")
         (String.split_on_char '\n' (read_file download_log))) then
      invalid "standard source archive lacks its actual pinned download";
    let entry = match array (field "declaration_sources" supplier) with
      | [entry] -> entry
      | _ -> invalid "standard String needs one exact declaration source" in
    let llbc_file = "/rustc/library/alloc/src/string.rs" in
    let member = "rust-" ^ text (field "commit" native)
      ^ "/library/alloc/src/string.rs" in
    if text (field "crate_name" entry) <> "alloc"
       || text (field "llbc_file" entry) <> llbc_file
       || text (field "archive_member" entry) <> member then
      invalid "standard declaration source has another canonical owner";
    let source_identity = field "source" entry in
    let source = check_identity source_identity in
    if text (field "sha256" source_identity)
       <> "e3289c812f163ba94b10d43f7fa5ba3bf9133adeaaa7733c4d796380e9aeac1e" then
      invalid "standard declaration source differs from its pinned archive member";
    let declaration = Yojson.Basic.from_file
      (check_identity (field "declaration_evidence" entry)) in
    ignore (check_identity (field "llbc" declaration));
    let recorded = field "declaration" declaration in
    let metadata = field "metadata" recorded in
    let file = field "source_file" recorded in
    if text (field "declaring_crate" declaration) <> "alloc"
       || text (field "canonical_name" declaration) <> "alloc::string::String"
       || canonical (field "canonical_rust_type" declaration) <> rust_type
       || text (field "public_rust_path" declaration) <> "std::string::String"
       || canonical (field "native_source" declaration) <> canonical source_identity
       || canonical (field "source_archive" declaration) <> canonical archive_identity
       || canonical (field "source_archive_command" declaration)
          <> canonical (field "source_archive_command" supplier)
       || text (field "archive_member" declaration) <> member
       || field "is_local" metadata <> `Bool false
       || field "public" (field "attr_info" metadata) <> `Bool true
       || text (field "lang_item" metadata) <> "String"
       || text (field "crate_name" file) <> "alloc"
       || field "name" file <> `Assoc [("Local", `String llbc_file)] then
      invalid "standard declaration evidence has another type or source";
    (match native_declarations evidence rust_type with
     | [declaration] ->
         let metadata = declaration.item_meta in
         let file = metadata.span.data.file in
         if metadata.is_local || not metadata.attr_info.public
            || metadata.lang_item <> Some "String"
            || file.crate_name <> "alloc"
            || file.name <> Meta.Local llbc_file then
           invalid "current complete declaration is not the authentic alloc String";
         (match file.contents with
          | Some contents when contents <> read_file source ->
              invalid "current standard declaration source differs from its archive"
          | _ -> ())
     | _ -> invalid "standard supplier has no unique current complete declaration");
    "alloc"
  (*
```
  *)

  let load (evidence : crate) =
    match !Config.native_collection_layouts with
    | None -> []
    | Some path ->
        let json = Yojson.Basic.from_file path in
        if integer (field "version" json) <> 1 then invalid "unknown schema version";
        let native = field "native" json in
        let release = text (field "release" native) in
        let commit = text (field "commit" native) in
        let target = text (field "target" native) in
        if release <> "1.98.0"
           || commit <> "88d9e12ae178fab0fb5cc050a94da85685d449ea"
           || target <> "aarch64-apple-darwin"
           || not (List.mem_assoc target evidence.target_information) then
          invalid "native compiler or target does not match the approved profile";
        ignore (check_identity (field "compiler" native));
        let version = read_file (check_identity (field "version_output" native)) in
        List.iter
          (fun expected ->
            if not (Str.string_match
              (Str.regexp (".*" ^ Str.quote expected ^ ".*"))
              (String.concat " " (String.split_on_char '\n' version)) 0) then
              invalid "native version output differs from its identity")
          [ "release: " ^ release; "commit-hash: " ^ commit; "host: " ^ target ];
        let imported = check_identity (field "llbc_input" json) in
        let actual = match !Config.native_collection_input_file with
          | Some actual -> actual
          | None -> invalid "no imported crate identity" in
        if sha256 imported <> sha256 actual then
          invalid "certificate does not bind the imported crate";
        check_sources (field "root_sources" json);
        check_profile (field "feature_chain" json);
        (* ```ocaml *)
        let capture_receipt = check_capture json in
        let profile = field "configuration" (field "feature_chain" json) in
        (* ``` *)
        let environment = Print.crate_to_fmt_env evidence in
        let declaration_names = Hashtbl.create 64 in
        TypeDeclId.Map.iter
          (fun _ (declaration : type_decl) ->
            Hashtbl.replace declaration_names
              (Print.name_to_string environment declaration.item_meta.name) ())
          (* <!-- ste-disable-next-line semicolon --> *)
          evidence.type_decls;
        let rec has_declarations descriptor =
          match text (field "kind" descriptor) with
          | "scalar" ->
              (* <!-- ste-disable-next-line semicolon --> *)
              ignore (closed_native_type evidence descriptor);
              true
          | "tuple" ->
              has_arguments (array (field "types" descriptor))
          | "adt" ->
              let name = text (field "name" descriptor) in
              let arguments = array (field "types" descriptor) in
              (* <!-- ste-disable-next-line semicolon --> *)
              ignore (array (field "consts" descriptor));
              let arguments_present = has_arguments arguments in
              Hashtbl.mem declaration_names name && arguments_present
          | _ -> invalid "layout row is not a closed Rust type"
        and has_arguments arguments =
          List.fold_left
            (fun present argument ->
              let argument_present = has_declarations argument in
              present && argument_present)
            true arguments
        in
        let seen = Hashtbl.create 16 in
        let rows =
          List.map
            (fun row ->
              let rust_type = canonical (field "rust_type" row) in
              let key = Yojson.Basic.to_string rust_type in
              (* <!-- ste-disable-next-line semicolon --> *)
              if Hashtbl.mem seen key then invalid "ambiguous complete Rust type";
              (* <!-- ste-disable-next-line semicolon --> *)
              Hashtbl.add seen key ();
              (row, rust_type))
            (array (field "rows" json))
        in
        List.filter_map
          (fun (row, rust_type) ->
            if not (has_declarations rust_type) then None
            else
            let complete_native_type = closed_native_type evidence rust_type in
            let size = integer (field "size" row) in
            let alignment = integer (field "alignment" row) in
            if size < 0 || alignment <= 0
               || alignment land (alignment - 1) <> 0 then
              invalid "invalid native size or alignment";
            let native_type = text (field "native_type" row) in
            let source_package = text (field "source_package" row) in
            if source_package = "" || native_type = "" then
              invalid "layout row has no complete native supplier";
            (*
```ocaml
            *)
            let standard_supplier = optional_field "standard_library_supplier" row in
            let supplier_crate =
              match source_package, standard_supplier with
              | "rustc", Some supplier ->
                  Some (check_standard_supplier evidence json capture_receipt
                    row rust_type supplier)
              | "rustc", None ->
                  let () = if text (field "kind" rust_type) <> "scalar" then
                    invalid "native scalar supplier binds a non-scalar type" in
                  None
              | _, Some _ ->
                  invalid "a Cargo ADT cannot claim a standard-library supplier"
              | _, None ->
                  Some (check_supplier evidence json profile capture_receipt
                    source_package rust_type)
            in
            (*
```
            *)
            (* ```ocaml *)
            let proof = field "evidence" row in
            let local_name = match supplier_crate with
              | None -> complete_native_type
              | Some crate_name -> Str.global_replace (Str.regexp
                  (Str.quote (crate_name ^ "::"))) "" complete_native_type in
            (* ```ocaml *)
            let transparent_tuple =
              complete_native_type = "(usize, chelis_ir::lower::LoweredValue)"
              && native_type = "std::mem::ManuallyDrop<(usize, lower::LoweredValue)>"
              && (let source = check_identity (field "manually_drop_source" proof) in
                  sha256 source = "c21100b507893a11ee27b0711be3ac3fe6cc970b96bba55a7d3bae5978209818"
                  && text (field "wrapper_type" proof)
                     = "std::mem::ManuallyDrop<(usize, chelis_ir::lower::LoweredValue)>"
                  && canonical (field "inner_type" proof) = rust_type) in
            (*
```ocaml
            *)
            let standard_alias = Option.is_some standard_supplier
              && native_type = "std::string::String" in
            if native_type <> complete_native_type && native_type <> local_name
               && not transparent_tuple && not standard_alias then
              invalid "raw native type does not bind its complete Rust type";
            (*
```
            *)
            (* ``` *)
            let artifact = check_identity (field "artifact" proof) in
            let line = integer (field "line" proof) in
            let expected = Printf.sprintf
              "print-type-size type: `%s`: %d bytes, alignment: %d bytes"
              native_type size alignment in
            let lines = String.split_on_char '\n' (read_file artifact) in
            (* ```ocaml *)
            let supplier_prefix = Printf.sprintf "print-type-size type: `%s`:" native_type in
            let suppliers = List.filter (fun line ->
              String.starts_with ~prefix:supplier_prefix line) lines in
            if suppliers <> [expected] then
              invalid "raw native output has no unique complete type supplier";
            (* ``` *)
            if line <= 0 || List.nth_opt lines (line - 1) <> Some expected then
              invalid "layout row does not match its raw native output";
            (* <!-- ste-disable-next-line semicolon --> *)
            Some { rust_type; size; alignment })
          rows

  let descriptor (evidence : crate) (ty : ty) =
    let environment = Print.crate_to_fmt_env evidence in
    let rec describe ty =
      match ty with
      | TLiteral _ ->
          Some (`Assoc [ ("kind", `String "scalar");
            ("name", `String (Print.ty_to_string environment ty)) ])
      | TAdt reference when reference.generics.regions = []
                            && reference.generics.const_generics = [] ->
          let arguments = List.map describe reference.generics.types in
          if not (List.for_all Option.is_some arguments) then None
          else
            let arguments = `List (List.map Option.get arguments) in
            (match reference.id with
             | TTuple -> Some (`Assoc [
                 ("kind", `String "tuple"); ("types", arguments) ])
             | TAdtId id ->
                 let declaration = TypeDeclId.Map.find id evidence.type_decls in
                 if not (List.for_all
                   (function PeIdent _ -> true | _ -> false)
                   declaration.item_meta.name) then None
                 else Some (`Assoc [
                   ("kind", `String "adt");
                   ("name", `String (Print.name_to_string environment
                     declaration.item_meta.name));
                   ("types", arguments);
                   ("consts", `List []) ])
             | _ -> None)
      | _ -> None
    in
    Option.map canonical (describe ty)

  let find evidence layouts ty =
    Option.bind (descriptor evidence ty)
      (fun rust_type -> List.find_opt
        (fun layout -> layout.rust_type = rust_type) layouts)
end
(*
```
*)

(** Crate iterator impls whose size_hint is their own translated function. The
    Lean extraction states, next to each, the proposition
    [<impl>.size_hint_total]: the size_hint model is total, given that the
    size_hint of each Iterator clause of the impl is. *)
let size_hint_impls : TraitImplId.Set.t ref = ref TraitImplId.Set.empty

(** The impls of [size_hint_impls] whose [size_hint_total] an admitted
    collection relies on: written by [-emit-collection-obligations], for a
    checked theorem to discharge. *)
let size_hint_obligations : TraitImplId.Set.t ref = ref TraitImplId.Set.empty

(** The deferred obligations of the declarations that the last [check] saw
    (none for a body without them, or a declaration without a body); rejected
    bodies and opaque custom FromIterator::from_iter are absent. *)
let reviewed : obligation list FunDeclId.Map.t ref = ref FunDeclId.Map.empty

(** A dictionary as a path from one of the function's own clauses through
    parent clauses (innermost first), if it is one. *)
let rec clause_path (tr : trait_ref) : (int * int list) option =
  match tr.kind with
  | Clause (Free clause) -> Some (TraitClauseId.to_int clause, [])
  | ParentClause (inner, clause) ->
      Option.map
        (fun (root, parents) -> (root, parents @ [ TraitClauseId.to_int clause ]))
        (clause_path inner)
  | _ -> None

(** The separate-compilation facts of a reviewed body: its deferred
    obligations as clause paths, for the callers in later chunks. [None] if the
    body was not reviewed or an obligation is not a clause path. *)
let manifest_obligations (id : FunDeclId.id) :
    SeparateCompilation.collection_obligation list option =
  Option.bind (FunDeclId.Map.find_opt id !reviewed) (fun obligations ->
      let path into tr =
        Option.map
          (fun (clause, parents) -> { SeparateCompilation.into; clause; parents })
          (clause_path tr)
      in
      let paths =
        List.map
          (function Iter tr -> path false tr | Into tr -> path true tr)
          obligations
      in
      if List.for_all Option.is_some paths then Some (List.map Option.get paths)
      else None)

let check ~(evidence : crate) (crate : crate) : crate =
  if Config.backend () <> Config.Lean then crate
  else
    let () = reviewed := FunDeclId.Map.empty in
    (*
```ocaml
    *)
    let native_layouts =
      try NativeLayouts.load evidence
      with Invalid_argument message | Sys_error message | Yojson.Json_error message ->
        [%craise_opt_span] None message
    in
    (*
```
    *)
    let mctx = NameMatcher.ctx_from_crate evidence in
    let rec native_name name =
      match List.rev name with
      | PeInstantiated _ :: rest -> native_name (List.rev rest)
      | _ -> name
    in
    let trait_name id =
      let decl = TraitDeclId.Map.find id evidence.trait_decls in
      Option.map
        (fun (info : Pure.builtin_trait_decl_info) -> info.extract_name)
        (ExtractBuiltin.find_trait_decl_info mctx (native_name decl.item_meta.name))
    in
    let ref_name (tr : trait_ref) =
      trait_name tr.trait_decl_ref.binder_value.id
    in
    let impl_name (impl : trait_impl) =
      let decl = TraitDeclId.Map.find impl.impl_trait.id evidence.trait_decls in
      Option.map
        (fun (info : Pure.builtin_trait_impl_info) -> info.extract_name)
        (ExtractBuiltin.find_trait_impl_info mctx (native_name decl.item_meta.name)
           impl.impl_trait.generics)
    in
    let fun_name (decl : fun_decl) =
      Option.map
        (fun (info : Pure.builtin_fun_info) -> info.extract_name)
        (ExtractBuiltin.find_fun_info mctx decl.def_id decl.item_meta.name)
    in
    let reject span reason =
      [%craise] span
        ("E_UNSUPPORTED_COLLECTION: " ^ reason
       ^ ". The value-only Vec/BTree collection model cannot preserve native "
       ^ "size_hint/consumer dispatch for this dictionary. Use an explicit "
       ^ "next-driven production loop, or provide a reviewed collector model "
       ^ "with the required capacity and specialization semantics.")
    in
    (* Each substitution below instantiates a declaration's own parameters with
       the arguments of one reference to it. A variable that those parameters do
       not bind makes the dictionary ill-scoped: report it rather than check or
       discharge an obligation against a guessed instance. *)
    let instantiate span what f =
      try f ()
      with Not_found | Invalid_argument _ ->
        [%craise] span
          ("Collection contract check: the instantiation of " ^ what
         ^ " refers to generic variables that its arguments do not bind")
    in
    (* Recover native dispatch identity, not the borrowed-state ABI. Structured
       specializations still retain their real methods and giveback signatures.
       Apply the same binder substitution as normalize_modeled_trait_specializations. *)
    let implementations = TraitImplId.Map.values evidence.trait_impls in
    let rec native_impl span (reference : trait_impl_ref) =
      let impl = TraitImplId.Map.find reference.id evidence.trait_impls in
      match List.rev impl.item_meta.name with
      | PeInstantiated shape :: rest -> (
          let name = List.rev rest in
          match List.find_opt
                  (fun (original : trait_impl) -> original.item_meta.name = name)
                  implementations with
          | None -> reject span "missing native collection specialization identity"
          | Some original ->
              let generics =
                instantiate span "a native collection specialization" (fun () ->
                    Substitute.apply_args_to_binder reference.generics
                      Substitute.generic_args_substitute shape)
              in
              native_impl span { id = original.def_id; generics })
      | _ -> reference
    in
    let obligations : obligation list FunDeclId.Map.t ref =
      ref FunDeclId.Map.empty
    in
    (* The reviewed bodies that an earlier chunk owns: a later chunk keeps only
       their declarations, and their deferred obligations come from the owner's
       manifest facts, as clause paths over the declaration's own clauses. A
       path that does not fit the declaration is not evidence: the function is
       then treated as unreviewed. *)
    let external_obligations (decl : fun_decl)
        (paths : SeparateCompilation.collection_obligation list) =
      let find_clause (params : trait_param list) index =
        List.find_opt
          (fun (param : trait_param) -> TraitClauseId.to_int param.clause_id = index)
          params
      in
      let parent (inner : trait_ref option) index =
        Option.bind inner (fun (inner : trait_ref) ->
            let decl_ref = inner.trait_decl_ref.binder_value in
            if inner.trait_decl_ref.binder_regions <> [] then None
            else
              Option.bind
                (TraitDeclId.Map.find_opt decl_ref.id evidence.trait_decls)
                (fun (trait_decl : trait_decl) ->
                  Option.bind (find_clause trait_decl.implied_clauses index)
                    (fun (param : trait_param) ->
                      if param.trait.binder_regions <> [] then None
                      else
                        try
                          let subst =
                            Charon.Substitute.make_subst_from_generics
                              trait_decl.generics decl_ref.generics inner.kind
                          in
                          Some
                            {
                              kind = ParentClause (inner, param.clause_id);
                              trait_decl_ref =
                                {
                                  param.trait with
                                  binder_value =
                                    Substitute.trait_decl_ref_substitute subst
                                      param.trait.binder_value;
                                };
                            }
                        with Not_found | Invalid_argument _ -> None)))
      in
      let obligation (path : SeparateCompilation.collection_obligation) =
        let root =
          Option.map
            (fun (param : trait_param) ->
              { kind = Clause (Free param.clause_id); trait_decl_ref = param.trait })
            (find_clause decl.generics.trait_clauses path.clause)
        in
        Option.map
          (fun tr -> if path.into then Into tr else Iter tr)
          (List.fold_left parent root path.parents)
      in
      let required = List.map obligation paths in
      if List.for_all Option.is_some required then
        Some (List.map Option.get required)
      else None
    in
    let external_reviewed =
      FunDeclId.Map.fold
        (fun id (decl : fun_decl) reviewed ->
          match SeparateCompilation.external_collection_obligations id with
          | None -> reviewed
          | Some paths -> (
              match external_obligations decl paths with
              | None -> reviewed
              | Some required ->
                  if required <> [] then
                    obligations := FunDeclId.Map.add id required !obligations;
                  FunDeclId.Set.add id reviewed))
        evidence.fun_decls FunDeclId.Set.empty
    in
    let current : FunDeclId.id option ref = ref None in
    let changed = ref false in
    let rec generic_root (tr : trait_ref) =
      match tr.kind with
      | Clause (Free _) -> true
      | ParentClause (inner, _) | ItemClause (inner, _, _) -> generic_root inner
      | _ -> false
    in
    let defer span obligation =
      match !current with
      | Some id ->
          let known =
            Option.value ~default:[] (FunDeclId.Map.find_opt id !obligations)
          in
          if not (List.mem obligation known) then (
            obligations := FunDeclId.Map.add id (obligation :: known) !obligations;
            changed := true)
      | None -> reject span "unresolved generic or projected collection dictionary"
    in
    let resolve span (tr : trait_ref) =
      match tr.kind with
      | TraitImpl reference ->
          let reference = native_impl span reference in
          let impl = TraitImplId.Map.find reference.id evidence.trait_impls in
          let generics = reference.generics in
          let parents =
            instantiate span "a collection implementation's parent clauses"
              (fun () ->
                let subst =
                  [%add_loc] Substitute.make_subst_from_generics (Some span)
                    impl.generics generics (TraitImpl reference)
                in
                List.map (Substitute.trait_ref_substitute subst)
                  impl.implied_trait_refs)
          in
          (impl, generics.trait_refs, parents)
      | _ -> reject span "unresolved generic or projected collection dictionary"
    in
    (* Project parent dictionaries of resolved implementations, so that a
       caller's instance of a deferred obligation reaches its implementation. *)
    let rec normalize span (tr : trait_ref) : trait_ref =
      match tr.kind with
      | ParentClause (inner, clause) -> (
          let inner = normalize span inner in
          match inner.kind with
          | TraitImpl _ -> (
              let _, _, parents = resolve span inner in
              match List.nth_opt parents (TraitClauseId.to_int clause) with
              | Some parent -> normalize span parent
              | None -> reject span "missing parent collection dictionary")
          | _ -> { tr with kind = ParentClause (inner, clause) })
      | _ -> tr
    in
    let one span name refs =
      match List.filter (fun tr -> ref_name tr = Some name) refs with
      | [ tr ] -> tr
      | _ -> reject span ("missing or ambiguous " ^ name ^ " evidence")
    in
    (* A crate's own iterator, translated from its Rust impl. Standard-library
       iterators are admitted by reviewed name only: their private
       specialization markers (OneShot, InPlaceIterable, NonDrop, ...) are not
       visible in their methods. *)
    let crate_iterator (impl : trait_impl) =
      impl.item_meta.opacity = Transparent
      &&
      match impl.item_meta.name with
      | PeIdent (krate, _) :: _ -> not (List.mem krate [ "core"; "alloc"; "std" ])
      | _ -> false
    in
    (* Charon keeps every method that a Transparent impl defines (it marks them
       used), and only copies of the trait's defaults otherwise. Admit the impl
       only if every method other than next and size_hint is such a copy.
       Returns whether size_hint is the impl's own. *)
    let own_size_hint (impl : trait_impl) =
      match List.assoc_opt "size_hint" impl.methods with
      | Some method_ref -> (
          match
            FunDeclId.Map.find_opt method_ref.binder_value.id evidence.fun_decls
          with
          | Some { src = TraitImplItem (_, _, _, false); body = StructuredBody _; _ }
            -> true
          | _ -> false)
      | None -> false
    in
    size_hint_impls :=
      TraitImplId.Map.fold
        (fun id (impl : trait_impl) impls ->
          if
            crate_iterator impl
            && trait_name impl.impl_trait.id = Some iterator
            && own_size_hint impl
          then TraitImplId.Set.add id impls
          else impls)
        evidence.trait_impls TraitImplId.Set.empty;
    size_hint_obligations := TraitImplId.Set.empty;
    let check_default_consumers span (impl : trait_impl) =
      let impl_text =
        Print.name_to_string (Print.crate_to_fmt_env evidence) impl.item_meta.name
      in
      if not (List.mem_assoc "next" impl.methods) then
        reject span ("missing next of the crate iterator " ^ impl_text);
      List.iter
        (fun (name, (method_ref : fun_decl_ref binder)) ->
          match
            FunDeclId.Map.find_opt method_ref.binder_value.id evidence.fun_decls
          with
          | None ->
              reject span
                ("untranslated method " ^ name ^ " of the crate iterator " ^ impl_text)
          | Some decl when name = "next" -> (
              match decl.body with
              | StructuredBody _ -> ()
              | _ -> reject span ("opaque next of the crate iterator " ^ impl_text))
          | Some { src = TraitImplItem (_, _, _, true); _ } -> ()
          | Some _ when name = "size_hint" ->
              if not (TraitImplId.Set.mem impl.def_id !size_hint_impls) then
                reject span ("opaque size_hint of the crate iterator " ^ impl_text)
          | Some _ ->
              reject span
                ("the crate iterator " ^ impl_text ^ " overrides Iterator::" ^ name
               ^ "; only an iterator whose methods other than next and \
                  size_hint are the trait's defaults has the native collection \
                  schedule of repeated next"))
        impl.methods;
      let own = TraitImplId.Set.mem impl.def_id !size_hint_impls in
      if own then (
        if Option.is_none !Config.emit_collection_obligations then
          reject span
            ("the crate iterator " ^ impl_text
           ^ " defines size_hint, which native collectors call: its \
              totality is a collection obligation, which needs \
              -emit-collection-obligations");
        size_hint_obligations :=
          TraitImplId.Set.add impl.def_id !size_hint_obligations);
      own
    in
    (*
```ocaml
    *)
    let iterator_item (tr : trait_ref) =
      match tr.trait_decl_ref.binder_regions,
            tr.trait_decl_ref.binder_value.generics.types with
      | [], [ _; item ] -> Some item
      | _ -> None
    in
    let rec reuse_source span seen (tr : trait_ref) =
      let tr = normalize span tr in
      if generic_root tr || List.mem tr seen then None
      else
        let impl, args, _ = resolve span tr in
        let seen = tr :: seen in
        match impl_name impl with
        | Some name when name = iterator ^ "VecIntoIter" ->
            Option.map (fun item -> Some item) (iterator_item tr)
        | Some name when List.mem name
            (List.map (( ^ ) iterator)
              [ "Map"; "Copied"; "Cloned"; "Enumerate"; "Skip";
                "Take"; "Filter"; "FilterMap"; "SkipWhile"; "Fuse" ]) ->
            reuse_source span seen (one span iterator args)
        | Some name when name = iterator ^ "Zip" ->
            (match List.filter (fun tr -> ref_name tr = Some iterator) args with
             | [ left; _ ] -> reuse_source span seen left
             | _ -> None)
        | Some name when List.mem name
            (List.map (( ^ ) iterator)
              [ "SliceIter"; "ArrayIntoIter"; "BTreeIter"; "BTreeIntoIter";
                "BTreeSetIntoIter"; "BTreeSetIter"; "Chunks"; "ChunksExact";
                "Windows"; "Once"; "Chars"; "Lines"; "Split"; "RSplit";
                "SplitN"; "BTreeKeys"; "BTreeValues"; "BTreeIntoValues";
                "OptionIter"; "OptionIntoIter"; "ResultIter"; "ResultIntoIter";
                "Range"; "RangeInclusive"; "StepBy"; "FlatMap"; "Flatten" ]) ->
            Some None
        | _ -> None
    in
    let rec native_reuse_factors span seen tr =
      let tr = normalize span tr in
      if generic_root tr || List.mem tr seen then None
      else
        let impl, args, _ = resolve span tr in
        let seen = tr :: seen in
        match impl_name impl with
        | Some name when name = iterator ^ "VecIntoIter" -> Some (1, 1)
        | Some name when name = iterator ^ "Map" || name = iterator ^ "Enumerate" ->
            native_reuse_factors span seen (one span iterator args)
        | Some name when name = iterator ^ "Zip" ->
            (match List.filter (fun tr -> ref_name tr = Some iterator) args with
             | [ left; _ ] -> native_reuse_factors span seen left
             | _ -> None)
        | _ -> None
    in
    (* Native 88d9 requires equal nonzero sizes and equal alignment.
       Any measured size difference proves fallback, not an unknown reuse state. *)
    let reuse_decision span tr =
      match reuse_source span [] tr with
      | Some None -> Some false
      | Some (Some source) ->
          Option.bind (iterator_item tr)
            (fun output ->
              match NativeLayouts.find evidence native_layouts source,
                    NativeLayouts.find evidence native_layouts output with
              | Some source_layout, Some output_layout ->
                  if source_layout.size = 0 || output_layout.size = 0
                     || source_layout.alignment <> output_layout.alignment
                     || source_layout.size <> output_layout.size then Some false
                  else
                    Option.map (fun (merge_by, expand_by) -> merge_by >= expand_by)
                      (native_reuse_factors span [] tr)
              | _ -> None)
      | None -> None
    in
    let closed_copy_impl ty =
      TraitImplId.Map.exists
        (fun _ (impl : trait_impl) ->
          trait_name impl.impl_trait.id = Some (prefix ^ "core.marker.Copy")
          && impl.generics.regions = []
          && impl.generics.types = []
          && impl.generics.const_generics = []
          && impl.generics.trait_clauses = []
          && impl.impl_trait.generics.regions = []
          && impl.impl_trait.generics.const_generics = []
          && impl.impl_trait.generics.trait_refs = []
          && impl.impl_trait.generics.types = [ty])
        evidence.trait_impls
    in
    let primitive_copy_ty = copy_ty in
    let rec copy_ty ty =
      match ty with
      | TAdt { id = TTuple; generics } -> List.for_all copy_ty generics.types
      | TArray (item, _) -> copy_ty item
      | _ -> primitive_copy_ty ty || closed_copy_impl ty
    in
    let rec known_noncopy seen ty =
      if List.mem ty seen then false
      else
        let seen = ty :: seen in
        match ty with
        | TRef (_, _, RMut) -> true
        | TArray (item, _) -> known_noncopy seen item
        | TAdt { id = TTuple; generics } ->
            List.exists (known_noncopy seen) generics.types
        | TAdt ({ id = TAdtId id; _ } as reference) ->
            let declaration = TypeDeclId.Map.find id evidence.type_decls in
            let name = Print.name_to_string (Print.crate_to_fmt_env evidence)
              declaration.item_meta.name in
            if List.mem name [ "alloc::vec::Vec"; "alloc::string::String";
                               "alloc::boxed::Box" ] then true
            else
              (match declaration.kind with
               | Struct _ | Enum _ ->
                   let fields =
                     Substitute.type_decl_get_instantiated_variants_fields_types
                       declaration reference.generics
                   in
                   List.exists (fun (_, fields) ->
                     List.exists (known_noncopy seen) fields) fields
               | _ -> false)
        | _ -> false
    in
    let rec check_indexed_copy span seen tr =
      let tr = normalize span tr in
      if generic_root tr then reject span "unresolved Copy specialization"
      else if List.mem tr seen then
        reject span "recursive Copy specialization"
      else
        let impl, args, _ = resolve span tr in
        match impl_name impl with
        | Some name when name = iterator ^ "VecIntoIter" ->
            (match iterator_item tr with
             | Some item when copy_ty item || known_noncopy [] item -> ()
             | _ -> reject span "unresolved Copy specialization for vec::IntoIter")
        | Some name when List.mem name
            (List.map (( ^ ) iterator)
              [ "Map"; "Copied"; "Cloned"; "Enumerate"; "Skip"; "Take" ]) ->
            check_indexed_copy span (tr :: seen) (one span iterator args)
        | Some name when name = iterator ^ "Zip" ->
            List.iter (check_indexed_copy span (tr :: seen))
              (List.filter (fun tr -> ref_name tr = Some iterator) args)
        | _ -> ()
    in
    let auxiliary_cache = Hashtbl.create 64 in
    let () =
      iterator_auxiliary := (fun tr ->
        match Hashtbl.find_opt auxiliary_cache tr with
        | Some auxiliary -> auxiliary
        | None ->
            let auxiliary =
              if ref_name tr <> Some iterator then None
              else
                let span =
                  (TraitDeclId.Map.find tr.trait_decl_ref.binder_value.id
                    evidence.trait_decls).item_meta.span
                in
                let tr = normalize span tr in
                match tr.kind with
                | TraitImpl _ ->
                    let impl, _, _ = resolve span tr in
                    let copy_random_access =
                      impl_name impl = Some (iterator ^ "VecIntoIter")
                      && (match iterator_item tr with
                          | Some item -> copy_ty item
                          | None -> false)
                    in
                    let in_place_collect = reuse_decision span tr in
                    if Option.is_none in_place_collect && not copy_random_access
                    then None
                    else Some { Pure.in_place_collect; copy_random_access }
                | _ ->
                    (* Abstract dictionaries carry their native fields through
                       the actual argument. Collection calls still require their
                       complete obligations at the concrete dispatch boundary. *)
                    None
            in
            Hashtbl.add auxiliary_cache tr auxiliary;
            auxiliary)
    in
    (*
```
    *)
    let rec check_iterator span seen (tr : trait_ref) =
      let tr = normalize span tr in
      if generic_root tr then defer span (Iter tr) else
      let impl, args, _ = resolve span tr in
      if List.mem tr seen then
        reject span "recursive iterator evidence without a finite source";
      (* ```ocaml *)
      let collection_root = seen = [] in
      (* ``` *)
      let seen = tr :: seen in
      let check_base () = check_iterator span seen (one span iterator args) in
      (*
```ocaml
      *)
      (match reuse_source span [] tr with
       (* ```ocaml *)
       | Some (Some _) when collection_root && Option.is_none (reuse_decision span tr) ->
       (* ``` *)
           reject span "unresolved native in-place collection layout"
       | _ -> ());
      (*
```
      *)
      match impl_name impl with
      (* Sources. Lines (core str/iter.rs) is SplitInclusive's next mapped by
         LinesMap, with the default size_hint (0, None) and next-driven fold.
         Split<P>, RSplit<P> and SplitN<P> (core str/iter.rs,
         generate_pattern_iterators!) define only next (SplitInternal::next,
         resp. next_back, resp. SplitNInternal::next), so their size_hint is
         the default (0, None) and every consumer is next-driven, whatever the
         pattern P.
         BTree Keys/Values (alloc btree/map.rs) project Iter's next and forward
         its exact size_hint; their fold is the next-driven default. IntoValues
         projects IntoIter's next and forwards its exact size_hint alike; it
         is TrustedLen, so the collectors fold it with the next-driven
         default (its own last, next_back, is not a collector's consumer).
         option::Iter and option::IntoIter (core option.rs) define only next
         (Item::next is opt.take()) and the exact size_hint (len, Some(len));
         they are TrustedLen but not TrustedRandomAccess, so the collectors'
         TrustedLen path folds them with the next-driven default.
         RepeatWith (core sources/repeat_with.rs, rustc 1.95) defines next
         (Some of one repeater call), size_hint (usize::MAX, None) and
         try_fold (one repeater call and one fold call per step: the schedule
         of repeated next). It is TrustedLen and FusedIterator, not
         TrustedRandomAccess (modeled in IteratorSources.lean). Collected
         without a bound, its (_, None) TrustedLen hint makes the Vec
         collectors panic before any repeater call, and the model's repeated
         next does not end: neither has a result.
         vec::Drain (alloc vec/drain.rs, rustc 1.95, 152-163) defines only
         next (the inner slice iterator's next, read out of the vector) and
         size_hint (that slice iterator's exact hint); it is TrustedLen (250)
         and FusedIterator (253), but neither TrustedRandomAccess nor
         SourceIter (no in-place collection), so the collectors' TrustedLen
         path folds it with the next-driven default fold and every other
         consumer is next-driven. Its Drop (174-241) removes the whole
         drained range, exhausted or not, and moves the tail back: the
         vector given back is the same whichever consumer ran (modeled in
         VecDrain.lean, whose kept vector is fixed when the drain is
         created). *)
      | Some name when
          List.mem name
            (List.map (( ^ ) iterator)
               [ "SliceIter"; "ArrayIntoIter"; "VecIntoIter"; "BTreeIter";
                 "BTreeIntoIter"; "BTreeSetIntoIter"; "BTreeSetIter"; "Chunks"; "ChunksExact"; "Windows";
                 "Once"; "Chars"; "Lines"; "Split"; "RSplit"; "SplitN"; "BTreeKeys";
                 "BTreeValues"; "BTreeIntoValues"; "OptionIter"; "OptionIntoIter";
                 "VecDrain"; "RepeatWith" ]) -> ()
      (* SkipWhile (core skip_while.rs, rustc 1.95): next is the base's find
         with the flag-guarded predicate, size_hint (0, upper of the base),
         and fold/try_fold take one next while the flag is unset, then fold
         the base: the schedule of repeated next, over an admitted base. *)
      | Some name when
          List.mem name
            (List.map (( ^ ) iterator)
               [ "Mut"; "Map"; "Copied"; "Cloned"; "Enumerate";
                 "Filter"; "FilterMap"; "SkipWhile" ]) -> check_base ()
      (* Skip (core skip.rs, rustc 1.95): next and fold call the base's nth
         once (Map's default nth maps each skipped item), then go on with the
         base. Skip<I> is TrustedRandomAccessNoCoerce when I is, and its
         __iterator_get_unchecked runs the skipped prefix only at index 0
         (when I::MAY_HAVE_SIDE_EFFECT). In-place collection (alloc
         vec/in_place_collect.rs, rustc 1.95, 384-406) of such an iterator
         over a vec::IntoIter source reads indices 0..size() and nothing
         else: with n >= len, size() is 0 and no skipped item is mapped,
         while repeated next maps all of them. Reject a Skip whose base has
         an indexed side effect over a vec::IntoIter source. *)
      | Some name when name = iterator ^ "Skip" ->
          check_base ();
          let base = one span iterator args in
          if indexed_effects span base = Some true && vec_source span base then
            reject span
              "Skip over an iterator with callbacks and a vec::IntoIter \
               source: native in-place collection reads the indices \
               0..size() and never maps the skipped items when the skip \
               reaches the end, while repeated next maps each of them"
      (* Take (core take.rs, rustc 1.95): next is the base's next while n > 0
         (None after, without a call of the base). try_fold folds the base
         with a check that breaks right after the n-th item. fold and
         for_each (SpecTake, 261-320) do the same, except over a
         TrustedRandomAccess base: then they read the indices
         0..min(n, size()) of the base and nothing else. size_hint is
         (0, Some(0)) at n = 0, else the hint of the base capped by n.
         Take<I> is TrustedLen when I is, so the collectors fold it. The
         indexed fold has the schedule of repeated next when the base's
         next is its indexed access with the same callbacks
         (indexed_schedule). A Skip over callbacks has another schedule (no
         mapped prefix when the skip reaches the end): reject it. Every
         other consumer takes the first min(n, len) items of the base with
         the schedule of repeated next, over an admitted base (modeled in
         Core/Iter.lean). *)
      | Some name when name = iterator ^ "Take" ->
          check_base ();
          let base = one span iterator args in
          if random_access span base && not (indexed_schedule span base) then
            reject span
              "Take over a TrustedRandomAccess Skip whose base runs \
               callbacks: native collectors fold it by index over \
               min(n, size()), which maps no skipped item when the skip \
               reaches the end, while repeated next maps each of them"
      (* Chain::next exhausts a then b; size_hint is the saturating/checked sum
         of both hints; fold/try_fold fold a then b (core chain.rs). Both
         sides must therefore have the schedule of repeated next. *)
      | Some name when name = iterator ^ "Chain" -> (
          match List.filter (fun tr -> ref_name tr = Some iterator) args with
          | [ a; b ] ->
              check_iterator span seen a;
              check_iterator span seen b
          | _ -> reject span "missing or ambiguous Chain iterator evidence")
      (* Rev::next is next_back, fold is rfold, size_hint the inner hint
         (core rev.rs): the base must be a modeled double-ended iterator whose
         forward iterator is itself admitted. *)
      | Some name when name = iterator ^ "Rev" ->
          let double_ended_ref = one span double_ended args in
          let double_ended_impl, _, parents = resolve span double_ended_ref in
          if Option.is_none (impl_name double_ended_impl) then
            reject span "unmodeled DoubleEndedIterator under Rev";
          check_iterator span seen (one span iterator parents)
      (* FlatMap maps each outer item and exhausts its inner iterator in turn;
         its size_hint only combines the outer and inner hints (core
         flatten.rs, modeled in FlatMap.lean): check both iterators. *)
      | Some name when name = iterator ^ "FlatMap" ->
          check_iterator span seen (one span iterator args);
          check_into span seen (one span into_iterator args)
      (* Flatten<I> is FlattenCompat<I, U> with the outer Fuse<I> (core
         flatten.rs): next, fold, try_fold, count and advance_by exhaust the
         front inner, then convert each outer item with into_iter and exhaust
         it, then exhaust the back inner (left by next_back; the back methods
         run the same schedule from the back); size_hint combines the front
         and back inners' hints with the outer's (an upper bound only once
         the outer is exhausted, unless the inner has a constant size),
         OneShot inners (option::IntoIter, ...) pull one item each. It is
         FlatMap with an identity mapper (modeled in FlatMap.lean). Its
         clauses are the outer Iterator, the outer item's IntoIterator and
         that IntoIterator's own iterator: check the outer and the inner. *)
      | Some name when name = iterator ^ "Flatten" -> (
          match List.filter (fun tr -> ref_name tr = Some iterator) args with
          | [ outer; inner ] ->
              check_iterator span seen outer;
              check_into span seen (one span into_iterator args);
              check_iterator span seen inner
          | _ -> reject span "missing or ambiguous Flatten iterator evidence")
      (* Range and RangeInclusive (core iter/range.rs, rustc 1.95) of a std
         integer Step: exact size_hint from steps_between. RangeInclusive is
         TrustedLen (TrustedStep) but not TrustedRandomAccess: the collectors
         fold it, and its fold is its try_fold (impl_fold_via_try_fold!), which
         yields start, its successors and finally end without stepping past
         it, exactly the items of repeated next (modeled in
         IteratorSources.lean). A custom Step would run user callbacks. *)
      | Some name
        when name = iterator ^ "Range" || name = iterator ^ "RangeInclusive" ->
          let step_ref = one span step args in
          let step_impl, _, _ = resolve span step_ref in
          if not
               (List.mem (impl_name step_impl)
                  [ Some (prefix ^ "core.iter.range.StepUsize");
                    Some (prefix ^ "core.iter.range.StepI32") ])
          then reject span "custom range Step callbacks"
      (*
```ocaml
      *)
      | Some name when name = iterator ^ "StepBy" -> check_base ()
      (*
```
      *)
      (* The native Zip fold uses its complete consumer schedule. Copy
         specialization needs a typed proof for each owned vector source. *)
      | Some name when name = iterator ^ "Zip" -> (
          match List.filter (fun tr -> ref_name tr = Some iterator) args with
          | [ a; b ] ->
              check_iterator span seen a;
              check_iterator span seen b;
              (*
```ocaml
              *)
              check_indexed_copy span [] a;
              check_indexed_copy span [] b
              (*
```
              *)
          | _ -> reject span "missing or ambiguous Zip iterator evidence")
      (* A crate iterator that only defines next, and possibly size_hint
         (check_default_consumers): every native consumer (fold, try_fold,
         for_each, nth, and the collectors' next loop) is repeated next. The
         Vec collector (BTreeMap/BTreeSet collect into a Vec first,
         alloc/src/collections/btree/map.rs:2385) only calls size_hint to size
         capacity: alloc/src/vec/spec_from_iter_nested.rs:27 (with_capacity of
         lower + 1) and Vec::extend_desugared, alloc/src/vec/mod.rs:3907 (reserve
         of lower + 1), in rust-src 1.95.0-nightly-2026-02-07. The collected
         values therefore do not depend on the hint's value, and its lawfulness
         is not needed; allocation failure and capacity overflow are outside the
         value model (trust boundary). What native does observe is that
         size_hint is user code it calls: a default size_hint is the total, pure
         (0, None), an own one must be proved total (the obligation
         [<impl>.size_hint_total], which assumes the hints of the impl's
         Iterator clauses total: those arguments are checked here as well).
         The specializations a collector could select instead need unsafe
         impls: TrustedLen (spec_from_iter_nested.rs:51) with an exact hint only
         pre-sizes the same next/fold schedule, and with (_, None) promises more
         than usize::MAX items, where the native collector and the model both
         fail; TrustedRandomAccess dispatch calls __iterator_get_unchecked,
         which would be an override. FusedIterator only changes Fuse after
         exhaustion, which no admitted consumer polls. *)
      | None when crate_iterator impl ->
          if check_default_consumers span impl then
            List.iter
              (check_iterator span seen)
              (List.filter (fun tr -> ref_name tr = Some iterator) args)
      | _ ->
          reject span
            ("unreviewed iterator hint or collector specialization in "
            ^ Print.name_to_string (Print.crate_to_fmt_env evidence)
                impl.item_meta.name)
    and check_into span seen tr =
      let tr = normalize span tr in
      if generic_root tr then defer span (Into tr)
      else
        let _, _, parents = resolve span tr in
        check_iterator span seen (one span iterator parents)
    (* The admitted iterators that core 1.95 makes TrustedRandomAccess and
       whose Lean dictionary carries a full random access (is_full): slice
       Iter, Windows, Chunks and ChunksExact, integer ranges, and the adapters
       that preserve it. A generic dictionary is not known to have one. *)
    and random_access span (tr : trait_ref) =
      let tr = normalize span tr in
      if generic_root tr then false
      else
        let impl, args, _ = resolve span tr in
        match impl_name impl with
        | Some name
          when List.mem name
                 (List.map (( ^ ) iterator)
                    [ "SliceIter"; "Windows"; "Chunks"; "ChunksExact"; "Range" ]) ->
            true
        | Some name
          when List.mem name
                 (List.map (( ^ ) iterator)
                    [ "Map"; "Copied"; "Cloned"; "Enumerate"; "Skip" ]) ->
            random_access span (one span iterator args)
        | Some name when name = iterator ^ "Zip" -> (
            match List.filter (fun tr -> ref_name tr = Some iterator) args with
            | [ a; b ] -> random_access span a && random_access span b
            | _ -> false)
        | _ -> false
    (* For an iterator that may be TrustedRandomAccessNoCoerce (a vec::IntoIter
       of any element, a slice-like source or a std integer Range, and Map,
       Cloned, Copied, Enumerate, Skip and Zip of them), Some of its
       MAY_HAVE_SIDE_EFFECT: true for Map and Cloned (core map.rs 220,
       cloned.rs 134), that of the base for Copied, Enumerate and Skip, the
       disjunction for Zip. None for any other iterator. *)
    and indexed_effects span (tr : trait_ref) =
      let tr = normalize span tr in
      if generic_root tr then None
      else
        let impl, args, _ = resolve span tr in
        match impl_name impl with
        | Some name
          when List.mem name
                 (List.map (( ^ ) iterator)
                    [ "SliceIter"; "Windows"; "Chunks"; "ChunksExact"; "Range";
                      "VecIntoIter" ]) ->
            Some false
        | Some name when List.mem name (List.map (( ^ ) iterator) [ "Map"; "Cloned" ]) ->
            Option.map (fun _ -> true) (indexed_effects span (one span iterator args))
        | Some name
          when List.mem name (List.map (( ^ ) iterator) [ "Copied"; "Enumerate"; "Skip" ]) ->
            indexed_effects span (one span iterator args)
        | Some name when name = iterator ^ "Zip" -> (
            match List.filter (fun tr -> ref_name tr = Some iterator) args with
            | [ a; b ] -> (
                match (indexed_effects span a, indexed_effects span b) with
                | Some a, Some b -> Some (a || b)
                | _ -> None)
            | _ -> None)
        | _ -> None
    (* TrustedRandomAccess iterators (random_access) whose next yields their
       next indexed access with the same callbacks, and whose next past the
       end runs none. Slice-like sources and std integer ranges; Map,
       Copied, Cloned and Enumerate of one (their next and
       __iterator_get_unchecked apply the same function to the base's item);
       a Zip of two (its next is the indexed access of both sides below
       min(a.size(), b.size()), and None after it, core zip.rs 305-319); a
       Skip of one whose indexed access has no side effect (its next calls
       the base's nth, which then runs no callback). *)
    and indexed_schedule span (tr : trait_ref) =
      let tr = normalize span tr in
      (not (generic_root tr))
      &&
      let impl, args, _ = resolve span tr in
      match impl_name impl with
      | Some name
        when List.mem name
               (List.map (( ^ ) iterator)
                  [ "SliceIter"; "Windows"; "Chunks"; "ChunksExact"; "Range" ]) ->
          true
      | Some name
        when List.mem name
               (List.map (( ^ ) iterator) [ "Map"; "Copied"; "Cloned"; "Enumerate" ])
        ->
          indexed_schedule span (one span iterator args)
      | Some name when name = iterator ^ "Zip" -> random_access span tr
      | Some name when name = iterator ^ "Skip" ->
          indexed_effects span (one span iterator args) = Some false
      | _ -> false
    (* Whether the source of an in-place collection (the SourceIter chain:
       Map, Cloned, Copied, Enumerate, Skip and the left side of Zip) may be a
       vec::IntoIter, of any element type. *)
    and vec_source span (tr : trait_ref) =
      let tr = normalize span tr in
      (not (generic_root tr))
      &&
      let impl, args, _ = resolve span tr in
      match impl_name impl with
      | Some name when name = iterator ^ "VecIntoIter" -> true
      | Some name
        when List.mem name
               (List.map (( ^ ) iterator) [ "Map"; "Cloned"; "Copied"; "Enumerate"; "Skip" ])
        ->
          vec_source span (one span iterator args)
      | Some name when name = iterator ^ "Zip" -> (
          match List.filter (fun tr -> ref_name tr = Some iterator) args with
          | [ a; _ ] -> vec_source span a
          | _ -> false)
      | _ -> false
    in
    let check_into span tr = check_into span [] tr in
    (* A function owned by an earlier chunk defers its obligations to its
       callers here too: without its reviewed collection facts, a call that
       could instantiate them (any trait clause) is not admitted. *)
    let discharge span (callee : fun_decl) (generics : generic_args) =
      if
        SeparateCompilation.is_external (IdFun callee.def_id)
        && callee.generics.trait_clauses <> []
        && not (FunDeclId.Set.mem callee.def_id external_reviewed)
      then
        reject span
          ("the collection obligations of "
          ^ Print.name_to_string (Print.crate_to_fmt_env evidence)
              callee.item_meta.name
          ^ ", owned by an earlier chunk, are unknown: its manifest entry has \
             no reviewed collection facts");
      match FunDeclId.Map.find_opt callee.def_id !obligations with
      | None -> ()
      | Some required ->
          let required =
            instantiate span "a deferred collection obligation" (fun () ->
                let subst =
                  [%add_loc] Substitute.make_subst_from_generics (Some span)
                    callee.generics generics Self
                in
                List.map
                  (function
                    | Iter tr -> Iter (Substitute.trait_ref_substitute subst tr)
                    | Into tr -> Into (Substitute.trait_ref_substitute subst tr))
                  required)
          in
          List.iter
            (function
              | Iter tr -> check_iterator span [] tr
              | Into tr -> check_into span tr)
            required
    in
    let name_of (decl : fun_decl) =
      Print.name_to_string (Print.crate_to_fmt_env evidence) decl.item_meta.name
    in
    let rec root_clause (tr : trait_ref) =
      match tr.kind with
      | Clause (Free clause) -> Some (TraitClauseId.to_int clause)
      | ParentClause (inner, _) | ItemClause (inner, _, _) -> root_clause inner
      | _ -> None
    in
    let obligation_root = function Iter tr | Into tr -> root_clause tr in
    (* The number of trait clauses of an implementation: the generics of its
       methods start with its own, so that an obligation of a method rooted in a
       clause below it is on the implementation's parameters (impl-level), and
       one above it on the method's own (method-level). *)
    let impl_clauses (id : TraitImplId.id) =
      List.length (TraitImplId.Map.find id evidence.trait_impls).generics.trait_clauses
    in
    (* A method of a trait implementation is also called through generic
       dictionaries (a clause of the caller, later instantiated with the
       implementation), where [check_ptr] does not see the callee. Its
       impl-level obligations are discharged where the dictionary is built:
       every implementation reference of a body, and the dictionaries that its
       header implies (parent and associated-type clauses, trait arguments),
       which generic code reaches by projection. Its method-level obligations
       cannot be: see [dispatch_only]. Memoized per function and scan pass. *)
    let constructed : (FunDeclId.id option * trait_ref, unit) Hashtbl.t =
      Hashtbl.create 256
    in
    let dictionaries =
      object (self)
        inherit [_] iter_statement as super

        method! visit_trait_ref span tr =
          super#visit_trait_ref span tr;
          self#construct span tr

        (* An implementation that Charon did not translate has neither method
           bodies nor a header here. *)
        method construct span (tr : trait_ref) =
          match tr.kind with
          | TraitImpl reference
            when TraitImplId.Map.mem reference.id evidence.trait_impls
                 && not (Hashtbl.mem constructed (!current, tr)) ->
              Hashtbl.add constructed (!current, tr) ();
              let impl = TraitImplId.Map.find reference.id evidence.trait_impls in
              let clauses = List.length impl.generics.trait_clauses in
              let subst =
                instantiate span "an implementation dictionary" (fun () ->
                    [%add_loc] Substitute.make_subst_from_generics (Some span)
                      impl.generics reference.generics (TraitImpl reference))
              in
              List.iter
                (fun (_, (method_ref : fun_decl_ref binder)) ->
                  let id = method_ref.binder_value.id in
                  match FunDeclId.Map.find_opt id evidence.fun_decls with
                  | None -> ()
                  | Some callee -> (
                      if
                        clauses > 0
                        && SeparateCompilation.is_external (IdFun id)
                        && not (FunDeclId.Set.mem id external_reviewed)
                      then
                        reject span
                          ("the collection obligations of " ^ name_of callee
                         ^ ", owned by an earlier chunk, are unknown: its \
                            manifest entry has no reviewed collection facts");
                      match FunDeclId.Map.find_opt id !obligations with
                      | None -> ()
                      | Some required ->
                          (match callee.src with
                          | TraitImplItem (impl_ref, _, _, _)
                            when impl_ref.id = impl.def_id -> ()
                          | _ ->
                              reject span
                                ("the collection obligations of " ^ name_of callee
                               ^ ", which is not a method of its implementation's \
                                  own, cannot be instantiated with that \
                                  implementation's dictionary"));
                          List.iter
                            (fun obligation ->
                              match obligation_root obligation with
                              | Some clause when clause < clauses -> (
                                  match
                                    instantiate span
                                      "an implementation's collection obligation"
                                      (fun () ->
                                        match obligation with
                                        | Iter tr ->
                                            Iter (Substitute.trait_ref_substitute subst tr)
                                        | Into tr ->
                                            Into (Substitute.trait_ref_substitute subst tr))
                                  with
                                  | Iter tr -> check_iterator span [] tr
                                  | Into tr -> check_into span tr)
                              | _ -> ())
                            required))
                impl.methods;
              List.iter
                (fun parent ->
                  self#visit_trait_ref span (Substitute.trait_ref_substitute subst parent))
                impl.implied_trait_refs;
              self#visit_trait_decl_ref span
                (Substitute.trait_decl_ref_substitute subst impl.impl_trait)
          | _ -> ()
      end
    in
    (* A method-level obligation of a trait method's implementation: it would be
       lost when the method is called through a generic dictionary. The
       reviewed collectors are exempt: FromIterator::from_iter and Extend::extend
       through a generic dictionary are rejected ([needs_check], the extend
       dispatch of [check_ptr]). *)
    let dispatch_only (decl : fun_decl) (required : obligation list) =
      match decl.src with
      | TraitImplItem (impl_ref, trait, name, _) ->
          let exempt =
            match trait_name trait.id with
            | Some trait -> (trait = from_iterator && name = "from_iter")
                            || (trait = extend && name = "extend")
            | None -> false
          in
          (not exempt)
          &&
          let clauses = impl_clauses impl_ref.id in
          List.exists
            (fun obligation ->
              match obligation_root obligation with
              | Some clause -> clause >= clauses
              | None -> true)
            required
      | _ -> false
    in
    let modeled_collectors =
      List.map (( ^ ) prefix)
        [ "core.iter.traits.collect.FromIteratorVec";
          "core.iter.traits.collect.FromIteratorBTreeMap";
          "core.iter.traits.collect.FromIteratorBTreeSet";
          (* VecDeque's collector (alloc/src/collections/vec_deque/mod.rs:3640,
             spec_from_iter.rs): Vec::from_iter(iterator).into(), or, for a
             vec::IntoIter or vec_deque::IntoIter source, into_vecdeque,
             which keeps the remaining elements in order without callbacks:
             the Vec collector's schedule and items (VecDeque.lean) *)
          "core.iter.traits.collect.FromIteratorVecDeque";
          (* String's collector of chars (alloc/src/string.rs): String::new,
             then Extend<char>, which reserves the lower size bound (the
             capacity is not modeled, as for Vec) and pushes each char through
             for_each, i.e. the iterator's fold *)
          "core.iter.traits.collect.FromIteratorStringChar" ]
    in
    let rec needs_check span seen tr =
      let impl, args, _ = resolve span tr in
      if List.mem tr seen then
        reject span "recursive collector dictionary";
      let seen = tr :: seen in
      match impl_name impl with
      | Some name when List.mem name modeled_collectors -> true
      (* FromIterator for Result<V, E> and Option<V> (core result.rs,
         option.rs): iter::try_process runs V's collector over a GenericShunt
         of the source (modeled in ResultIter.lean), which drives the source
         through its try_fold and forwards its upper bound: check V's collector
         against the source. *)
      | Some name
        when List.mem name
               (List.map (( ^ ) prefix)
                  [ "core.iter.traits.collect.FromIteratorResult";
                    "core.iter.traits.collect.FromIteratorOption" ]) ->
          needs_check span seen (one span from_iterator args)
      | Some _ -> reject span "unreviewed modeled FromIterator dispatch"
      | None ->
          (* Its real Rust body is translated and independently checked below
             (or, owned by an earlier chunk, was checked there). A wrapper is
             not permission to ignore a generic collector call. *)
          (match List.assoc_opt "from_iter" impl.methods with
          | Some method_ref -> (
              let id = method_ref.binder_value.id in
              match (FunDeclId.Map.find id evidence.fun_decls).body with
              | StructuredBody _ -> FunDeclId.Map.mem id !obligations
              | _ when FunDeclId.Set.mem id external_reviewed ->
                  FunDeclId.Map.mem id !obligations
              | _ -> reject span "opaque custom FromIterator implementation")
          | None -> reject span "missing custom FromIterator implementation")
    in
    (* ```ocaml *)
    let check_collect_iterator span tr =
      check_iterator span [] tr;
      if !Config.print_error_diagnostics then
        Option.iter
          (fun id ->
            let descriptor ty =
              match NativeLayouts.descriptor evidence ty with
              | None -> "Unresolved complete Rust type"
              | Some json -> Yojson.Basic.to_string json in
            let source =
              match reuse_source span [] tr with
              | None -> "Unresolved SourceIter"
              | Some None -> "No vector SourceIter"
              | Some (Some ty) -> descriptor ty in
            let output = match iterator_item tr with
              | None -> "Unresolved output type"
              | Some ty -> descriptor ty in
            let state = match reuse_decision span tr with
              | None -> "unresolved"
              | Some false -> "proved fallback"
              | Some true -> "proved reuse" in
            Printf.eprintf
              "Collection contract checked:\ncaller function: %d\ncaller: %s\niterator: %s\nsource: %s\noutput: %s\nnative state: %s\n%!"
              (FunDeclId.to_int id)
              (Print.name_to_string (Print.crate_to_fmt_env evidence)
                (FunDeclId.Map.find id evidence.fun_decls).item_meta.name)
              (Print.trait_ref_to_string (Print.crate_to_fmt_env evidence) tr)
              source output state)
          !current
    in
    (* ``` *)
    let check_ptr span (ptr : fn_ptr) =
      let check_collect args =
        let target = one span from_iterator args.trait_refs in
        if needs_check span [] target then
          check_collect_iterator span
            (one span iterator args.trait_refs)
      in
      let check_collection_input args =
        check_into span (one span into_iterator args.trait_refs)
      in
      (match ptr.kind with
      | FunId (FRegular id) -> (
          match FunDeclId.Map.find_opt id evidence.fun_decls with
          | Some callee -> discharge span callee ptr.generics
          | None -> ())
      | TraitMethod (tr, name, _) -> (
          let tr = normalize span tr in
          match tr.kind with
          | TraitImpl reference -> (
              let reference = native_impl span reference in
              let impl = TraitImplId.Map.find reference.id evidence.trait_impls in
              match List.assoc_opt name impl.methods with
              | Some binder -> (
                  (* The binder's free variables are the implementation's
                     parameters and its bound ones the method's. Instantiate the
                     implementation under the binder first, then the method, as
                     Charon's skip_trait_refs_when_known does: the method
                     arguments are caller terms, whose free variables are the
                     caller's own and must not be substituted a second time. *)
                  let method_ref =
                    instantiate span "a collection method call" (fun () ->
                        let subst =
                          [%add_loc] Substitute.make_subst_from_generics
                            (Some span) impl.generics reference.generics
                            (TraitImpl reference)
                        in
                        let visitor = Substitute.st_substitute_visitor in
                        visitor#visit_binder visitor#visit_fun_decl_ref subst binder
                        |> Substitute.apply_args_to_binder ptr.generics
                             visitor#visit_fun_decl_ref)
                  in
                  match FunDeclId.Map.find_opt method_ref.id evidence.fun_decls with
                  | Some callee -> discharge span callee method_ref.generics
                  | None -> ())
              | None -> ())
          | _ -> ())
      | _ -> ());
      match ptr.kind with
      | FunId (FRegular id) ->
          let decl = FunDeclId.Map.find id crate.fun_decls in
          (match fun_name decl with
          | Some name when
              name = prefix ^ "core.iter.traits.iterator.Iterator.collect.default" ->
              check_collect ptr.generics
          | Some name when
              List.mem name
                (List.map (( ^ ) prefix)
                   [ "alloc.vec.FromIteratorVec.from_iter";
                     "alloc.collections.btree.map.FromIteratorBTreeMap.from_iter";
                     "alloc.collections.btree.set.FromIteratorBTreeSet.from_iter";
                     "alloc.collections.vec_deque.FromIteratorVecDeque.from_iter";
                     "alloc.vec.ExtendVec.extend";
                     "alloc.collections.btree.map.ExtendBTreeMap.extend";
                     "alloc.collections.btree.set.ExtendBTreeSet.extend" ]) ->
              check_collection_input ptr.generics
          | Some name
            when List.mem name
                   (List.map (( ^ ) prefix)
                      [ "core.result.FromIteratorResult.from_iter";
                        "core.option.FromIteratorOption.from_iter" ]) ->
              if needs_check span [] (one span from_iterator ptr.generics.trait_refs) then
                check_collection_input ptr.generics
          | _ -> ())
      | TraitMethod (tr, "from_iter", _) when ref_name tr = Some from_iterator ->
          if needs_check span [] tr then
            check_collection_input ptr.generics
      | TraitMethod (tr, "extend", _) when ref_name tr = Some extend ->
          let impl, _, _ = resolve span tr in
          (match impl_name impl with
          | Some name when name = prefix ^ "alloc.vec.ExtendVec" ->
              check_collection_input ptr.generics
          | Some _ -> reject span "unreviewed modeled Extend dispatch"
          | None -> ())
      | TraitMethod (tr, "collect", _) when ref_name tr = Some iterator ->
          let target = one span from_iterator ptr.generics.trait_refs in
          if needs_check span [] target then
            check_collect_iterator span tr
      | _ -> ()
    in
    (* Obligations only grow; rescan until every call and every dictionary
       construction has seen its callee's complete obligations. A rejected
       collector makes its function body untranslatable, exactly as an error in
       a body prepass does: it is reported and only that body is dropped. *)
    let failed = ref FunDeclId.Map.empty in
    let rec scan () =
      changed := false;
      Hashtbl.reset constructed;
      FunDeclId.Map.iter
        (fun id (decl : fun_decl) ->
          if Option.is_none (fun_name decl) && not (FunDeclId.Map.mem id !failed) then
            match decl.body with
            | StructuredBody body ->
                current := Some id;
                let visitor =
                  object
                    inherit [_] iter_statement as super

                    method! visit_fn_ptr span ptr =
                      check_ptr span ptr;
                      super#visit_fn_ptr span ptr

                    method! visit_trait_ref span tr =
                      super#visit_trait_ref span tr;
                      dictionaries#construct span tr

                    method! visit_statement _ st =
                      super#visit_statement st.span st
                  end
                in
                (try
                   [%recover_internal_errors] decl.item_meta.span (fun () ->
                       visitor#visit_block decl.item_meta.span body.body)
                 with CFailure e -> failed := FunDeclId.Map.add id e !failed);
                current := None
            | _ -> ())
        crate.fun_decls;
      if !changed then scan ()
    in
    scan ();
    FunDeclId.Map.iter
      (fun id required ->
        match FunDeclId.Map.find_opt id crate.fun_decls with
        | Some decl
          when (not (FunDeclId.Map.mem id !failed)) && dispatch_only decl required
          -> (
            try
              [%recover_internal_errors] decl.item_meta.span (fun () ->
                  reject decl.item_meta.span
                    ("the trait method implementation " ^ name_of decl
                   ^ " collects from an iterator given by its own generic \
                      parameters: its collection obligation cannot be \
                      discharged when it is called through a generic \
                      dictionary, where the implementation is unknown"))
            with CFailure e -> failed := FunDeclId.Map.add id e !failed)
        | _ -> ())
      !obligations;
    (* The facts of this chunk's declarations, as its own checks use them: a
       reviewed body has its obligations; a declaration without a body calls no
       collector ([discharge] admits calls to it), except the from_iter of a
       custom FromIterator, which is admitted only through its reviewed body
       ([needs_check] rejects it): no facts, so that a later chunk rejects it
       too. Rejected bodies have no facts. *)
    reviewed :=
      FunDeclId.Map.filter_map
        (fun id (decl : fun_decl) ->
          if FunDeclId.Map.mem id !failed then None
          else
            match (decl.body, decl.src) with
            | StructuredBody _, _ ->
                Some (Option.value ~default:[] (FunDeclId.Map.find_opt id !obligations))
            | _, TraitImplItem (_, trait, "from_iter", _)
              when trait_name trait.id = Some from_iterator ->
                None
            | _ -> Some [])
        crate.fun_decls;
    let fun_decls =
      FunDeclId.Map.mapi
        (fun id (decl : fun_decl) ->
          match FunDeclId.Map.find_opt id !failed with
          | None -> decl
          | Some e ->
              let name =
                Print.name_to_string
                  (Print.crate_to_fmt_env evidence)
                  decl.item_meta.name
              in
              [%save_error] decl.item_meta.span
                ("Ignoring the body of '" ^ name
               ^ "' because of previous error");
              let msg =
                format_error_message_with_file_line e.file e.line e.span
                  e.msg
              in
              { decl with body = ErrorBody { span = decl.item_meta.span; msg } })
        crate.fun_decls
    in
    { crate with fun_decls }
