open Types
open LlbcAst

(** Input positions whose final state belongs to a canonical model result. *)
let for_method name method_name =
  match (name, method_name) with
  | "_root_.Aeneas.Std.core.ops.function.FnOnce", "call_once"
  | "_root_.Aeneas.Std.core.ops.function.FnOnceSharedMutArg", "call_once"
  | "_root_.Aeneas.Std.core.ops.function.FnMut", "call_mut"
  | "_root_.Aeneas.Std.core.ops.function.FnMutSharedMutArg", "call_mut" ->
      Some [ 0 ]
  | "_root_.Aeneas.Std.core.ops.function.Fn", "call"
  | "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator", "size_hint"
  | "_root_.Aeneas.Std.core.iter.traits.exact_size.ExactSizeIterator", "len" ->
      Some []
  | ( "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator",
      ("next" | "nth" | "advance_by") )
  | ( "_root_.Aeneas.Std.core.iter.traits.double_ended.DoubleEndedIterator",
      ("next_back" | "nth_back" | "advance_back_by") ) -> Some [ 0 ]
  | ( "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator",
      ( "any" | "all" | "find" | "find_map" | "position" | "rposition"
      | "min_by_key" | "reduce" | "for_each" | "try_for_each" | "eq" | "ne" ) )
  | ( "_root_.Aeneas.Std.core.iter.traits.double_ended.DoubleEndedIterator",
      "rfind" ) -> Some [ 0; 1 ]
  | "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator", ("fold" | "try_fold")
  | ( "_root_.Aeneas.Std.core.iter.traits.double_ended.DoubleEndedIterator",
      ("rfold" | "try_rfold") ) -> Some [ 0; 2 ]
  | ( "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator",
      ("collect" | "count" | "sum" | "product" | "max" | "min" | "unzip") )
  | "_root_.Aeneas.Std.core.iter.traits.collect.FromIterator", "from_iter"
  | "_root_.Aeneas.Std.core.iter.traits.accum.Sum", "sum"
  | "_root_.Aeneas.Std.core.iter.traits.accum.Product", "product" ->
      Some [ 0 ]
  | "_root_.Aeneas.Std.core.iter.traits.collect.Extend", "extend" ->
      Some [ 0; 1 ]
  | _ -> None

let rec has_hidden_state (crate : crate) seen ty =
  if List.mem ty seen then false
  else
    match ty with
    | TVar _ -> true
    | TRef _ | TFnDef _ -> false
    | TAdt { id; generics } ->
        let fields =
          match id with
          | TAdtId id -> (
              let decl = TypeDeclId.Map.find id crate.type_decls in
              match decl.kind with
              | Struct _ ->
                  Substitute.type_decl_get_instantiated_field_types decl None
                    generics
              | _ -> generics.types)
          | _ -> generics.types
        in
        List.exists (has_hidden_state crate (ty :: seen)) fields
    | TArray (ty, _) | TSlice ty -> has_hidden_state crate (ty :: seen) ty
    | _ -> false

(** The model of a trait impl's trait, as call sites resolve it. A remaining
    specialization (last name element [PeInstantiated]) is modeled only by the
    schema model its instantiation matches (e.g. [FnOnceMutArg] for
    [FnOnce<(&mut T,)>]), never by the generic record's contract. *)
let trait_model_name (crate : crate) (trait_decl : trait_decl) =
  Option.map
    (fun (info : Pure.builtin_trait_decl_info) -> info.extract_name)
    (ExtractBuiltin.find_trait_decl_info
       (NameMatcher.ctx_from_crate crate)
       trait_decl.item_meta.name)

(** Only symbolic bodies can supply the additional authoritative state outputs.
    Once a method needs hidden generic state, preserve all its owned state
    inputs, including a concrete receiver modified alongside its callback.
    The shared-mutable-argument FnOnce parent also retains concrete consumed
    closure state. Its result cannot use the unchanged input as a substitute. *)
let for_decl (crate : crate) (decl : fun_decl) =
  match SeparateCompilation.external_fun_facts decl.def_id with
  | Some facts -> facts.state_inputs
  | None -> (
      if Config.backend () <> Config.Lean then []
      else
        match (decl.src, decl.body) with
        | TraitImplItem (_, tr, method_name, _), StructuredBody _ ->
            let trait_decl = TraitDeclId.Map.find tr.id crate.trait_decls in
            let indices =
              Option.value ~default:[]
                (Option.bind (trait_model_name crate trait_decl) (fun name ->
                     for_method name method_name))
            in
            let owned =
              List.filter
                (fun index ->
                  match List.nth decl.signature.inputs index with
                  | TRef _ -> false
                  | _ -> true)
                indices
            in
            let consumed_parent =
              method_name = "call_once"
              && trait_model_name crate trait_decl
                 = Some "_root_.Aeneas.Std.core.ops.function.FnOnceSharedMutArg"
            in
            if consumed_parent ||
              List.exists
                (fun index ->
                  has_hidden_state crate []
                    (List.nth decl.signature.inputs index))
                owned
            then owned
            else []
        | _ -> [])

(** A translated body can be used as a canonical state boundary only when its
    native signature contributes no concrete mutable-borrow continuations.
    Inspect instantiated fields, not just type arguments: a nongeneric record
    can itself contain a mutable reference. Unknown layouts are not evidence
    that the native ABI is empty. *)
let rec has_no_native_mutable_abi (crate : crate) seen ty =
  if List.mem ty seen then false
  else
    let check = has_no_native_mutable_abi crate (ty :: seen) in
    match ty with
    | TRef (_, _, RMut) -> false
    | TRef (_, ty, RShared) | TArray (ty, _) | TSlice ty -> check ty
    | TAdt { id = TAdtId id; generics } -> (
        match TypeDeclId.Map.find_opt id crate.type_decls with
        | None -> false
        | Some decl ->
            let fields =
              match decl.kind with
              | Struct _ ->
                  Some
                    (Substitute.type_decl_get_instantiated_field_types decl None
                       generics)
              | Enum variants ->
                  Some
                    (List.concat
                       (List.mapi
                          (fun index _ ->
                            Substitute.type_decl_get_instantiated_field_types
                              decl
                              (Some (VariantId.of_int index))
                              generics)
                          variants))
              | Opaque -> (
                  match
                    ExtractBuiltin.NameMatcherMap.find_opt
                      (NameMatcher.ctx_from_crate crate)
                      decl.item_meta.name
                      (ExtractBuiltin.builtin_types_map ())
                  with
                  | Some info when info.mut_regions = [] -> Some generics.types
                  | _ -> None)
              | _ -> None
            in
            Option.fold ~none:false ~some:(List.for_all check) fields)
    | TAdt { id = TTuple | TBuiltin (TBox | TStr); generics } ->
        List.for_all check generics.types
    | TVar _ | TLiteral _ | TNever | TRawPtr _ | TFnDef _ | TFnPtr _ -> true
    | _ -> false

(** Return the complete canonical owned-state contract, not merely the subset
    which happens to be owned. Borrowed receivers and native backward results
    must keep their original region-indexed ABI. *)
let canonical_body_state_inputs (crate : crate) (decl : fun_decl) =
  match SeparateCompilation.external_fun_facts decl.def_id with
  | Some facts -> facts.canonical_body
  | None -> (
      let states = for_decl crate decl in
      match (decl.src, decl.body) with
      | TraitImplItem (_, tr, method_name, _), StructuredBody _ -> (
          let trait_decl = TraitDeclId.Map.find tr.id crate.trait_decls in
          match
            Option.bind (trait_model_name crate trait_decl) (fun name ->
                for_method name method_name)
          with
          | Some indices
            when indices <> [] && indices = states
                 && (!Config.simplify_merged_fwd_backs
                    || decl.generics.regions = [])
                 && List.for_all
                      (has_no_native_mutable_abi crate [])
                      (decl.signature.output :: decl.signature.inputs) ->
              Some indices
          | _ -> None)
      | _ -> None)
