(** Separate compilation of a workspace into chunks forming one Lean
    environment.

    Every item is identified across chunks by a {e key}: its kind and its
    structural Rust name, printed without any LLBC item id (instantiated path
    elements included), so that the key of an item is the same in every LLBC
    which contains it. A chunk extracted with [-emit-manifest] records, for
    every declaration it emits, its key, the Lean module which owns it, its Lean
    names, a fingerprint of its translated interface, and the facts that the
    translation of callers derives from its body. A later chunk given this
    manifest with [-external] keeps the LLBC declarations of these items (to
    translate the uses) but does not emit them: it checks that its own view of
    their interfaces is the one of the owner and imports the owner modules.

    Opaque functions which are not listed in a manifest remain unknown external
    definitions, which fail closed exactly as without these options.

    A chunk with errors writes no manifest, except in diagnostic runs
    ([-diagnostic-manifest], never with [-abort-on-error]): its manifest then
    lists the declarations it emitted and is marked incomplete, and only
    diagnostic runs accept incomplete manifests. *)

open Types
open LlbcAst

let log = Logging.translate_log

(** A deferred collection obligation of a function (see
    [CollectionContracts]): at every call, the function's own trait clause
    [clause], projected through the parent clauses [parents] (innermost first),
    must resolve to a reviewed iterator, or, if [into], to an IntoIterator whose
    iterator is reviewed. *)
type collection_obligation = { into : bool; clause : int; parents : int list }

(** Facts about a function that the translation of its callers (and its own
    signature) derives from its body. External functions may be opaque in a
    later chunk: they use the owner's facts. *)
type fun_facts = {
  can_fail : bool;
  stateful : bool;
  can_diverge : bool;
  is_rec : bool;
  state_inputs : int list;
      (** See [ModelStateInputs.for_decl] (input positions whose final state is
          an output of the translated signature) *)
  canonical_body : int list option;
      (** See [ModelStateInputs.canonical_body_state_inputs] *)
  collection_obligations : collection_obligation list option;
      (** The deferred collection obligations of a function that
          [CollectionContracts] saw ([Some []]: none, as for a declaration
          without a body). [None]: its body was rejected, it is the opaque
          from_iter of a custom FromIterator, or its obligations are not clause
          paths; the calls that could instantiate them are then rejected, as
          without a manifest. Absent from manifests written before this field,
          which therefore read as [None]. *)
}

(** Evidence that a trait implementation is a reviewed derived [Ord] or
    [PartialOrd] implementation of a non-generic type (see [SortContracts]).
    Only the chunk which emits the implementation records it, from its own LLBC
    view. The LLBC of a later chunk can contain the type without its
    implementations. That chunk uses the evidence only after
    [external_derived_order] checks it against the other manifest entries.

    [Translate] then checks the view of the type in that chunk against the
    owner's. [type_fingerprint] is the fingerprint of the type entry when the
    owner wrote its manifest. For [Ord], [partial_ord_impl_key] is the key of
    the [PartialOrd] implementation of its supertrait clause. *)
type sort_order_impl = {
  type_key : string;
  type_fingerprint : string;
  trait_name : string;
  partial_ord_impl_key : string option;
}

(** A derived implementation which this chunk reviewed: its evidence without
    the type fingerprint. [write_manifest] takes the fingerprint from the
    entry of the type. *)
type sort_order_candidate = {
  candidate_type_key : string;
  candidate_trait_name : string;
  candidate_partial_ord_impl_key : string option;
}

type entry = {
  key : string;
  lean_module : string;  (** The Lean module which emits the declaration *)
  lean_names : string list;
      (** The top-level Lean names of the declaration, the main one first
          (function declarations also emit their loops) *)
  fingerprint : string;
      (** Digest of the translated interface (see [Translate]) *)
  facts : fun_facts option;
      (** Functions and globals (facts of the initializer) *)
  methods : string list option;
      (** Trait declarations: the methods which are fields of the Lean
          structure; trait implementations: the methods which they define *)
  members : members option;
      (** Trait declarations and implementations (absent from the manifests
          which predate them) *)
  sort_order : sort_order_impl option;
      (** Trait implementations: the reviewed derived-order evidence. Older
          manifests and the other implementations have none. *)
}

(** The interface of a trait declaration or implementation, member by member:
    the partially monomorphized copies of a foreign trait keep the methods
    which their chunk uses, so that another chunk may see a copy with only some
    of the methods of the owner's (see [Translate.sc_check_external_views]). *)
and members = {
  header : string;
      (** Digest of the interface without the methods *)
  method_fingerprints : string list;
      (** Trait declarations: the digests of the signatures of the [methods],
          in the same order (implementations: empty, their methods are
          functions with their own entries) *)
}

let manifest_version = 1

(** Incomplete manifests ([-diagnostic-manifest]) have their own version, so
    that readers which predate them reject them as unsupported instead of
    consuming them. *)
let incomplete_manifest_version = 2

(** {1 Canonical names} *)

let canonical_env : Charon.Print.fmt_env option ref = ref None

let path_elem_to_string (env : Charon.Print.fmt_env) (e : path_elem) : string =
  match e with
  | PeInstantiated binder ->
      (* Contrary to [Charon.Print.path_elem_to_string], also print the trait
         references of the instantiation: they are part of its identity. *)
      let env =
        Charon.PrintUtils.fmt_env_push_generics_and_preds env
          binder.binder_params
      in
      let params, trait_refs =
        Charon.Print.generic_args_to_strings env binder.binder_value
      in
      "<" ^ String.concat ", " params ^ ">["
      ^ String.concat ", " trait_refs
      ^ "]"
  | _ -> Charon.Print.path_elem_to_string env e

let name_to_string_with (env : Charon.Print.fmt_env) (name : name) : string =
  String.concat "::" (List.map (path_elem_to_string env) name)

(** The structural Rust name of an item, independent of the LLBC ids. *)
let canonical_name_to_string (name : name) : string =
  match !canonical_env with
  | Some env -> name_to_string_with env name
  | None ->
      [%craise_opt_span] None
        "Internal error: the canonical naming environment is not initialized"

let item_meta (crate : crate) (id : item_id) : item_meta option =
  match id with
  | IdType id ->
      Option.map
        (fun (d : type_decl) -> d.item_meta)
        (TypeDeclId.Map.find_opt id crate.type_decls)
  | IdFun id ->
      Option.map
        (fun (d : fun_decl) -> d.item_meta)
        (FunDeclId.Map.find_opt id crate.fun_decls)
  | IdGlobal id ->
      Option.map
        (fun (d : global_decl) -> d.item_meta)
        (GlobalDeclId.Map.find_opt id crate.global_decls)
  | IdTraitDecl id ->
      Option.map
        (fun (d : trait_decl) -> d.item_meta)
        (TraitDeclId.Map.find_opt id crate.trait_decls)
  | IdTraitImpl id ->
      Option.map
        (fun (d : trait_impl) -> d.item_meta)
        (TraitImplId.Map.find_opt id crate.trait_impls)

let kind_to_string (id : item_id) : string =
  match id with
  | IdType _ -> "type"
  | IdFun _ -> "fun"
  | IdGlobal _ -> "global"
  | IdTraitDecl _ -> "trait_decl"
  | IdTraitImpl _ -> "trait_impl"

let item_key (crate : crate) (id : item_id) : string option =
  Option.map
    (fun (meta : item_meta) ->
      kind_to_string id ^ " " ^ canonical_name_to_string meta.name)
    (item_meta crate id)

(** {1 State} *)

(** Entries loaded from the [-external] manifests, by key *)
let loaded : (string, entry) Hashtbl.t = Hashtbl.create 1024

(** Keys of the loaded entries, by Lean name *)
let loaded_names : (string, string) Hashtbl.t = Hashtbl.create 1024

(** External items of the current crate *)
let externals : (item_id, entry) Hashtbl.t = Hashtbl.create 1024

(** Entries emitted by the current chunk, by key, in emission order *)
let emitted : (string, entry) Hashtbl.t = Hashtbl.create 1024

let emitted_order : string list ref = ref []

(** The derived implementations which this chunk reviewed, by key (see
    [register_sort_order_impl]) *)
let sort_order_candidates : (string, sort_order_candidate) Hashtbl.t =
  Hashtbl.create 32

(** The external types whose view in this chunk an admitted sort depends on
    (see [require_sort_order_view]). [Translate] checks each of them against
    the entry of its owner. *)
let sort_order_views : item_id list ref = ref []

(** Whether an incomplete manifest was loaded (only with [-diagnostic-manifest]):
    the manifest of this chunk is then incomplete too *)
let loaded_incomplete : bool ref = ref false

(** The Lean module of the file currently being generated *)
let current_module : string option ref = ref None

let enabled () : bool = !Config.canonical_names
let is_external (id : item_id) : bool = Hashtbl.mem externals id
let external_entry (id : item_id) : entry option = Hashtbl.find_opt externals id

let external_fun_facts (id : FunDeclId.id) : fun_facts option =
  match Hashtbl.find_opt externals (IdFun id) with
  | Some { facts = Some facts; _ } -> Some facts
  | _ -> None

let external_collection_obligations (id : FunDeclId.id) :
    collection_obligation list option =
  Option.bind (external_fun_facts id) (fun facts -> facts.collection_obligations)

(** {1 Manifests} *)

(** Register an error. The run fails (and writes no complete manifest), but all
    the inconsistencies are reported, even with [-abort-on-error]. *)
let fail (msg : string) : unit = Errors.push_error __FILE__ __LINE__ None msg

let has_prefix (prefix : string) (s : string) : bool =
  String.length s >= String.length prefix
  && String.sub s 0 (String.length prefix) = prefix

let has_suffix (suffix : string) (s : string) : bool =
  let n = String.length s in
  let k = String.length suffix in
  n >= k && String.sub s (n - k) k = suffix

let ord_trait = "core::cmp::Ord"
let partial_ord_trait = "core::cmp::PartialOrd"

(** The end of the key of an implementation of [trait_name] for the type of
    key [type_key]. Only the module path of the implementation comes before it.
    The two forms are [::{core::cmp::Ord for T}] and
    [::{core::cmp::PartialOrd<T> for T}]. *)
let sort_order_impl_key_suffix (type_key : string) (trait_name : string) :
    string option =
  if not (has_prefix "type " type_key) then None
  else
    let ty = String.sub type_key 5 (String.length type_key - 5) in
    if trait_name = ord_trait then Some ("::{core::cmp::Ord for " ^ ty ^ "}")
    else if trait_name = partial_ord_trait then
      Some ("::{core::cmp::PartialOrd<" ^ ty ^ "> for " ^ ty ^ "}")
    else None

(** Whether [impl_key] is the key of an implementation of [trait_name] for the
    type of key [type_key] *)
let names_sort_order_impl (type_key : string) (trait_name : string)
    (impl_key : string) : bool =
  has_prefix "trait_impl " impl_key
  &&
  match sort_order_impl_key_suffix type_key trait_name with
  | Some suffix -> has_suffix suffix impl_key
  | None -> false

(** Whether the evidence of the implementation [impl_key] names an
    implementation of its trait for its type. The evidence of an [Ord]
    implementation must also name a [PartialOrd] implementation for that
    type. *)
let sort_order_well_formed (impl_key : string) (type_key : string)
    (trait_name : string) (partial_ord_impl_key : string option) : bool =
  names_sort_order_impl type_key trait_name impl_key
  &&
  match partial_ord_impl_key with
  | Some key ->
      trait_name = ord_trait
      && names_sort_order_impl type_key partial_ord_trait key
  | None -> trait_name = partial_ord_trait

(** [SortContracts] calls this function for each derived [Ord] or [PartialOrd]
    implementation which it reviewed in the LLBC of this chunk.
    [write_manifest] attaches the evidence to the entry of the implementation
    if this chunk emits it. This function records no evidence whose keys do
    not name the implementation of the trait for the type. A later chunk then
    rejects each sort which needs that evidence. *)
let register_sort_order_impl ~(impl_key : string) ~(type_key : string)
    ~(trait_name : string) ~(partial_ord_impl_key : string option) : unit =
  if
    enabled ()
    && sort_order_well_formed impl_key type_key trait_name partial_ord_impl_key
  then
    let candidate =
      {
        candidate_type_key = type_key;
        candidate_trait_name = trait_name;
        candidate_partial_ord_impl_key = partial_ord_impl_key;
      }
    in
    match Hashtbl.find_opt sort_order_candidates impl_key with
    | Some previous when previous <> candidate ->
        fail
          ("Separate compilation: two different derived-order reviews of ["
         ^ impl_key ^ "]")
    | _ -> Hashtbl.replace sort_order_candidates impl_key candidate

let collection_obligation_to_json (o : collection_obligation) : Yojson.Basic.t =
  `Assoc
    [
      ("into", `Bool o.into);
      ("clause", `Int o.clause);
      ("parents", `List (List.map (fun i -> `Int i) o.parents));
    ]

let facts_to_json (f : fun_facts) : Yojson.Basic.t =
  `Assoc
    ([
       ("can_fail", `Bool f.can_fail);
       ("stateful", `Bool f.stateful);
       ("can_diverge", `Bool f.can_diverge);
       ("is_rec", `Bool f.is_rec);
       ("state_inputs", `List (List.map (fun i -> `Int i) f.state_inputs));
       ( "canonical_body",
         match f.canonical_body with
         | None -> `Null
         | Some l -> `List (List.map (fun i -> `Int i) l) );
     ]
    @
    (* Written only when known, so that the manifests of chunks without
       reviewed collectors keep their earlier form. *)
    match f.collection_obligations with
    | None -> []
    | Some l ->
        [ ("collection_obligations", `List (List.map collection_obligation_to_json l)) ])

let sort_order_impl_to_json (s : sort_order_impl) : Yojson.Basic.t =
  `Assoc
    [
      ("type_key", `String s.type_key);
      ("type_fingerprint", `String s.type_fingerprint);
      ("trait", `String s.trait_name);
      ( "partial_ord_impl_key",
        match s.partial_ord_impl_key with
        | None -> `Null
        | Some key -> `String key );
    ]

let entry_to_json (e : entry) : Yojson.Basic.t =
  let strings l = `List (List.map (fun s -> `String s) l) in
  `Assoc
    ([
       ("key", `String e.key);
       ("module", `String e.lean_module);
       ("names", strings e.lean_names);
       ("fingerprint", `String e.fingerprint);
     ]
    @ (match e.facts with
      | None -> []
      | Some f -> [ ("facts", facts_to_json f) ])
    @ (match e.methods with
      | None -> []
      | Some l -> [ ("methods", strings l) ])
    @ (match e.sort_order with
      | None -> []
      | Some s -> [ ("sort_order", sort_order_impl_to_json s) ])
    @
    match e.members with
    | None -> []
    | Some m ->
        [
          ( "members",
            `Assoc
              [
                ("header", `String m.header);
                ("method_fingerprints", strings m.method_fingerprints);
              ] );
        ])

exception Malformed of string

let sort_order_impl_of_json (entry_key : string) (js : Yojson.Basic.t) :
    sort_order_impl =
  let open Yojson.Basic.Util in
  let type_key = to_string (member "type_key" js) in
  let type_fingerprint = to_string (member "type_fingerprint" js) in
  let trait_name = to_string (member "trait" js) in
  let partial_ord_impl_key =
    match member "partial_ord_impl_key" js with
    | `Null -> None
    | key -> Some (to_string key)
  in
  if
    type_fingerprint = ""
    || not
         (sort_order_well_formed entry_key type_key trait_name
            partial_ord_impl_key)
  then
    raise
      (Malformed
         ("the derived-order evidence of [" ^ entry_key
        ^ "] does not name an Ord or PartialOrd implementation of its type"))
  else { type_key; type_fingerprint; trait_name; partial_ord_impl_key }

let facts_of_json (js : Yojson.Basic.t) : fun_facts =
  let open Yojson.Basic.Util in
  let ints js = List.map to_int (to_list js) in
  let obligation js =
    {
      into = to_bool (member "into" js);
      clause = to_int (member "clause" js);
      parents = ints (member "parents" js);
    }
  in
  {
    can_fail = to_bool (member "can_fail" js);
    stateful = to_bool (member "stateful" js);
    can_diverge = to_bool (member "can_diverge" js);
    is_rec = to_bool (member "is_rec" js);
    state_inputs = ints (member "state_inputs" js);
    canonical_body =
      (match member "canonical_body" js with
      | `Null -> None
      | l -> Some (ints l));
    collection_obligations =
      (match member "collection_obligations" js with
      | `Null -> None
      | l -> Some (List.map obligation (to_list l)));
  }

let entry_of_json (js : Yojson.Basic.t) : entry =
  let open Yojson.Basic.Util in
  let strings js = List.map to_string (to_list js) in
  let key = to_string (member "key" js) in
  let lean_names = strings (member "names" js) in
  if lean_names = [] then raise (Malformed "an entry has no Lean name");
  {
    key;
    lean_module = to_string (member "module" js);
    lean_names;
    fingerprint = to_string (member "fingerprint" js);
    facts =
      (match member "facts" js with
      | `Null -> None
      | f -> Some (facts_of_json f));
    methods =
      (match member "methods" js with
      | `Null -> None
      | l -> Some (strings l));
    members =
      (match member "members" js with
      | `Null -> None
      | m ->
          Some
            {
              header = to_string (member "header" m);
              method_fingerprints = strings (member "method_fingerprints" m);
            });
    sort_order =
      (match member "sort_order" js with
      | `Null -> None
      | s -> Some (sort_order_impl_of_json key s));
  }

let namespace_to_json () : Yojson.Basic.t =
  match !Config.namespace with
  | None -> `Null
  | Some ns -> `String ns

(** Register the entries of a manifest. The same key may be listed by several
    manifests only if it has the same owner (e.g., a manifest including an
    earlier one); two owners for one key, or one Lean name for two keys, is a
    duplicate emission. *)
let add_loaded (file : string) (e : entry) : unit =
  (match Hashtbl.find_opt loaded e.key with
  | Some prev when prev.lean_module <> e.lean_module ->
      fail
        ("Separate compilation: duplicate emission of [" ^ e.key
       ^ "] by the Lean modules " ^ prev.lean_module ^ " and " ^ e.lean_module
       ^ " (manifest " ^ file ^ ")")
  | Some prev when prev <> e ->
      fail
        ("Separate compilation: inconsistent manifest entries for [" ^ e.key
       ^ "] (manifest " ^ file ^ ")")
  | _ -> Hashtbl.replace loaded e.key e);
  List.iter
    (fun n ->
      match Hashtbl.find_opt loaded_names n with
      | Some key when key <> e.key ->
          fail
            ("Separate compilation: duplicate emission of the Lean name " ^ n
           ^ " for [" ^ key ^ "] and [" ^ e.key ^ "] (manifest " ^ file ^ ")")
      | _ -> Hashtbl.replace loaded_names n e.key)
    e.lean_names

let load_manifest (file : string) : unit =
  try
    let js = Yojson.Basic.from_file file in
    let open Yojson.Basic.Util in
    let version = to_int (member "version" js) in
    let complete =
      if version = manifest_version then true
      else if
        version = incomplete_manifest_version
        && member "complete" js = `Bool false
      then false
      else raise (Malformed "unsupported version")
    in
    if member "namespace" js <> namespace_to_json () then
      fail
        ("Separate compilation: the manifest " ^ file
       ^ " was generated for a different -namespace");
    if complete || !Config.diagnostic_manifest then (
      if not complete then loaded_incomplete := true;
      List.iter
        (fun e -> add_loaded file (entry_of_json e))
        (to_list (member "entries" js)))
    else
      fail
        ("Separate compilation: the manifest " ^ file
       ^ " is incomplete (written by a diagnostic run with \
          -diagnostic-manifest): only runs with -diagnostic-manifest may use it"
      )
  with
  | Yojson.Json_error msg | Malformed msg ->
      fail ("Separate compilation: malformed manifest " ^ file ^ ": " ^ msg)
  | Yojson.Basic.Util.Type_error (msg, _) ->
      fail ("Separate compilation: malformed manifest " ^ file ^ ": " ^ msg)
  | Sys_error msg ->
      fail
        ("Separate compilation: cannot read the manifest " ^ file ^ ": " ^ msg)

(** Initialize the canonical names, load the manifests and resolve the external
    items of the crate. To be called on the crate loaded from the LLBC. *)
let init (crate : crate) : unit =
  if enabled () then (
    canonical_env := Some (Charon.Print.crate_to_fmt_env crate);
    List.iter load_manifest !Config.external_manifests;
    if Hashtbl.length loaded > 0 then (
      let resolve (id : item_id) : entry option =
        match item_key crate id with
        | Some key -> (
            match Hashtbl.find_opt loaded key with
            | Some e ->
                Hashtbl.replace externals id e;
                Some e
            | None -> None)
        | None -> None
      in
      TypeDeclId.Map.iter
        (fun id _ -> ignore (resolve (IdType id)))
        crate.type_decls;
      FunDeclId.Map.iter
        (fun id (d : fun_decl) ->
          (* Globals initializers are emitted with (and resolved through) their
             global *)
          if Option.is_none d.is_global_initializer then
            ignore (resolve (IdFun id)))
        crate.fun_decls;
      GlobalDeclId.Map.iter
        (fun id (d : global_decl) ->
          match resolve (IdGlobal id) with
          | Some e -> Hashtbl.replace externals (IdFun d.init) e
          | None -> ())
        crate.global_decls;
      TraitDeclId.Map.iter
        (fun id _ -> ignore (resolve (IdTraitDecl id)))
        crate.trait_decls;
      TraitImplId.Map.iter
        (fun id _ -> ignore (resolve (IdTraitImpl id)))
        crate.trait_impls;
      log#linfo
        (lazy
          ("Separate compilation: "
          ^ string_of_int (Hashtbl.length externals)
          ^ " external items")));
    (* An external function carries the owner's facts *)
    Hashtbl.iter
      (fun id (e : entry) ->
        match (id, e.facts) with
        | IdFun _, None ->
            fail
              ("Separate compilation: the manifest entry of [" ^ e.key
             ^ "] has no function facts")
        | _ -> ())
      externals)

(** {1 Derived sort orders} *)

(** The evidence of the earlier chunks for the external type [id]. The result
    is the pair of the keys of its derived [Ord] implementation and of the
    [PartialOrd] implementation of its supertrait clause. Else it is the
    reason for a rejection. Each evidence entry must record the fingerprint of
    the type entry in the manifests. Exactly one entry must record an [Ord]
    implementation. Each [PartialOrd] entry must be the implementation which it
    names.

    The caller checks the implementations and methods of its own LLBC against
    these keys. [Translate] checks the view of the type in this chunk against
    its entry (see [require_sort_order_view]). *)
let external_derived_order (id : item_id) : (string * string, string) result =
  match external_entry id with
  | None ->
      Error "has no Ord impl in the crate, and no -external manifest emits it"
  | Some t when not (has_prefix "type " t.key) ->
      Error ("has the external entry [" ^ t.key ^ "], which is not a type")
  | Some t -> (
      let evidence =
        List.sort compare
          (Hashtbl.fold
             (fun key (e : entry) found ->
               match e.sort_order with
               | Some s when s.type_key = t.key -> (key, s) :: found
               | _ -> found)
             loaded [])
      in
      let with_trait name =
        List.filter
          (fun (_, (s : sort_order_impl)) -> s.trait_name = name)
          evidence
      in
      let stale =
        List.filter
          (fun (_, (s : sort_order_impl)) -> s.type_fingerprint <> t.fingerprint)
          evidence
      in
      let partials = with_trait partial_ord_trait in
      let owner = " (owner module " ^ t.lean_module ^ ")" in
      match (stale, with_trait ord_trait) with
      | (key, s) :: _, _ ->
          Error
            ("has stale derived-order evidence: the entry of [" ^ key
           ^ "] records the type fingerprint " ^ s.type_fingerprint
           ^ ", but the manifests emit [" ^ t.key ^ "] with the fingerprint "
           ^ t.fingerprint ^ owner)
      | [], [] ->
          Error
            ("has no Ord impl in the crate, and no manifest records \
              derived-order evidence for an Ord impl of [" ^ t.key ^ "]"
           ^ owner)
      | [], (_ :: _ :: _ as ords) ->
          Error
            ("has several Ord impls with derived-order evidence: "
            ^ String.concat ", " (List.map (fun (k, _) -> "[" ^ k ^ "]") ords))
      | [], (ord_key, (ord : sort_order_impl)) :: [] -> (
          match ord.partial_ord_impl_key with
          | None ->
              Error
                ("has Ord evidence in [" ^ ord_key
               ^ "] without a PartialOrd implementation")
          | Some partial_key -> (
              match
                ( Hashtbl.mem loaded partial_key,
                  List.mem_assoc partial_key partials,
                  List.filter (fun (k, _) -> k <> partial_key) partials )
              with
              | false, _, _ ->
                  Error
                    ("needs the PartialOrd impl [" ^ partial_key
                   ^ "], which the evidence of [" ^ ord_key
                   ^ "] names, but no manifest emits it")
              | true, false, _ ->
                  Error
                    ("needs derived-order evidence for the PartialOrd impl ["
                   ^ partial_key ^ "], which the evidence of [" ^ ord_key
                   ^ "] names, but its manifest entry has none")
              | true, true, (other, _) :: _ ->
                  Error
                    ("has PartialOrd evidence in [" ^ other
                   ^ "], but the Ord evidence of [" ^ ord_key ^ "] names ["
                   ^ partial_key ^ "]")
              | true, true, [] -> Ok (ord_key, partial_key))))

(** Record that an admitted sort depends on the view of the external type
    [id] in this chunk *)
let require_sort_order_view (id : item_id) : unit =
  if not (List.mem id !sort_order_views) then
    sort_order_views := id :: !sort_order_views

(** Only the owner chunk translates the body of an external function. *)
let hide_external_bodies (crate : crate) : crate =
  if Hashtbl.length externals = 0 then crate
  else
    let fun_decls =
      FunDeclId.Map.map
        (fun (f : fun_decl) ->
          if is_external (IdFun f.def_id) then { f with body = OpaqueBody }
          else f)
        crate.fun_decls
    in
    { crate with fun_decls }

(** The owner modules of the given external items, sorted *)
let modules_of (ids : item_id list) : string list =
  List.sort_uniq compare
    (List.filter_map
       (fun id -> Option.map (fun e -> e.lean_module) (external_entry id))
       ids)

(** {1 Emission} *)

(** Record a declaration emitted by the current chunk. Function declarations are
    recorded once per emitted Lean definition (loops included): the Lean names
    accumulate. *)
let record (e : entry) : unit =
  match Hashtbl.find_opt emitted e.key with
  | None ->
      Hashtbl.replace emitted e.key e;
      emitted_order := e.key :: !emitted_order
  | Some prev ->
      if prev.lean_module <> e.lean_module then
        fail
          ("Separate compilation: [" ^ e.key
         ^ "] is emitted by the Lean modules " ^ prev.lean_module ^ " and "
         ^ e.lean_module);
      let names =
        prev.lean_names
        @ List.filter (fun n -> not (List.mem n prev.lean_names)) e.lean_names
      in
      Hashtbl.replace emitted e.key { prev with lean_names = names }

(** Reject the declarations of this chunk which are already emitted by another
    module. *)
let check_emitted () : unit =
  List.iter
    (fun key ->
      let e = Hashtbl.find emitted key in
      (match Hashtbl.find_opt loaded key with
      | Some prev ->
          fail
            ("Separate compilation: duplicate emission of [" ^ key
           ^ "], already emitted by " ^ prev.lean_module)
      | None -> ());
      List.iter
        (fun n ->
          match Hashtbl.find_opt loaded_names n with
          | Some other ->
              let owner = (Hashtbl.find loaded other).lean_module in
              fail
                ("Separate compilation: duplicate emission of the Lean name "
               ^ n ^ " for [" ^ key ^ "]: already emitted by " ^ owner
               ^ " for [" ^ other ^ "]")
          | None -> ())
        e.lean_names)
    (List.rev !emitted_order)

(** Write the manifest of the declarations emitted by this chunk. A manifest is
    complete only if the chunk has no error and uses no incomplete manifest;
    incomplete manifests are written only with [-diagnostic-manifest]. *)
let write_manifest (file : string) ~(complete : bool) : unit =
  let find_entry (key : string) : entry option =
    match Hashtbl.find_opt emitted key with
    | Some e -> Some e
    | None -> Hashtbl.find_opt loaded key
  in
  let sort_order_for (e : entry) : sort_order_impl option =
    match Hashtbl.find_opt sort_order_candidates e.key with
    | None -> None
    | Some candidate -> (
        match find_entry candidate.candidate_type_key with
        | None -> None
        | Some type_entry ->
            let partial_ord_impl_key =
              match
                ( candidate.candidate_trait_name,
                  candidate.candidate_partial_ord_impl_key )
              with
              | "core::cmp::PartialOrd", None -> Some None
              | "core::cmp::Ord", Some key -> Some (Some key)
              | _ -> None
            in
            Option.map
              (fun partial_ord_impl_key ->
                {
                  type_key = candidate.candidate_type_key;
                  type_fingerprint = type_entry.fingerprint;
                  trait_name = candidate.candidate_trait_name;
                  partial_ord_impl_key;
                })
              partial_ord_impl_key)
  in
  let entries =
    List.map
      (fun key ->
        let e = Hashtbl.find emitted key in
        entry_to_json { e with sort_order = sort_order_for e })
      (List.rev !emitted_order)
  in
  let header =
    if complete then [ ("version", `Int manifest_version) ]
    else
      [
        ("version", `Int incomplete_manifest_version); ("complete", `Bool false);
      ]
  in
  let js =
    `Assoc
      (header
      @ [ ("namespace", namespace_to_json ()); ("entries", `List entries) ])
  in
  Yojson.Basic.to_file file js;
  log#linfo
    (lazy
      ("Separate compilation: wrote the "
      ^ (if complete then "" else "incomplete ")
      ^ "manifest " ^ file ^ " ("
      ^ string_of_int (List.length entries)
      ^ " declarations)"))
