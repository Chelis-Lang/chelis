(** Admission for the models of [<[T]>::sort_unstable],
    [<[T]>::sort_unstable_by], [<[T]>::sort], [<[T]>::sort_by] and
    [<[T]>::sort_by_key] (Aeneas.Std.Sort).

    Natively, the order of the elements that compare [Equal], and the sequence of
    comparisons, are unspecified. The models (a stable sort) return the native
    result exactly when the comparison is pure and total and returns [Equal] only
    for indistinguishable values: then every sorted permutation is the same list.

    [sort_unstable] compares with the element type's [Ord] ([T::lt]). By
    coherence a type has a single [Ord] impl, so this is a property of the
    element type. It holds for the integer types, [bool], [char], [str],
    [String] and [BigUint], for references, boxes, slices, arrays, tuples,
    [Option] and [Reverse] of such types, and for non-generic crate types whose
    [Ord] and [PartialOrd] impls are derived and whose fields all have such
    types. The derived [cmp] and [partial_cmp] compare the variants, then the
    fields in order. The models call [lt] of the [PartialOrd] impl, as the
    native entry points do. Charon marks each derived impl with
    [#[automatically_derived]], which it keeps as an unknown attribute.

    The LLBC of a later chunk can contain such a type without its impls, which
    an earlier chunk owns. Then the evidence in the manifest of that chunk
    replaces the attribute (see [SeparateCompilation.external_derived_order]).
    Each [Ord] or [PartialOrd] impl of the type in this chunk must be an
    external, derived impl which the evidence names. Each of their methods in
    this chunk must belong to such an impl. [Translate] checks the fields of
    the type in this chunk against the owner's. Without that evidence, the
    sort is rejected.

    [sort_unstable_by] is admitted when its comparator is a closure whose body
    returns [Ord::cmp(a, b)] (ascending) or [Ord::cmp(b, a)] (descending) of its
    two arguments, for an element type as above; the model sorts with that
    comparator. Every other comparator, and every call to [sort_unstable_by_key]
    (equal keys may hide distinct elements), is rejected with
    [E_UNSUPPORTED_SORT].

    The stable sorts ([sort], [sort_by], [sort_by_key]) keep the input order of
    the elements that compare [Equal]: natively their result is unique when the
    comparison is a pure total preorder (only the sequence of comparisons is
    unspecified), and unspecified, or a panic, otherwise.

    [sort] compares with [T::lt]: it is admitted on the element types above,
    whose [lt] is a strict total order.

    [sort_by] is admitted when its comparator is a closure whose body returns
    [Ord::cmp] of the same key of its two arguments (in either order): a key
    only reads its argument, as a shared reference to or a copy of a place
    reached by struct and tuple fields and dereferences of shared references
    and boxes, a tuple of keys, or a shared reference to a local holding a key;
    and the key type is one of the types above, whose [Ord] is a total order.

    [sort_by_key] compares [f(a).lt(&f(b))], recomputing the keys. It is
    admitted when the key function [f] is a closure that captures only shared
    references (its body does not assign, mutably borrow or move a captured
    variable, which would capture it by mutable reference or by value;
    interior mutability has no model, so it mutates nothing) or a function
    item or pointer (no state), and its key type [K] is one of the types
    above: then [f] is a function of the element (the model threads its
    unchanged state), a panic in [f] on an element happens in both sorts (a
    sort of two or more elements compares every element), and the comparison
    is a total preorder.

    Every other comparator, key function or type is rejected with
    [E_UNSUPPORTED_SORT]. *)

open Types
open Expressions
open LlbcAst
open Errors

(** A step of the path from a [sort_by] comparator's argument to a key place. *)
type key_step = KDeref | KField of field_proj_kind * FieldId.id

(** The value of a local of a [sort_by] comparator, computed from its arguments
    (0 and 1) without computation: a shared reference to the place of argument
    [arg] at [path] ([KRef (arg, [])] is the argument itself), a copy of that
    place, a tuple, or a shared reference to a local holding a key. *)
type key =
  | KRef of int * key_step list
  | KCopy of int * key_step list
  | KTuple of key list
  | KRefLocal of key

(** A place of a [sort_by] comparator: inside argument [arg] at [path], or a
    local holding a key. *)
type key_place = InArg of int * key_step list | Owned of key

(** Check sort admission using storage summaries of the current declarations. *)
let check (infos : TypesAnalysis.type_infos) (crate : crate) : crate =
  if Config.backend () <> Config.Lean then crate
  else
    let env = Print.crate_to_fmt_env crate in
    let mctx = NameMatcher.ctx_from_crate crate in
    let config =
      {
        NameMatcher.map_vars_to_vars = true;
        match_with_trait_decl_refs = Config.match_patterns_with_trait_decl_refs;
      }
    in
    let pattern s = NameMatcher.parse_pattern s in
    let sort_unstable = pattern "core::slice::{[@T]}::sort_unstable" in
    let sort_by = pattern "core::slice::{[@T]}::sort_unstable_by" in
    let sort_by_key = pattern "core::slice::{[@T]}::sort_unstable_by_key" in
    let stable_sort = pattern "alloc::slice::{[@T]}::sort" in
    let stable_sort_by = pattern "alloc::slice::{[@T]}::sort_by" in
    let stable_sort_by_key = pattern "alloc::slice::{[@T]}::sort_by_key" in
    let matches pat (name : name) = NameMatcher.match_name mctx config pat name in
    let name_of (name : name) = Print.name_to_string env name in
    let total_types =
      "integers, bool, char, str, String, BigUint, references, boxes, slices, \
       arrays, tuples, Option, Reverse and #[derive(PartialOrd, Ord)] types of \
       those"
    in
    let unstable_message reason =
      "E_UNSUPPORTED_SORT: " ^ reason
      ^ ". The sort_unstable models are admitted only where the comparison is \
         Ord::cmp on a type whose Equal holds exactly for indistinguishable \
         values (" ^ total_types
      ^ "), where every sorted permutation is the same list."
    in
    let reject span reason = [%craise] span (unstable_message reason) in
    let stable_message reason =
      "E_UNSUPPORTED_SORT: " ^ reason
      ^ ". The sort_by model is admitted only where the comparator returns \
         Ord::cmp of the same key of both elements, projected from each without \
         computation (fields, dereferences, tuples), on a key type whose Ord is \
         a total order (" ^ total_types
      ^ "): then the comparator is a total preorder and the stable order is \
         unique."
    in
    let reject_stable span reason = [%craise] span (stable_message reason) in
    let sort_message reason =
      "E_UNSUPPORTED_SORT: " ^ reason
      ^ ". The sort model is admitted only on an element type whose Ord is a \
         total order (" ^ total_types
      ^ "): then T::lt is a strict total order and the stable order is unique."
    in
    let key_message reason =
      "E_UNSUPPORTED_SORT: " ^ reason
      ^ ". The sort_by_key model is admitted only where the key function is a \
         closure that captures only shared references (it mutates nothing) or \
         a function item, and the key type's Ord is a total order ("
      ^ total_types
      ^ "): then the key is a function of the element, the comparison is a \
         total preorder and the stable order is unique."
    in
    let reject_key span reason = [%craise] span (key_message reason) in
    let trait_name id =
      name_of (TraitDeclId.Map.find id crate.trait_decls).item_meta.name
    in
    let derived (impl : trait_impl) =
      List.exists
        (function
          | Meta.AttrUnknown { path = "automatically_derived"; args = None } ->
              true
          | _ -> false)
        impl.item_meta.attr_info.attributes
    in
    let ord_impls (adt : TypeDeclId.id) =
      TraitImplId.Map.fold
        (fun impl_id (impl : trait_impl) found ->
          if trait_name impl.impl_trait.id <> "core::cmp::Ord" then found
          else
            match impl.impl_trait.generics.types with
            | [ TAdt { id = TAdtId impl_adt; _ } ] when impl_adt = adt ->
                (impl_id, impl) :: found
            | _ -> found)
        crate.trait_impls []
    in
    (* Resolve the exact PartialOrd implementation referenced by Ord's
       supertrait clause. The identity, not just the trait name, is needed by
       separate compilation. *)
    let partial_ord_impl (impl : trait_impl) =
      let refs =
        List.filter
          (fun (tr : trait_ref) ->
            trait_name tr.trait_decl_ref.binder_value.id
            = "core::cmp::PartialOrd")
          impl.implied_trait_refs
      in
      match refs with
      | [ { kind = TraitImpl impl_ref; _ } ] ->
          Option.map
            (fun partial -> (impl_ref.id, partial))
            (TraitImplId.Map.find_opt impl_ref.id crate.trait_impls)
      | _ -> None
    in
    let partial_ord_self_is (adt : TypeDeclId.id) (impl : trait_impl) =
      trait_name impl.impl_trait.id = "core::cmp::PartialOrd"
      &&
      match impl.impl_trait.generics.types with
      | TAdt { id = TAdtId impl_adt; _ } :: _ -> impl_adt = adt
      | _ -> false
    in
    let non_generic_type (adt : TypeDeclId.id) =
      match TypeDeclId.Map.find_opt adt crate.type_decls with
      | Some decl ->
          decl.generics.types = [] && decl.generics.const_generics = []
      | None -> false
    in
    let register_order_facts () =
      if SeparateCompilation.enabled () then (
        let register impl_id adt trait_name partial_ord_impl_key =
          match
            ( SeparateCompilation.item_key crate (IdTraitImpl impl_id),
              SeparateCompilation.item_key crate (IdType adt) )
          with
          | Some impl_key, Some type_key ->
              SeparateCompilation.register_sort_order_impl ~impl_key ~type_key
                ~trait_name ~partial_ord_impl_key
          | _ -> ()
        in
        TraitImplId.Map.iter
          (fun impl_id (impl : trait_impl) ->
            if
              not (SeparateCompilation.is_external (IdTraitImpl impl_id))
              && derived impl
              && trait_name impl.impl_trait.id = "core::cmp::PartialOrd"
            then
              match impl.impl_trait.generics.types with
              | TAdt { id = TAdtId adt; _ } :: _ when non_generic_type adt ->
                  register impl_id adt "core::cmp::PartialOrd" None
              | _ -> ())
          crate.trait_impls;
        TraitImplId.Map.iter
          (fun impl_id (impl : trait_impl) ->
            if
              not (SeparateCompilation.is_external (IdTraitImpl impl_id))
              && derived impl
              && trait_name impl.impl_trait.id = "core::cmp::Ord"
            then
              match impl.impl_trait.generics.types with
              | [ TAdt { id = TAdtId adt; _ } ] when non_generic_type adt -> (
                  match partial_ord_impl impl with
                  | Some (partial_id, partial)
                    when derived partial && partial_ord_self_is adt partial ->
                      let partial_key =
                        SeparateCompilation.item_key crate
                          (IdTraitImpl partial_id)
                      in
                      Option.iter
                        (fun partial_ord_impl_key ->
                          register impl_id adt "core::cmp::Ord"
                            (Some partial_ord_impl_key))
                        partial_key
                  | _ -> ())
              | _ -> ())
          crate.trait_impls)
    in
    register_order_facts ();
    (* The evidence of the earlier chunks for an external type without an Ord
       impl in this chunk, checked against the LLBC of this chunk (see the
       header). The result of each type is kept. *)
    let external_orders = Hashtbl.create 8 in
    let external_order (adt : TypeDeclId.id) : (unit, string) result =
      let trait_name_opt id =
        Option.map
          (fun (d : trait_decl) -> name_of d.item_meta.name)
          (TraitDeclId.Map.find_opt id crate.trait_decls)
      in
      let is_self (ty : ty) =
        match ty with
        | TAdt tref -> tref.id = TAdtId adt
        | _ -> false
      in
      (* The expected key of an impl of [trait_id] whose type arguments are
         [types], if it is an Ord impl or a PartialOrd<T> impl of the type *)
      let expected_impl ord_key partial_key trait_id (types : ty list) =
        match (trait_name_opt trait_id, types) with
        | Some "core::cmp::Ord", self_ty :: [] when is_self self_ty ->
            Some ord_key
        | Some "core::cmp::PartialOrd", self_ty :: rhs :: []
          when is_self self_ty && is_self rhs ->
            Some partial_key
        | _ -> None
      in
      let check ord_key partial_key =
        let impl_error =
          TraitImplId.Map.fold
            (fun impl_id (impl : trait_impl) found ->
              match
                ( found,
                  expected_impl ord_key partial_key impl.impl_trait.id
                    impl.impl_trait.generics.types )
              with
              | Some _, _ | None, None -> found
              | None, Some expected ->
                  let key =
                    SeparateCompilation.item_key crate (IdTraitImpl impl_id)
                  in
                  if
                    key = Some expected
                    && SeparateCompilation.is_external (IdTraitImpl impl_id)
                    && derived impl
                  then None
                  else
                    Some
                      ("has the impl "
                      ^ Option.value key ~default:"<unnamed>"
                      ^ " in this chunk, which is not the external derived \
                         impl [" ^ expected
                      ^ "] of the owner evidence"))
            crate.trait_impls None
        in
        let method_error =
          FunDeclId.Map.fold
            (fun fid (f : fun_decl) found ->
              match (found, f.src) with
              | None, TraitImplItem (_, trait_ref, method_name, _) -> (
                  match
                    expected_impl ord_key partial_key trait_ref.id
                      trait_ref.generics.types
                  with
                  | None -> None
                  | Some expected ->
                      let path =
                        String.sub expected 11 (String.length expected - 11)
                      in
                      let expected_fun = "fun " ^ path ^ "::" ^ method_name in
                      let key = SeparateCompilation.item_key crate (IdFun fid) in
                      if key = Some expected_fun then None
                      else
                        Some
                          ("has the method "
                          ^ Option.value key ~default:"<unnamed>"
                          ^ " in this chunk, which is not the method ["
                          ^ expected_fun ^ "] of the owner evidence"))
              | _ -> found)
            crate.fun_decls None
        in
        match (impl_error, method_error) with
        | Some why, _ | None, Some why -> Stdlib.Error why
        | None, None ->
            let () = SeparateCompilation.require_sort_order_view (IdType adt) in
            Stdlib.Ok ()
      in
      match Hashtbl.find_opt external_orders adt with
      | Some result -> result
      | None ->
          let result =
            match SeparateCompilation.external_derived_order (IdType adt) with
            | Stdlib.Error why -> Stdlib.Error why
            | Ok (ord_key, partial_key) -> check ord_key partial_key
          in
          let () = Hashtbl.replace external_orders adt result in
          result
    in
    (* Generic std types whose [Ord] and [PartialOrd] are total orders with
       [Equal] exactly for indistinguishable values when their type arguments'
       are: [Option] (derived: [None] first, then the payloads) and [Reverse]
       (the payloads' order, reversed). *)
    let reviewed_generic = [ "core::option::Option"; "core::cmp::Reverse" ] in
    (* Non-generic types with such hand-written impls: [String] (its bytes, as
       [str]) and [BigUint] (num-bigint 0.4.6 biguint.rs: the digits carry no
       leading zero, and [cmp] compares their counts, then the digits from the
       most significant, the numeric order; [partial_cmp] is [Some (cmp)]). *)
    let reviewed_total = [ "alloc::string::String"; "num_bigint::biguint::BigUint" ] in
    (* [visiting]: the crate types under examination (a recursive type is
       structural if its other fields are). *)
    let rec structural_with message span visiting (ty : ty) : unit =
      let structural = structural_with message in
      let unsupported why =
        [%craise] span
          (message ("the type " ^ Print.ty_to_string env ty ^ " " ^ why))
      in
      match ty with
      | TLiteral (TInt _ | TUInt _ | TBool | TChar) -> ()
      | TLiteral (TFloat _) -> unsupported "has no total order"
      | TRef (_, inner, _) | TSlice inner | TArray (inner, _) ->
          (* Slices and arrays: lexicographic, then by length *)
          structural span visiting inner
      | TAdt { id = TTuple; generics } | TAdt { id = TBuiltin TBox; generics } ->
          List.iter (structural span visiting) generics.types
      | TAdt { id = TBuiltin TStr; _ } -> ()
      | TAdt { id = TAdtId id; generics } -> (
          let decl = TypeDeclId.Map.find id crate.type_decls in
          let name = name_of decl.item_meta.name in
          if List.mem name reviewed_total then ()
          else if List.mem name reviewed_generic && generics.const_generics = []
          then List.iter (structural span visiting) generics.types
          else if List.mem id visiting then ()
          else if generics.types <> [] || generics.const_generics <> [] then
            unsupported "is generic"
          else
          let recurse_fields () =
            let fields =
              match decl.kind with
              | Struct fields -> fields
              | Enum variants ->
                  List.concat_map (fun (v : variant) -> v.fields) variants
              | _ -> unsupported "is not a struct or an enum"
            in
            List.iter
              (fun (field : field) ->
                structural span (id :: visiting) field.field_ty)
              fields
          in
          match ord_impls id with
          | [] -> (
              match external_order id with
              | Stdlib.Ok () -> recurse_fields ()
              | Stdlib.Error why -> unsupported why)
          | [ (_, impl) ] when not (derived impl) ->
              unsupported
                "has an Ord impl without #[automatically_derived] (a \
                 hand-written Equal may hold between distinct values)"
          | [ (_, impl) ] -> (
              match partial_ord_impl impl with
              | Some (_, partial)
                when derived partial && partial_ord_self_is id partial ->
                  recurse_fields ()
              | Some _ ->
                  unsupported
                    "has a PartialOrd impl without #[automatically_derived] \
                     for Ord's exact supertrait implementation (its lt may \
                     disagree with the derived cmp)"
              | None -> unsupported "has no exact PartialOrd impl in the crate")
          | _ -> unsupported "has multiple Ord impls in the crate")
      | _ -> unsupported "is not a reviewed Ord type"
    in
    let structural = structural_with unstable_message in
    (* Whether a call target is [Ord::cmp] (of any impl: the argument types fix
       the implementing type). *)
    let is_ord_cmp (ptr : fn_ptr) =
      match ptr.kind with
      | TraitMethod (tr, "cmp", _) ->
          trait_name tr.trait_decl_ref.binder_value.id = "core::cmp::Ord"
      | FunId (FRegular id) -> (
          match (FunDeclId.Map.find id crate.fun_decls).src with
          | TraitImplItem (_, trait_ref, "cmp", _) ->
              trait_name trait_ref.id = "core::cmp::Ord"
          | _ -> false)
      | _ -> false
    in
    (* The comparator of [sort_unstable_by] over [elem]: the [FnMut] impl [tr]
       must be a closure's, whose [call_mut] body, apart from storage markers
       and references to the unit metadata (the metadata of the reborrows),
       only moves or reborrows the two arguments (fields 0 and 1 of the tupled
       arguments) and returns [Ord::cmp] of them, in either order. The closure
       state is never read. *)
    (* The body of the [call_mut] method of the closure whose [FnMut] impl is
       [tr]. *)
    let closure_call_mut span message (tr : trait_ref) =
      let unsupported why = [%craise] span (message why) in
      let impl_ref =
        match tr.kind with
        | TraitImpl impl_ref -> impl_ref
        | _ -> unsupported "is not a closure"
      in
      let impl = TraitImplId.Map.find impl_ref.id crate.trait_impls in
      let is_closure_impl =
        match impl.impl_trait.generics.types with
        | TAdt { id = TAdtId id; _ } :: _ -> (
            match (TypeDeclId.Map.find id crate.type_decls).src with
            | ClosureItem { fn_mut_impl = Some fn_mut; _ } ->
                fn_mut.binder_value.id = impl_ref.id
            | _ -> false)
        | _ -> false
      in
      if not is_closure_impl then unsupported "is not a closure";
      let call_mut =
        match List.assoc_opt "call_mut" impl.methods with
        | Some method_ref -> method_ref.binder_value.id
        | None -> unsupported "has no call_mut"
      in
      let body =
        match (FunDeclId.Map.find call_mut crate.fun_decls).body with
        | StructuredBody body when body.locals.arg_count = 2 -> body
        | _ -> unsupported "has no body"
      in
      body
    in
    (* The key function of [sort_by_key], by its [FnMut] impl [tr]: a closure,
       whose [FnMut] impl this is, that captures only shared references, or the
       built-in impl of a function item or pointer (no state). Either is a
       function of its argument. The closure kind is no evidence (rustc takes
       the [FnMut] of the expected bound for a closure passed to [sort_by_key]),
       but the capture modes are: a closure body that assigns, mutably borrows
       or moves a captured variable captures it by mutable reference or by
       value, and nothing is mutable behind a shared reference (interior
       mutability has no model). *)
    let pure_key_function span (tr : trait_ref) =
      let unsupported why =
        reject_key span ("sort_by_key: the key function " ^ why)
      in
      match tr.kind with
      | BuiltinOrAuto ((BuiltinFnMut | BuiltinFn), _, _) -> ()
      | TraitImpl impl_ref -> (
          let impl = TraitImplId.Map.find impl_ref.id crate.trait_impls in
          match impl.impl_trait.generics.types with
          | TAdt { id = TAdtId id; _ } :: _ -> (
              let decl = TypeDeclId.Map.find id crate.type_decls in
              match (decl.src, decl.kind) with
              | ClosureItem { fn_mut_impl = Some fn_mut; _ }, Struct captures
                when fn_mut.binder_value.id = impl_ref.id ->
                  List.iter
                    (fun (capture : field) ->
                      match capture.field_ty with
                      | TRef (_, _, RShared) -> ()
                      | ty ->
                          unsupported
                            ("is a closure that captures a "
                            ^ Print.ty_to_string env ty
                            ^ " (by mutable reference or by value): its keys \
                               and final state may depend on the sequence of \
                               calls"))
                    captures
              | _ -> unsupported "is not a closure or a function item")
          | _ -> unsupported "is not a closure or a function item")
      | _ -> unsupported "is not a closure or a function item"
    in
    let comparator span (elem : ty) (tr : trait_ref) =
      let unsupported why =
        reject span ("sort_unstable_by: the comparator " ^ why)
      in
      let body =
        closure_call_mut span
          (fun why -> unstable_message ("sort_unstable_by: the comparator " ^ why))
          tr
      in
      let tupled_args = LocalId.of_int 2 in
      let return_local = LocalId.of_int 0 in
      (* The locals holding a reference to argument 0 or 1, and the locals
         holding a reference to the unit metadata global (the pre-pass
         decompose_global_accesses introduces them for the metadata operand of
         the reborrows [&*a]). *)
      let origins = ref LocalId.Map.empty in
      let unit_refs = ref LocalId.Set.empty in
      let is_unit_metadata (gref : global_decl_ref) =
        gref.id = crate.unit_metadata.id
      in
      let unit_metadata_operand = function
        | Copy { kind = PlaceGlobal gref; _ } -> is_unit_metadata gref
        | Copy { kind = PlaceProjection ({ kind = PlaceLocal id; _ }, Deref); _ }
          ->
            LocalId.Set.mem id !unit_refs
        | _ -> false
      in
      let place_origin (place : place) =
        match place.kind with
        | PlaceLocal id -> LocalId.Map.find_opt id !origins
        | PlaceProjection
            ({ kind = PlaceLocal id; _ }, Field (ProjTuple 2, field))
          when id = tupled_args ->
            Some (FieldId.to_int field)
        | _ -> None
      in
      let rvalue_origin = function
        | Use (Move place | Copy place) -> place_origin place
        | RvRef ({ kind = PlaceProjection (inner, Deref); _ }, BShared, metadata)
          when unit_metadata_operand metadata ->
            place_origin inner
        | _ -> None
      in
      let argument (operand : operand) =
        match operand with
        | Move place | Copy place -> (
            match
              (place_origin place, TypesUtils.ty_erase_regions infos place.ty)
            with
            | Some index, TRef (_, pointee, RShared)
              when pointee = TypesUtils.ty_erase_regions infos elem ->
                index
            | _ -> unsupported "does not pass its arguments to Ord::cmp")
        | Constant _ -> unsupported "does not pass its arguments to Ord::cmp"
      in
      let rec walk compared (statements : statement list) =
        match (statements, compared) with
        | [ { kind = Return; _ } ], true -> ()
        | { kind = StorageLive _ | StorageDead _ | Nop; _ } :: rest, _ ->
            walk compared rest
        | {
            kind =
              Assign
                ( { kind = PlaceLocal id; _ },
                  RvRef ({ kind = PlaceGlobal gref; _ }, BShared, metadata) );
            _;
          }
          :: rest,
          false
          when id <> return_local && is_unit_metadata gref
               && unit_metadata_operand metadata ->
            origins := LocalId.Map.remove id !origins;
            unit_refs := LocalId.Set.add id !unit_refs;
            walk compared rest
        | { kind = Assign ({ kind = PlaceLocal id; _ }, rvalue); _ } :: rest, false
          when id <> return_local -> (
            match rvalue_origin rvalue with
            | Some index ->
                origins := LocalId.Map.add id index !origins;
                unit_refs := LocalId.Set.remove id !unit_refs;
                walk compared rest
            | None -> unsupported "computes more than Ord::cmp of its arguments")
        | { kind = Call { func = FnOpRegular ptr; args = [ a; b ]; dest }; _ }
          :: rest,
          false
          when dest.kind = PlaceLocal return_local && is_ord_cmp ptr ->
            (match (argument a, argument b) with
            | 0, 1 | 1, 0 -> ()
            | _ -> unsupported "does not compare its two arguments");
            walk true rest
        | _ ->
            unsupported "is not Ord::cmp(a, b) or Ord::cmp(b, a) of its arguments"
      in
      walk false body.body.statements;
      structural span [] elem
    in
    (* The comparator of [sort_by]: the [FnMut] impl [tr] must be a closure's,
       whose [call_mut] body, apart from storage markers and references to the
       unit metadata, only computes keys of its two arguments (fields 0 and 1 of
       the tupled arguments, see [key]) and returns [Ord::cmp] of a key of one
       argument and the same key of the other. The closure state is never read. *)
    let key_comparator span (tr : trait_ref) =
      let unsupported why =
        reject_stable span ("sort_by: the comparator " ^ why)
      in
      let body =
        closure_call_mut span
          (fun why -> stable_message ("sort_by: the comparator " ^ why))
          tr
      in
      let tupled_args = LocalId.of_int 2 in
      let return_local = LocalId.of_int 0 in
      let keys = ref LocalId.Map.empty in
      let unit_refs = ref LocalId.Set.empty in
      let is_unit_metadata (gref : global_decl_ref) =
        gref.id = crate.unit_metadata.id
      in
      let unit_metadata_operand = function
        | Copy { kind = PlaceGlobal gref; _ } -> is_unit_metadata gref
        | Copy { kind = PlaceProjection ({ kind = PlaceLocal id; _ }, Deref); _ }
          ->
            LocalId.Set.mem id !unit_refs
        | _ -> false
      in
      (* Reading through a shared reference or a box has no effect. *)
      let pure_pointer (ty : ty) =
        match ty with
        | TRef (_, _, RShared) | TAdt { id = TBuiltin TBox; _ } -> true
        | _ -> false
      in
      let rec place_key (place : place) =
        match place.kind with
        | PlaceLocal id ->
            Option.map (fun key -> Owned key) (LocalId.Map.find_opt id !keys)
        | PlaceProjection
            ({ kind = PlaceLocal id; _ }, Field (ProjTuple 2, field))
          when id = tupled_args ->
            Some (Owned (KRef (FieldId.to_int field, [])))
        | PlaceProjection (inner, Deref) when pure_pointer inner.ty -> (
            match place_key inner with
            | Some (Owned (KRef (arg, path))) -> Some (InArg (arg, path))
            | Some (Owned (KCopy (arg, path))) | Some (InArg (arg, path)) ->
                Some (InArg (arg, path @ [ KDeref ]))
            | Some (Owned (KRefLocal key)) -> Some (Owned key)
            | Some (Owned (KTuple _)) | None -> None)
        | PlaceProjection
            (inner, Field (((ProjAdt (_, None) | ProjTuple _) as kind), field))
          -> (
            match place_key inner with
            | Some (InArg (arg, path)) ->
                Some (InArg (arg, path @ [ KField (kind, field) ]))
            | Some (Owned (KTuple keys)) ->
                Option.map
                  (fun key -> Owned key)
                  (List.nth_opt keys (FieldId.to_int field))
            | _ -> None)
        | _ -> None
      in
      let operand_key (operand : operand) =
        match operand with
        | Move place | Copy place -> (
            match (place_key place, operand) with
            | Some (Owned key), _ -> Some key
            | Some (InArg (arg, path)), Copy _ -> Some (KCopy (arg, path))
            | _ -> None)
        | Constant _ -> None
      in
      let rvalue_key = function
        | Use operand -> operand_key operand
        | RvRef (place, BShared, metadata) when unit_metadata_operand metadata
          -> (
            match place_key place with
            | Some (InArg (arg, path)) -> Some (KRef (arg, path))
            | Some (Owned key) -> Some (KRefLocal key)
            | None -> None)
        | Aggregate (AggregatedAdt ({ id = TTuple; _ }, None, None), operands)
          ->
            let fields = List.map operand_key operands in
            if List.for_all Option.is_some fields then
              Some (KTuple (List.map Option.get fields))
            else None
        | _ -> None
      in
      let rec swap = function
        | KRef (arg, path) -> KRef (1 - arg, path)
        | KCopy (arg, path) -> KCopy (1 - arg, path)
        | KTuple keys -> KTuple (List.map swap keys)
        | KRefLocal key -> KRefLocal (swap key)
      in
      let rec arguments found = function
        | KRef (arg, _) | KCopy (arg, _) ->
            if List.mem arg found then found else arg :: found
        | KTuple keys -> List.fold_left arguments found keys
        | KRefLocal key -> arguments found key
      in
      let rec walk compared (statements : statement list) =
        match (statements, compared) with
        | [ { kind = Return; _ } ], true -> ()
        | { kind = StorageLive _ | StorageDead _ | Nop; _ } :: rest, _ ->
            walk compared rest
        | {
            kind =
              Assign
                ( { kind = PlaceLocal id; _ },
                  RvRef ({ kind = PlaceGlobal gref; _ }, BShared, metadata) );
            _;
          }
          :: rest,
          false
          when LocalId.to_int id > 2 && is_unit_metadata gref
               && unit_metadata_operand metadata ->
            keys := LocalId.Map.remove id !keys;
            unit_refs := LocalId.Set.add id !unit_refs;
            walk compared rest
        | { kind = Assign ({ kind = PlaceLocal id; _ }, rvalue); _ } :: rest, false
          when LocalId.to_int id > 2 -> (
            match rvalue_key rvalue with
            | Some key ->
                keys := LocalId.Map.add id key !keys;
                unit_refs := LocalId.Set.remove id !unit_refs;
                walk compared rest
            | None -> unsupported "computes more than keys of its arguments")
        | { kind = Call { func = FnOpRegular ptr; args = [ a; b ]; dest }; _ }
          :: rest,
          false
          when dest.kind = PlaceLocal return_local && is_ord_cmp ptr ->
            (match (operand_key a, operand_key b, a) with
            | Some x, Some y, (Move place | Copy place) -> (
                match (arguments [] x, arguments [] y) with
                | [ i ], [ j ] when i + j = 1 && swap y = x -> (
                    match TypesUtils.ty_erase_regions infos place.ty with
                    | TRef (_, key_ty, RShared) ->
                        structural_with stable_message span [] key_ty
                    | _ -> unsupported "does not compare references to keys")
                | _ -> unsupported "does not compare the same key of its two arguments")
            | _ -> unsupported "does not compare keys of its arguments");
            walk true rest
        | _ ->
            unsupported "is not Ord::cmp of the same key of its two arguments"
      in
      walk false body.body.statements
    in
    (* A partial-monomorphization instance (last name element [PeInstantiated],
       e.g. [sort_unstable_by] at a closure that captures a mutable borrow) is
       the generic function at the instantiated arguments, and
       [PrePasses.admit_modeled_fun_instances] gives it the same model: check
       the generic name at those arguments. *)
    let check_ptr span (ptr : fn_ptr) =
      match ptr.kind with
      | FunId (FRegular id) -> (
          let decl = FunDeclId.Map.find id crate.fun_decls in
          let name, generics =
            NameMatcher.instantiate_name_generics decl.item_meta.name
              ptr.generics
          in
          if matches sort_by name then
            match (generics.types, generics.trait_refs) with
            | [ element; _ ], [ compare ] -> comparator span element compare
            | _ -> reject span "unexpected generics of sort_unstable_by"
          else if matches stable_sort_by name then
            match generics.trait_refs with
            | [ compare ] -> key_comparator span compare
            | _ -> reject_stable span "unexpected generics of sort_by"
          else if matches stable_sort_by_key name then
            match (generics.types, generics.trait_refs) with
            | [ _; key; _ ], [ key_fn; ord ]
              when trait_name key_fn.trait_decl_ref.binder_value.id
                   = "core::ops::function::FnMut"
                   && trait_name ord.trait_decl_ref.binder_value.id
                      = "core::cmp::Ord" ->
                pure_key_function span key_fn;
                structural_with key_message span [] key
            | _ -> reject_key span "unexpected generics of sort_by_key"
          else if matches stable_sort name then
            match generics.types with
            | [ element ] -> structural_with sort_message span [] element
            | _ ->
                [%craise] span (sort_message "unexpected generics of sort")
          else if matches sort_by_key name then
            reject span
              "sort_unstable_by_key: equal keys may hide distinct elements"
          else if matches sort_unstable name then
            match generics.types with
            | [ element ] -> structural span [] element
            | _ -> reject span "unexpected generics of sort_unstable")
      | _ -> ()
    in
    let failed = ref FunDeclId.Map.empty in
    FunDeclId.Map.iter
      (fun id (decl : fun_decl) ->
        match decl.body with
        | StructuredBody body -> (
            let visitor =
              object
                inherit [_] iter_statement as super
                method! visit_fn_ptr span ptr = check_ptr span ptr

                method! visit_statement _ st =
                  super#visit_statement st.span st
              end
            in
            try
              [%recover_internal_errors] decl.item_meta.span (fun () ->
                  visitor#visit_block decl.item_meta.span body.body)
            with CFailure e -> failed := FunDeclId.Map.add id e !failed)
        | _ -> ())
      crate.fun_decls;
    let fun_decls =
      FunDeclId.Map.mapi
        (fun id (decl : fun_decl) ->
          match FunDeclId.Map.find_opt id !failed with
          | None -> decl
          | Some e ->
              [%save_error] decl.item_meta.span
                ("Ignoring the body of '"
                ^ name_of decl.item_meta.name
                ^ "' because of previous error");
              let msg =
                format_error_message_with_file_line e.file e.line e.span e.msg
              in
              { decl with body = ErrorBody { span = decl.item_meta.span; msg } })
        crate.fun_decls
    in
    { crate with fun_decls }
