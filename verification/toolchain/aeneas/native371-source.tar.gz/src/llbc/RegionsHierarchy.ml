(** This module analyzes function signatures to compute the hierarchy between
    regions.

    Normally we don't need to analyze type declarations: Rust records their
    outlives constraints as predicates. For example, for

    {[
      struct Wrapper<'a, 'b, T> {
        x : &'a mut &'b mut T,
      }
    ]}

    Rust adds ['b : 'a] and [T : 'b]. Function signatures do not get the same
    implicit predicates, so we infer their nested lifetime constraints here.
    Synthetic closure types are another exception: Charon may record no
    predicates for a captured [&'a mut Closure<'b>], even though storing that
    inner borrow requires ['b : 'a]. Inspect instantiated closure fields, not
    every pair of their captured lifetimes. *)

open Types
open TypesUtils
open LlbcAst
open SCC
module Subst = Substitute

(** The local logger *)
let log = Logging.regions_hierarchy_log

type regions_hierarchy = region_var_groups [@@deriving show]
let back_path_raw_stage (path : bool list) : int * bool =
  List.fold_right
    (fun given_back (j, received) ->
      match (given_back, received) with
      | false, true -> (2 * j, true)
      | true, true -> (2 * j, false)
      | true, false -> ((2 * j) + 1, true)
      | false, false -> ((2 * j) + 1, false))
    path (0, false)
let back_ty_routes_for_regions (type_decls : type_decl TypeDeclId.Map.t)
    (type_infos : TypesAnalysis.type_infos)
    (keep_region : region -> bool) (ty : ty) : region list list =
  let module T = Types in
  let has_mut ty =
    TypesUtils.ty_has_mut_borrow_for_region_in_pred type_infos keep_region ty
  in
  let union l = List.sort_uniq compare (List.concat l) in
  let rec routes (visited : T.ty list) (ty : T.ty) : T.region list list =
    if not (has_mut ty) then []
    else
      match ty with
      | T.TRef (r, rty, RMut) ->
          if keep_region r then [ [] ]
          else List.map (fun p -> r :: p) (routes visited rty)
      | T.TRef (_, _, RShared) -> []
      | T.TAdt { id = TTuple | TBuiltin _; generics } ->
          union (List.map (routes visited) generics.types)
      | T.TAdt { id = TAdtId adt_id; generics } ->
          if List.mem ty visited then []
          else (
            match
              T.TypeDeclId.Map.find_opt adt_id type_decls
            with
            | Some ({ kind = Struct _ | Enum _; _ } as def) ->
                (* Transparent ADTs expose routes through their actual fields. *)
                union
                  (List.map
                     (routes (ty :: visited))
                     (List.concat_map snd
                        (Substitute
                         .type_decl_get_instantiated_variants_fields_types def
                           generics)))
            (* Stored declaration indices exclude phantom arguments. *)
            | _ ->
                let info = T.TypeDeclId.Map.find adt_id type_infos in
                let stored = ref [] in
                T.TypeVarId.iteri
                  (fun index ty ->
                    if T.TypeVarId.Set.mem index info.stored_type_params then
                      stored := routes visited ty :: !stored)
                  generics.types;
                union ([ [] ] :: !stored))
      | T.TArray (ty, _) | T.TSlice ty -> routes visited ty
      | _ -> []
  in
  routes [] ty

(*
```ocaml
*)
let rec back_route_sides = function
  | [] -> [ [] ]
  | _ :: route ->
      let rest = back_route_sides route in
      List.map (fun path -> false :: path) rest
      @ List.map (fun path -> true :: path) rest

let back_ty_routes_with_paths_for_regions
    (type_decls : type_decl TypeDeclId.Map.t) infos keep_region ty =
  let rec routes visited rev_path ty =
    if not (TypesUtils.ty_has_mut_borrow_for_region_in_pred infos keep_region ty)
    then []
    else
      match ty with
      | TRef (region, _, RMut) when keep_region region ->
          [ ([], List.rev rev_path) ]
      | TRef (region, child, RMut) ->
          List.map
            (fun (route, path) -> (region :: route, path))
            (routes visited (Values.PDeref :: rev_path) child)
      | TRef (_, _, RShared) -> []
      | TAdt { id = TTuple | TBuiltin TBox; generics } ->
          List.concat
            (List.mapi
               (fun index child ->
                 routes visited (Values.PField (None, index) :: rev_path) child)
               generics.types)
      | TAdt { id = TAdtId id; generics } ->
          if List.mem ty visited then []
          else
            let decl = TypeDeclId.Map.find id type_decls in
            (match decl.kind with
            | Struct _ | Enum _ ->
                List.concat_map
                  (fun (variant, fields) ->
                    List.concat
                      (List.mapi
                         (fun index child ->
                           routes (ty :: visited)
                             (Values.PField (variant, index) :: rev_path) child)
                         fields))
                  (Substitute.type_decl_get_instantiated_variants_fields_types
                     decl generics)
            | _ ->
                let path = List.rev rev_path in
                List.map
                  (fun route -> (route, path))
                  (back_ty_routes_for_regions type_decls infos keep_region ty))
      | TArray (child, _) | TSlice child ->
          let path = List.rev rev_path in
          List.map
            (fun route -> (route, path))
            (back_ty_routes_for_regions type_decls infos keep_region child)
      | _ -> []
  in
  routes [] [] ty

(* Supplier masks retain canonical reference and field coordinates. *)
let back_ty_path_analysis_for_regions ?level
    (type_decls : type_decl TypeDeclId.Map.t)
    (infos : TypesAnalysis.type_infos) (normalize_shape : ty -> ty)
    (keep_region : region -> bool) (ty : ty) :
    (RegionId.Set.t -> (bool list * Values.value_path_step list) list)
    * (ty -> RegionId.Set.t -> RegionId.Set.t option) =
  let next = ref 0 in
  let ids =
    object
      inherit [_] iter_ty
      method! visit_region _ = function
        | RVar (Free id) -> next := max !next (RegionId.to_int id + 1)
        | _ -> ()
    end
  in
  ids#visit_ty () ty;
  let originals = ref RegionId.Map.empty in
  let visitor =
    object (self)
      inherit [_] map_ty as super
      method! visit_region stored region =
        match (stored, region) with
        | true, RVar (Free _) ->
            let id = RegionId.of_int !next in
            incr next;
            originals := RegionId.Map.add id region !originals;
            RVar (Free id)
        | _ -> region
      method! visit_TFnDef _ value = TFnDef value
      method! visit_TFnPtr _ value = TFnPtr value
      method! visit_trait_ref _ value = value
      method! visit_TDynTrait stored value =
        super#visit_TDynTrait
          (stored && not Config.type_analysis_ignore_dyn) value
      method! visit_TAdt stored tref =
        if not stored then TAdt tref
        else
          let selected_region, selected_type =
            match tref.id with
            | TAdtId id ->
                let info = TypeDeclId.Map.find id infos in
                ((fun index -> RegionId.Set.mem index info.stored_regions),
                 (fun index -> TypeVarId.Set.mem index info.stored_type_params))
            | _ -> ((fun _ -> true), (fun _ -> true))
          in
          let generics = tref.generics in
          let regions =
            RegionId.mapi
              (fun index region ->
                self#visit_region (selected_region index) region)
              generics.regions
          in
          let types =
            TypeVarId.mapi
              (fun index ty ->
                if selected_type index then self#visit_ty true ty else ty)
              generics.types
          in
          TAdt { tref with generics = { generics with regions; types } }
    end
  in
  let analysis_ty = visitor#visit_ty true ty in
  let keep_occurrence = function
    | RVar (Free id) ->
        Option.fold ~none:false ~some:keep_region
          (RegionId.Map.find_opt id !originals)
    | region -> keep_region region
  in
  let routes =
    back_ty_routes_with_paths_for_regions type_decls infos keep_occurrence analysis_ty
  in
  (*
```ocaml
  *)
  let positions ended =
    let is_ended = function
      | RVar (Free rid) -> RegionId.Set.mem rid ended
      | _ -> false
    in
    let rec views remaining available route =
      if remaining < 0 || remaining > available then []
      else match route with
      | [] -> if remaining = 0 then [ [] ] else []
      | region :: route ->
          let supplied =
            if remaining <= 0 then []
            else List.map (fun path -> true :: path)
                (views (remaining - 1) (available - 1) route)
          in
          if is_ended region then supplied
          else List.map (fun path -> false :: path)
              (views remaining (available - 1) route) @ supplied
    in
    List.sort_uniq compare
      (List.concat_map
         (fun (route, value_path) ->
           let paths =
             match level with
             | None -> [ List.map is_ended route ]
             | Some level -> views level (List.length route) route
           in
           List.map (fun path -> (path, value_path)) paths)
         routes)
  (*
```
  *)
  in
  let regions_of ty =
    let regions = ref [] in
    let visitor =
      object
        inherit [_] TypesAnalysis.iter_storage_ty infos
        method! visit_region _ region = regions := region :: !regions
      end
    in
    visitor#visit_ty () ty;
    List.rev !regions
  in
  let receiver_regions = regions_of analysis_ty in
  let shape = normalize_shape ty in
  let rec reference_regions_at_path ty = function
    | [] -> Some []
    | Values.PDeref :: path ->
        (match ty with
        | TRef (region, child, RMut) ->
            Option.map (fun regions -> region :: regions)
              (reference_regions_at_path child path)
        | _ -> None)
    | Values.PField (variant, index) :: path ->
        let fields =
          match ty with
          | TAdt { id = TTuple | TBuiltin TBox; generics } ->
              Some generics.types
          | TAdt { id = TAdtId id; generics } ->
              Option.map
                (fun decl ->
                  Substitute.type_decl_get_instantiated_field_types decl variant generics)
                (TypeDeclId.Map.find_opt id type_decls)
          | _ -> None
        in
        Option.bind fields (fun fields ->
          Option.bind (List.nth_opt fields index)
            (fun child -> reference_regions_at_path child path))
  in
  let supplier_mask supplier_ty supplier_regions =
    let regions = regions_of supplier_ty in
    if shape <> normalize_shape supplier_ty
       || List.length regions <> List.length receiver_regions then None
    else
      let select selected receiver supplier =
        match receiver, supplier with
        | RVar (Free receiver), RVar (Free supplier)
          when RegionId.Set.mem supplier supplier_regions ->
            RegionId.Set.add receiver selected
        | _ -> selected
      in
      let stored =
        List.fold_left2 select RegionId.Set.empty receiver_regions regions
      in
      let rec reference_mask selected receivers suppliers =
        match receivers, suppliers with
        | [], [] -> Some selected
        | receiver :: receivers, supplier :: suppliers ->
            reference_mask (select selected receiver supplier) receivers suppliers
        | _ -> None
      in
      List.fold_left
        (fun selected (receiver_refs, value_path) ->
          Option.bind selected (fun selected ->
            Option.bind (reference_regions_at_path supplier_ty value_path)
              (reference_mask selected receiver_refs)))
        (Some stored) routes
      (*
```
      *)
  in
  (positions, supplier_mask)




let back_ty_paths_for_regions (type_decls : type_decl TypeDeclId.Map.t)
    (type_infos : TypesAnalysis.type_infos)
    (keep_region : region -> bool) (ty : ty) : bool list list =
  List.sort_uniq compare
    (List.concat_map back_route_sides
       (back_ty_routes_for_regions type_decls type_infos keep_region ty))

let back_positions_raw_paths (positions : (bool * bool list) list) :
    ((bool * bool list) * bool list) list =
  let positions = List.sort_uniq compare positions in
  let depth =
    List.fold_left (fun d (_, path) -> max d (List.length path)) 0 positions
  in
  List.map
    (fun ((from_input, path) as position) ->
      let pad = List.init (depth - List.length path) (fun _ -> false) in
      let path = if from_input then pad @ path else path @ pad in
      (position, (not from_input) :: path))
    positions

let back_positions_stage_map (positions : (bool * bool list) list) :
    ((bool * bool list) * int) list =
  let raw =
    List.map
      (fun (position, path) -> (position, back_path_raw_stage path))
      (back_positions_raw_paths positions)
  in
  let has k received =
    List.exists (fun (_, (k', r)) -> k' = k && r = received) raw
  in
  let _, _, groups =
    List.fold_left
      (fun (group, seen_output, groups) k ->
        let group, seen_output =
          if has k true && seen_output then (group + 1, false)
          else (group, seen_output)
        in
        (group, seen_output || has k false, (k, group) :: groups))
      (0, false, [])
      (List.sort_uniq compare (List.map (fun (_, (k, _)) -> k) raw))
  in
  if List.for_all (fun (_, group) -> group = 0) groups then []
  else List.map (fun (position, (k, _)) -> (position, List.assoc k groups)) raw

(** Open only the call binder. Nested binders stay closed.
    Free region aliases retain one identity. *)
let open_fn_ptr_sig (binder : fun_sig region_binder) : bound_fun_sig =
  let free = ref RegionId.Set.empty in
  let collect = object
    inherit [_] iter_ty
    method! visit_RVar _ = function
      | Free id -> free := RegionId.Set.add id !free
      | Bound _ -> ()
  end in
  List.iter (collect#visit_ty ()) (binder.binder_value.output :: binder.binder_value.inputs);
  let next = ref (RegionId.Set.fold (fun id n -> max n (RegionId.to_int id + 1)) !free 0) in
  let fresh () =
    let id = RegionId.of_int !next in
    incr next;
    free := RegionId.Set.add id !free;
    id
  in
  let locals = List.map (fun (p : region_param) -> (p.index, fresh ())) binder.binder_regions in
  let subst = Subst.subst_remove_binder_zero
    { Subst.empty_bound_sb_subst with r_sb_subst = (fun id -> RVar (Free (List.assoc id locals))) } in
  let body_regions = ref RegionId.Map.empty in
  let refresh = object
    inherit [_] map_ty
    method! visit_RErased _ = RVar (Free (fresh ()))
    method! visit_RBody _ id =
      let rid = match RegionId.Map.find_opt id !body_regions with
        | Some rid -> rid
        | None -> let rid = fresh () in body_regions := RegionId.Map.add id rid !body_regions; rid in
      RVar (Free rid)
  end in
  let translate ty = refresh#visit_ty () (Subst.ty_substitute subst ty) in
  let sg = binder.binder_value in
  let sg = { sg with inputs = List.map translate sg.inputs; output = translate sg.output } in
  let regions = List.map (fun index -> { index; name = None; mutability = LtUnknown })
    (RegionId.Set.elements !free) in
  { item_binder_params = { empty_generic_params with regions }; item_binder_value = sg }

let back_num_stages (stage_map : ((bool * bool list) * int) list) : int =
  List.fold_left (fun n (_, stage) -> max n (stage + 1)) 1 stage_map

let compute_regions_hierarchy_for_sig (span : Meta.span option) (crate : crate)
    (sg : bound_fun_sig) : region_var_groups =
  (* Create the dependency graph.

     An edge from 'long to 'short means that 'long outlives 'short (that is
     we have 'long : 'short,  using Rust notations).
  *)
  (* First initialize the regions map.

     We add:
     - the region variables
     - the static region
     - edges from the static region to the region variables

     Note that we only consider the regions bound at the
     level of the signature (this excludes the regions locally bound inside
     the types, for instance at the level of an arrow type).
  *)
  let g : RegionSet.t RegionMap.t ref =
    let rvars =
      List.map
        (fun (r : region_param) -> RVar (Free r.index))
        sg.item_binder_params.regions
    in
    let s = (RStatic, RegionSet.of_list rvars) in
    let rsets = List.map (fun r -> (r, RegionSet.empty)) rvars in
    ref (RegionMap.of_list (s :: rsets))
  in

  let add_edge ~(long : region) ~(short : region) =
    (* Sanity checks *)
    [%sanity_check_opt_span] span (short <> RErased);
    [%sanity_check_opt_span] span (long <> RErased);
    (* Ignore the locally bound regions (at the level of arrow types for instance *)
    match (short, long) with
    | RVar (Bound _), _ | _, RVar (Bound _) -> ()
    | _, _ ->
        let m = !g in
        let s = RegionMap.find long !g in
        let s = RegionSet.add short s in
        g := RegionMap.add long s m
  in

  let add_edges_from_region_binder :
      'a. ('a -> unit) -> 'a region_binder -> unit =
   fun visit c ->
    (* Bound regions stay outside the free-region graph. *)
    visit c.binder_value
  in

  let add_edge_from_region_constraint ((long, short) : region_outlives) =
    add_edge ~long ~short
  in

  let add_edges ~(long : region) ~(shorts : region list) =
    (* TODO: shouldn't have to use List.iter *)
    List.iter (fun short -> add_edge ~long ~short) shorts
  in

  (* Explore the clauses - we only explore the "region outlives" clause,
     not the "type outlives" clauses *)
  List.iter
    (add_edges_from_region_binder add_edge_from_region_constraint)
    sg.item_binder_params.regions_outlive;

  (* Explore the types in the signature to add the edges *)
  let rec explore_ty (outer : region list) (ty : ty) =
    match ty with
    | TAdt { id; generics } ->
        (* Add constraints coming from the type clauses *)
        (match id with
        | TAdtId id ->
            (* Lookup the type declaration *)
            let decl = TypeDeclId.Map.find_opt id crate.type_decls in
            let decl =
              [%unwrap_opt_span] span decl
                "A type declaration used here is missing from the crate \
                 (probably because of a previous error, or because of the use \
                 of --exclude)"
            in

            (* Instantiate the predicates *)
            let subst =
              [%add_loc] Subst.make_subst_from_generics span decl.generics
                generics Self
            in
            let predicates = Subst.predicates_substitute subst decl.generics in
            (* Note that because we also explore the generics below, we may
               explore several times the same type - this is ok *)
            let add_edges_from_regions_outlive (long, short) =
              add_edges ~long ~shorts:(short :: outer)
            in
            List.iter
              (add_edges_from_region_binder add_edges_from_regions_outlive)
              predicates.regions_outlive;
            let add_edges_from_types_outlive (ty, short) =
              explore_ty (short :: outer) ty
            in
            List.iter
              (add_edges_from_region_binder add_edges_from_types_outlive)
              predicates.types_outlive;
            (* Closure captures can contain nested borrows without corresponding
               outlives predicates on the synthetic type. In particular a
               captured [&'a mut Closure<'b>] stores the inner borrow for as
               long as 'a, so ending 'b must first release the 'a borrow.
               Inspect fields, not all generic lifetimes: separate captures
               of independent references must remain independent. *)
            (match (decl.src, decl.kind) with
            | ClosureItem _, Struct fields ->
                List.iter
                  (fun (field : field) ->
                    explore_ty outer (Subst.ty_substitute subst field.field_ty))
                  fields
            | _ -> ())
        | TTuple -> (* No clauses for tuples *) ()
        | TBuiltin aid -> (
            match aid with
            | TBox | TStr -> (* No clauses for those *) ()));
        (* Explore the generics *)
        explore_generics outer generics
    | TArray (ty, _) | TSlice ty ->
        (* No clauses for those, but the regions of the elements outlive the
           outer regions, as for the type arguments of an ADT (e.g., the
           region of [T] in [&'a mut [T]] with [T := &'b str]) *)
        explore_ty outer ty
    | TVar _ | TLiteral _ | TNever -> ()
    | TRef (r, ty, _) ->
        (* Add the constraints for r *)
        add_edges ~long:r ~shorts:outer;
        (* Add r to the outer regions *)
        let outer = r :: outer in
        (* Continue *)
        explore_ty outer ty
    | TRawPtr (ty, _) -> explore_ty outer ty
    | TTraitType (trait_ref, _) ->
        (* The trait should reference a clause, and not an implementation
           (otherwise it should have been normalized), or a special builtin
           trait (in particular, [core::marker::DiscriminantKind]) *)
        [%sanity_check_opt_span] span
          (check_non_normalizable_trait_ref_kind trait_ref.kind);
        (* We have nothing to do *)
        ()
    | TFnPtr binder ->
        (* We can ignore the outer regions *)
        let { Types.inputs; output; _ } = binder.binder_value in
        List.iter (explore_ty []) (output :: inputs)
    | TFnDef _ ->
        (* A function item has no captured environment. Its region arguments
           instantiate the callee's signature; they are not stored references
           imposing outlives edges on the function-item value. *)
        ()
    | TDynTrait _ ->
        [%cassert_opt_span] span Config.type_analysis_ignore_dyn "Unimplemented"
    | TPtrMetadata _ -> [%craise_opt_span] span "unsupported: PtrMetadata"
    | TError _ ->
        [%craise_opt_span] span "Found type error in the output of charon"
  and explore_generics (outer : region list) (generics : generic_args) =
    let { regions; types; const_generics = _; trait_refs = _ } = generics in
    List.iter (fun long -> add_edges ~long ~shorts:outer) regions;
    List.iter (explore_ty outer) types
  in

  (* Substitute the regions in a type, then explore *)
  let explore_ty_subst ty = explore_ty [] ty in
  List.iter explore_ty_subst
    (sg.item_binder_value.output :: sg.item_binder_value.inputs);

  (* Compute the ordered SCCs *)
  let module Scc = SCC.Make (RegionOrderedType) in
  let sccs = Scc.compute (RegionMap.bindings !g) in

  (* Remove the SCC containing the static region.

     For now, we don't handle cases where regions different from 'static
     can live as long as 'static, so we check that if the group contains
     'static then it is the only region it contains, and then we filter
     the group.
     TODO: general support for 'static
  *)
  let sccs =
    (* Find the SCC which contains the static region *)
    let static_gr_id, static_scc =
      List.find
        (fun (_, scc) -> List.mem RStatic scc)
        (SccId.Map.bindings sccs.sccs)
    in
    (* The SCC should only contain the 'static *)
    [%sanity_check_opt_span] span (static_scc = [ RStatic ]);
    (* Remove the group as well as references to this group from the
       other SCCs *)
    let { sccs; scc_deps } = sccs in
    (* We have to change the indexing:
       - if id < static_gr_id: we leave the id as it is
       - if id = static_gr_id: we remove id
       - if id > static_gr_id: we decrement it by one
    *)
    let static_i = SccId.to_int static_gr_id in
    let convert_id (id : SccId.id) : SccId.id option =
      let i = SccId.to_int id in
      if i < static_i then Some id
      else if i = static_i then None
      else Some (SccId.of_int (i - 1))
    in
    let sccs =
      SccId.Map.of_list
        (List.filter_map
           (fun (id, rg_ids) ->
             match convert_id id with
             | None -> None
             | Some id -> Some (id, rg_ids))
           (SccId.Map.bindings sccs))
    in

    let scc_deps =
      List.filter_map
        (fun (id, deps) ->
          match convert_id id with
          | None -> None
          | Some id ->
              let deps = List.filter_map convert_id (SccId.Set.elements deps) in
              Some (id, SccId.Set.of_list deps))
        (SccId.Map.bindings scc_deps)
    in
    let scc_deps = SccId.Map.of_list scc_deps in

    { sccs; scc_deps }
  in

  (*
   * Compute the regions hierarchy
   *)
  List.filter_map
    (fun (scc_id, scc) ->
      (* The region id *)
      let i = SccId.to_int scc_id in
      let id = RegionGroupId.of_int i in

      (* Retrieve the set of regions in the group *)
      let regions : RegionId.id list =
        List.map
          (fun r ->
            match r with
            | RVar (Free rid) -> rid
            | _ -> [%craise] (Option.get span) "Unreachable")
          scc
      in

      (* Compute the set of parent region groups *)
      let parents =
        List.map
          (fun id -> RegionGroupId.of_int (SccId.to_int id))
          (SccId.Set.elements (SccId.Map.find scc_id sccs.scc_deps))
      in

      (* Put together *)
      Some { id; regions; parents })
    (SccId.Map.bindings sccs.sccs)

(** {1 Trait-implementation methods}

    A trait-implementation method is used as the method of its trait: the
    trait's record stores it in the field of the trait method, and the calls
    through the trait use the signature of the trait method. The region groups
    of a function determine its backward functions and the order in which its
    forward function returns them, so the region groups of an implementation
    must lead to the backward functions of the trait method, in the same order.
    The regions of the implementation are ordered independently of those of the
    trait method: when two backward functions give back values of the same type,
    a different order still type-checks. *)

(** Map the free regions of a trait method's signature to the regions which
    instantiate them in the signature of an implementation of this method, by
    walking the two signatures together. The implementation instantiates the
    type variables of the trait signature (e.g., [Self]): the regions they
    contain have no counterpart in the trait signature. Returns an error if the
    two signatures differ in structure, or if the implementation instantiates a
    region of the trait signature by two different regions. *)
let trait_method_region_map (trait_sg : fun_sig) (impl_sg : fun_sig) :
    (region RegionId.Map.t, string) result =
  let exception Mismatch of string in
  let map = ref RegionId.Map.empty in
  let mismatch () =
    raise
      (Mismatch
         "The signature of the trait-impl method is not an instance of the \
          signature of its trait method")
  in
  let pair (rt : region) (ri : region) =
    match rt with
    | RVar (Free rid) -> (
        match RegionId.Map.find_opt rid !map with
        | None -> map := RegionId.Map.add rid ri !map
        | Some ri' ->
            if ri' <> ri then
              raise
                (Mismatch
                   "The trait-impl method instantiates a region of its trait \
                    method by two different regions"))
    | _ -> ()
  in
  let iter2 f l0 l1 =
    if List.length l0 = List.length l1 then List.iter2 f l0 l1 else mismatch ()
  in
  let rec walk (tt : ty) (ti : ty) =
    match (tt, ti) with
    | (TVar _ | TTraitType _), _ -> ()
    | TRef (rt, tt, kt), TRef (ri, ti, ki) ->
        if kt <> ki then mismatch ();
        pair rt ri;
        walk tt ti
    | TRawPtr (tt, kt), TRawPtr (ti, ki) ->
        if kt <> ki then mismatch ();
        walk tt ti
    | TAdt at, TAdt ai ->
        if at.id <> ai.id then mismatch ();
        iter2 pair at.generics.regions ai.generics.regions;
        iter2 walk at.generics.types ai.generics.types
    | TArray (tt, _), TArray (ti, _) | TSlice tt, TSlice ti -> walk tt ti
    | TLiteral lt, TLiteral li -> if lt <> li then mismatch ()
    | TNever, TNever -> ()
    | TFnPtr bt, TFnPtr bi ->
        let st = bt.binder_value and si = bi.binder_value in
        iter2 walk (st.output :: st.inputs) (si.output :: si.inputs)
    | TFnDef _, TFnDef _ | TDynTrait _, TDynTrait _ -> ()
    | _ -> mismatch ()
  in
  try
    iter2 walk
      (trait_sg.output :: trait_sg.inputs)
      (impl_sg.output :: impl_sg.inputs);
    Ok !map
  with Mismatch msg -> Error msg

(** Check that the backward functions of a trait-impl method are those of its
    trait method, in the same order.

    - [trait_groups], [impl_groups]: the region groups of the two signatures
    - [region_map]: the regions of the trait method's signature and the regions
      of the implementation's signature which instantiate them (see
      {!trait_method_region_map})
    - [trait_back], [impl_back]: whether a region group leads to a backward
      function
    - [impl_region_name]: the name of a region of the implementation, for the
      error messages *)
let check_trait_impl_method_region_groups (span : Meta.span) (name : string)
    ~(trait_groups : region_var_groups) ~(impl_groups : region_var_groups)
    ~(region_map : region RegionId.Map.t)
    ~(trait_back : RegionGroupId.id -> bool)
    ~(impl_back : RegionGroupId.id -> bool)
    ~(impl_region_name : RegionId.id -> string) : unit =
  let impl_group_of_region =
    RegionId.Map.of_list
      (List.concat_map
         (fun (g : region_var_group) -> List.map (fun r -> (r, g.id)) g.regions)
         impl_groups)
  in
  let group_to_string (gid : RegionGroupId.id) =
    let g = RegionGroupId.nth impl_groups gid in
    "{" ^ String.concat ", " (List.map impl_region_name g.regions) ^ "}"
  in
  let layout_to_string (l : RegionGroupId.id list) =
    "[" ^ String.concat "; " (List.map group_to_string l) ^ "]"
  in
  (* The group of the implementation corresponding to every region group of the
     trait method which leads to a backward function *)
  let expected =
    List.filter_map
      (fun (g : region_var_group) ->
        if not (trait_back g.id) then None
        else
          let images =
            List.filter_map
              (fun rid ->
                match RegionId.Map.find_opt rid region_map with
                | None -> (* Not in the signature *) None
                | Some (RVar (Free rid)) ->
                    Some (RegionId.Map.find_opt rid impl_group_of_region)
                | Some _ -> Some None)
              g.regions
          in
          match List.sort_uniq compare images with
          | [ Some gid ] -> Some gid
          | _ ->
              [%craise] span
                ("A backward function of the trait method of " ^ name
               ^ " does not correspond to a single region group of the \
                  implementation (implementation region groups: "
                ^ layout_to_string
                    (List.map (fun (g : region_var_group) -> g.id) impl_groups)
                ^ ")"))
      trait_groups
  in
  let actual =
    List.filter_map
      (fun (g : region_var_group) -> if impl_back g.id then Some g.id else None)
      impl_groups
  in
  [%cassert] span (expected = actual)
    ("The backward functions of the trait-impl method " ^ name
   ^ " are not those of its trait method in the same order: the trait method \
      gives back the region groups " ^ layout_to_string expected
   ^ " in this order, the implementation gives back "
    ^ layout_to_string actual)
