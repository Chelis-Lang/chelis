include Charon.Types

module TyCacheKey = struct
  type t = ty

  let equal x y = x == y || Stdlib.compare x y = 0
  let hash = Hashtbl.hash_param 64 256
end

module TyCache = Ephemeron.K1.Make (TyCacheKey)

(* Operation-local walks reuse shared nodes without unfolding type DAGs
   during key equality. The weak cache above also reuses equal rebuilt types. *)
module TyTbl = Hashtbl.Make (struct
  type t = ty

  let equal x y = x == y
  let hash = Hashtbl.hash
end)

type region_id_set = RegionId.Set.t [@@deriving show, eq, ord]

(** Fresh ownership regions retain a separate source metadata identity.
    Argument constraints can resolve a fresh identity once. *)
type region_metadata_binding =
  | MetadataFresh
  | MetadataSource of region
[@@deriving show]

type region_metadata_bindings = region_metadata_binding RegionId.Map.t
[@@deriving show]

(** A normalized projection type.

    Stored region positions encode ownership selection:
    - the free region of id 0 selects a projection
    - an erased region excludes a projection

    Callable signatures and unselected nominal metadata retain their identities.
    Mixed nominal positions encode ownership here, not runtime signature aliases.
    Runtime field substitution uses the original projection type.

    This alias documents the mask contract without a separate representation. *)
type norm_proj_ty = ty [@@deriving show, eq, ord]
