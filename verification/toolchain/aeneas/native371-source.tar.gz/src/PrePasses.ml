(** This files contains passes we apply on the AST *before* calling the
    (concrete/symbolic) interpreter on it *)

open Types
open TypesUtils
open Expressions
open LlbcAst
open Utils
open LlbcAstUtils
open Errors

let log = Logging.pre_passes_log

let statement_to_string (crate : crate) =
  let fmt_env = Print.crate_to_fmt_env crate in
  Print.statement_to_string fmt_env "" "  "

let call_to_string (crate : crate) =
  let fmt_env = Print.crate_to_fmt_env crate in
  Print.call_to_string fmt_env "  "

let fun_decl_ref_to_string (crate : crate) =
  let fmt_env = Print.crate_to_fmt_env crate in
  Print.fun_decl_ref_to_string fmt_env

let generic_args_to_string (crate : crate) (generics : generic_args) =
  let fmt_env = Print.crate_to_fmt_env crate in
  let generics, traits = Print.generic_args_to_strings fmt_env generics in
  "<" ^ String.concat ", " (generics @ traits) ^ ">"

let generic_params_to_string (crate : crate) (generics : generic_params) =
  let fmt_env = Print.crate_to_fmt_env crate in
  let generics, traits = Print.generic_params_to_strings fmt_env generics in
  "<" ^ String.concat ", " (generics @ traits) ^ ">"


(** Replace the occurrences of [core::intrinsics::unreachable] with
    [Abort UndefinedBehavior]. This helps with the analyzes and the symbolic
    evaluation (in particular, we stop the evaluation when encountering an
    [Abort] - this can help us avoid merging control-flow after a match for
    instance *)
let remove_unreachable (crate : crate) (f : fun_decl) : fun_decl =
  let impl_pat = NameMatcher.parse_pattern "core::intrinsics::unreachable" in
  let mctx = NameMatcher.ctx_from_crate crate in
  let match_name =
    NameMatcher.match_name mctx
      {
        map_vars_to_vars = true;
        match_with_trait_decl_refs = Config.match_patterns_with_trait_decl_refs;
      }
  in

  let is_unreachable (st : statement) : bool =
    match st.kind with
    | Call call -> (
        match call.func with
        | FnOpRegular { kind; _ } -> (
            match kind with
            | FunId (FRegular fid) ->
                let fun_decl =
                  [%silent_unwrap_opt_span] (Some st.span)
                    (FunDeclId.Map.find_opt fid crate.fun_decls)
                in
                match_name impl_pat fun_decl.item_meta.name
            | _ -> false)
        | FnOpDynamic _ -> false)
    | _ -> false
  in
  let rec update (stl : statement list) : statement list =
    match stl with
    | [] -> []
    | st :: stl ->
        if is_unreachable st then [ { st with kind = Abort UndefinedBehavior } ]
        else st :: update stl
  in
  let visitor =
    object
      inherit [_] map_statement_base as super

      method! visit_block env b =
        let b = { b with statements = update b.statements } in
        super#visit_block env b
    end
  in
  match f.body with
  | StructuredBody body ->
      let body = { body with body = visitor#visit_block () body.body } in
      { f with body = StructuredBody body }
  | _ -> f

(** The Rust compiler generates a unique implementation of [Default] for arrays
    for every choice of length. For instance, if we write:
    {[
      let a: [u8; 32] = default ();
      let b: [u8; 64] = default ();
      ...
    ]}
    then rustc will introduce two different implementations of [Default]: an
    implementation for [u8; 32] and a different one for [u8; 64].

    For the purpose of the translation, we prefer using a single implementation
    which is generic in the length of the array. This pass thus replaces all the
    implementations of [Default<[T; N]>] with a single implementation.

    Concretely, we spot all the instances of [Default<[T; N]>] where [N] is a
    concrete array. We update the first such implementation so that it becomes
    generic in the length of the array, and replace all the other ones with this
    implementation. We also remove the useless implementations. *)
let update_array_default (crate : crate) : crate =
  let pctx = Print.crate_to_fmt_env crate in
  let impl_pat = NameMatcher.parse_pattern "core::default::Default" in
  let mctx = NameMatcher.ctx_from_crate crate in
  let match_name =
    NameMatcher.match_name mctx
      {
        map_vars_to_vars = true;
        match_with_trait_decl_refs = Config.match_patterns_with_trait_decl_refs;
      }
  in

  (* First detect all the instances of [Default<[T; N]>] (and all the
     implementations of [Default<[T; N]>::default] *)
  let merged_impl = ref None in
  let merged_method = ref None in
  (* Those maps allow us to do two things:
     - store the set of trait impls and methods that implement an instance
       of [Default] for arrays
     - store for each of those the precise length for which the implementation
       is specialized (useful later when updating the crate)
  *)
  let impls = ref TraitImplId.Map.empty in
  let methods = ref FunDeclId.Map.empty in

  let visit_trait_impl _id (impl : trait_impl) : trait_impl option =
    (* Check this is an impl of [Default] for arrays *)
    let trait_decl =
      [%silent_unwrap_opt_span] (Some impl.item_meta.span)
        (TraitDeclId.Map.find_opt impl.impl_trait.id crate.trait_decls)
    in
    if match_name impl_pat trait_decl.item_meta.name then (
      [%ldebug
        "found a matching impl.\n - decl_generics: "
        ^ Print.generic_args_to_string pctx impl.impl_trait.generics];
      (* Check the generics. Note that we ignore the case where the length
         is equal to 0, because in this case rustc uses a different impl
         which doesn't require that the type of the elements also has a
         default implementation. *)
      match impl.impl_trait.generics with
      | {
       regions = [];
       types =
         [
           TArray
             ( (TVar (Free _) as elem_ty),
               ({ kind = CLiteral (VScalar (UnsignedScalar (Usize, nv))); _ } as
                n) );
         ];
       const_generics = [];
       trait_refs = _;
      }
        when Z.to_int nv != 0 -> begin
          (* Save the implementation and the method *)
          impls := TraitImplId.Map.add impl.def_id n !impls;
          assert (List.length impl.methods = 1);
          let meth = snd (List.hd impl.methods) in
          assert (meth.binder_params = empty_generic_params);
          let method_id = meth.binder_value.id in
          methods := FunDeclId.Map.add method_id n !methods;
          (* Is it the first implementation we find? *)
          match !merged_impl with
          | None ->
              (* Update the implementation in place *)
              let cg_id = ConstGenericVarId.zero in
              let cg : Types.constant_expr =
                { kind = CVar (Free cg_id); ty = TypesUtils.mk_usize_ty }
              in
              let generics =
                {
                  impl.impl_trait.generics with
                  types = [ TArray (elem_ty, cg) ];
                }
              in
              let impl_trait = { impl.impl_trait with generics } in
              let params =
                {
                  impl.generics with
                  const_generics =
                    [
                      { index = cg_id; name = "N"; ty = TypesUtils.mk_usize_ty };
                    ];
                }
              in
              let impl = { impl with impl_trait; generics = params } in
              (* Register it *)
              merged_impl := Some impl;
              merged_method := Some method_id;
              (* Continue *)
              Some impl
          | Some _ ->
              (* Filter the implementation *)
              None
        end
      | _ -> Some impl)
    else Some impl
  in
  let crate =
    {
      crate with
      trait_impls =
        TraitImplId.Map.filter_map visit_trait_impl crate.trait_impls;
    }
  in

  (* Check if we found a default implementation for array. If yes, we need
     to filter the [default] methods and update all the definitions to make
     sure they refer to the proper implementations and methods.
  *)
  match !merged_impl with
  | None -> crate
  | Some merged_impl ->
      let merged_method = Option.get !merged_method in
      let impls = !impls in
      let methods = !methods in

      (* Filter the functions *)
      let visit_fun id (fdecl : fun_decl) =
        match FunDeclId.Map.find_opt id methods with
        | None -> Some fdecl
        | Some _ ->
            if id = merged_method then (
              (* Update the method *)
              let cg_id = ConstGenericVarId.zero in
              let cg : Types.constant_expr =
                { kind = CVar (Free cg_id); ty = TypesUtils.mk_usize_ty }
              in
              let sg = fdecl.signature in
              assert (sg.inputs = []);
              match sg.output with
              | TArray ((TVar (Free _) as elem_ty), _) ->
                  let generics =
                    {
                      fdecl.generics with
                      const_generics =
                        [
                          {
                            index = cg_id;
                            name = "N";
                            ty = TypesUtils.mk_usize_ty;
                          };
                        ];
                    }
                  in
                  let sg = { sg with output = TArray (elem_ty, cg) } in
                  let fdecl = { fdecl with signature = sg; generics } in
                  Some fdecl
              | _ -> [%internal_error] fdecl.item_meta.span)
            else (* Filter *)
              None
      in
      let filter_ids_visitor =
        object
          inherit [_] filter_decl_id

          method! visit_trait_impl_id _ id =
            match TraitImplId.Map.find_opt id impls with
            | None -> Some id
            | Some _ -> if id = merged_impl.def_id then Some id else None

          method! visit_fun_decl_id _ id =
            match FunDeclId.Map.find_opt id methods with
            | None -> Some id
            | Some _ -> if id = merged_method then Some id else None
        end
      in
      let crate =
        {
          crate with
          fun_decls = FunDeclId.Map.filter_map visit_fun crate.fun_decls;
          declarations =
            filter_ids_visitor#visit_declaration_groups () crate.declarations;
        }
      in

      (* Update all the definitions in the crate *)
      let visitor =
        object
          inherit [_] map_crate_with_span as super

          method! visit_TraitImpl env impl_ref =
            match TraitImplId.Map.find_opt impl_ref.id impls with
            | None -> super#visit_TraitImpl env impl_ref
            | Some n ->
                super#visit_TraitImpl env
                  {
                    id = merged_impl.def_id;
                    generics = { impl_ref.generics with const_generics = [ n ] };
                  }

          method! visit_fn_ptr env fn_ptr =
            match fn_ptr.kind with
            | FunId (FRegular fid) -> begin
                match FunDeclId.Map.find_opt fid methods with
                | None -> super#visit_fn_ptr env fn_ptr
                | Some n ->
                    let fn_ptr =
                      {
                        kind = FunId (FRegular merged_method);
                        generics =
                          { fn_ptr.generics with const_generics = [ n ] };
                      }
                    in
                    super#visit_fn_ptr env fn_ptr
              end
            | _ -> super#visit_fn_ptr env fn_ptr
        end
      in
      visitor#visit_crate None crate

type loop_continuation = {
  after_loop : statement list;
  outer_loops : loop_continuation list;
  returns_to_function : bool;
}

(** Normalize function-returning loop exits before symbolic joins.

    Copy the normal continuation only onto the breaks that execute it, then
    replace completed returns with a local break followed by a return outside
    the loop. This keeps return values and scoped locals on their original
    paths, including when one serial loop is nested in another's continuation.

    A loop whose returns share it with breaks resuming an outer iteration keeps
    its local breaks: its returns become breaks of the nearest enclosing
    returning loop, which the symbolic interpreter handles as a separate exit
    of the inner loop, like continues and breaks to outer loops. *)
let update_loops (crate : crate) (f : fun_decl) : fun_decl =
  let f0 = f in
  let span = f.item_meta.span in
  let enclosing loops i =
    [%cassert] span
      (i >= 0 && i < List.length loops)
      "A loop exit refers to a missing enclosing loop";
    List.nth loops i
  in
  let has_break ?(nonlocal = false) (body : block) =
    let visitor =
      object (self)
        inherit [_] iter_statement
        method! visit_Loop depth body = self#visit_block (depth + 1) body

        method! visit_Break depth i =
          if i = depth && ((not nonlocal) || depth > 0) then raise Found
      end
    in
    try
      visitor#visit_block 0 body;
      false
    with Found -> true
  in
  let has_function_exit loops (body : block) =
    let visitor =
      object (self)
        inherit [_] iter_statement
        method! visit_Loop depth body = self#visit_block (depth + 1) body
        method! visit_Return _ = raise Found

        method! visit_Break depth i =
          if i > depth && (enclosing loops (i - depth - 1)).returns_to_function
          then raise Found
      end
    in
    try
      visitor#visit_block 0 body;
      false
    with Found -> true
  in
  let needs_continuation =
    let visitor =
      object
        inherit [_] iter_statement

        method! visit_Loop loops body =
          if has_function_exit loops body || has_break ~nonlocal:true body then
            raise Found
      end
    in
    fun loops st ->
      try
        visitor#visit_statement loops st;
        false
      with Found -> true
  in
  (* A copied continuation must finish the function, not resume an enclosing
     iteration. Following breaks decreases the source loop-stack depth. *)
  let rec completes_function loops (statements : statement list) =
    match statements with
    | [] -> false
    | st :: after -> (
        match st.kind with
        | Return | Abort _ -> true
        | Continue _ -> false
        | Break i ->
            let target = enclosing loops i in
            target.returns_to_function
            && completes_function target.outer_loops target.after_loop
        | Switch switch -> (
            let completes body =
              completes_function loops (body.statements @ after)
            in
            match switch with
            | If (_, left, right) -> completes left && completes right
            | SwitchInt (_, _, branches, otherwise) ->
                List.for_all (fun (_, body) -> completes body) branches
                && completes otherwise
            | Match (_, branches, otherwise) ->
                List.for_all (fun (_, body) -> completes body) branches
                && Option.fold ~none:true ~some:completes otherwise)
        | _ -> completes_function loops after)
  in
  let mk_statement span kind : statement =
    { span; statement_id = StatementId.zero; kind; comments_before = [] }
  in
  (* Continuations are copied only onto edges which would have executed them.
     Every exit of a returning loop has therefore completed its return value.
     In particular, dead locals on a return edge are never joined with locals
     needed by a normal continuation. *)
  let rec normalize loops return_kind (statements : statement list) =
    match statements with
    | [] -> []
    | st :: after -> (
        match st.kind with
        | Return -> [ { st with kind = return_kind } ]
        | Abort _ -> [ st ]
        | Continue _ ->
            (* A continue to an outer loop is a separate exit of the inner loops
               (see [InterpLoops.eval_loop_symbolic]). *)
            [ st ]
        | Break i ->
            let target = enclosing loops i in
            if target.returns_to_function then
              normalize target.outer_loops return_kind target.after_loop
            else [ st ]
        | Switch switch ->
            (* Only returning loops need an enclosing branch's continuation.
               Keep other joins to avoid exponential duplication of independent
               conditionals preceding a returning loop. *)
            let distribute = needs_continuation loops st in
            let branch (body : block) =
              {
                body with
                statements =
                  normalize loops return_kind
                    (if distribute then body.statements @ after
                     else body.statements);
              }
            in
            let switch =
              match switch with
              | If (op, left, right) -> If (op, branch left, branch right)
              | SwitchInt (op, ty, branches, otherwise) ->
                  SwitchInt
                    ( op,
                      ty,
                      List.map (fun (p, b) -> (p, branch b)) branches,
                      branch otherwise )
              | Match (place, branches, otherwise) ->
                  Match
                    ( place,
                      List.map (fun (p, b) -> (p, branch b)) branches,
                      Option.map branch otherwise )
            in
            { st with kind = Switch switch }
            :: (if distribute then [] else normalize loops return_kind after)
        | Loop body ->
            let has_function_exit = has_function_exit loops body in
            let returns_to_function =
              has_function_exit
              || has_break ~nonlocal:true body
                 && completes_function loops after
            in
            (* The loop's own breaks resume an outer iteration while other paths
               leave the function: keep the breaks, and leave the function
               through the enclosing loop which completes it. *)
            let mixed =
              returns_to_function && has_break body
              && not (completes_function loops after)
            in
            let returns_to_function = returns_to_function && not mixed in
            let current =
              { after_loop = after; outer_loops = loops; returns_to_function }
            in
            if returns_to_function then (
              let body =
                {
                  body with
                  statements =
                    normalize (current :: loops) (Break 0) body.statements;
                }
              in
              [ { st with kind = Loop body }; mk_statement st.span return_kind ])
            else
              let body_return_kind =
                if mixed then (
                  match return_kind with
                  | Break i -> Break (i + 1)
                  | _ ->
                      [%craise] st.span
                        "A loop which resumes an outer iteration must be \
                         nested in a loop")
                else return_kind
              in
              let body =
                {
                  body with
                  statements =
                    normalize (current :: loops) body_return_kind
                      body.statements;
                }
              in
              { st with kind = Loop body } :: normalize loops return_kind after
        | _ -> st :: normalize loops return_kind after)
  in
  let needs_normalization (body : block) =
    let visitor =
      object (self)
        inherit [_] iter_statement
        method! visit_Loop depth body = self#visit_block (depth + 1) body
        method! visit_Return depth = if depth > 0 then raise Found
        method! visit_Break _ i = if i > 0 then raise Found
        method! visit_Continue _ i = if i > 0 then raise Found
      end
    in
    try
      visitor#visit_block 0 body;
      false
    with Found -> true
  in
  let body =
    match f.body with
    | StructuredBody body when needs_normalization body.body ->
        let block = body.body in
        StructuredBody
          {
            body with
            body =
              { block with statements = normalize [] Return block.statements };
          }
    | other -> other
  in
  let f : fun_decl = { f with body } in
  [%ldebug
    let env = Print.crate_to_fmt_env crate in
    "Before/after [update_loops]:\n"
    ^ Print.fun_decl_to_string env "" " " f0
    ^ "\n\n"
    ^ Print.fun_decl_to_string env "" " " f];
  f

(** Inline what comes after an [if then else], a [switch] or a [match], etc.
    under certain conditions, to prevent useless joins from being performed by
    the symbolic execution.

    The main goal of this pass is to improve the quality of the generated code.
*)
let remove_useless_joins (crate : crate) (f : fun_decl) : fun_decl =
  let f0 = f in

  let rec update_block (to_inline : statement list) (block : block) :
      bool * block =
    let can_inline, statements = update_statements to_inline block.statements in
    (can_inline, { block with statements })
  and update_statements (to_inline : statement list) (ls : statement list) :
      bool * statement list =
    match ls with
    | [] -> (true, to_inline)
    | st :: ls -> (
        [%ldebug
          "ls:\n"
          ^ Print.list_to_string ~sep:"\n" (statement_to_string crate) ls];
        let can_inline, ls = update_statements to_inline ls in
        match st.kind with
        | Nop | StorageLive _ | StorageDead _ | PlaceMention _ | Drop _ ->
            (can_inline, st :: ls)
        | Abort _ | Return | Break _ | Continue _ -> (true, [ st ])
        | Switch (Match (_, branches, Some otherwise))
          when otherwise.statements = []
               && List.for_all (fun (_, b) -> b.statements = []) branches ->
            (* Drop elaboration can leave effect-free matches after moving an
               enum's payload. Remove them before inlining continuations: a
               preceding join need not retain the moved enum's discriminant.
               A zero-branch match without a default is not fallthrough. *)
            (can_inline, ls)
        | Switch switch -> (
            [%ldebug "Switch: can_inline: " ^ Print.bool_to_string can_inline];
            (* Keep an adjacent same-place cleanup under the known
               discriminant, without duplicating the unrelated continuation. *)
            let to_inline, ls =
              if can_inline then (ls, [])
              else
                match (switch, ls) with
                | ( Match (p, _, _),
                    ({ kind = Switch (Match (next, _, _)); _ } as cleanup)
                    :: rest )
                  when p = next -> ([ cleanup ], rest)
                | _ -> ([], ls)
            in
            let update b = snd (update_block to_inline b) in
            let switch =
              match switch with
              | If (scrut, st0, st1) -> If (scrut, update st0, update st1)
              | SwitchInt (op, ty, branches, otherwise) ->
                  let branches =
                    List.map (fun (pats, br) -> (pats, update br)) branches
                  in
                  let otherwise = update otherwise in
                  SwitchInt (op, ty, branches, otherwise)
              | Match (scrut, branches, otherwise) ->
                  let branches =
                    List.map (fun (id, br) -> (id, update br)) branches
                  in
                  let otherwise = Option.map update otherwise in
                  Match (scrut, branches, otherwise)
            in
            (* Cleanup defaults can already contain an exit. After inlining,
               identical exits no longer need to inspect the discriminant. *)
            match switch with
            | Match
                ( _,
                  branches,
                  Some
                    {
                      statements =
                        [
                          ({ kind = Abort _ | Return | Break _ | Continue _; _ }
                           as exit);
                        ];
                      _;
                    } )
              when List.for_all
                     (fun (_, b) ->
                       match b.statements with
                       | [ st ] -> st.kind = exit.kind
                       | _ -> false)
                     branches -> (true, [ exit ])
            | _ ->
                let ls = { st with kind = Switch switch } :: ls in
                [%ldebug
                  "after updating the switch:\n"
                  ^ Print.list_to_string ~sep:"\n"
                      (statement_to_string crate)
                      ls];
                (false, ls))
        | Loop loop ->
            (* Update the inside of the loop *)
            (false, { st with kind = Loop (snd (update_block [] loop)) } :: ls)
        | Assign (_, rv) -> (
            (* We allow inlining some assignments (otherwise the pass is too restrictive) *)
            match rv with
            | Use _ | RvRef _ | RawPtr _ | NullaryOp _ | Aggregate _ ->
                (can_inline, st :: ls)
            | BinaryOp _
            | UnaryOp _
            | Discriminant _
            | Len _
            | Repeat _
            | ShallowInitBox _ -> (false, st :: ls))
        | SetDiscriminant _ | CopyNonOverlapping _ | Assert _ | Call _ | Error _
          -> (false, st :: ls))
  in

  let body =
    match f.body with
    | StructuredBody body ->
        StructuredBody { body with body = snd (update_block [] body.body) }
    | other -> other
  in

  let f : fun_decl = { f with body } in
  [%ldebug
    let env = Print.crate_to_fmt_env crate in
    "Before/after [remove_useless_joins]:\n"
    ^ Print.fun_decl_to_string env "" " " f0
    ^ "\n\n"
    ^ Print.fun_decl_to_string env "" " " f];
  f

(** Remove the use of shallow borrows and the storage live/dead instructions.

    Storage live/dead instructions are not used by the symbolic/concrete
    interpreter, so we can safely remove them.

    Shallow borrows are used in early versions of MIR for the sole use of the
    borrow checker (they have no runtime semantics). They are used to prevent
    match guards from changing a discriminant that is being matched on.

    For instance, let's consider the following Rust code:
    {[
      let mut x = (true, true);
      match x {
          (false, _) => 1,
          (true, _) if { x.0 = false; false } => 0,
          (_, true) => 2,
          (true, _) => 3,
      }
    ]}

    If this code was allowed, it would reach an `unreachable_unchecked` code
    path. Rust disallows this by adding a shallow borrow of each place whose
    discriminant is read, and a fake (removed before codegen) read of that
    borrow.

    We discard these in Aeneas. This does allow more code to pass the
    borrow-checker, but the UB is still correctly caught by the
    evaluator/translation hence the translation is still sound. *)
let remove_shallow_borrows_storage_live_dead (crate : crate) (f : fun_decl) :
    fun_decl =
  let f0 = f in
  let filter_in_body (body : block) : block =
    let filtered = ref LocalId.Set.empty in

    let filter_shallow (st : statement) : statement list =
      match st.kind with
      | Assign (p, rv) -> (
          match (p.kind, rv) with
          | PlaceLocal var_id, RvRef (_, BShallow, _) ->
              (* Filter *)
              filtered := LocalId.Set.add var_id !filtered;
              []
          | _ -> [ st ])
      | _ -> [ st ]
    in

    let filter_storage (st : statement) : statement list =
      match st.kind with
      | StorageLive _ -> []
      | StorageDead loc when LocalId.Set.mem loc !filtered -> []
      | _ -> [ st ]
    in

    (* Filter the variables *)
    let body = map_statement filter_shallow body in
    let body = map_statement filter_storage body in

    (* Check that the filtered variables have completely disappeared from the body *)
    let check_visitor =
      object
        inherit [_] iter_statement as super

        (* Remember the span of the statement we enter *)
        method! visit_statement _ st = super#visit_statement st.span st

        method! visit_local_id span id =
          [%cassert] span
            (not (LocalId.Set.mem id !filtered))
            "Filtered variables should have completely disappeared from the \
             body"
      end
    in
    check_visitor#visit_block body.span body;

    (* Return the updated body *)
    body
  in

  let body =
    match f.body with
    | StructuredBody body ->
        StructuredBody { body with body = filter_in_body body.body }
    | other -> other
  in
  let f = { f with body } in
  [%ldebug
    let env = Print.crate_to_fmt_env crate in
    "Before/after [remove_shallow_borrows]:\n"
    ^ Print.fun_decl_to_string env "" " " f0
    ^ "\n\n"
    ^ Print.fun_decl_to_string env "" " " f];
  f

(* Remove the type aliases from the type declarations and declaration groups *)
let filter_type_aliases (crate : crate) : crate =
  let type_decl_is_alias (ty : type_decl) =
    match ty.kind with
    | Alias _ -> true
    | _ -> false
  in
  (* Whether the declaration group has a single entry that is a type alias.
     Type aliases should not be in recursive groups so we also ensure this doesn't
     happen. *)
  let decl_group_is_single_alias = function
    | TypeGroup (NonRecGroup id) ->
        type_decl_is_alias (TypeDeclId.Map.find id crate.type_decls)
    | TypeGroup (RecGroup ids) ->
        List.iter
          (fun id ->
            let ty = TypeDeclId.Map.find id crate.type_decls in
            if type_decl_is_alias ty then
              [%craise] ty.item_meta.span
                "found a type alias within a recursive group; this is \
                 unexpected")
          ids;
        false
    | _ -> false
  in
  {
    crate with
    type_decls =
      TypeDeclId.Map.filter
        (fun _id ty -> not (type_decl_is_alias ty))
        crate.type_decls;
    declarations =
      List.filter
        (fun decl -> not (decl_group_is_single_alias decl))
        crate.declarations;
  }

(** Refresh the statement ids to make sure they are unique *)
let refresh_statement_ids (_ : crate) (f : fun_decl) : fun_decl =
  (* Map  *)
  let body =
    match f.body with
    | StructuredBody body ->
        let _, gen_id = StatementId.fresh_stateful_generator () in

        (* Visit the rvalue *)
        let visitor =
          object
            inherit [_] map_statement
            method! visit_statement_id _ _ = gen_id ()
          end
        in

        StructuredBody { body with body = visitor#visit_block () body.body }
    | other -> other
  in
  { f with body }

(** We simplify statements of the shape:
    {[
      x := from_str<'_>(const ("Error"));
      panic(core::panicking::panic_fmt)

        ~>

      panic(core::panicking::panic_fmt)
    ]}

    TODO: remove *)
let simplify_panics (crate : crate) (f : fun_decl) : fun_decl =
  let pats =
    [
      "core::fmt::{core::fmt::Arguments<'a>}::from_str";
      "core::fmt::{core::fmt::Arguments<'a>}::from_str_nonconst";
    ]
  in
  let pats = List.map (fun p -> (NameMatcher.parse_pattern p, ())) pats in
  (* TODO: we shouldn't need to use a names map *)
  let names_map = NameMatcher.NameMatcherMap.of_list pats in
  let match_ctx = Charon.NameMatcher.ctx_from_crate crate in
  let is_from_str (d : fun_decl) =
    let config = ExtractName.default_match_config in
    NameMatcher.NameMatcherMap.mem match_ctx config d.item_meta.name names_map
  in

  let visitor =
    object (self)
      inherit [_] map_statement

      method! visit_block env (block : block) =
        let rec update (stl : statement list) : statement list =
          match stl with
          | [] -> []
          | [ st0; st1 ] -> (
              match (st0.kind, st1.kind) with
              | ( Call
                    { func = FnOpRegular { kind = FunId (FRegular fid); _ }; _ },
                  Abort (Panic _) ) -> (
                  match FunDeclId.Map.find_opt fid crate.fun_decls with
                  | Some decl when is_from_str decl -> [ st1 ]
                  | _ ->
                      [
                        self#visit_statement env st0;
                        self#visit_statement env st1;
                      ])
              | _ ->
                  [ self#visit_statement env st0; self#visit_statement env st1 ]
              )
          | st0 :: stl -> self#visit_statement env st0 :: update stl
        in
        { block with statements = update block.statements }
    end
  in

  let body =
    match f.body with
    | StructuredBody body ->
        StructuredBody { body with body = visitor#visit_block () body.body }
    | other -> other
  in
  { f with body }

(** This micro-pass introduces intermediate assignments to access the global
    values in order to simplify the semantics.

    Whenever we access a constant, we introduce a shared borrow and a
    dereference. Ex.:

    {[
      let x = copy C;

        ~~>

      let tmp = &C;
      let x = copy *C;
    ]}

    Remark: we use the crate to lookup the type of the globals.

    TODO: generalize the evaluation of globals in the symbolic interpreter. *)
let decompose_global_accesses (crate : crate) (f : fun_decl) : fun_decl =
  (* Map  *)
  let body =
    match f.body with
    | StructuredBody body -> (
        let new_locals = ref [] in
        let _, gen =
          LocalId.mk_stateful_generator_starting_at_id
            (LocalId.of_int (List.length body.locals.locals))
        in
        let fresh_local ty =
          let local =
            {
              index = gen ();
              local_ty = ty;
              name = None;
              span = f.item_meta.span;
            }
          in
          new_locals := local :: !new_locals;
          local.index
        in

        (* Function to decompose the operands in a statement *)
        let decompose_in_statement (st : statement) : statement list =
          let span = st.span in
          let new_statements = ref [] in

          (* Visit the rvalue *)
          let visitor =
            object
              inherit [_] map_statement as super
              method! visit_place _ p = super#visit_place p.ty p

              method! visit_PlaceGlobal ty gref =
                (* Compute the type of the reference *)
                let ref_ty = TRef (RErased, ty, RShared) in

                (* Introduce the intermediate reference *)
                let local_id =
                  let local_id = fresh_local ref_ty in
                  let metadata =
                    Copy
                      {
                        kind = PlaceGlobal crate.unit_metadata;
                        ty = mk_unit_ty;
                      }
                  in
                  let st =
                    {
                      span;
                      statement_id = StatementId.zero;
                      kind =
                        Assign
                          ( { kind = PlaceLocal local_id; ty = ref_ty },
                            RvRef
                              ( { kind = PlaceGlobal gref; ty },
                                BShared,
                                metadata ) );
                      comments_before = [];
                    }
                  in
                  new_statements := st :: !new_statements;
                  local_id
                in

                (* Finally we can update the place *)
                PlaceProjection
                  ({ kind = PlaceLocal local_id; ty = ref_ty }, Deref)
            end
          in

          let kind =
            match st.kind with
            | Assign (lv, rv) -> Assign (lv, visitor#visit_rvalue mk_unit_ty rv)
            | CopyNonOverlapping { src; dst; count } ->
                let src = visitor#visit_operand mk_unit_ty src in
                CopyNonOverlapping { src; dst; count }
            | Assert ({ cond; expected; check_kind }, on_failure) ->
                let cond = visitor#visit_operand mk_unit_ty cond in
                Assert ({ cond; expected; check_kind }, on_failure)
            | Call { func; args; dest } ->
                let func = visitor#visit_fn_operand mk_unit_ty func in
                let args = List.map (visitor#visit_operand mk_unit_ty) args in
                Call { func; args; dest }
            | SetDiscriminant _
            | StorageLive _
            | StorageDead _
            | PlaceMention _
            | Drop _
            | Abort _
            | Return
            | Break _
            | Continue _
            | Nop
            | Switch _
            | Loop _
            | Error _ -> st.kind
          in
          let st = { st with kind } in

          List.rev (st :: !new_statements)
        in

        (* Visit all the statements and decompose the operands *)
        try
          [%recover_internal_errors] f.item_meta.span (fun () ->
              let body_body = map_statement decompose_in_statement body.body in
              StructuredBody
                {
                  body with
                  body = body_body;
                  locals =
                    {
                      body.locals with
                      locals = body.locals.locals @ List.rev !new_locals;
                    };
                })
        with CFailure error ->
          let mctx = Charon.NameMatcher.ctx_from_crate crate in
          let fmt_env = Print.crate_to_fmt_env crate in
          let name = Print.name_to_string fmt_env f.item_meta.name in
          let name_pattern =
            LlbcAstUtils.name_pattern_for_error_message (fun () ->
                let c : Charon.NameMatcher.to_pat_config =
                  {
                    tgt = TkPattern;
                    use_trait_decl_refs =
                      ExtractName.match_with_trait_decl_refs;
                  }
                in
                let pat =
                  LlbcAstUtils.name_to_pattern (Some f.item_meta.span) mctx c
                    f.item_meta.name
                in
                Charon.NameMatcher.pattern_to_string { tgt = TkPattern } pat)
          in
          [%save_error_opt_span] error.span
            ("Failure when pre- processing: " ^ name
           ^ "; ignoring its body.\nName pattern: '" ^ name_pattern ^ "'");
          OpaqueBody)
    | other -> other
  in
  { f with body }

(** We do not support static regions yet.

    In order to support some printing functions, for now we update their
    signature to replace ['static] with a region variable. This should be fine
    as a temporary measure as we can pretend these functions copy the input
    string they receive (the static references are references to strings).

    TODO: remove once https://github.com/AeneasVerif/aeneas/issues/727 is fixed
*)
let replace_static (crate : crate) : crate =
  (* We update the uses of: [core::fmt::{core::fmt::Arguments<'a>}::from_str] *)
  let pat =
    NameMatcher.parse_pattern "core::fmt::{core::fmt::Arguments<'a>}::from_str"
  in

  (* Find the function [core::fmt::{core::fmt::Arguments<'a>}::from_str]:
     - we want to update its signature to replace 'static with a lifetime variable
     - we want to update its uses
  *)
  let names_set = NameMatcher.NameMatcherMap.of_list [ (pat, ()) ] in
  let match_ctx = Charon.NameMatcher.ctx_from_crate crate in
  let in_set (d : fun_decl) : bool =
    let config = ExtractName.default_match_config in
    NameMatcher.NameMatcherMap.mem match_ctx config d.item_meta.name names_set
  in
  let decl_opt = ref None in
  let in_set (_ : FunDeclId.id) (d : fun_decl) =
    if in_set d then (
      decl_opt := Some d;
      true)
    else false
  in

  if not (FunDeclId.Map.exists in_set crate.fun_decls) then crate
  else (* The function [from_str] is used in the crate *)
    let d = Option.get !decl_opt in

    (* Update the signature *)
    let generics =
      {
        d.generics with
        regions =
          d.generics.regions
          @ [
              {
                index = RegionId.of_int 1;
                name = Some "'b";
                mutability = LtUnknown;
              };
            ];
      }
    in
    let signature =
      let visitor =
        object
          inherit [_] map_ty
          method! visit_RStatic _ = RVar (Free (RegionId.of_int 1))
        end
      in
      visitor#visit_fun_sig () d.signature
    in

    let d = { d with generics; signature } in
    [%ltrace
      let env = Print.crate_to_fmt_env crate in
      "Updated declaration:\n" ^ Print.fun_decl_to_string env "" " " d];
    let crate =
      { crate with fun_decls = FunDeclId.Map.add d.def_id d crate.fun_decls }
    in

    (* Update the uses of this definition *)
    let update (f : fun_decl) : fun_decl =
      match f.body with
      | StructuredBody body ->
          let visitor =
            object
              inherit [_] map_statement

              method! visit_Call _ call =
                match call.func with
                | FnOpRegular { kind = FunId (FRegular id) as kind; generics }
                  when id = d.def_id ->
                    let func =
                      FnOpRegular
                        {
                          kind;
                          generics =
                            {
                              generics with
                              regions = generics.regions @ [ RErased ];
                            };
                        }
                    in
                    Call { call with func }
                | _ -> Call call
            end
          in

          let body = { body with body = visitor#visit_block () body.body } in
          { f with body = StructuredBody body }
      | _ -> f
    in
    let fun_decls = FunDeclId.Map.map update crate.fun_decls in
    { crate with fun_decls }

(** Charon introduces vtables for the traits which support dyn. We do not want
    to translate the corresponding type and global declarations. Moreover, the
    presence of those declarations leads to mutually recursive groups of traits
    and types. This micro-pass filters these definitions. *)
let remove_vtables (crate : crate) : crate =
  let src_is_vtable (src : item_source) : bool =
    match src with
    | VTableInstanceItem _ | VTableTyItem _ | VTableMethodShimItem -> true
    | _ -> false
  in

  (* Filter the groups.

     We detect mixed groups which combine trait declarations and their corresponding
     vtable types, and remove the vtable types (and convert the group to a homogeneous
     group if possible). We also filter the globals (and the functions corresponding
     to their implementation) introduced for the vtables.
  *)
  let declarations =
    List.filter_map
      (fun (g : declaration_group) ->
        match g with
        | GlobalGroup g -> (
            (* Filter the vtables *)
            let keep (id : global_decl_id) : bool =
              match GlobalDeclId.Map.find_opt id crate.global_decls with
              | None -> true
              | Some d -> not (src_is_vtable d.src)
            in
            match g with
            | RecGroup ids ->
                let ids = List.filter keep ids in
                if ids <> [] then Some (GlobalGroup (RecGroup ids)) else None
            | NonRecGroup id ->
                if keep id then Some (GlobalGroup (NonRecGroup id)) else None)
        | FunGroup g -> (
            (* Filter the vtables *)
            let keep (id : fun_decl_id) : bool =
              match FunDeclId.Map.find_opt id crate.fun_decls with
              | None -> true
              | Some d -> not (src_is_vtable d.src)
            in
            match g with
            | RecGroup ids ->
                let ids = List.filter keep ids in
                if ids <> [] then Some (FunGroup (RecGroup ids)) else None
            | NonRecGroup id ->
                if keep id then Some (FunGroup (NonRecGroup id)) else None)
        | TypeGroup g -> (
            (* Filter the vtables *)
            let keep (id : type_decl_id) : bool =
              match TypeDeclId.Map.find_opt id crate.type_decls with
              | None -> true
              | Some d -> not (src_is_vtable d.src)
            in
            match g with
            | RecGroup ids ->
                let ids = List.filter keep ids in
                if ids <> [] then Some (TypeGroup (RecGroup ids)) else None
            | NonRecGroup id ->
                if keep id then Some (TypeGroup (NonRecGroup id)) else None)
        | MixedGroup g -> (
            (* If the group is a mutually recursive group, filter the vtable types
               and check if the resulting group is only made of trait declarations.

               TODO: we should check whether the resulting group is recursive or not.
            *)
            match g with
            | RecGroup ids ->
                let keep (id : type_decl_id) : bool =
                  match TypeDeclId.Map.find_opt id crate.type_decls with
                  | None -> true
                  | Some d -> not (src_is_vtable d.src)
                in
                let ids =
                  List.filter
                    (fun (id : item_id) ->
                      match id with
                      | IdType id -> keep id
                      | _ -> true)
                    ids
                in
                (* Note that the resulting group shouldn't be empty, but we can
                   still support this case *)
                if ids = [] then None
                else if
                  List.for_all
                    (fun (id : item_id) ->
                      match id with
                      | IdTraitDecl _ -> true
                      | _ -> false)
                    ids
                then
                  (* There only remains trait ids *)
                  let ids =
                    List.map
                      (fun (id : item_id) ->
                        match id with
                        | IdTraitDecl id -> id
                        | _ -> raise (Failure "Unreachable"))
                      ids
                  in
                  (* If the resulting group is a singleton, check whether
                     it is recursive *)
                  match ids with
                  | [ id ] ->
                      let is_rec =
                        match TraitDeclId.Map.find_opt id crate.trait_decls with
                        | None ->
                            (* don't know so by default we consider it to be recursive *)
                            true
                        | Some d ->
                            (* We count the number of occurrences of the id of the trait
                             decl itself - if it's > 1 then it means it is recursive
                             (there is one occurrence for the [def_id] field) *)
                            let found = ref 0 in
                            let visitor =
                              object (self)
                                inherit [_] iter_trait_decl

                                method! visit_trait_ref_contents _
                                    { kind; trait_decl_ref = _ } =
                                  (* We ignore the [trait_decl_ref] which refer
                                     to the trait declaration itself if this is
                                     an occurrence of [Self] *)
                                  self#visit_trait_ref_kind () kind

                                method! visit_trait_decl_id _ id' =
                                  if id' = id then found := !found + 1
                              end
                            in
                            visitor#visit_trait_decl () { d with vtable = None };
                            !found > 1
                      in
                      if is_rec then Some (TraitDeclGroup (RecGroup [ id ]))
                      else Some (TraitDeclGroup (NonRecGroup id))
                  | _ -> Some (TraitDeclGroup (RecGroup ids))
                else Some (MixedGroup (RecGroup ids))
            | _ -> Some (MixedGroup g))
        | _ -> Some g)
      crate.declarations
  in

  (* *)
  let type_decls =
    TypeDeclId.Map.filter
      (fun _ (d : type_decl) -> not (src_is_vtable d.src))
      crate.type_decls
  in

  let global_decls =
    GlobalDeclId.Map.filter
      (fun _ (d : global_decl) -> not (src_is_vtable d.src))
      crate.global_decls
  in

  let fun_decls =
    FunDeclId.Map.filter
      (fun _ (d : fun_decl) -> not (src_is_vtable d.src))
      crate.fun_decls
  in

  let trait_decls =
    TraitDeclId.Map.map
      (fun (d : trait_decl) ->
        (* Remove the vtable *)
        { d with vtable = None })
      crate.trait_decls
  in

  let trait_impls =
    TraitImplId.Map.map
      (fun (d : trait_impl) -> { d with vtable = None })
      crate.trait_impls
  in

  {
    crate with
    declarations;
    type_decls;
    global_decls;
    fun_decls;
    trait_decls;
    trait_impls;
  }

let name_is_valid (n : string) : bool =
  let is_valid_char c =
    (c >= 'a' && c <= 'z')
    || (c >= 'A' && c <= 'Z')
    || (c >= '0' && c <= '9')
    || c = '_'
  in
  String.for_all is_valid_char n

(** The basename introduced by Charon for impl types (see
    https://github.com/AeneasVerif/charon/issues/1013) is an invalid name: we
    detect this case here and use a valid name instead. As it only happens for
    inputs of type `impl Trait` we use `Impl` as a basename. *)
let rename_type_vars (crate : crate) : crate =
  let visitor =
    object
      inherit [_] map_crate as super

      method! visit_generic_params env generics =
        (* Explore the types and rename them *)
        let num_renames =
          List.length
            (List.filter
               (fun (p : type_param) -> not (name_is_valid p.name))
               generics.types)
        in
        let rename =
          if num_renames > 1 then (
            let index = ref 0 in
            fun () ->
              let i = !index in
              index := !index + 1;
              "Impl" ^ string_of_int i)
          else fun () -> "Impl"
        in
        let types =
          List.map
            (fun (p : type_param) ->
              let name = if name_is_valid p.name then p.name else rename () in
              { p with name })
            generics.types
        in
        super#visit_generic_params env { generics with types }
    end
  in
  visitor#visit_crate () crate

(*
```ocaml
*)
let provided_source (crate : crate) (f : fun_decl) =
  match f.src with
  | TraitImplItem (_, tr, name, true) ->
      let decl = TraitDeclId.Map.find tr.id crate.trait_decls in
      let method_decl =
        List.find
          (fun (method_decl : trait_method binder) ->
            method_decl.binder_value.name = name)
          decl.methods
      in
      let source =
        FunDeclId.Map.find method_decl.binder_value.item.id crate.fun_decls
      in
      (match source.src with
      | TraitDeclItem (source_tr, source_name, true)
        when source_tr.id = tr.id && source_name = name -> Some source
      | _ -> None)
  | _ -> None

let reference_identity (f : fun_decl) =
  match (f.signature.inputs, f.signature.output, f.body) with
  | ( [ (TRef _ as argument) ],
      result,
      StructuredBody
        {
          locals = { arg_count = 1; _ };
          body =
            {
              statements =
                [
                  {
                    kind =
                      Assign
                        ( { kind = PlaceLocal dest; ty },
                          Use (Move input | Copy input) );
                    _;
                  };
                  { kind = Return; _ };
                ];
              _;
            };
          _;
        } )
    when dest = LocalId.zero
         && input.kind = PlaceLocal (LocalId.of_int 1)
         && argument = result
         && TypesUtils.ty_matches_body_annotation ty result
         && TypesUtils.ty_matches_body_annotation input.ty argument -> true
  | _ -> false

let reference_identity_or_provided (crate : crate) (f : fun_decl) =
  reference_identity f
  ||
  match (f.signature.inputs, f.signature.output, provided_source crate f) with
  | [ (TRef _ as input) ], output, Some source ->
      input = output && reference_identity source
  | _ -> false
(*
```
*)

(** Simplify calls to:
    - the blanket [IntoIterator::into_iter] implementation (we replace it with
      an assignment), including its partial-monomorphization instances (e.g.
      [into_iter::<IterMut<'0, T>, &'0 mut T>] of a [for] loop over a lending
      iterator): the body of the blanket implementation is [self] at every
      instantiation
    - the blanket [TryInto::try_into] implementation (we replace it with a call
      to the [try_from] method of the required [TryFrom] clause)
    - unary reference identities, verified from their complete Rust bodies

    TODO: remove once we have partial monomorphization *)
let simplify_trait_calls (crate : crate) : crate =
  (* Create a map from pattern to method *)
  (* Blanket definition for [into_iter] *)
  let into_iter_pat =
    NameMatcher.parse_pattern
      "core::iter::traits::collect::{core::iter::traits::collect::IntoIterator<@I, \
       @Item, @I>}::into_iter"
  in
  (* Blanket definition for [try_into] *)
  let try_into_pat =
    NameMatcher.parse_pattern
      "core::convert::{core::convert::TryInto<@T, @U, @Error>}::try_into"
  in
  let mctx = NameMatcher.ctx_from_crate crate in
  let match_pattern =
    NameMatcher.match_name mctx
      {
        map_vars_to_vars = true;
        match_with_trait_decl_refs = Config.match_patterns_with_trait_decl_refs;
      }
  in
  (* The name of a partial-monomorphization instance without its shape: the
     matcher compares the shape with the generics of the pattern's last
     element, which the blanket pattern leaves empty. *)
  let logical_name (name : name) =
    match List.rev name with
    | PeInstantiated _ :: rest -> List.rev rest
    | _ -> name
  in
  let is_blanket_into_iter name =
    match_pattern into_iter_pat (logical_name name)
  in
  let is_blanket_try_into = match_pattern try_into_pat in
  (*
```ocaml
  *)
  let provided_method (f : fun_decl) =
    match f.src with
    | TraitDeclItem (tr, name, true) -> Some (tr.id, name)
    | _ ->
        Option.map
          (fun (source : fun_decl) ->
            match source.src with
            | TraitDeclItem (tr, name, true) -> (tr.id, name)
            | _ -> [%internal_error] f.item_meta.span)
          (provided_source crate f)
  in
  let reference_identities =
    FunDeclId.Map.fold
      (fun id (f : fun_decl) ids ->
        if reference_identity_or_provided crate f then
          FunDeclId.Set.add id ids
        else ids)
      crate.fun_decls FunDeclId.Set.empty
  (*
```
  *)
  in
  let identity_defaults =
    FunDeclId.Set.filter
      (fun id ->
        let f = FunDeclId.Map.find id crate.fun_decls in
        let provided = provided_method f in
        match provided with
        | None -> false
        | Some (id, name) -> (
            let decl = TraitDeclId.Map.find id crate.trait_decls in
            match
              ExtractBuiltin.find_trait_decl_info mctx decl.item_meta.name
            with
            | Some info -> not (List.mem_assoc name info.methods)
            | None -> false))
      reference_identities
  in

  let try_replace_call (super_visit : unit -> statement_kind) (span : Meta.span)
      (call : call) : statement_kind =
    match call.func with
    | FnOpRegular { kind = FunId (FRegular fid); generics } -> (
        match FunDeclId.Map.find_opt fid crate.fun_decls with
        (*
```ocaml
        *)
        | Some d when FunDeclId.Set.mem fid reference_identities -> (
            (* The source body returns its only reference argument.
               Inherited copies require the provided-method source link.
               Concrete overrides require their own body proof. *)
            let subst =
              [%add_loc] Substitute.make_subst_from_generics (Some span)
                d.generics generics
                (UnknownTrait "reference identity has no free Self dictionary")
            in
            let signature =
              Substitute.st_substitute_visitor#visit_fun_sig subst d.signature
            in
            match (signature.inputs, signature.output, call.args) with
            | [ (TRef _ as input) ], output, [ arg ] ->
                let operand_ty =
                  match arg with
                  | Copy p | Move p -> p.ty
                  | Constant c -> c.ty
                in
                [%cassert] span
                  (input = output
                  && TypesUtils.ty_matches_body_annotation call.dest.ty output
                  && TypesUtils.ty_matches_body_annotation operand_ty input)
                  ("Reference identity has different operand types"
                  ^ "\n- input: " ^ Types.show_ty input
                  ^ "\n- output: " ^ Types.show_ty output
                  ^ "\n- destination: " ^ Types.show_ty call.dest.ty
                  ^ "\n- operand: " ^ Types.show_ty operand_ty);
                Assign (call.dest, Use arg)
            | _ -> [%internal_error] span)
        (*
```
        *)
        | Some d
          when List.length generics.trait_refs > 0 && List.length call.args > 0
          ->
            if is_blanket_into_iter d.item_meta.name then (
              (* Replace the call by an assignment *)
              [%sanity_check] span (List.length call.args = 1);
              let arg = Use (List.hd call.args) in
              Assign (call.dest, arg))
            else if is_blanket_try_into d.item_meta.name then (
              [%ldebug
                "- call: " ^ call_to_string crate call ^ "\n- generics: "
                ^ generic_args_to_string crate generics];
              (* There should be a single trait ref implementing [TryFrom] *)
              match generics.trait_refs with
              | [ trait_ref ] -> (
                  (* There are two cases depending on whether this is an impl or not *)
                  match trait_ref.kind with
                  | TraitImpl { id = impl_id; generics = impl_generics } ->
                      (* Lookup the impl to retrieve the method id *)
                      let impl =
                        [%unwrap_with_span] span
                          (TraitImplId.Map.find_opt impl_id crate.trait_impls)
                          "Internal error"
                      in
                      let method_ref =
                        snd
                          ([%unwrap_with_span] span
                             (List.find_opt
                                (fun (name, _) -> name = "try_from")
                                impl.methods)
                             "Internal error")
                      in

                      [%sanity_check] span
                        (method_ref.binder_params = empty_generic_params);

                      [%ldebug
                        "- call: " ^ call_to_string crate call
                        ^ "\n- generics: "
                        ^ generic_args_to_string crate generics
                        ^ "\n- impl.generic_params: "
                        ^ generic_params_to_string crate impl.generics
                        ^ "\n- impl_generics: "
                        ^ generic_args_to_string crate impl_generics
                        ^ "\n- method_ref.binder_params: "
                        ^ generic_params_to_string crate
                            method_ref.binder_params
                        ^ "\n- method_ref.binder_value: "
                        ^ fun_decl_ref_to_string crate method_ref.binder_value
                        ^ "\n "];

                      (* Instantiate *)
                      let subst =
                        [%add_loc] Substitute.make_subst_from_generics
                          (Some span) impl.generics impl_generics
                          (UnknownTrait "UNREACHABLE")
                      in
                      let generics =
                        Substitute.generic_args_substitute subst
                          method_ref.binder_value.generics
                      in

                      (* *)
                      let kind = FunId (FRegular method_ref.binder_value.id) in
                      let func = FnOpRegular { kind; generics } in
                      Call { call with func }
                  | _ ->
                      (* TODO: *)
                      super_visit ())
              | _ -> [%internal_error] span)
            else super_visit ()
        | _ -> super_visit ())
    | _ -> super_visit ()
  in

  (* The map visitor to simplify the calls *)
  let visitor =
    object
      inherit [_] map_crate as super

      (* Keep track of the last span *)
      method! visit_statement _ st = super#visit_statement (Some st.span) st

      method! visit_Call span call =
        try_replace_call
          (fun _ -> super#visit_Call span call)
          (Option.get span) call
    end
  in
  let crate = visitor#visit_crate None crate in

  (* Imported implementations replace Rust bodies, including their private
     representation dependencies. Compute reachability after that cutover,
     rather than retaining dependencies from bodies which are never exported. *)
  let mctx = NameMatcher.ctx_from_crate crate in
  let has_model models name =
    Config.if_backend
      (fun () -> ExtractBuiltin.NameMatcherMap.mem mctx name (models ()))
      false
  in
  let is_modeled_function (f : fun_decl) =
    match f.is_global_initializer with
    | Some id ->
        let global = GlobalDeclId.Map.find id crate.global_decls in
        has_model ExtractBuiltin.builtin_globals_map global.item_meta.name
    | None ->
        Config.if_backend
          (fun () -> ExtractBuiltin.mem_fun mctx f.def_id f.item_meta.name)
          false
  in
  let fun_decls =
    FunDeclId.Map.map
      (fun (f : fun_decl) ->
        if LlbcAstUtils.body_is_known f.body && is_modeled_function f then
          { f with body = OpaqueBody }
        else f)
      crate.fun_decls
  in
  (* Likewise, a local type with an opaque model (a crate-local native
     primitive) has no Rust representation in the translation: its fields may
     mention native types that only the replaced bodies used. *)
  let type_decls =
    TypeDeclId.Map.map
      (fun (d : type_decl) ->
        let opaque_model =
          d.item_meta.is_local
          && Config.if_backend
               (fun () ->
                 match
                   ExtractBuiltin.NameMatcherMap.find_opt mctx d.item_meta.name
                     (ExtractBuiltin.builtin_types_map ())
                 with
                 | Some (info : Pure.builtin_type_info) ->
                     Option.is_none info.body_info
                 | None -> false)
               false
        in
        if opaque_model then { d with kind = Opaque } else d)
      crate.type_decls
  in
  let crate = { crate with fun_decls; type_decls } in
  let declared =
    List.fold_left
      (fun declared group ->
        List.fold_left
          (fun declared id -> AnyDeclIdSet.add id declared)
          declared
          (declaration_group_to_list group))
      AnyDeclIdSet.empty crate.declarations
  in
  let used = ref AnyDeclIdSet.empty in
  let pending = ref [] in
  let require id =
    let is_identity =
      match id with
      | IdFun id -> FunDeclId.Set.mem id identity_defaults
      | _ -> false
    in
    if
      (not is_identity)
      && AnyDeclIdSet.mem id declared
      && not (AnyDeclIdSet.mem id !used)
    then (
      used := AnyDeclIdSet.add id !used;
      pending := id :: !pending)
  in
  let visited_types = TyCache.create 16 in
  let visitor =
    object
      inherit [_] iter_crate as super

      method! visit_ty env ty =
        if not (TyCache.mem visited_types ty) then (
          TyCache.add visited_types ty ();
          super#visit_ty env ty)

      method! visit_item_meta _ _ = ()
      method! visit_type_decl_id _ id = require (IdType id)
      method! visit_fun_decl_id _ id = require (IdFun id)
      method! visit_global_decl_id _ id = require (IdGlobal id)
      method! visit_trait_decl_id _ id = require (IdTraitDecl id)
      method! visit_trait_impl_id _ id = require (IdTraitImpl id)
    end
  in
  (* Items nested in a modeled function (its closures, their trait
     implementations and methods) belong to the replaced body: they are not
     roots, even when local. *)
  let modeled_local_functions =
    FunDeclId.Map.fold
      (fun _ (f : fun_decl) names ->
        if f.item_meta.is_local && is_modeled_function f then
          f.item_meta.name :: names
        else names)
      crate.fun_decls []
  in
  let nested_in_modeled_function (name : name) =
    List.exists
      (fun owner ->
        let n = List.length owner in
        List.length name > n
        && fst (Collections.List.split_at name n) = owner)
      modeled_local_functions
  in
  (* The roots are the items Charon started from (with everything named under
     them), or every local item when Charon started from the whole crate.
     Items Charon translated only as dependencies of replaced bodies are not
     roots. *)
  let start_from =
    match StartFrom.of_options crate.options with
    | Ok start_from -> start_from
    | Error pattern ->
        [%craise_opt_span] None
          ("Cannot parse Charon's --start-from pattern: " ^ pattern)
  in
  let is_root (meta : item_meta) =
    (not (nested_in_modeled_function meta.name))
    &&
    if start_from = [] then meta.is_local
    else List.exists (fun sf -> StartFrom.matches crate sf meta) start_from
  in
  AnyDeclIdSet.iter
    (fun id ->
      match LlbcAstUtils.crate_get_item_meta crate id with
      | Some meta when is_root meta -> require id
      | _ -> ())
    declared;
  (* Preserve explicitly supplied external-only crates when no local root is
     available to distinguish their roots from dependencies. *)
  if AnyDeclIdSet.is_empty !used then AnyDeclIdSet.iter require declared;
  while !pending <> [] do
    let id = List.hd !pending in
    pending := List.tl !pending;
    match id with
    | IdFun id ->
        let f = FunDeclId.Map.find id crate.fun_decls in
        (* The bodies of external functions are emitted by their owner chunk *)
        if
          is_modeled_function f
          || SeparateCompilation.is_external (IdFun f.def_id)
        then (
          visitor#visit_generic_params () f.generics;
          visitor#visit_fun_sig () f.signature)
        else visitor#visit_fun_decl () f
    | IdType id -> (
        let d = TypeDeclId.Map.find id crate.type_decls in
        (* A model of the representation (the variants or fields of the Rust
           type, e.g. BTreeMap's Entry) keeps the Rust declaration, whose field
           types the type analysis and the interpreter use: they are required.
           A model without a representation only uses the parameters. *)
        match
          Config.if_backend
            (fun () ->
              ExtractBuiltin.NameMatcherMap.find_opt mctx d.item_meta.name
                (ExtractBuiltin.builtin_types_map ()))
            None
        with
        | Some ({ body_info = None; _ } : Pure.builtin_type_info) ->
            visitor#visit_generic_params () d.generics
        | _ -> visitor#visit_type_decl () d)
    | IdGlobal id ->
        let d = GlobalDeclId.Map.find id crate.global_decls in
        require (IdFun d.init);
        if has_model ExtractBuiltin.builtin_globals_map d.item_meta.name then (
          visitor#visit_generic_params () d.generics;
          visitor#visit_ty () d.ty)
        else visitor#visit_global_decl () d
    | IdTraitDecl id ->
        visitor#visit_trait_decl () (TraitDeclId.Map.find id crate.trait_decls)
    | IdTraitImpl id ->
        let impl = TraitImplId.Map.find id crate.trait_impls in
        let decl = TraitDeclId.Map.find impl.impl_trait.id crate.trait_decls in
        let modeled =
          Config.if_backend
            (fun () ->
              Option.is_some
                (ExtractBuiltin.find_trait_impl_info mctx decl.item_meta.name
                   impl.impl_trait.generics))
            false
        in
        if modeled then (
          visitor#visit_generic_params () impl.generics;
          visitor#visit_trait_decl_ref () impl.impl_trait;
          List.iter (visitor#visit_trait_ref ()) impl.implied_trait_refs)
        else visitor#visit_trait_impl () impl
  done;
  let filter =
    object
      inherit [_] filter_decl_id

      method! visit_type_decl_id _ id =
        if AnyDeclIdSet.mem (IdType id) !used then Some id else None

      method! visit_fun_decl_id _ id =
        if AnyDeclIdSet.mem (IdFun id) !used then Some id else None

      method! visit_global_decl_id _ id =
        if AnyDeclIdSet.mem (IdGlobal id) !used then Some id else None

      method! visit_trait_decl_id _ id =
        if AnyDeclIdSet.mem (IdTraitDecl id) !used then Some id else None

      method! visit_trait_impl_id _ id =
        if AnyDeclIdSet.mem (IdTraitImpl id) !used then Some id else None
    end
  in
  {
    crate with
    declarations = filter#visit_declaration_groups () crate.declarations;
  }

(** Add missing outlives constraints for closure trait implementations.

    Charon sometimes fails to properly retrieves the lifetime constraints
    between the inputs and outputs of closures. This passes is a temporary
    (ad-hoc) fix for the following situation:
    {[
      call_mut<'a, 'b, 'c>(v@1 : &'c mut closure<'a>) -> &'b T
    ]}
    that we update to:
    {[
      call_mut<'b, 'c>(v@1 : &'c mut closure<'a>) -> &'a T
    ]}

    Similarly we do:
    {[
      call_once<'a, 'b>(v@1 : mut closure<'a>) -> &'b T
    ]}
    that we update to:
    {[
      call_once<'b, 'c>(v@1 : mut closure<'a>) -> &'a T
    ]}

    See https://github.com/AeneasVerif/aeneas/issues/804 and
    https://github.com/AeneasVerif/charon/issues/1040.

    The output keeps its region when the signature says that a region other
    than the one of the closure outlives it: the output then borrows from an
    input, not from the state. For instance, a closure defined in
    [fn visit<'a, T>] has the region ['a] (closure types take the generics of
    their parent) even if it captures nothing, and the closure [|s| s.literal]
    on [s : Src<'_1>] has the signature
    {[
      call_once<'a, '_1, '_2, T>(v@1 : closure<'a, T>, (Src<'_1>,)) -> &'_2 Expr
      where '_1 : '_2
    ]}
    which the update above would turn into a function whose output borrows
    from [v@1].

    TODO: remove once the Charon issue is fixed. *)
let fix_closure_lifetimes (crate : crate) (f : fun_decl) : fun_decl =
  (* Check that the function is a closure *)
  (* Decompose the type of the first argument (it should be the state).
     We do the update only if the state is inside a reference. *)
  let find_input_region (ty : ty) =
    match ty with
    | TAdt { id = TAdtId id; generics = { regions = [ RVar rid ]; _ } }
    | TRef
        (_, TAdt { id = TAdtId id; generics = { regions = [ RVar rid ]; _ } }, _)
      -> (
        match TypeDeclId.Map.find_opt id crate.type_decls with
        | Some decl -> (
            match decl.src with
            | ClosureItem _ -> Some rid
            | _ -> None)
        | None -> None)
    | _ -> None
  in
  match f.signature.inputs with
  | [] -> f
  | first_input :: _ -> (
      (* Does a region other than the one of the closure outlive [r]? *)
      let outlived_by_other_region (input_rid : region_id de_bruijn_var)
          (r : region) =
        List.exists
          (fun (p : (region, region) outlives_pred region_binder) ->
            let long, short = p.binder_value in
            short = r && long <> r && long <> RVar input_rid)
          f.generics.regions_outlive
      in
      match (find_input_region first_input, f.signature.output) with
      | Some input_rid, TRef ((RVar _ as r), _, _)
        when outlived_by_other_region input_rid r ->
          f
      | Some input_rid, TRef (RVar _, ref_ty, kind) ->
          (* TODO: support more cases for the output? *)
          let output = TRef (RVar input_rid, ref_ty, kind) in
          (* Remark: we don't have to remove the region we substitute from the region
             parameters *)
          let signature = { f.signature with output } in
          let f = { f with signature } in
          [%ltrace
            let env = Print.crate_to_fmt_env crate in
            "Updated: " ^ Print.fun_decl_to_string env "" " " f];
          f
      | _, _ -> f)

(** Resolve inherited implementations through real models, whether Charon
    supplied their body or not. Dictionary fields retain dispatch; fieldless
    provided methods use their standalone model. Overrides are never eligible.
*)
let resolve_modeled_defaults (crate : crate) : crate =
  if Config.backend () <> Config.Lean then crate
  else
    let mctx = NameMatcher.ctx_from_crate crate in
    let matches pat name =
      NameMatcher.match_name mctx
        {
          map_vars_to_vars = true;
          match_with_trait_decl_refs =
            Config.match_patterns_with_trait_decl_refs;
        }
        pat name
    in
    let modeled_traits =
      TraitDeclId.Map.filter_map
        (fun _ (decl : trait_decl) ->
          ExtractBuiltin.find_trait_decl_info mctx decl.item_meta.name)
        crate.trait_decls
    in
    let defaults =
      FunDeclId.Map.filter_map
        (fun _ (f : fun_decl) ->
          match f.src with
          | TraitImplItem (impl_ref, trait_ref, name, true) ->
              let decl = TraitDeclId.Map.find trait_ref.id crate.trait_decls in
              let through_dictionary =
                match TraitDeclId.Map.find_opt trait_ref.id modeled_traits with
                | Some info -> (
                    match List.assoc_opt name info.methods with
                    | Some method_info -> method_info.has_default
                    | None -> false)
                | None -> false
              in
              let standalone_eligible =
                match TraitDeclId.Map.find_opt trait_ref.id modeled_traits with
                | Some info -> not (List.mem_assoc name info.methods)
                | None -> false
              in
              (* Charon declares only the trait methods the crate demands: an
                 implementation can supply a provided method whose trait-side
                 declaration (and default body) was never translated. Nothing
                 can then be inherited through the declaration. *)
              let default_decl =
                Option.bind
                  (List.find_opt
                     (fun (m : trait_method binder) ->
                       m.binder_value.name = name)
                     decl.methods)
                  (fun method_decl ->
                    FunDeclId.Map.find_opt method_decl.binder_value.item.id
                      crate.fun_decls)
              in
              let inherited =
                match default_decl with
                | Some { src = TraitDeclItem (tr, method_name, true); _ } ->
                    tr.id = decl.def_id && method_name = name
                | _ -> false
              in
              let modeled =
                through_dictionary
                || standalone_eligible
                   &&
                   match default_decl with
                   | Some default_decl ->
                       List.exists
                         (fun (pattern, _) ->
                           matches pattern default_decl.item_meta.name)
                         (ExtractBuiltin.builtin_funs ())
                   | None -> false
              in
              if (not inherited) || not modeled then None
              else
                let impl = TraitImplId.Map.find impl_ref.id crate.trait_impls in
                let method_ref = List.assoc name impl.methods in
                Some
                  ( f,
                    impl_ref,
                    trait_ref,
                    name,
                    method_ref,
                    decl,
                    through_dictionary )
          | _ -> None)
        crate.fun_decls
    in
    (* A provided-method copy whose trait declaration does not list the
       method: Charon declares only the trait methods the crate demands, so no
       crate code calls the method through a dictionary, and the copy has no
       declaration to inherit through ([defaults] above). When no declaration
       calls the copy either, it is dead: it is inherited like [defaults] if the
       modeled trait provides the method, as a field with a default or as the
       standalone model of the provided method. Charon's [reuses_default] also
       holds for implementations of required methods; the model's provided
       method is the evidence that the trait provides it. A called copy stays
       (an unknown external, fail-closed). *)
    let called =
      let called = ref FunDeclId.Set.empty in
      let visitor =
        object
          inherit [_] iter_crate

          method! visit_fun_decl_id owner id =
            if id <> owner then called := FunDeclId.Set.add id !called
        end
      in
      FunDeclId.Map.iter
        (fun id (f : fun_decl) -> visitor#visit_fun_decl id f)
        crate.fun_decls;
      !called
    in
    let unlisted_defaults =
      FunDeclId.Map.filter_map
        (fun fid (f : fun_decl) ->
          match f.src with
          | TraitImplItem (_, trait_ref, name, true)
            when not (FunDeclId.Set.mem fid called) -> (
              match TraitDeclId.Map.find_opt trait_ref.id modeled_traits with
              | None -> None
              | Some info ->
                  let decl =
                    TraitDeclId.Map.find trait_ref.id crate.trait_decls
                  in
                  let listed =
                    List.exists
                      (fun (m : trait_method binder) ->
                        m.binder_value.name = name)
                      decl.methods
                  in
                  let provided =
                    match List.assoc_opt name info.methods with
                    | Some method_info -> method_info.has_default
                    | None ->
                        let method_name =
                          decl.item_meta.name
                          @ [ PeIdent (name, Disambiguator.zero) ]
                        in
                        List.exists
                          (fun (pattern, _) -> matches pattern method_name)
                          (ExtractBuiltin.builtin_funs ())
                  in
                  if (not listed) && provided then Some () else None)
          | _ -> None)
        crate.fun_decls
    in
    let inherited_copy id =
      FunDeclId.Map.mem id defaults || FunDeclId.Map.mem id unlisted_defaults
    in
    let no_inherited_copies =
      FunDeclId.Map.is_empty defaults && FunDeclId.Map.is_empty unlisted_defaults
    in
    let new_dictionary_uses = ref FunDeclId.Map.empty in
    (* The parent recorded in a method's source is metadata, but the same
         implementation can also occur in its body: recursive derived methods
         pass their own dictionary through imported box/formatting models. *)
    FunDeclId.Map.iter
      (fun fid (decl : fun_decl) ->
        match (decl.src, decl.body) with
        | TraitImplItem (parent, _, _, _), StructuredBody body -> (
            let exception UsesParentDictionary in
            let visitor =
              object
                inherit [_] iter_statement

                method! visit_trait_impl_id () id =
                  if id = parent.id then raise UsesParentDictionary
              end
            in
            try visitor#visit_block () body.body
            with UsesParentDictionary ->
              new_dictionary_uses :=
                FunDeclId.Map.update fid
                  (fun uses ->
                    Some
                      (TraitImplId.Set.add parent.id
                         (Option.value uses ~default:TraitImplId.Set.empty)))
                  !new_dictionary_uses)
        | _ -> ())
      crate.fun_decls;
    if
      no_inherited_copies
      && FunDeclId.Map.is_empty !new_dictionary_uses
    then crate
    else
      let new_method_uses = ref FunDeclId.Map.empty in
      let visitor =
        object
          inherit [_] map_crate as super

          method! visit_fun_decl _ (f : fun_decl) =
            super#visit_fun_decl (Some f.def_id) f

          method! visit_fn_ptr env ptr =
            let ptr = super#visit_fn_ptr env ptr in
            match ptr.kind with
            | FunId (FRegular fid) when FunDeclId.Map.mem fid defaults ->
                let ( f,
                      impl_ref,
                      trait_decl_ref,
                      name,
                      method_ref,
                      decl,
                      through_dictionary ) =
                  FunDeclId.Map.find fid defaults
                in
                let span = f.item_meta.span in
                Option.iter
                  (fun owner ->
                    new_dictionary_uses :=
                      FunDeclId.Map.update owner
                        (fun uses ->
                          Some
                            (TraitImplId.Set.add impl_ref.id
                               (Option.value uses ~default:TraitImplId.Set.empty)))
                        !new_dictionary_uses)
                  env;
                let subst =
                  [%add_loc] Substitute.make_subst_from_generics (Some span)
                    f.generics ptr.generics
                    (UnknownTrait "inherited method has no free Self dictionary")
                in
                let trait_ref =
                  Substitute.trait_ref_substitute subst
                    {
                      kind = TraitImpl impl_ref;
                      trait_decl_ref =
                        { binder_regions = []; binder_value = trait_decl_ref };
                    }
                in
                (* Recover the method binder from its actual argument template,
                   not by dropping an impl-parameter prefix. Associated-type
                   lifting can interleave impl and method parameters. *)
                let select get_id ids template actual =
                  [%cassert] span
                    (List.length template = List.length actual)
                    (* ```ocaml *)
                    ("Inherited method argument arity mismatch"
                    ^ "\n- inherited function: " ^ FunDeclId.to_string f.def_id
                    ^ "\n- dictionary: " ^ TraitImplId.to_string impl_ref.id
                    ^ "\n- method template function: "
                    ^ FunDeclId.to_string method_ref.binder_value.id
                    ^ "\n- name: " ^ Print.name_to_string (Print.crate_to_fmt_env crate)
                        f.item_meta.name
                    ^ "\n- template arity: " ^ string_of_int (List.length template)
                    ^ "\n- actual arity: " ^ string_of_int (List.length actual));
                    (* ``` *)
                  let pairs = List.combine template actual in
                  List.map
                    (fun id ->
                      let values =
                        List.filter_map
                          (fun (template, actual) ->
                            if get_id template = Some id then Some actual
                            else None)
                          pairs
                      in
                      match values with
                      | value :: rest when List.for_all (( = ) value) rest ->
                          value
                      | _ ->
                          [%craise] span
                            "Cannot recover an inherited method binder")
                    ids
                in
                let params = method_ref.binder_params in
                let template = method_ref.binder_value.generics in
                (* The specialization supplies fixed method arguments.
                   Its binder retains the actual dictionary and closure witnesses. *)
                (* ```ocaml *)
                let actual =
                  if method_ref.binder_value.id = f.def_id then ptr.generics
                  else
                    let method_decl = FunDeclId.Map.find method_ref.binder_value.id
                      crate.fun_decls in
                    match List.rev f.item_meta.name with
                    | PeInstantiated shape :: name
                      when List.rev name = method_decl.item_meta.name ->
                        Substitute.apply_args_to_binder ptr.generics
                          Substitute.generic_args_substitute shape
                    | _ -> ptr.generics
                in
                (* ``` *)
                let generics =
                  {
                    regions =
                      select
                        (function
                          | RVar (Bound (0, id)) -> Some id
                          | _ -> None)
                        (List.map
                           (fun (p : region_param) -> p.index)
                           params.regions)
                        template.regions actual.regions;
                    types =
                      select
                        (function
                          | TVar (Bound (0, id)) -> Some id
                          | _ -> None)
                        (List.map
                           (fun (p : type_param) -> p.index)
                           params.types)
                        template.types actual.types;
                    const_generics =
                      select
                        (fun (c : constant_expr) ->
                          match c.kind with
                          | CVar (Bound (0, id)) -> Some id
                          | _ -> None)
                        (List.map
                           (fun (p : const_generic_param) -> p.index)
                           params.const_generics)
                        template.const_generics actual.const_generics;
                    trait_refs =
                      select
                        (fun (tr : trait_ref) ->
                          match tr.kind with
                          | Clause (Bound (0, id)) -> Some id
                          | _ -> None)
                        (List.map
                           (fun (p : trait_param) -> p.clause_id)
                           params.trait_clauses)
                        template.trait_refs actual.trait_refs;
                  }
                in
                let method_decl =
                  List.find
                    (fun (m : trait_method binder) ->
                      m.binder_value.name = name)
                    decl.methods
                in
                Option.iter
                  (fun owner ->
                    new_method_uses :=
                      FunDeclId.Map.update owner
                        (fun uses ->
                          Some
                            (FunDeclId.Set.add method_decl.binder_value.item.id
                               (Option.value uses ~default:FunDeclId.Set.empty)))
                        !new_method_uses)
                  env;
                if through_dictionary then
                  {
                    kind =
                      TraitMethod
                        (trait_ref, name, method_decl.binder_value.item.id);
                    generics;
                  }
                else
                  let fn_ref =
                    [%unwrap_with_span] span
                      (Substitute.lookup_and_subst_trait_decl_method decl name
                         trait_ref generics)
                      "Missing modeled inherited method"
                  in
                  {
                    kind = FunId (FRegular fn_ref.id);
                    generics = fn_ref.generics;
                  }
            | _ -> ptr
        end
      in
      let crate =
        if FunDeclId.Map.is_empty defaults then crate
        else visitor#visit_crate None crate
      in
      let trait_impls =
        if no_inherited_copies then crate.trait_impls
        else
          TraitImplId.Map.map
            (fun (impl : trait_impl) ->
              let methods =
                List.filter
                  (fun (_, (m : fun_decl_ref binder)) ->
                    not (inherited_copy m.binder_value.id))
                  impl.methods
              in
              { impl with methods })
            crate.trait_impls
      in
      let declarations =
        if no_inherited_copies then crate.declarations
        else
          let filter =
            object
              inherit [_] filter_decl_id

              method! visit_fun_decl_id () id =
                if inherited_copy id then None else Some id
            end
          in
          filter#visit_declaration_groups () crate.declarations
      in
      let crate = { crate with trait_impls; declarations } in
      (* Both inherited calls rewritten above and native recursive methods can
         depend on dictionaries. Reorder whole existing recursive groups; never
         assume the implementation was textually earlier than its callers. *)
      let group_ids = function
        | TypeGroup g ->
            List.map (fun id -> IdType id) (g_declaration_group_to_list g)
        | FunGroup g ->
            List.map (fun id -> IdFun id) (g_declaration_group_to_list g)
        | GlobalGroup g ->
            List.map (fun id -> IdGlobal id) (g_declaration_group_to_list g)
        | TraitDeclGroup g ->
            List.map (fun id -> IdTraitDecl id) (g_declaration_group_to_list g)
        | TraitImplGroup g ->
            List.map (fun id -> IdTraitImpl id) (g_declaration_group_to_list g)
        | MixedGroup g -> g_declaration_group_to_list g
      in
      (* Charon can retain an implementation in its maps but omit its
         declaration when every use was a concrete method call. Introducing a
         dictionary makes that implementation, and its dictionary dependencies,
         real declarations again. Restore them before computing order. *)
      let present =
        List.fold_left
          (fun present group ->
            List.fold_left
              (fun present id -> AnyDeclIdMap.add id () present)
              present (group_ids group))
          AnyDeclIdMap.empty declarations
      in
      let dependency_graph = ref AnyDeclIdMap.empty in
      let add_dependency owner dependency =
        match owner with
        | IdTraitDecl id when TraitDeclId.Map.mem id modeled_traits ->
            (* Imported dictionaries do not depend on Rust method bodies. *)
            ()
        | _ when owner = dependency -> ()
        | _ ->
            dependency_graph :=
              AnyDeclIdMap.update owner
                (fun deps ->
                  Some
                    (AnyDeclIdSet.add dependency
                       (Option.value deps ~default:AnyDeclIdSet.empty)))
                !dependency_graph
      in
      let uses = Deps.compute_graph_of_uses crate in
      AnyDeclIdMap.iter
        (fun dependency users ->
          Deps.ItemInfoSet.iter
            (fun (user : Deps.item_info) ->
              match (user.id, dependency) with
              | IdTraitDecl _, IdFun _ -> ()
              | IdFun fid, IdTraitImpl iid
                when (match (FunDeclId.Map.find fid crate.fun_decls).src with
                     | TraitImplItem (parent, _, _, _) -> parent.id = iid
                     | _ -> false)
                     && not
                          (TraitImplId.Set.mem iid
                             (Option.value
                                (FunDeclId.Map.find_opt fid !new_dictionary_uses)
                                ~default:TraitImplId.Set.empty)) ->
                  (* A concrete method's parent is metadata unless its body
                     actually uses the parent's dictionary. *)
                  ()
              | IdFun fid, IdGlobal gid
                when (FunDeclId.Map.find fid crate.fun_decls)
                       .is_global_initializer = Some gid -> ()
              | _ -> add_dependency user.id dependency)
            users)
        uses.graph;
      (* Trait declarations require method signatures, not method bodies. *)
      let signature_visitor =
        object
          inherit [_] iter_crate
          method! visit_type_decl_id owner id = add_dependency owner (IdType id)
          method! visit_fun_decl_id owner id = add_dependency owner (IdFun id)

          method! visit_global_decl_id owner id =
            add_dependency owner (IdGlobal id)

          method! visit_trait_decl_id owner id =
            add_dependency owner (IdTraitDecl id)

          method! visit_trait_impl_id owner id =
            add_dependency owner (IdTraitImpl id)
        end
      in
      TraitDeclId.Map.iter
        (fun id (decl : trait_decl) ->
          List.iter
            (fun (m : trait_method binder) ->
              let f =
                FunDeclId.Map.find m.binder_value.item.id crate.fun_decls
              in
              signature_visitor#visit_generic_params (IdTraitDecl id) f.generics;
              signature_visitor#visit_fun_sig (IdTraitDecl id) f.signature)
            decl.methods)
        crate.trait_decls;
      let required = ref AnyDeclIdSet.empty in
      let pending = ref [] in
      let require id =
        (* Existing groups already have Charon's dependency closure. Restore
           only newly needed definitions retained in the maps, not metadata
           references to definitions removed by earlier passes. *)
        if
          (not (AnyDeclIdMap.mem id present))
          && (not (AnyDeclIdSet.mem id !required))
          &&
          match id with
          | IdType id -> TypeDeclId.Map.mem id crate.type_decls
          | IdFun id -> FunDeclId.Map.mem id crate.fun_decls
          | IdGlobal id -> GlobalDeclId.Map.mem id crate.global_decls
          | IdTraitDecl id -> TraitDeclId.Map.mem id crate.trait_decls
          | IdTraitImpl id -> TraitImplId.Map.mem id crate.trait_impls
        then (
          required := AnyDeclIdSet.add id !required;
          pending := id :: !pending)
      in
      FunDeclId.Map.iter
        (fun owner ids ->
          if AnyDeclIdMap.mem (IdFun owner) present then
            TraitImplId.Set.iter (fun id -> require (IdTraitImpl id)) ids)
        !new_dictionary_uses;
      FunDeclId.Map.iter
        (fun owner ids ->
          if AnyDeclIdMap.mem (IdFun owner) present then
            FunDeclId.Set.iter (fun id -> require (IdFun id)) ids)
        !new_method_uses;
      while !pending <> [] do
        let id = List.hd !pending in
        pending := List.tl !pending;
        AnyDeclIdSet.iter require
          (Option.value
             (AnyDeclIdMap.find_opt id !dependency_graph)
             ~default:AnyDeclIdSet.empty)
      done;
      let additional =
        AnyDeclIdSet.elements !required
        |> List.map (function
             | IdType id -> TypeGroup (NonRecGroup id)
             | IdFun id -> FunGroup (NonRecGroup id)
             | IdGlobal id -> GlobalGroup (NonRecGroup id)
             | IdTraitDecl id -> TraitDeclGroup (NonRecGroup id)
             | IdTraitImpl id -> TraitImplGroup (NonRecGroup id))
      in
      let declarations = declarations @ additional in
      let crate = { crate with declarations } in
      let groups = Array.of_list declarations in
      let owners =
        Array.fold_left
          (fun (index, owners) group ->
            ( index + 1,
              List.fold_left
                (fun owners id -> AnyDeclIdMap.add id index owners)
                owners (group_ids group) ))
          (0, AnyDeclIdMap.empty) groups
        |> snd
      in
      let module DepScc = SCC.Make (Collections.OrderedInt) in
      let module IntSet = DepScc.S in
      let dependencies = Array.make (Array.length groups) IntSet.empty in
      AnyDeclIdMap.iter
        (fun owner deps ->
          match AnyDeclIdMap.find_opt owner owners with
          | None -> ()
          | Some owner ->
              AnyDeclIdSet.iter
                (fun dependency ->
                  match AnyDeclIdMap.find_opt dependency owners with
                  | Some dependency when owner <> dependency ->
                      dependencies.(owner) <-
                        IntSet.add dependency dependencies.(owner)
                  | _ -> ())
                deps)
        !dependency_graph;
      (* Condense genuine cycles instead of rejecting every back-edge. Preserve
         existing recursive groups and let the backend handle each kind of SCC;
         in particular, mixed dictionary/function recursion must not be silently
         linearized as if it were a sequence of non-recursive declarations. *)
      let sccs =
        DepScc.compute
          (Array.to_list (Array.mapi (fun i deps -> (i, deps)) dependencies))
      in
      let merge_groups indices =
        match indices with
        | [ index ] -> groups.(index)
        | _ -> (
            let ids =
              List.concat_map (fun index -> group_ids groups.(index)) indices
            in
            let types, funs, globals, traits, impls =
              List.fold_left
                (fun (ts, fs, gs, tds, tis) -> function
                  | IdType id -> (id :: ts, fs, gs, tds, tis)
                  | IdFun id -> (ts, id :: fs, gs, tds, tis)
                  | IdGlobal id -> (ts, fs, id :: gs, tds, tis)
                  | IdTraitDecl id -> (ts, fs, gs, id :: tds, tis)
                  | IdTraitImpl id -> (ts, fs, gs, tds, id :: tis))
                ([], [], [], [], []) ids
            in
            match (types, funs, globals, traits, impls) with
            | ids, [], [], [], [] -> TypeGroup (RecGroup (List.rev ids))
            | [], ids, [], [], [] -> FunGroup (RecGroup (List.rev ids))
            | [], [], ids, [], [] -> GlobalGroup (RecGroup (List.rev ids))
            | [], [], [], ids, [] -> TraitDeclGroup (RecGroup (List.rev ids))
            | [], [], [], [], ids -> TraitImplGroup (RecGroup (List.rev ids))
            | _ -> MixedGroup (RecGroup ids))
      in
      let declarations =
        List.map
          (fun (_, indices) -> merge_groups indices)
          (SCC.SccId.Map.bindings sccs.sccs)
      in
      { crate with declarations }

(*
```ocaml
*)
let compute_type_infos (crate : crate) : TypesAnalysis.type_infos =
  let crate = filter_type_aliases crate in
  let groups, _, _, _, _, _ = split_declarations crate.declarations in
  let infos =
    List.fold_left
      (TypesAnalysis.analyze_type_declaration_group None crate)
      TypeDeclId.Map.empty groups
  in
  (* Body erasure also visits types retained outside the emission groups. *)
  let module TypeScc = SCC.Make (Collections.OrderedInt) in
  let dependencies =
    TypeDeclId.Map.bindings crate.type_decls
    |> List.filter_map (fun (id, (decl : type_decl)) ->
         if TypeDeclId.Map.mem id infos then None
         else
           let deps = ref TypeScc.S.empty in
           let visitor =
             object
               inherit [_] iter_ty
               method! visit_type_decl_id _ dependency =
                 if not (TypeDeclId.Map.mem dependency infos) then
                   deps := TypeScc.S.add (TypeDeclId.to_int dependency) !deps
             end
           in
           (match decl.kind with
           | Opaque | TDeclError _ -> ()
           | _ ->
               TypesAnalysis.fold_type_decl_field_types decl
                 (fun () ty -> visitor#visit_ty () ty) ());
           Some (TypeDeclId.to_int id, !deps))
  in
  let sccs = TypeScc.compute dependencies in
  SCC.SccId.Map.bindings sccs.sccs
  |> List.fold_left
       (fun infos (_, ids) ->
         let group =
           match ids with
           | [ id ] when not (TypeScc.S.mem id (List.assoc id dependencies)) ->
               NonRecGroup (TypeDeclId.of_int id)
           | ids -> RecGroup (List.map TypeDeclId.of_int ids)
         in
         TypesAnalysis.analyze_type_declaration_group None crate infos group)
       infos
 (*
```
 *)

(** Fold only ABI-compatible modeled specializations. Whole-state contracts can
    reconstruct captured mutable state, but a generic borrowed-output record
    cannot express additional backward continuations. In that case retain the
    specialized trait, method signatures, and dictionary references together.
    Normalize modeled implementation references too: their specialized records
    contain only Charon's demanded methods, not the model's native overrides and
    marker evidence. Instantiating the original implementation preserves both.
    Structured methods may also reuse the original body when its actual owned
    state outputs form the complete canonical ABI, without native mutable
    backward results. This preserves delayed restoration across conversions
    instead of translating an artificial independent-lifetime body. *)
let normalize_modeled_trait_specializations (crate : crate) : crate =
  if Config.backend () <> Config.Lean then crate
  else
    let type_infos = compute_type_infos crate in
    let mctx = NameMatcher.ctx_from_crate crate in
    let modeled name = ExtractBuiltin.find_trait_decl_info mctx name in
    let specialization (name : name) =
      match List.rev name with
      | PeInstantiated shape :: rest -> Some (List.rev rest, shape)
      | _ -> None
    in
    let schema_targets =
      TraitDeclId.Map.values crate.trait_decls
      |> List.filter_map (fun (decl : trait_decl) ->
           match specialization decl.item_meta.name with
           | Some (_, shape) ->
               Option.map
                 (fun info -> (decl, shape, info))
                 (modeled decl.item_meta.name)
           | None -> None)
    in
    let schema_target (decl : trait_decl) (shape : generic_args binder) =
      let bind find add map key value =
        match find key !map with
        | Some previous -> previous = value
        | None ->
            map := add key value !map;
            true
      in
      List.find_map
        (fun ((target : trait_decl), (schema : generic_args binder), info) ->
          if target.def_id = decl.def_id then None
          else
            let regions = ref RegionId.Map.empty in
            let types = ref TypeVarId.Map.empty in
            let region left right =
              match left with
              | RVar (Bound (0, id)) ->
                  bind RegionId.Map.find_opt RegionId.Map.add regions id right
              | _ -> left = right
            in
            let pairs f left right =
              List.length left = List.length right
              && List.for_all2 f left right
            in
            let rec ty left right =
              match (left, right) with
              | TVar (Bound (0, id)), _ ->
                  bind TypeVarId.Map.find_opt TypeVarId.Map.add types id right
              | TRef (r0, t0, k0), TRef (r1, t1, k1) ->
                  k0 = k1 && region r0 r1 && ty t0 t1
              | TAdt a0, TAdt a1 ->
                  a0.id = a1.id && args a0.generics a1.generics
              | TArray (t0, n0), TArray (t1, n1) ->
                  n0 = n1 && ty t0 t1
              | TSlice t0, TSlice t1 -> ty t0 t1
              | TRawPtr (t0, k0), TRawPtr (t1, k1) ->
                  k0 = k1 && ty t0 t1
              | _ -> left = right
            and args left right =
              left.const_generics = right.const_generics
              && left.trait_refs = right.trait_refs
              && pairs region left.regions right.regions
              && pairs ty left.types right.types
            in
            if
              fst (Option.get (specialization target.item_meta.name))
              <> fst (Option.get (specialization decl.item_meta.name))
              || not (args schema.binder_value shape.binder_value)
              || schema.binder_params.const_generics <> []
              || schema.binder_params.trait_clauses <> []
            then None
            else
              try
                let generics =
                  { TypesUtils.empty_generic_args with
                    regions = List.map
                      (fun (p : region_param) -> RegionId.Map.find p.index !regions)
                      schema.binder_params.regions;
                    types = List.map
                      (fun (p : type_param) -> TypeVarId.Map.find p.index !types)
                      schema.binder_params.types }
                in
                let shape = { shape with binder_value = generics } in
                if ModelStateABI.trait_specialization_is_compatible type_infos info shape
                then Some (target.def_id, shape)
                else None
              with Not_found -> None)
        schema_targets
    in
    let traits =
      TraitDeclId.Map.filter_map
        (fun _ (decl : trait_decl) ->
          match specialization decl.item_meta.name with
          | Some (name, shape) -> (
              match modeled name with
              | Some info
                when ModelStateABI.trait_specialization_is_compatible type_infos info shape
                ->
                  let original =
                    List.find
                      (fun (d : trait_decl) -> d.item_meta.name = name)
                      (TraitDeclId.Map.values crate.trait_decls)
                  in
                  Some (original.def_id, shape)
              | _ -> schema_target decl shape)
          | _ -> None)
        crate.trait_decls
    in
    (* A canonical subtrait cannot contain a specialized parent dictionary.
       Remove such candidates to a fixed point, including transitive parents. *)
    let rec retain_specialized_parents traits =
      let compatible =
        TraitDeclId.Map.filter
          (fun id _ ->
            let decl = TraitDeclId.Map.find id crate.trait_decls in
            let compatible = ref true in
            let visitor =
              object
                inherit [_] iter_crate

                method! visit_trait_decl_id _ parent_id =
                  let parent =
                    TraitDeclId.Map.find parent_id crate.trait_decls
                  in
                  if
                    ExtractBuiltin.is_trait_specialization parent.item_meta.name
                    && not (TraitDeclId.Map.mem parent_id traits)
                  then compatible := false
              end
            in
            List.iter (visitor#visit_trait_param ()) decl.implied_clauses;
            !compatible)
          traits
      in
      if TraitDeclId.Map.cardinal compatible = TraitDeclId.Map.cardinal traits
      then compatible
      else retain_specialized_parents compatible
    in
    let traits = retain_specialized_parents traits in
    let schema_fold id =
      match TraitDeclId.Map.find_opt id traits with
      | Some (target, _) ->
          ExtractBuiltin.is_trait_specialization
            (TraitDeclId.Map.find target crate.trait_decls).item_meta.name
      | None -> false
    in
    let compatible_trait id =
      let decl = TraitDeclId.Map.find id crate.trait_decls in
      match specialization decl.item_meta.name with
      | Some _ -> TraitDeclId.Map.mem id traits
      | None -> Option.is_some (modeled decl.item_meta.name)
    in
    (* Whether the model adapts the region-indexed ABI of the implementations of
       a method of a (possibly specialized) modeled trait to its canonical state
       ABI (see {!ModelStateABI.trait_contract}) *)
    let method_has_contract id method_name =
      let decl = TraitDeclId.Map.find id crate.trait_decls in
      let name =
        match specialization decl.item_meta.name with
        | Some (name, _) -> name
        | None -> decl.item_meta.name
      in
      match modeled name with
      | Some (info : Pure.builtin_trait_decl_info) ->
          Option.is_some
            (ModelStateABI.trait_contract info.extract_name method_name)
      | None -> false
    in
    let methods =
      FunDeclId.Map.filter_map
        (fun _ (decl : fun_decl) ->
          match (decl.src, specialization decl.item_meta.name) with
          | ( ( TraitDeclItem (trait_ref, _, _)
              | TraitImplItem (_, trait_ref, _, _) ),
              Some (name, shape) )
            when compatible_trait trait_ref.id && not (schema_fold trait_ref.id) -> (
              match
                List.find_opt
                  (fun (f : fun_decl) -> f.item_meta.name = name)
                  (FunDeclId.Map.values crate.fun_decls)
              with
              | Some original ->
                  let compatible =
                    match (decl.body, decl.src) with
                    | OpaqueBody, TraitDeclItem (trait_ref, method_name, _) ->
                        (* The signature of a trait method is the type of a
                           field of the trait's record, in which the
                           implementations of the traits which are not folded
                           store their methods as they are: e.g., the method
                           [cloned] of [Iterator::<IterMut<'0, T0>, T1>] is
                           that of [Iterator::<IterMut<'0, T0>, &'0 mut T1>].
                           Folding the method must keep its backward
                           functions, unless the model adapts them. *)
                        method_has_contract trait_ref.id method_name
                        || ModelStateABI.shape_is_abi_neutral decl shape
                        || reference_identity_or_provided crate original
                    | OpaqueBody, TraitImplItem (_, trait_ref, method_name, _) ->
                        method_has_contract trait_ref.id method_name
                        || ModelStateABI.shape_is_abi_neutral decl shape
                        || reference_identity_or_provided crate original
                    | StructuredBody _, _ ->
                        Option.is_some
                          (ModelStateInputs.canonical_body_state_inputs crate
                             original)
                    | _ -> false
                  in
                  if compatible then Some (original.def_id, shape) else None
              | None -> None)
          | _ -> None)
        crate.fun_decls
    in
    let original_impls = TraitImplId.Map.values crate.trait_impls in
    let impls =
      TraitImplId.Map.filter_map
        (fun _ (impl : trait_impl) ->
          match specialization impl.item_meta.name with
          | Some (name, shape)
            when compatible_trait impl.impl_trait.id
                 && not (schema_fold impl.impl_trait.id)
                 && List.for_all
                      (fun (_, (method_ref : fun_decl_ref binder)) ->
                        let id = method_ref.binder_value.id in
                        let decl = FunDeclId.Map.find id crate.fun_decls in
                        match
                          (decl.body, specialization decl.item_meta.name)
                        with
                        | (StructuredBody _ | OpaqueBody), Some _ ->
                            FunDeclId.Map.mem id methods
                        | _ -> true)
                      impl.methods -> (
              match
                List.find_opt
                  (fun (original : trait_impl) ->
                    original.item_meta.name = name)
                  original_impls
              with
              | None -> None
              | Some original -> Some (original.def_id, shape))
          | _ -> None)
        crate.trait_impls
    in
    (* A retained dictionary keeps its Rust method owners.
       Partial method folding breaks inherited-default provenance. *)
    (* ```ocaml *)
    let methods =
      FunDeclId.Map.filter
        (fun id _ ->
          match (FunDeclId.Map.find id crate.fun_decls).src with
          | TraitImplItem (owner, _, _, _) -> TraitImplId.Map.mem owner.id impls
          | _ -> true)
        methods
    in
    (* ``` *)
    if
      TraitDeclId.Map.is_empty traits
      && FunDeclId.Map.is_empty methods
      && TraitImplId.Map.is_empty impls
    then crate
    else
      let instantiate args shape =
        Substitute.apply_args_to_binder args Substitute.generic_args_substitute
          shape
      in
      let visitor =
        object (self)
          inherit [_] map_crate as super

          method! visit_item_meta env meta =
            let meta = super#visit_item_meta env meta in
            (* Names are opaque to the generated visitor, but specialization
               binders remain live substitutions after dictionary folding. *)
            let name =
              List.map
                (function
                  | PeInstantiated shape ->
                      PeInstantiated
                        (self#visit_binder self#visit_generic_args env shape)
                  | elem -> elem)
                meta.name
            in
            { meta with name }

          method! visit_trait_decl_ref env tr =
            match TraitDeclId.Map.find_opt tr.id traits with
            | None -> super#visit_trait_decl_ref env tr
            | Some (id, shape) ->
                self#visit_trait_decl_ref env
                  { id; generics = instantiate tr.generics shape }

          method! visit_trait_impl_ref env impl =
            match TraitImplId.Map.find_opt impl.id impls with
            | None -> super#visit_trait_impl_ref env impl
            | Some (id, shape) ->
                self#visit_trait_impl_ref env
                  { id; generics = instantiate impl.generics shape }

          method! visit_fun_decl_ref env f =
            match FunDeclId.Map.find_opt f.id methods with
            | None -> super#visit_fun_decl_ref env f
            | Some (id, shape) ->
                self#visit_fun_decl_ref env
                  { id; generics = instantiate f.generics shape }

          method! visit_fn_ptr env ptr =
            match ptr.kind with
            | FunId (FRegular fid) when FunDeclId.Map.mem fid methods ->
                let id, shape = FunDeclId.Map.find fid methods in
                super#visit_fn_ptr env
                  {
                    kind = FunId (FRegular id);
                    generics = instantiate ptr.generics shape;
                  }
            | TraitMethod (tr, name, fid) ->
                let fid =
                  match FunDeclId.Map.find_opt fid methods with
                  | Some (id, _) -> id
                  | None -> fid
                in
                super#visit_fn_ptr env
                  { ptr with kind = TraitMethod (tr, name, fid) }
            | _ -> super#visit_fn_ptr env ptr
        end
      in
      let seen_traits = ref TraitDeclId.Set.empty in
      let seen_impls = ref TraitImplId.Set.empty in
      let seen_methods = ref FunDeclId.Set.empty in
      let groups =
        object
          inherit [_] filter_decl_id

          method! visit_trait_decl_id _ id =
            let id =
              match TraitDeclId.Map.find_opt id traits with
              | Some (id, _) -> id
              | None -> id
            in
            if TraitDeclId.Set.mem id !seen_traits then None
            else (
              seen_traits := TraitDeclId.Set.add id !seen_traits;
              Some id)

          method! visit_trait_impl_id _ id =
            let id =
              match TraitImplId.Map.find_opt id impls with
              | Some (id, _) -> id
              | None -> id
            in
            if TraitImplId.Set.mem id !seen_impls then None
            else (
              seen_impls := TraitImplId.Set.add id !seen_impls;
              Some id)

          method! visit_fun_decl_id _ id =
            let id =
              match FunDeclId.Map.find_opt id methods with
              | Some (id, _) -> id
              | None -> id
            in
            if FunDeclId.Set.mem id !seen_methods then None
            else (
              seen_methods := FunDeclId.Set.add id !seen_methods;
              Some id)
        end
      in
      let crate =
        {
          crate with
          trait_decls =
            TraitDeclId.Map.filter
              (fun id _ -> not (TraitDeclId.Map.mem id traits))
              crate.trait_decls;
          trait_impls =
            TraitImplId.Map.filter
              (fun id _ -> not (TraitImplId.Map.mem id impls))
              crate.trait_impls;
          fun_decls =
            FunDeclId.Map.filter
              (fun id _ -> not (FunDeclId.Map.mem id methods))
              crate.fun_decls;
          declarations = groups#visit_declaration_groups () crate.declarations;
        }
      in
      visitor#visit_crate () crate

(** Admit the partial-monomorphization instances of modeled functions whose ABI
    is that of their generic model (see
    [ModelStateABI.fun_instance_is_compatible]). The logical name matcher
    ignores [PeInstantiated]; every other instance keeps its Rust body or stays
    an unknown external. *)
let admit_modeled_fun_instances (crate : crate) : unit =
  ExtractBuiltin.admitted_fun_instances :=
    if Config.backend () <> Config.Lean then FunDeclId.Set.empty
    else
      let mctx = NameMatcher.ctx_from_crate crate in
      FunDeclId.Map.fold
        (fun id (decl : fun_decl) admitted ->
          match List.rev decl.item_meta.name with
          | PeInstantiated shape :: _ -> (
              match
                ExtractBuiltin.find_generic_fun_info mctx decl.item_meta.name
              with
              | Some info
                when ModelStateABI.fun_instance_is_compatible crate decl info
                       shape -> FunDeclId.Set.add id admitted
              | _ -> admitted)
          | _ -> admitted)
        crate.fun_decls FunDeclId.Set.empty

(** Reorder the region parameters of the functions of [orders] (for every
    function, the positions of its region parameters in their new order), and
    the region arguments of every reference to them. *)
let reorder_fun_region_params (crate : crate) (orders : int list FunDeclId.Map.t)
    : crate =
  if FunDeclId.Map.is_empty orders then crate
  else
    let reorder (order : int list) l = List.map (List.nth l) order in
    let reorder_args (fid : FunDeclId.id) (generics : generic_args) =
      match FunDeclId.Map.find_opt fid orders with
      | None -> generics
      | Some order -> { generics with regions = reorder order generics.regions }
    in
    (* Reorder the region parameters of a function, and rename accordingly its
       free region variables, which are those parameters. Its name keeps its own
       specialization binder. *)
    let reorder_params (f : fun_decl) (order : int list) : fun_decl =
      let params = reorder order f.generics.regions in
      let renaming =
        RegionId.Map.of_list
          (List.mapi
             (fun i (r : region_param) -> (r.index, RegionId.of_int i))
             params)
      in
      let rename =
        object
          inherit [_] map_crate as super

          method! visit_region env r =
            match r with
            | RVar (Free id) -> RVar (Free (RegionId.Map.find id renaming))
            | _ -> super#visit_region env r
        end
      in
      let f = rename#visit_fun_decl () f in
      let regions =
        List.mapi
          (fun i (r : region_param) -> { r with index = RegionId.of_int i })
          params
      in
      { f with generics = { f.generics with regions } }
    in
    let fun_decls =
      FunDeclId.Map.map
        (fun (f : fun_decl) ->
          match FunDeclId.Map.find_opt f.def_id orders with
          | None -> f
          | Some order ->
              let f = reorder_params f order in
              [%ltrace
                let env = Print.crate_to_fmt_env crate in
                "Reordered the region parameters of: "
                ^ Print.fun_decl_to_string env "" " " f];
              f)
        crate.fun_decls
    in
    let visitor =
      object
        inherit [_] map_crate as super

        method! visit_fun_decl_ref env fref =
          let fref = super#visit_fun_decl_ref env fref in
          { fref with generics = reorder_args fref.id fref.generics }

        method! visit_fn_ptr env ptr =
          let ptr = super#visit_fn_ptr env ptr in
          match ptr.kind with
          | FunId (FRegular fid) ->
              { ptr with generics = reorder_args fid ptr.generics }
          | FunId (FBuiltin _) | TraitMethod _ -> ptr
      end
    in
    visitor#visit_crate () { crate with fun_decls }

(** Lay out the region parameters of every method as those of its trait (or
    implementation) followed by its own.

    This is how Charon lays out the parameters of methods, except for the
    methods specialized by its partial monomorphization ([--monomorphize-mut]):
    the regions extracted from the specialized arguments are appended after the
    regions of the original method, including the method's own (late-bound)
    regions. For instance, for [impl Fn(&mut u32, &u32) -> u32]:
    {[
      trait FnMut::<_, (&_ mut _, _), _><'_0, T0, T1, T2, T3> {
        fn call_mut<'_0_1> = FnMut::call_mut::<..><'_0_1, '_0, T0, T1, T2, T3>
      }
      fn FnMut::call_mut::<..><'_0, '_1, T0, T1, T2, T3>
        (_1: &'_0 mut T0, _2: (&'_1 mut T1, T2)) -> T3
    ]}
    while the implementation for a closure is laid out as usual:
    {[
      fn {impl FnMut::<..> for closure}::call_mut<'_0, '_1, '_2>
        (state_1: &'_2 mut closure, args_2: (&'_0 mut u32, &'_1 u32)) -> u32
    ]}
    The order of the region parameters of a function determines the order of its
    region groups, and thus of the values its backward functions give back: the
    method field of the trait and the implementations of the method must agree
    on it. *)
let order_method_region_params (crate : crate) : crate =
  (* The instantiation of a method by its trait or implementation, whose
     binder binds the method's own parameters *)
  let owner_ref (f : fun_decl) : fun_decl_ref option =
    match f.src with
    | TraitDeclItem (trait_ref, name, _) ->
        Option.bind (TraitDeclId.Map.find_opt trait_ref.id crate.trait_decls)
          (fun (decl : trait_decl) ->
            List.find_map
              (fun (m : trait_method binder) ->
                let m = m.binder_value in
                if m.name = name && m.item.id = f.def_id then Some m.item
                else None)
              decl.methods)
    | TraitImplItem (impl_ref, _, name, _) ->
        Option.bind (TraitImplId.Map.find_opt impl_ref.id crate.trait_impls)
          (fun (impl : trait_impl) ->
            List.find_map
              (fun ((n, m) : _ * fun_decl_ref binder) ->
                if n = name && m.binder_value.id = f.def_id then
                  Some m.binder_value
                else None)
              impl.methods)
    | TopLevelItem
    | ClosureItem _
    | VTableTyItem _
    | VTableInstanceItem _
    | VTableMethodShimItem
    | VTableInstanceMonoItem
    | VTableMethodPreShimItem _ -> None
  in
  (* For every method whose region parameters must be reordered: the positions
     of its region parameters, in their new order. The regions of the owner are
     free variables, the regions of the method are bound by the method binder. *)
  let orders : int list FunDeclId.Map.t =
    FunDeclId.Map.filter_map
      (fun _ (f : fun_decl) ->
        match owner_ref f with
        | None -> None
        | Some fref ->
            let regions = List.mapi (fun i r -> (i, r)) fref.generics.regions in
            let owner, own =
              List.partition
                (fun (_, r) ->
                  match r with
                  | RVar (Free _) -> true
                  | _ -> false)
                regions
            in
            let is_own (_, r) =
              match r with
              | RVar (Bound (0, _)) -> true
              | _ -> false
            in
            let order = List.map fst (owner @ own) in
            if
              List.for_all is_own own
              && List.length regions = List.length f.generics.regions
              && order <> List.map fst regions
            then Some order
            else None)
      crate.fun_decls
  in
  reorder_fun_region_params crate orders

(** Lay out the region parameters of every trait-impl method so that its region
    groups are those of its trait method, in the same order.

    The region groups of a signature are ordered by a depth-first search over
    the outlives graph of its region parameters, taken in their order (see
    {!RegionsHierarchy.compute_regions_hierarchy_for_sig}). The forward function
    returns the backward functions in the order of the region groups, and the
    record of the trait stores an implementation in the field of the trait
    method, so that the calls through the trait use the order of the trait
    method. An implementation may order the regions differently:
    - its regions may instantiate those of the trait in another order, e.g. in
      [impl<'a, 'b> Two<'b, 'a> for S];
    - its instantiation of the type variables of the trait may contain regions
      which outlive the regions of the method, and the search puts the region
      groups they outlive first. For instance, for a closure capturing a
      variable by shared reference:
      {[
        fn FnMut::call_mut::<..><'_0, '_1, T0, T1, T2>
          (_1: &'_1 mut T0, _2: (&'_0 mut T1,)) -> T2
        fn {impl FnMut::<..> for closure<'_0>}::call_mut<'_0, '_1, '_2>
          (state_1: &'_2 mut closure<'_0>, args_2: (&'_1 mut u32,)) -> u32
      ]}
      the trait method gives back the argument, then the state, while in the
      implementation ['_0 : '_2] puts the state first.
    When the given back values have the same type, the other order silently
    swaps them.

    For every implementation that the record of its trait implementation stores
    as it is (see {!ModelStateABI.record_stores_translated_method}) and whose
    regions, grouped and ordered as in its signature, differ from the regions
    which instantiate those of the trait method, grouped and ordered as in the
    trait method, we put first the regions which instantiate those of the trait
    method, in the order of the trait method's regions, then the other regions.
    Every other function is left unchanged. [SymbolicToPure] then checks that
    the backward functions of those implementations are those of their trait
    method (see {!RegionsHierarchy.check_trait_impl_method_region_groups}). *)
let order_impl_method_region_groups (crate : crate) : crate =
  (* The trait method of an implementation stored as it is in its record *)
  let trait_fun_decl (f : fun_decl) : fun_decl option =
    match f.src with
    | TraitImplItem (impl_ref, trait_ref, name, _) -> (
        match
          ( TraitImplId.Map.find_opt impl_ref.id crate.trait_impls,
            TraitDeclId.Map.find_opt trait_ref.id crate.trait_decls )
        with
        | Some impl, Some decl
          when ModelStateABI.record_stores_translated_method crate impl name
                 f.def_id ->
            Option.bind
              (List.find_opt
                 (fun (m : trait_method binder) -> m.binder_value.name = name)
                 decl.methods)
              (fun (m : trait_method binder) ->
                FunDeclId.Map.find_opt m.binder_value.item.id crate.fun_decls)
        | _ -> None)
    | _ -> None
  in
  let orders : int list FunDeclId.Map.t =
    FunDeclId.Map.filter_map
      (fun _ (f : fun_decl) ->
        match trait_fun_decl f with
        | None -> None
        | Some tf -> (
            (* A mismatch of the signatures is reported by the check in
               [SymbolicToPure] *)
            match
              RegionsHierarchy.trait_method_region_map tf.signature f.signature
            with
            | Error _ -> None
            | Ok region_map ->
                (* The regions of the implementation which instantiate those of
                   the trait method, in the order of the trait method *)
                let image (rid : RegionId.id) =
                  match RegionId.Map.find_opt rid region_map with
                  | Some (RVar (Free rid)) -> Some rid
                  | _ -> None
                in
                let images =
                  List.fold_left
                    (fun images (r : region_param) ->
                      match image r.index with
                      | Some rid when not (List.mem rid images) ->
                          images @ [ rid ]
                      | _ -> images)
                    [] tf.generics.regions
                in
                let groups (d : fun_decl) =
                  RegionsHierarchy.compute_regions_hierarchy_for_sig
                    (Some d.item_meta.span) crate
                    (LlbcAstUtils.bound_fun_sig_of_decl d)
                in
                let layout (d : fun_decl) to_impl =
                  List.filter_map
                    (fun (g : region_var_group) ->
                      match
                        List.sort_uniq RegionId.compare_id
                          (List.filter_map to_impl g.regions)
                      with
                      | [] -> None
                      | l -> Some l)
                    (groups d)
                in
                let in_images rid =
                  if List.mem rid images then Some rid else None
                in
                if layout tf image = layout f in_images then None
                else
                  let others =
                    List.filter
                      (fun (r : region_param) -> not (List.mem r.index images))
                      f.generics.regions
                  in
                  Some
                    (List.map RegionId.to_int images
                    @ List.map
                        (fun (r : region_param) -> RegionId.to_int r.index)
                        others)))
      crate.fun_decls
  in
  reorder_fun_region_params crate orders

(** Some provided methods cannot occur in the model record because their bounds
    depend on that record (Iterator.collect / FromIterator). The model must
    explicitly restrict them to inherited-default dictionaries. Check Rust
    provenance for every canonical implementation before lowering any generic
    projection; an absent method or an opaque body is not evidence.

    Charon's [reuses_default] is also true for implementations of required
    methods, so it proves inheritance only together with the declaration's
    [has_default]. Concrete calls keep their normal implementation dispatch. *)
let resolve_default_only_dispatch (crate : crate) : crate =
  if Config.backend () <> Config.Lean then crate
  else
    let mctx = NameMatcher.ctx_from_crate crate in
    let checked = ref [] in
    let check (decl : trait_decl) method_name =
      if not (List.mem (decl.def_id, method_name) !checked) then (
        let method_decl =
          match
            List.find_opt
              (fun (method_decl : trait_method binder) ->
                method_decl.binder_value.name = method_name)
              decl.methods
          with
          | Some method_decl ->
              FunDeclId.Map.find method_decl.binder_value.item.id
                crate.fun_decls
          | None ->
              [%craise] decl.item_meta.span
                ("Default-only method lacks a Rust declaration: " ^ method_name)
        in
        [%cassert] method_decl.item_meta.span
          (match method_decl.src with
          | TraitDeclItem (tr, name, true) ->
              tr.id = decl.def_id && name = method_name
          | _ -> false)
          ("Default-only dispatch requires a Rust provided method: "
         ^ method_name);
        [%cassert] method_decl.item_meta.span
          (ExtractBuiltin.mem_fun mctx method_decl.def_id
             method_decl.item_meta.name)
          ("Default-only method lacks a standalone model: " ^ method_name);
        TraitImplId.Map.iter
          (fun _ (impl : trait_impl) ->
            if impl.impl_trait.id = decl.def_id then
              let name () =
                Print.name_to_string
                  (Print.crate_to_fmt_env crate)
                  impl.item_meta.name
              in
              match List.assoc_opt method_name impl.methods with
              | None ->
                  [%craise] impl.item_meta.span
                    ("Default-only dispatch for " ^ method_name
                   ^ " lacks inherited-default evidence in " ^ name ())
              | Some method_ref -> (
                  let implementation =
                    FunDeclId.Map.find method_ref.binder_value.id
                      crate.fun_decls
                  in
                  match implementation.src with
                  | TraitImplItem (owner, tr, name, true)
                    when owner.id = impl.def_id && tr.id = decl.def_id
                         && name = method_name -> ()
                  | _ ->
                      [%craise] implementation.item_meta.span
                        (* ```ocaml *)
                        ("Default-only dispatch for " ^ method_name
                       ^ " conflicts with a native override or unproven method in " ^ name ()
                       ^ "\n- current impl: " ^ TraitImplId.to_string impl.def_id
                       ^ "\n- method ref: " ^ FunDeclId.to_string implementation.def_id
                       ^ "\n- Rust method provenance: "
                       ^ (match implementation.src with
                          | TraitImplItem (owner, tr, method_name, inherited) ->
                              "impl=" ^ TraitImplId.to_string owner.id
                              ^ ",trait=" ^ TraitDeclId.to_string tr.id
                              ^ ",method=" ^ method_name
                              ^ ",inherited=" ^ string_of_bool inherited
                          | _ -> "not a trait implementation"))))
                        (* ``` *)
          crate.trait_impls;
        checked := (decl.def_id, method_name) :: !checked)
    in
    let visitor =
      object
        inherit [_] map_crate as super

        method! visit_fn_ptr env ptr =
          let ptr = super#visit_fn_ptr env ptr in
          match ptr.kind with
          | TraitMethod ({ kind = TraitImpl _; _ }, _, _) -> ptr
          | TraitMethod (tr, method_name, _) -> (
              let decl =
                TraitDeclId.Map.find tr.trait_decl_ref.binder_value.id
                  crate.trait_decls
              in
              match
                ExtractBuiltin.find_trait_decl_info mctx decl.item_meta.name
              with
              | Some info when List.mem method_name info.default_only_methods ->
                  [%cassert] decl.item_meta.span
                    (not (List.mem_assoc method_name info.methods))
                    "A default-only method must not also be a dictionary field";
                  check decl method_name;
                  let method_ref =
                    [%unwrap_with_span] decl.item_meta.span
                      (Substitute.lookup_and_subst_trait_decl_method decl
                         method_name tr ptr.generics)
                      "Missing checked standalone default"
                  in
                  {
                    kind = FunId (FRegular method_ref.id);
                    generics = method_ref.generics;
                  }
              | _ -> ptr)
          | _ -> ptr
      end
    in
    visitor#visit_crate () crate

(** Read the length of a matched slice directly.

    The length check of a slice pattern on a place which is not a local (e.g.
    [match c { A(x, [y]) => ... }], or on a mutable slice) creates a raw pointer
    to the matched slice only to read its metadata:
    {[
      r := &raw const ( *p) with_metadata(m);
      n := copy r.metadata;
    ]}
    The metadata of this pointer is [m]. When the raw pointer has no other use,
    read [m] directly ([n := m]) and drop the raw pointer. The code of a match
    arm may be duplicated by the control-flow reconstruction: the raw pointer
    then has one such definition and read per copy, and no other use. *)
let read_raw_pointer_metadata (_crate : crate) (f : fun_decl) : fun_decl =
  match f.body with
  | StructuredBody body ->
      (* The metadata read which follows the definition of the raw pointer [r]
         (after storage markers of other locals): the markers, the read, its
         destination and the statements after it *)
      let metadata_read r (rest : statement list) =
        let rec split lives = function
          | ({ kind = StorageLive id; _ } as live) :: rest when id <> r ->
              split (live :: lives) rest
          | next :: rest -> Some (List.rev lives, next, rest)
          | [] -> None
        in
        match split [] rest with
        | Some
            ( lives,
              ({
                 kind =
                   Assign
                     ( dest,
                       Use
                         ( Copy
                             {
                               kind =
                                 PlaceProjection
                                   ({ kind = PlaceLocal r'; _ }, PtrMetadata);
                               _;
                             }
                         | Move
                             {
                               kind =
                                 PlaceProjection
                                   ({ kind = PlaceLocal r'; _ }, PtrMetadata);
                               _;
                             } ) );
                 _;
               } as next),
              rest' )
          when r = r' -> Some (lives, next, dest, rest')
        | _ -> None
      in
      let incr id map =
        LocalId.Map.add id
          (1 + Option.value (LocalId.Map.find_opt id map) ~default:0)
          map
      in
      let counts = ref LocalId.Map.empty in
      let pairs = ref LocalId.Map.empty in
      let occurrences =
        object
          inherit [_] iter_statement as super

          (* Occurrences in places (not in storage markers) *)
          method! visit_place env p =
            match p.kind with
            | PlaceLocal id -> counts := incr id !counts
            | _ -> super#visit_place env p

          (* Definitions immediately followed by their metadata read *)
          method! visit_block env b =
            let rec go = function
              | {
                  kind = Assign ({ kind = PlaceLocal r; _ }, RawPtr (_, _, _));
                  _;
                }
                :: rest ->
                  if Option.is_some (metadata_read r rest) then
                    pairs := incr r !pairs;
                  go rest
              | _ :: rest -> go rest
              | [] -> ()
            in
            go b.statements;
            super#visit_block env b
        end
      in
      occurrences#visit_block () body.body;
      (* Every occurrence is the definition or the metadata read of a pair *)
      let single_use id =
        match LocalId.Map.find_opt id !pairs with
        | Some n -> LocalId.Map.find_opt id !counts = Some (2 * n)
        | None -> false
      in
      let visitor =
        object
          inherit [_] map_statement as super

          method! visit_block env b =
            let b = super#visit_block env b in
            let rec go (sts : statement list) =
              match sts with
              | ({
                   kind = Assign ({ kind = PlaceLocal r; _ }, RawPtr (_, _, m));
                   _;
                 } as st)
                :: rest
                when single_use r -> (
                  match metadata_read r rest with
                  | Some (lives, next, dest, rest') ->
                      lives
                      @ {
                          next with
                          kind = Assign (dest, Use m);
                          comments_before =
                            st.comments_before @ next.comments_before;
                        }
                        :: go rest'
                  | None -> st :: go rest)
              | st :: rest -> st :: go rest
              | [] -> []
            in
            { b with statements = go b.statements }
        end
      in
      let b = visitor#visit_block () body.body in
      { f with body = StructuredBody { body with body = b } }
  | _ -> f

(** Read the length of a mutable slice before the reborrow which follows it.

    The rest [rest @ ..] of a slice pattern on a mutable slice reborrows the
    slice, then reads its length for the end of the subslice:
    {[
      r := &mut ( *p) with_metadata(..);
      n := len( *p);    // or: n := copy p.metadata
      rest := @SliceSubSliceMut(move r, from, n - k);
    ]}
    The length is the metadata of the reference [p], which the reborrow does
    not change; the interpreter, however, reads it from the slice, which is
    then lent to [r]: the read would end [r]. Read the length before the
    reborrow (with the storage markers in between, which may be [n]'s). *)
let read_lengths_before_reborrows (_crate : crate) (f : fun_decl) : fun_decl =
  match f.body with
  | StructuredBody body ->
      let reborrow (st : statement) =
        match st.kind with
        | Assign
            ( { kind = PlaceLocal r; _ },
              RvRef
                ( {
                    kind = PlaceProjection ({ kind = PlaceLocal p; _ }, Deref);
                    _;
                  },
                  (BMut | BTwoPhaseMut),
                  _ ) ) -> Some (r, p)
        | _ -> None
      in
      let length_read p (st : statement) =
        match st.kind with
        | Assign
            ( { kind = PlaceLocal n; _ },
              ( Len
                  ( {
                      kind =
                        PlaceProjection ({ kind = PlaceLocal p'; _ }, Deref);
                      _;
                    },
                    _,
                    None )
              | Use
                  (Copy
                     {
                       kind =
                         PlaceProjection ({ kind = PlaceLocal p'; _ }, PtrMetadata);
                       _;
                     }) ) )
          when p' = p -> Some n
        | _ -> None
      in
      let visitor =
        object
          inherit [_] map_statement as super

          method! visit_block env b =
            let b = super#visit_block env b in
            let rec go (sts : statement list) =
              match sts with
              | st :: rest -> (
                  match reborrow st with
                  | None -> st :: go rest
                  | Some (r, p) -> (
                      let rec split lives = function
                        | ({ kind = StorageLive id; _ } as live) :: rest
                          when id <> r && id <> p -> split (live :: lives) rest
                        | next :: rest -> Some (List.rev lives, next, rest)
                        | [] -> None
                      in
                      match split [] rest with
                      | Some (lives, next, rest') -> (
                          match length_read p next with
                          | Some n when n <> r && n <> p ->
                              lives @ (next :: go (st :: rest'))
                          | _ -> st :: go rest)
                      | None -> st :: go rest))
              | [] -> []
            in
            { b with statements = go b.statements }
        end
      in
      let b = visitor#visit_block () body.body in
      { f with body = StructuredBody { body with body = b } }
  | _ -> f

(** Move array elements out through shared indexings.

    Rust moves an element out of an owned array only by a constant index (array
    patterns: [let [a, b] = arr]). Charon lowers the move to
    [b = &mut arr; r = @ArrayIndexMut(move b, k); x = move ( *r).path]: a move
    behind a mutable borrow, which the interpreter cannot evaluate (ending the
    borrow would give back an array holding a moved element). The borrow
    checker forbids any later read of the moved element: the array is only
    accessed at its other constant indices, dropped or reassigned as a whole.
    So the move may leave the element in the array: it reads the element
    through a shared indexing [b = &arr; r = @ArrayIndexShared(move b, k)],
    which [share_repeated_shared_indexing] then identifies with the shared
    indexings of the same element that tested its variants (refutable
    patterns), and the interpreter evaluates [move ( *r).path] as a read of a
    value without borrows (see
    [InterpExpressions.place_moves_through_shared_borrow]).

    Applies to adjacent statements when [b] and [r] have no other use. *)
let shared_indexing_for_array_moves (_crate : crate) (f : fun_decl) : fun_decl =
  match f.body with
  | StructuredBody body ->
      let counts = ref LocalId.Map.empty in
      let occurrences =
        object
          inherit [_] iter_statement as super

          method! visit_place () p =
            match p.kind with
            | PlaceLocal id ->
                counts :=
                  LocalId.Map.update id
                    (fun n -> Some (1 + Option.value n ~default:0))
                    !counts
            | _ -> super#visit_place () p
        end
      in
      occurrences#visit_block () body.body;
      let used_twice id = LocalId.Map.find_opt id !counts = Some 2 in
      let rec moved_through_deref id (p : place) =
        match p.kind with
        | PlaceProjection ({ kind = PlaceLocal root; _ }, Deref) -> root = id
        | PlaceProjection (p, _) -> moved_through_deref id p
        | _ -> false
      in
      (* Skip the storage markers between the statements *)
      let rec split lives = function
        | ({ kind = StorageLive _; _ } as st) :: rest -> split (st :: lives) rest
        | st :: rest -> Some (List.rev lives, st, rest)
        | [] -> None
      in
      let converted = ref LocalId.Set.empty in
      let rec rewrite (sts : statement list) : statement list =
        match sts with
        | ({ kind = Assign (({ kind = PlaceLocal b; _ } as bp), RvRef (arr, (BMut | BTwoPhaseMut), meta)); _ } as st0)
          :: rest -> (
            match split [] rest with
            | Some
                ( lives0,
                  ({
                     kind =
                       Call
                         ({
                            func =
                              FnOpRegular
                                ({
                                   kind =
                                     FunId
                                       (FBuiltin
                                          (Index
                                             {
                                               is_array = true;
                                               mutability = RMut;
                                               is_range = false;
                                             }));
                                   _;
                                 } as fn_ptr);
                            args = [ Move { kind = PlaceLocal b'; _ }; idx ];
                            dest = { kind = PlaceLocal r; _ } as rp;
                          });
                     _;
                   } as st1),
                  rest' )
              when b = b' && used_twice b && used_twice r -> (
                match split [] rest' with
                | Some
                    ( lives1,
                      ({ kind = Assign (_, Use (Move p)); _ } as st2),
                      rest'' )
                  when moved_through_deref r p ->
                    converted := LocalId.Set.add b (LocalId.Set.add r !converted);
                    let st0 = { st0 with kind = Assign (bp, RvRef (arr, BShared, meta)) } in
                    let fn_ptr =
                      {
                        fn_ptr with
                        kind =
                          FunId
                            (FBuiltin
                               (Index
                                  {
                                    is_array = true;
                                    mutability = RShared;
                                    is_range = false;
                                  }));
                      }
                    in
                    let st1 =
                      {
                        st1 with
                        kind =
                          Call
                            {
                              func = FnOpRegular fn_ptr;
                              args = [ Move bp; idx ];
                              dest = rp;
                            };
                      }
                    in
                    (st0 :: lives0) @ (st1 :: lives1) @ (st2 :: rewrite rest'')
                | _ -> st0 :: rewrite rest)
            | _ -> st0 :: rewrite rest)
        | st :: rest -> st :: rewrite rest
        | [] -> []
      in
      let rewrite_blocks =
        object
          inherit [_] map_statement as super

          method! visit_block env b =
            let b = super#visit_block env b in
            { b with statements = rewrite b.statements }
        end
      in
      let body_body = rewrite_blocks#visit_block () body.body in
      if LocalId.Set.is_empty !converted then f
      else
        (* The borrow and the result become shared references *)
        let shared (ty : ty) : ty =
          match ty with
          | TRef (r, ty, RMut) -> TRef (r, ty, RShared)
          | _ -> ty
        in
        let retype =
          object
            inherit [_] map_statement as super

            method! visit_place env p =
              match p.kind with
              | PlaceLocal id when LocalId.Set.mem id !converted ->
                  { p with ty = shared p.ty }
              | _ -> super#visit_place env p
          end
        in
        let locals =
          List.map
            (fun (local : local) ->
              if LocalId.Set.mem local.index !converted then
                { local with local_ty = shared local.local_ty }
              else local)
            body.locals.locals
        in
        let body =
          {
            body with
            body = retype#visit_block () body_body;
            locals = { body.locals with locals };
          }
        in
        { f with body = StructuredBody body }
  | _ -> f

(** Share repeated shared indexings of an unchanged place.

    A slice pattern such as [[A(B(x)), C(y), rest @ ..]] tests the variant of
    each element, then reads the tested elements again through fresh
    constant-index projections. Charon lowers every such projection to its own
    builtin call ([@SliceIndexShared], [@ArrayIndexShared]) on a fresh shared
    borrow of the indexed place, so the symbolic interpreter sees unrelated
    element references: projecting through the variant tested on the first
    reference then requires expanding the second one without branching, which
    fails ("Not allowed to expand enumerations with several variants").

    A shared indexing is a pure function of the indexed place and the index:
    while the indexed place, the index and the first result are unchanged, a
    second shared indexing with the same arguments returns the same element
    reference (and cannot fail, since the first one did not). Replace it with a
    copy of the first result, which is the MIR semantics of the projection.

    A result is available in the statements which follow it in its block,
    including nested blocks, until a statement may write one of the locals it
    depends on (assignment, move, mutable or raw borrow, storage marker, drop).
    After a branching, a result survives only if no branch writes those locals;
    in a loop body, only if the loop body does not write them. *)
let share_repeated_shared_indexing (_crate : crate) (f : fun_decl) : fun_decl =
  let rec root (p : place) : LocalId.id option =
    match p.kind with
    | PlaceLocal id -> Some id
    | PlaceProjection (p, _) -> root p
    | PlaceGlobal _ -> None
  in
  (* The locals a statement (with its nested blocks) may write *)
  let written (st : statement) : LocalId.Set.t =
    let set = ref LocalId.Set.empty in
    let add (p : place) =
      Option.iter (fun id -> set := LocalId.Set.add id !set) (root p)
    in
    let visitor =
      object
        inherit [_] iter_statement as super

        method! visit_statement env st =
          (match st.kind with
          | Assign (p, _) | SetDiscriminant (p, _) | Drop (p, _, _) -> add p
          | Call call -> add call.dest
          | StorageLive id | StorageDead id -> set := LocalId.Set.add id !set
          | _ -> ());
          super#visit_statement env st

        method! visit_operand env op =
          (match op with
          | Move p -> add p
          | _ -> ());
          super#visit_operand env op

        method! visit_rvalue env rv =
          (match rv with
          | RvRef (_, BShared, _) -> ()
          | RvRef (p, _, _) | RawPtr (p, _, _) -> add p
          | _ -> ());
          super#visit_rvalue env rv
      end
    in
    visitor#visit_statement () st;
    !set
  in
  (* The locals read by an indexing key: the borrow of the indexed place and
     the index *)
  let key_locals (rv, idx) : LocalId.Set.t =
    let set = ref LocalId.Set.empty in
    let visitor =
      object
        inherit [_] iter_statement
        method! visit_local_id _ id = set := LocalId.Set.add id !set
      end
    in
    visitor#visit_rvalue () rv;
    visitor#visit_operand () idx;
    !set
  in
  (* An available result: the key (borrow rvalue, builtin, generics, index),
     its locals, and the local holding the result *)
  let valid written (key, locals, result) =
    ignore key;
    (not (LocalId.Set.mem result written))
    && LocalId.Set.disjoint locals written
  in
  let shared_index (st : statement) =
    match st.kind with
    | Call
        {
          func =
            FnOpRegular
              {
                kind =
                  FunId
                    (FBuiltin
                       (Index { mutability = RShared; is_range = false; _ } as
                        builtin));
                generics;
              };
          args = [ Move { kind = PlaceLocal borrow; _ }; idx ];
          dest = { kind = PlaceLocal result; ty };
        } -> Some (builtin, generics, borrow, idx, result, ty)
    | _ -> None
  in
  (* Whether control may continue after a block with the statement which
     follows it *)
  let rec falls_through (b : block) : bool =
    match List.rev b.statements with
    | { kind = Return | Abort _ | Break _ | Continue _; _ } :: _ -> false
    | { kind = Switch switch; _ } :: _ -> (
        match switch with
        | If (_, b0, b1) -> falls_through b0 || falls_through b1
        | SwitchInt (_, _, branches, otherwise) ->
            List.exists (fun (_, b) -> falls_through b) branches
            || falls_through otherwise
        | Match (_, branches, otherwise) -> (
            List.exists (fun (_, b) -> falls_through b) branches
            ||
            match otherwise with
            | Some b -> falls_through b
            | None -> false))
    | _ -> true
  in
  match f.body with
  | StructuredBody body ->
      let rec block avail (b : block) : block =
        let rec go avail (sts : statement list) =
          match sts with
          | ({ kind = Assign ({ kind = PlaceLocal borrow; _ }, rv); _ } as st0)
            :: rest -> (
              (* The indexing call may follow storage markers *)
              let rec split lives = function
                | ({ kind = StorageLive id; _ } as st) :: rest when id <> borrow
                  -> split (st :: lives) rest
                | st1 :: rest -> Some (List.rev lives, st1, rest)
                | [] -> None
              in
              match (rv, split [] rest) with
              | RvRef (_, BShared, _), Some (lives, st1, rest') -> (
                  match shared_index st1 with
                  | Some (builtin, generics, borrow', idx, result, ty)
                    when borrow = borrow' ->
                      let key = (rv, builtin, generics, idx) in
                      let written =
                        List.fold_left
                          (fun w st -> LocalId.Set.union w (written st))
                          LocalId.Set.empty
                          ((st0 :: lives) @ [ st1 ])
                      in
                      let avail = List.filter (valid written) avail in
                      let previous =
                        List.find_opt (fun (key', _, _) -> key' = key) avail
                      in
                      let sts, avail =
                        match previous with
                        | Some (_, _, previous) ->
                            (* The previous result is still valid after these
                               statements, which write [result] *)
                            let copy =
                              {
                                st1 with
                                kind =
                                  Assign
                                    ( { kind = PlaceLocal result; ty },
                                      Use
                                        (Copy { kind = PlaceLocal previous; ty })
                                    );
                                comments_before =
                                  st0.comments_before @ st1.comments_before;
                              }
                            in
                            (lives @ [ copy ], avail)
                        | None ->
                            let locals = key_locals (rv, idx) in
                            ( (st0 :: lives) @ [ st1 ],
                              (key, locals, result) :: avail )
                      in
                      sts @ go avail rest'
                  | _ -> statement avail st0 rest)
              | _ -> statement avail st0 rest)
          | st :: rest -> statement avail st rest
          | [] -> []
        and statement avail st rest =
          (* The statements after a switch follow only its branches which may
             complete normally: the writes of a branch ending with a return, an
             abort, a break or a continue (e.g. the storage markers before the
             early return of a slice pattern's fallback arm in a loop body) do
             not reach them *)
          let written =
            match st.kind with
            | Switch switch ->
                let keep (b : block) =
                  if falls_through b then b else { b with statements = [] }
                in
                let switch =
                  match switch with
                  | If (op, b0, b1) -> If (op, keep b0, keep b1)
                  | SwitchInt (op, ty, branches, otherwise) ->
                      SwitchInt
                        ( op,
                          ty,
                          List.map (fun (v, b) -> (v, keep b)) branches,
                          keep otherwise )
                  | Match (p, branches, otherwise) ->
                      Match
                        ( p,
                          List.map (fun (v, b) -> (v, keep b)) branches,
                          Option.map keep otherwise )
                in
                written { st with kind = Switch switch }
            | _ -> written st
          in
          let st =
            match st.kind with
            | Switch switch ->
                (* A branch runs from the switch: its scan invalidates the
                   results it writes from the writing statement on *)
                let inner = avail in
                let switch =
                  match switch with
                  | If (op, b0, b1) -> If (op, block inner b0, block inner b1)
                  | SwitchInt (op, ty, branches, otherwise) ->
                      SwitchInt
                        ( op,
                          ty,
                          List.map (fun (v, b) -> (v, block inner b)) branches,
                          block inner otherwise )
                  | Match (p, branches, otherwise) ->
                      Match
                        ( p,
                          List.map (fun (v, b) -> (v, block inner b)) branches,
                          Option.map (block inner) otherwise )
                in
                { st with kind = Switch switch }
            | Loop b ->
                (* Every iteration may follow a write of the loop body *)
                {
                  st with
                  kind = Loop (block (List.filter (valid written) avail) b);
                }
            | _ -> st
          in
          st :: go (List.filter (valid written) avail) rest
        in
        { b with statements = go avail b.statements }
      in
      { f with body = StructuredBody { body with body = block [] body.body } }
  | _ -> f

(** Optimized upstream MIR may use [Copy] at a non-Copy value's last use
    (including an unconstrained generic parameter). Recover the ownership
    transfer before symbolic execution. A place must be locally owned, used only
    once by the statement, and dead on every successor, including indirect uses
    through live borrowers. Never turn a read through a reference or a global
    into a move. *)
let recover_last_use_moves (_crate : crate) (f : fun_decl) : fun_decl =
  let rec owned_local (p : place) =
    match p.kind with
    | PlaceLocal id -> Some id
    | PlaceProjection (p, Field _) -> owned_local p
    | PlaceProjection _ | PlaceGlobal _ -> None
  in
  (* Direct variable liveness does not cover references already handed to
     another local. Keep conservative provenance edges through reference-bearing
     assignments and call results, including wrappers and generic values. *)
  let rec may_store_borrow = function
    | TRef _ | TVar _ | TTraitType _ | TDynTrait _ | TError _ -> true
    | TAdt { generics; _ } ->
        generics.regions <> [] || List.exists may_store_borrow generics.types
    | TArray (ty, _) | TSlice ty -> may_store_borrow ty
    | TLiteral _ | TNever | TRawPtr _ | TFnDef _ | TFnPtr _ | TPtrMetadata _ ->
        false
  in
  let rec may_write_borrows = function
    | TRef (_, ty, RMut) -> may_store_borrow ty
    | TAdt { generics; _ } ->
        generics.regions <> [] || List.exists may_write_borrows generics.types
    | TArray (ty, _) | TSlice ty -> may_write_borrows ty
    | TVar _ | TTraitType _ | TDynTrait _ | TError _ -> true
    | TRef (_, _, RShared)
    | TLiteral _ | TNever | TRawPtr _ | TFnDef _ | TFnPtr _ | TPtrMetadata _ ->
        false
  in
  let rec base_local (p : place) =
    match p.kind with
    | PlaceLocal id -> Some id
    | PlaceProjection (p, _) -> base_local p
    | PlaceGlobal _ -> None
  in
  let rec indirect_place (p : place) =
    match p.kind with
    | PlaceProjection (_, Deref) -> true
    | PlaceProjection (p, _) -> indirect_place p
    | PlaceLocal _ | PlaceGlobal _ -> false
  in
  let borrowers = ref LocalId.Map.empty in
  let origins = ref LocalId.Map.empty in
  let stores = ref [] in
  let changed = ref false in
  let add_edge source dest =
    let next =
      Option.value
        (LocalId.Map.find_opt source !borrowers)
        ~default:LocalId.Set.empty
    in
    if not (LocalId.Set.mem dest next) then (
      changed := true;
      borrowers := LocalId.Map.add source (LocalId.Set.add dest next) !borrowers;
      origins :=
        LocalId.Map.update dest
          (fun ids ->
            Some
              (LocalId.Set.add source
                 (Option.value ids ~default:LocalId.Set.empty)))
          !origins)
  in
  let collect_sources (dest : place) visit =
    match base_local dest with
    | Some dest_id when may_store_borrow dest.ty ->
        let reads =
          object
            inherit [_] iter_statement

            method! visit_local_id _ source_id =
              add_edge source_id dest_id;
              if indirect_place dest then
                stores := (source_id, dest_id) :: !stores
          end
        in
        visit reads
    | _ -> ()
  in
  let aliases =
    object
      inherit [_] iter_statement as super

      method! visit_statement env st =
        (match st.kind with
        | Assign (dest, value) ->
            collect_sources dest (fun reads -> reads#visit_rvalue () value)
        | Call call ->
            let args =
              List.filter_map
                (function
                  | (Copy p | Move p) when may_store_borrow p.ty ->
                      Option.map (fun id -> (id, p.ty)) (base_local p)
                  | _ -> None)
                call.args
            in
            List.iter
              (fun (target, ty) ->
                if may_write_borrows ty then
                  List.iter
                    (fun (source, _) ->
                      if source <> target then
                        stores := (source, target) :: !stores)
                    args)
              args;
            collect_sources call.dest (fun reads ->
                reads#visit_fn_operand () call.func;
                List.iter (reads#visit_operand ()) call.args)
        | _ -> ());
        super#visit_statement env st
    end
  in
  (match f.body with
  | StructuredBody body -> aliases#visit_block () body.body
  | _ -> ());
  (* A callee can retain an input borrow in a mutable receiver even when its
     return type is unit. Propagate those writes back to the receiver's lenders,
     not just its temporary reference. Iterate for nested stores and loops. *)
  let storage =
    match f.body with
    | StructuredBody body ->
        List.fold_left
          (fun ids (local : local) ->
            if may_store_borrow local.local_ty then
              LocalId.Set.add local.index ids
            else ids)
          LocalId.Set.empty body.locals.locals
    | _ -> LocalId.Set.empty
  in
  let rec propagate_stores () =
    changed := false;
    List.iter
      (fun (source, target) ->
        let seen = ref LocalId.Set.empty in
        let rec visit target =
          if source <> target && not (LocalId.Set.mem target !seen) then (
            seen := LocalId.Set.add target !seen;
            if LocalId.Set.mem target storage then add_edge source target;
            Option.iter (LocalId.Set.iter visit)
              (LocalId.Map.find_opt target !origins))
        in
        visit target)
      !stores;
    if !changed then propagate_stores ()
  in
  propagate_stores ();
  let is_live_through_aliases live id =
    let seen = ref LocalId.Set.empty in
    let rec visit id =
      if LocalId.Set.mem id live then true
      else if LocalId.Set.mem id !seen then false
      else (
        seen := LocalId.Set.add id !seen;
        match LocalId.Map.find_opt id !borrowers with
        | None -> false
        | Some ids -> LocalId.Set.exists visit ids)
    in
    visit id
  in
  let rec block rewrite loops live_after (b : block) =
    let live, statements =
      List.fold_right
        (fun st (live, statements) ->
          let live, st = statement rewrite loops live st in
          (live, st :: statements))
        b.statements (live_after, [])
    in
    (live, if rewrite then { b with statements } else b)
  and statement rewrite loops live_after (st : statement) =
    match st.kind with
    | Return -> (LocalId.Set.singleton LocalId.zero, st)
    | Abort _ -> (LocalId.Set.empty, st)
    | Break depth -> (fst (List.nth loops depth), st)
    | Continue depth -> (snd (List.nth loops depth), st)
    | Loop body ->
        let rec fix head =
          let next, _ = block false ((live_after, head) :: loops) head body in
          if LocalId.Set.equal head next then head else fix next
        in
        let head = fix LocalId.Set.empty in
        let _, body = block rewrite ((live_after, head) :: loops) head body in
        (head, if rewrite then { st with kind = Loop body } else st)
    | Switch switch ->
        let live = ref LocalId.Set.empty in
        let branch b =
          let before, b = block rewrite loops live_after b in
          live := LocalId.Set.union before !live;
          b
        in
        let switch =
          match switch with
          | If (op, yes, no) -> If (op, branch yes, branch no)
          | SwitchInt (op, ty, branches, otherwise) ->
              SwitchInt
                ( op,
                  ty,
                  List.map (fun (pats, b) -> (pats, branch b)) branches,
                  branch otherwise )
          | Match (p, branches, otherwise) ->
              Match
                ( p,
                  List.map (fun (pats, b) -> (pats, branch b)) branches,
                  Option.map branch otherwise )
        in
        (* Branches have already been analyzed. Treat only the scrutinee as
           this statement's read, while keeping it intact for the interpreter. *)
        let reads =
          object
            inherit [_] iter_statement
            method! visit_block _ _ = ()
            method! visit_local_id _ id = live := LocalId.Set.add id !live
          end
        in
        reads#visit_switch () switch;
        (!live, if rewrite then { st with kind = Switch switch } else st)
    | _ ->
        let counts = ref LocalId.Map.empty in
        let reads =
          object
            inherit [_] iter_statement

            method! visit_local_id _ id =
              counts :=
                LocalId.Map.update id
                  (fun n -> Some (1 + Option.value n ~default:0))
                  !counts
          end
        in
        let write_place (p : place) =
          match p.kind with
          | PlaceLocal id -> LocalId.Set.remove id live_after
          | _ ->
              reads#visit_place () p;
              live_after
        in
        let live_after =
          match st.kind with
          | Assign (p, rv) ->
              reads#visit_rvalue () rv;
              write_place p
          | Call call ->
              reads#visit_fn_operand () call.func;
              List.iter (reads#visit_operand ()) call.args;
              write_place call.dest
          | StorageLive id | StorageDead id -> LocalId.Set.remove id live_after
          | _ ->
              reads#visit_statement () st;
              live_after
        in
        let st =
          if not rewrite then st
          else
            let visitor =
              object
                inherit [_] map_statement as super

                method! visit_operand env op =
                  match op with
                  | Copy p -> (
                      match owned_local p with
                      | Some id
                        when LocalId.Map.find_opt id !counts = Some 1
                             && not (is_live_through_aliases live_after id) ->
                          Move p
                      | _ -> super#visit_operand env op)
                  | _ -> super#visit_operand env op
              end
            in
            visitor#visit_statement () st
        in
        let before =
          LocalId.Map.fold
            (fun id _ live -> LocalId.Set.add id live)
            !counts live_after
        in
        (before, st)
  in
  match f.body with
  | StructuredBody body ->
      let _, b = block true [] LocalId.Set.empty body.body in
      { f with body = StructuredBody { body with body = b } }
  | _ -> f

(** A CopyForDeref temporary is a place proxy, not a fresh mutable reborrow.
    Inline an adjacent, single-consumer proxy into its reference expression.
    This preserves shared reborrows through shared access to mutable references.
*)
let inline_deref_copies (_crate : crate) (f : fun_decl) : fun_decl =
  match f.body with
  | StructuredBody body ->
      let counts = ref LocalId.Map.empty in
      let count id =
        Option.value (LocalId.Map.find_opt id !counts) ~default:0
      in
      let occurrences =
        object
          inherit [_] iter_statement as super

          method! visit_place delta p =
            match p.kind with
            | PlaceLocal id ->
                counts := LocalId.Map.add id (count id + delta) !counts
            | _ -> super#visit_place delta p
        end
      in
      occurrences#visit_block 1 body.body;
      let rec through_deref id (p : place) =
        match p.kind with
        | PlaceProjection ({ kind = PlaceLocal root; _ }, Deref) -> root = id
        | PlaceProjection (p, _) -> through_deref id p
        | _ -> false
      in
      let rvalue_count id rv =
        let n = ref 0 in
        let visitor =
          object
            inherit [_] iter_statement as super

            method! visit_place env p =
              match p.kind with
              | PlaceLocal root when root = id -> incr n
              | _ -> super#visit_place env p
          end
        in
        visitor#visit_rvalue () rv;
        !n
      in
      let visitor =
        object
          inherit [_] map_statement as super

          method! visit_block env b =
            let b = super#visit_block env b in
            let statements =
              List.fold_right
                (fun st rest ->
                  match (st.kind, rest) with
                  | ( Assign
                        ( { kind = PlaceLocal id; _ },
                          Use (Copy ({ ty = TRef (_, _, RMut); _ } as p)) ),
                      ({ kind = Assign (dest, (RvRef (target, _, _) as rv)); _ }
                       as next)
                      :: tail )
                    when through_deref id target
                         && count id = 1 + rvalue_count id rv ->
                      let replace =
                        object
                          inherit [_] map_statement as super

                          method! visit_place env q =
                            match q.kind with
                            | PlaceLocal root when root = id -> p
                            | _ -> super#visit_place env q
                        end
                      in
                      let next' =
                        {
                          next with
                          kind = Assign (dest, replace#visit_rvalue () rv);
                          comments_before =
                            st.comments_before @ next.comments_before;
                        }
                      in
                      occurrences#visit_statement (-1) st;
                      occurrences#visit_statement (-1) next;
                      occurrences#visit_statement 1 next';
                      next' :: tail
                  | _ -> st :: rest)
                b.statements []
            in
            { b with statements }
        end
      in
      let b = visitor#visit_block () body.body in
      { f with body = StructuredBody { body with body = b } }
  | _ -> f

(** Restore the reborrows hidden by optimized MIR's mutable-reference [Copy]
    operands. Last-use ownership transfers have already been recovered; a
    remaining [copy p : &mut T] means [&mut *p], never a duplicated borrow or a
    move out of [p]. In particular, the ordinary mutable-borrow access checks
    still reject paths crossing a shared reference.

    When an operand needs a temporary, materialize the other place operands of
    that statement in evaluation order too: hoisting only the reborrow could
    invalidate an earlier read or move. Nested blocks are handled separately by
    [map_statement], so no borrow is hoisted out of its branch or loop. *)
let reborrow_mutable_copies (_crate : crate) (f : fun_decl) : fun_decl =
  let is_mutable_copy = function
    | Copy { ty = TRef (_, _, RMut); _ } -> true
    | _ -> false
  in
  let reborrow (p : place) ty =
    let pointee = { kind = PlaceProjection (p, Deref); ty } in
    (* Keep the source reference's metadata, including for unsized pointees.
       This is a metadata read, not a copy of the mutable reference itself. *)
    let metadata =
      Copy { kind = PlaceProjection (p, PtrMetadata); ty = TPtrMetadata ty }
    in
    RvRef (pointee, BMut, metadata)
  in
  match f.body with
  | StructuredBody body ->
      let new_locals = ref [] in
      let _, gen =
        LocalId.mk_stateful_generator_starting_at_id
          (LocalId.of_int (List.length body.locals.locals))
      in
      let normalize (st : statement) =
        match st.kind with
        | Assign (dest, Use (Copy ({ ty = TRef (_, ty, RMut); _ } as p))) ->
            [ { st with kind = Assign (dest, reborrow p ty) } ]
        | _ ->
            let needs_reborrow = ref false in
            let scan =
              object
                inherit [_] iter_statement
                method! visit_block _ _ = ()
                method! visit_place _ _ = ()

                method! visit_operand _ op =
                  if is_mutable_copy op then needs_reborrow := true
              end
            in
            scan#visit_statement () st;
            if not !needs_reborrow then [ st ]
            else
              let before = ref [] in
              let visitor =
                object
                  inherit [_] map_statement
                  method! visit_block _ b = b
                  method! visit_place _ p = p

                  method! visit_operand _ op =
                    match op with
                    | Constant _ -> op
                    | Copy p | Move p ->
                        let local =
                          {
                            index = gen ();
                            local_ty = p.ty;
                            name = None;
                            span = st.span;
                          }
                        in
                        new_locals := local :: !new_locals;
                        let dest =
                          { kind = PlaceLocal local.index; ty = p.ty }
                        in
                        let rv =
                          match op with
                          | Copy { ty = TRef (_, ty, RMut); _ } -> reborrow p ty
                          | _ -> Use op
                        in
                        before :=
                          {
                            span = st.span;
                            statement_id = StatementId.zero;
                            kind = Assign (dest, rv);
                            comments_before = [];
                          }
                          :: !before;
                        Move dest
                end
              in
              let st = visitor#visit_statement () st in
              List.rev_append !before [ st ]
      in
      let b = map_statement normalize body.body in
      {
        f with
        body =
          StructuredBody
            {
              body with
              body = b;
              locals =
                {
                  body.locals with
                  locals = body.locals.locals @ List.rev !new_locals;
                };
            };
      }
  | _ -> f

(** A switch over a [char] has no symbolic integer expansion. Test its values
    in order with [==] instead: the scrutinee is a copyable [char], and the
    branches are left in place (a group of values sets a flag, so its branch is
    not duplicated). *)
let expand_char_switches (_crate : crate) (f : fun_decl) : fun_decl =
  match f.body with
  | StructuredBody body ->
      let new_locals = ref [] in
      let _, gen =
        LocalId.mk_stateful_generator_starting_at_id
          (LocalId.of_int (List.length body.locals.locals))
      in
      let bool_ty = TLiteral TBool in
      let fresh span : place =
        let local = { index = gen (); local_ty = bool_ty; name = None; span } in
        new_locals := local :: !new_locals;
        { kind = PlaceLocal local.index; ty = bool_ty }
      in
      let mk span kind : statement =
        { span; statement_id = StatementId.zero; kind; comments_before = [] }
      in
      let block span statements : block = { span; statements } in
      let bool_const b : operand =
        Constant { kind = CLiteral (VBool b); ty = bool_ty }
      in
      let rewrite (st : statement) : statement list =
        match st.kind with
        | Switch (SwitchInt (op, TChar, targets, otherwise)) ->
            let span = st.span in
            let op =
              match op with
              | Move p -> Copy p
              | _ -> op
            in
            (* [dest := op == value] *)
            let test (dest : place) (value : Values.literal) : statement =
              mk span
                (Assign
                   ( dest,
                     BinaryOp
                       ( Eq,
                         op,
                         Constant { kind = CLiteral value; ty = TLiteral TChar }
                       ) ))
            in
            let rec branches targets : statement list =
              match targets with
              | [] -> otherwise.statements
              | ([ value ], target) :: targets ->
                  let flag = fresh span in
                  [
                    test flag value;
                    mk span
                      (Switch
                         (If (Move flag, target, block span (branches targets))));
                  ]
              | (values, target) :: targets ->
                  let flag = fresh span in
                  let set_flag value =
                    let equal = fresh span in
                    [
                      test equal value;
                      mk span
                        (Switch
                           (If
                              ( Move equal,
                                block span
                                  [ mk span (Assign (flag, Use (bool_const true))) ],
                                block span [] )));
                    ]
                  in
                  (mk span (Assign (flag, Use (bool_const false)))
                  :: List.concat_map set_flag values)
                  @ [
                      mk span
                        (Switch
                           (If (Move flag, target, block span (branches targets))));
                    ]
            in
            branches targets
        | _ -> [ st ]
      in
      let b = map_statement rewrite body.body in
      if !new_locals = [] then f
      else
        {
          f with
          body =
            StructuredBody
              {
                body with
                body = b;
                locals =
                  {
                    body.locals with
                    locals = body.locals.locals @ List.rev !new_locals;
                  };
              };
        }
  | _ -> f

(** Closure types carry no outlives predicates, while rustc infers those of
    the other structures from the types of their fields (for [struct W<'a, 'b>
    { f : &'a mut C<'b> }]: ['b : 'a]). Well-formedness of a closure type
    implies the same predicates for the types of its captured variables:
    without them, the region of a borrow captured by a closure is not an
    ancestor of the regions of the value it borrows, neither in the regions
    hierarchy of a signature ([RegionsHierarchy]) nor in the outlive
    projections of a value ([TypesAnalysis.compute_outlive_proj_ty]), so the
    values borrowed through a captured borrow are never given back at their
    level. We add them like rustc's inference: for every [&'r T] in the type
    of a field, [T : 'r], and the (substituted) predicates of every ADT which
    appears in the type of a field. A closure cannot capture itself, so the
    recursion through the closures captured by a closure terminates.
    The regions of an added predicate must be free (or ['static]): its
    consumers read them as the regions of a value. The exception is the
    regions quantified by a binder inside a trait reference, e.g. the ['a] of
    the clause [T : for<'a> FnMut(&'a Expr)] which the arguments of the type
    of a closure capturing [&'r mut C<T>] carry: a trait reference is evidence,
    not stored data, the consumers of the predicates never visit it
    ([RegionsHierarchy.explore_generics] and
    [TypesAnalysis.compute_outlive_proj_ty] skip the trait references), and a
    region bound inside it (a de Bruijn index below the number of binders
    crossed inside it) does not escape the predicate. Predicates which mention
    erased regions, or bound regions other than those, are not added. *)
let add_closure_implied_outlives (crate : crate) : crate =
  let memo = ref TypeDeclId.Map.empty in
  (* The environment: the flag which records an unsupported region, and the
     number of binders crossed inside the enclosing trait reference ([None]
     outside the trait references) *)
  let supported_regions =
    object
      inherit [_] iter_ty as super

      method! visit_region (ok, trait_depth) r =
        match (r, trait_depth) with
        | (RVar (Free _) | RStatic), _ -> ()
        | RVar (Bound (dbid, _)), Some depth when dbid < depth -> ()
        | _ -> ok := false

      method! visit_trait_ref (ok, trait_depth) tr =
        super#visit_trait_ref
          (ok, Some (Option.value trait_depth ~default:0))
          tr

      method! visit_region_binder visit_value (ok, trait_depth) b =
        super#visit_region_binder visit_value
          (ok, Option.map (( + ) 1) trait_depth)
          b

      method! visit_binder visit_value (ok, trait_depth) b =
        super#visit_binder visit_value (ok, Option.map (( + ) 1) trait_depth) b
    end
  in
  let is_supported (visit : bool ref * int option -> unit) : bool =
    let ok = ref true in
    visit (ok, None);
    !ok
  in
  let rec predicates_of (id : TypeDeclId.id) : generic_params option =
    match TypeDeclId.Map.find_opt id crate.type_decls with
    | None -> None
    | Some decl -> (
        match (decl.src, decl.kind) with
        | ClosureItem _, Struct fields -> (
            match TypeDeclId.Map.find_opt id !memo with
            | Some generics -> Some generics
            | None ->
                let generics = implied_generics decl.generics fields in
                memo := TypeDeclId.Map.add id generics !memo;
                Some generics)
        | _ -> Some decl.generics)
  and implied_generics (generics : generic_params) (fields : field list) :
      generic_params =
    let regions_outlive = ref (List.rev generics.regions_outlive) in
    let types_outlive = ref (List.rev generics.types_outlive) in
    let add_region_outlive (p : (region, region) outlives_pred) =
      let r0, r1 = p in
      let pred = { binder_regions = []; binder_value = p } in
      if
        is_supported (fun env ->
            supported_regions#visit_region env r0;
            supported_regions#visit_region env r1)
        && not (List.mem pred !regions_outlive)
      then regions_outlive := pred :: !regions_outlive
    in
    let add_type_outlive (p : (ty, region) outlives_pred) =
      let ty, r = p in
      let pred = { binder_regions = []; binder_value = p } in
      if
        is_supported (fun env ->
            supported_regions#visit_ty env ty;
            supported_regions#visit_region env r)
        && not (List.mem pred !types_outlive)
      then types_outlive := pred :: !types_outlive
    in
    let rec visit_ty (ty : ty) : unit =
      match ty with
      | TRef (r, pointee, _) ->
          add_type_outlive (pointee, r);
          visit_ty pointee
      | TAdt { id; generics = args } ->
          (match id with
          | TAdtId id -> (
              match
                ( TypeDeclId.Map.find_opt id crate.type_decls,
                  predicates_of id )
              with
              | Some decl, Some params ->
                  let subst =
                    [%add_loc] Substitute.make_subst_from_generics
                      (Some decl.item_meta.span) decl.generics args Self
                  in
                  let params = Substitute.predicates_substitute subst params in
                  List.iter
                    (fun (p : _ region_binder) ->
                      if p.binder_regions = [] then
                        add_region_outlive p.binder_value)
                    params.regions_outlive;
                  List.iter
                    (fun (p : _ region_binder) ->
                      if p.binder_regions = [] then
                        add_type_outlive p.binder_value)
                    params.types_outlive
              | _ -> ())
          | TTuple | TBuiltin _ -> ());
          List.iter visit_ty args.types
      | TArray (ty, _) | TSlice ty | TRawPtr (ty, _) -> visit_ty ty
      | TVar _ | TLiteral _ | TNever | TTraitType _ | TFnPtr _ | TFnDef _
      | TDynTrait _ | TPtrMetadata _ | TError _ -> ()
    in
    List.iter (fun (f : field) -> visit_ty f.field_ty) fields;
    {
      generics with
      regions_outlive = List.rev !regions_outlive;
      types_outlive = List.rev !types_outlive;
    }
  in
  let type_decls =
    TypeDeclId.Map.map
      (fun (decl : type_decl) ->
        match (decl.src, decl.kind) with
        | ClosureItem _, Struct _ -> (
            match predicates_of decl.def_id with
            | Some generics -> { decl with generics }
            | None -> decl)
        | _ -> decl)
      crate.type_decls
  in
  { crate with type_decls }

let apply_passes (crate : crate) : crate =
  TypesUtils.register_phantom_data_decls crate.type_decls;
  (* Passes that apply to the whole crate *)
  let crate = add_closure_implied_outlives crate in
  let crate = normalize_modeled_trait_specializations crate in
  (* Before [order_method_region_params]: an instance's shape binds the
     parameters in their original order *)
  admit_modeled_fun_instances crate;
  let crate = order_method_region_params crate in
  (* After [order_method_region_params]: the region parameters of the trait
     methods are in their final order *)
  let crate = order_impl_method_region_groups crate in
  let crate = resolve_default_only_dispatch crate in
  let crate = update_array_default crate in
  (* Passes that apply to individual function bodies *)
  let function_passes =
    [
      ("fix_closure_lifetimes", fix_closure_lifetimes);
      ("remove_unreachable", remove_unreachable);
      ("expand_char_switches", expand_char_switches);
      ("update_loop", update_loops);
      ("read_raw_pointer_metadata", read_raw_pointer_metadata);
      ("read_lengths_before_reborrows", read_lengths_before_reborrows);
      ("shared_indexing_for_array_moves", shared_indexing_for_array_moves);
      ("share_repeated_shared_indexing", share_repeated_shared_indexing);
      ("remove_useless_joins", remove_useless_joins);
      ("recover_last_use_moves", recover_last_use_moves);
      ("inline_deref_copies", inline_deref_copies);
      ("reborrow_mutable_copies", reborrow_mutable_copies);
      ( "remove_shallow_borrows_storage_live_dead",
        remove_shallow_borrows_storage_live_dead );
      ("simplify_panics", simplify_panics);
      ("decompose_global_accesses", decompose_global_accesses);
      ("refresh_statement_ids", refresh_statement_ids);
    ]
  in
  (* Attempt to apply a pass: if it fails we replace the body by [None] *)
  let apply_function_pass (pass_name : string)
      (pass : crate -> fun_decl -> fun_decl) (f : fun_decl) =
    try
      [%recover_internal_errors] f.item_meta.span (fun () ->
          let f = pass crate f in
          [%ltrace
            let env = Print.crate_to_fmt_env crate in
            "After applying [" ^ pass_name ^ "]:\n"
            ^ Print.fun_decl_to_string env "" " " f];
          f)
    with CFailure e ->
      (* The error was already registered, we don't need to register it twice.
         However, we replace the body of the function, and save an error to
         report to the user the fact that we will ignore the function body *)
      let fmt = Print.crate_to_fmt_env crate in
      let name = Print.name_to_string fmt f.item_meta.name in
      [%save_error] f.item_meta.span
        ("Ignoring the body of '" ^ name ^ "' because of previous error");
      let msg =
        Errors.format_error_message_with_file_line e.file e.line e.span e.msg
      in
      { f with body = ErrorBody { span = f.item_meta.span; msg } }
  in
  let fun_decls : fun_decl FunDeclId.Map.t =
    let num_decls = FunDeclId.Map.cardinal crate.fun_decls in
    ProgressBar.with_reporter num_decls "Applied prepasses: " (fun report ->
        FunDeclId.Map.map
          (fun f ->
            [%ltrace
              let env = Print.crate_to_fmt_env crate in
              "Before applying the prepasses:\n"
              ^ Print.fun_decl_to_string env "" " " f];
            let f : fun_decl =
              List.fold_left
                (fun f (name, pass) -> apply_function_pass name pass f)
                f function_passes
            in
            report 1;
            f)
          crate.fun_decls)
  in
  let crate = { crate with fun_decls } in
  let crate = filter_type_aliases crate in
  let crate = replace_static crate in
  let crate = remove_vtables crate in
  let crate = rename_type_vars crate in
  let collection_evidence = crate in
  let crate = resolve_modeled_defaults crate in
  let crate = simplify_trait_calls crate in
  let crate = CollectionContracts.check ~evidence:collection_evidence crate in
  let type_infos = compute_type_infos crate in
  let crate = SortContracts.check type_infos crate in
  [%ltrace "After pre-passes:\n" ^ Print.crate_to_string crate ^ "\n"];
  crate
