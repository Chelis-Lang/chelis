open Values
open Contexts
module S = SynthesizeSymbolic
open Cps
open InterpUtils
open InterpAbs
open InterpMatchCtxs
open InterpJoin

(** The local logger *)
let log = Logging.loops_fixed_point_log

(** Update the abstractions introduced by a loop with additional information,
    such as region group ids, continuation expressions, etc.

    Only the abstractions of loop [loop_id] get a new continuation: they are the
    inputs of the loop (see {!InterpLoops.eval_loop_symbolic}). The abstraction
    of an enclosing loop which the join kept keeps the continuation which that
    loop introduced: inside the loop body, its variable is still the one of the
    enclosing loop, whose inputs have the structure of that continuation (e.g.,
    a whole [Cx] of which the body of the enclosing loop expanded the fields).
    Recomputing it from the destructured loans would apply that variable to the
    loans of the fields instead. *)
let loop_abs_reorder_and_add_info (span : Meta.span) (loop_id : LoopId.id)
    (fixed_ids : ids_sets) (ctx : eval_ctx) : eval_ctx =
  (* Reorder the fresh abstractions in the fixed-point *)
  let fp = reorder_fresh_abs span false fixed_ids.aids ctx in

  (* Introduce continuation expressions. *)
  let add_abs_cont_to_abs (abs : abs) (loop_id : loop_id) : abs =
    InterpAbs.add_abs_cont_to_abs span ctx abs (ELoop (abs.abs_id, loop_id))
  in
  let add_abs_conts ctx =
    let visitor =
      object
        inherit [_] map_eval_ctx

        method! visit_abs _ abs =
          match abs.kind with
          | Loop loop_id' when loop_id' <> loop_id && Option.is_some abs.cont
            ->
              InterpBorrows.destructure_abs span abs.kind ~can_end:abs.can_end
                ctx abs
          | Loop loop_id -> add_abs_cont_to_abs abs loop_id
          | _ -> abs
      end
    in
    visitor#visit_eval_ctx () ctx
  in

  let fp = add_abs_conts fp in

  (* Return *)
  fp

(* TODO: remove the output ids_sets *)
let compute_loop_entry_fixed_point (config : config) (span : Meta.span)
    (loop_id : LoopId.id) (eval_loop_body : stl_cm_fun) (ctx0 : eval_ctx) :
    eval_ctx * ids_sets =
  (* Introduce "reborrows" for the shared values in the abstractions, so that
     the shared values in the fixed abstractions never get modified (technically,
     they are immutable, but in practice we can introduce more shared loans, or
     expand symbolic values).

     For more details, see the comments for {!reborrow_ashared_loans_symbolic_mutable_borrows}
  *)
  let ctx =
    InterpJoin.reborrow_ashared_loans_symbolic_borrows_no_synth span loop_id
      ~with_abs_conts:false ctx0
  in

  (* Debug *)
  [%ltrace
    "after reborrow_ashared_loans_symbolic_mutable_borrows:" ^ "\n\n- ctx0:\n"
    ^ eval_ctx_to_string ~span:(Some span) ~filter:false ctx0
    ^ "\n\n- ctx1:\n"
    ^ eval_ctx_to_string ~span:(Some span) ~filter:false ctx
    ^ "\n"];

  (* The fixed ids - TODO: remove *)
  let fixed_ids, _ = compute_ctx_ids ctx0 in
  let fixed_ids = ref fixed_ids in

  (* Update the set of fixed ids - for the symbolic and abstraction ids, we
     compute the intersection of ids between the original environment and the
     list of new environments *)
  let update_fixed_ids (ctxl : eval_ctx list) =
    let {
      aids;
      blids;
      borrow_ids;
      unique_borrow_ids;
      shared_borrow_ids;
      non_unique_shared_borrow_ids;
      loan_ids;
      shared_loans_to_values;
      dids;
      rids;
      sids;
    } =
      !fixed_ids
    in
    let sids = ref sids in
    let aids = ref aids in
    (* An abstraction of the loop entry stays fixed only if it is unchanged
       (modulo its continuation, see {!InterpJoinCore.compute_fixed_abs_ids}):
       the loop body can expand the payload of a shared loan it holds (e.g.,
       the reborrow of a shared input whose nested regions are owned by child
       abstractions), after which the join keeps its id but refreshes its
       payload at every iteration. *)
    let abs0 = ctx_get_abs ctx0 in
    List.iter
      (fun ctx ->
        let fixed_ids, _ = compute_ctx_ids ctx in
        sids := SymbolicValueId.Set.inter !sids fixed_ids.sids;
        let abs = ctx_get_abs ctx in
        aids :=
          AbsId.Set.filter
            (fun aid ->
              match (AbsId.Map.find_opt aid abs0, AbsId.Map.find_opt aid abs) with
              | Some a0, Some a1 -> { a0 with cont = None } = { a1 with cont = None }
              | _ -> false)
            (AbsId.Set.inter !aids fixed_ids.aids))
      ctxl;
    fixed_ids :=
      {
        aids = !aids;
        blids;
        borrow_ids;
        unique_borrow_ids;
        shared_borrow_ids;
        non_unique_shared_borrow_ids;
        loan_ids;
        shared_loans_to_values;
        dids;
        rids;
        sids = !sids;
      }
  in

  (* Join the contexts at the loop entry - ctx1 is the current joined
     context (the context at the loop entry, after we called
     {!reborrow_ashared_loans_symbolic_mutable_borrows}, if this is the first iteration) *)
  let join_ctxs (ctx1 : eval_ctx) (ctxs : eval_ctx list) : eval_ctx =
    [%ltrace "join_ctxs"];
    (* Join the context with the context at the loop entry *)
    let (_, _), ctx2 =
      loop_join_origin_with_continue_ctxs config span loop_id ctx1 ctxs
    in
    ctx2
  in

  (* Check if two contexts are equivalent - modulo alpha conversion on the
     existentially quantified borrows/abstractions/symbolic values.
  *)
  let equiv_ctxs (i : int) (ctx1 : eval_ctx) (ctx2 : eval_ctx) : bool =
    [%ltrace "equiv_ctx:"];
    (* Intersect only after the join has reconciled retained payloads. A branch
       can expand an immutable payload symbol which the join legitimately
       retains; transient branch representations must not unfix that symbol. *)
    update_fixed_ids [ ctx2 ];
    let lookup_shared_value _ = [%craise] span "Unreachable" in
    (* If there is just a single iteration left it means we *should* have reached
       a fixed point (otherwise we will fail). In case the fail hard option is on,
       we directly call [match_ctxs]: this way exceptions will not be caught and
       the user will see a full call stack, which eases deboguing. *)
    if i = 1 && !Config.fail_hard then
      let _ =
        match_ctxs span ~check_equiv:true ~recoverable:false !fixed_ids
          lookup_shared_value lookup_shared_value ctx1 ctx2
      in
      true
    else
      Option.is_some
        (try_match_ctxs span ~check_equiv:true !fixed_ids lookup_shared_value
           lookup_shared_value ctx1 ctx2)
  in
  let max_num_iter = Config.loop_fixed_point_max_num_iters in
  (* Keep a trace of the subsequent contexts we computed *)
  let joined_ctxs = ref [ ctx ] in
  let rec compute_fixed_point (ctx : eval_ctx) (i0 : int) (i : int) : eval_ctx =
    if i = 0 then (
      [%ltrace
        "Joined contexts:\n"
        ^ String.concat "\n\n"
            (List.map eval_ctx_to_string (List.rev !joined_ctxs))];
      [%craise] span
        ("Could not compute a loop fixed point in " ^ string_of_int i0
       ^ " iterations"))
    else
      (* Evaluate the loop body to register the different contexts upon reentry *)
      let ctx_resl, _ = eval_loop_body ctx in
      (* Keep only the contexts which reached a `continue`. *)
      let keep_continue_ctx (ctx, res) =
        [%ltrace "register_continue_ctx"];
        match res with
        | Return | Panic | Break _ -> None
        | Unit ->
            (* See the comment in {!eval_loop} *)
            [%craise] span "Unreachable"
        | Continue 0 -> Some ctx
        | Continue _ ->
            (* A continue to an outer loop leaves this loop: see
               {!compute_loop_exit_contexts} *)
            None
      in
      let continue_ctxs = List.filter_map keep_continue_ctx ctx_resl in

      [%ltrace
        "about to join with continue_ctx" ^ "\n\n- ctx0:\n"
        ^ eval_ctx_to_string ~span:(Some span) ~filter:false ctx
        ^ "\n\n"
        ^ String.concat "\n\n"
            (List.map
               (fun ctx ->
                 "- continue_ctx:\n"
                 ^ eval_ctx_to_string ~span:(Some span) ~filter:false ctx)
               continue_ctxs)
        ^ "\n"];

      (* Compute the join between the original contexts and the contexts computed
         upon reentry *)
      let ctx1 = join_ctxs ctx continue_ctxs in

      (* Debug *)
      [%ltrace
        "after joining continue ctxs" ^ "\n\n- ctx0:\n"
        ^ eval_ctx_to_string ~span:(Some span) ~filter:false ctx
        ^ "\n\n- ctx1:\n"
        ^ eval_ctx_to_string ~span:(Some span) ~filter:false ctx1
        ^ "\n"];

      (* Reduce the context in order to reach a fixed-point *)
      let fixed_aids = InterpJoinCore.compute_fixed_abs_ids ctx0 ctx1 in
      let fixed_dids = ctx_get_dummy_var_ids ctx0 in
      let ctx1 =
        InterpReduceCollapse.reduce_ctx config span ~with_abs_conts:false
          (Loop loop_id) fixed_aids fixed_dids ctx1
      in
      (* Debug *)
      [%ltrace
        "after reducing the joined context (fixed_aids: "
        ^ AbsId.Set.to_string None fixed_aids
        ^ "):" ^ "\n- ctx1:\n"
        ^ eval_ctx_to_string ~span:(Some span) ~filter:false ctx1
        ^ "\n"];

      (* Check if we reached a fixed point: if not, iterate *)
      if equiv_ctxs i ctx ctx1 then ctx1
      else (
        joined_ctxs := ctx1 :: !joined_ctxs;
        compute_fixed_point ctx1 i0 (i - 1))
  in
  let fp = compute_fixed_point ctx max_num_iter max_num_iter in

  [%ltrace
    "- fixed point:\n" ^ eval_ctx_to_string ~span:(Some span) ~filter:false fp];

  (* Update the region abstractions to introduce continuation expressions, etc. *)
  update_fixed_ids [ fp ];
  let fp = loop_abs_reorder_and_add_info span loop_id !fixed_ids fp in

  [%ltrace
    "- fixed point:\n" ^ eval_ctx_to_string ~span:(Some span) ~filter:false fp];

  (* Return *)
  (fp, !fixed_ids)

type break_ctx =
  | Single
      (** There is a single break statement, so we don't join the break contexts
      *)
  | Multiple of (eval_ctx * eval_ctx * abs list)
      (** We joined multiple break contexts: the joined context matched at each
          break, the joined context after the loop (they only differ by the
          continuations of the abstractions of enclosing loops, see
          {!join_loop_exit_contexts}), and the fresh abstractions *)

(** The result of leaving a loop, as seen by the code *around* the loop:
    [Unit] for the loop's own [break], and a [Break] or [Continue] of an
    enclosing loop (with the index relative to that enclosing loop) for the
    nonlocal exits. Returns [None] for the results which don't leave the loop.
*)
let loop_exit_of_res (res : statement_eval_res) : statement_eval_res option =
  match res with
  | Break 0 -> Some Unit
  | Break i -> Some (Break (i - 1))
  | Continue 0 | Return | Panic | Unit -> None
  | Continue i -> Some (Continue (i - 1))

(** Join the contexts reaching the same exit of a loop *)
let join_loop_exit_contexts (config : config) (span : Meta.span)
    (loop_id : LoopId.id) (fixed_aids : AbsId.Set.t)
    (fixed_dids : DummyVarId.Set.t) (break_ctxs : eval_ctx list) : break_ctx =
  [%ltrace
    "about to join the contexts at the breaks:\n"
    ^ String.concat "\n\n"
        (List.map
           (fun ctx ->
             "- break_ctx:\n"
             ^ eval_ctx_to_string ~span:(Some span) ~filter:false ctx)
           break_ctxs)
    ^ "\n"];

  (* Compute the join *)
  match break_ctxs with
  | [] -> [%internal_error] span
  | [ _ ] ->
      (* Single break context *)
      Single
  | ctxs ->
      (* Join the contexts *)
      let break_ctx =
        loop_join_break_ctxs config span loop_id fixed_aids fixed_dids ctxs
      in
      (* Debug *)
      [%ltrace
        "after joining break ctxs" ^ "\n\n- ctx0:\n"
        ^ eval_ctx_to_string ~span:(Some span) ~filter:false break_ctx];

      (* Reduce the context - TODO: generalize so that we don't have to do this *)
      let break_ctx =
        InterpReduceCollapse.reduce_ctx config span ~with_abs_conts:true
          (Loop loop_id) fixed_aids fixed_dids break_ctx
      in
      [%ltrace
        "break_ctx after reduce:\n"
        ^ eval_ctx_to_string ~span:(Some span) break_ctx];
      (* Sanity check *)
      if !Config.sanity_checks then Invariants.check_invariants span break_ctx;

      (* Reorder the fresh abstractions *)
      let break_ctx = reorder_fresh_abs span false fixed_aids break_ctx in

      (* Introduce continuation expressions and destructure the region
         abstractions. The context matched at each break, inside the loop body,
         keeps the continuations of the abstractions of enclosing loops, as the
         fixed point does (see {!loop_abs_reorder_and_add_info}). The context
         after the loop recomputes those of the outputs of the loop, as for a
         single break: after the loop, their variables are outputs of the loop.
         The fixed abstractions are not outputs: their variables stay the ones
         of the enclosing loop. *)
      let add_abs_cont_to_abs (abs : abs) (loop_id : loop_id) : abs =
        InterpAbs.add_abs_cont_to_abs span break_ctx abs
          (ELoop (abs.abs_id, loop_id))
      in
      let add_abs_conts (keep_cont : abs -> bool) ctx =
        let visitor =
          object
            inherit [_] map_eval_ctx

            method! visit_abs _ abs =
              match abs.kind with
              | Loop loop_id' ->
                  let abs =
                    if
                      loop_id' <> loop_id && Option.is_some abs.cont
                      && keep_cont abs
                    then abs
                    else add_abs_cont_to_abs abs loop_id'
                  in
                  InterpBorrows.destructure_abs span abs.kind ~can_end:true ctx
                    abs
              | _ -> abs
          end
        in
        visitor#visit_eval_ctx () ctx
      in
      let match_ctx = add_abs_conts (fun _ -> true) break_ctx in
      let break_ctx =
        add_abs_conts
          (fun abs -> AbsId.Set.mem abs.abs_id fixed_aids)
          break_ctx
      in

      let get_fresh_abs (e : env_elem) : abs option =
        match e with
        | EAbs abs ->
            if not (AbsId.Set.mem abs.abs_id fixed_aids) then Some abs else None
        | EBinding _ | EFrame -> None
      in
      (* Pay attention to the fact that the elements are stored in reverse order *)
      let abs = List.rev (List.filter_map get_fresh_abs break_ctx.env) in

      Multiple (match_ctx, break_ctx, abs)

(** Compute the contexts at the exits of a loop, grouped by exit (see
    {!loop_exit_of_res}). The loop's own [break] comes first, followed by the
    nonlocal exits in the order in which they are first reached. *)
let compute_loop_exit_contexts (config : config) (span : Meta.span)
    (loop_id : LoopId.id) (eval_loop_body : stl_cm_fun) (fp_ctx : eval_ctx)
    (fixed_aids : AbsId.Set.t) (fixed_dids : DummyVarId.Set.t) :
    (statement_eval_res * break_ctx) list =
  [%ltrace
    "Initial fixed-point context:\n"
    ^ eval_ctx_to_string ~span:(Some span) ~filter:false fp_ctx];

  (* Update the fixed-point context to remove the continuation expressions from
     the abstractions introduced by the fixed-point *)
  let fp_ctx =
    let update (e : env_elem) : env_elem =
      match (e : env_elem) with
      | EAbs abs -> (
          match abs.kind with
          | Loop loop_id' ->
              if loop_id' = loop_id then
                EAbs { abs with cont = None; kind = Loop loop_id }
              else e
          | _ -> e)
      | EBinding _ | EFrame -> e
    in
    { fp_ctx with env = List.map update fp_ctx.env }
  in

  (* Evaluate the loop body to register the different contexts upon exit *)
  let eval_exit_ctxs () : (statement_eval_res * eval_ctx list ref) list =
    let ctx_resl, _ = eval_loop_body fp_ctx in
    List.fold_left
      (fun exits (ctx, res) ->
        match res with
        | Unit ->
            (* See the comment in {!eval_loop} *)
            [%craise] span "Unreachable"
        | _ -> (
            match loop_exit_of_res res with
            | None -> exits
            | Some exit -> (
                match List.assoc_opt exit exits with
                | None -> exits @ [ (exit, ref [ ctx ]) ]
                | Some ctxs ->
                    ctxs := !ctxs @ [ ctx ];
                    exits)))
      [] ctx_resl
  in
  let exits = eval_exit_ctxs () in
  (* Within one evaluation, the paths reaching an exit may fork after creating a
     loan held by a local, and then share its ids (e.g., [a = *y; let x = &a;]
     followed by two [return]s out of an inner loop: both contexts contain
     [a -> SL@8] and [x -> SB@8]). Their join keeps this loan in the local as
     it is, while the evaluation which synthesizes the loop body creates it
     with fresh ids: joining the exit context with the context at such an exit
     then introduces a region abstraction which is missing from the exit
     context, and the two do not match. In that case, we evaluate the body a
     second time, which refreshes the ids of everything the iteration creates,
     and join the contexts of both evaluations: this introduces the necessary
     abstractions (upstream Aeneas 86158eb, applied to the exits of this fork).

     Loans created by the iteration which are held by anonymous values or
     region abstractions do not need this (the joins move them to region
     abstractions, which the synthesis matches up to their ids), and the join
     over two evaluations is not always possible for them (e.g., the shared
     loans of a static global read in the iteration: "Markers remain after
     ownership reduction"), so we only refresh the exits which need it.

     An exit reached by a single context is not joined (see
     {!join_loop_exit_contexts}): it keeps the context of the first evaluation. *)
  let fp_blids = (fst (compute_ctx_ids fp_ctx)).blids in
  let fresh_local_loans (ctx : eval_ctx) : BorrowId.Set.t =
    let locals =
      List.filter_map
        (function
          | EBinding (BVar _, v) -> Some v
          | EBinding (BDummy _, _) | EAbs _ | EFrame -> None)
        ctx.env
    in
    BorrowId.Set.diff (fst (compute_tvalues_ids locals)).loan_ids fp_blids
  in
  (* Whether two of the contexts reaching an exit share a fresh loan held by a
     local *)
  let share_fresh_local_loan (ctxs : eval_ctx list) : bool =
    let rec go seen = function
      | [] -> false
      | loans :: rest ->
          (not (BorrowId.Set.disjoint seen loans))
          || go (BorrowId.Set.union seen loans) rest
    in
    go BorrowId.Set.empty (List.map fresh_local_loans ctxs)
  in
  let refresh =
    List.map
      (fun (_, ctxs) -> List.length !ctxs > 1 && share_fresh_local_loan !ctxs)
      exits
  in
  (if List.mem true refresh then
     let exits' = eval_exit_ctxs () in
     [%cassert] span
       (List.length exits = List.length exits'
       && List.for_all2
            (fun (exit, ctxs) (exit', ctxs') ->
              exit = exit' && List.length !ctxs = List.length !ctxs')
            exits exits')
       "The two evaluations of the loop body reach different exits";
     List.iteri
       (fun i ((_, ctxs), (_, ctxs')) ->
         if List.nth refresh i then ctxs := !ctxs @ !ctxs')
       (List.combine exits exits'));
  let exits =
    List.filter (fun (exit, _) -> exit = Unit) exits
    @ List.filter (fun (exit, _) -> exit <> Unit) exits
  in
  List.map
    (fun (exit, ctxs) ->
      ( exit,
        join_loop_exit_contexts config span loop_id fixed_aids fixed_dids !ctxs
      ))
    exits
