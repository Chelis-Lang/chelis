open Values
open Types
open Contexts
open Utils
open TypesUtils
open ValuesUtils
open InterpUtils
open InterpBorrowsCore
open InterpAbs
open InterpJoinCore
open InterpMatchCtxs

(** The local logger *)
let log = Logging.reduce_collapse_log

(** Attempts to eliminate useless shared loans, in particular to get rid of
    remaining markers.

    We end concrete shared loans and shared-only loan projectors which have no
    corresponding borrowers. Shared loans have no backward component: this
    removes ownership bookkeeping without discarding either continuation.

    TODO: will not be necessary once we destructure the avalues. *)
let eliminate_shared_loans_once (span : Meta.span) (ctx : eval_ctx) : eval_ctx =
  (* Compute the set of shared borrows *)
  let ids, _ = compute_ctx_ids ctx in
  let shared_borrows = ids.non_unique_shared_borrow_ids in

  let update_loans =
    object (self)
      inherit [_] map_abs as super

      (* ```ocaml *)
      method! visit_ATransportedProj _ transport child =
        ATransportedProj
          (transport, self#visit_aproj transport.current_regions child)

      method! visit_ATransportedValue _ transport child =
        ATransportedValue
          (transport, self#visit_tavalue transport.current_regions child)
      (* ``` *)

      method! visit_ASharedLoan env pm bid sv child =
        if not (BorrowId.Set.mem bid shared_borrows) then
          self#visit_AEndedSharedLoan env pm sv child
        else super#visit_ASharedLoan env pm bid sv child

      method! visit_value env value =
        match value with
        | VLoan (VSharedLoan (bid, sv))
          when not (BorrowId.Set.mem bid shared_borrows) ->
            (* The enclosing retained payload remains in place. Only an
               unborrowed inner loan tag disappears, not its concrete value. *)
            self#visit_value env sv.value
        | _ -> super#visit_value env value

      method! visit_ASymbolic regions pm aproj =
        let aproj = self#visit_aproj regions aproj in
        let pm = if InterpBorrows.proj_has_ownership aproj then pm else PNone in
        ASymbolic (pm, aproj)

      method! visit_aproj regions aproj =
        let aproj = super#visit_aproj regions aproj in
        match aproj with
        | AProjLoans { proj; consumed; borrows }
          when (not
                  (ty_has_mut_borrow_for_region_in_set ctx.type_ctx.type_infos
                     regions proj.proj_ty))
               && InterpBorrows.loan_proj_is_endable span ctx
                    ~lookup_shared:true regions proj ->
            (* Ending the root does not change the levels or histories of
               any surviving descendants. *)
            AEndedProjLoans { proj = proj.sv_id; consumed; borrows }
        | _ -> aproj

      method! visit_abs _ abs =
        (* Continuation metadata records history, not current loan ownership. *)
        {
          abs with
          avalues = List.map (self#visit_tavalue abs.regions.owned) abs.avalues;
        }
    end
  in
  let update_abs (abs : abs) : abs =
    (* Only update the non-frozen abstractions *)
    if abs.can_end then update_loans#visit_abs RegionId.Set.empty abs else abs
  in
  let ctx = ctx_map_abs update_abs ctx in

  (* Remove the ended shared loans, if possible *)
  let ctx = InterpBorrows.eliminate_ended_shared_loans span ctx in

  (* *)
  ctx

(** Eliminating a shared loan also drops the borrows retained in its payload
    (e.g. the [&'b T] captured by a closure lent as [&'a F<'b>]): the loans of
    those borrows may become unborrowed in turn, so we iterate. *)
let rec eliminate_shared_loans (span : Meta.span) (ctx : eval_ctx) : eval_ctx =
  let nctx = eliminate_shared_loans_once span ctx in
  if nctx.env = ctx.env then nctx else eliminate_shared_loans span nctx

(** Compute the set of shared loans and shared loan projectors without markers
    appearing in the context *)
let get_non_marked_shared_loans _span (ctx : eval_ctx) :
    BorrowId.Set.t * NormSymbProj.Set.t =
  let non_marked_loans = ref BorrowId.Set.empty in
  let non_marked_projs = ref NormSymbProj.Set.empty in
  let collect_loans =
    object (self)
      inherit [_] iter_eval_ctx as super

      method! visit_ASharedLoan (regions, _) pm lid sv child =
        if pm = PNone then
          non_marked_loans := BorrowId.Set.add lid !non_marked_loans;
        self#visit_tvalue (regions, pm) sv;
        self#visit_tavalue (regions, PNone) child

      method! visit_AEndedSharedLoan (regions, _) pm sv child =
        self#visit_tvalue (regions, pm) sv;
        self#visit_tavalue (regions, PNone) child

      method! visit_VSharedLoan ((_, pm) as env) lid sv =
        if pm = PNone then
          non_marked_loans := BorrowId.Set.add lid !non_marked_loans;
        super#visit_VSharedLoan env lid sv

      method! visit_ASymbolic (regions, _) pm aproj =
        self#visit_aproj (regions, pm) aproj

      method! visit_aproj ((regions, pm) as env) aproj =
        let visit_children children =
          List.iter (fun (_, child) -> self#visit_aproj env child) children
        in
        (* ```ocaml *)
        match aproj with
        | ATransportedProj (transport, child) ->
            self#visit_aproj (transport.current_regions, pm) child
        (* ``` *)
        | AProjLoans { proj; consumed; borrows } ->
            if
              pm = PNone
              && not
                   (ty_has_mut_borrow_for_region_in_set ctx.type_ctx.type_infos
                      regions proj.proj_ty)
            then
              non_marked_projs :=
                NormSymbProj.Set.add
                  (normalize_symbolic_proj ctx.type_ctx.type_infos regions proj)
                  !non_marked_projs;
            visit_children consumed;
            visit_children borrows
        | AEndedProjLoans { consumed; borrows; _ } ->
            visit_children consumed;
            visit_children borrows
        | AProjBorrows { loans; _ } | AEndedProjBorrows { loans; _ } ->
            visit_children loans
        | APendingLoans _ | APendingSymbolicLoans _ | AEmpty -> ()

      (* ```ocaml *)
      method! visit_ATransportedValue (_, pm) transport child =
        self#visit_tavalue (transport.current_regions, pm) child
      (* ``` *)

      method! visit_abs _ abs = super#visit_abs (abs.regions.owned, PNone) abs
    end
  in
  collect_loans#visit_eval_ctx (RegionId.Set.empty, PNone) ctx;
  (!non_marked_loans, !non_marked_projs)

type borrow_or_proj =
  | Borrow of borrow_id
  | Proj of RegionId.Set.t * symbolic_proj
  | SharedProj of RegionId.Set.t * abstract_shared_borrows
and replay_diagnostic = {
  replay_index : int;
  replay_recorded : abs_id * abs_id * abs_id;
  replay_resolved_left : abs_id;
  replay_resolved_right : abs_id;
  replay_normalized_left : abs_id;
  replay_normalized_right : abs_id;
  replay_normalization_begin : int;
  replay_normalization_end : int;
  replay_case : string;
  replay_result : abs_id option;
  replay_map_before : abs_id AbsId.Map.t;
  replay_map_after : abs_id AbsId.Map.t;
  replay_before : eval_ctx;
  replay_after : eval_ctx;
}
and replay_diagnostics = {
  replay_native : InterpAbs.merge_diagnostics;
  mutable replay_count : int;
  replay_records : replay_diagnostic option array;
}

(** Attempts to eliminate remaining markers over shared borrows.

    We can eliminate a marker over a shared borrow if the corresponding loan in
    the context doesn't have markers. The reason is that we are always allowed
    to introduce a shared borrow for an existing shared loan: in order to remove
    the marker, we can introduce a shared borrow in the other environment.

    For instance, the following is legal:
    {[
      x -> SL l v
      abs { |SB l| } // the left environment has a borrow, but not the right one

        ~>

      x -> SL l v
      abs { SB l } // introduce SB l in the right environment and add it to the abstraction
    ]}

    Note that we do the same for symbolic values: if a symbolic projection only
    projects shared borrows and there exists the corresponding loan projector,
    then we eliminate the marker. *)
let eliminate_shared_borrow_markers (span : Meta.span)
    (shared_borrows_seq :
      (abs_id * int * proj_marker * borrow_or_proj * ty) list ref option)
    (ctx : eval_ctx) : eval_ctx =
  (* Reconcile real complementary observations before lender-based marker
     elimination. The shared copies remain distinct borrowers. *)
  let ctx =
    ctx_map_abs
      (fun abs ->
        let avalues = reconcile_shared_borrow_groups abs.avalues in
        if avalues == abs.avalues then abs else { abs with avalues })
      ctx
  in
  (* Compute the set of loans without markers *)
  let non_marked_loans, non_marked_loan_projs =
    get_non_marked_shared_loans span ctx
  in
  (* A shared reborrow of a part of a symbolic value can be introduced as soon
     as unmarked loan projectors cover this part: e.g., the region abstraction
     of an indexing call in a loop body, which reborrows the component
     [&'b u32] of the elements [(&'a u32, &'b u32)] of a shared slice whose
     loan projector covers both components. *)
  let loan_projs_cover (nproj : norm_symb_proj) : bool =
    NormSymbProj.Set.mem nproj non_marked_loan_projs
    ||
    let coverage =
      NormSymbProj.Set.fold
        (fun (loan : norm_symb_proj) coverage ->
          if loan.sv_id <> nproj.sv_id then coverage
          else
            match coverage with
            | None -> Some loan.norm_proj_ty
            | Some previous ->
                Some (norm_proj_tys_union span ctx previous loan.norm_proj_ty))
        non_marked_loan_projs None
    in
    match coverage with
    | None -> false
    | Some coverage ->
        norm_proj_ty_contains span ctx coverage nproj.norm_proj_ty
  in
  let shared_proj_is_available regions asb =
    List.for_all
      (function
        | AsbBorrow (bid, _) -> BorrowId.Set.mem bid non_marked_loans
        | AsbProjReborrows proj ->
            loan_projs_cover (normalize_symbolic_proj ctx.type_ctx.type_infos regions proj))
      asb
  in
  (* Endpoint snapshots follow marker changes without registering borrowers or
     copies. Their original types, masks, paths, and allocated IDs remain intact. *)
  let clear_shared_marker regions value =
    match value with
    | ABorrow (ASharedBorrow (pm, bid, sid)) ->
        let pm =
          if pm <> PNone && BorrowId.Set.mem bid non_marked_loans then PNone
          else pm
        in
        ABorrow (ASharedBorrow (pm, bid, sid))
    | ABorrow (AProjSharedBorrow (pm, asb)) ->
        let pm =
          if pm <> PNone && shared_proj_is_available regions asb then PNone
          else pm
        in
        ABorrow (AProjSharedBorrow (pm, asb))
    | ASymbolic (pm, AProjBorrows { proj; loans = [] }) ->
        let pm =
          if
            pm <> PNone
            && NormSymbProj.Set.mem
                 (normalize_symbolic_proj ctx.type_ctx.type_infos regions proj)
                 non_marked_loan_projs
          then PNone
          else pm
        in
        ASymbolic (pm, AProjBorrows { proj; loans = [] })
    | _ -> value
  in
  let endpoint_markers =
    object (self)
      inherit [_] map_env as super
      method! visit_ty _ ty = ty
      method! visit_symbolic_pending_slot _ slot = slot

      method! visit_avalue regions value =
        clear_shared_marker regions (super#visit_avalue regions value)

      method! visit_ECallEndpoints regions witnesses body =
        ECallEndpoints
          ( map_call_endpoint_witnesses self regions witnesses,
            self#visit_tevalue regions body )
    end
  in
  (* A shared input can consist of an already common input plus a self-fed
     loan. Cancel that identity only with exact disjoint coverage, including
     when replaying the collapse after projecting away branch markers. *)
  let eliminate_shared_identities (abs : abs) : abs =
    if not abs.can_end then abs
    else
      let discharged = ref MarkedNormSymbProj.Set.empty in
      List.iter
        (fun (av : tavalue) ->
          match av.value with
          | ASymbolic (pm, AProjBorrows { proj; loans = [] })
            when not (ty_has_mut_borrows ctx.type_ctx.type_infos proj.proj_ty)
            ->
              let mask = normalize_proj_ty ctx.type_ctx.type_infos abs.regions.owned proj.proj_ty in
              let coverage, has_input, has_loan =
                List.fold_left
                  (fun ((coverage, has_input, has_loan) as acc)
                       (other : tavalue) ->
                    let candidate =
                      if other == av then None
                      else
                        match other.value with
                        | ASymbolic (PNone, AProjBorrows { proj; loans = [] })
                          -> Some (proj, true)
                        | ASymbolic
                            ( loan_pm,
                              AProjLoans { proj; consumed = []; borrows = [] }
                            )
                          when loan_pm = pm -> Some (proj, false)
                        | _ -> None
                    in
                    match candidate with
                    | Some (other, input) when other.sv_id = proj.sv_id -> (
                        let other_mask =
                          normalize_proj_ty ctx.type_ctx.type_infos abs.regions.owned other.proj_ty
                        in
                        if
                          (not (norm_proj_ty_contains span ctx mask other_mask))
                          || not
                               (norm_proj_tys_intersect span ctx other_mask
                                  other_mask)
                        then acc
                        else
                          let combined =
                            match coverage with
                            | None -> Some other_mask
                            | Some previous ->
                                if
                                  norm_proj_tys_intersect span ctx previous
                                    other_mask
                                then None
                                else
                                  Some
                                    (norm_proj_tys_union span ctx previous
                                       other_mask)
                          in
                          match combined with
                          | None -> acc
                          | Some combined ->
                              ( Some combined,
                                has_input || input,
                                has_loan || not input ))
                    | _ -> acc)
                  (None, false, false) abs.avalues
              in
              if coverage = Some mask && has_input && has_loan then
                discharged :=
                  MarkedNormSymbProj.Set.add
                    { pm; sv_id = proj.sv_id; norm_proj_ty = mask }
                    !discharged
          | _ -> ())
        abs.avalues;
      if MarkedNormSymbProj.Set.is_empty !discharged then abs
      else
        let was_discharged pm sv_id proj_ty =
          MarkedNormSymbProj.Set.mem
            {
              pm;
              sv_id;
              norm_proj_ty = normalize_proj_ty ctx.type_ctx.type_infos abs.regions.owned proj_ty;
            }
            !discharged
        in
        let avalues =
          List.map
            (fun (av : tavalue) ->
              match av.value with
              | ASymbolic (pm, AProjBorrows { proj; loans = [] })
                when was_discharged pm proj.sv_id proj.proj_ty ->
                  mk_aignored span ctx.type_ctx.type_infos av.ty None
              | _ -> av)
            abs.avalues
        in
        let cont =
          Option.map
            (fun (cont : abs_cont) ->
              let update =
                object
                  inherit [_] map_eval_ctx_with_abs_levels
                  method incr_level level = level + 1

                  method! visit_ESymbolic level pm eproj =
                    match eproj with
                    | EProjBorrows { proj; loans = [] }
                      when level = 0
                           && was_discharged pm proj.sv_id proj.proj_ty ->
                        EIgnored
                    | _ -> ESymbolic (pm, eproj)
                end
              in
              {
                cont with
                output = Option.map (update#visit_tevalue 0) cont.output;
              })
            abs.cont
        in
        { abs with avalues; cont }
  in

  (* A call can ignore a shared backward output while a drop/identity retains
     its projector. Merging their live borrows then removes both branch
     markers, but continuation composition sees only the identity's marker.
     Extend that shared observation only when the same live borrower is
     unmarked at the same level and its entire mask has an unmarked lender.
     Mutable values and projector histories cannot be copied this way. *)
  let update_shared_outputs (abs : abs) : abs =
    let call_scopes =
      List.map
        (map_call_scope endpoint_markers abs.regions.owned)
        abs.call_scopes
    in
(*
```ocaml
*)
    let abs = { abs with call_scopes } in
(*
```
*)
    match abs.cont with
    | None -> abs
    | Some cont ->
        let input =
          Option.map
            (endpoint_markers#visit_tevalue abs.regions.owned) cont.input
        in
        let cont = { cont with input } in
        let abs = { abs with cont = Some cont } in
        let borrows = ref NormSymbProjMap.empty in
        let collect =
          object
            inherit [_] iter_tavalue_with_levels
            method incr_level level = level + 1

            method! visit_ASymbolic level pm aproj =
              match (pm, aproj) with
              | PNone, AProjBorrows { proj; loans = [] }
                when not
                       (ty_has_mut_borrows ctx.type_ctx.type_infos proj.proj_ty)
                ->
                  let key = normalize_symbolic_proj ctx.type_ctx.type_infos abs.regions.owned proj in
                  if NormSymbProj.Set.mem key non_marked_loan_projs then
                    borrows :=
                      NormSymbProjMap.update key
                        (fun levels ->
                          Some
                            (AbsLevelSet.add level
                               (Option.value levels ~default:AbsLevelSet.empty)))
                        !borrows
              | _ -> ()
          end
        in
        List.iter (collect#visit_tavalue 0) abs.avalues;
        if NormSymbProjMap.is_empty !borrows then abs
        else
          let update =
            object
              inherit [_] map_eval_ctx_with_abs_levels
              method incr_level level = level + 1

              method! visit_ESymbolic level pm eproj =
                let pm =
                  match eproj with
                  | EProjBorrows { proj; loans = [] } when pm <> PNone ->
                      let key : norm_symb_proj =
                        {
                          sv_id = proj.sv_id;
                          norm_proj_ty =
                            normalize_proj_ty ctx.type_ctx.type_infos abs.regions.owned proj.proj_ty;
                        }
                      in
                      begin
                        match NormSymbProjMap.find_opt key !borrows with
                        | Some levels when AbsLevelSet.mem level levels -> PNone
                        | _ -> pm
                      end
                  | _ -> pm
                in
                ESymbolic (pm, eproj)
            end
          in
          let output = Option.map (update#visit_tevalue 0) cont.output in
          { abs with cont = Some { cont with output } }
  in
  [%ldebug
    "- non_marked_loans: "
    ^ BorrowId.Set.to_string None non_marked_loans
    ^ "\n- non_marked_loan_projs: "
    ^ NormSymbProj.Set.with_ctx_to_string None ctx non_marked_loan_projs];

  match shared_borrows_seq with
  | None ->
      let update_borrows =
        object
          inherit [_] map_eval_ctx as super

          method! visit_avalue regions value =
            clear_shared_marker regions (super#visit_avalue regions value)

          method! visit_abs _ abs =
            eliminate_shared_identities
              (update_shared_outputs (super#visit_abs abs.regions.owned abs))
        end
      in
      update_borrows#visit_eval_ctx RegionId.Set.empty ctx
  | Some shared_borrows ->
      (* Record copies at the surrounding top-level slot even when the borrow
         is nested: a shared borrow can be introduced independently of the
         aggregate containing the original borrow. *)
      let update_avalue (regions : RegionId.Set.t) (offset : int ref)
          (aid : abs_id) (i : int) (av : tavalue) : tavalue =
        match av.value with
        | ABorrow (ASharedBorrow (pm, bid, sid)) ->
            let pm =
              if pm <> PNone && BorrowId.Set.mem bid non_marked_loans then (
                (* Register the fact that we need to introduce a new shared borrow *)
                let pm' =
                  match pm with
                  | PNone -> [%internal_error] span
                  | PLeft -> PRight
                  | PRight -> PLeft
                in
                let _, ty, _ = ty_get_ref av.ty in
                shared_borrows :=
                  (aid, i + !offset, pm', Borrow bid, ty) :: !shared_borrows;
                offset := !offset + 1;
                PNone)
              else pm
            in
            { av with value = ABorrow (ASharedBorrow (pm, bid, sid)) }
        | ABorrow (AProjSharedBorrow (pm, asb)) ->
            if pm <> PNone && shared_proj_is_available regions asb then (
              let other = if pm = PLeft then PRight else PLeft in
              shared_borrows :=
                (aid, i + !offset, other, SharedProj (regions, asb), av.ty)
                :: !shared_borrows;
              offset := !offset + 1;
              { av with value = ABorrow (AProjSharedBorrow (PNone, asb)) })
            else av
        | ASymbolic (pm, AProjBorrows { proj; loans = [] }) ->
            [%ldebug "Found symbolic borrow proj:\n" ^ tavalue_to_string ctx av];
            let pm =
              let nproj = normalize_symbolic_proj ctx.type_ctx.type_infos regions proj in
              if pm <> PNone && NormSymbProj.Set.mem nproj non_marked_loan_projs
              then (
                (* Register the fact that we need to introduce a new shared borrow *)
                let pm' =
                  match pm with
                  | PNone -> [%internal_error] span
                  | PLeft -> PRight
                  | PRight -> PLeft
                in
                shared_borrows :=
                  (aid, i + !offset, pm', Proj (regions, proj), av.ty)
                  :: !shared_borrows;
                offset := !offset + 1;
                PNone)
              else pm
            in
            {
              av with
              value = ASymbolic (pm, AProjBorrows { proj; loans = [] });
            }
        | _ -> av
      in
      let update_borrows =
        object
          inherit [_] map_eval_ctx

          method! visit_abs _ abs =
            let offset = ref 0 in
            let abs =
              {
                abs with
                avalues =
                  List.mapi
                    (fun i av ->
                      let visitor =
                        object
                          inherit [_] map_tavalue as super

                          method! visit_tavalue () av =
                            let av = super#visit_tavalue () av in
                            update_avalue abs.regions.owned offset abs.abs_id i
                              av
                        end
                      in
                      visitor#visit_tavalue () av)
                    abs.avalues;
              }
            in
            eliminate_shared_identities (update_shared_outputs abs)
        end
      in
      update_borrows#visit_eval_ctx RegionId.Set.empty ctx

(** Eliminate the markers of ended loans/borrows

    TODO: the projection markers should be placed in aproj/eproj rather than
    ASymbolic/ESymbolic *)
let eliminate_ended_markers (_span : Meta.span) (ctx : eval_ctx) : eval_ctx =
  (* We also remove the markers from the ended loans/borrows in the evalues *)
  let update_abs (abs : abs) : abs =
    let visitor =
      object (self)
        inherit [_] map_abs as super
        method! visit_ty _ ty = ty
        method! visit_symbolic_pending_slot _ slot = slot

        method! visit_ECallEndpoints env witnesses body =
          ECallEndpoints
            ( map_call_endpoint_witnesses self env witnesses,
              self#visit_tevalue env body )

        method! visit_ASymbolic env pm proj =
          match proj with
          | AEndedProjLoans { proj = _; consumed; borrows }
            when List.for_all
                   (fun (_, proj) -> proj = AEmpty)
                   (consumed @ borrows) -> super#visit_ASymbolic env PNone proj
          | AEndedProjBorrows { mvalues = _; loans }
            when List.for_all (fun (_, proj) -> proj = AEmpty) loans ->
              super#visit_ASymbolic env PNone proj
          | _ -> super#visit_ASymbolic env pm proj

        method! visit_ESymbolic env pm proj =
          match proj with
          | EEndedProjLoans { proj = _; consumed; borrows }
            when List.for_all
                   (fun (_, proj) -> proj = EEmpty)
                   (consumed @ borrows) -> super#visit_ESymbolic env PNone proj
          | EEndedProjBorrows { mvalues = _; loans }
            when List.for_all (fun (_, proj) -> proj = EEmpty) loans ->
              super#visit_ESymbolic env PNone proj
          | _ -> super#visit_ESymbolic env pm proj
      end
    in
    let cont = Option.map (visitor#visit_abs_cont ()) abs.cont in
    let call_scopes =
      List.map (map_call_scope visitor ()) abs.call_scopes
    in
(*
```ocaml
*)
    { abs with cont; call_scopes }
(*
```
*)
  in
  let ctx = ctx_map_abs update_abs ctx in

  (* *)
  ctx

(** A collapse merges the marked loans of the two branches of an abstraction
    into one unmarked loan. The continuation of one branch can read the value
    given back to such a loan while the continuation of the other branch does
    not read it: e.g., the join abstraction of a nested region of a shared
    reborrow [&'1 S<'0>] where [S] has a field [&'0 mut T] (its continuation
    passes the loan to the join), and the abstraction of the same region in a
    branch, converted from a dummy value (its continuation reads nothing,
    because the abstraction gives nothing back). The loan, and thus the value
    given back to it, exists in both branches: the read keeps the marker of its
    branch only because no read of the other branch could pair with it. Remove
    the marker of the reads of the loans which the abstraction holds without
    marker. The reads under [EJoinMarkers] keep theirs: a projection selects
    one side of it. *)
let eliminate_held_loan_cont_markers (ctx : eval_ctx) : eval_ctx =
  let update_abs (abs : abs) : abs =
        let loans = ref BorrowId.Set.empty in
        let loan_projs = ref NormSymbProj.Set.empty in
        (*
```ocaml
        *)
        let ignored_loans = ref [] in
        let collect =
          object
            inherit [_] iter_tavalue as super
            method! visit_tavalue env (value : tavalue) =
              (match value.value with
              | ALoan (AIgnoredMutLoan (PNone, Some borrow, _)) ->
                  ignored_loans :=
                    (borrow, normalize_proj_ty ctx.type_ctx.type_infos
                      abs.regions.owned value.ty) :: !ignored_loans
              | _ -> ());
              super#visit_tavalue env value
            method! visit_AMutLoan env pm bid child =
              if pm = PNone then loans := BorrowId.Set.add bid !loans;
              super#visit_AMutLoan env pm bid child
            method! visit_ASymbolic env pm projector =
              (match pm, projector with
              | PNone, AProjLoans { proj; _ } ->
                  loan_projs := NormSymbProj.Set.add
                    (normalize_symbolic_proj ctx.type_ctx.type_infos
                      abs.regions.owned proj) !loan_projs
              | _ -> ());
              super#visit_ASymbolic env pm projector
          end
        in
        List.iter (collect#visit_tavalue ()) abs.avalues;
        (*
```
        *)
        let held_proj sv_id proj_ty =
          NormSymbProj.Set.mem
            (normalize_symbolic_proj ctx.type_ctx.type_infos abs.regions.owned { sv_id; proj_ty })
            !loan_projs
        in
        (*
```ocaml
        *)
        let held_ignored borrow ty =
          List.mem
            (borrow, normalize_proj_ty ctx.type_ctx.type_infos
              abs.regions.owned ty) !ignored_loans
        in
        (*
```
        *)
        let visitor =
          object (self)
            inherit [_] map_abs as super
            method! visit_ty _ ty = ty
            method! visit_symbolic_pending_slot _ slot = slot
            (*
```ocaml
            *)
            method! visit_tevalue env (value : tevalue) =
              let value =
                match value.value with
                | ELoan (EIgnoredMutLoan (pm, Some borrow, child))
                  when pm <> PNone && held_ignored borrow value.ty ->
                    { value with value =
                        ELoan (EIgnoredMutLoan (PNone, Some borrow, child)) }
                | _ -> value
              in
              super#visit_tevalue env value
            method! visit_tavalue env (value : tavalue) =
              let value =
                match value.value with
                | ALoan (AIgnoredMutLoan (pm, Some borrow, child))
                  when pm <> PNone && held_ignored borrow value.ty ->
                    { value with value =
                        ALoan (AIgnoredMutLoan (PNone, Some borrow, child)) }
                | _ -> value
              in
              super#visit_tavalue env value
            (*
```
            *)

            method! visit_ECallEndpoints env witnesses body =
              ECallEndpoints
                ( map_call_endpoint_witnesses self env witnesses,
                  self#visit_tevalue env body )

            method! visit_AMutLoan env pm bid child =
              let pm =
                if pm <> PNone && BorrowId.Set.mem bid !loans then PNone else pm
              in
              super#visit_AMutLoan env pm bid child

            method! visit_ASymbolic env pm proj =
              match proj with
              | AProjLoans { proj = source; _ }
                when pm <> PNone && held_proj source.sv_id source.proj_ty ->
                  super#visit_ASymbolic env PNone proj
              | _ -> super#visit_ASymbolic env pm proj
            method! visit_EJoinMarkers _ left right = EJoinMarkers (left, right)

            method! visit_EMutLoan env pm bid child =
              let pm =
                if pm <> PNone && BorrowId.Set.mem bid !loans then PNone else pm
              in
              super#visit_EMutLoan env pm bid child

            method! visit_ESymbolic env pm proj =
              match proj with
              | EProjLoans { proj = eproj; _ }
                when pm <> PNone && held_proj eproj.sv_id eproj.proj_ty ->
                  super#visit_ESymbolic env PNone proj
              | _ -> super#visit_ESymbolic env pm proj
          end
        in
        let cont =
          Option.map
            (fun cont ->
              { cont with
                input = Option.map (visitor#visit_tevalue ()) cont.input })
            abs.cont
        in
        let call_scopes =
          List.map (map_call_scope visitor ()) abs.call_scopes
        in
(*
```ocaml
*)
        { abs with cont; call_scopes }
(*
```
*)
  in
  ctx_map_abs update_abs ctx

(** Utility.

    An environment augmented with information about its
    borrows/loans/abstractions for the purpose of merging abstractions together.
    We provide functions to update this information when merging two
    abstractions together. We use it in {!reduce_ctx} and {!collapse_ctx}. *)
type ctx_with_info = { ctx : eval_ctx; info : abs_borrows_loans_maps }

let ctx_with_info_merge_into_first_abs (span : Meta.span) (abs_kind : abs_kind)
    ?diagnostic
    ~(can_end : bool) ~(with_abs_conts : bool)
    (merge_funs : merge_duplicates_funcs option) (ctx : ctx_with_info)
    (abs_id0 : AbsId.id) (abs_id1 : AbsId.id) : ctx_with_info * abs_id =
  [%ldebug
    "Merging abstraction " ^ AbsId.to_string abs_id1 ^ " into abstraction "
    ^ AbsId.to_string abs_id0];
  (* Compute the new context and the new abstraction id *)
  let nctx, nabs_id =
    merge_into_first_abstraction span abs_kind ?diagnostic ~can_end ~with_abs_conts
      merge_funs ctx.ctx abs_id0 abs_id1
  in
  (* A merge can introduce owners or rewrite region projections in existing
     neighbors. Updating only the merged abstraction is valid only when every
     other ownership index and exploration predicate stayed unchanged. Rebuild
     otherwise, preserving the original exploration boundary. *)
  let previous_abs = ctx_get_abs ctx.ctx in
  let is_new_abs id = not (AbsId.Map.mem id previous_abs) in
  let has_other_ownership_changes =
    List.exists
      (function
        | EAbs abs when abs.abs_id <> nabs_id -> (
            match AbsId.Map.find_opt abs.abs_id previous_abs with
            | None -> true
            | Some previous ->
                abs.can_end <> previous.can_end
                || abs.kind <> previous.kind
                || (not
                      (RegionId.Set.equal abs.regions.owned
                         previous.regions.owned))
                || abs.avalues <> previous.avalues)
        | _ -> false)
      nctx.env
  in
  if abs_id0 = abs_id1 || has_other_ownership_changes then
    let explored = AbsId.Set.of_list ctx.info.abs_ids in
    let explore (abs : abs) =
      abs.can_end
      && (match abs.kind with
         | SynthInput _ -> false
         | _ -> true)
      && (abs.abs_id = nabs_id
         || AbsId.Set.mem abs.abs_id explored
         || is_new_abs abs.abs_id)
    in
    let info = compute_abs_borrows_loans_maps span explore nctx nctx.env in
    ({ ctx = nctx; info }, nabs_id)
  else
    let nabs = ctx_lookup_abs nctx nabs_id in
    [%ldebug
      "abstraction resulting from the merge:\n"
      ^ abs_to_string span ctx.ctx nabs];
    (* Update the information *)
    (* We start by computing the maps for an environment which only contains
     the new region abstraction *)
    let {
      abs_to_borrows = nabs_to_borrows;
      abs_to_non_unique_borrows = nabs_to_non_unique_borrows;
      abs_to_loans = nabs_to_loans;
      borrow_to_abs = borrow_to_nabs;
      non_unique_borrow_to_abs = non_unique_borrow_to_nabs;
      loan_to_abs = loan_to_nabs;
      abs_to_borrow_projs = nabs_to_borrow_projs;
      abs_to_loan_projs = nabs_to_loan_projs;
      borrow_proj_to_abs = borrow_proj_to_nabs;
      loan_proj_to_abs = loan_proj_to_nabs;
      _;
    } =
      compute_abs_borrows_loans_maps span (fun _ -> true) nctx [ EAbs nabs ]
    in
    (* Retrieve the previous maps, so that we can update them *)
    let {
      abs_ids;
      abs_to_borrows;
      abs_to_non_unique_borrows;
      abs_to_loans;
      borrow_to_abs;
      non_unique_borrow_to_abs;
      loan_to_abs;
      abs_to_borrow_projs;
      abs_to_loan_projs;
      borrow_proj_to_abs;
      loan_proj_to_abs;
    } =
      ctx.info
    in
    let abs_ids =
      List.filter_map
        (fun id ->
          if id = abs_id0 then Some nabs_id
          else if id = abs_id1 then None
          else Some id)
        abs_ids
    in
    (* Update the various maps.

     We use a functor for the maps from marked borrows/loans or symbolic value
     projections to symbolic abstractions, because we have to manipulate maps and
     sets over different types (borrow/loan ids and symbolic value projections).
  *)
    let module UpdateToAbs
        (M : Collections.Map)
        (S : Collections.Set with type elt = M.key) =
    struct
      (* Update a map from marked borrows/loans or symbolic value projections
       to region abstractions by using the old map and the information computed
       from the merged abstraction. *)
      let update_to_abs ~(to_abs_inj : bool) (key_to_string : M.key -> string)
          (abs_to : S.t AbsId.Map.t) (to_nabs : AbsId.Set.t M.t)
          (to_abs : AbsId.Set.t M.t) : AbsId.Set.t M.t =
        (* Remove the old bindings from borrow/loan ids to the two region
         abstractions we just merged (because those two region abstractions
         do not exist anymore). *)
        let abs0_elems = AbsId.Map.find abs_id0 abs_to in
        let abs1_elems = AbsId.Map.find abs_id1 abs_to in
        let abs01_elems = S.union abs0_elems abs1_elems in
        (* Remove the to_abs mapping if to_abs is injective *)
        let to_abs =
          if to_abs_inj then
            M.filter (fun id _ -> not (S.mem id abs01_elems)) to_abs
          else to_abs
        in
        (* Add the new bindings from the borrows/loan ids that we find in the
         merged abstraction to this abstraction's id *)
        let merge (key : M.key) (abs0 : AbsId.Set.t) (abs1 : AbsId.Set.t) =
          (* We shouldn't see the same key twice if the [to_abs] map is injective *)
          if to_abs_inj then
            [%craise] span
              ("Unreachable:\n key: " ^ key_to_string key ^ "\n- abs0: "
              ^ AbsId.Set.to_string None abs0
              ^ "\n- abs1: "
              ^ AbsId.Set.to_string None abs1)
          else Some (AbsId.Set.union abs0 abs1)
        in
        let to_abs = M.union merge to_nabs to_abs in
        (* Filter to remove the old abstraction ids *)
        M.filter_map
          (fun _ s ->
            let s =
              AbsId.Set.filter
                (fun (id : abs_id) -> id <> abs_id0 && id <> abs_id1)
                s
            in
            if AbsId.Set.is_empty s then None else Some s)
          to_abs
    end in
    let module UpdateMarkedBorrowId =
      UpdateToAbs (MarkedBorrowId.Map) (MarkedBorrowId.Set)
    in
    let module UpdateMarkedUniqueBorrowId =
      UpdateToAbs (MarkedUniqueBorrowId.Map) (MarkedUniqueBorrowId.Set)
    in
    let module UpdateMarkedLoanId =
      UpdateToAbs (MarkedLoanId.Map) (MarkedLoanId.Set)
    in
    let marked_unique_borrow_id_to_string
        ((pm, bid, sid) : marked_unique_borrow_id) : string =
      let s =
        match sid with
        | None -> "MB@" ^ show_borrow_id bid
        | Some sid ->
            "SB@" ^ show_borrow_id bid ^ "(^" ^ show_shared_borrow_id sid ^ ")"
      in
      Print.Values.add_proj_marker pm s
    in
    let borrow_to_abs =
      UpdateMarkedUniqueBorrowId.update_to_abs ~to_abs_inj:true
        marked_unique_borrow_id_to_string abs_to_borrows borrow_to_nabs
        borrow_to_abs
    in
    let non_unique_borrow_to_abs =
      UpdateMarkedBorrowId.update_to_abs ~to_abs_inj:false show_marked_borrow_id
        abs_to_non_unique_borrows non_unique_borrow_to_nabs
        non_unique_borrow_to_abs
    in
    let loan_to_abs =
      UpdateMarkedLoanId.update_to_abs ~to_abs_inj:true show_marked_borrow_id
        abs_to_loans loan_to_nabs loan_to_abs
    in
    let module UpdateSymbProj =
      UpdateToAbs (MarkedNormSymbProj.Map) (MarkedNormSymbProj.Set)
    in
    let borrow_proj_to_abs =
      UpdateSymbProj.update_to_abs ~to_abs_inj:false show_marked_norm_symb_proj
        abs_to_borrow_projs borrow_proj_to_nabs borrow_proj_to_abs
    in
    let loan_proj_to_abs =
      UpdateSymbProj.update_to_abs ~to_abs_inj:false show_marked_norm_symb_proj
        abs_to_loan_projs loan_proj_to_nabs loan_proj_to_abs
    in

    (* Update the maps from abstractions to marked borrows/loans or
     symbolic value projections.
  *)
    let update_abs_to nabs_to abs_to =
      (* Remove the two region abstractions we merged *)
      let m = AbsId.Map.remove abs_id0 (AbsId.Map.remove abs_id1 abs_to) in
      (* Add the merged abstraction *)
      AbsId.Map.add_strict nabs_id (AbsId.Map.find nabs_id nabs_to) m
    in
    let abs_to_borrows = update_abs_to nabs_to_borrows abs_to_borrows in
    let abs_to_non_unique_borrows =
      update_abs_to nabs_to_non_unique_borrows abs_to_non_unique_borrows
    in
    let abs_to_loans = update_abs_to nabs_to_loans abs_to_loans in
    let abs_to_borrow_projs =
      update_abs_to nabs_to_borrow_projs abs_to_borrow_projs
    in
    let abs_to_loan_projs =
      update_abs_to nabs_to_loan_projs abs_to_loan_projs
    in
    let info =
      {
        abs_ids;
        abs_to_borrows;
        abs_to_non_unique_borrows;
        abs_to_loans;
        borrow_to_abs;
        non_unique_borrow_to_abs;
        loan_to_abs;
        borrow_proj_to_abs;
        loan_proj_to_abs;
        abs_to_borrow_projs;
        abs_to_loan_projs;
      }
    in
    ({ ctx = nctx; info }, nabs_id)

exception AbsToMerge of abs_id * abs_id

(** Repeatedly iterate through the borrows/loans in an environment and merge the
    abstractions that have to be merged according to a user-provided policy.

    [sequence]: we save the sequence of merges there, in reverse order (the last
    merges are pushed at the front). *)
let repeat_iter_borrows_merge (span : Meta.span) (fixed_abs_ids : AbsId.Set.t)
    (abs_kind : abs_kind) ~(can_end : bool) ~(with_abs_conts : bool)
    (sequence : (abs_id * abs_id * abs_id) list ref option)
    (merge_funs : merge_duplicates_funcs option)
    (iter : ctx_with_info -> ('a -> unit) -> unit)
    (policy : ctx_with_info -> 'a -> (abs_id * abs_id) option)
    ?(merge_count : int ref option = None) ?diagnostic ?diagnostic_selection
    (ctx : eval_ctx) : eval_ctx =
  (match diagnostic with None -> () | Some capture -> capture.trace_fixed <- Some fixed_abs_ids);
  (* Compute the information *)
  let to_ctx_with_info (ctx : eval_ctx) : ctx_with_info =
    let is_fresh_abs_id (id : AbsId.id) : bool =
      not (AbsId.Set.mem id fixed_abs_ids)
    in
    let explore (abs : abs) =
      is_fresh_abs_id abs.abs_id && abs.can_end
      &&
      match abs.kind with
      | SynthInput _ -> false
      | _ -> true
    in
    let info = compute_abs_borrows_loans_maps span explore ctx ctx.env in
    { ctx; info }
  in
  let ctx = to_ctx_with_info ctx in
  let count_markers (ctx : eval_ctx) aid =
    let count = ref 0 in
    let visitor =
      object
        inherit [_] iter_tavalue
        method! visit_proj_marker _ pm = if pm <> PNone then incr count
      end
    in
    List.iter (visitor#visit_tavalue ()) (ctx_lookup_abs ctx aid).avalues;
    !count
  in
  (* Explore and merge *)
  let rec explore_merge (ctx : ctx_with_info) : eval_ctx =
    let ctx0 = ctx in
    try
      iter ctx (fun x ->
          (* Check if we need to merge some abstractions *)
          match policy ctx x with
          | None -> (* No *) ()
          | Some (abs_id0, abs_id1) ->
              (* Yes: raise an exception *)
              raise (AbsToMerge (abs_id0, abs_id1)));
      (* No exception raise: return the current context *)
      ctx.ctx
    with AbsToMerge (abs_id0, abs_id1) ->
      (* Merge and recurse *)
      let ctx, naid =
        ctx_with_info_merge_into_first_abs span abs_kind ?diagnostic ~can_end
          ~with_abs_conts merge_funs ctx abs_id0 abs_id1
      in
      (match diagnostic, diagnostic_selection with
      | Some capture, Some selected ->
          (try
             let index = capture.trace_count - 1 in
             if index >= 0 then
               match capture.trace_records.(index mod 128) with
               | Some entry when entry.merge_result = naid
                   && entry.merge_left.abs_id = abs_id0
                   && entry.merge_right.abs_id = abs_id1 ->
                   entry.merge_selection <- selected ()
               | _ -> ()
           with _ -> ())
      | _ -> ());
      if abs_id0 = abs_id1 then
        [%cassert] span
          (count_markers ctx.ctx naid < count_markers ctx0.ctx abs_id0)
          ("Self-collapse must strictly decrease marked ownership:\n"
          ^ abs_to_string span ctx0.ctx (ctx_lookup_abs ctx0.ctx abs_id0)
          ^ "\nAfter self-collapse:\n"
          ^ abs_to_string span ctx.ctx (ctx_lookup_abs ctx.ctx naid));
      (* Sanity check: the information was properly updated *)
      if !Config.sanity_checks then
        (let info = ctx.info in
         let info' = (to_ctx_with_info ctx.ctx).info in

         let print_msg (field : string) =
           [%ltrace
             "Invalid incremental update of the context information: field '"
             ^ field ^ "':" ^ "\n- incremental computation:\n"
             ^ abs_borrows_loans_maps_to_string ctx.ctx info
             ^ "\n\n- reference computation:\n"
             ^ abs_borrows_loans_maps_to_string ctx.ctx info'
             ^ "\n\n- initial context:\n"
             ^ eval_ctx_to_string ctx0.ctx
             ^ "\n\n- new context:\n" ^ eval_ctx_to_string ctx.ctx];
           [%internal_error] span
         in
         let check (b : bool) (field : string) =
           if not b then print_msg field
         in
         check (info.abs_ids = info'.abs_ids) "abs_ids";
         check
           (AbsId.Map.equal MarkedUniqueBorrowId.Set.equal info.abs_to_borrows
              info'.abs_to_borrows)
           "abs_to_borrows";
         check
           (AbsId.Map.equal MarkedBorrowId.Set.equal
              info.abs_to_non_unique_borrows info'.abs_to_non_unique_borrows)
           "abs_to_non_unique_borrows";
         check
           (AbsId.Map.equal MarkedLoanId.Set.equal info.abs_to_loans
              info'.abs_to_loans)
           "abs_to_loans";
         check
           (MarkedUniqueBorrowId.Map.equal AbsId.Set.equal info.borrow_to_abs
              info'.borrow_to_abs)
           "borrow_to_abs";
         check
           (MarkedBorrowId.Map.equal AbsId.Set.equal
              info.non_unique_borrow_to_abs info'.non_unique_borrow_to_abs)
           "non_unique_borrow_to_abs";
         check
           (MarkedLoanId.Map.equal AbsId.Set.equal info.loan_to_abs
              info'.loan_to_abs)
           "loan_to_abs";
         check
           (AbsId.Map.equal MarkedNormSymbProj.Set.equal
              info.abs_to_borrow_projs info'.abs_to_borrow_projs)
           "abs_to_borrow_projs";
         check
           (AbsId.Map.equal MarkedNormSymbProj.Set.equal info.abs_to_loan_projs
              info'.abs_to_loan_projs)
           "abs_to_loan_projs";
         check
           (MarkedNormSymbProj.Map.equal AbsId.Set.equal info.borrow_proj_to_abs
              info'.borrow_proj_to_abs)
           "borrow_proj_to_abs";
         check
           (MarkedNormSymbProj.Map.equal AbsId.Set.equal info.loan_proj_to_abs
              info'.loan_proj_to_abs))
          "loan_proj_to_abs";
      (* Remember the sequence of merges *)
      Option.iter
        (fun sequence -> sequence := (abs_id0, abs_id1, naid) :: !sequence)
        sequence;
      Option.iter incr merge_count;
      explore_merge ctx
  in
  explore_merge ctx

let convert_fresh_dummy_values_to_abstractions (span : Meta.span)
    (fresh_abs_kind : abs_kind) (fixed_dids : DummyVarId.Set.t)
    (ctx0 : eval_ctx) : eval_ctx =
  (* Debug *)
  [%ltrace
    "- ctx0:\n"
    ^ eval_ctx_to_string ~span:(Some span) ctx0
    ^ "\n\n- fixed_dids: "
    ^ DummyVarId.Set.to_string None fixed_dids];

  let can_end = true in
  let is_fresh_did (id : DummyVarId.id) : bool =
    not (DummyVarId.Set.mem id fixed_dids)
  in

  let ctx = ctx0 in
  (* Convert the dummy values to abstractions (note that when we convert
     values to abstractions, the resulting abstraction should be destructured) *)
  (* Note that we preserve the order of the dummy values: we replace them with
     abstractions in place - this makes matching easier *)
  let metadata_bindings = ref ctx.metadata_bindings in
  let env =
    List.concat
      (List.map
         (fun ee ->
           match ee with
           | EAbs _ | EFrame | EBinding (BVar _, _) -> [ ee ]
           | EBinding (BDummy id, v) ->
               if is_fresh_did id then (
                 let ctx = ctx_with_metadata_bindings ctx !metadata_bindings in
                 let absl, bindings =
                   convert_value_to_abstractions span fresh_abs_kind ~can_end
                     ctx v
                 in
                 let () = metadata_bindings := bindings in
                 let ctx = ctx_with_metadata_bindings ctx bindings in
                 Invariants.opt_type_check_absl span ctx absl;
                 List.map (fun abs -> EAbs abs) absl)
               else [ ee ])
         ctx.env)
  in
  let ctx = { ctx with env } in
  let ctx = ctx_with_metadata_bindings ctx !metadata_bindings in
  [%ltrace
    "after converting values to abstractions:" ^ "\n- ctx:\n"
    ^ eval_ctx_to_string ~span:(Some span) ctx
    ^ "\n"];

  ctx


(** Reduce an environment.

    We do this to simplify an environment, for the purpose of finding a loop
    fixed point (this is our equivalent of Abstract Interpretation's
    **widening** operation).

    We do the following:
    - we look for all the *new* dummy values (we use sets of old ids to decide
      wether a value is new or not) and convert them into abstractions. TODO: we
      don't do this anymore
    - whenever there is a new abstraction in the context, and some of its
      borrows are associated to loans in another new abstraction, we merge them.
      We also do this with loan/borrow projectors over symbolic values. In
      effect, this allows us to merge newly introduced abstractions/borrows with
      their parent abstractions.

    For instance, looking at the [list_nth_mut] example, when evaluating the
    first loop iteration, we start in the following environment:
    {[
      abs@0 { ML l0 }
      ls -> MB l0 (s2 : loops::List<T>)
      i -> s1 : u32
    ]}

    and get the following environment upon reaching the [Continue] statement:
    {[
      abs@0 { ML l0 }
      ls -> MB l4 (s@6 : loops::List<T>)
      i -> s@7 : u32
      _@1 -> MB l0 (loops::List::Cons (ML l1, ML l2))
      _@2 -> MB l2 (@Box (ML l4))                      // tail
      _@3 -> MB l1 (s@3 : T)                           // hd
    ]}

    In this new environment, the dummy variables [_@1], [_@2] and [_@3] are
    considered as new.

    We first convert the new dummy values to abstractions. It gives:
    {[
      abs@0 { ML l0 }
      ls -> MB l4 (s@6 : loops::List<T>)
      i -> s@7 : u32
      abs@1 { MB l0, ML l1, ML l2 }
      abs@2 { MB l2, ML l4 }
      abs@3 { MB l1 }
    ]}

    We finally merge the new abstractions together (abs@1 and abs@2 because of
    l2, and abs@1 and abs@3 because of l1). It gives:
    {[
      abs@0 { ML l0 }
      ls -> MB l4 (s@6 : loops::List<T>)
      i -> s@7 : u32
      abs@4 { MB l0, ML l4 }
    ]}

    - If [merge_funs] is [None], we check that there are no markers in the
      environments. This is the "reduce" operation.
    - If [merge_funs] is [Some _], when merging abstractions together, we merge
      the pairs of borrows and the pairs of loans with the same markers **if
      this marker is not** [PNone]. This is useful to reuse the reduce operation
      to implement the collapse. Note that we ignore borrows/loans with the
      [PNone] marker: the goal of the collapse operation is to *eliminate*
      markers, not to simplify the environment.

    For instance, when merging:
    {[
      abs@0 { ML l0, |MB l1| }
      abs@1 { MB l0, ︙MB l1︙ }
    ]}
    We get:
    {[
      abs@2 { MB l1 }
    ]} *)
let reduce_ctx_with_markers (merge_funs : merge_duplicates_funcs option)
    (sequence : (abs_id * abs_id * abs_id) list ref option)
    ~(with_abs_conts : bool) (span : Meta.span) ?(loop : bool = false)
    (fresh_abs_kind : abs_kind)
    (fixed_abs_ids : AbsId.Set.t) ?(fixed_dids : DummyVarId.Set.t option = None)
    ?(keep_variable_borrows_apart : AbsId.Set.t = AbsId.Set.empty)
    ?(restore_unmerged : AbsId.Set.t = AbsId.Set.empty)
    ?(merge_count : int ref option = None) ?diagnostic (ctx0 : eval_ctx) : eval_ctx =
  (* Debug *)
  [%ltrace "- ctx0:\n" ^ eval_ctx_to_string ~span:(Some span) ctx0];

  let with_markers = merge_funs <> None in
  let can_end = true in

  let ctx = ctx0 in
  (* Convert the fresh dummy values to abstractions, if the caller requests so
     (note that when we convert values to abstractions, the resulting abstraction
     should be destructured) *)
  let ctx =
    match fixed_dids with
    | None -> ctx
    | Some fixed_dids ->
        convert_fresh_dummy_values_to_abstractions span fresh_abs_kind
          fixed_dids ctx
  in
  (* A join and the subsequent match must see the same ownership graph.
     Returned ignored loans carry independent outputs; expose them before
     collecting reduction edges, not only while adding branch markers.
     The abstractions of [restore_unmerged] which this changes are recorded
     with their parts (see below). *)
  let normalized = ref [] in
  let env =
    List.concat_map
      (function
        | EAbs abs
          when abs.can_end && not (AbsId.Set.mem abs.abs_id fixed_abs_ids) ->
            let parts =
              InterpAbs.normalize_abs_for_join
                ~loop_level_outputs:(loop_level_outputs ~loop fresh_abs_kind)
                span ctx abs
            in
            if AbsId.Set.mem abs.abs_id restore_unmerged && parts <> [ abs ]
            then normalized := (abs, parts) :: !normalized;
            List.map (fun abs -> EAbs abs) parts
        | element -> [ element ])
      ctx.env
  in
  let ctx = { ctx with env } in

  (*
```ocaml
  *)
  let selected_policy = Option.map (fun _ -> ref None) diagnostic in
  let diagnostic_selection = Option.map (fun cell () -> !cell) selected_policy in
  let policy_details = Option.map (fun _ -> ref []) diagnostic in
  let observe_bool observations name verdict =
    (match observations with
    | None -> ()
    | Some cell -> (try cell := (name, verdict) :: !cell with _ -> ()));
    verdict
  in
  let print_guards formatter names observed =
    List.iter (fun name -> Format.fprintf formatter "%s=%s@."
        name (match List.assoc_opt name observed with
        | None -> "skipped" | Some value -> string_of_bool value)) names
  in
  let shared_observations_only ctx (abs : abs) =
    abs.call_scopes = []
    && List.for_all
         (fun (av : tavalue) ->
           not (TypesUtils.ty_has_mut_borrow_for_region_in_set
             ctx.type_ctx.type_infos abs.regions.owned av.ty))
         abs.avalues
    &&
    let visitor =
      object
        inherit [_] iter_tavalue
        method! visit_VMutBorrow _ _ _ = raise Found
        method! visit_VMutLoan _ _ = raise Found
        method! visit_AMutBorrow _ _ _ _ = raise Found
        method! visit_AMutLoan _ _ _ _ = raise Found
      end
    in
    try List.iter (visitor#visit_tavalue ()) abs.avalues; true
    with Found -> false
  in
  (*
```
  *)

  (* A retained payload cannot capture a lender whose lifetime is still used
     outside the pair. If every other use is internal, ordinary reduction is
     safe: ending that lender already requires ending this payload holder. *)
  let would_capture_payload_lifetime (ctx : ctx_with_info) lender holder =
    let observations = Option.map (fun _ -> ref []) diagnostic in
    let result =
    if observe_bool observations "shared-only-lender"
         (shared_observations_only ctx.ctx (ctx_lookup_abs ctx.ctx lender))
       && observe_bool observations "shared-only-holder"
            (shared_observations_only ctx.ctx (ctx_lookup_abs ctx.ctx holder))
    then false
    else
    let regions = (ctx_lookup_abs ctx.ctx lender).regions.owned in
    let loan_projs = AbsId.Map.find lender ctx.info.abs_to_loan_projs in
    let loans = AbsId.Map.find lender ctx.info.abs_to_loans in
    (* A concrete symbolic value uses all of its borrowed fields. Its region
       annotations may predate the lender's projection renaming. *)
    let uses_projected_value pm (sv : symbolic_value) =
      MarkedNormSymbProj.Set.exists
        (fun (loan : marked_norm_symb_proj) ->
          proj_markers_intersect loan.pm pm
          && loan.sv_id = sv.sv_id
          && norm_proj_tys_intersect span ctx.ctx loan.norm_proj_ty
               loan.norm_proj_ty)
        loan_projs
    in
    let visitor =
      object (self)
        inherit [_] iter_tavalue

        method! visit_ASharedLoan _ pm _ value child =
          self#visit_tvalue (Some pm) value;
          self#visit_tavalue None child

        method! visit_AEndedSharedLoan _ pm value child =
          self#visit_tvalue (Some pm) value;
          self#visit_tavalue None child

        method! visit_VSharedBorrow marker bid _ =
          match marker with
          | None -> ()
          | Some pm ->
              if
                MarkedLoanId.Set.exists
                  (fun (loan_pm, loan_bid) ->
                    loan_bid = bid && proj_markers_intersect loan_pm pm)
                  (AbsId.Map.find lender ctx.info.abs_to_loans)
              then raise Found

        method! visit_symbolic_value marker sv =
          match marker with
          | None -> ()
          | Some pm -> if uses_projected_value pm sv then raise Found
      end
    in
    let retained =
      try
        List.iter
          (visitor#visit_tavalue None)
          (ctx_lookup_abs ctx.ctx holder).avalues;
        false
      with Found -> true
    in
    if not (observe_bool observations "retained-payload" retained) then false
    else if
      (* Borrowed inputs can lead back to independently live owners through
         subsequent reductions. Do not bind that upstream lifetime to the
         retained payload holder merely because its direct loan is internal. *)
      observe_bool observations "independent-concrete-input"
        (MarkedBorrowId.Set.exists
          (fun borrow -> not (MarkedLoanId.Set.mem borrow loans))
          (AbsId.Map.find lender ctx.info.abs_to_non_unique_borrows))
      || observe_bool observations "independent-symbolic-input"
           (not (MarkedNormSymbProj.Set.is_empty
              (AbsId.Map.find lender ctx.info.abs_to_borrow_projs)))
    then true
    else
      let check_borrow bid =
        if MarkedLoanId.Set.exists (fun (_, loan) -> loan = bid) loans then
          raise Found
      in
      let external_use =
        object
          inherit [_] iter_tavalue as super

          method! visit_symbolic_value () sv =
            if uses_projected_value PNone sv then raise Found;
            super#visit_symbolic_value () sv

          method! visit_borrow_id _ bid = check_borrow bid
          method! visit_VSharedBorrow _ bid _ = check_borrow bid
          method! visit_VReservedMutBorrow _ bid _ = check_borrow bid
          method! visit_ASharedBorrow _ _ bid _ = check_borrow bid
          method! visit_AsbBorrow _ bid _ = check_borrow bid

          method! visit_region_id _ rid =
            if RegionId.Set.mem rid regions then raise Found
        end
      in
      observe_bool observations "external-use" (try
        List.iter
          (function
            | EAbs abs when abs.abs_id <> lender && abs.abs_id <> holder ->
                List.iter (external_use#visit_tavalue ()) abs.avalues
            | EBinding (_, value) -> external_use#visit_tvalue () value
            | EAbs _ | EFrame -> ())
          ctx.ctx.env;
        false
      with Found -> true)
    in
    (match policy_details, observations with
    | Some details, Some observed -> (try
        let observed = !observed in
        details := (fun formatter ->
          Format.fprintf formatter "payload-capture-guard lender=%s holder=%s result=%b@."
            (AbsId.to_string lender) (AbsId.to_string holder) result;
          print_guards formatter
            ["shared-only-lender"; "shared-only-holder"; "retained-payload";
             "independent-concrete-input"; "independent-symbolic-input"; "external-use"] observed)
          :: !details with _ -> ())
    | _ -> ());
    result
  in

  (* A lender whose loans a program variable still borrows (e.g., the reborrow
     of a shared argument introduced before a switch, see
     [InterpStatements.eval_switch_prepare], which the argument now borrows) is
     not merged with a holder which also borrows a loan held by a program
     variable (e.g., a call made before a loop which borrows the reborrow and
     [*self]): writing that variable ends the holder, and would end the loans
     of the lender with it, while the variable which borrows them is still
     live (as in Rust, where the lifetime of the holder ends before the write,
     not the one of the argument). The dummy values are not variables: the
     program neither reads nor writes them (e.g., the released payload of a
     shared loan, which lends the ['static] borrow its holder transferred).
     Only for the final canonicalization of a collapse (see
     [collapse_ctx_aux]), and only when the join left both abstractions
     unchanged ([keep_variable_borrows_apart]): they are then apart in every
     joined context. The abstractions a join introduces are canonicalized as
     before, since the contexts later matched with the joined one (e.g., the
     arms of a match, which borrow different variables) must reduce to the
     same partition. *)
  let would_end_variable_borrows (ctx : ctx_with_info) lender holder =
    let observations = Option.map (fun _ -> ref []) diagnostic in
    let result =
    observe_bool observations "lender-preserved-variable-partition"
      (AbsId.Set.mem lender keep_variable_borrows_apart)
    && observe_bool observations "holder-preserved-variable-partition"
         (AbsId.Set.mem holder keep_variable_borrows_apart)
    &&
    let lender_loans =
      MarkedLoanId.Set.fold
        (fun (_, id) ids -> BorrowId.Set.add id ids)
        (AbsId.Map.find lender ctx.info.abs_to_loans)
        BorrowId.Set.empty
    in
    let borrows = ref BorrowId.Set.empty in
    let loans = ref BorrowId.Set.empty in
    let visitor =
      object
        inherit [_] iter_abs
        method! visit_borrow_id _ id = borrows := BorrowId.Set.add id !borrows
        method! visit_loan_id _ id = loans := BorrowId.Set.add id !loans
        method! visit_mvalue _ _ = ()
      end
    in
    List.iter
      (function
        | EBinding (BVar _, value) -> visitor#visit_tvalue () value
        | EBinding (BDummy _, _) | EAbs _ | EFrame -> ())
      ctx.ctx.env;
    let value_borrows = !borrows and value_loans = !loans in
    observe_bool observations "variable-borrows-lender" (not (BorrowId.Set.disjoint lender_loans value_borrows))
    &&
    let () = borrows := BorrowId.Set.empty in
    visitor#visit_abs () { (ctx_lookup_abs ctx.ctx holder) with cont = None };
    observe_bool observations "holder-borrows-variable" (not (BorrowId.Set.disjoint !borrows value_loans))
    in
    (match policy_details, observations with
    | Some details, Some observed -> (try
        let observed = !observed in
        details := (fun formatter ->
          Format.fprintf formatter "variable-borrow-guard lender=%s holder=%s preserved-count=%d result=%b@."
            (AbsId.to_string lender) (AbsId.to_string holder)
            (AbsId.Set.cardinal keep_variable_borrows_apart) result;
          print_guards formatter
            ["lender-preserved-variable-partition"; "holder-preserved-variable-partition";
             "variable-borrows-lender"; "holder-borrows-variable"] observed) :: !details
        with _ -> ())
    | _ -> ());
    result
  in

  (* Nested borrows: a function-call abstraction whose loan projectors hold
     level-1 outputs of the call (see [InterpAbs.abs_call_level_output_svs]) is
     first merged with the abstraction which lends them. That abstraction can
     consume them and give back inputs of the same call at level 0 (e.g., the
     call receiving the reborrow returned by [Option::as_deref_mut] at the
     continue of a loop): a cycle through the two calls which only their
     levels order, and which the composition of their continuations can only
     express while the call's continuation is a single application (see
     [InterpAbs.merge_abs_conts_aux]). *)
  let defers_level_outputs (ctx : eval_ctx) abs_id0 abs_id1 =
    let observations = Option.map (fun _ -> ref []) diagnostic in
    let result =
    observe_bool observations "with-continuations" with_abs_conts
    &&
    let svs = abs_call_level_output_svs (ctx_lookup_abs ctx abs_id1) in
    observe_bool observations "direct-call-level-output-present" (not (SymbolicValueId.Set.is_empty svs))
    && observe_bool observations "lender-does-not-lend-output" (not (abs_lends_symbolic (ctx_lookup_abs ctx abs_id0) svs))
    && observe_bool observations "other-owner-lends-output" (List.exists
         (function
           | EAbs abs ->
               abs.abs_id <> abs_id0 && abs.abs_id <> abs_id1
               && abs_lends_symbolic abs svs
           | EBinding _ | EFrame -> false)
         ctx.env)
    in
    (match policy_details, observations with
    | Some details, Some observed -> (try
        let observed = !observed in
        details := (fun formatter ->
          Format.fprintf formatter "deferred-output-guard lender=%s holder=%s result=%b@."
            (AbsId.to_string abs_id0) (AbsId.to_string abs_id1) result;
          print_guards formatter
            ["with-continuations"; "direct-call-level-output-present";
             "lender-does-not-lend-output"; "other-owner-lends-output"] observed) :: !details
        with _ -> ())
    | _ -> ());
    result
  in

  (*
   * Merge all the mergeable abs.
   *)
  (* Because we need to manipulate different types for the concrete and the
     symbolic loans and borrows, we introduce a functor *)
  let module IterMerge
      (Map : Collections.Map)
      (Set : Collections.Set with type elt = Map.key)
      (Marked : sig
        val get_marker : Map.key -> proj_marker
        val diagnostic_family : string
        val diagnostic_edge : Map.key -> Format.formatter -> unit

        val get_borrow_candidates :
          ?observe:(AbsId.Set.t -> (Format.formatter -> unit) -> unit) ->
          eval_ctx -> abs_borrows_loans_maps -> Map.key -> AbsId.Set.t

        val get_to_loans : abs_borrows_loans_maps -> Set.t AbsId.Map.t
        val can_reduce_borrow : eval_ctx -> abs_id -> Map.key -> bool
      end) =
  struct
    (* We iterate over the *new* abstractions, then over the **loans**
       (concrete or symbolic) in the abstractions.

       We do this because we want to control the order in which abstractions
       are merged (the ids are iterated in increasing order). Otherwise, we
       could simply iterate over all the borrows in [loan_to_abs] for instance... *)
    let iterate_loans (ctx : ctx_with_info) (merge : abs_id * Map.key -> unit) =
      List.iter
        (fun abs_id0 ->
          (* Iterate over the loans *)
          let lids = AbsId.Map.find abs_id0 (Marked.get_to_loans ctx.info) in
          Set.iter (fun lid -> merge (abs_id0, lid)) lids)
        ctx.info.abs_ids

    (* Given a **loan**, check if there is a fresh abstraction with the corresponding borrow *)
    let merge_policy (ctx : ctx_with_info) (abs_id0, loan) =
      if not with_markers then
        [%sanity_check] span (Marked.get_marker loan = PNone);
      (* If we use markers: we are doing a collapse, which means we attempt
         to eliminate markers (and this is the only goal of the operation).
         We thus ignore the non-marked values (we merge non-marked values
         when doing a "real" reduce, to simplify the environment in order
         to converge to a fixed-point, for instance). *)
      if with_markers && Marked.get_marker loan = PNone then None
      else
        let candidate_proofs = Option.map (fun _ -> ref []) diagnostic in
        let observe = Option.map (fun proofs aids printer ->
            try proofs := (aids, printer) :: !proofs with _ -> ()) candidate_proofs in
        let abs_ids1 = Marked.get_borrow_candidates ?observe ctx.ctx ctx.info loan in
        if AbsId.Set.is_empty abs_ids1 then None
        else
          (* Compose abstract input slots. Borrowers retained inside concrete
             payloads are dependency edges, not lifetime equalities. A marked
             loan is an exception for the payloads of the abstraction which
             lends it: only the abstraction which holds its marked borrow can
             pair with it, and the collapse must remove the markers. E.g., the
             call abstraction of [&'a &'a T] in a loop lends the inner loan,
             whose marked borrow the joined abstraction of the inner region
             holds, and holds the outer loan, whose payload borrows the inner
             loan of that joined abstraction. Merging two abstractions only
             makes their lifetimes equal. *)
          let chosen_guards = Option.map (fun _ -> ref None) diagnostic in
          let candidates =
            AbsId.Set.filter
              (fun aid -> match chosen_guards with
              | None ->
                  aid <> abs_id0
                  && Marked.can_reduce_borrow ctx.ctx aid loan
                  && (not (would_capture_payload_lifetime ctx abs_id0 aid))
                  && (Marked.get_marker loan <> PNone
                     || not (would_capture_payload_lifetime ctx aid abs_id0))
                  && (not (defers_level_outputs ctx.ctx abs_id0 aid))
                  && not (would_end_variable_borrows ctx abs_id0 aid)
              | Some chosen ->
                  (match policy_details with None -> () | Some details -> details := []);
                  let guards = ref [] in
                  let record label verdict =
                    (try guards := (label, verdict) :: !guards with _ -> ());
                    verdict
                  in
                  let accepted =
                    record "distinct-owner" (aid <> abs_id0)
                    && record "can-reduce-borrow" (Marked.can_reduce_borrow ctx.ctx aid loan)
                    && record "no-forward-payload-capture"
                         (not (would_capture_payload_lifetime ctx abs_id0 aid))
                    && (record "marked-edge" (Marked.get_marker loan <> PNone)
                       || record "no-backward-payload-capture"
                            (not (would_capture_payload_lifetime ctx aid abs_id0)))
                    && record "no-deferred-level-output" (not (defers_level_outputs ctx.ctx abs_id0 aid))
                    && record "no-variable-borrow-end" (not (would_end_variable_borrows ctx abs_id0 aid))
                  in
                  if accepted then (try
                    match !chosen with
                    | Some (previous, _, _) when AbsId.compare_id previous aid <= 0 -> ()
                    | _ -> chosen := Some (aid, List.rev !guards,
                        (match policy_details with None -> [] | Some details -> List.rev !details))
                    with _ -> ());
                  accepted)
              abs_ids1
          in
          match AbsId.Set.min_elt_opt candidates with
          | None -> None
          | Some abs_id1 ->
              (match chosen_guards with
              | Some chosen -> (match !chosen with
                  | Some (aid, guards, details) when aid = abs_id1 ->
                      (match selected_policy with
                      | None -> ()
                      | Some cell -> (try
                          let proofs = match candidate_proofs with None -> [] | Some proofs ->
                            List.filter (fun (aids, _) -> AbsId.Set.mem abs_id1 aids) (List.rev !proofs) in
                          cell := Some (Marked.diagnostic_family,
                          (fun formatter ->
                            Format.fprintf formatter "orientation=loan-owner-left-borrow-owner-right left=%s right=%s candidate-selection=minimum-authorized-id@."
                              (AbsId.to_string abs_id0) (AbsId.to_string abs_id1);
                            Marked.diagnostic_edge loan formatter;
                            Format.pp_print_newline formatter ();
                            List.iter (fun (_, printer) -> printer formatter) proofs;
                            List.iter (fun detail -> detail formatter) details),
                          ("with-markers", with_markers) :: guards) with _ -> ()))
                  | _ -> ())
              | None -> ());
              [%ltrace
                "merging abstraction " ^ AbsId.to_string abs_id1 ^ " into "
                ^ AbsId.to_string abs_id0 ^ ":" ^ "\n- abs "
                ^ AbsId.to_string abs_id1 ^ ":\n"
                ^ abs_to_string span ctx.ctx (ctx_lookup_abs ctx.ctx abs_id1)
                ^ "\n\n- abs " ^ AbsId.to_string abs_id0 ^ ":\n"
                ^ abs_to_string span ctx.ctx (ctx_lookup_abs ctx.ctx abs_id0)
                ^ "\n\n"
                ^ eval_ctx_to_string ~span:(Some span) ctx.ctx];
              Some (abs_id0, abs_id1)

    (* Iterate over the loans and merge the abstractions *)
    let iter_merge (ctx : eval_ctx) : eval_ctx =
      repeat_iter_borrows_merge span fixed_abs_ids fresh_abs_kind ~can_end
        ~with_abs_conts sequence merge_funs iterate_loans merge_policy
        ~merge_count ?diagnostic ?diagnostic_selection ctx
  end in
  (* Instantiate the functor for the concrete borrows and loans *)
  let module IterMergeConcrete =
    IterMerge (MarkedBorrowId.Map) (MarkedBorrowId.Set)
      (struct
        let get_marker (pm, _) = pm
        let diagnostic_family = "concrete-borrow-loan"
        let diagnostic_edge (pm, bid) formatter =
          Format.fprintf formatter "marker=%a borrow=%s" pp_proj_marker pm
            (BorrowId.to_string bid)

        let get_borrow_candidates ?observe _ info loan =
          match
            MarkedBorrowId.Map.find_opt loan info.non_unique_borrow_to_abs
          with
          | None -> AbsId.Set.empty
          | Some aids ->
              (match observe with None -> () | Some observe ->
                observe aids (fun formatter ->
                  Format.fprintf formatter "concrete-index-membership=true candidates=%a@."
                    AbsId.Set.pp aids));
              aids

        let get_to_loans info = info.abs_to_loans

        let can_reduce_borrow ctx aid (pm, bid) =
          let abs = ctx_lookup_abs ctx aid in
          let rec visit_payload regions (value : tvalue) ty =
            match value.value with
            | VBorrow (VSharedBorrow (borrow, _)) ->
                let region, _, _ = ty_as_ref ty in
                if borrow = bid && region_in_set region regions then raise Found
            | VBorrow (VMutBorrow (_, child)) ->
                let _, referent, _ = ty_as_ref ty in
                visit_payload regions child referent
            | VLoan (VSharedLoan (_, payload)) ->
                visit_payload regions payload ty
            | VAdt adt ->
                (match ty with
                | TAdt { id; generics } ->
                    let fields =
                      ctx_adt_get_instantiated_field_types span ctx id
                        adt.variant_id generics
                    in
                    List.iter2 (visit_payload regions) adt.fields fields
                | TArray (element, _) ->
                    List.iter (fun field -> visit_payload regions field element)
                      adt.fields
                | _ -> [%internal_error] span)
            | VLiteral _ | VBottom | VSymbolic _
            | VBorrow (VReservedMutBorrow _) | VLoan (VMutLoan _) -> ()
          in
          let visitor =
            object (self)
              inherit [_] iter_tavalue as super

              method! visit_ASharedLoan regions marker _ value child =
                if pm <> PNone && marker = pm then
                  visit_payload regions value child.ty;
                self#visit_tavalue regions child

              method! visit_AEndedSharedLoan regions marker value child =
                if pm <> PNone && marker = pm then
                  visit_payload regions value child.ty;
                self#visit_tavalue regions child

              method! visit_ATransportedValue _ transport child =
                self#visit_tavalue transport.current_regions child

              method! visit_ATransportedProj _ transport child =
                self#visit_aproj transport.current_regions child

              method! visit_ETransportedValue _ transport child =
                self#visit_tevalue transport.current_regions child

              method! visit_ETransportedProj _ transport child =
                self#visit_eproj transport.current_regions child

              method! visit_aborrow_content env bc =
                let matches =
                  match bc with
                  | ASharedBorrow (pm', bid', _) | AMutBorrow (pm', bid', _) ->
                      pm = pm' && bid = bid'
                  | AProjSharedBorrow (pm', asb) ->
                      pm = pm'
                      && List.exists
                           (function
                             | AsbBorrow (bid', _) -> bid = bid'
                             | AsbProjReborrows _ -> false)
                           asb
                  | _ -> false
                in
                if matches then raise Found;
                super#visit_aborrow_content env bc
            end
          in
          try
            List.iter
              (visitor#visit_tavalue abs.regions.owned)
              abs.avalues;
            false
          with Found -> true
      end)
  in
  (* Instantiate the functor for the symbolic borrows and loans *)
  let module IterMergeSymbolic =
    IterMerge (MarkedNormSymbProj.Map) (MarkedNormSymbProj.Set)
      (struct
        let get_marker (proj : marked_norm_symb_proj) = proj.pm
        let diagnostic_family = "symbolic-borrow-loan"
        let diagnostic_edge (proj : marked_norm_symb_proj) formatter =
          Format.fprintf formatter "marker=%a symbol=%s normalized-type=%a"
            pp_proj_marker proj.pm (SymbolicValueId.to_string proj.sv_id)
            Types.pp_ty proj.norm_proj_ty

        let get_borrow_candidates ?observe ctx info (loan : marked_norm_symb_proj) =
          let projected = RegionId.Set.singleton (RegionId.of_int 0) in
          let shared_only =
            not
              (ty_has_mut_borrow_for_region_in_set ctx.type_ctx.type_infos
                 projected loan.norm_proj_ty)
          in
          let loan_shape =
            lazy
              (normalize_proj_ty ctx.type_ctx.type_infos RegionId.Set.empty loan.norm_proj_ty)
          in
          MarkedNormSymbProj.Map.fold
            (fun (borrow : marked_norm_symb_proj) aids candidates ->
(* ```ocaml *)
              if loan.pm <> borrow.pm then candidates
              else if loan.sv_id <> borrow.sv_id then candidates
              else
              let observations = Option.map (fun _ ->
                  ref ["same-symbol", true; "same-marker", true]) observe in
              let admitted =
                (observe_bool observations "direct-normalized-equality"
                      (norm_proj_tys_equal span ctx loan.norm_proj_ty borrow.norm_proj_ty)
                   || observe_bool observations "shared-only-alternative" shared_only
                      && observe_bool observations "erased-shape-equality"
                           (norm_proj_tys_equal span ctx (Lazy.force loan_shape)
                              (normalize_proj_ty ctx.type_ctx.type_infos RegionId.Set.empty
                                borrow.norm_proj_ty))
                      && observe_bool observations "normalized-intersection"
                           (norm_proj_tys_intersect span ctx loan.norm_proj_ty borrow.norm_proj_ty))
              in
              if admitted then (
                (match observe, observations with
                | Some observe, Some observed ->
                    let observed = !observed in
                    observe aids (fun formatter ->
                      Format.fprintf formatter "symbolic-candidate-membership candidates=%a shared-only=%b@.loan-marker=%a loan-symbol=%s loan-mask=%a@.borrow-marker=%a borrow-symbol=%s borrow-mask=%a@."
                        AbsId.Set.pp aids shared_only pp_proj_marker loan.pm
                        (SymbolicValueId.to_string loan.sv_id) Types.pp_ty loan.norm_proj_ty
                        pp_proj_marker borrow.pm (SymbolicValueId.to_string borrow.sv_id)
                        Types.pp_ty borrow.norm_proj_ty;
                      print_guards formatter ["same-marker"; "same-symbol";
                        "direct-normalized-equality"; "shared-only-alternative";
                        "erased-shape-equality"; "normalized-intersection"] observed)
                | _ -> ());
                AbsId.Set.union candidates aids)
              else candidates)
            info.borrow_proj_to_abs AbsId.Set.empty

        let get_to_loans info = info.abs_to_loan_projs
        let can_reduce_borrow _ _ _ = true
      end)
  in
  (* Compose physical parent dependencies before marker collapse.
     The carrier child receives one parent giveback and lends another return.
     These dependencies do not create concrete ownership-map edges. *)
  let iter_root_avalues (abs : abs) f =
    let ordinal = Option.map (fun _ -> ref 0) diagnostic in
    let visitor =
      object
        inherit [_] iter_tavalue_with_levels as super
        method incr_level level = level + 1
        method! visit_tavalue level av =
          let path = match ordinal with
            | None -> None
            | Some ordinal -> let index = !ordinal in incr ordinal; Some index in
          if level = 0 then f path av;
          super#visit_tavalue level av
      end
    in
    List.iter (visitor#visit_tavalue 0) abs.avalues
  in
  let pending_selected_edge = Option.map (fun _ -> ref None) diagnostic in
  let iter_pending_dependencies (ctx : ctx_with_info) merge =
    let pending_roots = Option.map (fun _ -> ref []) diagnostic in
    let child_ownership = Option.map (fun _ -> ref None) diagnostic in
    let pendings = ref BorrowId.Map.empty in
    List.iter
      (fun aid ->
        let abs = ctx_lookup_abs ctx.ctx aid in
        iter_root_avalues abs (fun path (av : tavalue) ->
            match av.value with
            | ASymbolic (pm, APendingLoans bid)
              when not with_markers || pm <> PNone ->
                let mask =
                  normalize_proj_ty ctx.ctx.type_ctx.type_infos
                    abs.regions.owned av.ty
                in
                let previous =
                  Option.value (BorrowId.Map.find_opt bid !pendings) ~default:[]
                in
                (match pending_roots with None -> () | Some roots ->
                  (try roots := (aid, bid, pm, mask, path, av) :: !roots with _ -> ()));
                pendings := BorrowId.Map.add bid ((aid, pm, mask) :: previous) !pendings
            | _ -> ()))
      ctx.info.abs_ids;
    List.iter
      (fun aid ->
        let abs = ctx_lookup_abs ctx.ctx aid in
        iter_root_avalues abs (fun path (av : tavalue) ->
            match av.value with
            | ALoan (AIgnoredMutLoan (pm, Some bid, child))
              when not (let verdict = InterpBorrows.tavalue_has_ownership span ctx.ctx child in
                (match child_ownership with None -> () | Some cell -> cell := Some verdict);
                verdict) ->
                let mask =
                  normalize_proj_ty ctx.ctx.type_ctx.type_infos
                    abs.regions.owned child.ty
                in
                Option.iter
                  (List.iter (fun (pending_aid, pending_pm, pending_mask) ->
                       let observations = Option.map (fun _ -> ref []) diagnostic in
                       if observe_bool observations "distinct-pending-owner" (aid <> pending_aid)
                          && observe_bool observations "pending-mask-equality" (mask = pending_mask)
                          && observe_bool observations "pending-marker-intersection"
                               (proj_markers_intersect pm pending_pm) then (
                         (match pending_selected_edge, pending_roots, observations with
                         | Some selected, Some roots, Some observed -> (try
                             let roots = !roots and observed = !observed in
                             let child_ownership = match child_ownership with
                               | None -> None | Some cell -> !cell in
                             selected := Some (fun formatter ->
                               Format.fprintf formatter "live-root-edge borrow=%s ignored-owner=%s pending-owner=%s ignored-root-ordinal=%s ignored-mask=%a pending-mask=%a@.ignored-child-has-ownership=%s@.ignored-root=%a@."
                                 (BorrowId.to_string bid) (AbsId.to_string aid)
                                 (AbsId.to_string pending_aid)
                                 (match path with None -> "unavailable" | Some index -> string_of_int index)
                                 Types.pp_ty mask Types.pp_ty pending_mask
                                 (match child_ownership with None -> "skipped" | Some value -> string_of_bool value)
                                 Values.pp_tavalue av;
                               List.iter (fun (owner, root_bid, marker, root_mask, root_path, root) ->
                                 if owner = pending_aid && root_bid = bid
                                    && marker = pending_pm && root_mask = pending_mask then
                                   Format.fprintf formatter "pending-live-root-ordinal=%s pending-marker=%a pending-root=%a@."
                                     (match root_path with None -> "unavailable" | Some index -> string_of_int index)
                                     pp_proj_marker marker Values.pp_tavalue root) roots;
                               print_guards formatter ["distinct-pending-owner";
                                 "pending-mask-equality"; "pending-marker-intersection"] observed)
                             with _ -> ())
                         | _ -> ());
                         merge (aid, pending_aid))))
                  (BorrowId.Map.find_opt bid !pendings)
            | _ -> ()))
      ctx.info.abs_ids
  in
  let pending_dependency_policy ctx (lender, holder) =
    (match policy_details with None -> () | Some details -> details := []);
    let capture_forward = would_capture_payload_lifetime ctx lender holder in
    let capture_backward = would_capture_payload_lifetime ctx holder lender in
    let deferred = defers_level_outputs ctx.ctx lender holder in
    let variables = would_end_variable_borrows ctx lender holder in
    if capture_forward || capture_backward || deferred || variables then None
    else (
      (match diagnostic with
      | None -> ()
      | Some _ -> (match selected_policy with
          | None -> ()
          | Some cell -> (try
              let details = match policy_details with None -> [] | Some details -> List.rev !details in
              let edge = match pending_selected_edge with None -> None | Some edge -> !edge in
              cell := Some ("pending-dependency",
              (fun formatter ->
                Format.fprintf formatter "orientation=ignored-loan-into-pending-holder lender=%s holder=%s candidate-selection=existing-root-traversal-order@."
                  (AbsId.to_string lender) (AbsId.to_string holder);
                (match edge with None -> () | Some printer -> printer formatter);
                List.iter (fun detail -> detail formatter) details),
              ["capture-forward", capture_forward; "capture-backward", capture_backward;
               "deferred-level-output", deferred; "variable-borrow-end", variables])
              with _ -> ())));
      Some (lender, holder))
  in
  let merge_pending_dependencies ctx =
    repeat_iter_borrows_merge span fixed_abs_ids fresh_abs_kind ~can_end
      ~with_abs_conts sequence merge_funs iter_pending_dependencies
      pending_dependency_policy ~merge_count ?diagnostic ?diagnostic_selection ctx
  in
  let rec merge_all ctx =
    let next =
      merge_pending_dependencies
        (IterMergeSymbolic.iter_merge (IterMergeConcrete.iter_merge ctx))
    in
    if next == ctx then ctx else merge_all next
  in let ctx = merge_all ctx in
  
  (* The abstractions of [restore_unmerged] (those a join kept unchanged, see
     [collapse_ctx_aux]) whose normalized parts were all left alone get back
     the shape they have in the joined contexts. Normalized, they would differ
     from their versions in the contexts which a later join compares with this
     one (e.g., the call abstraction [{ .., Some (SL l) }] of a call made
     before a loop, in another context of the loop body), which would no
     longer keep them unchanged. *)
  let ctx =
    if !normalized = [] then ctx
    else
      let abs_map = ctx_get_abs ctx in
      let restored =
        List.filter
          (fun (_, parts) ->
            List.for_all
              (fun (part : abs) ->
                AbsId.Map.find_opt part.abs_id abs_map = Some part)
              parts)
          !normalized
      in
      let originals =
        AbsId.Map.of_list
          (List.map (fun ((abs : abs), _) -> (abs.abs_id, abs)) restored)
      in
      let parts =
        AbsId.Set.of_list
          (List.concat_map
             (fun (_, parts) -> List.map (fun (part : abs) -> part.abs_id) parts)
             restored)
      in
      let env =
        List.filter_map
          (function
            | EAbs abs when AbsId.Set.mem abs.abs_id parts ->
                Option.map
                  (fun abs -> EAbs abs)
                  (AbsId.Map.find_opt abs.abs_id originals)
            | element -> Some element)
          ctx.env
      in
      { ctx with env }
  in
  
  (* Debugging *)
  [%ltrace
    "- after reduce:\n" ^ eval_ctx_to_string ~span:(Some span) ctx ^ "\n"];
  
  (* Reorder the fresh region abstractions - note that we may not have eliminated
     all the markers at this point. *)
  let ctx = reorder_fresh_abs span true fixed_abs_ids ctx in
  
  [%ltrace
    "- after reduce and reorder borrows/loans and abstractions:\n"
    ^ eval_ctx_to_string ~span:(Some span) ctx
    ^ "\n"];
  
  (* Return the new context *)
  ctx

(** reduce_ctx can only be called in a context with no markers *)
let reduce_ctx config (span : Meta.span) ?diagnostic
    ?(sequence : (abs_id * abs_id * abs_id) list ref option = None)
    ?(loop : bool = false) ~(with_abs_conts : bool) (fresh_abs_kind : abs_kind)
    (fixed_abs_ids : AbsId.Set.t) (fixed_dids : DummyVarId.Set.t)
    (ctx : eval_ctx) : eval_ctx =
  (* Simplify the context *)
  let ctx, _ =
    InterpBorrows.simplify_dummy_values_useless_abs config span ctx
  in
  (* Reduce *)
  let ctx =
    reduce_ctx_with_markers None sequence span ~with_abs_conts ~loop
      fresh_abs_kind fixed_abs_ids ~fixed_dids:(Some fixed_dids) ?diagnostic ctx
  in
  let ctx = eliminate_shared_loans span ctx in
  ctx_drop_carrierless_owned_regions fixed_abs_ids ctx

(** Auxiliary function for collapse (see below).

    We traverse all abstractions, and merge abstractions when they contain the
    same element, but with dual markers (i.e., [PLeft] and [PRight]).

    For instance, if we have the abstractions

    {[
      abs@0 { | MB l0 _ |, ML l1 }
      abs@1 { ︙MB l0 _ ︙, ML l2 }
    ]}

    We merge abs@0 and abs@1 into a new abstraction abs@2. This allows us to
    eliminate the markers used for [MB l0]:
    {[
      abs@2 { MB l0 _, ML l1, ML l2 }
    ]} *)
let collapse_ctx_collapse (span : Meta.span)
    (sequence : (abs_id * abs_id * abs_id) list ref option)
    (fresh_abs_kind : abs_kind) ~(with_abs_conts : bool)
    (merge_funs : merge_duplicates_funcs) ?(merge_count : int ref option = None)
    ?diagnostic
    (ctx : eval_ctx) : eval_ctx =
  (* Debug *)
  [%ltrace
    "\n- initial ctx:\n" ^ eval_ctx_to_string ~span:(Some span) ctx ^ "\n"];

  let can_end = true in
  let ctx0 = ctx in

  let invert_proj_marker = function
    | PNone -> [%craise] span "Unreachable"
    | PLeft -> PRight
    | PRight -> PLeft
  in

  (* The number of marked elements of [aid0] whose dual (same element, other
     marker) [aid1] holds, over every kind of element: shared borrows with
     their shared borrow ids, borrows, loans, borrow and loan projections. *)
  let complementarity (info : abs_borrows_loans_maps) (aid0 : abs_id)
      (aid1 : abs_id) : int =
    let find m empty aid = Option.value ~default:empty (AbsId.Map.find_opt aid m) in
    let unique =
      let s1 = find info.abs_to_borrows MarkedUniqueBorrowId.Set.empty aid1 in
      MarkedUniqueBorrowId.Set.cardinal
        (MarkedUniqueBorrowId.Set.filter
           (fun (pm, bid, sid) ->
             pm <> PNone
             && MarkedUniqueBorrowId.Set.mem (invert_proj_marker pm, bid, sid) s1)
           (find info.abs_to_borrows MarkedUniqueBorrowId.Set.empty aid0))
    in
    let ids m =
      let s1 = find m MarkedBorrowId.Set.empty aid1 in
      MarkedBorrowId.Set.cardinal
        (MarkedBorrowId.Set.filter
           (fun (pm, id) ->
             pm <> PNone && MarkedBorrowId.Set.mem (invert_proj_marker pm, id) s1)
           (find m MarkedBorrowId.Set.empty aid0))
    in
    let projs m =
      let s1 = find m MarkedNormSymbProj.Set.empty aid1 in
      MarkedNormSymbProj.Set.cardinal
        (MarkedNormSymbProj.Set.filter
           (fun (p : marked_norm_symb_proj) ->
             p.pm <> PNone
             && MarkedNormSymbProj.Set.mem
                  { p with pm = invert_proj_marker p.pm }
                  s1)
           (find m MarkedNormSymbProj.Set.empty aid0))
    in
    unique
    + ids info.abs_to_non_unique_borrows
    + ids info.abs_to_loans
    + projs info.abs_to_borrow_projs
    + projs info.abs_to_loan_projs
  in

  let fixed_aids = ctx_get_frozen_abs_set ctx in

  (* Merge all the mergeable abs where the same element is present in both abs,
     but with left and right markers respectively.

     As we have to operate over different types, with both concrete borrows and loans and
     borrow projectors and loan projectors, we implement this as a functor.
  *)
  let module IterMerge
      (Map : Collections.Map)
      (Set : Collections.Set with type elt = Map.key)
      (Marked : sig
        val get_marker : Map.key -> proj_marker

        (* Remove a marker - we need this to check whether some borrows in one
           abstraction have corresponding loans in another abstraction,
           independently of the markers, to properly choose which abstraction
           we merge into the other. *)
        val unmark : Map.key -> Map.key
        val same_ownership : eval_ctx -> Map.key -> Map.key -> bool

        (* Invert a marker *)
        val invert_proj_marker : Map.key -> Map.key
        val get_to_borrows : abs_borrows_loans_maps -> Set.t AbsId.Map.t
        val get_to_loans : abs_borrows_loans_maps -> Set.t AbsId.Map.t
        val get_borrow_to_abs : abs_borrows_loans_maps -> AbsId.Set.t Map.t
        val get_loan_to_abs : abs_borrows_loans_maps -> AbsId.Set.t Map.t
      end) =
  struct
    (* The iter function: iterate over the abstractions, and inside an abstraction
       over the borrows (projectors) then the loan (projectors) *)
    let iter (ctx : ctx_with_info) (f : AbsId.id * bool * Map.key -> unit) =
      List.iter
        (fun abs_id0 ->
          (* Small helper *)
          let iterate is_borrow =
            let m =
              if is_borrow then Marked.get_to_borrows ctx.info
              else Marked.get_to_loans ctx.info
            in
            let ids = AbsId.Map.find abs_id0 m in
            Set.iter (fun id -> f (abs_id0, is_borrow, id)) ids
          in
          (* Iterate over the borrows *)
          iterate true;
          (* Iterate over the loans *)
          iterate false)
        ctx.info.abs_ids

    (* Small utility: check if we need to swap two region abstractions before
       merging them.

       We might have to swap the order to make sure that if there
       are loans in one abstraction and the corresponding borrows
       in the other they get properly merged (if we merge them in the wrong
       order, we might introduce borrowing cycles).

       Example:
       If we are merging abs0 and abs1 because of the marked value
       [MB l0]:
       {[
         abs0 { |MB l0|, MB l1 }
         abs1 { ︙MB l0︙, ML l1 }
       ]}
       we want to make sure that we swap them (abs1 goes to the
       left) to make sure [MB l1] and [ML l1] get properly eliminated.

       Remark: in case there is a borrowing cycle between the two abstractions
       (which shouldn't happen) then there isn't much we can do, and whatever
       the order in which we merge, we will preserve the cycle.
    *)
    let swap_abs (ctx : ctx_with_info) (abs_id0 : abs_id) (abs_id1 : abs_id) =
      let info = ctx.info in
      let abs0_borrows =
        Set.of_list
          (List.map Marked.unmark
             (Set.elements
                (AbsId.Map.find abs_id0 (Marked.get_to_borrows info))))
      in
      let abs1_loans =
        Set.of_list
          (List.map Marked.unmark
             (Set.elements (AbsId.Map.find abs_id1 (Marked.get_to_loans info))))
      in
      not (Set.disjoint abs0_borrows abs1_loans)
      || Set.exists
           (fun borrow ->
             Set.exists
               (fun loan -> Marked.same_ownership ctx.ctx borrow loan)
               abs1_loans)
           abs0_borrows

    (* Check if there is an abstraction with the same borrow/loan id (or the
       same projections of borrows/loans) and the dual marker, and merge them
       if it is the case. *)
    let merge_policy ctx (abs_id0, is_borrow, loan) =
      if Marked.get_marker loan = PNone then None
      else
        (* Look for an element with the dual marker *)
        match
          Map.find_opt
            (Marked.invert_proj_marker loan)
            (if is_borrow then Marked.get_borrow_to_abs ctx.info
             else Marked.get_loan_to_abs ctx.info)
        with
        | None -> (* Nothing to do *) None
        | Some abs_ids1 -> (
            (* We need to merge *)
            let order abs_id1 =
              (* Check if we need to swap *)
              if swap_abs ctx abs_id0 abs_id1 then (abs_id1, abs_id0)
              else (abs_id0, abs_id1)
            in
            (* The candidate which [choose] below picks for an abstraction
               holding the element *)
            let choose aid0 =
              match AbsId.Set.elements abs_ids1 with
              | [] -> None
              | first :: _ as candidates ->
                  let score aid = complementarity ctx.info aid0 aid in
                  Some
                    (fst
                       (List.fold_left
                          (fun (best, best_score) aid ->
                            let s = score aid in
                            if s > best_score then (aid, s) else (best, best_score))
                          (first, score first) candidates))
            in
            (* Another abstraction which holds the same marked element (e.g.,
               another shared borrow of the same loan) can be the better
               partner of the candidate: the candidate holds the duals of more
               of its elements. Merging [abs_id0] with the candidate first
               coalesces owners which both branches keep apart. Let the other
               abstraction merge first: that abstraction picks the same
               candidate, so the iteration merges it. After that merge, the
               element of [abs_id0] has no dual in the candidate anymore, and
               the elimination of the shared borrow markers handles it (or
               the final check fails). *)
            let defer abs_id1 =
              let own = complementarity ctx.info abs_id0 abs_id1 in
              let rivals =
                Option.value ~default:AbsId.Set.empty
                  (Map.find_opt loan
                     (if is_borrow then Marked.get_borrow_to_abs ctx.info
                      else Marked.get_loan_to_abs ctx.info))
              in
              AbsId.Set.exists
                (fun aid ->
                  aid <> abs_id0
                  && (not (AbsId.Set.mem aid fixed_aids))
                  && complementarity ctx.info aid abs_id1 > own
                  && choose aid = Some abs_id1)
                rivals
            in
            let order abs_id1 =
              if defer abs_id1 then None else Some (order abs_id1)
            in
            match AbsId.Set.elements abs_ids1 with
            | [] -> None
            | [ abs_id1 ] -> order abs_id1
            | abs_id1 :: _ as candidates ->
                (* Several abstractions hold the dual element, e.g., distinct
                   shared reborrows of one loan by the abstractions of distinct
                   regions. Pair with the most complementary one (the largest
                   number of elements of [abs_id0] whose dual it holds): taking
                   any other one coalesces owners which both branches keep
                   apart, and the joined context then no longer matches them.
                   Count every kind of element, not only the kind of the
                   element which triggered the merge: e.g., two abstractions of
                   a branch holding distinct shared borrows [SB l (^4)] and
                   [SB l (^6)] of one loan, which are two distinct borrows
                   (and, for one of them, a loan projector) that the other
                   branch keeps apart as well. *)
                let score aid = complementarity ctx.info abs_id0 aid in
                let best, _ =
                  List.fold_left
                    (fun (best, best_score) aid ->
                      let s = score aid in
                      if s > best_score then (aid, s) else (best, best_score))
                    (abs_id1, score abs_id1)
                    candidates
                in
                order best)

    (* Iterate and merge *)
    let iter_merge (ctx : eval_ctx) : eval_ctx =
      repeat_iter_borrows_merge span fixed_aids fresh_abs_kind ~can_end
        ~with_abs_conts sequence (Some merge_funs) iter merge_policy
        ~merge_count ?diagnostic ctx
  end in
  (* Instantiate the functor for concrete loans and borrows *)
  let module IterMergeConcrete =
    IterMerge (MarkedBorrowId.Map) (MarkedBorrowId.Set)
      (struct
        let get_marker (v : marked_borrow_id) = fst v
        let unmark (_, bid) = (PNone, bid)
        let same_ownership _ left right = left = right
        let invert_proj_marker (pm, bid) = (invert_proj_marker pm, bid)
        let get_to_borrows info = info.abs_to_non_unique_borrows
        let get_to_loans info = info.abs_to_loans
        let get_borrow_to_abs info = info.non_unique_borrow_to_abs
        let get_loan_to_abs info = info.loan_to_abs
      end)
  in
  (* Instantiate the functor for symbolic loans and borrows *)
  let module IterMergeSymbolic =
    IterMerge (MarkedNormSymbProj.Map) (MarkedNormSymbProj.Set)
      (struct
        let get_marker (v : marked_norm_symb_proj) = v.pm
        let unmark v = { v with pm = PNone }
        let same_ownership ctx (left : marked_norm_symb_proj) right =
          left.pm = right.pm && left.sv_id = right.sv_id
          && norm_proj_tys_equal span ctx left.norm_proj_ty right.norm_proj_ty
        let invert_proj_marker v = { v with pm = invert_proj_marker v.pm }
        let get_to_borrows info = info.abs_to_borrow_projs
        let get_to_loans info = info.abs_to_loan_projs
        let get_borrow_to_abs info = info.borrow_proj_to_abs
        let get_loan_to_abs info = info.loan_proj_to_abs
      end)
  in
  (* Pending projections are dependencies on a future parent giveback, not
     loans. Pair their complementary branches in a separate namespace so they
     can never cancel the parent's actual loan. *)
  let iter_pending (ctx : ctx_with_info) emit =
    let seen = lazy (Hashtbl.create 16) in
    let symbolic_seen = lazy (Hashtbl.create 16) in
    List.iter
      (fun aid ->
        let abs = ctx_lookup_abs ctx.ctx aid in
        let visitor =
          object (self)
            inherit [_] InterpBorrowsCore.iter_tavalue_with_levels as super
            method incr_level (pm, level, ty) = (pm, level + 1, ty)

            method! visit_tavalue (pm, level, _) (av : tavalue) =
              super#visit_tavalue (pm, level, av.ty) av

            method! visit_ASymbolic (_, level, ty) pm proj =
              self#visit_aproj (pm, level, ty) proj

            method! visit_APendingLoans (pm, level, ty) bid =
              if pm <> PNone then (
                let norm_ty =
                  normalize_proj_ty ctx.ctx.type_ctx.type_infos abs.regions.owned ty
                in
                let seen = Lazy.force seen in
                let opposite = (invert_proj_marker pm, bid, level, norm_ty) in
                (match Hashtbl.find_opt seen opposite with
                | Some other -> emit (other, aid)
                | None -> ());
                Hashtbl.replace seen (pm, bid, level, norm_ty) aid)

            method! visit_APendingSymbolicLoans (pm, level, _) slot =
              if pm <> PNone then (
                let seen = Lazy.force symbolic_seen in
                let opposite = (invert_proj_marker pm, level, slot) in
                (match Hashtbl.find_opt seen opposite with
                | Some other -> emit (other, aid)
                | None -> ());
                Hashtbl.replace seen (pm, level, slot) aid)
          end
        in
        List.iter
          (fun (av : tavalue) -> visitor#visit_tavalue (PNone, 0, av.ty) av)
          abs.avalues)
      ctx.info.abs_ids
  in
  let merge_pending ctx =
    let policy ctx (aid0, aid1) =
      Some
        (if
           IterMergeConcrete.swap_abs ctx aid0 aid1
           || IterMergeSymbolic.swap_abs ctx aid0 aid1
(* ``` *)
         then (aid1, aid0)
         else (aid0, aid1))
    in
    repeat_iter_borrows_merge span fixed_aids fresh_abs_kind ~can_end
      ~with_abs_conts sequence (Some merge_funs) iter_pending policy
      ~merge_count ?diagnostic ctx
  in
  (* Iterate and merge *)
  let rec merge_all ctx =
    let next =
      merge_pending
        (IterMergeSymbolic.iter_merge (IterMergeConcrete.iter_merge ctx))
    in
    if next == ctx then ctx else merge_all next
  in
  let ctx = merge_all ctx in

  [%ltrace
    "- after collapse:\n" ^ eval_ctx_to_string ~span:(Some span) ctx ^ "\n"];

  (* Reorder the fresh region abstractions - note that we may not have eliminated
     all the markers yet *)
  let fixed_aids = compute_fixed_abs_ids ctx0 ctx in
  let ctx = reorder_fresh_abs span true fixed_aids ctx in

  [%ltrace
    "- after collapse and reorder borrows/loans:\n"
    ^ eval_ctx_to_string ~span:(Some span) ctx
    ^ "\n"];

  (* Return the new context *)
  ctx

(** Small utility: check whether an environment contains markers *)
(*
```ocaml
*)
let eval_ctx_has_markers (ctx : eval_ctx) : bool =
  let visitor =
    object
      inherit [_] iter_eval_ctx as super
      method! visit_tavalue _ value =
        super#visit_tavalue
          (Some (fun () -> "Actual ownership value:\n" ^ show_tavalue value))
          value
      method! visit_tevalue _ value =
        super#visit_tevalue
          (Some (fun () -> "Continuation ownership value:\n" ^ show_tevalue value))
          value

      method! visit_proj_marker where pm =
        match pm with
        | PNone -> ()
        | PLeft | PRight ->
            Option.iter (fun describe -> [%ldebug describe ()]) where;
            raise Found
    end
  in
  try
    visitor#visit_eval_ctx None ctx;
    false
  with Found -> true
(*
```
*)

(** Release closed, single-branch components through the ordinary ownership
    lifecycle. Reduction can end an outer shared loan while retaining a concrete
    borrower in its payload. Such a borrower must be released by [end_abs], not
    erased by abstract borrow cancellation. *)
let end_closed_shared_components config (span : Meta.span) (ctx : eval_ctx) :
    eval_ctx =
  let entries =
    List.filter_map
      (function
        | EAbs abs ->
            let visitor, get_ids, _ = compute_ids () in
            List.iter (visitor#visit_tavalue ()) abs.avalues;
            Some (abs, get_ids ())
        | _ -> None)
      ctx.env
  in
  let external_blids, external_regions =
    List.fold_left
      (fun (blids, regions) -> function
        | EBinding (_, value) ->
            let ids, _ = compute_tvalue_ids value in
            ( BorrowId.Set.union blids ids.blids,
              RegionId.Set.union regions ids.rids )
        | EAbs _ | EFrame -> (blids, regions))
      (BorrowId.Set.empty, RegionId.Set.empty)
      ctx.env
  in
  let connected ((abs0 : abs), (ids0 : ids_sets))
      ((abs1 : abs), (ids1 : ids_sets)) =
    (not (BorrowId.Set.disjoint ids0.blids ids1.blids))
    || (not (RegionId.Set.disjoint abs0.regions.owned ids1.rids))
    || (not (RegionId.Set.disjoint abs1.regions.owned ids0.rids))
    || AbsId.Set.mem abs0.abs_id abs1.parents
    || AbsId.Set.mem abs1.abs_id abs0.parents
  in
  let rec collect component frontier remaining =
    match frontier with
    | [] -> (component, remaining)
    | entry :: frontier ->
        let neighbours, remaining =
          List.partition (connected entry) remaining
        in
        collect (entry :: component) (neighbours @ frontier) remaining
  in
  let branch_of_component (component : (abs * ids_sets) list) =
    let branch = ref None in
    let visitor =
      object (self)
        inherit [_] iter_tavalue as super

        method! visit_proj_marker () pm =
          match (pm, !branch) with
          | PNone, _ -> raise Found
          | (PLeft | PRight), None -> branch := Some pm
          | _, Some previous when pm = previous -> ()
          | _ -> raise Found

        method! visit_VBorrow () =
          function
          | VSharedBorrow _ -> ()
          | VMutBorrow _ | VReservedMutBorrow _ -> raise Found

        method! visit_VLoan () =
          function
          | VSharedLoan (_, value) -> super#visit_tvalue () value
          | VMutLoan _ -> raise Found

        method! visit_symbolic_value () sv =
          if ty_has_borrows (Some span) ctx.type_ctx.type_infos sv.sv_ty then
            raise Found

        method! visit_ABorrow () =
          function
          (* Shared reborrows of the borrows inside a value (e.g., of the
             elements [&'a T] of a [Vec<&'a T>] behind the shared borrow given
             to [Option::as_ref]) are shared borrows: releasing them gives
             nothing back and leaves their lenders untouched. *)
          | ASharedBorrow (pm, _, _) | AProjSharedBorrow (pm, _) ->
              self#visit_proj_marker () pm
          | AEndedSharedBorrow -> ()
          | _ -> raise Found

        method! visit_ALoan () =
          function
          | (ASharedLoan _ | AEndedSharedLoan _ | AIgnoredSharedLoan _) as loan
            -> super#visit_ALoan () loan
          | _ -> raise Found

        method! visit_ASymbolic () pm proj =
          if InterpBorrows.proj_has_ownership proj then raise Found;
          self#visit_proj_marker () pm
      end
    in
    try
      List.iter
        (fun ((abs : abs), (ids : ids_sets)) ->
          if
            (not abs.can_end)
            || (match abs.kind with
               | SynthInput _ -> true
               | _ -> false)
            || (not (BorrowId.Set.disjoint ids.blids external_blids))
            || not (RegionId.Set.disjoint abs.regions.owned external_regions)
          then raise Found;
          List.iter (visitor#visit_tavalue ()) abs.avalues)
        component;
      !branch
    with Found -> None
  in
  let rec release (ctx : eval_ctx) = function
    | [] -> ctx
    | entry :: remaining ->
        let component, remaining = collect [] [ entry ] remaining in
        let ctx =
          match branch_of_component component with
          | None -> ctx
          | Some pm ->
              let aids =
                AbsId.Set.of_list
                  (List.map (fun ((abs : abs), _) -> abs.abs_id) component)
              in
              let env =
                List.filter
                  (function
                    | EAbs abs -> AbsId.Set.mem abs.abs_id aids
                    | EFrame -> true
                    | EBinding _ -> false)
                  ctx.env
              in
              (* Closure proves that projection cannot affect another owner.
                 The normal lifecycle transfers retained payloads to dummy
                 values, ends their borrowers, and then releases their loans. *)
              let isolated =
                project_context span AbsId.Set.empty pm { ctx with env }
              in
              let released, _ =
                InterpBorrows.simplify_dummy_values_useless_abs config span
                  isolated
              in
              if
                List.for_all
                  (function
                    | EFrame -> true
                    | EAbs _ | EBinding _ -> false)
                  released.env
              then
                {
                  ctx with
                  env =
                    List.filter
                      (function
                        | EAbs abs -> not (AbsId.Set.mem abs.abs_id aids)
                        | EBinding _ | EFrame -> true)
                      ctx.env;
                  ended_regions = released.ended_regions;
                }
              else ctx
        in
        release ctx remaining
  in
  release ctx entries

(** Transfer unprotected, released shared payloads to abstract input slots.
    Values with live loans stay concrete, as does mutable or nested ownership.
    Conversion and merging preserve the original continuation, dependencies,
    branch marker, and the independent abstract child of the ended loan. *)
let normalize_released_shared_payloads span ?diagnostic ~loop fresh_abs_kind
    ~with_abs_conts merge_funs on_merge ctx (abs : abs) =
  let left = lazy (project_context span AbsId.Set.empty PLeft ctx) in
  let right = lazy (project_context span AbsId.Set.empty PRight ctx) in
  let lookup_ctx pm =
    if not (eval_ctx_has_markers ctx) then ctx
    else
      match pm with
      | PNone | PLeft -> Lazy.force left
      | PRight -> Lazy.force right
  in
  let can_transfer value =
    let has_borrow = ref false in
    let visitor =
      object
        inherit [_] iter_tvalue
        method! visit_VLoan () _ = raise Found

        method! visit_VBorrow () =
          function
          | VSharedBorrow _ -> has_borrow := true
          | VMutBorrow _ | VReservedMutBorrow _ -> raise Found

        method! visit_symbolic_value () sv =
          if
            ty_has_mut_borrows ctx.type_ctx.type_infos sv.sv_ty
            || ty_has_nested_borrows (Some span) ctx.type_ctx.type_infos
                 sv.sv_ty
          then raise Found
          else if symbolic_value_has_borrows (Some span) ctx sv then
            has_borrow := true
      end
    in
    try
      visitor#visit_tvalue () value;
      !has_borrow
    with Found -> false
  in
  let transferred = ref [] in
  let metadata_bindings = ref ctx.metadata_bindings in
  (* The payload's borrows live in the regions of the loan's referent type.
     When a child abstraction owns some of them (the referent has nested
     regions, e.g. [&'a F<'b>] for a closure capturing [&'b T]), those
     borrows are nested ownership: they are not inputs of this holder. *)
  let referent_regions_owned (ty : ty) =
    match ty with
    | TRef (_, referent, _) ->
        RegionId.Set.subset (ty_regions ctx.type_ctx.type_infos referent) abs.regions.owned
    | _ -> false
  in
  let avalues =
    List.map
      (fun (av : tavalue) ->
        match av.value with
        | ALoan (AEndedSharedLoan (pm, payload, child))
          when can_transfer payload && referent_regions_owned av.ty ->
            let owners, bindings =
              convert_value_to_abstractions span fresh_abs_kind
                ~can_end:abs.can_end (lookup_ctx pm) payload
            in
            let bindings =
              merge_metadata_bindings (Some span) !metadata_bindings bindings
            in
            let () = metadata_bindings := bindings in
            let ctx = ctx_with_metadata_bindings ctx bindings in
            let owners =
              match pm with
              | PNone -> owners
              | PLeft | PRight ->
                  List.concat_map
                    (abs_add_marker span
                       ~loop_level_outputs:
                         (loop_level_outputs ~loop fresh_abs_kind)
                       ctx pm)
                    owners
            in
            transferred := List.rev_append owners !transferred;
            {
              av with
              value =
                ALoan
                  (AEndedSharedLoan (pm, { payload with value = VBottom }, child));
            }
        | _ -> av)
      abs.avalues
  in
  let ctx = ctx_with_metadata_bindings ctx !metadata_bindings in
  if !transferred = [] then (ctx, abs.abs_id)
  else
    let ctx, _ = ctx_subst_abs span ctx abs.abs_id { abs with avalues } in
    (* Install the entire transfer before merging any owner: merge cleanup
       consults global borrowers and must not end a lender whose transferred
       borrower has not yet been installed. *)
    let transferred = List.rev !transferred in
    let ctx =
      {
        ctx with
        env = List.map (fun owner -> EAbs owner) transferred @ ctx.env;
      }
    in
    List.fold_left
      (fun (ctx, holder) (owner : abs) ->
        let ctx, merged =
          InterpAbs.merge_into_first_abstraction span fresh_abs_kind ?diagnostic
            ~can_end:abs.can_end ~with_abs_conts merge_funs ctx holder
            owner.abs_id
        in
        on_merge holder owner.abs_id merged;
        (ctx, merged))
      (ctx, abs.abs_id) transferred

(** Collapse two environments containing projection markers; this function is
    called after joining environments.

    The collapse is done in two steps.

    First, we reduce the environment, merging any two pair of fresh abstractions
    which contain a loan (in one) and its corresponding borrow (in the other).
    This is our version of Abstract Interpretation's **widening** operation. For
    instance, we merge abs@0 and abs@1 below:
    {[
      abs@0 { |ML l0|, ML l1 }
      abs@1 { |MB l0 _|, ML l2 }
                ~~>
      abs@2 { ML l1, ML l2 }
    ]}
    Note that we also merge abstractions when the loan/borrow don't have the
    same markers. For instance, below:
    {[
      abs@0 { ML l0, ML l1 } // ML l0 doesn't have markers
      abs@1 { |MB l0 _|, ML l2 }
                ~~>
      abs@2 { ︙ML l0︙, ML l1, ML l2 }
    ]}

    Second, we merge abstractions containing the same element with left and
    right markers respectively. For instance:
    {[
      abs@0 { | MB l0 _ |, ML l1 }
      abs@1 { ︙MB l0 _ ︙, ML l2 }
                ~~>
      abs@2 { MB l0 _, ML l1, ML l2 }
    ]}

    At the end of the second step, all markers should have been removed from the
    resulting environment. *)
let collapse_ctx_aux config (span : Meta.span)
    (sequence : (abs_id * abs_id * abs_id) list ref option)
    (shared_borrows_seq :
      (abs_id * int * proj_marker * borrow_or_proj * ty) list ref option)
    ~(loop : bool) (fresh_abs_kind : abs_kind) ~(with_abs_conts : bool)
    ~(untouched : AbsId.Set.t) (merge_funs : merge_duplicates_funcs)
    ~preserved_abs_ids ?diagnostic
    (ctx0 : eval_ctx) : eval_ctx =
  [%ldebug "ctx0:\n" ^ eval_ctx_to_string ctx0];
  let fixed_aids =
    (* We forbid modifying the abs which are frozen or which don't have any markers *)
    let frozen = ctx_get_frozen_abs_set ctx0 in
    let abs = AbsId.Map.values (ctx_get_abs ctx0) in
    let no_markers =
      List.filter_map
        (fun (abs : abs) ->
          if abs_has_markers abs then None else Some abs.abs_id)
        abs
    in
    AbsId.Set.union preserved_abs_ids (AbsId.Set.add_list no_markers frozen)
  in

  (match diagnostic with None -> () | Some capture ->
      capture.trace_fixed <- Some fixed_aids;
      capture.trace_preserved <- preserved_abs_ids);
  [%ldebug "fixed_aids: " ^ AbsId.Set.to_string None fixed_aids];

  (* Matching retained payloads during collapse can introduce fresh owners
     whose same-branch loans are already in the context. Reduction must see
     those owners before we attempt the final shared-marker elimination. *)
  let merge_count = ref 0 in
(* ```ocaml *)
  let check_shared_owners phase ctx =
    if !Config.sanity_checks then (
      let loans = ref BorrowId.Set.empty in
      let borrows = ref BorrowId.Set.empty in
      let visitor = object
        inherit [_] iter_eval_ctx as super
        method! visit_ty _ _ = ()
        method! visit_abs_cont _ _ = ()
        method! visit_VSharedLoan env bid value =
          loans := BorrowId.Set.add bid !loans;
          super#visit_VSharedLoan env bid value
        method! visit_ASharedLoan env marker bid value child =
          loans := BorrowId.Set.add bid !loans;
          super#visit_ASharedLoan env marker bid value child
        method! visit_VSharedBorrow _ bid _ =
          borrows := BorrowId.Set.add bid !borrows
        method! visit_VReservedMutBorrow _ bid _ =
          borrows := BorrowId.Set.add bid !borrows
        method! visit_ASharedBorrow _ _ bid _ =
          borrows := BorrowId.Set.add bid !borrows
        method! visit_AsbBorrow _ bid _ =
          borrows := BorrowId.Set.add bid !borrows
      end in
      visitor#visit_eval_ctx () ctx;
      if not (BorrowId.Set.subset !borrows !loans) then
        [%craise] span
          ("Shared payload owners are absent after " ^ phase ^ ": "
          ^ BorrowId.Set.to_string None (BorrowId.Set.diff !borrows !loans)
          ^ "\n" ^ eval_ctx_to_string ~span:(Some span) ~filter:false ctx))
  in
  let () = check_shared_owners "collapse entry" ctx0 in
(*
```ocaml
*)
  InterpBorrows.diagnose_symbolic_runtime_type_transition span
    "collapse_ctx_aux: entry" ctx0 ctx0;
(*
```
*)
  let normalize_payloads ctx =
    (match diagnostic with None -> () | Some capture -> capture.trace_fixed <- Some fixed_aids);
    let on_merge holder owner merged =
      incr merge_count;
      Option.iter
        (fun sequence -> sequence := (holder, owner, merged) :: !sequence)
        sequence
    in
    List.fold_left
      (fun ctx -> function
        | EAbs abs when not (AbsId.Set.mem abs.abs_id fixed_aids) ->
            let abs = ctx_lookup_abs ctx abs.abs_id in
            fst
              (normalize_released_shared_payloads span ?diagnostic ~loop fresh_abs_kind
                 ~with_abs_conts (Some merge_funs) on_merge ctx abs)
        | _ -> ctx)
      ctx ctx.env
  in
  let rec reconcile ctx =
    let before = !merge_count in
    let reduced =
      reduce_ctx_with_markers (Some merge_funs) sequence span ~with_abs_conts
        ~loop fresh_abs_kind fixed_aids ~merge_count:(Some merge_count) ?diagnostic ctx
    in
(*
```ocaml
*)
    InterpBorrows.diagnose_symbolic_runtime_type_transition span
      "collapse_ctx_aux: marked reduction" ctx reduced;
(*
```
*)
    [%ldebug "ctx after reduce:\n" ^ eval_ctx_to_string reduced];
    let () = check_shared_owners "marked reduction" reduced in
    (* A join can pair a released payload of one branch with the same
       borrows already transferred to their holder in the other branch (a
       previous join normalized them), e.g. [︙@ended_shared_loan((.., SB l))︙]
       and [|SB l|] in one abstraction. Only the normalized representations
       are complementary: transfer before pairing markers. *)
(*
```ocaml
*)
    let before_normalization = reduced in
(*
```
*)
    let reduced = normalize_payloads reduced in
(*
```ocaml
*)
    InterpBorrows.diagnose_symbolic_runtime_type_transition span
      "collapse_ctx_aux: released payload normalization" before_normalization reduced;
(*
```
*)
    let () = check_shared_owners "released payload normalization" reduced in
    let collapsed =
      collapse_ctx_collapse span ~with_abs_conts sequence fresh_abs_kind
        merge_funs ~merge_count:(Some merge_count) ?diagnostic reduced
    in
(*
```ocaml
*)
    InterpBorrows.diagnose_symbolic_runtime_type_transition span
      "collapse_ctx_aux: marker collapse" reduced collapsed;
(*
```
*)
    let () = check_shared_owners "marker collapse" collapsed in
(*
```ocaml
*)
    let before_normalization = collapsed in
(*
```
*)
    let collapsed = normalize_payloads collapsed in
(*
```ocaml
*)
    InterpBorrows.diagnose_symbolic_runtime_type_transition span
      "collapse_ctx_aux: collapsed payload normalization" before_normalization collapsed;
(*
```
*)
    let () = check_shared_owners "collapsed payload normalization" collapsed in
(* ``` *)
    [%ldebug "ctx after reduce and collapse:\n" ^ eval_ctx_to_string collapsed];
    (* Reordering is not ownership progress. Repeat only after an actual
       merge, which may have exposed or introduced another ownership pair. *)
    if !merge_count = before then collapsed else reconcile collapsed
  in
  let ctx = reconcile ctx0 in
(* ```ocaml *)
  if !Config.sanity_checks then
    Invariants.check_loans_borrows_relation_invariant span ctx;
(* ``` *)

(*
```ocaml
*)
  let before_internal_borrows = ctx in
(*
```
*)
  let ctx =
    ctx_map_abs (InterpBorrows.eliminate_internal_shared_borrows span ctx) ctx
  in
(*
```ocaml
*)
  InterpBorrows.diagnose_symbolic_runtime_type_transition span
    "collapse_ctx_aux: internal shared borrows" before_internal_borrows ctx;
(*
```
*)
  [%ldebug
    "ctx after eliminating internal shared borrows:\n" ^ eval_ctx_to_string ctx];

(*
```ocaml
*)
  let before_borrow_markers = ctx in
(*
```
*)
  let ctx = eliminate_shared_borrow_markers span shared_borrows_seq ctx in
(*
```ocaml
*)
  InterpBorrows.diagnose_symbolic_runtime_type_transition span
    "collapse_ctx_aux: shared borrow markers" before_borrow_markers ctx;
(*
```
*)
  [%ldebug
    "ctx after reduce, collapse and eliminate_shared_borrow_markers:\n"
    ^ eval_ctx_to_string ctx];

(*
```ocaml
*)
  let before_shared_loans = ctx in
(*
```
*)
  let ctx = eliminate_shared_loans span ctx in
(*
```ocaml
*)
  InterpBorrows.diagnose_symbolic_runtime_type_transition span
    "collapse_ctx_aux: shared loans" before_shared_loans ctx;
(*
```
*)
  [%ldebug
    "ctx after reduce, collapse and eliminate_shared_loans:\n"
    ^ eval_ctx_to_string ctx];
(* ```ocaml *)
  if !Config.sanity_checks then
    Invariants.check_loans_borrows_relation_invariant span ctx;
(* ``` *)

(*
```ocaml
*)
  let before_ended_markers = ctx in
(*
```
*)
  let ctx = eliminate_ended_markers span ctx in
(*
```ocaml
*)
  InterpBorrows.diagnose_symbolic_runtime_type_transition span
    "collapse_ctx_aux: ended markers" before_ended_markers ctx;
  let before_closed_components = ctx in
(*
```
*)
  let ctx =
    if eval_ctx_has_markers ctx then
      end_closed_shared_components config span ctx
    else ctx
  in
(*
```ocaml
*)
  InterpBorrows.diagnose_symbolic_runtime_type_transition span
    "collapse_ctx_aux: closed shared components" before_closed_components ctx;
  let before_held_markers = ctx in
(*
```
*)
  let ctx =
    if eval_ctx_has_markers ctx then eliminate_held_loan_cont_markers ctx
    else ctx
  in
(*
```ocaml
*)
  InterpBorrows.diagnose_symbolic_runtime_type_transition span
    "collapse_ctx_aux: held loan continuation markers" before_held_markers ctx;
(*
```
*)
  [%ldebug
    "ctx after reduce, collapse and eliminate_ended_markers:\n"
    ^ eval_ctx_to_string ctx];

  (*
```ocaml
  *)
  if eval_ctx_has_markers ctx
    && (!Config.print_error_diagnostics || !Config.print_error_emitters) then begin
    let fixed = ctx_get_frozen_abs_set ctx in
    let explore (abs : abs) =
      abs.can_end && not (AbsId.Set.mem abs.abs_id fixed)
      && match abs.kind with SynthInput _ -> false | _ -> true in
    let info = compute_abs_borrows_loans_maps span explore ctx ctx.env in
    Printf.eprintf "Remaining ownership index:\n%s\n%!"
      (abs_borrows_loans_maps_to_string ctx info)
  end;
  (*
```
  *)
  (* Sanity check: there are no markers remaining *)
  if eval_ctx_has_markers ctx then
    [%craise] span
      ("Markers remain after ownership reduction:\n"
      ^ eval_ctx_to_string ~span:(Some span) ~filter:false ctx
      ^ "\nBefore ownership reduction:\n"
      ^ eval_ctx_to_string ~span:(Some span) ~filter:false ctx0);

  (* Marker collapse protects initially unmarked owners, but a live retained
     payload may depend on one of those owners. Canonicalize the resulting
     marker-free components before this context becomes a source snapshot.
     Record these merges as well, so projected replay preserves the same
     partition and continuation composition. Frozen inputs remain untouched.
     So do, like the frozen ones, the abstractions of the function calls with a
     staged backward function which the join kept unchanged ([untouched]), and
     those they depend on (see {!InterpJoinCore.untouched_staged_call_abs_ids}):
     e.g., the abstractions of a call made before a loop, and the loop
     abstraction of an enclosing loop, which the loop body does not modify;
     merged together, they would become a loop abstraction whose continuation
     applies the stages of the call. And a match with three arms or more joins
     the next arm into this context: the abstraction of the call which consumed
     the value a staged call returned, normalized here ([(s@1), _, _] into
     [(s@1)]), would differ from the one of the arm, and be merged into a join
     abstraction. Nor does it merge two abstractions which the join kept
     unchanged when one borrows a loan held by a variable and a variable
     borrows a loan of the other: e.g., a call made before a loop which
     borrows [*self] and the reborrow of an argument read after [self] is
     written (see [would_end_variable_borrows] in {!reduce_ctx_with_markers}).
     In the joins of branches (not in the loop joins), the other abstractions
     which the join kept unchanged, and which are not merged, keep their shape
     (see [restore_unmerged] there): e.g., the abstraction
     [{ SB .., Some (SL l) }] of such a call would otherwise become
     [{ SB .., SL l }], differ from its version in another context of the loop
     body, and be merged into a join abstraction there. A loop join keeps the
     normalized form: the fixed point then merges a call made before the loop
     which the loop body reborrows (e.g., [index_mut] in [get_elem_mut] of the
     test [loops]) into the loop abstraction, as before. *)
  (* A match replay must retain the source partition for unchanged owners. *)
(*
```ocaml
*)
  let before_marker_free_reduction = ctx in
(*
```
*)
  let ctx =
    reduce_ctx_with_markers None sequence span ~with_abs_conts ~loop
      fresh_abs_kind
      (AbsId.Set.union preserved_abs_ids
         (AbsId.Set.union
            (ctx_get_frozen_abs_set ctx)
            (InterpJoinCore.untouched_staged_call_abs_ids ctx untouched)))
      ~keep_variable_borrows_apart:untouched
      ~restore_unmerged:
        (match fresh_abs_kind with
        | Loop _ -> AbsId.Set.empty
        | _ -> untouched)
      ?diagnostic ctx
  in
(*
```ocaml
*)
  InterpBorrows.diagnose_symbolic_runtime_type_transition span
    "collapse_ctx_aux: marker-free reduction" before_marker_free_reduction ctx;
(*
```
*)
(* ```ocaml *)
  if !Config.sanity_checks then
    Invariants.check_loans_borrows_relation_invariant span ctx;
(* ``` *)
  (* Component merging can make a formerly external shared input internal.
     Use the same normalization as projected replay before taking a snapshot. *)
(*
```ocaml
*)
  let before_internal_borrows = ctx in
(*
```
*)
  let ctx =
    ctx_map_abs (InterpBorrows.eliminate_internal_shared_borrows span ctx) ctx
  in
(*
```ocaml
*)
  InterpBorrows.diagnose_symbolic_runtime_type_transition span
    "collapse_ctx_aux: final internal shared borrows" before_internal_borrows ctx;
  let before_shared_loans = ctx in
(*
```
*)
  let ctx = eliminate_shared_loans span ctx in
(*
```ocaml
*)
  InterpBorrows.diagnose_symbolic_runtime_type_transition span
    "collapse_ctx_aux: final shared loans" before_shared_loans ctx;
(*
```
*)
(* ```ocaml *)
  if !Config.sanity_checks then
    Invariants.check_loans_borrows_relation_invariant span ctx;
(* ``` *)

(*
```ocaml
*)
  InterpBorrows.diagnose_symbolic_runtime_type_transition span
    "collapse_ctx_aux: before dummy cleanup" ctx ctx;
(*
```
*)
(*
```ocaml
*)
  let before_dummy_cleanup = ctx in
(*
```
*)
  (* One last cleanup *)
  let ctx, _ =
    InterpBorrows.simplify_dummy_values_useless_abs config span ctx
  in
(*
```ocaml
*)
  InterpBorrows.diagnose_symbolic_runtime_type_transition span
    "collapse_ctx_aux: after dummy cleanup" before_dummy_cleanup ctx;
(*
```
*)
  (* Use the same carrier relation as marker-free reduction before export. *)
  ctx_drop_carrierless_owned_regions
    (AbsId.Set.union preserved_abs_ids
       (AbsId.Set.union
          (ctx_get_frozen_abs_set ctx)
          (InterpJoinCore.untouched_staged_call_abs_ids ctx untouched)))
    ctx

let mk_collapse_ctx_merge_duplicate_funs (span : Meta.span)
    ?(loop : bool = false) (fresh_abs_kind : abs_kind) ~(recoverable : bool)
    ~(with_abs_conts : bool) (ctx : eval_ctx) : merge_duplicates_funcs =
  (* Rem.: the merge functions raise exceptions (that we catch). *)
  let module S : MatchJoinState = struct
    let span = span
    let fresh_abs_kind = fresh_abs_kind
    let loop_level_outputs = loop_level_outputs ~loop fresh_abs_kind
    let nabs = ref []
    let metadata_bindings = ref ctx.metadata_bindings
    let with_abs_conts = with_abs_conts
    let symbolic_to_value = ref SymbolicValueId.Map.empty
    let recover = recoverable

    let lookup_shared_value ~is_left:_ ctx bid =
      InterpBorrowsCore.ctx_lookup_shared_value span ctx bid
  end in
  (* Functions to match avalues (see {!merge_duplicates_funcs}).

     Those functions are used to merge borrows/loans with the *same ids*.

     Mutable children are destructured. Shared payloads may retain ownership,
     and InterpAbs reconciles their abstract children before calling us. We
     use the ordinary join matcher for their concrete payloads, transferring
     every generated abstraction through [drain_new_abstractions].
  *)
  let merge_amut_borrows id ty0 _pm0 (child0 : tavalue) _ty1 _pm1
      (child1 : tavalue) : tavalue =
    (* Sanity checks *)
    [%sanity_check] span (is_aignored child0.value);
    [%sanity_check] span (is_aignored child1.value);

    (* We need to pick a type for the avalue. The types on the left and on the
       right may use different regions: it doesn't really matter (here, we pick
       the one from the left), because we will merge those regions together
       anyway (see the comments for {!merge_into_first_abstraction}).
    *)
    let ty = ty0 in
    let child = child0 in
    let value = ABorrow (AMutBorrow (PNone, id, child)) in
    { value; ty }
  in

  let merge_ashared_borrows id ty0 _pm0 _ ty1 _pm1 _ : tavalue =
    (* Sanity checks *)
    let _ =
      let _, ty0, _ = ty_as_ref ty0 in
      let _, ty1, _ = ty_as_ref ty1 in
      [%sanity_check] span (ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings ty0 = ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings ty1)
    in

    (* Same remarks as for [merge_amut_borrows] *)
    let ty = ty0 in
    let value =
      ABorrow (ASharedBorrow (PNone, id, ctx.fresh_shared_borrow_id ()))
    in
    { value; ty }
  in

  let merge_amut_loans id ty0 _pm0 (child0 : tavalue) _ty1 _pm1
      (child1 : tavalue) : tavalue =
    (* Sanity checks *)
    [%sanity_check] span (is_aignored child0.value);
    [%sanity_check] span (is_aignored child1.value);

    (* Same remarks as for [merge_amut_borrows] *)
    let ty = ty0 in
    let child = child0 in
    let value = ALoan (AMutLoan (PNone, id, child)) in
    { value; ty }
  in
  let merge_shared_payloads (ctx : eval_ctx) pm0 (sv0 : tvalue)
      (child0 : tavalue) pm1 (sv1 : tvalue) (child1 : tavalue) =
    (* InterpAbs reconciles abstract children structurally before invoking
       this callback. Concrete payloads use the ordinary join matcher, which
       may create abstractions owning their nested borrows and loans. *)
    [%sanity_check] span (child0 = child1);
    (* Scope the symbolic join cache to this payload: subsequent abstraction
       merges can substitute regions throughout the context. *)
    let module JM = MakeJoinMatcher (S) in
    let module M = MakeMatcher (JM) in
    (* Callback order follows value insertion, not branch order. The join
       matcher assigns PLeft/PRight to its arguments, so preserve the original
       provenance of every abstraction it creates for the retained payload. *)
    let left, right =
      match (pm0, pm1) with
      | PLeft, PRight -> (sv0, sv1)
      | PRight, PLeft -> (sv1, sv0)
      | _ -> [%internal_error] span
    in
    (* Read each payload from its physical branch. These views select its
       lenders without a change to the merged context. *)
    let fixed = ctx_get_frozen_abs_set ctx in
    let left_ctx = project_context span fixed PLeft ctx in
    let right_ctx = project_context span fixed PRight ctx in
    let sv =
      JM.match_shared_payloads ~merge_lender:true
        (M.match_tvalues left_ctx right_ctx)
        left_ctx right_ctx left right
    in
    (sv, child0)
  in
  let merge_ashared_loans ctx ids ty0 pm0 sv0 child0 _ty1 pm1 sv1 child1 :
      tavalue =
    let sv, child = merge_shared_payloads ctx pm0 sv0 child0 pm1 sv1 child1 in
    let region, _, kind = ty_get_ref ty0 in
    let ty = mk_ref_ty region child.ty kind in
    { value = ALoan (ASharedLoan (PNone, ids, sv, child)); ty }
  in
  let merge_aended_shared_loans ctx ty0 pm0 sv0 child0 _ty1 pm1 sv1 child1 :
      tavalue =
    let sv, child = merge_shared_payloads ctx pm0 sv0 child0 pm1 sv1 child1 in
    let region, _, kind = ty_get_ref ty0 in
    let ty = mk_ref_ty region child.ty kind in
    { value = ALoan (AEndedSharedLoan (PNone, sv, child)); ty }
  in
  let drain_new_abstractions () =
    let abstractions = !S.nabs in
    S.nabs := [];
    (abstractions, !S.metadata_bindings)
  in
  {
    drain_new_abstractions;
    merge_amut_borrows;
    merge_ashared_borrows;
    merge_amut_loans;
    merge_ashared_loans;
    merge_aended_shared_loans;
  }

let merge_into_first_abstraction (span : Meta.span) (abs_kind : abs_kind)
    ~(can_end : bool) ~(recoverable : bool) ~(with_abs_conts : bool)
    (ctx : eval_ctx) (aid0 : AbsId.id) (aid1 : AbsId.id) : eval_ctx * AbsId.id =
  let merge_funs =
    mk_collapse_ctx_merge_duplicate_funs span abs_kind ~recoverable
      ~with_abs_conts ctx
  in
  InterpAbs.merge_into_first_abstraction span abs_kind ~can_end ~with_abs_conts
    (Some merge_funs) ctx aid0 aid1

let collapse_ctx config (span : Meta.span) ?diagnostic
    ?(sequence : (abs_id * abs_id * abs_id) list ref option = None)
    ?(shared_borrows_seq :
        (abs_id * int * proj_marker * borrow_or_proj * ty) list ref option =
      None) ?(untouched : AbsId.Set.t = AbsId.Set.empty) ?(loop : bool = false)
    ?(preserved_abs_ids = AbsId.Set.empty)
    (fresh_abs_kind : abs_kind) ~(recoverable : bool) ~(with_abs_conts : bool)
    (ctx : eval_ctx) : eval_ctx =
  [%ldebug "Initial ctx:\n" ^ eval_ctx_to_string ctx];
  let merge_funs =
    mk_collapse_ctx_merge_duplicate_funs span ~loop fresh_abs_kind ~recoverable
      ~with_abs_conts ctx
  in
  try
    collapse_ctx_aux config span ~with_abs_conts ~untouched ~preserved_abs_ids
      sequence shared_borrows_seq ~loop fresh_abs_kind merge_funs ?diagnostic ctx
  with ValueMatchFailure _ -> [%internal_error] span

let add_shared_borrows (span : Meta.span)
    (shared_borrows_seq :
      (abs_id * int * proj_marker * borrow_or_proj * ty) list) (ctx : eval_ctx)
    : eval_ctx =
  let loans, loan_projs = get_non_marked_shared_loans span ctx in
  let ctx = ref ctx in
  let update
      ((abs_id, i, pm, borrow_or_proj, ty) :
        abs_id * int * proj_marker * borrow_or_proj * ty) : unit =
    let abs =
      match ctx_lookup_abs_opt !ctx abs_id with
      | Some abs -> abs
      | None ->
          [%craise] span
            ("Could not find the abstraction abs@" ^ AbsId.to_string abs_id
           ^ " in which to introduce a shared borrow (marker "
            ^ show_proj_marker pm ^ ") in:\n" ^ eval_ctx_to_string !ctx)
    in
    let rid = RegionId.Set.choose abs.regions.owned in
    let r : region = RVar (Free rid) in
    let subst_projection_ty r_subst ty =
      let metadata_policy =
        (* ```ocaml *)
        ((fun id index original mapped ->
           let info = TypeDeclId.Map.find id (!ctx).type_ctx.type_infos in
           if RegionId.Set.mem index info.metadata_regions
              && not (RegionId.Set.mem index info.stored_regions)
           then original else mapped),
        (* ``` *)
         (fun id index ->
           let info = TypeDeclId.Map.find id (!ctx).type_ctx.type_infos in
           TypeVarId.Set.mem index info.metadata_type_params
           && not (TypeVarId.Set.mem index info.stored_type_params)))
      in
      let visitor =
        Substitute.subst_ids_visitor ~metadata_policy
          { Substitute.empty_id_subst with r_subst }
      in
      visitor#visit_ty () ty
    in
    let rec update_avalues (i : int) (avl : tavalue list) : tavalue list =
      if i = 0 then
        let nv : tavalue =
          match borrow_or_proj with
          | Borrow bid ->
              [%sanity_check] span (BorrowId.Set.mem bid loans);
              (* The outer lifetime belongs to this abstraction; nested
                 lifetimes are witnesses of the currently retained payload,
                 not regions to replace with the outer lifetime. *)
              let referent, bindings =
                match snd (ctx_lookup_loan span ek_all bid !ctx) with
                | Concrete (VSharedLoan (_, value)) ->
                    retained_value_rty span !ctx value
                | Abstract (ASharedLoan (_, _, _, child)) ->
                    (child.ty, (!ctx).metadata_bindings)
                | _ -> [%internal_error] span
              in
              let () = ctx := ctx_with_metadata_bindings !ctx bindings in
              [%sanity_check] span
                (ty_erase_regions_with_metadata (!ctx).type_ctx.type_infos (!ctx).metadata_bindings referent
                 = ty_erase_regions_with_metadata (!ctx).type_ctx.type_infos (!ctx).metadata_bindings ty);
              {
                value =
                  ABorrow
                    (ASharedBorrow (pm, bid, !ctx.fresh_shared_borrow_id ()));
                ty = mk_ref_ty r referent RShared;
              }
          | Proj (regions', proj) ->
              [%sanity_check] span
                (let proj =
                   normalize_symbolic_proj (!ctx).type_ctx.type_infos abs.regions.owned proj
                 in
                 NormSymbProj.Set.mem proj loan_projs);
              (* Substitute the regions with the one we picked *)
              let proj_ty =
                subst_projection_ty
                  (fun rid' ->
                    if RegionId.Set.mem rid' regions' then rid else rid')
                  proj.proj_ty
              in
              let proj = { proj with proj_ty } in
              let value = ASymbolic (pm, AProjBorrows { proj; loans = [] }) in
              let ty = proj.proj_ty in
              { value; ty }
          | SharedProj (regions, asb) ->
              let subst rid' =
                if RegionId.Set.mem rid' regions then rid else rid'
              in
              let asb =
                List.map
                  (function
                    | AsbBorrow (bid, _) ->
                        [%sanity_check] span (BorrowId.Set.mem bid loans);
                        AsbBorrow (bid, !ctx.fresh_shared_borrow_id ())
                    | AsbProjReborrows proj ->
                        [%sanity_check] span
                          (NormSymbProj.Set.mem
                             (normalize_symbolic_proj (!ctx).type_ctx.type_infos regions proj)
                             loan_projs);
                        let proj_ty =
                          subst_projection_ty subst proj.proj_ty
                        in
                        AsbProjReborrows { proj with proj_ty })
                  asb
              in
              {
                value = ABorrow (AProjSharedBorrow (pm, asb));
                ty = subst_projection_ty subst ty;
              }
        in
        nv :: avl
      else
        match avl with
        | [] -> [%internal_error] span
        | av :: avl' -> av :: update_avalues (i - 1) avl'
    in
    let abs = { abs with avalues = update_avalues i abs.avalues } in
    let ctx', _ = ctx_subst_abs span !ctx abs.abs_id abs in
    ctx := ctx'
  in
  List.iter update shared_borrows_seq;

  !ctx

(** Collapse a context following a sequence *)
let collapse_ctx_following_sequence (span : Meta.span) ?diagnostic
    (sequence : (abs_id * abs_id * abs_id) list)
    (shared_borrows_seq :
      (abs_id * int * proj_marker * borrow_or_proj * ty) list) ~(loop : bool)
    (fresh_abs_kind : abs_kind) ~(with_abs_conts : bool) (ctx0 : eval_ctx) :
    eval_ctx =
  [%ltrace
    "- ctx0:\n" ^ eval_ctx_to_string ctx0 ^ "\n- sequence:\n"
    ^ String.concat "\n"
        (List.map
           (fun (a0, a1, a2) ->
             "(" ^ AbsId.to_string a0 ^ "," ^ AbsId.to_string a1 ^ ") -> "
             ^ AbsId.to_string a2)
           sequence)];
  let native_diagnostic = Option.map (fun capture -> capture.replay_native) diagnostic in
  let ctx = ref ctx0 in
  let nabs_map = ref AbsId.Map.empty in
  let get_id (aid : abs_id) : abs_id =
    match AbsId.Map.find_opt aid !nabs_map with
    | None -> aid
    | Some aid -> aid
  in

  (* Apply the sequence of merges *)
  List.iter
    (fun ((abs0, abs1, nabs) as recorded) ->
      let before = !ctx in
      let map_before = !nabs_map in
      let step = match diagnostic with None -> -1 | Some capture -> capture.replay_count in
      (match native_diagnostic with None -> () | Some capture ->
          capture.trace_step <- step;
          capture.trace_phase <- "replay-normalization";
          capture.trace_preserved <- AbsId.Set.empty;
          capture.trace_fixed <- None);
      let normalization_begin = match native_diagnostic with
        | None -> 0 | Some capture -> capture.trace_count in
      (* Substitute - the ids may have changed *)
      let abs0 = get_id abs0 in
      let abs1 = get_id abs1 in
      let resolved_left = abs0 in
      let resolved_right = abs1 in
      let on_merge = match native_diagnostic with
        | None -> (fun _ _ _ -> ())
        | Some capture -> (fun holder owner merged ->
            try
              let index = capture.trace_count - 1 in
              match capture.trace_records.(index mod 128) with
              | Some entry when entry.merge_index = index
                  && entry.merge_left.abs_id = holder
                  && entry.merge_right.abs_id = owner
                  && entry.merge_result = merged ->
                  entry.merge_normalization_callback <- Some (holder, owner, merged)
              | _ -> capture.trace_callback_unavailable <- capture.trace_callback_unavailable + 1
            with _ -> ())
      in
      (* Replay the same payload representation change in the projected
         context. The transient owners recorded by the original transfer
         need not exist here; their borrowers now reside in this holder. *)
      let normalize aid =
        match ctx_lookup_abs_opt !ctx aid with
        | Some abs when abs.can_end ->
            let nctx, aid =
              normalize_released_shared_payloads span ?diagnostic:native_diagnostic ~loop fresh_abs_kind
                ~with_abs_conts None on_merge
                !ctx abs
            in
            ctx := nctx;
            aid
        | _ -> aid
      in
      let same_abs = abs0 = abs1 in
      let abs0 = normalize abs0 in
      let abs1 = if same_abs then abs0 else normalize abs1 in
      let normalization_end = match native_diagnostic with
        | None -> 0 | Some capture -> capture.trace_count in
      (match native_diagnostic with None -> () | Some capture -> capture.trace_phase <- "replay-merge");
      let action =
      (* Attempt to merge - note that some region might be missing, because
         it appears only in one environment and not the other *)
      match (ctx_lookup_abs_opt !ctx abs0, ctx_lookup_abs_opt !ctx abs1) with
      | Some abs, Some _ when abs0 = abs1 ->
          (* Self-reconciliation only removes complementary branch markers.
             In an already projected environment it is the identity, including
             on the abstraction's continuation. *)
          nabs_map := AbsId.Map.add nabs abs.abs_id !nabs_map;
          "self"
      | Some _, Some _ ->
          (* Merge and register the new id *)
          [%ldebug
            "Merging: " ^ AbsId.to_string abs0 ^ " <- " ^ AbsId.to_string abs1];
          let nctx, nabs' =
            InterpAbs.merge_into_first_abstraction span fresh_abs_kind ?diagnostic:native_diagnostic
              ~can_end:true ~with_abs_conts None !ctx abs0 abs1
          in
          ctx := nctx;
          [%ldebug
            "Context after merging " ^ AbsId.to_string nabs' ^ " := ("
            ^ AbsId.to_string abs0 ^ " <- " ^ AbsId.to_string abs1 ^ "):\n"
            ^ eval_ctx_to_string !ctx];
          nabs_map := AbsId.Map.add nabs nabs' !nabs_map;
          "merge"
      | None, Some abs | Some abs, None ->
          (* We don't have to merge anything, meaning the abstraction resulting
             from the merge is exactly the abstraction we found (what happened is
             that we're in the situation where we had to merge an abstraction
             from one side with another abstracction from the other side). *)
          [%ldebug
            "Registering: " ^ AbsId.to_string nabs ^ " --> "
            ^ AbsId.to_string abs.abs_id];
          nabs_map := AbsId.Map.add nabs abs.abs_id !nabs_map;
          "one-present"
      | None, None ->
          (* The two abs come from the unprojected environment: we don't have to
             merge anything *)
          [%ldebug
            "Could not find left abstraction " ^ AbsId.to_string abs0
            ^ " and right abstraction " ^ AbsId.to_string abs1
            ^ " in context:\n" ^ eval_ctx_to_string !ctx];
          "none-present"
      in
      (match diagnostic with None -> () | Some capture ->
          try
            let index = capture.replay_count in
            capture.replay_count <- index + 1;
            capture.replay_records.(index mod 128) <- Some {
              replay_index = index; replay_recorded = recorded;
              replay_resolved_left = resolved_left; replay_resolved_right = resolved_right;
              replay_normalized_left = abs0; replay_normalized_right = abs1;
              replay_normalization_begin = normalization_begin;
              replay_normalization_end = normalization_end;
              replay_case = action; replay_result = AbsId.Map.find_opt nabs !nabs_map;
              replay_map_before = map_before; replay_map_after = !nabs_map;
              replay_before = before; replay_after = !ctx;
            }
          with _ -> ()))
    sequence;
  let ctx = !ctx in
  [%ldebug "ctx after applying the merge sequence:\n" ^ eval_ctx_to_string ctx];

  let fixed_aids = compute_fixed_abs_ids ctx0 ctx in
  let ctx = reorder_fresh_abs span true fixed_aids ctx in
  [%ldebug "ctx after reordering the fresh abs:\n" ^ eval_ctx_to_string ctx];
  let ctx =
    ctx_map_abs (InterpBorrows.eliminate_internal_shared_borrows span ctx) ctx
  in

  (* Update the ids used in the sequence of shared borrows *)
  let shared_borrows_seq =
    List.map
      (fun (abs_id, i, pm, bid, ty) -> (get_id abs_id, i, pm, bid, ty))
      shared_borrows_seq
  in
  let ctx = add_shared_borrows span shared_borrows_seq ctx in
  [%ldebug "ctx after adding the shared borrows:\n" ^ eval_ctx_to_string ctx];
  let ctx = eliminate_shared_borrow_markers span None ctx in

  let ctx = eliminate_shared_loans span ctx in
  [%ldebug "ctx after eliminating the shared loans:\n" ^ eval_ctx_to_string ctx];

  ctx

let collapse_ctx_no_markers_following_sequence (span : Meta.span) ?diagnostic
    ?(loop : bool = false) (sequence : (abs_id * abs_id * abs_id) list)
    (shared_borrows_seq :
      (abs_id * int * proj_marker * borrow_or_proj * ty) list)
    (fresh_abs_kind : abs_kind) ~(with_abs_conts : bool) (ctx : eval_ctx) :
    eval_ctx =
  try
    collapse_ctx_following_sequence span ?diagnostic ~with_abs_conts sequence
      shared_borrows_seq ~loop fresh_abs_kind ctx
  with ValueMatchFailure _ -> [%internal_error] span
