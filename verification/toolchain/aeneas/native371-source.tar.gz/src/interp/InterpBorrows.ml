open Types
open Values
open Contexts
open Cps
open Utils
open ValuesUtils
open TypesUtils
open InterpUtils
open InterpBorrowsCore
open InterpProjectors

(** The local logger *)
let log = Logging.borrows_log

(*
```ocaml
*)
let iter_runtime_binding_values ctx visit =
  let rec value frame binder position (tv : tvalue) =
    visit frame binder position tv;
    match tv.value with
    | VAdt product ->
        List.iteri (fun index field ->
          value frame binder
(*
```ocaml
*)
            (PField (product.variant_id, index) :: position) field)
(*
```
*)
          product.fields
    | VBorrow (VMutBorrow (_, child)) | VLoan (VSharedLoan (_, child)) ->
(*
```ocaml
*)
        value frame binder (PDeref :: position) child
(*
```
*)
    | _ -> ()
  in
  let rec bindings frame = function
    | [] -> ()
    | EBinding (binder, tv) :: rest ->
        value frame binder [] tv;
        bindings frame rest
    | EFrame :: rest -> bindings (frame + 1) rest
    | EAbs _ :: rest -> bindings frame rest
  in
  bindings 0 ctx.env

let runtime_type_metadata_view ctx tys =
  let regions = ref RegionId.Set.empty in
  let declarations = ref TypeDeclId.Set.empty in
  let visitor = object
    inherit [_] iter_ty as super
    method! visit_RVar _ = function
      | Free id -> regions := RegionId.Set.add id !regions
      | Bound _ -> ()
    method! visit_TAdt env tref =
      (match tref.id with
      | TAdtId id -> declarations := TypeDeclId.Set.add id !declarations
      | _ -> ());
      super#visit_TAdt env tref
  end in
  List.iter (visitor#visit_ty ()) tys;
  (* ```ocaml *)
  let rec sources visited id =
    if RegionId.Set.cardinal visited >= 32 || RegionId.Set.mem id visited then visited
    else
      let visited = RegionId.Set.add id visited in
      match RegionId.Map.find_opt id ctx.metadata_bindings with
      | Some (MetadataSource (RVar (Free source))) -> sources visited source
      | _ -> visited
  in
  let relevant = RegionId.Set.fold
    (fun id visited -> sources visited id) !regions RegionId.Set.empty in
  let bindings = RegionId.Map.filter
    (fun id _ -> RegionId.Set.mem id relevant) ctx.metadata_bindings in
  let classifications = TypeDeclId.Set.elements !declarations
    |> List.filteri (fun index _ -> index < 8)
    |> List.map (fun id ->
      TypeDeclId.to_string id ^ ": "
      ^ (match TypeDeclId.Map.find_opt id ctx.type_ctx.type_infos with
        | Some info -> TypesAnalysis.show_type_decl_info info
        | None -> "absent")) in
  "\nmetadata bindings: "
  ^ RegionId.Map.to_string None Types.show_region_metadata_binding bindings
  ^ "\nnominal classifications: " ^ String.concat "\n" classifications
  ^ (if RegionId.Set.cardinal relevant >= 32 then
       "\nmetadata chains: 32-key diagnostic limit" else "")
  (* ``` *)

(*
```ocaml
*)
let diagnostic_runtime_erasure ctx bindings ty =
  try
    if not (RegionId.Map.is_empty bindings) then (
      let checked = ref RegionId.Set.empty in
      let rec check_alias active id =
        if RegionId.Set.mem id active then
          failwith ("Metadata alias cycle at region " ^ RegionId.to_string id)
        else if not (RegionId.Set.mem id !checked) then (
          (match RegionId.Map.find_opt id bindings with
          | Some (MetadataSource (RVar (Free source))) when source <> id ->
              check_alias (RegionId.Set.add id active) source
          | _ -> ());
          checked := RegionId.Set.add id !checked)
      in
      let visitor = object
        inherit [_] iter_ty
        method! visit_RVar _ = function
          | Free id -> check_alias RegionId.Set.empty id
          | Bound _ -> ()
      end in
      visitor#visit_ty () ty);
    Ok (ty_erase_regions_with_metadata ctx.type_ctx.type_infos bindings ty)
  with error -> Error (Printexc.to_string error)
(*
```
*)

(*
```ocaml
*)
(* ```ocaml *)
let diagnose_symbolic_runtime_type_transition span phase before after =
  let log = Logging.carrier_events_log in
  if !Config.print_error_emitters || !Config.print_error_diagnostics
     || Logging.L.Debug >= log#effective_level then
    let reported = ref false in
    let raw label text =
      let limit = 65536 in
      let length = String.length text in
      let shown = Stdlib.min limit length in
      let text = if shown = length then text else String.sub text 0 shown in
      Printf.eprintf "%s bytes=%d shown=%d:\n%s\n%!" label length shown text;
      if shown < length then
        Printf.eprintf "%s: truncated at the %d-character text limit\n%!" label limit
    in
    try
      iter_runtime_binding_values after (fun frame binder position tv ->
        if not !reported then
          match tv.value with
          | VSymbolic sv ->
              let erased =
                diagnostic_runtime_erasure after after.metadata_bindings sv.sv_ty
              in
              (match erased with
              | Ok erased when erased <> tv.ty ->
                  let previous = ref None in
                  iter_runtime_binding_values before
                    (fun old_frame old_binder old_position old_tv ->
                      if old_frame = frame && old_binder = binder
                         && old_position = position
                      then previous := Some old_tv);
                  let prior_incoherent =
                    match !previous with
                    | Some { value = VSymbolic old; ty } ->
                        (match diagnostic_runtime_erasure before
                                 before.metadata_bindings old.sv_ty with
                        | Ok old_erased -> old_erased <> ty
                        | Error _ -> true)
                    | Some _ | None -> false
                  in
                  if not prior_incoherent then (
                    reported := true;
                    Printf.eprintf
                      "Carrier symbolic first-incoherence interval: %s\nsource span: %s\n"
                      phase (Errors.span_to_string span);
                    raw "environment binding" (show_var_binder binder);
                    Printf.eprintf "frame index: %d\n%!" frame;
                    raw "physical position"
                      (String.concat "/"
                         (List.map show_value_path_step (List.rev position)));
                    let types (value : tvalue) =
                      match value.value with
                      | VSymbolic symbolic -> [symbolic.sv_ty; value.ty]
                      | _ -> [value.ty]
                    in
                    let relevant_types =
                      types tv
                      @ (match !previous with None -> [] | Some value -> types value)
                    in
                    let describe label (ctx : eval_ctx) (value : tvalue) =
                      raw (label ^ " concrete value") (show_tvalue value);
                      raw (label ^ " concrete ety") (Types.show_ty value.ty);
                      (match value.value with
                      | VSymbolic symbolic ->
                          Printf.eprintf "%s symbolic ID: %s\n%!" label
                            (SymbolicValueId.to_string symbolic.sv_id);
                          raw (label ^ " symbolic rty") (Types.show_ty symbolic.sv_ty);
                          (match diagnostic_runtime_erasure ctx ctx.metadata_bindings
                                   symbolic.sv_ty with
                          | Ok erased ->
                              raw (label ^ " symbolic erasure") (Types.show_ty erased);
                              Printf.eprintf "%s erasure equality: %b\n%!"
                                label (erased = value.ty)
                          | Error reason -> raw (label ^ " erasure error") reason)
                      | _ -> Printf.eprintf "%s symbolic ID: absent\n%!" label);
                      raw (label ^ " source chains and nominal roles")
                        (runtime_type_metadata_view ctx relevant_types)
                    in
                    (match !previous with
                    | None -> Printf.eprintf "before occurrence: absent\n%!"
                    | Some value -> describe "before" before value);
                    describe "after" after tv)
              | Ok _ | Error _ -> ())
          | _ -> ())
    with error ->
      raw "Carrier symbolic transition analysis unavailable"
        (Printexc.to_string error)
(* ``` *)
(*
```
*)

(** Auxiliary function to end borrows: lookup a *concrete* borrow in the
    environment, update it (by returning an updated environment where the borrow
    has been replaced by {!Bottom})) if we can end the borrow (for instance, it
    is not an outer borrow...) or return the reason why we couldn't update the
    borrow.

    We can end a borrow if:
    - it is not inside a borrow
    - it doesn't contain loans
    - it is not inside a region abstraction (it can happen if the borrow is
      inside a shared value)

    [end_borrow_aux] then simply performs a loop: as long as we need to end
    (outer) borrows, we end them, before finally ending the borrow we wanted to
    end in the first place.

    - [allowed_abs]: if not [None], allows to get a borrow in the given
      abstraction without ending the whole abstraction first. This parameter
      allows us to use {!end_borrow_aux} as an auxiliary function for
      {!end_abs_aux} (we end all the borrows in the abstraction one by one
      before removing the abstraction from the context). We use this to end
      shared borrows and mutable borrows inside of **shared values**; the other
      borrows are taken care of differently. *)
let end_concrete_borrow_get_borrow_core (span : Meta.span)
    (allowed_abs : AbsId.id option) (l : unique_borrow_id) (ctx : eval_ctx) :
    ( eval_ctx * (AbsId.id option * g_borrow_content) option,
      priority_borrow_or_abs )
    result =
  (* We use a reference to communicate the kind of borrow we found, if we
   * find one *)
  let replaced_bc : (AbsId.id option * g_borrow_content) option ref =
    ref None
  in
  let set_replaced_bc (abs_id : AbsId.id option) (bc : g_borrow_content) =
    [%sanity_check] span (Option.is_none !replaced_bc);
    replaced_bc := Some (abs_id, bc)
  in
  (* Raise an exception if:
     - there are outer borrows
     - if we are inside an abstraction
     - there are inner loans
     (this exception is caught in a wrapper function) *)
  let raise_if_priority (outer : outer) (borrowed_value : tvalue option) =
    (* First, look for outer borrows or abstraction *)
    (match outer.abs_id with
    | Some abs -> (
        if
          (* Check if we can end borrow inside this abstraction *)
          Some abs <> allowed_abs
        then raise (FoundPriority (OuterAbs (abs, outer.level)))
        else
          match outer.borrow_loan with
          | Some (MutBorrow bid) -> raise (FoundPriority (OuterMutBorrow bid))
          | Some (SharedLoan lid) -> raise (FoundPriority (OuterSharedLoan lid))
          | None -> ())
    | None -> (
        match outer.borrow_loan with
        | Some (MutBorrow bid) -> raise (FoundPriority (OuterMutBorrow bid))
        | Some (SharedLoan lid) -> raise (FoundPriority (OuterSharedLoan lid))
        | None -> ()));
    (* Then check if there are inner loans *)
    match borrowed_value with
    | None -> ()
    | Some v -> (
        match get_first_loan_in_value v with
        | None -> ()
        | Some c -> (
            match c with
            | VSharedLoan (bid, _) -> raise (FoundPriority (InnerLoan bid))
            | VMutLoan bid -> raise (FoundPriority (InnerLoan bid))))
  in
  let incr_level (outer : outer) : outer =
    { outer with level = outer.level + 1 }
  in

  (* The environment in the visitor is used to keep track of the first
     outer shared loan or mutable borrow we dived into (because we need to
     end it before ending the target borrow). *)
  let visitor =
    object (self)
      inherit [_] map_eval_ctx as super

      (** We reimplement {!visit_Loan} because we may have to update the outer
          borrows *)
      method! visit_VLoan (outer : outer) lc =
        match lc with
        | VMutLoan bid -> VLoan (self#visit_VMutLoan outer bid)
        | VSharedLoan (bid, v) ->
            (* Remember the outer loan before diving into the shared value,
               in case we haven't dived into a borrow/loan yet. *)
            let outer = update_outer_borrow outer (SharedLoan bid) in
            VLoan (self#visit_VSharedLoan outer bid v)

      method! visit_VBorrow (outer : outer) bc =
        match bc with
        | VSharedBorrow (bid, l') | VReservedMutBorrow (bid, l') ->
            (* Check if this is the borrow we are looking for *)
            if l = UShared (bid, l') then (
              (* Check if there are outer borrows or if we are inside an abstraction *)
              raise_if_priority outer None;
              (* Register the update *)
              set_replaced_bc outer.abs_id (Concrete bc);
              (* Update the value *)
              VBottom)
            else super#visit_VBorrow outer bc
        | VMutBorrow (l', bv) ->
            (* Check if this is the borrow we are looking for *)
            if l = UMut l' then (
              (* Check if there are outer borrows or if we are inside an abstraction *)
              raise_if_priority outer (Some bv);
              (* Register the update *)
              set_replaced_bc outer.abs_id (Concrete bc);
              (* Update the value *)
              VBottom)
            else
              (* Remember the outer borrow before diving into the shared value,
               in case we haven't dived into a borrow/loan yet. *)
              let outer = update_outer_borrow outer (MutBorrow l') in
              VBorrow (self#visit_VMutBorrow outer l' bv)

      (** We reimplement {!visit_ALoan} because we may have to update the outer
          borrows *)
      method! visit_ALoan outer lc =
        (* Note that the children avalues are just other, independent loans,
         * so we don't need to update the outer borrows when diving in.
         * We keep track of the parents/children relationship only because we
         * need it to properly instantiate the backward functions when generating
         * the pure translation. *)
        match lc with
        | AMutLoan (pm, _, _) ->
            [%sanity_check] span (pm = PNone);
            (* Nothing special to do *)
            super#visit_ALoan outer lc
        | ASharedLoan (pm, bid, v, av) ->
            [%sanity_check] span (pm = PNone);
            (* Explore the shared value - we need to update the outer borrows *)
            let souter = update_outer_borrow outer (SharedLoan bid) in
            (* Also note that we are diving into a shared **loan**: we can forget
               about the region abstraction when diving into the shared value
               (because we can end a loan without ending the region abstraction
               itself) *)
            let v = self#visit_tvalue { souter with abs_id = None } v in
            (* Explore the child avalue - we keep the same outer borrows *)
            let av = self#visit_tavalue outer av in
            (* Reconstruct *)
            ALoan (ASharedLoan (pm, bid, v, av))
        | AEndedMutLoan { given_back; child; given_back_meta } ->
            let given_back = self#visit_tavalue (incr_level outer) given_back in
            let child = self#visit_tavalue outer child in
            ALoan (AEndedMutLoan { given_back; child; given_back_meta })
        | AEndedSharedLoan (pm, sv, av) ->
            (* The ended shared loan no longer protects the payload, but any
               enclosing mutable borrow or shared loan still does. *)
            let sv = self#visit_tvalue { outer with abs_id = None } sv in
            (* Explore the child avalue - we keep the same outer borrows *)
            let av = self#visit_tavalue outer av in
            (* Reconstruct *)
            ALoan (AEndedSharedLoan (pm, sv, av))
        (* The loan has ended, so no need to update the outer borrows *)
        | AIgnoredMutLoan _ (* Nothing special to do *)
        (* Nothing special to do *)
        | AIgnoredSharedLoan _ ->
            (* Nothing special to do *)
            super#visit_ALoan outer lc
        | AEndedIgnoredMutLoan lc ->
            let given_back =
              self#visit_tavalue (incr_level outer) lc.given_back
            in
            let child = self#visit_tavalue outer lc.child in
            ALoan (AEndedIgnoredMutLoan { lc with given_back; child })

      method! visit_ABorrow outer bc =
        match bc with
        | AMutBorrow (pm, bid, _) ->
            [%sanity_check] span (pm = PNone);
            (* Check if this is the borrow we are looking for *)
            if UMut bid = l then (
              (* Signal that we should replace the whole abstraction *)
              raise_if_priority outer None;
              (* We shouldn't get there: this should be taken care of elsewhere *)
              [%craise] span "Unreachable")
            else
              (* Update the outer borrows before diving into the child avalue *)
              let outer = update_outer_borrow outer (MutBorrow bid) in
              super#visit_ABorrow outer bc
        | ASharedBorrow (pm, bid, sid) ->
            [%sanity_check] span (pm = PNone);
            (* Check if this is the borrow we are looking for *)
            if UShared (bid, sid) = l then (
              (* Check there are outer borrows, or if we need to end the whole
               * abstraction *)
              raise_if_priority outer None;
              (* Register the update *)
              set_replaced_bc outer.abs_id (Abstract bc);
              (* Update the value - note that we are necessarily in the second
                 of the two cases described above *)
              ABorrow AEndedSharedBorrow)
            else super#visit_ABorrow outer bc
        | AIgnoredMutBorrow _ | AEndedSharedBorrow ->
            (* Nothing special to do *)
            super#visit_ABorrow outer bc
        | AEndedMutBorrow (meta, given_back) ->
            (* We need to increase the level when diving into the given back value *)
            let given_back = self#visit_tavalue (incr_level outer) given_back in
            ABorrow (AEndedMutBorrow (meta, given_back))
        | AEndedIgnoredMutBorrow { given_back; child; given_back_meta } ->
            (* We need to increase the level when diving into the given back value *)
            let given_back = self#visit_tavalue (incr_level outer) given_back in
            let child = self#visit_tavalue outer child in
            ABorrow
              (AEndedIgnoredMutBorrow { given_back; child; given_back_meta })
        | AProjSharedBorrow (pm, asb) -> (
            (* Check if the borrow we are looking for is in the asb *)
            match l with
            | UShared (_, l) ->
                if borrow_in_asb l asb then (
                  (* Check there are outer borrows, or if we need to end the whole
                   * abstraction *)
                  raise_if_priority outer None;
                  (* Register the update *)
                  set_replaced_bc outer.abs_id (Abstract bc);
                  (* Update the value - note that we are necessarily in the second
                   * of the two cases described above *)
                  let asb = remove_borrow_from_asb span l asb in
                  ABorrow (AProjSharedBorrow (pm, asb)))
                else (* Nothing special to do *)
                  super#visit_ABorrow outer bc
            | UMut _ -> super#visit_ABorrow outer bc)

      method! visit_abs outer abs =
        (* Update the outer abs *)
        [%sanity_check] span (Option.is_none outer.abs_id);
        [%sanity_check] span (Option.is_none outer.borrow_loan);
        let outer =
          { abs_id = Some abs.abs_id; level = 0; borrow_loan = None }
        in
        super#visit_abs outer abs
    end
  in
  (* Catch the exceptions - raised if there are outer borrows *)
  try
    let ctx =
      visitor#visit_eval_ctx
        { abs_id = None; level = 0; borrow_loan = None }
        ctx
    in
    Ok (ctx, !replaced_bc)
  with FoundPriority outers -> Error outers

(** We want to end a symbolic projection: look for *concrete* occurrences of the
    symbolic value and check whether they are inside borrows/loans that need to
    be ended first. *)
let end_proj_loan_get_concrete_priority (_span : Meta.span)
    (sid : symbolic_value_id) (ctx : eval_ctx) :
    mut_borrow_or_shared_loan_id option =
  let found_outer : mut_borrow_or_shared_loan_id option ref = ref None in
  (* Raise an exception if there is an outer borrow/loan *)
  let raise_if_outer (outer : mut_borrow_or_shared_loan_id option) =
    match outer with
    | None -> ()
    | Some outer ->
        found_outer := Some outer;
        raise Found
  in

  let update_outer (opt_outer : mut_borrow_or_shared_loan_id option)
      (outer : mut_borrow_or_shared_loan_id) =
    match opt_outer with
    | None -> Some outer
    | Some outer -> Some outer
  in

  (* The environment in the visitor is used to keep track of the first
     outer shared loan or mutable borrow we dived into (because we need to
     end it before ending the target borrow). *)
  let visitor =
    object (self)
      inherit [_] iter_eval_ctx

      method! visit_VSymbolic outer sv =
        if sv.sv_id = sid then raise_if_outer outer

      (** We reimplement {!visit_Loan} because we may have to update the outer
          borrows *)
      method! visit_VLoan (outer : mut_borrow_or_shared_loan_id option) lc =
        match lc with
        | VMutLoan _ -> ()
        | VSharedLoan (bid, v) ->
            let outer = update_outer outer (SharedLoan bid) in
            self#visit_tvalue outer v

      method! visit_VBorrow (outer : mut_borrow_or_shared_loan_id option) bc =
        match bc with
        | VSharedBorrow _ | VReservedMutBorrow _ -> ()
        | VMutBorrow (bid, bv) ->
            let outer = update_outer outer (MutBorrow bid) in
            self#visit_tvalue outer bv

      (** There can be concrete values in shared loans *)
      method! visit_ASharedLoan outer _pm bid v child =
        self#visit_tvalue (update_outer outer (SharedLoan bid)) v;
        self#visit_tavalue outer child
    end
  in
  (* Catch the exceptions - raised if there are outer borrows/loans *)
  try
    visitor#visit_eval_ctx None ctx;
    None
  with Found -> Some (Option.get !found_outer)

(** See [end_borrow_get_borrow] *)
let end_concrete_borrow_get_borrow (span : Meta.span) (l : unique_borrow_id)
    (ctx : eval_ctx) :
    ( eval_ctx * (AbsId.id option * g_borrow_content) option,
      priority_borrow_or_abs )
    result =
  end_concrete_borrow_get_borrow_core span None l ctx

let end_concrete_borrow_in_abs_get_borrow (span : Meta.span) (abs_id : abs_id)
    (l : unique_borrow_id) (ctx : eval_ctx) :
    ( eval_ctx * (AbsId.id option * g_borrow_content) option,
      priority_borrow_or_abs )
    result =
  end_concrete_borrow_get_borrow_core span (Some abs_id) l ctx

(** Auxiliary function to end borrows. See {!give_back_concrete}.

    When we end a mutable borrow, we need to "give back" the value it contained
    to its original owner by reinserting it at the proper position.

    Note that this function checks that there is exactly one loan to which we
    give the value back. TODO: this was not the case before, so some sanity
    checks are not useful anymore.

    Also, we take care to also update the **abstraction expressions**. *)
(*
```ocaml
*)
(*
```ocaml
*)
let rec input_return_route_ty ctx ty = function
  | [] -> Some ty
  | PDeref :: route ->
      (match ty with
       | TRef (_, inner, RMut) -> input_return_route_ty ctx inner route
       | _ -> None)
  | PField (variant, index) :: route ->
      let fields = match ty with
        | TAdt { id = TAdtId id; generics } ->
            Some (Substitute.type_decl_get_instantiated_field_types
              (TypeDeclId.Map.find id ctx.type_ctx.type_decls) variant generics)
        | TAdt { id = TTuple; generics } -> Some generics.types
        | _ -> None in
      Option.bind fields (fun fields ->
        Option.bind (List.nth_opt fields index)
          (fun ty -> input_return_route_ty ctx ty route))

(*
```ocaml
*)
let rec call_input_value_at_path (value : tvalue) = function
  | [] -> Some value
  | PDeref :: rest ->
      (match value.value with
       | VBorrow (VMutBorrow (_, child)) -> call_input_value_at_path child rest
       | _ -> None)
  | PField (variant, index) :: rest ->
      (match value.value with
       | VAdt actual when actual.variant_id = variant ->
           Option.bind (List.nth_opt actual.fields index)
             (fun child -> call_input_value_at_path child rest)
       | _ -> None)

let call_input_borrow_reference span ctx (proof : call_input_correspondence) bid =
  let paths =
    match List.rev proof.input_path with
    | PDeref :: rest -> [ proof.input_path; List.rev rest ]
    | _ -> [ proof.input_path ] in
  let references = List.filter_map
    (fun path ->
      match call_input_value_at_path proof.input_value path,
        input_return_route_ty ctx proof.instantiated_input path with
      | Some { value = VBorrow (VMutBorrow (actual, _)); _ },
        Some (TRef (_, payload, RMut) as reference) when actual = bid ->
          Some (reference, payload)
      | _ -> None)
    paths |> List.sort_uniq Stdlib.compare in
  match references with
  | [ reference ] -> Some reference
  | [] -> None
  | _ -> [%craise] span "A call input has different physical borrower views"
(*
```
*)

(*
```ocaml
*)
(* ```ocaml *)
let call_input_actual_path (proof : call_input_correspondence) canonical_path =
  let rec suffix prefix path =
    match prefix, path with
    | [], path -> Some path
    | head :: prefix, actual :: path when head = actual -> suffix prefix path
    | _ -> None
  in
  Option.map (fun relative -> proof.input_path @ relative)
    (suffix proof.input_source_path canonical_path)
(* ``` *)

let register_call_input_correspondences span ctx call_id target
    (signature : fun_sig) (instantiated : LlbcAst.inst_fun_sig) args =
  let rec matches witnesses visited (source : symbolic_value) (value : tvalue) =
    if SymbolicValueId.Set.mem source.sv_id visited then false
    else
      match value.value with
      | VSymbolic actual -> actual = source
      | VLoan (VSharedLoan (_, child)) -> matches witnesses visited source child
      | _ ->
          let visited = SymbolicValueId.Set.add source.sv_id visited in
          let expansions = List.filter_map
            (fun (parent, expansion) -> if parent = source then Some expansion else None)
            witnesses.expansions |> List.sort_uniq Stdlib.compare in
          [%cassert] span (List.length expansions <= 1)
            "A call operand has different source expansions";
          match expansions, value.value with
          | [ SeAdt (variant, fields) ], VAdt actual ->
              variant = actual.variant_id && List.length fields = List.length actual.fields
              && List.for_all2 (matches witnesses visited) fields actual.fields
          | [ SeMutRef (borrow, _) ], VBorrow (VMutBorrow (actual, _)) ->
              borrow = actual
              || (match lookup_borrow_opt span
                   { enter_shared_loans = true; enter_mut_borrows = true; enter_abs = false }
                   (UMut borrow) ctx with
                  | Some (Concrete (VMutBorrow (_, { value = VLoan (VMutLoan loan); _ }))) ->
                      loan = actual
                  | _ -> false)
          | [ SeSharedRef (borrow, _) ], VBorrow (VSharedBorrow (actual, _)) ->
              borrow = actual
          | [ SeLiteral literal ], VLiteral actual -> literal = actual
          | _ -> false
  in
(* ```ocaml *)
  let rec source_paths witnesses source path (value : tvalue) ty =
    if matches witnesses SymbolicValueId.Set.empty source value then [ (path, ty) ]
    else
      match value.value, ty with
      | VBorrow (VMutBorrow (_, child)), TRef (_, inner, RMut) ->
          source_paths witnesses source (path @ [ PDeref ]) child inner
      | VLoan (VSharedLoan (_, child)), _ ->
          source_paths witnesses source path child ty
      | VAdt actual, TAdt { id; generics } ->
          let fields = ctx_adt_get_instantiated_field_types span ctx id
            actual.variant_id generics in
          [%cassert] span (List.length fields = List.length actual.fields)
            "A call source changes its declared field positions";
          List.concat (List.mapi
            (fun index child ->
              source_paths witnesses source
                (path @ [ PField (actual.variant_id, index) ]) child
                (List.nth fields index))
            actual.fields)
      | _ -> []
  in

(* ```ocaml *)
  let rec declared_views witnesses visited path (source : symbolic_value) =
    if SymbolicValueId.Set.mem source.sv_id visited then []
    else
      let visited = SymbolicValueId.Set.add source.sv_id visited in
      let expansions = witnesses.expansions
        |> List.filter_map (fun (parent, expansion) ->
          if parent = source then Some expansion else None)
        |> List.sort_uniq Stdlib.compare in
      [%cassert] span (List.length expansions <= 1)
        "A call source has different retained expansion records";
      let children = match expansions with
        | [ SeMutRef (_, child) ] | [ SeSharedRef (_, child) ] ->
            declared_views witnesses visited (path @ [ PDeref ]) child
        | [ SeAdt (variant, fields) ] ->
            List.concat (List.mapi (fun index child ->
              declared_views witnesses visited (path @ [ PField (variant, index) ]) child)
              fields)
        | _ -> [] in
      (path, source) :: children
  in
(* ``` *)

(* ``` *)
  let inputs = List.mapi
    (fun index (value, (declared, instantiated)) ->
      (index, value, declared, instantiated))
    (List.combine args (List.combine signature.inputs instantiated.inputs)) in
  let input_owners = List.map
    (fun (group : LlbcAst.abs_region_group) ->
      (group.id, RegionId.Set.of_list group.regions))
    instantiated.abs_regions_hierarchy in
(*
```ocaml
*)
  let cache = ref [] in
  let update_witnesses witnesses =
    match List.find_opt (fun (original, _) -> original == witnesses) !cache with
    | Some (_, mapped) -> mapped
    | None ->
      let additional = List.concat_map
        (fun (origin : carrier_origin) ->
(* ```ocaml *)

(* ```ocaml *)
          List.concat_map (fun (source_path, source) ->
            List.concat_map
              (fun (index, value, declared_input, instantiated_input) ->
                List.map
                  (fun (input_path, source_ty) ->
                    let relation = projection_metadata_renaming span
                      ctx.type_ctx.type_infos source.sv_ty source_ty in
                    { input_call = call_id; input_target = target;
                      input_index = index; declared_input;
                      input_root = origin.transport_root; input_origin = origin;
                      input_source = source; input_source_path = source_path; input_path;
                      instantiated_input; input_value = value; input_owners;
                      input_relation = RegionId.Map.bindings relation })
                  (source_paths witnesses source [] value instantiated_input))
              inputs)
            (declared_views witnesses SymbolicValueId.Set.empty [] origin.transport_root))
(* ``` *)

(* ``` *)
        witnesses.carrier_origins in
      let mapped =
        if additional = [] then witnesses
        else { witnesses with input_correspondences =
          List.sort_uniq Stdlib.compare (additional @ witnesses.input_correspondences) }
      in
      cache := (witnesses, mapped) :: !cache;
      mapped
  in
  let rec update_input (value : tevalue) =
    match value.value with
    | ECallProtocol (positions, body) ->
        let mapped = update_input body in
        if mapped == body then value
        else { value with value = ECallProtocol (positions, mapped) }
    | ECallEndpoints (witnesses, body) ->
        let mapped = update_witnesses witnesses in
        if mapped == witnesses then value
        else { value with value = ECallEndpoints (mapped, body) }
    | _ -> value
  in
  let replacements = List.filter_map
    (function
      | EAbs abs when abs.call_scopes <> [] ->
          let scopes = List.map
            (map_call_scope_witnesses update_witnesses) abs.call_scopes in
          if List.for_all2 ( == ) scopes abs.call_scopes then None
          else
            let cont = Option.map
              (fun cont -> { cont with input = Option.map update_input cont.input }) abs.cont in
(*
```ocaml
*)
            Some (abs.abs_id, { abs with call_scopes = scopes; cont })
(*
```
*)
      | _ -> None)
    ctx.env in
  if replacements = [] then ctx
  else { ctx with env = List.map
    (function
      | EAbs abs as original ->
          (match List.assoc_opt abs.abs_id replacements with
           | Some mapped -> EAbs mapped
           | None -> original)
      | original -> original) ctx.env }
(*
```
*)
(*
```
*)


(*
```ocaml
*)
let input_return_declared_source ?final_borrow span expansions source position =
  let rec visit visited (source : symbolic_value) position =
    match position with
    | [] -> if Option.is_none final_borrow then Some source else None
    | _ when SymbolicValueId.Set.mem source.sv_id visited -> None
    | step :: rest ->
        let visited = SymbolicValueId.Set.add source.sv_id visited in
        let expansions = expansions
          |> List.filter_map (fun (parent, expansion) ->
               if parent = source then Some expansion else None)
          |> List.sort_uniq Stdlib.compare in
        let () = [%cassert] span (List.length expansions <= 1)
          "A physical parent source has different expansion records" in
        (match expansions, step with
         | [ SeMutRef (borrow, child) ], PDeref when rest = [] ->
             if Option.fold ~none:true ~some:(( = ) borrow) final_borrow
             then Some child else None
         | [ SeSharedRef (_, child) ], PDeref when rest = [] ->
             if Option.is_none final_borrow then Some child else None
         | [ SeMutRef (_, child) ], PDeref
         | [ SeSharedRef (_, child) ], PDeref ->
             visit visited child rest
         | [ SeAdt (variant, fields) ], PField (expected, index)
             when variant = expected ->
             Option.bind (List.nth_opt fields index)
               (fun child -> visit visited child rest)
         | _ -> None)
  in
  visit SymbolicValueId.Set.empty source position

(*
```
*)

let capture_input_physical_return span ctx (abs : abs)
    (witnesses : call_endpoint_witnesses) bid (nv : tvalue) supplier =
  let captures = ref [] in
(*
```ocaml
*)
  let parent_routes = ref [] in
(*
```
*)
(* ```ocaml *)
(*
```ocaml
*)
  let route_ty = input_return_route_ty ctx in
(*
```
*)
  let rec route_suffix prefix route =
    match prefix, route with
    | [], route -> Some route
    | first :: prefix, next :: route when first = next ->
        route_suffix prefix route
    | _ -> None in
  let actual_ty = match nv.value with
    | VSymbolic source -> source.sv_ty
    | _ -> nv.ty in
(*
```ocaml
*)
(*
```ocaml
*)
  let ordinary_supplier (origin : carrier_origin) payload_ty returned_at =
    match origin.source_role, nv.value, supplier with
    | OrdinaryCallOutputOrigin declaration, VSymbolic current,
      AbstractionInputReturn (owner, _, supplied, owned, _) ->
        let receiver_kind = FunCall (declaration.output_call, origin.region_group) in
        [%cassert] span
          (declaration.instantiated_output = origin.original_root.sv_ty
           && origin.original_root = origin.transport_root
           && supplied = current)
          "An ordinary return changes its declared output carrier";
        let reference_path = match List.rev returned_at with
          | PDeref :: path -> Some (List.rev path)
          | _ -> None in
        let source_reference = Option.bind reference_path
          (input_return_declared_source span witnesses.expansions origin.transport_root) in
        let source_edge = Option.fold ~none:false
          ~some:(fun (source : symbolic_value) ->
            List.exists (fun (parent, expansion) ->
              parent = source && match expansion with
              | SeMutRef (borrow, payload) ->
                  borrow = bid && payload.sv_ty = payload_ty
              | _ -> false) witnesses.expansions)
          source_reference in
        if not source_edge || origin.source_owner <> abs.abs_id then None
        else begin
          let canonical = ctx_lookup_abs ctx origin.source_owner in
          [%cassert] span (canonical.kind = receiver_kind)
            "An applicable ordinary return changes its declared owner";
          [%cassert] span
            (origin.source_owner = abs.abs_id && abs.kind = receiver_kind)
            "An applicable ordinary return changes its execution receiver";
          let proofs = List.filter
            (fun proof ->

(* ```ocaml *)
              proof.input_origin = origin && proof.input_root = origin.transport_root
              && proof.input_source_path = [] && proof.input_path = []
(* ``` *)

              && List.assoc_opt owner proof.input_owners = Some owned
              && (match (ctx_lookup_abs ctx owner).kind with
                  | FunCall (call, _) -> call = proof.input_call
                  | _ -> false))
            witnesses.input_correspondences in
          let proofs = List.filter
            (fun proof ->
              let relation = RegionId.Map.of_list proof.input_relation in
              let mapped = projection_metadata_renaming span ctx.type_ctx.type_infos
                origin.transport_root.sv_ty proof.instantiated_input in
              [%cassert] span (RegionId.Map.equal (=) relation mapped)
                "An ordinary return changes its declared input coordinates";
              match reference_path with
              | None -> false
              | Some path ->
                  match route_ty proof.instantiated_input path,
                    route_ty proof.instantiated_input returned_at with
                  | Some (TRef (_, expected, RMut) as reference), Some payload
                      when expected = payload && payload = current.sv_ty ->
                      let ended = ref 0 in
                      let visitor = object
                        inherit [_] iter_tavalue as super
                        method! visit_tavalue env value =
                          (match value.value with
                           | ABorrow (AEndedMutBorrow (meta, child))
                               when meta.bid = bid ->
                               [%cassert] span
                                 (meta.given_back = current && child.ty = payload
                                  && value.ty = reference)
                                 "An ordinary return changes its actual ended borrower";
                               incr ended
                           | _ -> ());
                          super#visit_tavalue env value
                      end in
                      List.iter (visitor#visit_tavalue ()) (ctx_lookup_abs ctx owner).avalues;
                      !ended = 1
                  | _ -> false)
            proofs |> List.sort_uniq Stdlib.compare in
          (match proofs with
           | [] -> None
           | [ proof ] -> Some (DeclaredCallInputReturn (proof, supplier))
           | _ -> [%craise] span "An ordinary return has different declared input carriers")
        end
    | _ -> None
  in
(* ```ocaml *)
  let function_supplier (origin : carrier_origin) payload_ty returned_at =
    match origin.source_role, nv.value, supplier with
    | FunctionInputOrigin _, VSymbolic current,
      AbstractionInputReturn (owner, level, supplied, owned, endpoint) ->
        check_function_input_interface span ctx witnesses origin
          (ctx_lookup_abs ctx origin.source_owner);
        [%cassert] span (supplied = current)
          "A function input return changes its supplied symbol";
        let actual_owner = ctx_lookup_abs ctx owner in
        let selected = ref actual_owner.regions.owned in
        let ended = ref 0 in
        let visitor = object (self)
          inherit [_] iter_abs_with_levels as super
          method incr_level level = level + 1
          method! visit_ATransportedProj env transport child =
            let previous = !selected in
            selected := transport.current_regions;
            self#visit_aproj env child;
            selected := previous
          method! visit_ATransportedValue env transport child =
            let previous = !selected in
            selected := transport.current_regions;
            self#visit_tavalue env child;
            selected := previous
          method! visit_tavalue env value =
            (match value.value with
             | ABorrow (AEndedMutBorrow (meta, child)) when meta.bid = bid ->
                 [%cassert] span
                   (env = level && meta.given_back = current
                    && child.ty = current.sv_ty
                    && RegionId.Set.equal owned !selected
                    && match value.ty with
                       | TRef (region, payload, RMut) ->
                           payload = current.sv_ty && region_in_set region owned
                       | _ -> false)
                   "A function input return changes its actual ended borrower";
                 incr ended
             | _ -> ());
            super#visit_tavalue env value
        end in
        visitor#visit_abs 0 actual_owner;
        [%cassert] span (!ended = 1)
          "A function input return lacks its unique actual ended borrower";
        Option.iter
          (fun (endpoint : tevalue) ->
            [%cassert] span
              (endpoint.ty = current.sv_ty
               && match endpoint.value with
                  | EBorrow (EEndedMutBorrow (meta, child)) ->
                      meta.bid = bid && meta.given_back = current
                      && child.ty = current.sv_ty
                  | _ -> false)
              "A function input return changes its actual ended endpoint")
          endpoint;
        Some (projection_metadata_renaming span ctx.type_ctx.type_infos
          payload_ty current.sv_ty)
(*
```ocaml
*)
    | FunctionInputOrigin _, VSymbolic current, ConcreteInputReturn (borrow, endpoint) ->
        check_function_input_interface span ctx witnesses origin
          (ctx_lookup_abs ctx origin.source_owner);
        [%cassert] span
          (borrow = bid
           && match endpoint.value with EValue (_, value) -> value = nv | _ -> false)
          "A function input return changes its complete concrete supplier";
        let routes = match input_return_declared_source ~final_borrow:bid
          span witnesses.expansions origin.transport_root returned_at with
          | None -> []
          | Some source ->
              witnesses.return_routes |> List.filter (fun (route : input_return_route) ->
                route.route_origin = origin && route.route_branch = PNone
                && route.route_position = returned_at
                && route.route_source = { sv_id = source.sv_id; proj_ty = payload_ty }
                && source.sv_ty = payload_ty
                && route.route_current = current
                && Option.fold ~none:false ~some:(fun upstream ->
                  upstream <> bid
                  && (match input_return_supplier_producer route.route_supplier with
                    | AbstractionInputReturn (_, _, supplied, _, Some endpoint) ->
                        supplied = current
                        && endpoint.ty = current.sv_ty
                        && (match endpoint.value with
                          | EBorrow (EEndedMutBorrow (meta, child)) ->
                              meta.bid = upstream && meta.given_back = current
                              && child.ty = current.sv_ty
                          | _ -> false)
                    | _ -> false)
                  && List.exists (fun (receipt : input_physical_return) ->
                    receipt.origin = origin
                    && receipt.returned_borrow = Some upstream
                    && receipt.returned_at = returned_at
                    && receipt.full_return_ty = payload_ty
                    && receipt.current_payload = nv
                    && receipt.supplier = route.route_supplier)
                    witnesses.physical_returns)
                  route.route_loan)
              |> List.sort_uniq Stdlib.compare in
        let retained = match routes with
          | [] -> None
          | [ route ] ->
              let coordinates = RegionId.Map.of_list route.route_relation in
              (* Retained routes map stored coordinates, not resolved aliases. *)
              [%cassert] span
                (compare_ty_regions span ctx (lazy coordinates) true ( && )
                   (fun original actual ->
                     rename_projection_metadata_region coordinates original = actual)
                   payload_ty current.sv_ty)
                "A concrete parent return changes its retained coordinate proof";
              Some coordinates
          | _ -> [%craise] span "A concrete parent return has different upstream suppliers" in
        let proofs = List.filter
          (fun (proof : call_input_correspondence) ->

(* ```ocaml *)
            proof.input_origin = origin && proof.input_root = origin.transport_root
(* ``` *)

            && (match call_input_borrow_reference span ctx proof bid with
                | Some (_, payload) -> payload = current.sv_ty
                | None -> false)

(* ```ocaml *)
            && Option.bind (call_input_actual_path proof returned_at)
                 (input_return_route_ty ctx proof.instantiated_input) = Some current.sv_ty
(* ``` *)

            && projection_metadata_types_equal ctx
                 (RegionId.Map.of_list proof.input_relation) payload_ty current.sv_ty)
          witnesses.input_correspondences |> List.sort_uniq Stdlib.compare in
        (match retained, proofs with
         | Some coordinates, _ -> Some coordinates
         | None, [] -> None
         | None, [ proof ] -> Some (RegionId.Map.of_list proof.input_relation)
         | None, _ -> [%craise] span "A concrete input return has different declared suppliers")
(*
```
*)
    | _ -> None
  in
(* ``` *)
(*
```
*)
(*
```
*)
(* ``` *)
(*
```ocaml
*)
  let rec visit (origin : carrier_origin) path (value : tavalue) =
    let child step child = visit origin (path @ [ step ]) child in
(* ```ocaml *)
(* ``` *)
    let capture branch payload_ty returned_at =
      [%cassert] span
        (ty_erase_regions_with_metadata ctx.type_ctx.type_infos
           ctx.metadata_bindings payload_ty = nv.ty)
        "A physical input return has a different payload type";
(* ```ocaml *)
(*
```ocaml
*)
(* ```ocaml *)
      let ordinary = ordinary_supplier origin payload_ty returned_at in
      let function_coordinates = function_supplier origin payload_ty returned_at in
      let relation = Option.is_some ordinary || Option.is_some function_coordinates
        || projection_metadata_types_equal ctx RegionId.Map.empty actual_ty payload_ty in
      let receipt_supplier = Option.value ordinary ~default:supplier in
      let coordinates = match ordinary with
        | Some (DeclaredCallInputReturn (proof, _)) ->
            RegionId.Map.of_list proof.input_relation
        | _ -> Option.value function_coordinates ~default:RegionId.Map.empty in
(* ``` *)
      let declared_route = route_ty origin.transport_root.sv_ty returned_at in
(* ``` *)
(*
```ocaml
*)
      let () =
        match relation, declared_route, nv.value,
          input_return_supplier_owner supplier with
        | true, Some declared, VSymbolic current, Some owner
            when declared = payload_ty ->
            Option.iter (fun (source : symbolic_value) ->
              [%cassert] span (source.sv_ty = payload_ty)
                "A physical parent changes its declared source view";
              let transport = projection_metadata_renaming span
                ctx.type_ctx.type_infos payload_ty current.sv_ty in
              let route = {
                route_origin = origin; route_branch = branch;
                route_position = returned_at;
                route_source = { sv_id = source.sv_id; proj_ty = payload_ty };
                route_current = current; route_supplier = supplier;
                route_kind = (ctx_lookup_abs ctx owner).kind;
                route_relation = RegionId.Map.bindings transport;
                route_loan = Some bid; route_previous = None;
(*
```ocaml
*)
                route_physical_parents = [];
(*
```
*)
              } in
              parent_routes := route :: !parent_routes;
              let producer_level, producer_owned = match supplier with
                | AbstractionInputReturn (_, level, _, owned, _)
                | SymbolicInputReturn (_, level, _, _, owned, _) -> level, owned
                | ConcreteInputReturn _ | FieldInputReturn _ | DeclaredCallInputReturn _ ->
                    [%internal_error] span in
              let log = Logging.carrier_events_log in
              [%ldebug
                "Carrier physical parent return event:\nloan: "
                ^ BorrowId.to_string bid ^ "\nsource: "
                ^ show_symbolic_proj route.route_source ^ "\ncurrent return: "
                ^ show_symbolic_value current ^ "\nproducer owner: "
                ^ AbsId.to_string owner ^ "\nproducer kind: "
                ^ show_abs_kind route.route_kind ^ "\nbranch: "
                ^ show_proj_marker branch ^ "\nposition: "
                ^ String.concat "/" (List.map show_value_path_step returned_at)
                ^ "\nproducer level: " ^ string_of_int producer_level
                ^ "\nproducer owned mask: "
                ^ RegionId.Set.to_string None producer_owned
                ^ "\norigin: " ^ show_carrier_origin origin
                ^ "\nregion relation: "
                ^ RegionId.Map.to_string None Types.show_region transport])
              (input_return_declared_source span witnesses.expansions
                 origin.transport_root returned_at)
        | _ -> ()
      in
(*
```
*)
      let slots = List.filter_map
        (function
          | PendingParameterScope scope ->
              if scope.slot.root_sv_id = origin.transport_root.sv_id
                 || scope.slot.root_sv_id = origin.original_root.sv_id
              then Some (PendingParameterSlot scope.slot) else None
          | PhysicalInputScope scope ->
              if scope.physical_slot.origin = origin
              then Some (PhysicalInputSlot scope.physical_slot) else None)
        abs.call_scopes |> List.sort_uniq Stdlib.compare in
(* ```ocaml *)
      List.iter (fun slot ->
        let coverage = match declared_route,
          route_suffix returned_at (carrier_slot_path slot) with
          | Some declared, Some suffix when declared = payload_ty ->
              (match route_ty actual_ty suffix, route_ty declared suffix with
               | Some actual, Some expected ->
                   let compatible = compare_ty_regions span ctx
                     (lazy coordinates) true ( && )
                     (fun original current ->
                       rename_projection_metadata_region coordinates original
                       = current)
                     expected actual in
                   let covered = compatible
                     && RegionId.Set.equal
                          (RegionId.Set.map
                            (fun region ->
                              match RegionId.Map.find_opt region coordinates with
                              | Some (RVar (Free destination)) -> destination
                              | None -> region
                              | _ -> [%craise] span "A return coordinate is not a physical region")
                            (carrier_slot_regions slot))
                          (ty_regions ctx.type_ctx.type_infos actual) in
                   let () =
                     if relation && not (compatible && covered)
                        && (!Config.print_error_diagnostics || !Config.print_error_emitters) then
                       Printf.eprintf
                         "Physical payload relation:\nexpected: %s\nactual: %s\nstored mapped: %s\nresolved expected: %s\nresolved actual: %s\ncoordinates: %s\nsource mask: %s\nmetadata compatible: %b\n%!"
                         (Types.show_ty expected) (Types.show_ty actual)
                         (Types.show_ty (map_free_region_aliases
                            (rename_projection_metadata_region coordinates) expected))
                         (Types.show_ty (resolve_projection_metadata_ty ctx expected))
                         (Types.show_ty (resolve_projection_metadata_ty ctx actual))
                         (RegionId.Map.to_string None Types.show_region coordinates)
                         (RegionId.Set.to_string None (carrier_slot_regions slot)) compatible in
                   compatible && covered
               | _ -> false)
          | _ -> false in
        if relation && coverage then
          captures := ({ origin; slot; branch; returned_borrow = Some bid;
            returned_at; full_return_ty = payload_ty; current_payload = nv;
(* ```ocaml *)
            supplier = receipt_supplier; conversion = None } : input_physical_return) :: !captures) slots
(* ``` *)
(*
```
*)
(* ``` *)
    in
    let rec current branch view_ty path (value : tvalue) =
      [%cassert] span
        (ty_erase_regions_with_metadata ctx.type_ctx.type_infos
           ctx.metadata_bindings view_ty = value.ty)
        "A physical input borrower changes its complete stored type";
      match value.value with
      | VLoan (VMutLoan parent) when parent = bid ->
          capture branch view_ty path
      | VAdt adt ->
          let fields =
            match view_ty with
            | TAdt { id = TAdtId id; generics } ->
                Substitute.type_decl_get_instantiated_field_types
                  (TypeDeclId.Map.find id ctx.type_ctx.type_decls)
                  adt.variant_id generics
            | TAdt { id = TTuple; generics } -> generics.types
            | _ -> [%craise] span "A physical input borrower changes its product type"
          in
          [%cassert] span (List.length fields = List.length adt.fields)
            "A physical input borrower changes its field positions";
          List.iteri
            (fun index field ->
              current branch (List.nth fields index)
                (path @ [ PField (adt.variant_id, index) ]) field)
            adt.fields
      | VBorrow (VMutBorrow (_, child)) ->
          (match view_ty with
           | TRef (_, inner, RMut) ->
               current branch inner (path @ [ PDeref ]) child
           | _ -> [%craise] span "A physical input borrower changes its reference type")
      | VLoan (VSharedLoan (_, child)) -> current branch view_ty path child
      | _ -> ()
    in
    (*
```ocaml
    *)
    let rec current_abstract branch view_ty path (value : tavalue) =
      match value.value with
      | ALoan (AMutLoan (_, parent, _))
      | ALoan (AIgnoredMutLoan (_, Some parent, _)) when parent = bid ->
          capture branch view_ty path
      | AAdt adt ->
          let fields =
            match view_ty with
            | TAdt { id = TAdtId id; generics } ->
                Substitute.type_decl_get_instantiated_field_types
                  (TypeDeclId.Map.find id ctx.type_ctx.type_decls)
                  adt.variant_id generics
            | TAdt { id = TTuple; generics } -> generics.types
            | _ -> [%craise] span "A physical abstract borrower changes its product type"
          in
          [%cassert] span
            (ty_erase_regions_with_metadata ctx.type_ctx.type_infos
               ctx.metadata_bindings view_ty
             = ty_erase_regions_with_metadata ctx.type_ctx.type_infos
                 ctx.metadata_bindings value.ty)
            "A physical abstract borrower changes its complete stored type";
          [%cassert] span (List.length fields = List.length adt.fields)
            "A physical abstract borrower changes its field positions";
          List.iteri
            (fun index field ->
              current_abstract branch (List.nth fields index)
                (path @ [ PField (adt.variant_id, index) ]) field)
            adt.fields
      | _ -> ()
    in
    (*
```
    *)
    let current_borrower branch parent (payload : tavalue) =
      if parent <> bid then (
        match lookup_borrow_opt span ek_all (UMut parent) ctx with
        | Some (Concrete (VMutBorrow (_, value))) ->
(* ```ocaml *)
(* ``` *)
            current branch payload.ty (path @ [ PDeref ]) value
        | Some (Abstract (AMutBorrow (_, _, value) | AIgnoredMutBorrow (_, value))) ->
(* ```ocaml *)
(* ``` *)
            current_abstract branch payload.ty (path @ [ PDeref ]) value
        | _ -> ())
    in
    match value.value with
    | AAdt { variant_id; fields; _ } ->
        List.iteri (fun index field -> child (PField (variant_id, index)) field)
          fields
    | ALoan (AMutLoan (branch, parent, payload)) ->
        if parent = bid then capture branch payload.ty (path @ [ PDeref ]);
        current_borrower branch parent payload;
        child PDeref payload
    | ALoan (AIgnoredMutLoan (branch, parent, payload)) ->
        if parent = Some bid then capture branch payload.ty (path @ [ PDeref ]);
        Option.iter (fun parent -> current_borrower branch parent payload) parent;
        child PDeref payload
    (*
```ocaml
    *)
    | ALoan (AEndedMutLoan { child = payload; _ })
    | ALoan (AEndedIgnoredMutLoan { child = payload; _ }) ->
        if path = [] then
          List.iter
            (fun ((source : symbolic_value), expansion) ->
              if source = origin.transport_root then
                match expansion with
                | SeMutRef (parent, stored) ->
                    [%cassert] span (stored.sv_ty = payload.ty)
                      "A physical root changes its complete stored payload";
                    current_borrower PNone parent payload
                | _ -> ())
            witnesses.expansions;
        child PDeref payload
    (*
```
    *)
    | ABorrow (AMutBorrow (_, _, payload) | AIgnoredMutBorrow (_, payload)) ->
        child PDeref payload
    | _ -> ()
  in
(*
```ocaml
*)
  List.iter
    (fun (conversion : input_carrier_conversion) ->
      if conversion.conversion_owner = abs.abs_id
        && conversion.conversion_returned_borrow = bid then begin
        let source = ctx_lookup_abs ctx conversion.conversion_source_owner in
        [%cassert] span
          (AbsId.Set.mem conversion.conversion_parent_owner abs.parents
           && source.regions.owned = conversion.conversion_source_regions)
          "A converted return changes its source or parent";
        let endpoints = ref [] in
        let obj = object
          inherit [_] iter_abs_with_levels as super
          method incr_level level = level + 1
          method! visit_tavalue level value =
            match value.value with
            | ABorrow (AEndedMutBorrow (ended, child))
              when level = conversion.conversion_source_level
                && ended.bid = bid ->
                endpoints := (value.ty, ended.given_back, child.ty) :: !endpoints
            | _ -> super#visit_tavalue level value
        end in
        obj#visit_abs 0 source;
        let endpoint = match List.sort_uniq Stdlib.compare !endpoints with
          | [ endpoint ] -> endpoint
          | _ -> [%craise] span "A converted return lacks one actual supplier endpoint" in
        let reference_ty, supplied, supplied_ty = endpoint in
        [%cassert] span
          (reference_ty = conversion.conversion_source_reference
           && nv.value = VSymbolic supplied
           && supplied_ty = conversion.conversion_source_payload
           && actual_ty = conversion.conversion_source_payload)
          "A converted return changes its complete source payload";
        (match input_return_supplier_producer supplier with
        | AbstractionInputReturn (owner, level, current, regions, endpoint) ->
            [%cassert] span
              (owner = source.abs_id && level = conversion.conversion_source_level
               && regions = source.regions.owned
               && current.sv_ty = conversion.conversion_source_payload
               && current = supplied
               && Option.fold ~none:false ~some:(fun (endpoint : tevalue) ->
                 endpoint.ty = current.sv_ty
                 && match endpoint.value with
                    | EBorrow (EEndedMutBorrow (meta, child)) ->
                        meta.bid = bid && meta.given_back = current
                        && child.ty = current.sv_ty
                    | _ -> false) endpoint)
              "A converted return changes its actual source supplier"
        | _ -> [%craise] span "A converted return lacks its actual abstraction supplier");
        let relation = RegionId.Map.of_list conversion.conversion_relation in
        [%cassert] span
          (projection_metadata_types_equal ctx relation
            conversion.conversion_source_payload conversion.conversion_receiver_payload)
          "A converted return changes its recorded coordinate relation";
        let slot = conversion.conversion_slot in
        let origin = conversion.conversion_origin in
        let proof = conversion.conversion_input in
        let selected_source = input_return_route_ty ctx origin.transport_root.sv_ty
          conversion.conversion_returned_at in
        [%cassert] span

(* ```ocaml *)
          (proof.input_origin = origin && proof.input_root = origin.transport_root
(* ``` *)

           && Option.fold ~none:false
             ~some:(fun ty -> projection_metadata_types_equal ctx
               (RegionId.Map.of_list proof.input_relation) ty conversion.conversion_source_payload)
             selected_source
           && call_input_borrow_reference span ctx proof bid =
                Some (conversion.conversion_source_reference, conversion.conversion_source_payload))
          "A converted return changes its actual input declaration";
        let coordinates = projection_metadata_renaming span ctx.type_ctx.type_infos
          conversion.conversion_receiver_payload conversion.conversion_source_payload in
        let coverage = match route_suffix conversion.conversion_returned_at slot.value_path with
          | None -> false
          | Some path ->
              (match input_return_route_ty ctx conversion.conversion_receiver_payload path,
                     input_return_route_ty ctx conversion.conversion_source_payload path with
              | Some receiver, Some actual ->
                  projection_metadata_types_equal ctx coordinates receiver actual
                  && RegionId.Set.equal
                    (RegionId.Set.map
                      (fun region -> match RegionId.Map.find_opt region coordinates with
                        | Some (RVar (Free mapped)) -> mapped
                        | _ -> region)
                      slot.proj_regions)
                    (ty_regions ctx.type_ctx.type_infos actual)
              | _ -> false) in
        [%cassert] span coverage
          "A converted return changes its exact selected payload";
(*
```ocaml
*)
        captures := { origin; slot = PendingParameterSlot slot; branch = PNone; returned_borrow = Some bid;
(*
```
*)
          returned_at = conversion.conversion_returned_at;
          full_return_ty = conversion.conversion_receiver_payload; current_payload = nv;
          supplier; conversion = Some conversion } :: !captures
      end)
    witnesses.carrier_conversions;
(*
```
*)
  List.iter (fun (origin : carrier_origin) ->
    if not (List.exists
      (fun conversion -> conversion.conversion_owner = abs.abs_id
        && conversion.conversion_origin = origin)
      witnesses.carrier_conversions) then
    List.iter (fun (from_input, (original : tavalue), (actual : tavalue)) ->
      if not from_input then
        match original.value with
        | ASymbolic (_, AProjLoans { proj; _ })
            when proj.sv_id = origin.transport_root.sv_id ->
            visit origin [] actual
        | _ -> ())
      witnesses.roots)
    witnesses.carrier_origins;
(*
```ocaml
*)
  let rec precedes route next =
    match next.route_previous with
    | None -> false
    | Some previous -> previous = route || precedes route previous in
  let current_routes = List.filter
    (fun route -> not (List.exists (precedes route) witnesses.return_routes))
    witnesses.return_routes in
  let rec borrow_edges visited position (source : symbolic_value) =
    if SymbolicValueId.Set.mem source.sv_id visited then []
(*
```ocaml
*)
    else
      let visited = SymbolicValueId.Set.add source.sv_id visited in
      let parents = witnesses.return_routes |> List.filter
        (fun route -> Option.is_some route.route_loan
          && route.route_position = position
          && route.route_source.sv_id = source.sv_id
          && route.route_source.proj_ty = source.sv_ty)
        |> List.sort_uniq Stdlib.compare in
      if parents <> [] then
        parents |> List.concat_map (fun route ->
          let log = Logging.carrier_events_log in
          [%ldebug
            "Carrier physical parent expansion event:\nloan: "
            ^ BorrowId.to_string (Option.get route.route_loan)
            ^ "\nsource: " ^ show_symbolic_proj route.route_source
            ^ "\ncurrent return: " ^ show_symbolic_value route.route_current
            ^ "\nposition: "
            ^ String.concat "/" (List.map show_value_path_step position)
            ^ "\nactual expansions: "
            ^ String.concat "\n" (List.filter_map
                (fun (parent, expansion) ->
                  if parent = route.route_current
                  then Some (show_symbolic_expansion expansion) else None)
                witnesses.expansions)];
          borrow_edges visited position route.route_current
(*
```ocaml
*)
          |> List.filter_map (fun (field_position, current_ref, _, parents) ->
(*
```
*)
            Option.bind (route_suffix position field_position) (fun suffix ->
              match route_ty route.route_source.proj_ty suffix with
              | Some (TRef (_, payload, RMut) as declared_ref) ->
                  (try
                    let relation = projection_metadata_renaming ~mismatch:Exit
                      span ctx.type_ctx.type_infos declared_ref current_ref in
                    let parent_relation = RegionId.Map.of_list route.route_relation in
                    if RegionId.Map.for_all (fun region destination ->
                      match RegionId.Map.find_opt region parent_relation with
                      | Some expected -> expected = destination
                      | None -> destination = RVar (Free region)) relation
(*
```ocaml
*)
                    then Some (field_position, declared_ref, payload, route :: parents)
(*
```
*)
                    else None
                  with Exit -> None)
              | _ -> None)))
      else
        witnesses.expansions |> List.filter_map
          (fun (parent, expansion) ->
            if parent <> source then None else Some expansion)
        |> List.concat_map (function
          | SeMutRef (borrow, child) ->
(*
```ocaml
*)
              let edges = if borrow = bid then [ (position, source.sv_ty, child.sv_ty, []) ]
(*
```
*)
                else [] in
              edges @ borrow_edges visited (position @ [ PDeref ]) child
          | SeAdt (variant, fields) ->
              List.mapi (fun index field ->
                borrow_edges visited (position @ [ PField (variant, index) ]) field) fields
              |> List.concat
          | SeSharedRef (_, child) ->
              borrow_edges visited (position @ [ PDeref ]) child
          | SeLiteral _ -> []) in
(*
```
*)
  List.iter (fun (route : input_return_route) ->
    let origin = route.route_origin in
(*
```ocaml
*)
    let external_owner = input_return_supplier_owner (input_return_route_producer route) in
(*
```ocaml
*)
    let current_owner = input_return_supplier_owner route.route_supplier in
(*
```ocaml
*)
    let current_regions = match route.route_supplier with
      | SymbolicInputReturn (_, _, _, _, owned, _)
      | AbstractionInputReturn (_, _, _, owned, _) -> owned
      | ConcreteInputReturn _ | FieldInputReturn _ | DeclaredCallInputReturn _ ->
          [%internal_error] span in
(*
```
*)
    let declaration_role =
      if current_owner <> Some origin.source_owner then true
      else match route.route_kind with
        | SynthInput group -> group = origin.region_group
        | _ -> false in
(*
```
*)
(*
```ocaml
*)
    if external_owner <> Some origin.source_owner && external_owner <> Some abs.abs_id
       && current_owner <> Some abs.abs_id && declaration_role
       && Option.is_some external_owner then
(*
```
*)
      borrow_edges SymbolicValueId.Set.empty [] origin.transport_root
      |> List.sort_uniq Stdlib.compare
(*
```ocaml
*)
      |> List.iter (fun (position, declared_ref_ty, declared_payload_ty, parents) ->
        if List.for_all (fun parent ->
          parent.route_origin = origin && parent.route_branch = route.route_branch
          && input_return_supplier_owner parent.route_supplier <> Some abs.abs_id
          && input_return_supplier_owner parent.route_supplier <> Some origin.source_owner)
          parents then
        let route = if parents = [] then route
          else { route with route_physical_parents = parents } in
        match route_suffix route.route_position position with
(*
```
*)
        | None -> ()
        | Some projection ->
            match route_ty route.route_current.sv_ty projection with
(*
```ocaml
*)
            | Some (TRef (RVar (Free field_region), payload_ty, RMut) as field_ty)
                when projection_metadata_types_equal ctx RegionId.Map.empty
                  actual_ty payload_ty ->
(*
```
*)
(*
```ocaml
*)
                let selected_field = RegionId.Set.inter current_regions
                  (RegionId.Set.singleton field_region) in
                let () =
                  let log = Logging.carrier_events_log in
                  [%ldebug
                    "Carrier field ownership event:\ncurrent parent: "
                    ^ show_symbolic_value route.route_current
                    ^ "\ncurrent supplier owner: "
                    ^ AbsId.to_string (Option.get current_owner)
                    ^ "\ncurrent supplier mask: "
                    ^ RegionId.Set.to_string None current_regions
                    ^ "\nprojected reference region: " ^ RegionId.to_string field_region
                    ^ "\nselected field mask: "
                    ^ RegionId.Set.to_string None selected_field
                    ^ "\nfield ownership admitted: "
                    ^ string_of_bool (not (RegionId.Set.is_empty selected_field))]
                in
                if not (RegionId.Set.is_empty selected_field) then
(*
```
*)
                (try
                  let relation = projection_metadata_renaming ~mismatch:Exit
                    span ctx.type_ctx.type_infos field_ty declared_ref_ty in
(*
```ocaml
*)
                  let transported = RegionId.Set.fold
                    (fun region mask ->
                      let destination = match RegionId.Map.find_opt region relation with
                        | Some (RVar (Free destination)) -> destination
                        | None -> region
                        | _ -> raise Exit in
                      RegionId.Set.add destination mask)
                    selected_field RegionId.Set.empty in
(*
```
*)
                  if projection_metadata_types_equal ctx RegionId.Map.empty
                       actual_ty declared_payload_ty then
(*
```ocaml
*)
                    List.iter (fun scope ->
                      if call_scope_matches_origin scope origin
                         && call_scope_path scope = position
                         && RegionId.Set.equal transported (call_scope_regions scope) then (
                        let slot = call_scope_receipt_slot scope in
                        let returned = { origin; slot; branch = route.route_branch;
(*
```
*)
                          returned_borrow = Some bid; returned_at = position @ [ PDeref ];
                          full_return_ty = declared_payload_ty; current_payload = nv;
(*
```ocaml
*)
(*
```ocaml
*)
                          supplier = FieldInputReturn
(* ```ocaml *)
                            (route, projection, field_ty, RegionId.Map.bindings relation);
                          conversion = None } in
(* ``` *)
(*
```
*)
(*
```
*)
                        captures := returned :: !captures;
                        let log = Logging.carrier_events_log in
                        [%ldebug
                          "Carrier current field event:\nexternal producer: "
                          ^ AbsId.to_string (Option.get external_owner)
                          ^ "\ncurrent parent: " ^ show_symbolic_value route.route_current
                          ^ "\nsource projector: " ^ show_symbolic_proj route.route_source
                          ^ "\noriginal view: " ^ Types.show_ty origin.original_root.sv_ty
                          ^ "\ntransported view: " ^ Types.show_ty origin.transport_root.sv_ty
                          ^ "\nfield type: " ^ Types.show_ty field_ty
                          ^ "\nfield transport: "
                          ^ RegionId.Map.to_string None Types.show_region relation
                          ^ "\nfield mask: " ^ RegionId.Set.to_string None transported
                          ^ "\nborrow: " ^ BorrowId.to_string bid
                          ^ "\ncurrent receiver: " ^ show_tvalue nv
                          ^ "\nphysical position: "
                          ^ String.concat "/" (List.map show_value_path_step returned.returned_at)]))
                      abs.call_scopes
                with Exit -> ())
            | _ -> ()))
    current_routes;
(*
```
*)
  (* ```ocaml *)
  [%ldebug
    "Physical receipt creation:\n- owner: " ^ AbsId.to_string abs.abs_id
    ^ "\n- returned borrow: " ^ BorrowId.to_string bid
    ^ "\n- complete payload: " ^ tvalue_to_string ctx nv
    ^ "\n- source origins:\n"
    ^ String.concat "\n" (List.map show_carrier_origin witnesses.carrier_origins)
    ^ "\n- pending declarations:\n"
    ^ String.concat "\n" (List.map
        call_scope_slot_to_string
        abs.call_scopes)
    ^ "\n- created receipts:\n"
    ^ String.concat "\n" (List.map show_input_physical_return !captures)];
  (* ``` *)
(*
```ocaml
*)
  (List.sort_uniq Stdlib.compare !captures,
   List.sort_uniq Stdlib.compare !parent_routes)
(*
```
*)
(*
```
*)

let give_back_value (span : Meta.span) (bid : BorrowId.id) (nv : tvalue)
    (supplier : input_return_supplier) (ctx : eval_ctx) : eval_ctx =
  (* Sanity check *)
  [%cassert] span
    (not (concrete_loans_in_value nv))
    "Can not end a borrow because the value to give back contains bottom";
  [%cassert] span
    (not (bottom_in_value ctx.type_ctx.type_infos ctx.ended_regions nv))
    "Can not end a borrow because the value to give back contains bottom";
  (* Debug *)
  [%ltrace
    "- bid: " ^ BorrowId.to_string bid ^ "\n- value: "
    ^ tvalue_to_string ~span:(Some span) ctx nv
    ^ "\n- context:\n"
    ^ eval_ctx_to_string ~span:(Some span) ctx];
  (* We use a reference to check that we updated exactly one loan *)
  let replaced : bool ref = ref false in
  let set_replaced () =
    [%sanity_check] span (not !replaced);
    replaced := true
  in
  let replaced_evalue : bool ref = ref false in
  let set_replaced_evalue () =
    [%sanity_check] span (not !replaced_evalue);
    replaced_evalue := true
  in
  (* Whenever giving back symbolic values, they shouldn't contain already ended regions *)
  let check_symbolic_no_ended = true in
  let given_back_env =
    if concrete_borrows_in_value nv then capture_env ctx.env else []
  in
  let completed_projections = ref [] in
  let remember_projection (abs : abs) loan ty result =
    completed_projections :=
      (abs.abs_id, loan,
       normalize_proj_ty ctx.type_ctx.type_infos abs.regions.owned ty, result)
      :: !completed_projections
  in
  let physical_returns_for (abs : abs) =
    let _, captures = List.fold_left
      (fun (seen, captures) scope ->
        let witnesses = call_scope_witnesses scope in
        if List.exists (fun witness -> witness == witnesses) seen
        then (seen, captures)
        else
          (witnesses :: seen,
(*
```ocaml
*)
           fst (capture_input_physical_return span ctx abs witnesses bid nv supplier)
           @ captures))
(*
```
*)
      ([], []) abs.call_scopes in
    captures
  in
(*
```ocaml
*)
  let physical_projector (abs : abs) receiver_ty =
    let current = as_symbolic span nv.value in
    if projection_masks_equal span ctx abs.regions.owned
         receiver_ty current.sv_ty then
      (current, abs.regions.owned, None)
    else
      let producer = input_return_supplier_producer in
(* ```ocaml *)
(*
```ocaml
*)
      let receiver_matches (receipt : input_physical_return) =
        match receipt.conversion with
        | Some conversion ->
            conversion.conversion_owner = abs.abs_id
            && PendingParameterSlot conversion.conversion_slot = receipt.slot
            && conversion.conversion_origin = receipt.origin
            && conversion.conversion_receiver_payload = receiver_ty
            && conversion.conversion_returned_borrow = bid
            && AbsId.Set.mem conversion.conversion_parent_owner abs.parents
            && RegionId.Set.subset (carrier_slot_regions receipt.slot) abs.regions.owned
            && List.exists (fun (scope : call_pending_scope) ->
              PendingParameterSlot scope.slot = receipt.slot
              && List.mem conversion scope.witnesses.carrier_conversions)
              (parameter_scopes abs.call_scopes)
        | None ->
            match receipt.origin.source_role with
            | OrdinaryCallOutputOrigin _ ->
                receipt.origin.source_owner = abs.abs_id
                && (match receipt.slot with
                  | PendingParameterSlot _ -> true
                  | PhysicalInputSlot _ -> false)
            | FunctionInputOrigin _ ->
                List.exists
                  (function
                    | PendingParameterScope scope ->
                        PendingParameterSlot scope.slot = receipt.slot
                        && scope.slot.proj_ty = receipt.origin.transport_root.sv_ty
                        && (scope.slot.root_sv_id = receipt.origin.original_root.sv_id
                            || scope.slot.root_sv_id = receipt.origin.transport_root.sv_id)
                        && RegionId.Set.subset scope.slot.proj_regions abs.regions.owned
                        && List.mem receipt.origin scope.witnesses.carrier_origins
                        && (check_function_input_interface span ctx scope.witnesses
                              receipt.origin (ctx_lookup_abs ctx receipt.origin.source_owner); true)
                    | PhysicalInputScope scope ->
                        PhysicalInputSlot scope.physical_slot = receipt.slot
                        && scope.physical_slot.origin = receipt.origin
                        && RegionId.Set.equal scope.physical_slot.proj_regions
                          (RegionId.Set.inter abs.regions.owned
                            (ty_regions ctx.type_ctx.type_infos receipt.origin.transport_root.sv_ty))
                        && List.mem receipt.origin scope.witnesses.carrier_origins
                        && (check_function_input_interface span ctx scope.witnesses
                              receipt.origin (ctx_lookup_abs ctx receipt.origin.source_owner); true))
                  abs.call_scopes
(*
```
*)
      in
(* ``` *)
      let candidates = physical_returns_for abs in
      let receipts =
        candidates
        |> List.filter (fun (receipt : input_physical_return) ->
             receiver_matches receipt
             && receipt.returned_borrow = Some bid
             && receipt.current_payload = nv
             && producer receipt.supplier = producer supplier
(*
```ocaml
*)
             && (match receipt.conversion with
                 | Some conversion ->
                     receipt.full_return_ty = receiver_ty
                     && conversion.conversion_receiver_payload = receiver_ty
                     && input_return_route_ty ctx (ValuesUtils.carrier_slot_ty receipt.slot)
                          receipt.returned_at = Some receiver_ty
                 | None ->
                     (input_return_route_ty ctx receipt.origin.original_root.sv_ty
                        receipt.returned_at = Some receiver_ty
                      || input_return_route_ty ctx receipt.origin.transport_root.sv_ty
                           receipt.returned_at = Some receiver_ty)
                     && input_return_route_ty ctx receipt.origin.transport_root.sv_ty
                          receipt.returned_at = Some receipt.full_return_ty))
(*
```
*)
        |> List.sort_uniq Stdlib.compare
      in
      let origins =
        List.map (fun (receipt : input_physical_return) ->
          (receipt.origin, receipt.returned_at, receipt.full_return_ty)) receipts
        |> List.sort_uniq Stdlib.compare
      in
      let origin, position =
        match origins with
        | [ (origin, position, _) ] -> (origin, position)
        | _ ->
(*
```ocaml
*)
            let () =
              if abs.abs_id = AbsId.of_int 5 && bid = BorrowId.of_int 11
                 && current.sv_id = SymbolicValueId.of_int 20
                 && RegionId.Set.cardinal abs.regions.owned = 1
                 && RegionId.Set.mem (RegionId.of_int 5) abs.regions.owned then
                let diagnostic = try
                  let output = Buffer.create 8192 in
                  let omitted = ref 0 in
                  let emit name value =
                    let length = String.length name + String.length value + 2 in
                    if Buffer.length output + length <= 8096 then begin
                      Buffer.add_string output name;
                      Buffer.add_char output '=';
                      Buffer.add_string output value;
                      Buffer.add_char output '\n'
                    end else incr omitted in
                  let integer name value = emit name (string_of_int value) in
                  let boolean name value = emit name (string_of_bool value) in
                  let symbol name value = emit name (SymbolicValueId.to_string value) in
                  let checks name values =
                    emit name (match List.find_opt (fun (_, passed) -> not passed) values with
                      | None -> "all-pass" | Some (first, _) -> "first-false:" ^ first);
                    List.iter (fun (name, passed) -> boolean name passed) values in
                  let position name steps =
                    integer (name ^ ".length") (List.length steps);
                    List.iteri (fun index step -> if index < 8 then begin
                      integer (name ^ ".index") index;
                      (match step with
                      | PDeref -> emit name "deref"
                      | PField (variant, field) ->
                          integer (name ^ ".field") field;
                          emit (name ^ ".variant") (Option.fold ~none:"none"
                            ~some:VariantId.to_string variant))
                    end) steps;
                    integer (name ^ ".omitted") (Stdlib.max 0 (List.length steps - 8)) in
                  let relation name values =
                    integer (name ^ ".count") (List.length values);
                    List.iteri (fun index (source, destination) -> if index < 8 then begin
                      emit (name ^ ".source") (RegionId.to_string source);
                      emit (name ^ ".destination") (Types.show_region destination)
                    end) values;
                    integer (name ^ ".omitted") (Stdlib.max 0 (List.length values - 8)) in
                  let expected_position = [PField (None, 0); PDeref] in
                  integer "pending-scope-count" (List.length abs.call_scopes);
(*
```ocaml
*)
                  List.iteri (fun scope_index scope -> if scope_index < 8 then begin
                    integer "scope-index" scope_index;
                    symbol "slot-root" (call_scope_root_id scope);
                    position "slot-path" (call_scope_path scope);
                    let selected = call_scope_regions scope in
                    integer "slot-mask-count" (RegionId.Set.cardinal selected);
                    boolean "slot-mask5" (RegionId.Set.mem (RegionId.of_int 5) selected);
                    boolean "slot-owned" (RegionId.Set.subset selected abs.regions.owned);
                    (match scope with
                    | PendingParameterScope scope ->
                        integer "slot-ancestor-depth" (List.length scope.slot.ancestor_path);
                        List.iteri (fun index side ->
                          if index < 8 then boolean "slot-ancestor-bit" side) scope.slot.ancestor_path;
                        integer "slot-ancestor-omitted"
                          (Stdlib.max 0 (List.length scope.slot.ancestor_path - 8));
                        integer "position-count" (List.length scope.positions);
                        List.iteri (fun index (side, path) -> if index < 8 then begin
                          integer "position-index" index;
                          boolean "position-side" side;
                          integer "position-depth" (List.length path);
                          List.iteri (fun index side ->
                            if index < 8 then boolean "position-bit" side) path;
                          integer "position-bit-omitted" (Stdlib.max 0 (List.length path - 8))
                        end) scope.positions;
                        integer "position-omitted" (Stdlib.max 0 (List.length scope.positions - 8))
                    | PhysicalInputScope _ -> emit "parameter-protocol" "unavailable-physical-interface");
                    let witnesses = call_scope_witnesses scope in
(*
```
*)
                    let origins = List.filter (fun (origin : carrier_origin) ->
                      origin.source_owner = AbsId.of_int 2
                      && origin.region_group = RegionGroupId.of_int 2
                      && origin.source_role = FunctionInputOrigin 1
                      && origin.original_root.sv_id = SymbolicValueId.of_int 1
                      && origin.transport_root.sv_id = SymbolicValueId.of_int 3)
                      witnesses.carrier_origins |> List.sort_uniq Stdlib.compare in
                    integer "target-origin-count" (List.length origins);
                    match origins with
                    | [origin] ->
(*
```ocaml
*)
                      boolean "slot-transport-type" (call_scope_ty scope = origin.transport_root.sv_ty);
(*
```
*)
                      let reference = input_return_declared_source span witnesses.expansions
                        origin.transport_root [PField (None, 0)] in
                      let source = input_return_declared_source ~final_borrow:bid span
                        witnesses.expansions origin.transport_root expected_position in
                      emit "resolved-reference" (Option.fold ~none:"absent"
                        ~some:(fun (source : symbolic_value) -> SymbolicValueId.to_string source.sv_id) reference);
                      emit "resolved-borrow-payload" (Option.fold ~none:"absent"
                        ~some:(fun (source : symbolic_value) -> SymbolicValueId.to_string source.sv_id) source);
                      boolean "resolved-payload-type" (Option.fold ~none:false
                        ~some:(fun (source : symbolic_value) -> source.sv_ty = receiver_ty) source);
                      let routes = List.filter (fun (route : input_return_route) ->
                        route.route_origin = origin && route.route_current = current)
                        witnesses.return_routes in
                      integer "all-route-count" (List.length witnesses.return_routes);
                      integer "current-route-count" (List.length routes);
                      List.iteri (fun index (route : input_return_route) -> if index < 8 then begin
                        integer "route-index" index;
                        symbol "route-source" route.route_source.sv_id;
                        position "route-position" route.route_position;
                        relation "route-relation" route.route_relation;
                        emit "upstream-borrow" (Option.fold ~none:"absent" ~some:BorrowId.to_string route.route_loan);
                        checks "route-checks" [
                          ("route-unmarked", route.route_branch = PNone);
                          ("route-position", route.route_position = expected_position);
                          ("route-source", Option.fold ~none:false ~some:(fun (source : symbolic_value) ->
                            route.route_source = { sv_id = source.sv_id; proj_ty = receiver_ty }
                            && source.sv_ty = receiver_ty) source);
                          ("route-current", route.route_current = current);
                          ("upstream-distinct", Option.fold ~none:false ~some:(( <> ) bid) route.route_loan)];
                        (match input_return_supplier_producer route.route_supplier with
                        | AbstractionInputReturn (owner, level, supplied, owned, endpoint) ->
                            emit "upstream-owner" (AbsId.to_string owner);
                            integer "upstream-level" level;
                            boolean "upstream-external" (owner <> abs.abs_id && owner <> origin.source_owner);
                            integer "upstream-mask-count" (RegionId.Set.cardinal owned);
                            boolean "upstream-mask6" (RegionId.Set.mem (RegionId.of_int 6) owned);
                            checks "upstream-checks" [
                              ("upstream-symbol", supplied = current);
                              ("upstream-endpoint", Option.fold ~none:false ~some:(fun endpoint ->
                                endpoint.ty = current.sv_ty && match endpoint.value with
                                | EBorrow (EEndedMutBorrow (meta, child)) ->
                                    Some meta.bid = route.route_loan && meta.given_back = current
                                    && child.ty = current.sv_ty
                                | _ -> false) endpoint)]
                        | _ -> emit "upstream-form" "not-abstraction-return");
                        let receipts = List.filter (fun (receipt : input_physical_return) ->
                          receipt.origin = origin && receipt.returned_borrow = route.route_loan
                          && receipt.returned_at = expected_position
                          && receipt.full_return_ty = receiver_ty && receipt.current_payload = nv
                          && receipt.supplier = route.route_supplier) witnesses.physical_returns in
                        integer "upstream-matching-receipt-count" (List.length receipts)
                      end) routes;
                      integer "route-omitted" (Stdlib.max 0 (List.length routes - 8));
                      integer "input-proof-count" (List.length witnesses.input_correspondences);
                      List.iteri (fun index (proof : call_input_correspondence) -> if index < 8 then begin
                        integer "input-proof-index" index;
                        symbol "input-root" proof.input_root.sv_id;
                        symbol "input-source" proof.input_source.sv_id;
                        position "input-source-path" proof.input_source_path;
                        position "input-path" proof.input_path;
                        relation "input-relation" proof.input_relation;
                        let prefix = proof.input_origin = origin && proof.input_root = origin.transport_root in
                        boolean "input-origin" (proof.input_origin = origin);
                        boolean "input-root" (proof.input_root = origin.transport_root);
                        if prefix then begin
                          let borrow_match = match call_input_borrow_reference span ctx proof bid with
                            | Some (_, payload) -> payload = current.sv_ty | None -> false in
                          let actual_path = call_input_actual_path proof expected_position in
                          let actual_match = Option.bind actual_path
                            (input_return_route_ty ctx proof.instantiated_input) = Some current.sv_ty in
                          boolean "input-borrow-reference" borrow_match;
                          Option.iter (position "input-actual-path") actual_path;
                          boolean "input-actual-payload" actual_match;
                          if borrow_match && actual_match then boolean "input-metadata"
                            (projection_metadata_types_equal ctx (RegionId.Map.of_list proof.input_relation)
                              receiver_ty current.sv_ty)
                          else emit "input-metadata" "not-reached"
                        end else emit "input-admission" "not-reached"
                      end) witnesses.input_correspondences;
                      integer "input-proof-omitted" (Stdlib.max 0 (List.length witnesses.input_correspondences - 8));
                      integer "root-count" (List.length witnesses.roots);
                      List.iteri (fun index (side, (value : tavalue), (actual : tavalue)) -> if index < 8 then begin
                        integer "root-index" index;
                        boolean "root-side" side;
                        emit "root-role" (match value.value with
                          | ASymbolic (_, AProjBorrows _) -> "borrow"
                          | ASymbolic (_, AProjLoans _) -> "loan"
                          | _ -> "other");
                        boolean "root-transport-type" (value.ty = origin.transport_root.sv_ty);
                        boolean "root-original-type" (value.ty = origin.original_root.sv_ty);
                        boolean "actual-root-type" (actual.ty = value.ty);
                        (match value.value with
                        | ASymbolic (branch, AProjLoans { proj; _ })
                        | ASymbolic (branch, AProjBorrows { proj; _ }) ->
                            symbol "root-symbol" proj.sv_id;
                            boolean "root-unmarked" (branch = PNone);
                            boolean "root-projector-type" (proj.proj_ty = value.ty)
                        | _ -> emit "root-form" "not-direct-projector")
                      end) witnesses.roots;
                      integer "root-omitted" (Stdlib.max 0 (List.length witnesses.roots - 8));
                      let expansions = List.filter (fun (parent, _) ->
                        parent = origin.transport_root || Some parent = reference || Some parent = source)
                        witnesses.expansions in
                      integer "relevant-expansion-count" (List.length expansions);
                      List.iteri (fun index ((parent : symbolic_value), expansion) -> if index < 8 then begin
                        symbol "expansion-parent" parent.sv_id;
                        (match expansion with
                        | SeMutRef (borrow, stored) ->
                            emit "expansion-kind" "mutable";
                            emit "expansion-borrow" (BorrowId.to_string borrow);
                            symbol "expansion-stored" stored.sv_id;
                            boolean "expansion-payload-type" (stored.sv_ty = receiver_ty)
                        | SeSharedRef (_, stored) ->
                            emit "expansion-kind" "shared";
                            symbol "expansion-stored" stored.sv_id
                        | SeAdt (variant, fields) ->
                            emit "expansion-kind" "product";
                            emit "expansion-variant" (Option.fold ~none:"none" ~some:VariantId.to_string variant);
                            integer "expansion-field-count" (List.length fields);
                            List.iteri (fun index (field : symbolic_value) -> if index < 8 then symbol "expansion-field" field.sv_id) fields;
                            integer "expansion-field-omitted" (Stdlib.max 0 (List.length fields - 8))
                        | SeLiteral _ -> emit "expansion-kind" "literal")
                      end) expansions;
                      integer "expansion-omitted" (Stdlib.max 0 (List.length expansions - 8))
                    | _ -> ()
                  end) abs.call_scopes;
                  integer "scope-omitted" (Stdlib.max 0 (List.length abs.call_scopes - 8));
                  Buffer.add_string output ("section-lines-omitted=" ^ string_of_int !omitted ^ "\n");
                  Buffer.contents output
                with _ -> "Physical carrier diagnostic unavailable." in
                (try Printf.eprintf "Physical carrier proof operands:\n%s\n%!" diagnostic
                 with _ -> ())
            in
(*
```
*)
            Printf.eprintf "Physical return authentication failure:\n- borrow: %s\n- receiver type: %s\n- current symbol: %s\n- current payload: %s\n- supplier: %s\n- raw owner: %s\n- candidates: %d\n- accepted receipts: %d\n- unique origins: %d\n%!"
              (BorrowId.to_string bid) (Types.show_ty receiver_ty)
              (Values.show_symbolic_value current) (Values.show_tvalue nv)
              (Values.show_input_return_supplier supplier) (Values.show_abs abs)
              (List.length candidates) (List.length receipts) (List.length origins);
(* ```ocaml *)
            AbsId.Set.iter
              (fun parent ->
                Printf.eprintf "Physical receiver parent:\n%s\n%!"
                  (Values.show_abs (ctx_lookup_abs ctx parent)))
              abs.parents;
            Option.iter
              (fun owner ->
                Printf.eprintf "Physical supplier owner:\n%s\n%!"
                  (Values.show_abs (ctx_lookup_abs ctx owner)))
              (input_return_supplier_owner supplier);
(* ``` *)
            List.iter (fun (receipt : input_physical_return) ->
              let original_ty = input_return_route_ty ctx
                receipt.origin.original_root.sv_ty receipt.returned_at in
              let transport_ty = input_return_route_ty ctx
                receipt.origin.transport_root.sv_ty receipt.returned_at in
              Printf.eprintf "Physical return candidate:\n- receipt: %s\n- owner matches: %b\n- borrow matches: %b\n- payload matches: %b\n- supplier matches: %b\n- original receiver matches: %b\n- transport receiver matches: %b\n- transport payload matches: %b\n%!"
                (Values.show_input_physical_return receipt)
                (receiver_matches receipt)
                (receipt.returned_borrow = Some bid)
                (receipt.current_payload = nv)
                (producer receipt.supplier = producer supplier)
                (original_ty = Some receiver_ty)
                (transport_ty = Some receiver_ty)
                (transport_ty = Some receipt.full_return_ty))
              candidates;
            [%craise] span
              "A physical return lacks a unique authenticated complete carrier"
      in
      let receiver_root =
        if input_return_route_ty ctx origin.original_root.sv_ty position
             = Some receiver_ty
        then origin.original_root
        else origin.transport_root
      in
      let relation = projection_metadata_renaming span
        ctx.type_ctx.type_infos receiver_ty current.sv_ty in
(*
```ocaml
*)
      List.iter
        (fun (receipt : input_physical_return) ->
          match receipt.origin.source_role, receipt.supplier with
          | OrdinaryCallOutputOrigin _, DeclaredCallInputReturn (proof, _) ->
              let declared = RegionId.Map.of_list proof.input_relation in
              [%cassert] span
                (projection_metadata_types_equal ctx declared receiver_ty current.sv_ty
                 && RegionId.Map.for_all
                      (fun source destination ->
                        RegionId.Map.find_opt source declared = Some destination)
                      relation)
                "An ordinary return lacks its declared payload coordinate relation"
          | OrdinaryCallOutputOrigin _, _ ->
              [%craise] span "An ordinary return lacks its actual input correspondence"
          | FunctionInputOrigin _, _ -> ())
        receipts;
(*
```
*)
      let receiver_regions = RegionId.Set.inter abs.regions.owned
        (ty_regions ctx.type_ctx.type_infos receiver_ty) in
      let current_regions = RegionId.Set.fold
        (fun original regions ->
          match RegionId.Map.find_opt original relation with
          | Some (RVar (Free current)) -> RegionId.Set.add current regions
          | None -> RegionId.Set.add original regions
          | _ -> [%craise] span
              "A physical carrier coordinate does not denote a physical region")
        receiver_regions RegionId.Set.empty in
      [%cassert] span
        (compare_rtys span ctx true ( && )
           (fun original actual ->
             region_in_set original receiver_regions
             = region_in_set actual current_regions)
           receiver_ty current.sv_ty)
        "A physical carrier transport changes its selected stored positions";
      let transport : carrier_coordinate_transport =
        { receiver = { sv_id = receiver_root.sv_id; proj_ty = receiver_ty };
(*
```
*)
          receiver_regions; current; current_regions;
          return_source = PhysicalCarrierReturn receipts }
      in
      (current, current_regions, Some transport)
  in
  let physical_avalue (abs : abs) ty project =
    let current, regions, transport = physical_projector abs ty in
    let projection_ty =
      match transport with None -> ty | Some _ -> current.sv_ty in
    let child : tavalue = project regions current projection_ty in
(* ```ocaml *)
    match transport, child.value with
    | None, _ -> child
    | Some transport, ASymbolic (marker, projection) ->
        { value = ASymbolic (marker, ATransportedProj (transport, projection)); ty }
    | Some transport, _ ->
        { child with value = ATransportedValue (transport, child) }
(* ``` *)
  in
  let physical_evalue (abs : abs) ty project =
    let current, regions, transport = physical_projector abs ty in
    let projection_ty =
      match transport with None -> ty | Some _ -> current.sv_ty in
    let child : tevalue = project regions current projection_ty in
(* ```ocaml *)
    match transport, child.value with
    | None, _ -> child
    | Some transport, ESymbolic (marker, projection) ->
        { value = ESymbolic (marker, ETransportedProj (transport, projection)); ty }
    | Some transport, _ ->
        { child with value = ETransportedValue (transport, child) }
(* ``` *)
  in
  let physical_loans abs ty =
    physical_avalue abs ty (mk_aproj_loans_value_from_symbolic_value
      ctx.type_ctx.type_infos ctx.metadata_bindings)
  in
  let physical_eloans abs ty =
    physical_evalue abs ty
      (mk_eproj_loans_value_from_symbolic_value ctx.type_ctx.type_infos)
  in
  let physical_borrows abs ty =
    match nv.value with
    | VSymbolic _ ->
(*
```ocaml
*)
        physical_avalue abs ty (fun regions _ ty ->
          apply_proj_borrows span check_symbolic_no_ended ctx regions nv ty)
    | _ ->
        apply_proj_borrows span check_symbolic_no_ended ctx abs.regions.owned nv ty
  in
  let physical_eborrows abs ty =
    match nv.value with
    | VSymbolic _ ->
        physical_evalue abs ty (fun regions _ ty ->
          apply_eproj_borrows span check_symbolic_no_ended ctx regions nv ty)
    | _ ->
        apply_eproj_borrows span check_symbolic_no_ended ctx abs.regions.owned nv ty
  in
  let projection_marker pm =
    object
      inherit [_] map_eval_ctx
      method! visit_proj_marker _ previous =
        let () = [%sanity_check] span (previous = PNone || previous = pm) in
        pm
    end
  in

  let mark_avalue pm value =
    if pm = PNone then value
    else (projection_marker pm)#visit_tavalue () value
  in

  let mark_evalue pm value =
    if pm = PNone then value
    else (projection_marker pm)#visit_tevalue () value
  in

  (* The visitor to give back the values *)
  let obj =
    object (self)
      inherit [_] map_eval_ctx_carrier_coordinates as super
(*
```
*)

      (** This is a bit annoying, but as we need the type of the value we are
          exploring, for sanity checks, we need to implement {!visit_tavalue}
          instead of overriding {!visit_ALoan} *)
      method! visit_tvalue opt_abs (v : tvalue) : tvalue =
        match v.value with
        | VLoan lc ->
            let value = self#visit_typed_Loan opt_abs v.ty lc in
            ({ v with value } : tvalue)
        | _ -> super#visit_tvalue opt_abs v

      method visit_typed_Loan opt_abs ty lc =
        match lc with
        | VSharedLoan (bids, v) ->
            (* We are giving back a value (i.e., the content of a *mutable*
               borrow): nothing special to do *)
            VLoan (super#visit_VSharedLoan opt_abs bids v)
        | VMutLoan bid' ->
            (* Check if this is the loan we are looking for *)
            if bid' = bid then (
              (* Sanity check *)
              let expected_ty = ty in
              if nv.ty <> expected_ty then
                [%craise] span
                  ("Value given back doesn't have the proper type:\n\
                    - expected: " ^ ty_to_string ctx ty ^ "\n- received: "
                 ^ ty_to_string ctx nv.ty);
              (* Replace *)
              set_replaced ();
              nv.value)
            else VLoan (super#visit_VMutLoan opt_abs bid')

      (** This is a bit annoying, but as we need the type of the avalue we are
          exploring, in order to be able to project the value we give back, we
          need to reimplement {!visit_tavalue} instead of {!visit_ALoan} *)
      method! visit_tavalue opt_abs (av : tavalue) : tavalue =
        match av.value with
        | ASymbolic (pm, APendingLoans parent) when parent = bid -> (
            let abs = Option.get opt_abs in
            let sv = as_symbolic span nv.value in
            let projected = physical_loans abs av.ty in
            remember_projection abs true av.ty projected;
            if !Config.print_error_diagnostics then
              Printf.eprintf
                "Physical return projection event:\nbranch: pending-loan\nborrow: %s\nowner: %d\nsupplier: %s\nstored type: %s\nreturned source: %s\nprojected value: %s\n%!"
                (BorrowId.to_string bid) (AbsId.to_int abs.abs_id)
                (show_input_return_supplier supplier)
                (Types.show_ty av.ty) (show_symbolic_value sv)
                (show_tavalue projected);
            match projected.value with
            | ASymbolic (_, proj) ->
                { projected with value = ASymbolic (pm, proj) }
            | _ -> projected)
        | ALoan lc ->
            let value = self#visit_typed_ALoan opt_abs av.ty lc in
            ({ av with value } : tavalue)
        | ABorrow bc ->
            let value = self#visit_typed_ABorrow opt_abs av.ty bc in
            ({ av with value } : tavalue)
        | _ -> super#visit_tavalue opt_abs av

      (** Similar to [visit_tevalue] *)
      method! visit_tevalue opt_abs (av : tevalue) : tevalue =
        match av.value with
        | ESymbolic (pm, EPendingLoans parent) when parent = bid -> (
            let abs = Option.get opt_abs in
            mark_evalue pm (physical_eloans abs av.ty))
        | ELoan lc ->
            let value = self#visit_typed_ELoan opt_abs av.ty lc in
            ({ av with value } : tevalue)
        | EBorrow bc ->
            let value = self#visit_typed_EBorrow opt_abs av.ty bc in
            ({ av with value } : tevalue)
        | _ -> super#visit_tevalue opt_abs av

      (** We need to inspect ignored mutable borrows, to insert loan projectors
          if necessary. *)
      method visit_typed_ABorrow (opt_abs : abs option) (ty : rty)
          (bc : aborrow_content) : avalue =
        match bc with
        | AIgnoredMutBorrow (bid', child) ->
            if bid' = Some bid then
              (* Insert a loans projector - note that if this case happens,
               * it is necessarily because we ended a parent abstraction,
               * and the given back value is thus a symbolic value *)
              match nv.value with
              | VSymbolic sv ->
                  let abs = Option.get opt_abs in
                  (* Remember the given back value as a meta-value
                   * TODO: it is a bit annoying to have to deconstruct
                   * the value... Think about a more elegant way. *)
                  let given_back_meta = as_symbolic span nv.value in
                  (* The loan projector *)
                  let _, ty, _ = ty_as_ref ty in
                  let given_back =
                    physical_loans abs ty
                  in
                  remember_projection abs true ty given_back;
                  if !Config.print_error_diagnostics then
                    Printf.eprintf
                      "Physical return projection event:\nbranch: ignored-mutable-borrow\nborrow: %s\nowner: %d\nsupplier: %s\nstored type: %s\nreturned source: %s\nprojected value: %s\n%!"
                      (BorrowId.to_string bid) (AbsId.to_int abs.abs_id)
                      (show_input_return_supplier supplier)
                      (Types.show_ty ty) (show_symbolic_value sv)
                      (show_tavalue given_back);
                  (* Continue giving back in the child value *)
                  let child = super#visit_tavalue opt_abs child in
                  (* Return *)
                  ABorrow
                    (AEndedIgnoredMutBorrow
                       { given_back; child; given_back_meta })
              | _ -> [%craise] span "Unreachable"
            else
              (* Continue exploring *)
              ABorrow (super#visit_AIgnoredMutBorrow opt_abs bid' child)
        | _ ->
            (* Continue exploring *)
            super#visit_ABorrow opt_abs bc

      (** We are not specializing an already existing method, but adding a new
          method (for projections, we need type information) *)
      method visit_typed_ALoan (opt_abs : abs option) (ty : rty)
          (lc : aloan_content) : avalue =
        (* Preparing a bit *)
        let abs = Option.get opt_abs in
        (* Rk.: there is a small issue with the types of the aloan values.
         * See the comment at the level of definition of {!tavalue} *)
        let borrowed_value_aty =
          let _, ty, _ = ty_get_ref ty in
          ty
        in
        match lc with
        | AMutLoan (pm, bid', child) ->
            [%sanity_check] span (pm = PNone);
            if bid' = bid then (
              (* This is the loan we are looking for: apply the projection to
               * the value we give back and replaced this mutable loan with
               * an ended loan *)
              (* Register the insertion *)
              set_replaced ();
              (* Remember the given back value as a meta-value *)
              let given_back_meta = nv in
              (* Apply the projection *)
              let given_back = physical_borrows abs borrowed_value_aty in
              remember_projection (Option.get opt_abs) false borrowed_value_aty
                given_back;
              (* Continue giving back in the child value *)
              let child = super#visit_tavalue opt_abs child in
              (* Return the new value *)
              ALoan (AEndedMutLoan { child; given_back; given_back_meta }))
            else (* Continue exploring *)
              super#visit_ALoan opt_abs lc
        | ASharedLoan (pm, _, _, _) ->
            [%sanity_check] span (pm = PNone);
            (* We are giving back a value to a *mutable* loan: nothing special to do *)
            super#visit_ALoan opt_abs lc
        | AEndedMutLoan { child = _; given_back = _; given_back_meta = _ }
        | AEndedSharedLoan (_, _, _) ->
            (* Nothing special to do *)
            super#visit_ALoan opt_abs lc
        | AIgnoredMutLoan (pm, opt_bid, child) ->
            (* This loan is ignored, but we may have to project on a subvalue
             * of the value which is given back *)
            if opt_bid = Some bid then
              (* Remember the given back value as a meta-value *)
              let given_back_meta = nv in
              (* Note that we replace the ignored mut loan by an *ended* ignored
               * mut loan. Also, this is not the loan we are looking for *per se*:
               * we don't register the fact that we inserted the value somewhere
               * (i.e., we don't call {!set_replaced}) *)
              let given_back =
                mark_avalue pm (physical_borrows abs borrowed_value_aty)
              in
              remember_projection (Option.get opt_abs) false borrowed_value_aty
                given_back;
              (* Continue giving back in the child value *)
              let child = super#visit_tavalue opt_abs child in
              ALoan
                (AEndedIgnoredMutLoan
                   { given_back; child; given_back_meta; given_back_env })
            else super#visit_ALoan opt_abs lc
        | AEndedIgnoredMutLoan { given_back = _; child = _; _ }
        | AIgnoredSharedLoan _ ->
            (* Nothing special to do *)
            super#visit_ALoan opt_abs lc

      (** We need to inspect ignored mutable borrows, to insert loan projectors
          if necessary. *)
      method visit_typed_EBorrow (opt_abs : abs option) (ty : rty)
          (bc : eborrow_content) : evalue =
        match bc with
        | EIgnoredMutBorrow (bid', child) ->
            if bid' = Some bid then
              (* Insert a loans projector - note that if this case happens,
               * it is necessarily because we ended a parent abstraction,
               * and the given back value is thus a symbolic value *)
              match nv.value with
              | VSymbolic _ ->
                  let abs = Option.get opt_abs in
                  (* Remember the given back value as a meta-value
                   * TODO: it is a bit annoying to have to deconstruct
                   * the value... Think about a more elegant way. *)
                  let given_back_meta = as_symbolic span nv.value in
                  (* The loan projector *)
                  let _, ty, _ = ty_as_ref ty in
                  let given_back = physical_eloans abs ty in
                  (* Continue giving back in the child value *)
                  let child = super#visit_tevalue opt_abs child in
                  (* Shared-only descendants have no continuation component.
                     Once the ignored dependency ends, an entirely ignored
                     carrier is itself ignored; active descendants stay intact. *)
                  if is_eignored child.value && is_eignored given_back.value
                  then EIgnored
                  else
                    EBorrow
                      (EEndedIgnoredMutBorrow
                         { given_back; child; given_back_meta })
              | _ -> [%craise] span "Unreachable"
            else
              (* Continue exploring *)
              EBorrow (super#visit_EIgnoredMutBorrow opt_abs bid' child)
        | _ ->
            (* Continue exploring *)
            super#visit_EBorrow opt_abs bc

      (** We are not specializing an already existing method, but adding a new
          method (for projections, we need type information) *)
      method visit_typed_ELoan (opt_abs : abs option) (ty : rty)
          (lc : eloan_content) : evalue =
        (* Preparing a bit *)
        let abs = Option.get opt_abs in
        (* Rk.: there is a small issue with the types of the aloan values.
         * See the comment at the level of definition of {!tavalue} *)
        let borrowed_value_aty =
          let _, ty, _ = ty_get_ref ty in
          ty
        in
        match lc with
        | EMutLoan (pm, bid', child) ->
            [%sanity_check] span (pm = PNone);
            if bid' = bid then (
              (* This is the loan we are looking for: apply the projection to
               * the value we give back and replaced this mutable loan with
               * an ended loan *)
              (* Register the insertion *)
              set_replaced_evalue ();
              (* Remember the given back value as a meta-value *)
              let given_back_meta = nv in
              let physical_returns = physical_returns_for (Option.get opt_abs) in
              (* Apply the projection *)
              let given_back = physical_eborrows abs borrowed_value_aty in
              (* Continue giving back in the child value *)
              let child = super#visit_tevalue opt_abs child in
              (* Return the new value *)
              ELoan (EEndedMutLoan
                { child; given_back; given_back_meta; physical_returns }))
            else (* Continue exploring *)
              super#visit_ELoan opt_abs lc
        | EEndedMutLoan { child = _; given_back = _; given_back_meta = _; _ } ->
            (* Nothing special to do *)
            super#visit_ELoan opt_abs lc
        | EIgnoredMutLoan (pm, opt_bid, child) ->
            (* This loan is ignored, but we may have to project on a subvalue
             * of the value which is given back *)
            if opt_bid = Some bid then
              (* Remember the given back value as a meta-value *)
              let given_back_meta = nv in
              let physical_returns = physical_returns_for (Option.get opt_abs) in
              (* Note that we replace the ignored mut loan by an *ended* ignored
               * mut loan. Also, this is not the loan we are looking for *per se*:
               * we don't register the fact that we inserted the value somewhere
               * (i.e., we don't call {!set_replaced}) *)
              let given_back =
                mark_evalue pm (physical_eborrows abs borrowed_value_aty)
              in
              (* Continue giving back in the child value *)
              let child = super#visit_tevalue opt_abs child in
              if is_eignored child.value && is_eignored given_back.value
                 && physical_returns = [] then
                EIgnored
              else
                ELoan
                  (EEndedIgnoredMutLoan
                     { given_back; child; given_back_meta; given_back_env;
                       physical_returns })
            else super#visit_ELoan opt_abs lc
        | EEndedIgnoredMutLoan { given_back = _; child = _; _ } ->
            (* Nothing special to do *)
            super#visit_ELoan opt_abs lc

      method! visit_EAbs opt_abs abs =
        (* We remember in which abstraction we are before diving -
         * this is necessary for projecting values: we need to know
         * over which regions to project *)
        [%sanity_check] span (Option.is_none opt_abs);
        super#visit_EAbs (Some abs) abs
    end
  in

  (* Explore the environment *)
  let receipt_ctx = ctx in
  let ctx = obj#visit_eval_ctx None ctx in
  (* Check we gave back to exactly one loan *)
  [%cassert] span !replaced "No loan updated";
  (* *)
  let metadata =
    object (self)
      inherit [_] map_eval_ctx as super
      method! visit_abs _ abs =
        let call_scopes =
          List.map
            (function Values.PendingParameterScope scope -> Values.PendingParameterScope { scope with witnesses = self#update_witnesses abs scope.witnesses } | Values.PhysicalInputScope scope -> Values.PhysicalInputScope { scope with witnesses = self#update_witnesses abs scope.witnesses })
            abs.call_scopes
        in
(*
```ocaml
*)
        super#visit_abs (Some abs) { abs with call_scopes }
(*
```
*)
      method private update_witnesses (abs : abs)
          (witnesses : call_endpoint_witnesses) =
(*
```ocaml
*)
        let captured, parent_routes =
          capture_input_physical_return span receipt_ctx abs witnesses bid nv supplier
        in
        let physical_returns = captured @ witnesses.physical_returns in
        let return_routes =
          List.sort_uniq Stdlib.compare (parent_routes @ witnesses.return_routes)
        in
(*
```
*)
        let supplied loan ty =
          let view =
            normalize_proj_ty ctx.type_ctx.type_infos abs.regions.owned ty
          in
          let matches =
            List.filter_map
              (fun (owner, direction, mask, result) ->
                if owner = abs.abs_id && direction = loan && mask = view
                then Some result else None)
              !completed_projections
          in
          match matches with
          | [ result ] -> result
          | [] when loan ->
              physical_loans abs ty
          | _ -> [%internal_error] span
        in
        let root_visitor =
          object (root_self)
            inherit [_] map_tavalue as root_super
            method! visit_tavalue env value =
              let child_ty () =
                let _, ty, _ = ty_as_ref value.ty in ty
              in
              match value.value with
              | ABorrow (AIgnoredMutBorrow (Some parent, child)) when parent = bid ->
                  let given_back = supplied true (child_ty ()) in
                  let child = root_self#visit_tavalue env child in
                  let given_back_meta = as_symbolic span nv.value in
                  { value with
                    value = ABorrow
                      (AEndedIgnoredMutBorrow
                         { child; given_back; given_back_meta }) }
              | ABorrow (AMutBorrow (pm, parent, child)) when parent = bid ->
                  let () = [%sanity_check] span (pm = PNone) in
                  let child = root_self#visit_tavalue env child in
                  let given_back = as_symbolic span nv.value in
                  { value with
                    value = ABorrow (AEndedMutBorrow ({ bid; given_back }, child)) }
              | ALoan (AMutLoan (_, parent, child)) when parent = bid ->
                  let given_back = supplied false (child_ty ()) in
                  let child = root_self#visit_tavalue env child in
                  { value with
                    value = ALoan
                      (AEndedMutLoan { child; given_back; given_back_meta = nv }) }
              | ALoan (AIgnoredMutLoan (pm, Some parent, child)) when parent = bid ->
                  let given_back = mark_avalue pm (supplied false (child_ty ())) in
                  let child = root_self#visit_tavalue env child in
                  { value with
                    value = ALoan
                      (AEndedIgnoredMutLoan
                         { child; given_back; given_back_meta = nv; given_back_env }) }
              | _ -> root_super#visit_tavalue env value
          end
        in
        let roots =
          List.map
            (fun (side, original, actual) ->
              (side, original, root_visitor#visit_tavalue () actual))
            witnesses.roots
        in
(*
```ocaml
*)
        { witnesses with roots; physical_returns; return_routes }
(*
```
*)
      method! visit_ECallEndpoints opt_abs witnesses body =
        ECallEndpoints
          (self#update_witnesses (Option.get opt_abs) witnesses,
           self#visit_tevalue opt_abs body)
    end
  in
  metadata#visit_eval_ctx None ctx

(* ```ocaml *)
let input_return_binding span (abs : abs) (nsv : symbolic_value) =
  let binding = ref None in
  let visitor = object (self)
    inherit [_] iter_tevalue as super
    method! visit_tevalue env (value : tevalue) =
      if Option.is_none !binding then
        match value.value with
        | EBorrow (EEndedMutBorrow (meta, _))
            when meta.given_back = nsv -> binding := Some value
        (*
```ocaml
        *)
        | ESymbolic (_, EEndedProjBorrows { mvalues; _ })
            when mvalues.given_back = nsv ->
            [%cassert] span (value.ty = nsv.sv_ty)
              "An ended input return changes its complete carrier";
            binding := Some value
        (*
```
        *)
        | ESymbolic (_, proj) -> super#visit_eproj (Some value) proj
        | _ -> super#visit_tevalue env value
    (*
```ocaml
    *)
    method! visit_ETransportedProj env transport child =
      if Option.is_none !binding then
        let parent = [%unwrap_with_span] span env
          "A transported input return has no complete receiver" in
        [%cassert] span (parent.ty = transport.receiver.proj_ty)
          "A transported input receiver changes its complete carrier";
        [%cassert] span (ValuesUtils.carrier_coordinate_return_matches transport)
          "A transported input return changes its authenticated carrier route";
        match parent.value with
        | ESymbolic (pm, _) ->
            let current : tevalue =
              { value = ESymbolic (pm, child); ty = transport.current.sv_ty }
            in
            self#visit_eproj (Some current) child
        | _ -> [%internal_error] span
    (*
```
    *)
    method! visit_eproj env proj =
      if Option.is_none !binding then
        match env, proj with
        | Some ({ value = ESymbolic (pm, _); _ } as parent),
          EEndedProjBorrows { mvalues; _ }
            when mvalues.given_back = nsv ->
            [%cassert] span (parent.ty = nsv.sv_ty)
              "A declared input return changes its complete carrier";
            binding := Some
              { value = ESymbolic (pm, proj); ty = parent.ty }
        | _ -> super#visit_eproj env proj
  end in
  Option.iter
    (fun cont ->
      Option.iter (visitor#visit_tevalue None) cont.output;
      if Option.is_none !binding then
        match abs.kind, Option.map call_protocol_body cont.input with
        | SynthInput group,
          Some { value = EApp (EInputAbs declared_group, arguments); _ } ->
            [%cassert] span (group = declared_group)
              "A declared input return changes its synthesis group";
            List.iter (List.iter (visitor#visit_tevalue None)) arguments
        | _ -> ())
    abs.cont;
  !binding
(* ``` *)

(* ```ocaml *)
let capture_input_symbolic_return span ctx (abs : abs)
    (witnesses : call_endpoint_witnesses) (proj : symbolic_proj)
    (nsv : symbolic_value) supplier =
  let rec path visited route (root : symbolic_value) =
    if root.sv_id = proj.sv_id then Some route
    else if SymbolicValueId.Set.mem root.sv_id visited then None
    else
      let visited = SymbolicValueId.Set.add root.sv_id visited in
      match List.find_opt (fun ((source : symbolic_value), _) ->
        source.sv_id = root.sv_id)
        witnesses.expansions with
      | None -> None
      | Some (_, SeLiteral _) -> None
      | Some (_, (SeMutRef (_, child) | SeSharedRef (_, child))) ->
          path visited (route @ [ PDeref ]) child
      | Some (_, SeAdt (variant, fields)) ->
          List.find_map (fun (index, field) ->
            path visited (route @ [ PField (variant, index) ]) field)
            (List.mapi (fun index field -> (index, field)) fields)
  in
  let covers_scope (scope : call_scope) =
    let owned =
      match supplier with
      | SymbolicInputReturn (_, _, _, _, owned, _)
      | AbstractionInputReturn (_, _, _, owned, _) -> owned
      | ConcreteInputReturn _ ->
          [%internal_error] span
      | FieldInputReturn _ | DeclaredCallInputReturn _ -> [%internal_error] span
    in
    let source_mask = RegionId.Set.inter owned
      (ty_regions ctx.type_ctx.type_infos nsv.sv_ty) in
    try
      let bindings = projection_metadata_renaming ~mismatch:Exit
        span ctx.type_ctx.type_infos nsv.sv_ty (call_scope_ty scope) in
      let transported = RegionId.Set.fold
        (fun id mask ->
          match RegionId.Map.find_opt id bindings with
          | Some (RVar (Free destination)) -> RegionId.Set.add destination mask
          | None -> RegionId.Set.add id mask
          | _ -> raise Exit)
        source_mask RegionId.Set.empty in
      let () =
        let log = Logging.carrier_events_log in
        [%ldebug
          "Carrier return transport event:\nowner: " ^ AbsId.to_string abs.abs_id
          ^ "\ncurrent return: " ^ show_symbolic_value nsv
          ^ "\nsource projector: " ^ show_symbolic_proj proj
          ^ "\nslot: " ^ call_scope_slot_to_string scope
          ^ "\nsource mask: " ^ RegionId.Set.to_string None source_mask
          ^ "\nregion transport: "
          ^ RegionId.Map.to_string None Types.show_region bindings
          ^ "\ndestination mask: " ^ RegionId.Set.to_string None transported
          ^ "\nexact mask: "
          ^ string_of_bool (RegionId.Set.equal transported (call_scope_regions scope))]
      in
      RegionId.Set.equal transported (call_scope_regions scope)
    with Exit -> false
  in
(*
```ocaml
*)
  let return_routes = ref [] in
  let captures = List.concat_map (fun (origin : carrier_origin) ->
(*
```ocaml
*)
    let producer_branch = match supplier with
      | SymbolicInputReturn (_, _, _, _, _, Some { value = ESymbolic (branch, _); _ })
      | AbstractionInputReturn (_, _, _, _, Some { value = ESymbolic (branch, _); _ }) ->
          branch
      | _ -> PNone in
(*
```
*)
    let direct root =
      Option.bind (path SymbolicValueId.Set.empty [] root)
        (fun position ->
(*
```ocaml
*)
          Option.map (fun source_ty -> (producer_branch, position, source_ty, None))
(*
```
*)
            (input_return_route_ty ctx root.sv_ty position)) in
    let returned_at =
      match direct origin.transport_root with
      | Some _ as returned_at -> returned_at
      | None ->
          (match direct origin.original_root with
           | Some _ as returned_at -> returned_at
           | None ->
               let routes = List.filter_map
                 (fun (previous : input_return_route) ->
                   if previous.route_origin <> origin then None
                   else
                     Option.bind
                       (path SymbolicValueId.Set.empty [] previous.route_current)
                       (fun relative ->
                         Option.map (fun source_ty ->
                           (previous.route_branch,
                            previous.route_position @ relative, source_ty,
                            Some previous))
                           (input_return_route_ty ctx
                             previous.route_current.sv_ty relative)))
                 witnesses.return_routes |> List.sort_uniq Stdlib.compare in
               match routes with
               | [] -> None
               | [ route ] -> Some route
               | _ -> [%craise] span
                   "A current return has several authenticated source routes") in
    let route =
      Option.bind returned_at (fun (branch, position, source_ty, previous) ->
        try
          let relation = projection_metadata_renaming ~mismatch:Exit
            span ctx.type_ctx.type_infos source_ty proj.proj_ty in
          [%cassert] span (proj.proj_ty = nsv.sv_ty)
            "A current return changes its complete projector type";
          let owner = [%unwrap_with_span] span
            (input_return_supplier_owner supplier)
            "A symbolic return has no producer owner" in
          Some { route_origin = origin; route_branch = branch;
            route_position = position; route_source = proj; route_current = nsv;
            route_supplier = supplier; route_kind = (ctx_lookup_abs ctx owner).kind;
            route_relation = RegionId.Map.bindings relation;
(*
```ocaml
*)
            route_loan = None;
(*
```ocaml
*)
            route_physical_parents = [];
(*
```
*)
(*
```
*)
            route_previous = previous }
        with Exit -> None) in
    let () =
      let log = Logging.carrier_events_log in
      [%ldebug
        "Carrier return route event:\nowner: " ^ AbsId.to_string abs.abs_id
        ^ "\norigin: " ^ show_carrier_origin origin
        ^ "\nsource projector: " ^ show_symbolic_proj proj
        ^ "\ncurrent return: " ^ show_symbolic_value nsv
(*
```ocaml
*)
        ^ "\nauthenticated current route: "
        ^ (match route with None -> "absent"
           | Some route ->
               "present\nposition: "
               ^ String.concat "/" (List.map show_value_path_step route.route_position)
               ^ "\nproducer kind: " ^ show_abs_kind route.route_kind
               ^ "\nregion relation: "
               ^ RegionId.Map.to_string None Types.show_region
                   (RegionId.Map.of_list route.route_relation)
               ^ "\nprevious current return: "
               ^ (match route.route_previous with None -> "declaration"
                  | Some previous -> show_symbolic_value previous.route_current))]
(*
```
*)
    in
    match route with
    | None -> []
    | Some route ->
        return_routes := route :: !return_routes;
(*
```ocaml
*)
        List.filter_map (fun scope ->
          if not (call_scope_matches_origin scope origin)
             || not (covers_scope scope)
          then None
          else Some ({ origin; slot = call_scope_receipt_slot scope; branch = route.route_branch;
(*
```
*)
            returned_borrow = None; returned_at = route.route_position;
            full_return_ty = nsv.sv_ty;
            current_payload = mk_tvalue_from_symbolic_value
              ctx.type_ctx.type_infos ctx.metadata_bindings nsv;
(* ```ocaml *)
            supplier; conversion = None } : input_physical_return)) abs.call_scopes)
(* ``` *)
    witnesses.carrier_origins in
(*
```
*)
  (* ```ocaml *)
  [%ldebug
    "Symbolic receipt creation:\n- owner: " ^ AbsId.to_string abs.abs_id
    ^ "\n- projected source: " ^ show_symbolic_proj proj
    ^ "\n- complete returned source: " ^ show_symbolic_value nsv
    ^ "\n- source origins:\n"
    ^ String.concat "\n" (List.map show_carrier_origin witnesses.carrier_origins)
    ^ "\n- pending declarations:\n"
    ^ String.concat "\n" (List.map
        call_scope_slot_to_string
        abs.call_scopes)
    ^ "\n- created receipts:\n"
    ^ String.concat "\n" (List.map show_input_physical_return captures)];
  (* ``` *)
(*
```ocaml
*)
  (captures @ witnesses.physical_returns,
   List.sort_uniq Stdlib.compare (!return_routes @ witnesses.return_routes))
(*
```
*)
(* ``` *)

let update_symbolic_return_metadata ?(include_owned = true)
    ?(include_outlive = true) span ended_regions (proj : symbolic_proj)
    (nsv : symbolic_value) supplier update_borrow update_loan ctx =
  let source_intersections =
    projection_intersections span ctx ended_regions proj.proj_ty
  in
(*
```ocaml
*)
  let intersections regions ty =
    let owned, outlive = source_intersections regions ty in
    (include_owned && owned, include_outlive && outlive)
  in
(*
```
*)
  let visitor =
    object (self)
      inherit [_] map_eval_ctx_carrier_coordinates as super
      method! visit_abs _ abs =
        let call_scopes =
          List.map
            (function Values.PendingParameterScope scope -> Values.PendingParameterScope { scope with witnesses = self#update_witnesses abs scope.witnesses } | Values.PhysicalInputScope scope -> Values.PhysicalInputScope { scope with witnesses = self#update_witnesses abs scope.witnesses })
            abs.call_scopes
        in
(*
```ocaml
*)
        super#visit_abs (Some abs) { abs with call_scopes }
(*
```
*)
      method private update_witnesses (abs : abs)
          (roots : call_endpoint_witnesses) =
(*
```ocaml
*)
        let physical_returns, return_routes = match supplier with
          | None -> (roots.physical_returns, roots.return_routes)
          | Some supplier ->
              capture_input_symbolic_return span ctx abs roots proj nsv supplier
        in
(*
```
*)
        let root_visitor =
          object
            inherit [_] map_eval_ctx_carrier_coordinates as root_super
            method! visit_aproj env value =
              let abs = Option.get env in
              let update (source : symbolic_proj) apply =
                if source.sv_id <> proj.sv_id then value
                else
                  let owned, outlive =
                    intersections abs.regions.owned source.proj_ty
                  in
                  if owned || outlive then
                    apply ~owned ~outlive abs
                  else root_super#visit_aproj env value
              in
              match value with
              | AProjBorrows source -> (
                  match update_borrow with
                  | Some apply ->
                      update source.proj
                        (fun ~owned ~outlive abs ->
                          apply ~owned ~outlive abs source)
                  | None -> root_super#visit_aproj env value)
              | AProjLoans source -> (
                  match update_loan with
                  | Some apply ->
                      update source.proj
                        (fun ~owned ~outlive abs ->
                          apply ~owned ~outlive abs source)
                  | None -> root_super#visit_aproj env value)
              | _ -> root_super#visit_aproj env value
          end
        in
        let actual_roots =
          List.map
            (fun (from_input, original_root, actual_root) ->
              (from_input, original_root,
               root_visitor#visit_tavalue (Some abs) actual_root))
            roots.roots
        in
(*
```ocaml
*)
        { roots with roots = actual_roots; physical_returns; return_routes }
(*
```
*)
      method! visit_ECallEndpoints opt_abs roots body =
        ECallEndpoints
          (self#update_witnesses (Option.get opt_abs) roots,
           self#visit_tevalue opt_abs body)
      method! visit_tevalue opt_abs value =
        let pending =
          match value.value with
          | ESymbolic (pm, EPendingSymbolicLoans slot) ->
              Some (pm, slot, value, [])
          | ERecombine
              (({ value = ESymbolic (pm, EPendingSymbolicLoans slot); _ } as base),
               suppliers) ->
              Some (pm, slot, base, suppliers)
          | _ -> None
        in
        match pending with
        | Some (pm, slot, base, suppliers)
          when slot.root_sv_id = proj.sv_id
               || List.exists
                    (fun ((meta : mconsumed_symb), _) ->
                      meta.sv_id = proj.sv_id)
                    suppliers ->
            let _, outlive = intersections slot.proj_regions slot.proj_ty in
            if outlive
               && ty_has_mut_borrow_for_region_in_set ctx.type_ctx.type_infos
                    ended_regions proj.proj_ty
            then
              let meta : mconsumed_symb =
                {
                  sv_id = nsv.sv_id;
                  proj_ty = nsv.sv_ty;
                  proj_regions = ended_regions;
                }
              in
              if List.exists (fun (source, _) -> source = meta) suppliers then value
              else
              let supplied =
                mk_eproj_loans_value_from_symbolic_value ctx.type_ctx.type_infos
                  slot.proj_regions nsv slot.proj_ty
              in
              let supplied =
                match supplied.value with
                | ESymbolic (_, child) ->
                    { supplied with value = ESymbolic (pm, child) }
                | _ -> supplied
              in
              { value with
                value = ERecombine (base, suppliers @ [ (meta, supplied) ]) }
            else value
        | _ -> super#visit_tevalue opt_abs value
    end
  in
  visitor#visit_eval_ctx None ctx

(** Return children retain the actual carrier type and one mutable identity.
    An authenticated operation supplies a local coordinate view when necessary. *)
(*
```ocaml
*)
let returned_child_projector span ctx (abs : abs) (source : symbolic_proj)
    (returned : symbolic_value) (receiver : symbolic_proj) =
  [%cassert] span
    (source.sv_id = receiver.sv_id && source.proj_ty = returned.sv_ty)
    "A returned child lacks its complete source-to-return type relation";
  let child : symbolic_proj =
    { sv_id = returned.sv_id; proj_ty = returned.sv_ty }
  in
  if projection_masks_equal span ctx abs.regions.owned
       receiver.proj_ty returned.sv_ty
  then (child, None)
  else
    let routes = ref [] in
    let declared_origin origin =
      match abs.cont with
      | Some { input = Some { value = ECallEndpoints (witnesses, _); _ }; _ } ->
          List.mem origin witnesses.carrier_origins
      | _ -> false
    in
    let collect (witnesses : call_endpoint_witnesses) =
      List.iter
        (fun (route : input_return_route) ->
          let origin = route.route_origin in
          if route.route_current = returned && route.route_source = source
             && (match origin.source_role with
               | OrdinaryCallOutputOrigin _ ->
                   origin.source_owner = abs.abs_id
                   && input_return_route_ty ctx origin.original_root.sv_ty
                        route.route_position = Some receiver.proj_ty
               | FunctionInputOrigin _ ->
                   (origin.source_owner = abs.abs_id
                    && declared_origin origin
                    && input_return_route_ty ctx origin.original_root.sv_ty
                         route.route_position = Some receiver.proj_ty)
                   ||
                   List.exists (fun scope ->
                     let witnesses = call_scope_witnesses scope in
                     call_scope_ty scope = origin.transport_root.sv_ty
                     && call_scope_matches_origin scope origin
                     && RegionId.Set.subset (call_scope_regions scope) abs.regions.owned
                     && List.mem origin witnesses.carrier_origins
                     && input_return_route_ty ctx origin.transport_root.sv_ty
                          route.route_position = Some receiver.proj_ty
                     && Option.fold ~none:false ~some:(fun declared ->
                          map_free_region_aliases
                            (rename_projection_metadata_region
                               (RegionId.Map.of_list route.route_relation))
                            declared = source.proj_ty)
                          (input_return_route_ty ctx origin.original_root.sv_ty
                             route.route_position)
                     && (check_function_input_interface span ctx witnesses
                           origin (ctx_lookup_abs ctx origin.source_owner); true))
                     abs.call_scopes)
          then
            match route.route_supplier with
            | SymbolicInputReturn
                (owner, _, projected, current, _, Some producer)
              when owner <> abs.abs_id && projected = source
                   && current = returned && producer.ty = returned.sv_ty ->
                routes := route :: !routes
            | _ -> ())
        witnesses.return_routes
    in
    let scan collect =
    let visitor = object
      inherit [_] iter_tevalue as super
      method! visit_ECallEndpoints env witnesses body =
        collect witnesses;
        super#visit_tevalue env body
    end in
    List.iter
      (function
        | EAbs owner ->
(*
```ocaml
*)
            List.iter (fun scope -> collect (call_scope_witnesses scope)) owner.call_scopes;
(*
```
*)
            Option.iter
              (fun cont ->
                Option.iter (visitor#visit_tevalue ()) cont.output;
                Option.iter (visitor#visit_tevalue ()) cont.input)
              owner.cont
        | EBinding _ | EFrame -> ())
      ctx.env in
    scan collect;
    let route =
      match List.sort_uniq Stdlib.compare !routes with
      | [ route ] -> route
      | _ ->
          if !Config.print_error_diagnostics || !Config.print_error_emitters then begin
            Printf.eprintf
              "Whole symbolic return authority:\nowner: %s\nowned: %s\nsource: %s\nreceiver: %s\nreturned: %s\n%!"
              (AbsId.to_string abs.abs_id) (RegionId.Set.to_string None abs.regions.owned)
              (show_symbolic_proj source) (show_symbolic_proj receiver)
              (show_symbolic_value returned);
(*
```ocaml
*)
            List.iter (fun scope ->
              Printf.eprintf "Execution scope:\nslot: %s\norigins: %s\n%!"
                (call_scope_slot_to_string scope)
                (String.concat "\n" (List.map show_carrier_origin
                   (call_scope_witnesses scope).carrier_origins))) abs.call_scopes;
(*
```
*)
            let describe (witnesses : call_endpoint_witnesses) =
              List.iter (fun (route : input_return_route) ->
                if route.route_current = returned && route.route_source = source then
                  let owner, level, mask = match route.route_supplier with
                    | SymbolicInputReturn (owner, level, _, _, mask, _) ->
                        (AbsId.to_string owner, string_of_int level,
                         RegionId.Set.to_string None mask)
                    | _ -> ("none", "none", "none") in
                  Printf.eprintf
                    "Actual symbolic route:\nposition: [%s]\nproducer: %s\nlevel: %s\nmask: %s\nroute: %s\n%!"
                    (String.concat "/" (List.map show_value_path_step route.route_position))
                    owner level mask (show_input_return_route route))
                witnesses.return_routes in
            scan describe
          end;
          [%craise] span
            "A returned child lacks a unique authenticated complete carrier route"
    in
    let origin = route.route_origin in
    let renaming =
      if origin.source_owner = abs.abs_id
         && input_return_route_ty ctx origin.original_root.sv_ty
              route.route_position = Some receiver.proj_ty then
        projection_metadata_renaming span ctx.type_ctx.type_infos
          receiver.proj_ty returned.sv_ty
      else
        let declared = [%unwrap_with_span] span
          (input_return_route_ty ctx origin.original_root.sv_ty route.route_position)
          "A symbolic return loses its declared source path" in
        let body = projection_metadata_renaming span ctx.type_ctx.type_infos
          declared receiver.proj_ty in
        let current = RegionId.Map.of_list route.route_relation in
        let renaming = RegionId.Map.fold (fun canonical body renaming ->
          let body = match body with
            | RVar (Free body) -> body
            | _ -> [%craise] span "A receiver interface has no physical region" in
          let destination = rename_projection_metadata_region current
            (RVar (Free canonical)) in
          [%cassert] span
            (Option.fold ~none:true ~some:(( = ) destination)
               (RegionId.Map.find_opt body renaming))
            "A receiver interface has conflicting current coordinates";
          RegionId.Map.add body destination renaming)
          body RegionId.Map.empty in
        [%cassert] span
          (map_free_region_aliases (rename_projection_metadata_region renaming)
             receiver.proj_ty = returned.sv_ty)
          "A symbolic return changes its complete stored coordinate proof";
        renaming in
    let receiver_regions = RegionId.Set.inter abs.regions.owned
      (ty_regions ctx.type_ctx.type_infos receiver.proj_ty) in
    let current_regions = RegionId.Set.fold
      (fun source regions ->
        match RegionId.Map.find_opt source renaming with
        | Some (RVar (Free current)) -> RegionId.Set.add current regions
        | None -> RegionId.Set.add source regions
        | _ -> [%craise] span
            "A current carrier coordinate does not denote a physical region")
      receiver_regions RegionId.Set.empty in
    [%cassert] span
      (compare_rtys span ctx true ( && )
         (fun original current ->
           region_in_set original receiver_regions
           = region_in_set current current_regions)
         receiver.proj_ty returned.sv_ty)
      "A carrier coordinate transport changes its selected stored positions";
    let transport : carrier_coordinate_transport =
      { receiver; receiver_regions; current = returned; current_regions;
        return_source = SymbolicCarrierReturn route }
(*
```
*)
    in
    (child, Some transport)

let returned_abstract_child span ctx abs source returned receiver make =
  let proj, transport =
    returned_child_projector span ctx abs source returned receiver in
  let child = make proj in
  match transport with
  | None -> child
  | Some transport -> ATransportedProj (transport, child)

(*
```ocaml
*)
let returned_continuation_child span ctx abs source returned
    (receiver : esymbolic_proj) make =
  let receiver : symbolic_proj =
    { sv_id = receiver.sv_id; proj_ty = receiver.proj_ty } in
  let proj, transport =
    returned_child_projector span ctx abs source returned receiver in
  let proj : esymbolic_proj = { sv_id = proj.sv_id; proj_ty = proj.proj_ty } in
  let child = make proj in
(*
```
*)
  match transport with
  | None -> child
  | Some transport -> ETransportedProj (transport, child)
(*
```
*)

(** Update the borrow projectors upon ending some regions in a symbolic value.

    Because doing this introduces a fresh symbolic value which may contain
    borrows, we may need to update the proj_borrows to introduce loan projectors
    over those borrows.

    Note that we also update the abstraction expressions. *)
(*
```ocaml
*)
let end_aproj_borrows (span : Meta.span) (ended_regions : RegionId.Set.t)
    (proj : symbolic_proj) (nsv : symbolic_value) producer_id producer_level
    (ctx : eval_ctx) : eval_ctx * input_return_supplier =
(*
```
*)
  (* Sanity checks *)
  [%sanity_check] span (proj.sv_id <> nsv.sv_id && ty_is_rty ctx.type_ctx.type_infos proj.proj_ty);
  [%ltrace
    "- ended regions: "
    ^ RegionId.Set.to_string None ended_regions
    ^ "\n- projection type: "
    ^ ty_to_string ctx proj.proj_ty
    ^ "\n- sv: "
    ^ symbolic_value_id_to_pretty_string proj.sv_id
    ^ "\n- nsv: "
    ^ symbolic_value_to_string ctx nsv
    ^ "\n- ctx: " ^ eval_ctx_to_string ctx];
  let carrier_ctx = ref ctx in
  (* See the comments about [AProjLoans], we have to update in two situations:
     - if the projection over the symbolic value intersects the borrow projector:
       this is because we are ending exactly this borrow projector, so we need
       to end it.
     - if the *outlive* projection intersects the borrow projector: we need to
       project the inner loans of the given back value.
  *)
  (* ```ocaml *)
  let update_mut ~owned ~outlive (abs : abs) (aproj : aproj_borrows) : aproj =
  (* ``` *)

    (* We can be in one case, or the other, but not both *)
    [%sanity_check] span ((not owned) || not outlive);

    if owned then
      (* There is nothing to project *)
      let mvalues = { consumed = proj.sv_id; given_back = nsv } in
      AEndedProjBorrows { mvalues; loans = aproj.loans }
    else
      (* Compute the projection over the given back value (we project the loans) *)
(*
```ocaml
*)
      let loan =
        returned_abstract_child span !carrier_ctx abs proj nsv aproj.proj
          (fun proj -> AProjLoans { proj; consumed = []; borrows = [] })
      in
(*
```
*)
      let consumed : mconsumed_symb =
        { sv_id = nsv.sv_id; proj_ty = nsv.sv_ty; proj_regions = ended_regions }
      in
      (* The receiver still owns its original projection. The ended ancestor's
         mask only describes the given-back metadata, not this surviving borrow. *)
      AProjBorrows { aproj with loans = (consumed, loan) :: aproj.loans }
  in
  (* ```ocaml *)
  let update_emut ~owned ~outlive (abs : abs) (aproj : eproj_borrows) : eproj =
  (* ``` *)

    (* We can be in one case, or the other, but not both *)
    [%sanity_check] span ((not owned) || not outlive);

    if owned then
      (* There is nothing to project *)
      let mvalues = { consumed = proj.sv_id; given_back = nsv } in
      EEndedProjBorrows { mvalues; loans = aproj.loans }
    else
      (* Compute the projection over the given back value (we project the loans) *)
(*
```ocaml
*)
      let loan =
        returned_continuation_child span !carrier_ctx abs proj nsv aproj.proj
          (fun proj -> EProjLoans { proj; consumed = []; borrows = [] })
      in
(*
```
*)
      let consumed : mconsumed_symb =
        { sv_id = nsv.sv_id; proj_ty = nsv.sv_ty; proj_regions = ended_regions }
      in
      EProjBorrows { aproj with loans = (consumed, loan) :: aproj.loans }
  in
(*
```ocaml
*)
  let ctx =
    update_intersecting_aproj_borrows span ~fail_if_unchanged:true
      ~include_owned:true ~include_outlive:false ~update_shared:None ~update_mut
      ~update_emut ended_regions proj ctx
  in
  let ctx = update_symbolic_return_metadata ~include_outlive:false
    span ended_regions proj nsv None (Some update_mut) None ctx in
  let producer = ctx_lookup_abs ctx producer_id in
  let supplier = SymbolicInputReturn
    (producer_id, producer_level, proj, nsv, ended_regions,
     input_return_binding span producer nsv) in
  let () =
    if !Config.print_error_diagnostics || !Config.print_error_emitters then
      Printf.eprintf
        "Symbolic return producer: owner=%s level=%d source=%s current=%s mask=%s endpoint=%s\n%!"
        (AbsId.to_string producer_id) producer_level
        (SymbolicValueId.to_string proj.sv_id)
        (SymbolicValueId.to_string nsv.sv_id)
        (RegionId.Set.to_string None ended_regions)
        (Option.fold ~none:"none" ~some:show_tevalue
          (input_return_binding span producer nsv))
  in

(* ```ocaml *)
  let () =
    if (!Config.print_error_diagnostics || !Config.print_error_emitters)
       && Option.is_none (input_return_binding span producer nsv) then
      let text = Option.fold ~none:"none" ~some:show_abs_cont producer.cont in
      let limit = Stdlib.min 8192 (String.length text) in
      Printf.eprintf
        "Missing symbolic return endpoint: owner=%s kind=%s level=%d source=%s current=%s continuation bytes=%d shown=%d\n%s\n%!"
        (AbsId.to_string producer_id) (show_abs_kind producer.kind) producer_level
        (SymbolicValueId.to_string proj.sv_id) (SymbolicValueId.to_string nsv.sv_id)
        (String.length text) limit (String.sub text 0 limit)
  in
(* ``` *)

  let ctx = update_symbolic_return_metadata span ended_regions proj nsv
    (Some supplier) None None ctx in
  carrier_ctx := ctx;
  let ctx =
    update_intersecting_aproj_borrows span ~fail_if_unchanged:false
      ~include_owned:false ~include_outlive:true ~update_shared:None ~update_mut
      ~update_emut ended_regions proj ctx
  in
  let ctx = update_symbolic_return_metadata ~include_owned:false
    span ended_regions proj nsv None (Some update_mut) None ctx in
  (ctx, supplier)
(*
```
*)

(** Give back a *modified* symbolic value. *)
let give_back_symbolic_value (_config : config) (span : Meta.span)
    (ended_regions : RegionId.Set.t) (proj : symbolic_proj)
    (nsv : symbolic_value) (supplier : input_return_supplier)
    (ctx : eval_ctx) : eval_ctx =
(*
```ocaml
*)
  let ctx_before = ctx in
(*
```
*)
  (* Sanity checks *)
  [%sanity_check] span (proj.sv_id <> nsv.sv_id && ty_is_rty ctx.type_ctx.type_infos proj.proj_ty);
  (* Substitution functions, to replace the borrow projectors over symbolic values *)
  (* We need to handle two cases:
     - the regions ended in the symbolic value might intersect with the owned
       regions of the abstraction.

       Ex.: we are ending abs1 below:
       {[
         abs0 {'a} { AProjLoans (s0 : &'a mut T) [] }
         abs1 {'b} { AProjBorrows (s0 : &'a mut T <: &'b mut T) }
       ]}
     - the regions given back in the symbolic value might intersect with the outlive
       regions of the abstraction, in which case we have to introduce a projection
       (because it means we ended ancestor "outer" borrows, and so we need
       to project the given back inner borrows into the abstraction).

       Ex.: we are ending abs2 below, and considering abs1: we have to project
       the inner borrows inside of abs1. However we do not project anything
       into abs0 (see the case above).
       {[
         abs0 {'a} { AProjLoans (s0 : &'a mut &'b mut T) [] }
         abs1 {'b} { AProjLoans (s0 : &'a mut &'b mut T) [] }
         abs2 {'c} { AProjBorrows (s0 : &'a mut &'b mut T <: &'c mut T &'d mut T) }
         abs3 {'d} { AProjBorrows (s0 : &'a mut &'b mut T <: &'c mut T &'d mut T) }
       ]}

     We proceed in two steps:
     - we first update when intersecting with ancestors regions
     - then we update when intersecting with owned regions

     If the ended regions hold no mutable borrow in the projection type, the
     ended projector only held shared borrows (e.g., the ['a] of
     [Option<&'a &'b mut T>] after [Option::as_ref]): the inner borrows below
     them are frozen and the value given back is the original one on these
     positions (there is no interior mutability). Their inner borrows are the
     original ones, which their holders still own: we do not project them
     into the outliving abstractions, which give back nothing for them (see
     [SymbolicToPureTypes.back_input_is_frozen]).
  *)
  let frozen_outlive =
    not
      (ty_has_mut_borrow_for_region_in_set ctx.type_ctx.type_infos
         ended_regions proj.proj_ty)
  in
  (* ```ocaml *)
  let subst ~owned ~outlive (abs : abs) (aproj : aproj_loans) : aproj =
  (* ``` *)

    [%sanity_check] span ((not owned) || not outlive);
    if outlive && frozen_outlive then AProjLoans aproj
    else if owned then
      (* There is nothing to project *)
      let child_proj = AEmpty in
      let consumed : mconsumed_symb =
        { sv_id = nsv.sv_id; proj_ty = nsv.sv_ty; proj_regions = ended_regions }
      in
      AProjLoans
        { aproj with consumed = (consumed, child_proj) :: aproj.consumed }
    else
      (* Compute the projection over the given back value *)
(*
```ocaml
*)
      let borrow =
        returned_abstract_child span ctx abs proj nsv aproj.proj
          (fun proj -> AProjBorrows { proj; loans = [] })
      in
(*
```
*)
      let consumed : mconsumed_symb =
        { sv_id = nsv.sv_id; proj_ty = nsv.sv_ty; proj_regions = ended_regions }
      in
      AProjLoans { aproj with borrows = (consumed, borrow) :: aproj.borrows }
  in
  (* ```ocaml *)
  let esubst ~owned ~outlive (abs : abs) (aproj : eproj_loans) : eproj =
  (* ``` *)

    [%sanity_check] span ((not owned) || not outlive);
    if outlive && frozen_outlive then EProjLoans aproj
    else if owned then
      (* There is nothing to project *)
      let child_proj = EEmpty in
      let consumed : mconsumed_symb =
        { sv_id = nsv.sv_id; proj_ty = nsv.sv_ty; proj_regions = ended_regions }
      in
      EProjLoans
        { aproj with consumed = (consumed, child_proj) :: aproj.consumed }
    else
      (* Compute the projection over the given back value *)
(*
```ocaml
*)
      let borrow =
        returned_continuation_child span ctx abs proj nsv aproj.proj
          (fun proj -> EProjBorrows { proj; loans = [] })
      in
(*
```
*)
      let consumed : mconsumed_symb =
        { sv_id = nsv.sv_id; proj_ty = nsv.sv_ty; proj_regions = ended_regions }
      in
      EProjLoans { aproj with borrows = (consumed, borrow) :: aproj.borrows }
  in
  let ctx =
    update_intersecting_aproj_loans span ~fail_if_unchanged:true
      ~include_owned:true ~include_outlive:true ended_regions proj subst esubst
      ctx
  in
(*
```ocaml
*)
  diagnose_symbolic_runtime_type_transition span
    "give_back_symbolic_value: projector update" ctx_before ctx;
  let ctx_before_metadata = ctx in
(*
```
*)
(*
```ocaml
*)
  let ctx = update_symbolic_return_metadata span ended_regions proj nsv
    (Some supplier) None (Some subst) ctx in
  diagnose_symbolic_runtime_type_transition span
    "give_back_symbolic_value: return metadata update" ctx_before_metadata ctx;
  ctx
(*
```
*)

(** Convert an {!type:avalue} to a {!type:value}.

    This function is used when ending abstractions: whenever we end a borrow in
    an abstraction, we convert the borrowed {!avalue} to a fresh symbolic
    {!type:value}, then give back this {!type:value} to the context.

    Note that some regions may have ended in the symbolic value we generate. For
    instance, consider the following function signature:
    {[
      fn f<'a>(x : &'a mut &'a mut u32);
    ]}
    When ending the abstraction, the value given back for the outer borrow
    should be ⊥. In practice, we will give back a symbolic value which can't be
    expanded (because expanding this symbolic value would require expanding a
    reference whose region has already ended). *)
let convert_avalue_to_given_back_value (span : Meta.span) ctx (av : tavalue) :
    symbolic_value =
  mk_fresh_symbolic_value span ctx av.ty

(** Auxiliary function: see {!end_borrow_aux}.

    When we end a mutable borrow, we need to "give back" the value it contained
    to its original owner by reinserting it at the proper position.

    Rem.: this function is used when we ending *concrete* borrows (we handle
    borrows inside region abstractions elsewhere). *)
let give_back_concrete (span : Meta.span) (l : unique_borrow_id)
    (bc : g_borrow_content) (ctx : eval_ctx) : eval_ctx =
  (* Debug *)
  [%ltrace
    let bc =
      match bc with
      | Concrete bc -> borrow_content_to_string ~span:(Some span) ctx bc
      | Abstract bc -> aborrow_content_to_string ~span:(Some span) ctx bc
    in
    "- bid: "
    ^ unique_borrow_id_to_string l
    ^ "\n- content: " ^ bc ^ "\n- context:\n"
    ^ eval_ctx_to_string ~span:(Some span) ctx];
  (* This is used for sanity checks *)
  let sanity_ek =
    { enter_shared_loans = true; enter_mut_borrows = true; enter_abs = true }
  in
  match bc with
  | Concrete (VMutBorrow (l', tv)) ->
      (* Sanity check *)
      [%sanity_check] span (UMut l' = l);
      [%sanity_check] span (not (concrete_loans_in_value tv));
      (* Check that the corresponding loan is somewhere - purely a sanity check *)
      [%sanity_check] span
        (Option.is_some (ctx_lookup_loan_opt span sanity_ek l' ctx));
      (* Update the context *)
      give_back_value span l' tv
        (ConcreteInputReturn (l', mk_evalue ctx.env tv.ty tv)) ctx
  | Concrete (VSharedBorrow (bid, l') | VReservedMutBorrow (bid, l')) ->
      (* Sanity check *)
      [%sanity_check] span (UShared (bid, l') = l);
      (* Check that the borrow is somewhere - purely a sanity check *)
      [%sanity_check] span
        (Option.is_some (ctx_lookup_loan_opt span sanity_ek bid ctx));
      (* We have nothing to update in the context *)
      ctx
  | Abstract _ ->
      (* We shouldn't get here: ending borrows inside abstractions is taken care
       of separately *)
      [%internal_error] span

let check_borrow_disappeared (span : Meta.span) (fun_name : string)
    (l : unique_borrow_id) (ctx0 : eval_ctx) (ctx : eval_ctx) : unit =
  (match lookup_borrow_opt span ek_all l ctx with
  | None -> () (* Ok *)
  | Some _ ->
      log#ltrace
        (lazy
          (fun_name ^ ": "
          ^ unique_borrow_id_to_string l
          ^ ": borrow didn't disappear:\n- original context:\n"
          ^ eval_ctx_to_string ~span:(Some span) ctx0
          ^ "\n\n- new context:\n"
          ^ eval_ctx_to_string ~span:(Some span) ctx));
      [%internal_error] span);
  match l with
  | UShared _ -> ()
  | UMut l -> (
      match ctx_lookup_loan_opt span ek_all l ctx with
      | None -> () (* Ok *)
      | Some _ ->
          log#ltrace
            (lazy
              (fun_name ^ ": " ^ BorrowId.to_string l
             ^ ": loan didn't disappear:\n- original context:\n"
              ^ eval_ctx_to_string ~span:(Some span) ctx0
              ^ "\n\n- new context:\n"
              ^ eval_ctx_to_string ~span:(Some span) ctx));
          [%internal_error] span)

(** Discharge shared borrows whose ownership is already supplied inside the same
    abstraction and branch, including loans inside retained payloads. Collapse
    and abstraction teardown can both expose these internal ownership edges.
    There is no shared backward component to compose: preserve the existing
    continuation and the positional shape of every abstract child. Loans are
    ended separately, only after checking all remaining borrowers globally. *)
let eliminate_internal_shared_borrows (span : Meta.span) (ctx : eval_ctx)
    (abs : abs) : abs =
  if not abs.can_end then abs
  else
    let loans = ref MarkedBorrowId.Map.empty in
    let loan_projs = ref [] in
    (*
```ocaml
    *)
    let discharged = ref MarkedNormSymbProj.Set.empty in
    let add_loan level pm bid =
      let levels =
        match MarkedBorrowId.Map.find_opt (pm, bid) !loans with
        | None -> AbsLevelSet.empty
        | Some levels -> levels
      in
      loans :=
        MarkedBorrowId.Map.add (pm, bid) (AbsLevelSet.add level levels) !loans
    in
    let shared_only (proj : symbolic_proj) =
      not
        (ty_has_mut_borrow_for_region_in_set ctx.type_ctx.type_infos
           abs.regions.owned proj.proj_ty)
    in
    let collect =
      object (self)
        inherit [_] iter_tavalue_with_levels as super
        method incr_level (pm, level) = (pm, level + 1)

        method! visit_ASharedLoan (_, level) pm bid sv child =
          add_loan level pm bid;
          self#visit_tvalue (pm, level) sv;
          self#visit_tavalue (PNone, level) child

        method! visit_AEndedSharedLoan (_, level) pm sv child =
          self#visit_tvalue (pm, level) sv;
          self#visit_tavalue (PNone, level) child

        method! visit_VSharedLoan ((pm, level) as env) bid sv =
          add_loan level pm bid;
          super#visit_VSharedLoan env bid sv

        method! visit_ASymbolic (_, level) pm aproj =
          self#visit_aproj (pm, level) aproj

        method! visit_AProjLoans ((pm, level) as env) proj =
          if shared_only proj.proj then
            loan_projs := (pm, level, proj.proj) :: !loan_projs;
          super#visit_AProjLoans env proj
      end
    in
    List.iter (collect#visit_tavalue (PNone, 0)) abs.avalues;
    let has_loan pm level bid =
      match MarkedBorrowId.Map.find_opt (pm, bid) !loans with
      | None -> false
      | Some levels -> AbsLevelSet.mem level levels
    in
    let has_loan_proj pm level (proj : symbolic_proj) =
      (* A shared borrower may span several independently retained loan
           partitions. Their union must cover the entire borrower; neither
           partial overlap nor a loan at another level is enough. The union
           is only a coverage proof: keep every original loan mask intact. *)
      let coverage =
        List.fold_left
          (fun coverage (loan_pm, loan_level, (loan : symbolic_proj)) ->
            if pm = loan_pm && level = loan_level && proj.sv_id = loan.sv_id
            then
              let mask = normalize_proj_ty ctx.type_ctx.type_infos abs.regions.owned loan.proj_ty in
              Some
                (match coverage with
                | None -> mask
                | Some previous -> norm_proj_tys_union span ctx previous mask)
            else coverage)
          None !loan_projs
      in
      match coverage with
      | None -> false
      | Some coverage ->
          norm_proj_ty_contains span ctx coverage
            (normalize_proj_ty ctx.type_ctx.type_infos abs.regions.owned proj.proj_ty)
    in
    let update =
      object (self)
        inherit [_] map_abs_with_levels as super
        method incr_level (pm, level) = (pm, level + 1)

        method! visit_ASymbolic (_, level) pm aproj =
          ASymbolic (pm, self#visit_aproj (pm, level) aproj)

        method! visit_aproj (pm, level) aproj =
          let children values =
            List.map
              (fun (meta, child) ->
                (meta, self#visit_aproj (pm, level + 1) child))
              values
          in
          match aproj with
          (* ```ocaml *)
          | ATransportedProj _ -> aproj
          (* ``` *)
          | AProjBorrows { proj; loans } ->
              let loans = children loans in
              (* An unowned mutable ancestor can still give back a fresh
                   payload through this receiver. Keep it until that happens. *)
              if
                shared_only proj
                && (not
                      (ty_has_mut_borrows ctx.type_ctx.type_infos proj.proj_ty))
                && has_loan_proj pm level proj
              then
                let () =
                  if level = 0 && loans = [] then
                    discharged := MarkedNormSymbProj.Set.add
                      { pm; sv_id = proj.sv_id;
                        norm_proj_ty = normalize_proj_ty ctx.type_ctx.type_infos
                          abs.regions.owned proj.proj_ty } !discharged
                in
                if loans = [] then AEmpty
                else
                  AEndedProjLoans
                    { proj = proj.sv_id; consumed = loans; borrows = [] }
              else AProjBorrows { proj; loans }
          | AProjLoans ({ consumed; borrows; _ } as proj) ->
              AProjLoans
                {
                  proj with
                  consumed = children consumed;
                  borrows = children borrows;
                }
          | AEndedProjLoans ({ consumed; borrows; _ } as proj) ->
              AEndedProjLoans
                {
                  proj with
                  consumed = children consumed;
                  borrows = children borrows;
                }
          | AEndedProjBorrows ({ loans; _ } as proj) ->
              AEndedProjBorrows { proj with loans = children loans }
          | APendingLoans _ | APendingSymbolicLoans _ | AEmpty -> aproj

        method! visit_tavalue ((_, level) as env) av =
          let av = super#visit_tavalue env av in
          let value =
            match av.value with
            | ABorrow (ASharedBorrow (pm, bid, _)) when has_loan pm level bid ->
                AIgnored None
            | ABorrow (AProjSharedBorrow (pm, asb)) ->
                let asb =
                  List.filter
                    (function
                      | AsbBorrow (bid, _) -> not (has_loan pm level bid)
                      | AsbProjReborrows proj ->
                          not (has_loan_proj pm level proj))
                    asb
                in
                if asb = [] then AIgnored None
                else ABorrow (AProjSharedBorrow (pm, asb))
            | ASymbolic (_, AEmpty) -> AIgnored None
            | _ -> av.value
          in
          { av with value }
      end
    in
    let avalues = List.map (update#visit_tavalue (PNone, 0)) abs.avalues in
    let cont =
      if MarkedNormSymbProj.Set.is_empty !discharged then abs.cont
      else Option.map
        (fun (cont : abs_cont) ->
          let update =
            object
              inherit [_] map_eval_ctx_with_abs_levels as super
              method incr_level level = level + 1
              method! visit_ESymbolic level pm eproj =
                match eproj with
                | EProjBorrows { proj; loans = [] }
                  when level = 0
                       && MarkedNormSymbProj.Set.mem
                         { pm; sv_id = proj.sv_id;
                           norm_proj_ty = normalize_proj_ty ctx.type_ctx.type_infos
                             abs.regions.owned proj.proj_ty } !discharged ->
                    EIgnored
                | _ -> super#visit_ESymbolic level pm eproj
            end
          in
          { cont with output = Option.map (update#visit_tevalue 0) cont.output })
        abs.cont
    in
    { abs with avalues; cont }
    (*
```
    *)

(** Whether a projection over [regions] of a value of type [ty] may observe a
    shared borrow of [regions]: a shared reference of a region of [regions],
    or a type whose borrows are unknown here (an opaque type, a trait type, a
    trait object, a function type or a raw pointer with regions of [regions]).
    A recursive occurrence of a type being visited ([seen]) adds nothing. *)
let proj_may_observe_shared_borrows (span : Meta.span) (ctx : eval_ctx)
    (regions : RegionId.Set.t) (ty : ty) : bool =
  let rec visit (seen : ty list) (ty : ty) : bool =
    if List.mem ty seen then false
    else
      let seen = ty :: seen in
      match ty with
      | TRef (r, ref_ty, RShared) -> region_in_set r regions || visit seen ref_ty
      | TRef (_, ref_ty, RMut) -> visit seen ref_ty
      | TAdt { id = TAdtId id; generics } -> (
          let decl = ctx_lookup_type_decl span ctx id in
          let fields variant =
            Substitute.type_decl_get_instantiated_field_types decl variant
              generics
          in
          match decl.kind with
          | Struct _ -> List.exists (visit seen) (fields None)
          | Enum variants ->
              List.exists
                (fun i -> List.exists (visit seen) (fields (Some i)))
                (List.mapi (fun i _ -> VariantId.of_int i) variants)
          | _ -> ty_has_regions_in_set ctx.type_ctx.type_infos regions ty)
      | TAdt { id = TTuple | TBuiltin _; generics } ->
          List.exists (visit seen) generics.types
      | TArray (elem, _) | TSlice elem -> visit seen elem
      | TLiteral _ | TNever -> false
      | _ -> ty_has_regions_in_set ctx.type_ctx.type_infos regions ty
  in
  visit [] ty

(** End the shared observations of frozen mutable borrows which the end of a
    shared loan releases.

    A call which receives a shared borrow of a value holding mutable borrows
    (e.g., [Option::is_some] on [&'a Option<&'b mut T>]) leaves an
    abstraction for ['b] which observes the mutable borrows of the symbolic
    values of the shared value (see
    [InterpProjectors.apply_proj_borrows_on_shared_borrow]). A mutable borrow
    below a shared borrow is frozen: the callee and its outputs can only read
    through it, and only through the outer shared borrow ([&'a &'b mut T]
    gives [&'a T]). This relies on the absence of interior mutability, as the
    rest of Aeneas. Hence, once no shared loan holds a symbolic value, the
    observations of its mutable borrows are dead. Leaving them in the context
    makes them overlap the projection which later consumes the value (e.g.,
    the value given back to the lender of an outer mutable borrow).

    [released] is the value of the shared loan which just ended. We end, in
    every abstraction, the shared observations of the symbolic values of
    [released] which no shared loan of the context holds anymore, when the
    projected regions hold mutable borrows and no shared borrow (an
    observation of a shared borrow stays valid: copies of the borrow may
    outlive the loan, see [Invariants]). The other observations stay. The
    ended observations give nothing back (see [end_abs_borrows]). *)
let end_released_frozen_observations (span : Meta.span) (ctx : eval_ctx)
    (released : tvalue) : eval_ctx =
  let collect =
    object
      inherit [_] iter_tvalue

      method! visit_symbolic_value_id acc id =
        acc := SymbolicValueId.Set.add id !acc
    end
  in
  let svs = ref SymbolicValueId.Set.empty in
  collect#visit_tvalue svs released;
  let shared = ref SymbolicValueId.Set.empty in
  let shared_visitor =
    object
      inherit [_] iter_eval_ctx as super

      method! visit_VSharedLoan env bid sv =
        collect#visit_tvalue shared sv;
        super#visit_VSharedLoan env bid sv

      method! visit_ASharedLoan env pm bid sv child =
        collect#visit_tvalue shared sv;
        super#visit_ASharedLoan env pm bid sv child
    end
  in
  shared_visitor#visit_eval_ctx () ctx;
  let freed = SymbolicValueId.Set.diff !svs !shared in
  if SymbolicValueId.Set.is_empty freed then ctx
  else
    let frozen (regions : RegionId.Set.t) (proj : symbolic_proj) : bool =
      SymbolicValueId.Set.mem proj.sv_id freed
      && ty_has_mut_borrow_for_region_in_set ctx.type_ctx.type_infos regions
           proj.proj_ty
      && not (proj_may_observe_shared_borrows span ctx regions proj.proj_ty)
    in
    let visitor =
      object
        inherit [_] map_eval_ctx as super
        method! visit_abs _ abs = super#visit_abs (Some abs) abs

        method! visit_aborrow_content abs bc =
          match (bc, abs) with
          | AProjSharedBorrow (pm, asb), Some (abs : abs) ->
              let kept =
                List.filter
                  (function
                    | AsbProjReborrows proj ->
                        not (frozen abs.regions.owned proj)
                    | AsbBorrow _ -> true)
                  asb
              in
              (* An empty list is a shared projection with no live borrow,
                 as after [remove_borrow_from_asb] *)
              AProjSharedBorrow (pm, kept)
          | _ -> super#visit_aborrow_content abs bc
      end
    in
    visitor#visit_eval_ctx None ctx

(** End a borrow identified by its borrow id in a context.

    This function **preserves invariants** provided [allowed_abs] is [None]: if
    the borrow is inside another borrow/an abstraction, we end the outer
    borrow/abstraction first, etc.

    [chain]: contains the list of borrows/abstraction ids on which
    {!end_borrow_aux} and {!end_abs_aux} were called, to remember the chain of
    calls. This is useful for debugging purposes, and also for sanity checks to
    detect cycles (which shouldn't happen if the environment is well-formed).

    Rk.: from now onwards, the functions are written in continuation passing
    style. The reason is that when ending borrows we may end abstractions, which
    requires generating code for the translation (and we do this in CPS).

    TODO: we should split this function in two: one function which doesn't
    perform anything smart and is trusted, and another function for the
    book-keeping. *)
let rec end_borrow_aux (config : config) (span : Meta.span) ~(snapshots : bool)
    (chain : borrow_loan_abs_ids) (l : unique_borrow_id) : cm_fun =
 fun ctx ->
  (* Check that we don't loop *)
  let chain0 = chain in
  let chain =
    add_borrow_loan_abs_id_to_chain span "end_borrow_aux: " (BorrowId l) chain
  in
  [%ltrace
    unique_borrow_id_to_string l
    ^ ":\n- original context:\n"
    ^ eval_ctx_to_string ~span:(Some span) ctx];

  (* Utility function for the sanity checks: check that the borrow disappeared
   * from the context *)
  let ctx0 = ctx in
  let check = check_borrow_disappeared span "end borrow" l ctx0 in
  (* Start by ending the borrow itself (we lookup it up and replace it with [Bottom] *)
  match end_concrete_borrow_get_borrow span l ctx with
  (* Two cases:
     - error: we found outer borrows (the borrow is inside a borrowed value),
       inner loans (the borrow contains loans), or the borrow is inside a
       region abstraction
     - success: either we could not find the borrow or it was successfully
       replaced with [Bottom], and we can proceed to ending the corresponding loan.
  *)
  | Error priority -> (
      (* Debug *)
      [%ltrace
        unique_borrow_id_to_string l
        ^ ": found outer borrows/abs or inner loans:"
        ^ show_priority_borrow_or_abs priority];
      (* End the priority borrows, abstractions, then try again to end the target
       * borrow (if necessary) *)
      match priority with
      | OuterMutBorrow bid | OuterSharedLoan bid | InnerLoan bid ->
          (* End the outer borrows *)
          let ctx, cc = end_loan_aux config span ~snapshots chain bid ctx in
          (* Retry to end the borrow *)
          let ctx, cc =
            comp cc (end_borrow_aux config span ~snapshots chain0 l ctx)
          in
          (* Check and continue *)
          check ctx;
          (ctx, cc)
      | OuterAbs (abs_id, level) ->
          (* The borrow is inside an abstraction: end the whole abstraction *)
          let ctx, end_abs =
            end_abs_aux config span ~snapshots chain abs_id level ctx
          in
          (* Sanity check *)
          check ctx;
          (ctx, end_abs))
  | Ok (ctx, None) ->
      [%ltrace "borrow not found"];
      (* It is possible that we can't find a borrow in symbolic mode (ending
       * an abstraction may end several borrows at once *)
      [%sanity_check] span (config.mode = SymbolicMode);
      (* Do a sanity check and continue *)
      check ctx;
      (ctx, fun e -> e)
  (* We found a borrow and replaced it with [Bottom]: give it back (i.e., update
     the corresponding loan) *)
  | Ok (ctx, Some (_, bc)) ->
      (* Sanity check: the borrowed value shouldn't contain loans *)
      (match bc with
      | Concrete (VMutBorrow (_, bv)) ->
          [%sanity_check] span (Option.is_none (get_first_loan_in_value bv))
      | _ -> ());
      (* Give back the value *)
      let ctx = give_back_concrete span l bc ctx in
      (* Do a sanity check and continue *)
      check ctx;
      (* Save a snapshot of the environment for the name generation *)
      let cc =
        if snapshots then SynthesizeSymbolic.save_snapshot span ctx
        else fun e -> e
      in
      (* Compose *)
      (ctx, cc)

and end_borrows_aux (config : config) (span : Meta.span) ~(snapshots : bool)
    (chain : borrow_loan_abs_ids) (lset : UniqueBorrowIdSet.t) : cm_fun =
 fun ctx ->
  (* This is not necessary, but we prefer to reorder the borrow ids,
     so that we actually end from the smallest id to the highest id - just
     a matter of taste, and may make debugging easier *)
  let ids = UniqueBorrowIdSet.fold (fun id ids -> id :: ids) lset [] in
  fold_left_apply_continuation
    (fun id ctx -> end_borrow_aux config span ~snapshots chain id ctx)
    ids ctx

and try_end_loan_aux (config : config) (span : Meta.span) ~(snapshots : bool)
    (chain : borrow_loan_abs_ids) ~(must_end : bool) (l : loan_id) : cm_fun =
 fun ctx ->
  (* Lookup the loan to identify whether this is a shared loan or a mutable loan *)
  match ctx_lookup_loan_opt span ek_all l ctx with
  | None ->
      [%sanity_check] span (not must_end);
      (ctx, fun id -> id)
  | Some loan -> (
      match snd loan with
      | Concrete (VSharedLoan _) | Abstract (ASharedLoan _) ->
          end_shared_loan_aux config span ~snapshots chain l ctx
      | Concrete (VMutLoan _) | Abstract (AMutLoan _) ->
          let chain =
            add_borrow_loan_abs_id_to_chain span "end_loan_aux: " (LoanId l)
              chain
          in
          end_borrow_aux config span ~snapshots chain (UMut l) ctx
      | _ -> [%craise] span "Unreachable")

and end_loan_aux (config : config) (span : Meta.span) ~(snapshots : bool)
    (chain : borrow_loan_abs_ids) (l : loan_id) : cm_fun =
  try_end_loan_aux config span ~snapshots chain ~must_end:true l

and try_end_loans_aux (config : config) (span : Meta.span) ~(snapshots : bool)
    (chain : borrow_loan_abs_ids) ~(must_end : bool) (lset : BorrowId.Set.t) :
    cm_fun =
 fun ctx ->
  (* This is not necessary, but we prefer to reorder the borrow ids,
     so that we actually end from the smallest id to the highest id - just
     a matter of taste, and may make debugging easier *)
  let ids = BorrowId.Set.fold (fun id ids -> id :: ids) lset [] in
  fold_left_apply_continuation
    (fun id ctx ->
      try_end_loan_aux config span ~snapshots chain ~must_end id ctx)
    ids ctx

and end_loans_aux (config : config) (span : Meta.span) ~(snapshots : bool)
    (chain : borrow_loan_abs_ids) (lset : BorrowId.Set.t) : cm_fun =
  try_end_loans_aux config span ~snapshots chain ~must_end:true lset

and end_shared_loan_aux (config : config) (span : Meta.span) ~(snapshots : bool)
    (chain : borrow_loan_abs_ids) (l : loan_id) : cm_fun =
 fun ctx ->
  (* Repeateadly lookup and end the borrows corresponding to this loan *)
  let visitor =
    object
      inherit [_] iter_eval_ctx

      method! visit_VSharedBorrow _ bid sid =
        if bid = l then raise (FoundSharedBorrowId (bid, sid)) else ()

      method! visit_VReservedMutBorrow _ bid sid =
        (* We raise the same exception as for shared borrows: it doesn't matter *)
        if bid = l then raise (FoundSharedBorrowId (bid, sid)) else ()

      method! visit_ASharedBorrow _ pm bid sid =
        [%sanity_check] span (pm = PNone);
        if bid = l then raise (FoundSharedBorrowId (bid, sid)) else ()

      method! visit_AsbBorrow _ bid sid =
        if bid = l then raise (FoundSharedBorrowId (bid, sid)) else ()
    end
  in
  let rec run : cm_fun =
   fun ctx ->
    try
      visitor#visit_eval_ctx () ctx;
      (ctx, fun x -> x)
    with FoundSharedBorrowId (bid, sid) ->
      (* A borrower-free shared loan is a leaf, even when teardown reached it
         earlier through an abstraction. Check cycles only on live edges. *)
      let chain =
        add_borrow_loan_abs_id_to_chain span "end_shared_loan_aux: " (LoanId l)
          chain
      in
      (* Note that this includes the case of reserved borrows, that we treat
         like shared borrows *)
      let ctx, cc =
        end_borrow_aux config span ~snapshots chain (UShared (bid, sid)) ctx
      in
      comp cc (run ctx)
  in
  let ctx, cc = run ctx in

  (* There are no remaining borrows: end the loan itself *)
  (* We use a reference to check that we updated exactly one loan *)
  let replaced : bool ref = ref false in
  let released : tvalue option ref = ref None in
  let set_replaced () =
    [%cassert] span (not !replaced) "Exactly one loan should be updated";
    replaced := true
  in
  let obj =
    (* Note that abstraction expressions do not track shared loans/borrows,
       so we only need to look at "regular" abstraction values *)
    object
      inherit [_] map_eval_ctx as super

      method! visit_VLoan env lc =
        match lc with
        | VSharedLoan (l', shared_value) ->
            if l = l' then (
              (* This is the loan we are looking for *)
              set_replaced ();
              released := Some shared_value;
              (* Remove the loan by replacing it with the shared value *)
              shared_value.value)
            else
              (* Not the loan we are looking for: continue exploring *)
              VLoan (super#visit_VSharedLoan env l' shared_value)
        | VMutLoan bid' ->
            (* We are ending a *shared* loan: nothing special to do *)
            VLoan (super#visit_VMutLoan env bid')

      method! visit_ALoan opt_abs lc =
        match lc with
        | AMutLoan (pm, bid, av) ->
            [%sanity_check] span (pm = PNone);
            (* Nothing special to do (we are ending a *shared* loan) *)
            ALoan (super#visit_AMutLoan opt_abs pm bid av)
        | ASharedLoan (pm, l', shared_value, child) ->
            [%sanity_check] span (pm = PNone);
            if l = l' then (
              (* This is the loan we are looking for *)
              set_replaced ();
              released := Some shared_value;
              ALoan (AEndedSharedLoan (pm, shared_value, child)))
            else
              (* Not the loan we are looking for: continue exploring *)
              super#visit_ALoan opt_abs lc
        | AEndedMutLoan { given_back = _; child = _; given_back_meta = _ }
        (* Nothing special to do (the loan has ended) *)
        | AEndedSharedLoan (_, _, _)
        (* Nothing special to do (the loan has ended) *)
        | AIgnoredMutLoan (_, _, _)
        (* Nothing special to do (we are giving back a *shared* borrow) *)
        | AEndedIgnoredMutLoan { given_back = _; child = _; _ }
        (* Nothing special to do *)
        | AIgnoredSharedLoan _ ->
            (* Nothing special to do *)
            super#visit_ALoan opt_abs lc
    end
  in

  (* Explore the environment *)
  let ctx = obj#visit_eval_ctx None ctx in
  (* Ending an abstraction may already have released this now-unborrowed loan
     while ending a symbolic projector in its payload. It must be gone, not
     merely skipped. Multiple surviving loan tags still fail [set_replaced]. *)
  [%cassert] span
    (!replaced || Option.is_none (ctx_lookup_loan_opt span ek_all l ctx))
    "Shared loan was neither ended nor removed by ending its borrowers";
  (* The observations of frozen mutable borrows end with the loan *)
  let ctx =
    match !released with
    | None -> ctx
    | Some released -> end_released_frozen_observations span ctx released
  in
  (* Return *)
  (ctx, cc)

and end_abs_aux (config : config) (span : Meta.span) ~(snapshots : bool)
    (chain : borrow_loan_abs_ids) (abs_id : AbsId.id) (level : int) : cm_fun =
 fun ctx ->
  (* Check that we don't loop *)
  let chain =
    add_borrow_loan_abs_id_to_chain span "end_abs_aux: "
      (AbsId (abs_id, level))
      chain
  in
  (* Remember the original context for printing purposes *)
  let ctx0 = ctx in
  [%ltrace
    AbsId.to_string abs_id ^ "\n- original context:\n"
    ^ eval_ctx_to_string ~span:(Some span) ctx0];

  (* Lookup the abstraction - note that if we end a list of abstractions [A1, A0],
     ending the first abstraction A1 may require the last abstraction A0 to
     end first, so when reaching the end of the list, A0 might not be in the
     context anymore, meaning we have to simply ignore it. *)
  match ctx_lookup_abs_opt ctx abs_id with
  | None ->
      [%ltrace
        "abs not found (already ended): " ^ AbsId.to_string abs_id ^ "\n"];
      (ctx, fun e -> e)
  | Some abs ->
      (* Check that we can end the abstraction *)
      if abs.can_end then ()
      else
        [%craise] span
          ("Can't end abstraction " ^ AbsId.to_string abs.abs_id
         ^ " as it is set as non-endable");

      (* End the parent abstractions first - we end them completely (level 0) *)
      let ctx, cc =
        let parents =
          AbsIdWithLevelSet.of_list
            (List.map
               (fun abs_id -> { abs_id; level = 0 })
               (AbsId.Set.elements abs.parents))
        in
        end_abs_set_aux config span ~snapshots chain parents ctx
      in
      [%ltrace
        AbsId.to_string abs_id
        ^ "\n- context after parent abstractions ended:\n"
        ^ eval_ctx_to_string ~span:(Some span) ctx];

      (* End the strict sub-abstractions *)
      let ctx, cc =
        comp cc (end_all_sub_abs config span ~snapshots chain abs_id level ctx)
      in

      (* A shared-only abstraction has no mutable giveback. Retire its own
         read-only observations before its lenders: a lender may be stored in
         the very value those observations protect. Concrete retained payloads
         and other abstraction levels are independent ownership and stay live. *)
      let ctx =
        let abs =
          eliminate_internal_shared_borrows span ctx (ctx_lookup_abs ctx abs_id)
        in
        let abs =
          if
            List.for_all
              (fun (av : tavalue) ->
                not (ty_has_mut_borrows ctx.type_ctx.type_infos av.ty))
              abs.avalues
          then
            let visitor =
              object
                inherit [_] map_abs_with_levels as super
                method incr_level level = level + 1
                method! visit_tvalue _ value = value
                method! visit_tevalue _ value = value

                method! visit_ASharedBorrow current pm bid sid =
                  if current = level then (
                    [%sanity_check] span (pm = PNone);
                    AEndedSharedBorrow)
                  else super#visit_ASharedBorrow current pm bid sid

                method! visit_AProjSharedBorrow current pm borrows =
                  if current = level then (
                    [%sanity_check] span (pm = PNone);
                    AEndedSharedBorrow)
                  else super#visit_AProjSharedBorrow current pm borrows
              end
            in
            visitor#visit_abs 0 abs
          else abs
        in
        fst (ctx_subst_abs span ctx abs_id abs)
      in

      (* End the loans inside the abstraction *)
      let ctx, cc =
        comp cc (end_abs_loans config span ~snapshots chain abs_id level ctx)
      in
(*
```ocaml
*)
      diagnose_symbolic_runtime_type_transition span
        "end_abs_aux: entry through loans" ctx0 ctx;
(*
```
*)
      [%ltrace
        AbsId.to_string abs_id ^ "\n- context after loans ended:\n"
        ^ eval_ctx_to_string ~span:(Some span) ctx];

      (* End the abstraction itself by redistributing the borrows it contains *)
(*
```ocaml
*)
      let ctx_before_borrows = ctx in
(*
```
*)
      let ctx, cc =
        comp cc (end_abs_borrows config span ~snapshots chain abs_id level ctx)
      in
(*
```ocaml
*)
      diagnose_symbolic_runtime_type_transition span
        "end_abs_aux: borrows" ctx_before_borrows ctx;
(*
```
*)

      (* End the regions owned by the abstraction - note that we don't need to
         relookup the abstraction: the set of regions in an abstraction never
         changes... *)
      let ctx =
        let ended_regions =
          RegionId.Set.union ctx.ended_regions abs.regions.owned
        in
        { ctx with ended_regions }
      in

      (* Synthesize the symbolic expression to save the fact that we ended a (sub-)
         abstraction.

         If the sub-abstraction is at level 0, we remove the abstraction from the
         context all-together. *)
(*
```ocaml
*)
      let ctx_before_synthesis = ctx in
(*
```
*)
      let ctx, cc = comp cc (end_abs_synthesize config span abs_id level ctx) in

(*
```ocaml
*)
      diagnose_symbolic_runtime_type_transition span
        "end_abs_aux: synthesis" ctx_before_synthesis ctx;
(*
```
*)
      (* Debugging *)
      [%ltrace
        AbsId.to_string abs_id ^ "\n- original context:\n"
        ^ eval_ctx_to_string ~span:(Some span) ctx0
        ^ "\n\n- new context:\n"
        ^ eval_ctx_to_string ~span:(Some span) ctx];

      (* Sanity check: ending an abstraction must preserve the invariants *)
      Invariants.check_invariants span ctx;

      (* Save a snapshot of the environment for the name generation *)
      let cc =
        if snapshots then cc_comp cc (SynthesizeSymbolic.save_snapshot span ctx)
        else cc
      in

      (* Return *)
      (ctx, cc)

and end_abs_set_aux (config : config) (span : Meta.span) ~(snapshots : bool)
    (chain : borrow_loan_abs_ids) (subabs : AbsIdWithLevelSet.t) : cm_fun =
 fun ctx ->
  (* This is not necessary, but we prefer to reorder the abstraction ids,
   * so that we actually end from the smallest id to the highest id - just
   * a matter of taste, and may make debugging easier *)
  let subabs = AbsIdWithLevelSet.elements subabs in
  fold_left_apply_continuation
    (fun ({ abs_id; level } : abs_id_with_level) ctx ->
      end_abs_aux config span ~snapshots chain abs_id level ctx)
    subabs ctx

(** End all the sub-abstractions of level strictly higher than [level].

    We need to do this before ending the abstraction at level [level].

    With several levels of sub-abstractions (three or more levels of nested
    borrows), a sub-abstraction may give back values which depend on the values
    consumed by a lower sub-abstraction: for instance, the loans of level 1 of
    a function-call abstraction consume the inputs of the backward function,
    while its borrows of level 2 give back some of its outputs. We thus first
    end the loans of every sub-level (deepest first), then end the
    sub-abstractions themselves, deepest first. With a single level of
    sub-abstractions, both orders coincide. *)
and end_all_sub_abs (config : config) (span : Meta.span) ~(snapshots : bool)
    (chain : borrow_loan_abs_ids) (abs_id : AbsId.id) (level : int) : cm_fun =
 fun ctx ->
  [%ltrace
    "- abs_id: " ^ AbsId.to_string abs_id ^ "\n- ctx:\n"
    ^ eval_ctx_to_string ctx];
  (* Lookup the abstraction *)
  let abs = ctx_lookup_abs ctx abs_id in
  let max_level = get_max_sub_abs abs in
  let ctx, cc =
    if max_level > level + 1 then
      let rec end_loans (sub_level : int) ctx =
        if sub_level <= level then (ctx, fun e -> e)
        else
          let ctx, cc =
            end_abs_loans config span ~snapshots chain abs_id sub_level ctx
          in
          comp cc (end_loans (sub_level - 1) ctx)
      in
      let ctx, cc = end_loans max_level ctx in
      (* Some levels may now only contain ended values: end them explicitly (the
         translation needs to know when the values of a level are available),
         deepest first. *)
      let rec end_levels (sub_level : int) ctx =
        if sub_level <= level then (ctx, fun e -> e)
        else
          let abs = ctx_lookup_abs ctx abs_id in
          let ctx, cc =
            if AbsLevelSet.mem sub_level abs.ended_subabs then
              (ctx, fun e -> e)
            else end_abs_aux config span ~snapshots chain abs_id sub_level ctx
          in
          comp cc (end_levels (sub_level - 1) ctx)
      in
      comp cc (end_levels max_level ctx)
    else (ctx, fun e -> e)
  in
  comp cc
    (end_sub_abs_deepest_first config span ~snapshots chain abs_id level ctx)

and end_sub_abs_deepest_first (config : config) (span : Meta.span)
    ~(snapshots : bool) (chain : borrow_loan_abs_ids) (abs_id : AbsId.id)
    (level : int) : cm_fun =
 fun ctx ->
  (* Lookup the abstraction *)
  let abs = ctx_lookup_abs ctx abs_id in
  (* Check whether we need to end sub-abstractions *)
  let max_level = get_max_sub_abs abs in
  if max_level > level then
    (* Ending the deepest sub-abstraction does not end its siblings at lower
       levels. Recompute the frontier after each giveback: those intermediate
       levels can still lend values to other abstractions. *)
    let ctx, cc =
      end_abs_aux config span ~snapshots chain abs_id max_level ctx
    in
    comp cc
      (end_sub_abs_deepest_first config span ~snapshots chain abs_id level ctx)
  else
    (* No strict sub-abstraction to end. *)
    (ctx, fun e -> e)

(** This function assumes there remains no sub-abstractions *)
and end_abs_loans (config : config) (span : Meta.span) ~(snapshots : bool)
    (chain : borrow_loan_abs_ids) (abs_id : AbsId.id) (level : int) : cm_fun =
 fun ctx ->
  [%ltrace
    "- abs_id: " ^ AbsId.to_string abs_id ^ "\n- ctx:\n"
    ^ eval_ctx_to_string ctx];
  (* Lookup the abstraction *)
  let abs = ctx_lookup_abs ctx abs_id in

  (* End the first loan we find.

     We ignore the "ignored mut/shared loans": as we should have already ended
     the parent abstractions, they necessarily come from children. *)
  let opt_loan = get_first_non_ignored_aloan_in_abs span abs level level in
  match opt_loan with
  | None ->
      (* No loans: nothing to update *)
      (ctx, fun e -> e)
  | Some (BorrowId bid, _) ->
      (* There are loans: end them, then recheck *)
      let ctx, cc = end_loan_aux config span ~snapshots chain bid ctx in
      (* Reexplore, looking for loans *)
      comp cc (end_abs_loans config span ~snapshots chain abs_id level ctx)
  | Some (SymbolicValue proj, projected_regions) ->
      (* There is a proj_loans over a symbolic value: end the proj_borrows
         which intersect this proj_loans, then end the proj_loans itself *)
      let ctx, cc =
        end_proj_loans_symbolic config span ~snapshots chain abs_id level
          projected_regions proj ctx
      in
      (* Reexplore, looking for loans *)
      comp cc (end_abs_loans config span ~snapshots chain abs_id level ctx)

(** This function assumes there remains no sub-abstractions *)
and end_abs_borrows (config : config) (span : Meta.span) ~(snapshots : bool)
    (chain : borrow_loan_abs_ids) (abs_id : AbsId.id) (level : int) : cm_fun =
 fun ctx ->
  [%ltrace
    "abs_id: " ^ AbsId.to_string abs_id ^ ", level: " ^ string_of_int level];
  (* Note that the abstraction mustn't contain any loans *)
  (* We end the borrows, starting with the *inner* ones. This is important
     when considering nested borrows which have the same lifetime.
     TODO: is that really important? Initially, there was a concern about
     whether we should give back ⊥ or not, but everything is handled by
     the symbolic value expansion... Also, now we use the AEndedMutBorrow
     values to store the children avalues (which was not the case before - we
     initially replaced the ended mut borrows with ⊥).
  *)
  (* We explore in-depth and use exceptions. When exploring a borrow, if
     the exploration didn't trigger an exception, it means there are no
     inner borrows to end: we can thus trigger an exception for the current
     borrow.

     TODO: we should implement a function in InterpBorrowsCore to do
     exactly that.
  *)
  let check_level level' = level' = level in
  let projector_regions = ref (ctx_lookup_abs ctx abs_id).regions.owned in
  let visitor =
    object (self)
      inherit [_] iter_abs_with_levels as super
      method incr_level level = level + 1
(*
```ocaml
*)
      method! visit_ATransportedProj state transport child =
        let previous = !projector_regions in
        projector_regions := transport.current_regions;
        self#visit_aproj state child;
        projector_regions := previous

      method! visit_ATransportedValue state transport child =
        let previous = !projector_regions in
        projector_regions := transport.current_regions;
        self#visit_tavalue state child;
        projector_regions := previous
(*
```
*)

      method! visit_AEndedSharedLoan level _pm _sv child =
        (* Ending the outer shared lifetime releases its payload; it does not
           end the independent borrows stored in that payload. The payload is
           transferred out of this abstraction by [end_abs_synthesize]. *)
        super#visit_tavalue level child

      method! visit_aborrow_content level bc =
        (* In-depth exploration *)
        super#visit_aborrow_content level bc;
        (* No exception was raised: we can raise an exception for the
         * current borrow *)
        match bc with
        | AMutBorrow _ | ASharedBorrow _ ->
            (* Raise an exception *)
            if check_level level then raise (FoundABorrowContent bc)
        | AProjSharedBorrow (pm, asb) ->
            [%sanity_check] span (pm = PNone);
            (* Both concrete and symbolic reborrows keep their owner live. *)
            if check_level level && asb <> [] then
              raise (FoundABorrowContent bc)
        | AEndedMutBorrow _
        | AIgnoredMutBorrow _
        | AEndedIgnoredMutBorrow _
        | AEndedSharedBorrow ->
            (* Nothing to do for ignored borrows *)
            ()

      method! visit_aproj env sproj =
        (match sproj with
        | AProjBorrows aproj ->
            if check_level env then raise (FoundAProjBorrows aproj)
        | APendingLoans _
        | APendingSymbolicLoans _
        | AProjLoans _
        | AEndedProjLoans _
        | AEndedProjBorrows _
(*
```ocaml
*)
        | ATransportedProj _ | AEmpty -> ());
(*
```
*)
        super#visit_aproj env sproj

      (** We may need to end borrows in "regular" values, because of shared
          values *)
      method! visit_borrow_content level bc =
        match bc with
        | VSharedBorrow _ | VMutBorrow (_, _) ->
            if check_level level then raise (FoundBorrowContent bc)
        | VReservedMutBorrow _ -> [%craise] span "Unreachable"
    end
  in
  (* Lookup the abstraction *)
  let abs = ctx_lookup_abs ctx abs_id in
  try
    (* Explore the abstraction, looking for borrows *)
    visitor#visit_abs 0 abs;
    (* No borrows: nothing to update *)
    (* Last sanity check: the region abstraction doesn't contain borrows in its *expression* *)
    [%sanity_check] span (not (abs_has_non_ended_eborrows ctx abs level));
    (ctx, fun e -> e)
  with
  (* There are concrete (i.e., not symbolic) borrows: end them, then re-explore *)
  | FoundABorrowContent bc ->
      [%ltrace
        "found aborrow content: "
        ^ aborrow_content_to_string ~span:(Some span) ctx bc];
      let ctx =
        match bc with
        | AMutBorrow (pm, bid, av) ->
            [%sanity_check] span (pm = PNone);
            (* First, convert the avalue to a (fresh symbolic) value *)
            let sv = convert_avalue_to_given_back_value span ctx av in
            let () =
              let log = Logging.carrier_events_log in
              [%ldebug
                "Carrier producer event:\nkind: abstract mutable borrow\nowner: "
                ^ AbsId.to_string abs_id ^ "\nowner kind: " ^ show_abs_kind abs.kind
                ^ "\nlevel: " ^ string_of_int level
                ^ "\nowned mask: " ^ RegionId.Set.to_string None !projector_regions
                ^ "\nborrow: " ^ BorrowId.to_string bid
                ^ "\ncurrent return: " ^ show_symbolic_value sv
                ^ "\nsource payload type: " ^ Types.show_ty av.ty]
            in
            (* Replace the mut borrow to register the fact that we ended
               it and store with it the freshly generated given back value *)
            let meta : aended_mut_borrow_meta = { bid; given_back = sv } in
            let ended_borrow = ABorrow (AEndedMutBorrow (meta, av)) in
            let ended_eborrow =
              match lookup_eborrow_opt span ek_all bid ctx with
              | None -> None
              | Some (EMutBorrow (pm, bid, av)) ->
                  [%sanity_check] span (pm = PNone);
                  let meta : eended_mut_borrow_meta =
                    { bid; given_back = sv }
                  in
                  Some (EBorrow (EEndedMutBorrow (meta, av)))
              | Some _ -> [%internal_error] span
            in
            let ctx =
              update_aborrow span ek_all (UMut bid) ended_borrow ended_eborrow
                ctx
            in
            (* Give the value back *)
            let supplier = AbstractionInputReturn
              (abs_id, level, sv, !projector_regions,
               Option.map (fun value -> ({ value; ty = sv.sv_ty } : tevalue))
                 ended_eborrow) in
            let sv = mk_tvalue_from_symbolic_value ctx.type_ctx.type_infos ctx.metadata_bindings sv in
            give_back_value span bid sv supplier ctx
        | ASharedBorrow (pm, bid, sid) ->
            [%sanity_check] span (pm = PNone);
            (* Replace the shared borrow to account for the fact it ended *)
            let ended_borrow = ABorrow AEndedSharedBorrow in
            update_aborrow span ek_all
              (UShared (bid, sid))
              ended_borrow None ctx
        | AProjSharedBorrow (pm, asb) ->
            [%sanity_check] span (pm = PNone);
            (* Shared projections give no mutable value back. End exactly this
               sub-abstraction's shared reborrows, including symbolic-only
               projections; other levels and abstractions remain untouched. *)
            [%sanity_check] span (asb <> []);
            let visitor =
              object
                inherit [_] map_abs_with_levels as super
                method incr_level level = level + 1

                method! visit_AProjSharedBorrow current_level pm asb =
                  if current_level = level then (
                    [%sanity_check] span (pm = PNone);
                    AEndedSharedBorrow)
                  else super#visit_AProjSharedBorrow current_level pm asb
              end
            in
            let abs = visitor#visit_abs 0 abs in
            fst (ctx_subst_abs span ctx abs_id abs)
        | AEndedMutBorrow _
        | AIgnoredMutBorrow _
        | AEndedIgnoredMutBorrow _
        | AEndedSharedBorrow -> [%craise] span "Unexpected"
      in
      (* Reexplore *)
      end_abs_borrows config span ~snapshots chain abs_id level ctx
  (* There are symbolic borrows: end them, then re-explore *)
  | FoundAProjBorrows aproj ->
      [%ltrace
        "found aproj borrows: " ^ aproj_to_string ctx (AProjBorrows aproj)];
      (* Generate a fresh symbolic value *)
      let nsv = mk_fresh_symbolic_value span ctx aproj.proj.proj_ty in
      let () =
        let log = Logging.carrier_events_log in
        [%ldebug
          "Carrier producer event:\nkind: symbolic borrow projector\nowner: "
          ^ AbsId.to_string abs_id ^ "\nowner kind: " ^ show_abs_kind abs.kind
          ^ "\nlevel: " ^ string_of_int level
          ^ "\nowned mask: " ^ RegionId.Set.to_string None !projector_regions
          ^ "\nprojector: " ^ show_symbolic_proj aproj.proj
          ^ "\ncurrent return: " ^ show_symbolic_value nsv]
      in
      (* Replace the proj_borrows - there should be exactly one *)
(*
```ocaml
*)
      let ctx_before_projectors = ctx in
(*
```
*)
      let ctx, supplier =
        end_aproj_borrows span !projector_regions aproj.proj nsv abs_id level ctx in
(*
```ocaml
*)
      diagnose_symbolic_runtime_type_transition span
        "end_abs_borrows: borrow projector update" ctx_before_projectors ctx;
(*
```
*)
      (* Give back the symbolic value *)
      let ctx =
        give_back_symbolic_value config span !projector_regions aproj.proj nsv
          supplier ctx
      in
      (* Reexplore *)
      end_abs_borrows config span ~snapshots chain abs_id level ctx
  (* There are concrete (i.e., not symbolic) borrows in shared values: end them, then reexplore *)
  | FoundBorrowContent bc ->
      [%ltrace
        "found borrow content: "
        ^ borrow_content_to_string ~span:(Some span) ctx bc];
      let ctx =
        match bc with
        | VSharedBorrow (bid, sid) -> (
            (* Replace the shared borrow with bottom *)
            match
              end_concrete_borrow_in_abs_get_borrow span abs_id
                (UShared (bid, sid))
                ctx
            with
            | Error _ -> [%craise] span "Unreachable"
            | Ok (ctx, _) -> ctx)
        | VMutBorrow (bid, v) -> (
            (* Replace the mut borrow with bottom *)
            match
              end_concrete_borrow_in_abs_get_borrow span abs_id (UMut bid) ctx
            with
            | Error _ -> [%craise] span "Unreachable"
            | Ok (ctx, _) ->
                (* Give the value back - note that the mut borrow was below a
                 * shared borrow: the value is thus unchanged *)
                give_back_value span bid v
                  (ConcreteInputReturn (bid, mk_evalue ctx.env v.ty v)) ctx)
        | VReservedMutBorrow _ -> [%craise] span "Unreachable"
      in
      (* Reexplore *)
      end_abs_borrows config span ~snapshots chain abs_id level ctx

(** Remove an abstraction from the context, as well as all its references *)
and end_abs_synthesize (_config : config) (span : Meta.span) (abs_id : AbsId.id)
    (level : int) : cm_fun =
 fun ctx ->
  let abs =
    [%unwrap_with_span] span
      (ctx_lookup_abs_opt ctx abs_id)
      "Internal error: please file an issue"
  in
  [%sanity_check] span (not (AbsLevelSet.mem level abs.ended_subabs));
  let abs =
    { abs with ended_subabs = AbsLevelSet.add level abs.ended_subabs }
  in

  (* An ended shared loan no longer protects its concrete payload. Move that
     payload, rather than ending its inner owners or dropping its borrowers.
     Keep the original abstraction for synthesis: it is a historical snapshot,
     whereas only [resident_abs] remains operational in the context. *)
  let released = ref [] in
  let visitor =
    object
      inherit [_] map_abs_with_levels as super
      method incr_level level = level + 1

      method! visit_AEndedSharedLoan current_level pm sv child =
        let child = super#visit_tavalue current_level child in
        let sv =
          if
            current_level = level
            && tvalue_has_loans_or_borrows (Some span) ctx sv
          then (
            released := sv :: !released;
            { sv with value = VBottom })
          else sv
        in
        AEndedSharedLoan (pm, sv, child)
    end
  in
  let resident_abs = visitor#visit_abs 0 abs in
  let ctx =
    if level = 0 then fst (ctx_remove_abs span ctx abs_id)
    else fst (ctx_subst_abs span ctx abs_id resident_abs)
  in
  let ctx = ctx_push_fresh_dummy_vars ctx (List.rev !released) in
  (* Synthesize with the original payload and giveback continuation. *)
  (ctx, SynthesizeSymbolic.synthesize_end_abs ctx abs level)

(** End a proj_loan over a symbolic value by ending the proj_borrows which
    intersect this proj_loan.

    Remark: if this symbolic value is primitively copiable, then:
    - either proj_borrows are only present in the concrete context
    - or there is only one intersecting proj_borrow present in an abstraction
    - otherwise, this symbolic value is not primitively copiable:
    - there may be proj_borrows_shared over this value
    - if we put aside the proj_borrows_shared, there should be exactly one
      intersecting proj_borrows, either in the concrete context or in an
      abstraction

    Note that we may get recursively get here after a sequence of updates which
    look like this:
    - attempt ending a loan projector
    - end a borrow projector before, and by doing this actually end the loan
      projector
    - retry ending the loan projector

    We thus have to be careful about the fact that maybe the loan projector
    actually doesn't exist anymore when we get here. *)
and end_proj_loans_symbolic (config : config) (span : Meta.span)
    ~(snapshots : bool) (chain : borrow_loan_abs_ids) (abs_id : AbsId.id)
    (level : abs_level) (regions : RegionId.Set.t) (proj : symbolic_proj) :
    cm_fun =
 fun ctx ->
  [%ltrace
    "- abs_id: " ^ AbsId.to_string abs_id ^ "\n- regions: "
    ^ RegionId.Set.to_string None regions
    ^ "\n- sv: "
    ^ symbolic_value_id_to_pretty_string proj.sv_id
    ^ "\n- projection type: "
    ^ ty_to_string ctx proj.proj_ty
    ^ "\n- ctx:\n" ^ eval_ctx_to_string ctx];
  (* Find the first proj_borrows which intersects the proj_loans *)
  let explore_shared = true in
  match
    lookup_intersecting_aproj_borrows_opt span explore_shared regions proj ctx
  with
  | None -> (
      (* We couldn't find any in the context: it means that the symbolic value
         is in the concrete environment (or that we dropped it, in which case
         it is completely absent).

         We need to check whether the value appears inside a borrow, in which
         case we need to end it first.
      *)
      match end_proj_loan_get_concrete_priority span proj.sv_id ctx with
      | None ->
          (* No outer borrows/loans found: we can end the loan projector *)
          let ctx = update_aproj_loans_to_ended span abs_id level proj ctx in
          (* Continue *)
          (ctx, fun e -> e)
      | Some outer ->
          (* End the outer borrow/loan first *)
          let ctx, cc =
            let bid =
              match outer with
              | SharedLoan l -> l
              | MutBorrow l -> l
            in
            end_loan_aux config span ~snapshots chain bid ctx
          in
          (* Retry ending the loan projector *)
          comp cc
            (end_proj_loans_symbolic config span ~snapshots chain abs_id level
               regions proj ctx))
  | Some (SharedProjs projs) ->
      (* We found projectors over shared values: end the abstractions containing
         them at the proper level.  *)
      let ctx, cc =
        let abs_ids =
          List.map (fun (abs_id, _, level) -> { abs_id; level }) projs
        in
        let abs_ids = AbsIdWithLevelSet.of_list abs_ids in
        (* End the abstractions and continue *)
        end_abs_set_aux config span ~snapshots chain abs_ids ctx
      in
      (* End the loan itself *)
      let ctx = update_aproj_loans_to_ended span abs_id level proj ctx in
      (ctx, cc)
  | Some (NonSharedProj (abs_id', proj_ty', level'))
    when abs_id' = abs_id && level' < level ->
      (* The intersecting borrow projector lies in the abstraction whose
         sub-abstraction we are ending, at another level: the borrows of the
         symbolic value flow from one level of the abstraction to another one
         (this happens with nested borrows, when a value given back by an
         ignored borrow of the abstraction is itself given back to an ignored
         loan of the same abstraction). Ending the whole level of the borrow
         projector would require ending the current level first (the
         sub-abstractions of higher levels must end before the lower ones):
         we end exactly this projector instead, as [end_abs_borrows] does.
         The other values of that level are left untouched. *)
      let bproj : symbolic_proj = { sv_id = proj.sv_id; proj_ty = proj_ty' } in
      let nsv = mk_fresh_symbolic_value span ctx proj_ty' in
      let ctx, supplier =
        end_aproj_borrows span regions bproj nsv abs_id' level' ctx in
      let ctx = give_back_symbolic_value config span regions bproj nsv supplier ctx in
      (* Retry ending the projector of loans *)
      end_proj_loans_symbolic config span ~snapshots chain abs_id level regions
        proj ctx
  | Some (NonSharedProj (abs_id', _proj_ty, level')) ->
      (* We found one projector of borrows in an abstraction: end the abstraction
         at the corresponding level. *)
      let ctx, cc =
        end_abs_aux config span ~snapshots chain abs_id' level' ctx
      in
      (* Retry ending the projector of loans *)
      let ctx, cc =
        comp cc
          (end_proj_loans_symbolic config span ~snapshots chain abs_id level
             regions proj ctx)
      in
      (* Return *)
      (ctx, cc)

let end_borrow config (span : Meta.span) ?(snapshots : bool = true) :
    unique_borrow_id -> cm_fun =
  end_borrow_aux config ~snapshots span []

let end_borrows config (span : Meta.span) ?(snapshots : bool = true) :
    unique_borrow_id_set -> cm_fun =
  end_borrows_aux config ~snapshots span []

let end_loan config (span : Meta.span) ?(snapshots : bool = true) :
    loan_id -> cm_fun =
  end_loan_aux config ~snapshots span []

let end_loans config (span : Meta.span) ?(snapshots : bool = true) :
    loan_id_set -> cm_fun =
  end_loans_aux config ~snapshots span []

let try_end_loans config (span : Meta.span) ?(snapshots : bool = true) :
    loan_id_set -> cm_fun =
  try_end_loans_aux config ~snapshots span [] ~must_end:false

let end_abs config span ?(snapshots = true) =
  end_abs_aux config ~snapshots span []

let end_abs_set config span ?(snapshots = true) =
  end_abs_set_aux config ~snapshots span []

let end_borrow_no_synth config span ?(snapshots = true) id ctx =
  fst (end_borrow config span ~snapshots id ctx)

let end_borrows_no_synth config span ?(snapshots = true) ids ctx =
  fst (end_borrows config span ~snapshots ids ctx)

let end_loan_no_synth config span ?(snapshots = true) id ctx =
  fst (end_loan config span ~snapshots id ctx)

let end_loans_no_synth config span ?(snapshots = true) ids ctx =
  fst (end_loans config span ~snapshots ids ctx)

let try_end_loans_no_synth config span ?(snapshots = true) ids ctx =
  fst (try_end_loans config span ~snapshots ids ctx)

let end_abs_no_synth config span ?(snapshots = true) id level ctx =
  fst (end_abs config ~snapshots span id level ctx)

let end_abs_set_no_synth config span ?(snapshots = true) ids ctx =
  fst (end_abs_set config ~snapshots span ids ctx)

(** Helper function: see {!activate_reserved_mut_borrow}.

    This function updates the shared loan to a mutable loan (we then update the
    borrow with another helper). Of course, the shared loan must contain exactly
    one borrow id (the one we give as parameter), otherwise we can't promote it.
    Also, the shared value mustn't contain any loan.

    The returned value (previously shared) is checked:
    - it mustn't contain loans
    - it mustn't contain {!Bottom}
    - it mustn't contain reserved borrows TODO: this kind of checks should be
      put in an auxiliary helper, because they are redundant.

    The loan to update mustn't be a borrowed value. *)
let promote_shared_loan_to_mut_loan (span : Meta.span) (l : BorrowId.id)
    (bid : SharedBorrowId.id) (ctx : eval_ctx) : tvalue * eval_ctx =
  (* Debug *)
  [%ltrace
    "- loan: " ^ BorrowId.to_string l ^ "\n- context:\n"
    ^ eval_ctx_to_string ~span:(Some span) ctx];
  (* Sanity check: there is exactly one borrow mapping to [bid] in the context,
     and it is the one we want to promote.
   *)
  let borrows = lookup_shared_reserved_borrows l ctx in
  [%sanity_check] span (borrows = [ bid ]);
  (* Lookup the shared loan - note that we can't promote a shared loan
     in a shared value, but we can do it in a mutably borrowed value.
     This is important because we can do: [let y = &two-phase ( *x );]
   *)
  let ek =
    { enter_shared_loans = false; enter_mut_borrows = true; enter_abs = false }
  in
  match ctx_lookup_loan span ek l ctx with
  | _, Concrete (VMutLoan _) ->
      [%craise] span "Expected a shared loan, found a mut loan"
  | _, Concrete (VSharedLoan (_, sv)) ->
      (* We need to check that there aren't any loans in the value:
         we should have gotten rid of those already, but it is better
         to do a sanity check. *)
      [%sanity_check] span (not (concrete_loans_in_value sv));
      (* Check there isn't {!Bottom} (this is actually an invariant *)
      [%cassert] span
        (not (bottom_in_value ctx.type_ctx.type_infos ctx.ended_regions sv))
        "There shouldn't be a bottom";
      (* Check there aren't reserved borrows *)
      [%cassert] span
        (not (reserved_in_value sv))
        "There shouldn't be reserved borrows";
      (* Update the loan content *)
      let ctx = update_loan span ek l (VMutLoan l) ctx in
      (* Return *)
      (sv, ctx)
  | _, Abstract _ ->
      (* I don't think it is possible to have two-phase borrows involving borrows
         returned by abstractions. I'm not sure how we could handle that anyway. *)
      [%craise] span
        "Can't promote a shared loan to a mutable loan if the loan is inside a \
         region abstraction"

(** Helper function: see {!activate_reserved_mut_borrow}.

    This function updates a shared borrow to a mutable borrow (and that is all:
    it doesn't touch the corresponding loan). *)
let replace_reserved_borrow_with_mut_borrow (span : Meta.span) (l : BorrowId.id)
    (bid : SharedBorrowId.id) (borrowed_value : tvalue) (ctx : eval_ctx) :
    eval_ctx =
  (* Lookup the reserved borrow - note that we don't go inside borrows/loans:
     there can't be reserved borrows inside other borrows/loans
  *)
  let ek =
    { enter_shared_loans = false; enter_mut_borrows = false; enter_abs = false }
  in
  match lookup_borrow span ek (UShared (l, bid)) ctx with
  | Concrete (VSharedBorrow _ | VMutBorrow (_, _)) ->
      [%craise] span "Expected a reserved mutable borrow"
  | Concrete (VReservedMutBorrow _) ->
      (* Update it *)
      update_borrow span ek
        (UShared (l, bid))
        (VMutBorrow (l, borrowed_value))
        ctx
  | Abstract _ ->
      (* This can't happen for sure *)
      [%craise] span
        "Can't promote a shared borrow to a mutable borrow if the borrow is \
         inside a region abstraction"

(** Helper: check if a loan_id appears anywhere inside a value (traverses all
    nested structures including shared loans). *)
let loan_id_in_value (target : BorrowId.id) (v : tvalue) : bool =
  try
    (object
       inherit [_] iter_tvalue as super

       method! visit_loan_content env lc =
         (match lc with
         | VSharedLoan (lid, _) when lid = target -> raise Found
         | VMutLoan lid when lid = target -> raise Found
         | _ -> ());
         super#visit_loan_content env lc
    end)
      #visit_tvalue
      () v;
    false
  with Found -> true

(** Find the outermost shared loan in the environment that contains the given
    loan id in its value. This is used when {!promote_reserved_mut_borrow} can't
    find a loan because it's nested inside an outer shared loan (which can
    happen when a two-phase borrow is created on a struct field, and then shared
    borrows are taken on the whole struct for argument evaluation).

    Traverses the environment entering mut borrows but NOT entering shared loans
    (same exploration as the narrow [ek] in {!promote_reserved_mut_borrow}).
    When a shared loan is encountered, checks if its value contains the target
    loan. Returns the id of the first such outer shared loan. *)
let find_outer_shared_loan_containing_loan (span : Meta.span) (l : BorrowId.id)
    (ctx : eval_ctx) : loan_id =
  try
    (object
       inherit [_] iter_eval_ctx as super

       method! visit_borrow_content env bc =
         match bc with
         | VMutBorrow (_, mv) -> super#visit_tvalue env mv
         | VSharedBorrow _ | VReservedMutBorrow _ -> ()

       method! visit_loan_content _env lc =
         match lc with
         | VSharedLoan (lid, sv) ->
             (* Don't enter this shared loan for the outer traversal,
                but check if the target loan is somewhere inside *)
             if loan_id_in_value l sv then raise (FoundLoanId lid)
         | VMutLoan _ -> ()

       method! visit_EAbs _ _ =
         (* We shouldn't be able to create reserved borrows pointing inside
            region abstractions *)
         ()
    end)
      #visit_env
      () ctx.env;
    [%craise] span
      ("Could not find an outer shared loan containing loan "
     ^ BorrowId.to_string l)
  with FoundLoanId lid -> lid

(** A call which takes a shared borrow of a value owning mutable borrows (a
    symbolic value of a model type such as BTreeMap's [OccupiedEntry<'a, ..>])
    leaves, for the regions of those borrows, an abstraction which observes
    them through a shared reborrow projector ([AsbProjReborrows]). Through a
    shared borrow of the value, those borrows can only be reborrowed for the
    lifetime of that outer borrow: moving the value or borrowing it mutably
    ends the observations. This ends the abstractions observing mutable borrows
    of a symbolic value of [v], and returns [None] if there are none.
    Observations of shared borrows only stay: copies of those borrows may
    outlive the outer borrow (see [Invariants.check_symbolic_values]). *)
let end_mut_borrow_observations_in_value_opt (config : config)
    (span : Meta.span) (v : tvalue) (ctx : eval_ctx) :
    (eval_ctx * (SymbolicAst.expr -> SymbolicAst.expr)) option =
  let svs = ref SymbolicValueId.Set.empty in
  (object
     inherit [_] iter_tvalue

     method! visit_VSymbolic _ sv =
       svs := SymbolicValueId.Set.add sv.sv_id !svs
  end)
    #visit_tvalue
    () v;
  if SymbolicValueId.Set.is_empty !svs then None
  else
    let observers = ref AbsIdWithLevelSet.empty in
    (object
       inherit [_] iter_eval_ctx_with_abs_levels as super

       method incr_level al =
         match al with
         | Some (abs, level) -> Some (abs, level + 1)
         | None -> [%internal_error] span

       method! visit_abs _ abs = super#visit_abs (Some (abs, 0)) abs

       method! visit_abstract_shared_borrow al asb =
         match asb with
         | AsbBorrow _ -> ()
         | AsbProjReborrows proj ->
             let abs, level = Option.get al in
             if
               SymbolicValueId.Set.mem proj.sv_id !svs
               && ty_has_mut_borrow_for_region_in_set ctx.type_ctx.type_infos
                    abs.regions.owned proj.proj_ty
             then
               observers :=
                 AbsIdWithLevelSet.add { abs_id = abs.abs_id; level }
                   !observers
    end)
      #visit_eval_ctx
      None ctx;
    if AbsIdWithLevelSet.is_empty !observers then None
    else (
      [%ltrace
        "ending the observations of mutable borrows in "
        ^ tvalue_to_string ~span:(Some span) ctx v];
      Some (end_abs_set config span !observers ctx))

(** Promote a reserved mut borrow to a mut borrow. *)
let rec promote_reserved_mut_borrow (config : config) (span : Meta.span)
    (l : BorrowId.id) (rid : SharedBorrowId.id) : cm_fun =
 fun ctx ->
  (* Lookup the value *)
  let ek =
    { enter_shared_loans = false; enter_mut_borrows = true; enter_abs = false }
  in
  match ctx_lookup_loan_opt span ek l ctx with
  | None ->
      (* The loan was not found with the narrow exploration kind. This can
         happen if the loan is inside an outer shared loan that we can't enter.
         For instance, when a two-phase borrow is taken on a struct field and
         then shared borrows are taken on the whole struct (e.g., for argument
         evaluation), the target loan ends up nested inside the outer shared
         loan.

         Strategy: find and end the outer shared loan, then retry. *)
      [%ltrace
        "promote_reserved_mut_borrow: loan " ^ BorrowId.to_string l
        ^ " not found (likely behind a shared loan), looking for outer shared \
           loan"];
      let outer_lid = find_outer_shared_loan_containing_loan span l ctx in
      [%ltrace
        "promote_reserved_mut_borrow: ending outer shared loan "
        ^ BorrowId.to_string outer_lid];
      let ctx, cc = end_loan config span outer_lid ctx in
      comp cc (promote_reserved_mut_borrow config span l rid ctx)
  | Some (_, Concrete (VMutLoan _)) -> [%craise] span "Unreachable"
  | Some (_, Concrete (VSharedLoan (_, sv))) -> (
      (* If there are loans inside the value, end them. Note that there can't be
         reserved borrows inside the value.
         If we perform an update, do a recursive call to lookup the updated value *)
      match get_first_loan_in_value sv with
      | Some lc ->
          (* End the loans *)
          let ctx, cc =
            match lc with
            | VSharedLoan (bid', _) | VMutLoan bid' ->
                end_loan config span bid' ctx
          in
          (* Recursive call *)
          comp cc (promote_reserved_mut_borrow config span l rid ctx)
      | None -> (
          (* End the observations of the mutable borrows of the value *)
          match end_mut_borrow_observations_in_value_opt config span sv ctx with
          | Some (ctx, cc) ->
              comp cc (promote_reserved_mut_borrow config span l rid ctx)
          | None ->
          (* No loan to end inside the value *)
          (* Some sanity checks *)
          [%ltrace
            "resulting value:\n" ^ tvalue_to_string ~span:(Some span) ctx sv];
          [%sanity_check] span (not (concrete_loans_in_value sv));
          [%sanity_check] span (not (bottom_in_value ctx.type_ctx.type_infos ctx.ended_regions sv));
          [%sanity_check] span (not (reserved_in_value sv));
          (* End the borrows which borrow from the value, at the exception of
             the borrow we want to promote *)
          let bids =
            List.filter
              (fun bid' -> bid' <> rid)
              (lookup_shared_reserved_borrows l ctx)
          in
          let bids = List.map (fun bid -> UShared (l, bid)) bids in
          let ctx, cc =
            end_borrows config span (UniqueBorrowIdSet.of_list bids) ctx
          in
          (* Promote the loan - TODO: this will fail if the value contains
           * any loans. In practice, it shouldn't, but we could also
           * look for loans inside the value and end them before promoting
           * the borrow. *)
          let v, ctx = promote_shared_loan_to_mut_loan span l rid ctx in
          (* Promote the borrow - the value should have been checked by
             {!promote_shared_loan_to_mut_loan}
          *)
          let ctx = replace_reserved_borrow_with_mut_borrow span l rid v ctx in
          (* Return *)
          (ctx, cc)))
  | Some (_, Abstract _) ->
      (* I don't think it is possible to have two-phase borrows involving borrows
       * returned by abstractions. I'm not sure how we could handle that anyway. *)
      [%craise] span
        "Can't activate a reserved mutable borrow referencing a loan inside\n\
        \         a region abstraction"

let rec proj_has_ownership = function
  (* ```ocaml *)
  | ATransportedProj (_, child) -> proj_has_ownership child
  (* ``` *)
  | APendingLoans _ | AProjLoans _ | AProjBorrows _ -> true
  | AEndedProjLoans { consumed; borrows; _ } ->
      List.exists (fun (_, p) -> proj_has_ownership p) consumed
      || List.exists (fun (_, p) -> proj_has_ownership p) borrows
  | AEndedProjBorrows { loans; _ } ->
      List.exists (fun (_, p) -> proj_has_ownership p) loans
  | APendingSymbolicLoans _ | AEmpty -> false

let rec tavalue_has_ownership span ctx (av : tavalue) =
  let owns = tavalue_has_ownership span ctx in
  match av.value with
  (* ```ocaml *)
  | ATransportedValue (_, child) -> owns child
  (* ``` *)
  | AIgnored _ -> false
  | AAdt adt -> List.exists owns adt.fields
  | ASymbolic (_, proj) -> proj_has_ownership proj
  | ALoan lc -> (
      match lc with
      | AMutLoan _ | ASharedLoan _ -> true
      | AIgnoredMutLoan (_, bid, child) -> Option.is_some bid || owns child
      | AIgnoredSharedLoan child -> owns child
      | AEndedSharedLoan (_, value, child) ->
          tvalue_has_loans_or_borrows (Some span) ctx value || owns child
      | AEndedMutLoan { child; given_back; _ }
      | AEndedIgnoredMutLoan { child; given_back; _ } ->
          owns child || owns given_back)
  | ABorrow bc -> (
      match bc with
      | AMutBorrow _ | ASharedBorrow _ -> true
      | AIgnoredMutBorrow (bid, child) -> Option.is_some bid || owns child
      | AEndedIgnoredMutBorrow { child; given_back; _ } ->
          owns child || owns given_back
      | AEndedMutBorrow (_, child) -> owns child
      | AEndedSharedBorrow -> false
      | AProjSharedBorrow (_, borrows) -> borrows <> [])

let destructure_abs (span : Meta.span) (abs_kind : abs_kind) ~(can_end : bool)
    (ctx : eval_ctx) (abs0 : abs) : abs =
  [%ltrace "- abs:\n" ^ abs_to_string span ctx abs0];
  (* Accumulator to store the destructured values *)
  let avalues = ref [] in
  (* Utility function to store a value in the accumulator *)
  let push_avalue av = avalues := List.append !avalues [ av ] in
  (* We use this function to make sure we never register values (i.e.,
     loans or borrows) when we shouldn't - see it as a sanity check:
     for now, we don't allow nested borrows, which means we should register
     values from children of borrows. In this condition, we could simply
     ignore the children altogether. Instead, we explore them and make sure
     we don't register values while doing so.
  *)
  let push_fail _ = [%craise] span "Unreachable" in
  (* Symbolic children are sub-abstractions, not ADT fields: moving them to
     the root would change their ending level. Keep each live projection tree
     together with its given-back metadata and continuation correspondence.
     An ended root can only disappear when none of its descendants owns
     anything anymore. *)
  (* Function to explore an avalue and destructure it *)
  let rec list_avalues (allow_borrows : int) (push : tavalue -> unit)
      (av : tavalue) : unit =
    let ty = av.ty in
    match av.value with
    (* ```ocaml *)
    | ATransportedValue _ ->
        if tavalue_has_ownership span ctx av then push av
    (* ``` *)
    | AIgnored _ -> ()
    | AAdt adt ->
        (* Simply explore the children *)
        List.iter (list_avalues allow_borrows push) adt.fields
    | ALoan lc -> (
        (* Explore the loan content *)
        match lc with
        | ASharedLoan (pm, bids, sv, child_av) ->
            (* Shared payloads remain single operational owners: the payload
               stays whole below. Its mutable borrows (e.g., the field
               [native : &'n mut T] of the payload of [&C<'n>], or of a copy of
               it, see [InterpJoin.reborrow_ashared_loans]) are only read
               through the loan; their loans are in other abstractions. *)
            (* Push a value *)
            let ignored = mk_aignored span ctx.type_ctx.type_infos child_av.ty None in
            let value = ALoan (ASharedLoan (pm, bids, sv, ignored)) in
            push { value; ty };
            (* Explore the child *)
            list_avalues 0 push child_av
        | AMutLoan (pm, bid, child_av) ->
            (* Explore the child *)
            list_avalues 0 push_fail child_av;
            (* Explore the whole loan *)
            let ignored = mk_aignored span ctx.type_ctx.type_infos child_av.ty None in
            let value = ALoan (AMutLoan (pm, bid, ignored)) in
            push { value; ty }
        | AIgnoredMutLoan (pm, parent, child) ->
            (* Shared loans stay at this level. Mutable descendants retain
               the parent dependency for its later value return. *)
            let rec separate_shared (child : tavalue) =
              match child.value with
              | ALoan (ASharedLoan _ | AEndedSharedLoan _) ->
                  list_avalues 0 push child;
                  mk_aignored span ctx.type_ctx.type_infos child.ty None
              | AAdt adt ->
                  { child with value = AAdt
                      { adt with fields = List.map separate_shared adt.fields } }
              | ALoan (AIgnoredMutLoan (pm, parent, inner)) ->
                  { child with value = ALoan
                      (AIgnoredMutLoan (pm, parent, separate_shared inner)) }
              | ALoan (AIgnoredSharedLoan inner) ->
                  { child with value = ALoan
                      (AIgnoredSharedLoan (separate_shared inner)) }
              | _ -> child
            in
            let child = separate_shared child in
            let av = { av with value = ALoan (AIgnoredMutLoan (pm, parent, child)) } in
            if tavalue_has_ownership span ctx av then push av
        | AEndedSharedLoan (pm, sv, child_av) ->
            (* Do not discard surviving ownership when shared values are kept
               concrete. Only an ownership-free payload can be forgotten. *)
            if tvalue_has_loans_or_borrows (Some span) ctx sv then
              push
                {
                  value =
                    ALoan
                      (AEndedSharedLoan
                         (pm, sv, mk_aignored span ctx.type_ctx.type_infos child_av.ty None));
                  ty;
                };
            (* Explore the child *)
            list_avalues 0 push child_av
        | AIgnoredSharedLoan child_av ->
            (* The outer region is unowned here. Its child loans are genuine
               owners in this abstraction, not forbidden nested borrowers. *)
            list_avalues 0 push child_av
        | AEndedMutLoan ended ->
            (* Child loans still belong to this level and must participate in
               ordinary marker reconciliation. Only give-back ownership stays
               nested at the next sub-abstraction level. *)
            let child = mk_aignored span ctx.type_ctx.type_infos ended.child.ty None in
            let retained =
              { av with value = ALoan (AEndedMutLoan { ended with child }) }
            in
            if tavalue_has_ownership span ctx retained then push retained;
            list_avalues 0 push ended.child
        | AEndedIgnoredMutLoan ended ->
            (* The given-back output must be separated from the residual call
               together with its continuation, not flattened here on its own. *)
            let child = mk_aignored span ctx.type_ctx.type_infos ended.child.ty None in
            let retained =
              {
                av with
                value = ALoan (AEndedIgnoredMutLoan { ended with child });
              }
            in
            if tavalue_has_ownership span ctx retained then push retained;
            list_avalues 0 push ended.child)
    | ABorrow bc -> (
        (* Sanity check - rem.: may be redundant with [push_fail] *)
        [%sanity_check] span (allow_borrows > 0);
        (* Explore the borrow content *)
        match bc with
        | AMutBorrow (pm, bid, child_av) ->
            (* Explore the child *)
            list_avalues 0 push_fail child_av;
            (* Explore the borrow *)
            let ignored = mk_aignored span ctx.type_ctx.type_infos child_av.ty None in
            let value = ABorrow (AMutBorrow (pm, bid, ignored)) in
            push { value; ty }
        | ASharedBorrow _ ->
            (* Nothing specific to do: keep the value as it is *)
            push av
        | AIgnoredMutBorrow (bid, child) ->
            (* The borrowed value of an ignored borrow stays at the current
               level (only the value it gives back is one level deeper), so
               owned borrows below several ignored borrows are at level 0,
               e.g. the [&'p mut] fields of a [&'s mut LowerCtx<'p>] captured
               by a closure passed as [&'c mut]. Normalize the future
               give-back into an explicit input dependency, without inventing
               a symbolic value before the parent returns. *)
            list_avalues allow_borrows push child;
            Option.iter
              (fun bid ->
                if ty_has_regions_in_set ctx.type_ctx.type_infos abs0.regions.owned child.ty then
                  push
                    {
                      value = ASymbolic (PNone, APendingLoans bid);
                      ty =
                        isolate_projection_ty ~refreshed:(ref RegionId.Map.empty)
                          ctx.type_ctx.type_infos abs0.regions.owned
                          ctx.fresh_region_id child.ty;
                    })
              bid
        | AEndedIgnoredMutBorrow { child; given_back; _ } ->
            (* The parent dependency has resolved. Join normalization lifts its
               give-back loans to the new abstraction's inputs; continuation
               composition performs the matching lift to a leading call argument
               in [abs_cont_destructure_input_output_levels]. The child stays
               at the current level, the given-back value is one level deeper. *)
            list_avalues allow_borrows push child;
            list_avalues (allow_borrows - 1) push given_back
        | AProjSharedBorrow (_, asb) -> if asb <> [] then push av
        | AEndedMutBorrow _ | AEndedSharedBorrow ->
            (* If we get there it means the abstraction ended: it should not
               be in the context anymore (if we end *one* borrow in an abstraction,
               we have to end them all and remove the abstraction from the context)
            *)
            [%craise] span "Unreachable")
    | ASymbolic (_, APendingSymbolicLoans _) -> push av
    | ASymbolic (_, aproj) -> if proj_has_ownership aproj then push av
  in

  (* Destructure the avalues *)
  List.iter (list_avalues 2 push_avalue) abs0.avalues;
  let avalues = !avalues in
  (* Destructuring does not turn an existing function-input owner into a
     continuation introduced by the join or loop doing the destructuring. *)
  let abs_kind, can_end =
    match abs0.kind with
    | SynthInput _ -> (abs0.kind, abs0.can_end)
    | _ -> (abs_kind, can_end)
  in
  (* Update *)
  { abs0 with avalues; kind = abs_kind; can_end }

let abs_is_destructured (span : Meta.span) (ctx : eval_ctx) (abs : abs) : bool =
  let abs' = destructure_abs span abs.kind ~can_end:abs.can_end ctx abs in
  [%ldebug
    "- abs:\n" ^ abs_to_string span ctx abs ^ "\n- abs':\n"
    ^ abs_to_string span ctx abs'];
  (* Ignore optional concrete metadata on both sides. Destructuring only
     changes avalues; traversing the unchanged continuation would unfold its
     shared expression DAG without contributing to this comparison. *)
  let visitor =
    object
      inherit [_] map_tavalue
      method! visit_ty _ ty = ty
      method! visit_tvalue _ value = value
      method! visit_AIgnored _ _ = AIgnored None
    end
  in
  let normalize abs =
    { abs with avalues = List.map (visitor#visit_tavalue ()) abs.avalues }
  in
  normalize abs = normalize abs'

exception FoundBorrowId of unique_borrow_id
exception FoundAbsId of AbsId.id
exception FoundSharedChildAbsId of AbsId.id

(** Check whether an abstraction only holds shared borrows: no loans (ignored
    or not), no mutable borrows and no symbolic projections.

    Such an abstraction gives nothing back and consumes nothing when it ends
    (the regions it owns have no backward function): ending it does not depend
    on its parent abstractions. Example: the region abstractions of the nested
    regions of a shared slice iterator, e.g., the regions ['b], ['c] of
    [Iter<'a, (&'b str, View<'c>)>] once the iterator is dead. *)
let abs_only_holds_shared_borrows (abs : abs) : bool =
  let visitor =
    object
      inherit [_] iter_abs as super
      method! visit_ty _ _ = ()
      method! visit_abs_cont _ _ = ()
      method! visit_ALoan _ _ = raise Found
      method! visit_ASymbolic _ _ _ = raise Found

      method! visit_aborrow_content env bc =
        match bc with
        | ASharedBorrow _ | AProjSharedBorrow _ | AEndedSharedBorrow ->
            super#visit_aborrow_content env bc
        | AMutBorrow _
        | AIgnoredMutBorrow _
        | AEndedMutBorrow _
        | AEndedIgnoredMutBorrow _ -> raise Found
    end
  in
  try
    visitor#visit_abs () abs;
    true
  with Found -> false

(** Check whether a loan projector has no remaining borrowers.

    The symbolic value itself also counts as a borrower. Set [lookup_shared]
    when ending the projector without first ending shared reborrow projectors.
*)
let loan_proj_is_endable (span : Meta.span) (ctx : eval_ctx)
    ~(lookup_shared : bool) (regions : RegionId.Set.t) (proj : symbolic_proj) :
    bool =
  (* Endability is existential, including while collapse still contains
     branch-marked alternatives. Stop at the first borrower rather than
     invoking the linear-context lookup's exclusivity checks across all hits. *)
  let check_borrow borrowed_regions (borrow : symbolic_proj) =
    if
      proj_borrows_intersects_proj_loans span ctx
        (borrowed_regions, borrow.sv_id, borrow.proj_ty)
        (regions, proj.sv_id, proj.proj_ty)
    then raise Found
  in
  let visitor =
    object (self)
      inherit [_] iter_eval_ctx as super
      method! visit_ty _ _ = ()
      method! visit_abs_cont _ _ = ()
      method! visit_abs _ abs = super#visit_abs abs.regions.owned abs

      (* ```ocaml *)
      method! visit_ATransportedProj _ transport child =
        self#visit_aproj transport.current_regions child

      method! visit_ATransportedValue _ transport child =
        self#visit_tavalue transport.current_regions child
      (* ``` *)

      method! visit_VSymbolic _ sv =
        if sv.sv_id = proj.sv_id then raise Found else ()

      method! visit_abstract_shared_borrow borrowed_regions asb =
        match asb with
        | AsbProjReborrows borrow when lookup_shared ->
            check_borrow borrowed_regions borrow
        | AsbBorrow _ | AsbProjReborrows _ -> ()

      method! visit_aproj borrowed_regions aproj =
        (match aproj with
        | AProjBorrows { proj = borrow; _ } ->
            check_borrow borrowed_regions borrow
        | _ -> ());
        super#visit_aproj borrowed_regions aproj
    end
  in
  try
    visitor#visit_eval_ctx RegionId.Set.empty ctx;
    true
  with Found -> false

(** Find the first endable loan projector in an abstraction.

    An endable loan projector is a loan projector over a symbolic value which
    doesn't appear anywhere else in the context.

    This function may raise a [FoundAbsProj] exception. *)
let find_first_endable_loan_proj_in_abs (span : Meta.span) (ctx : eval_ctx)
    (abs : abs) : unit =
  (* ```ocaml *)
  let current_regions = ref abs.regions.owned in
  (* ``` *)
  let visitor =
    object (self)
      inherit [_] iter_abs_with_levels as super
      method! visit_ty _ _ = ()
      method! visit_abs_cont _ _ = ()
      method incr_level level = level + 1

      (* ```ocaml *)
      method! visit_ATransportedValue level transport child =
        let previous = !current_regions in
        current_regions := transport.current_regions;
        self#visit_tavalue level child;
        current_regions := previous
      (* ``` *)

      method! visit_aproj level proj =
        match proj with
        (* ```ocaml *)
        | ATransportedProj (transport, child) ->
            let previous = !current_regions in
            current_regions := transport.current_regions;
            self#visit_aproj level child;
            current_regions := previous
        (* ``` *)
        | AProjLoans proj ->
            if
              loan_proj_is_endable span ctx ~lookup_shared:true
                !current_regions proj.proj
            then raise (FoundAbsProj (abs.abs_id, level, proj.proj))
            else super#visit_aproj level (AProjLoans proj)
        | APendingLoans _
        | APendingSymbolicLoans _
        | AProjBorrows _
        | AEndedProjLoans _
        | AEndedProjBorrows _
        | AEmpty -> super#visit_aproj level proj
    end
  in
  (* Visit *)
  visitor#visit_abs 0 abs

(** Small helper

    Iterate over all the mutable borrows (concrete borrows and borrow
    projectors) in the abstraction and find their corresponding loans: return
    [true] if one of those loans is inside an abstraction identified by the set
    [fixed_abs_ids]. *)
let abs_mut_borrows_loans_in_fixed span (ctx : eval_ctx)
    (fixed_abs_ids : AbsId.Set.t) (abs : abs) : bool =
  (* Iterate through the loan projectors which intersect a given borrow
     projector and which are held by a fixed abstraction or by a loop
     abstraction. Ending the borrow projector gives back to those loan
     projectors, like ending a concrete borrow gives back to its loan: this
     only matters for the fixed abstractions, and for the abstractions of the
     loop fixed points, whose loan projectors must stay as in the fixed point
     (the contexts at the [continue] and [break] of the loop body are matched
     with the ones computed from the fixed point). *)
  let visit_proj_loans (proj : symbolic_proj) =
    object
      inherit [_] iter_eval_ctx as super
      method! visit_ty _ _ = ()
      method! visit_abs_cont _ _ = ()

      method! visit_abs env abs =
        [%sanity_check] span (env = None);
        super#visit_abs (Some abs) abs

      method! visit_AProjLoans env proj' =
        let holder = Option.get env in
        let holder_fixed =
          AbsId.Set.mem holder.abs_id fixed_abs_ids
          ||
          match holder.kind with
          | Loop _ -> true
          | FunCall _ | SynthInput _ | SynthRet _ | Identity
          | CopySymbolicValue | WithCont | Join ->
              false
        in
        if
          holder_fixed
          && proj.sv_id = proj'.proj.sv_id
          && projections_intersect span ctx abs.regions.owned proj.proj_ty
               holder.regions.owned proj'.proj.proj_ty
        then raise Found
        else super#visit_AProjLoans env proj'
    end
  in

  let visit_borrows =
    object
      inherit [_] iter_eval_ctx as super
      method! visit_ty _ _ = ()
      method! visit_abs_cont _ _ = ()

      method! visit_AEndedSharedLoan env _pm _sv child =
        (* Released concrete ownership is transferred unchanged, not ended
           with the abstraction. Only its abstract children can give back. *)
        super#visit_tavalue env child

      method! visit_borrow_content _ _ =
        (* We can get there through shared loans: let's just ignore it for now
           (this function should be used to explore abstractions which don't
           have remaining loans - see its use below) *)
        [%internal_error] span

      method! visit_aborrow_content env lc =
        super#visit_aborrow_content env lc;
        match lc with
        | AMutBorrow (_, bid, _) ->
            (* Lookup the loan *)
            let abs_or_var, _ = ctx_lookup_loan span ek_all bid ctx in
            begin
              match abs_or_var with
              | AbsId abs_id ->
                  if AbsId.Set.mem abs_id fixed_abs_ids then raise Found else ()
              | LocalId _ | DummyVarId _ -> ()
            end;
            super#visit_aborrow_content env lc
        | ASharedBorrow _
        | AIgnoredMutBorrow _
        | AEndedMutBorrow _
        | AEndedSharedBorrow
        | AEndedIgnoredMutBorrow _
        | AProjSharedBorrow _ -> ()

      method! visit_aproj env proj =
        super#visit_aproj env proj;
        match proj with
        | AProjBorrows proj ->
            (visit_proj_loans proj.proj)#visit_eval_ctx None ctx
        (* ```ocaml *)
        | ATransportedProj _ -> ()
        (* ``` *)
        | APendingLoans _
        | APendingSymbolicLoans _
        | AProjLoans _
        | AEndedProjLoans _
        | AEndedProjBorrows _
        | AEmpty -> ()
    end
  in
  try
    visit_borrows#visit_abs () abs;
    false
  with Found -> true

(** Check whether the loans of a region abstraction are only borrowed by its
    own deeper levels.

    A value lent by an abstraction can come back to it through a nested loan.
    For instance, the abstraction of ['b] for a call returning
    [&'a mut Frame<'b>] lends the borrows of the frame; ending the outer borrow
    gives the frame back to its ignored mutable loan, one level deeper (see
    {!aended_ignored_mut_loan}): the abstraction then holds both the loans and
    their borrows. Ending it first ends its deeper levels (see
    {!end_all_sub_abs}), which gives those borrows back to its own loans: the
    rest of the context is not affected. Loan projectors over symbolic values
    do not track their borrowers, and concrete borrows in shared values are
    not considered either: such abstractions are never considered. *)
let abs_loans_only_borrowed_by_deeper_levels (ctx : eval_ctx) (abs : abs) :
    bool =
  let exception External in
  let loans = ref [] in
  let borrows = ref BorrowId.Map.empty in
  let add_loan level bid = loans := (level, bid) :: !loans in
  let add_borrow level bid =
    borrows :=
      BorrowId.Map.update bid
        (function
          | None -> Some level
          | Some level' -> Some (Int.min level level'))
        !borrows
  in
  let visitor =
    object
      inherit [_] iter_abs_with_levels as super
      method incr_level level = level + 1
      method! visit_ty _ _ = ()
      method! visit_abs_cont _ _ = ()

      method! visit_AMutLoan level pm bid child =
        add_loan level bid;
        super#visit_AMutLoan level pm bid child

      method! visit_ASharedLoan level pm bid sv child =
        add_loan level bid;
        super#visit_ASharedLoan level pm bid sv child

      method! visit_VSharedLoan level bid sv =
        add_loan level bid;
        super#visit_VSharedLoan level bid sv

      method! visit_VMutLoan level bid =
        add_loan level bid;
        super#visit_VMutLoan level bid

      method! visit_AProjLoans _ _ = raise External
      method! visit_borrow_content _ _ = raise External
      method! visit_ASharedBorrow level _ bid _ = add_borrow level bid
      method! visit_AsbBorrow level bid _ = add_borrow level bid

      method! visit_AMutBorrow level pm bid av =
        add_borrow level bid;
        super#visit_AMutBorrow level pm bid av
    end
  in
  try
    visitor#visit_abs 0 abs;
    let outside =
      let others =
        List.filter
          (function
            | EAbs abs' -> abs'.abs_id <> abs.abs_id
            | EBinding _ | EFrame -> true)
          ctx.env
      in
      (fst (compute_env_ids others)).blids
    in
    List.for_all
      (fun (level, bid) ->
        (not (BorrowId.Set.mem bid outside))
        &&
        match BorrowId.Map.find_opt bid !borrows with
        | Some borrow_level -> borrow_level > level
        | None -> false)
      !loans
  with External -> false

(** A value which contains no loans and no mutable borrows, including inside
    its symbolic values: discarding it gives nothing back and only releases
    shared loans. *)
let value_has_only_shared_borrows (ctx : eval_ctx) (v : tvalue) : bool =
  let exception Found in
  let visitor =
    object
      inherit [_] iter_tvalue
      method! visit_VLoan _ _ = raise Found

      method! visit_VBorrow _ bc =
        match bc with
        | VSharedBorrow _ -> ()
        | VMutBorrow _ | VReservedMutBorrow _ -> raise Found

      method! visit_VSymbolic _ sv =
        if ty_has_mut_borrows ctx.type_ctx.type_infos sv.sv_ty then raise Found
    end
  in
  try
    visitor#visit_tvalue () v;
    true
  with Found -> false

let eliminate_ended_shared_loans (span : Meta.span) (ctx : eval_ctx) : eval_ctx
    =
  (* Filter the avalues *)
  let update_abs (abs : abs) : abs =
    let keep (v : tavalue) : bool =
      match v.value with
      | ALoan (AEndedSharedLoan (_, sv, child))
        when (not (value_has_loans_or_borrows (Some span) ctx sv.value))
             && is_aignored child.value -> false
      (* The shared value of an ended shared loan cannot be accessed anymore:
         the shared borrows it contains are dead (e.g., the borrow of an
         element of a slice, whose reference was itself shared and is not
         live anymore). Dropping them releases the loans they borrow from.
         Only do so in abstractions which can end: fixed abstractions must
         not change. *)
      | ALoan (AEndedSharedLoan (_, sv, child))
        when abs.can_end && is_aignored child.value
             && value_has_only_shared_borrows ctx sv -> false
      | ASymbolic (_, AEndedProjLoans { proj = _; consumed; borrows })
        when List.for_all (fun (_, proj) -> proj = AEmpty) (consumed @ borrows)
        -> false
      | _ -> true
    in
    let avalues = List.filter keep abs.avalues in
    { abs with avalues }
  in
  let ctx = ctx_map_abs update_abs ctx in

  (* *)
  ctx

(* Repeat until we can't simplify the context anymore:
   - end the borrows which appear in anonymous values and don't contain loans
   - end the region abstractions which can be ended (no loans)
   - replace the values in anonymous values with bottom whenever possible
     (the value is not inside a borrow/loan and doesn't itself contain borrows/loans)
   - end the shared loans which don't have corresponding borrows
   - end the loan projectors inside region abstractions when the corresponding
     symbolic value doesn't appear anywhere else in the context
   However we ignore the "fixed" abstractions.
*)
let rec simplify_dummy_values_useless_abs_aux (config : config)
    ~(snapshots : bool) (span : Meta.span) : cm_fun =
 fun ctx ->
  let simplify_abs = true in
  let simplify_borrows = true in
  (* Small utilities: we do not modify the region abstractions marked as frozen
     (i.e., which should not be ended) - it is usually important that those remain
     the same, for instance when computing fixed points. *)
  let frozen_abs =
    let abs = env_get_abs ctx.env in
    AbsId.Set.of_list
      (List.filter_map
         (fun (abs : abs) -> if abs.can_end then None else Some abs.abs_id)
         (AbsId.Map.values abs))
  in
  (* Every lookup in this pass uses the same immutable context. A recursive
     simplification after ending a borrower constructs a fresh index. *)
  let borrowed_shared_loans = lazy (shared_reserved_loan_ids ctx) in
  let shared_loan_has_borrows l =
    BorrowId.Set.mem l (Lazy.force borrowed_shared_loans)
  in
  let loan_id_not_in_fixed_abs (lid : BorrowId.id) : bool =
    match fst (ctx_lookup_loan span ek_all lid ctx) with
    | AbsId abs_id -> not (AbsId.Set.mem abs_id frozen_abs)
    | _ -> true
  in
  let rec explore_env (ctx : eval_ctx) (env : env) : env =
    match env with
    | [] -> [] (* Done *)
    | EBinding (BDummy vid, v) :: env ->
        [%ldebug
          "Dummy value " ^ DummyVarId.to_string vid ^ ":\n"
          ^ tvalue_to_string ctx v];
        (* If the symbolic value doesn't contain concrete borrows or loans
           we simply ignore it *)
        if not (concrete_borrows_loans_in_value v.value) then (
          [%ldebug "Eliminating the value"];
          explore_env ctx env)
        else (
          [%ldebug "Diving into the value"];
          (* Explore the anonymous value - raises an exception if it finds
             a borrow to end *)
          let visitor =
            object (self)
              inherit [_] map_tvalue as super
              method! visit_ty _ ty = ty

              method! visit_VLoan end_borrows lc =
                (* Check if we can end the loan, but don't dive inside *)
                match lc with
                | VSharedLoan (l, value) -> begin
                    [%ldebug
                      "Found shared loan:\n" ^ loan_content_to_string ctx lc];
                    if shared_loan_has_borrows l then super#visit_VLoan false lc
                    else
                      (* End the loan *)
                      self#visit_value end_borrows value.value
                  end
                | _ -> super#visit_VLoan false lc

              method! visit_VBorrow end_borrows bc =
                (* Simplify if the option is on *)
                if end_borrows && simplify_borrows then
                  (* Check if we can end the borrow, do not enter inside if we can't *)
                  match bc with
                  | VSharedBorrow (bid, sid) | VReservedMutBorrow (bid, sid) ->
                      (* We could directly end the borrow actually
                         (replace it with bottom). But it's also good to
                         raise an exception and call [end_borrow], as it
                         allows to make the implementation more consistent. *)
                      raise (FoundBorrowId (UShared (bid, sid)))
                  | VMutBorrow (bid, v) ->
                      if
                        (not (concrete_loans_in_value v))
                        && loan_id_not_in_fixed_abs bid
                      then raise (FoundBorrowId (UMut bid))
                      else
                        (* There might be shared loans to end inside the borrow *)
                        let v = self#visit_tvalue false v in
                        VBorrow (VMutBorrow (bid, v))
                else VBorrow bc

              (* If no concrete borrows/loans and we can end borrows (we are not
                 inside a shared loan): replace with bottom *)
              method! visit_value end_borrows v =
                if end_borrows && not (concrete_borrows_loans_in_value v) then
                  VBottom
                else super#visit_value end_borrows v
            end
          in
          let v = visitor#visit_tvalue true v in
          (* No exception was raised: continue *)
          let env = explore_env ctx env in
          (* Check if we eliminated all remaining loans and borrows (we might
             have removed shared loans): we ignore the value if it is the case *)
          if not (concrete_borrows_loans_in_value v.value) then env
          else EBinding (BDummy vid, v) :: env)
    | EBinding (BVar vid, v) :: env ->
        [%ldebug
          "Value (name: "
          ^ Print.option_to_string (fun x -> x) vid.name
          ^ ",id: "
          ^ Expressions.LocalId.to_string vid.index
          ^ "):\n" ^ tvalue_to_string ctx v];
        (* End the shared loans which don't have corresponding borrows.
           We explore the value and raise an exception if it finds a borrow to end *)
        let visitor =
          object (self)
            inherit [_] map_tvalue as super
            method! visit_ty _ ty = ty

            method! visit_VLoan end_borrows lc =
              (* Check if we can end the loan, but don't dive inside *)
              match lc with
              | VSharedLoan (l, value) -> begin
                  [%ldebug
                    "Found shared loan:\n" ^ loan_content_to_string ctx lc];
                  if shared_loan_has_borrows l then super#visit_VLoan false lc
                  else
                    (* End the loan *)
                    self#visit_value end_borrows value.value
                end
              | _ -> super#visit_VLoan false lc
          end
        in
        let v = visitor#visit_tvalue true v in
        (* No exception was raised: continue *)
        EBinding (BVar vid, v) :: explore_env ctx env
    | EAbs abs :: _
      when simplify_abs && abs.can_end
           && (not (AbsId.Set.is_empty abs.parents))
           && (not (AbsId.Set.mem abs.abs_id frozen_abs))
           && abs_only_holds_shared_borrows abs ->
        (* A child abstraction which only holds shared borrows can end before
           its parents (see [abs_only_holds_shared_borrows]) *)
        raise (FoundSharedChildAbsId abs.abs_id)
    | EAbs abs :: env
      when simplify_abs && abs.can_end
           && AbsId.Set.is_empty abs.parents
           && not (AbsId.Set.mem abs.abs_id frozen_abs) -> (
        [%ldebug "Diving into abs:\n" ^ abs_to_string span ctx abs];
        (* End the shared loans with no corresponding borrows *)
        let visitor =
          object
            inherit [_] map_abs as super
            method! visit_ty _ ty = ty

            (* Shared loans have no continuation counterpart. Preserve the
               expression DAG instead of copying it during operational cleanup. *)
            method! visit_abs_cont _ cont = cont

            method! visit_VLoan () lc =
              (* Check if we can end the loan, but don't dive inside *)
              match lc with
              | VSharedLoan (l, value) -> begin
                  if shared_loan_has_borrows l then super#visit_VLoan () lc
                  else
                    (* End the loan *)
                    super#visit_value () value.value
                end
              | _ -> super#visit_VLoan () lc

            method! visit_ASharedLoan () pm l sv child =
              [%sanity_check] span (pm = PNone);
              if shared_loan_has_borrows l then
                super#visit_ASharedLoan () pm l sv child
              else
                (* End the loan *)
                super#visit_AEndedSharedLoan () pm sv child
          end
        in
        let abs = visitor#visit_abs () abs in
        (* Check if it is possible to end the abstraction: if yes, raise an exception *)
        let opt_loan = get_first_non_ignored_aloan_in_abs span abs 0 (-1) in
        match opt_loan with
        | None ->
            [%ldebug
              "No non-ignored aloans in abs:\n" ^ abs_to_string span ctx abs];
            (* No remaining loans: we can end the abstraction.

               However, we need to make sure that ending this abstraction will not
               modify the *fixed* abstractions: we thus explore all the borrows and
               check that there corresponding loans are not inside fixed abstractions
               (because otherwise ending the borrow would end the loan).

               TODO: this limitation is annoying. We need to generalize the join.
            *)
            if not (abs_mut_borrows_loans_in_fixed span ctx frozen_abs abs) then
              raise (FoundAbsId abs.abs_id)
            else EAbs abs :: explore_env ctx env
        | Some _
          when abs_loans_only_borrowed_by_deeper_levels ctx abs
               && not (abs_mut_borrows_loans_in_fixed span ctx frozen_abs abs)
          ->
            [%ldebug
              "The loans of the abs are only borrowed by its deeper levels:\n"
              ^ abs_to_string span ctx abs];
            raise (FoundAbsId abs.abs_id)
        | Some _ ->
            [%ldebug
              "There are non-ignored aloans in abs:\n"
              ^ abs_to_string span ctx abs];
            (* There are remaining loans: we can't end the abstraction *)
            (* Check if we can end some loan projectors (because there doesn't
               remain corresponding borrow projectors in the context) *)
            find_first_endable_loan_proj_in_abs span ctx abs;
            (* Continue *)
            EAbs abs :: explore_env ctx env)
    | EAbs abs :: env
      when simplify_abs && abs.can_end
           && (not (AbsId.Set.is_empty abs.parents))
           && not (AbsId.Set.mem abs.abs_id frozen_abs) ->
        (* A child abstraction cannot end before its parents, but its loan
           projectors over symbolic values which do not appear anywhere else
           in the context can end, like the ones of the abstractions without
           parents: the loans are given back independently of the order in
           which the abstractions end (e.g., the abstraction of the region of
           the inner borrows of a joined [Option<&'a mut Frame<'b>>], a child
           of the one of ['a], after the joined value was overwritten). *)
        find_first_endable_loan_proj_in_abs span ctx abs;
        EAbs abs :: explore_env ctx env
    | b :: env -> b :: explore_env ctx env
  in
  let rec_call = simplify_dummy_values_useless_abs_aux config span ~snapshots in
  try
    (* Explore the environment.

       Note that we don't need to call [end_loan] whenever we need to end a shared
       loan: we can directly update the value. *)
    ({ ctx with env = explore_env ctx ctx.env }, fun e -> e)
  with
  | FoundAbsId abs_id ->
      (* TODO: generalize so that we can end sub-abstractions *)
      let ctx, cc = end_abs config span ~snapshots abs_id 0 ctx in
      comp cc (rec_call ctx)
  | FoundSharedChildAbsId abs_id ->
      (* Detach the abstraction from its parents, which stay alive *)
      let abs = ctx_lookup_abs ctx abs_id in
      let ctx, _ =
        ctx_subst_abs span ctx abs_id { abs with parents = AbsId.Set.empty }
      in
      let ctx, cc = end_abs config span ~snapshots abs_id 0 ctx in
      comp cc (rec_call ctx)
  | FoundBorrowId bid ->
      let ctx, cc = end_borrow config span ~snapshots bid ctx in
      comp cc (rec_call ctx)
  | FoundAbsProj (abs_id, level, proj) ->
      (* We can end this loan projector (there are no corresponding borrows
         projectors in the context): set it as ended and continue *)
      let ctx = update_aproj_loans_to_ended span abs_id level proj ctx in
      rec_call ctx

let simplify_dummy_values_useless_abs (config : config)
    ?(snapshots : bool = true) (span : Meta.span) : cm_fun =
 fun ctx0 ->
  [%ldebug eval_ctx_to_string ctx0];
  (* Simplify the context as long as it leads to changes - TODO: make this more efficient *)
  let rec simplify ctx0 =
    let ctx, cc =
      simplify_dummy_values_useless_abs_aux config span ~snapshots ctx0
    in
    Invariants.check_invariants span ctx;
    (* Total IR comparison short-circuits physically shared continuation DAGs. *)
    if Stdlib.compare ctx.env ctx0.env = 0 then (
      [%ldebug "Done:\n" ^ eval_ctx_to_string ctx];
      (ctx, cc))
    else (
      [%ldebug "Not finished:\n" ^ eval_ctx_to_string ctx];
      comp cc (simplify ctx))
  in
  (* Eliminating the ended shared loans drops the shared borrows of their
     payloads (see [eliminate_ended_shared_loans]), which may leave the loans
     they borrow from without borrowers: simplify again until neither step
     changes the context. Otherwise the result depends on the number of calls
     (e.g., a first call keeps the unborrowed dummy loan of the ['static str]
     field of a slice element whose shared loan ended, a second call removes
     it), and a join whose contexts were simplified once does not match the
     same contexts simplified twice. *)
  let rec simplify_eliminate ctx0 =
    let ctx, cc = simplify ctx0 in
    let ctx' = eliminate_ended_shared_loans span ctx in
    if Stdlib.compare ctx'.env ctx.env = 0 then (ctx, cc)
    else comp cc (simplify_eliminate ctx')
  in
  let ctx, cc = simplify_eliminate ctx0 in
  [%ltrace
    "- ctx0:\n" ^ eval_ctx_to_string ctx0 ^ "\n- ctx1:\n"
    ^
    if Stdlib.compare ctx.env ctx0.env = 0 then "UNCHANGED"
    else eval_ctx_to_string ctx];
  (ctx, cc)
