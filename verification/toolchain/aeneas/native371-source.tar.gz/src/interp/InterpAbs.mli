open Types
open Values
open Contexts

(** Stable region annotation for ignored payload slots, independent of the
    current payload's temporary lifetimes. Erased regions become unowned. *)
val unowned_rty_of_ety :
  Meta.span -> eval_ctx -> ety -> rty * region_metadata_bindings

(** Region type of an operational retained payload. Erased child lifetimes get
    distinct unowned witnesses; symbolic payloads keep their original type. *)
val retained_value_rty :
  Meta.span -> eval_ctx -> tvalue -> rty * region_metadata_bindings

(** Turn a value into a abstractions.

    We generally use this to turn anonymous values into region abstractions.

    We are conservative, and don't group borrows/loans into the same abstraction
    unless necessary.

    For instance:
    {[
      _ -> (mut_borrow l1 (mut_loan l2), mut_borrow l3)

      ~~>

      abs'0 { mut_borrow l1, mut_loan l2 }
      abs'1 { mut_borrow l3 }
    ]}

    Parameters:
    - [abs_kind]
    - [can_end]
    - [ctx]
    - [v] *)
val convert_value_to_abstractions :
  Meta.span -> abs_kind -> can_end:bool -> eval_ctx -> tvalue ->
  abs list * region_metadata_bindings

(** The outermost borrow or loan of a value which region abstractions cannot
    hold because of the mutable borrows below it: a mutable borrow whose
    borrowed value holds mutable borrows outside of shared loans (nested
    borrows), or, if [shared_payloads], a shared loan whose payload holds
    mutable borrows. Ending its loan gives the nested borrows back. *)
val value_nested_mut_borrows_owner :
  Meta.span -> shared_payloads:bool -> eval_ctx -> tvalue -> BorrowId.id option

(** Convert a value to a list of *output* avalues (the value should contain
    borrows but no loans), and output and input expressions, so that we can put
    it in a region abstraction.

    We use this when performing joins. *)
val convert_value_to_output_avalues :
  Meta.span ->
  eval_ctx ->
  proj_marker ->
  tvalue ->
  RegionId.Set.t ->
  ty ->
  tavalue list * tevalue

val convert_value_to_input_avalues :
  Meta.span ->
  eval_ctx ->
  proj_marker ->
  tvalue ->
  RegionId.id ->
  rty ->
  tavalue list * tevalue * region_metadata_bindings * RegionId.Set.t

(** Join a field loan with its actual nested borrower while retaining both
    the original field return and the fresh storage return dependencies. *)
val join_mut_loan_with_nested_input :
  Meta.span ->
  eval_ctx ->
  loan_ctx:eval_ctx ->
  other_ctx:eval_ctx ->
  abs_kind:abs_kind ->
  with_abs_conts:bool ->
  loan_pm:proj_marker ->
  other_pm:proj_marker ->
  loan_id:loan_id ->
  other:tvalue ->
  abs list * tvalue * region_metadata_bindings

(** See {!merge_into_abstraction}.

    Rem.: it may be more idiomatic to have a functor, but this seems a bit
    heavyweight, though. *)
type merge_duplicates_funcs = {
  merge_amut_borrows :
    borrow_id ->
    rty ->
    proj_marker ->
    tavalue ->
    rty ->
    proj_marker ->
    tavalue ->
    tavalue;
      (** Parameters:
          - [id]
          - [ty0]
          - [pm0]
          - [child0]
          - [ty1]
          - [pm1]
          - [child1]

          The children should be [AIgnored]. *)
  merge_ashared_borrows :
    borrow_id ->
    rty ->
    proj_marker ->
    shared_borrow_id ->
    rty ->
    proj_marker ->
    shared_borrow_id ->
    tavalue;
      (** Parameters:
          - [id]
          - [ty0]
          - [pm0]
          - [sid0]
          - [ty1]
          - [pm1]
          - [sid1] *)
  merge_amut_loans :
    loan_id ->
    rty ->
    proj_marker ->
    tavalue ->
    rty ->
    proj_marker ->
    tavalue ->
    tavalue;
      (** Parameters:
          - [id]
          - [ty0]
          - [pm0]
          - [child0]
          - [ty1]
          - [pm1]
          - [child1]

          The children should be [AIgnored]. *)
  merge_ashared_loans :
    eval_ctx ->
    loan_id ->
    rty ->
    proj_marker ->
    tvalue ->
    tavalue ->
    rty ->
    proj_marker ->
    tvalue ->
    tavalue ->
    tavalue;
      (** Parameters:
          - [ids]
          - [ty0]
          - [pm0]
          - [sv0]
          - [child0]
          - [ty1]
          - [pm1]
          - [sv1]
          - [child1]

          The children are already reconciled and identical. Use their real
          region type for the wrapper's referent, retaining its owned outer
          region; the original referent types need not equal the child's. *)
  merge_aended_shared_loans :
    eval_ctx ->
    rty ->
    proj_marker ->
    tvalue ->
    tavalue ->
    rty ->
    proj_marker ->
    tvalue ->
    tavalue ->
    tavalue;
      (** Merge corresponding retained payloads with already reconciled
          children. Preserve the reconciled child's real region type as the
          wrapper's referent type, while retaining the wrapper's owned outer
          region. *)
  drain_new_abstractions : unit -> abs list * region_metadata_bindings;
      (** Transfer owners introduced while matching concrete payloads. *)
}
and merge_diagnostic = {
  merge_index : int;
  merge_phase : string;
  merge_step : int;
  merge_fixed : AbsId.Set.t option;
  merge_preserved : AbsId.Set.t;
  merge_before : eval_ctx;
  merge_left : abs;
  merge_right : abs;
  merge_isolated_left : abs;
  merge_isolated_right : abs;
  merge_left_coordinates : RegionId.id RegionId.Map.t;
  merge_right_coordinates : RegionId.id RegionId.Map.t;
  merge_after : eval_ctx;
  merge_result : abs_id;
  mutable merge_normalization_callback : (abs_id * abs_id * abs_id) option;
  mutable merge_selection :
    (string * (Format.formatter -> unit) * (string * bool) list) option;
}
and merge_diagnostics = {
  mutable trace_count : int;
  mutable trace_phase : string;
  mutable trace_step : int;
  mutable trace_fixed : AbsId.Set.t option;
  mutable trace_preserved : AbsId.Set.t;
  mutable trace_callback_unavailable : int;
  trace_records : merge_diagnostic option array;
}

(** Whether retained payloads are equal or share a concrete or symbolic owner.
*)
val shared_payloads_correspond : tvalue -> tvalue -> bool

val merge_abstractions_merge_markers :
  Meta.span ->
  merge_duplicates_funcs ->
  eval_ctx ->
  RegionId.Set.t ->
  tavalue list ->
  tavalue list

(** Nested borrows: the symbolic values of the level-1 outputs of a
    function-call abstraction which its loan projectors hold as [borrows] (the
    inner borrows of values given back when an ancestor region ended). *)
val abs_call_level_output_svs : abs -> SymbolicValueId.Set.t

(** Whether an abstraction holds (possibly nested) loan projectors over one of
    the given symbolic values. *)
val abs_lends_symbolic : abs -> SymbolicValueId.Set.t -> bool

(** Merge an abstraction into another abstraction.

    We insert the result of the merge in place of the first abstraction (and in
    particular, we don't simply push the merged abstraction at the end of the
    environment: this helps preserving the structure of the environment, when
    computing loop fixed points for instance).

    When we merge two abstractions together, we remove the loans which appear in
    the *left* abstraction and whose corresponding borrows appear in the
    **right** abstraction. For instance:
    {[
      abs'0 { mut_borrow l0, mut_loan l1 }   // Rem.: mut_loan l1
      abs'1 { mut_borrow l1, mut_borrow l2 } // Rem.: mut_borrow l1

          ~~>

      abs'2 { mut_borrow l0, mut_borrow l2 }
    ]}

    We also simplify the markers, when the same value appears in both
    abstractions but with different markers. For instance:
    {[
      abs'0 { |mut_borrow l0|, mut_loan l1 }
      abs'1 { ︙mut_borrow l0︙, mut_borrow l1 }

          ~~>

      abs'2 { mut_borrow l0 }
    ]}

    Finally, we merge all their regions together. For instance, if [abs'0]
    projects region [r0] and [abs'1] projects region [r1], we pick one of the
    two, say [r0] (the one with the smallest index in practice) and substitute
    [r1] with [r0] in the whole context.

    Parameters:
    - [kind]
    - [can_end]
    - [with_abs_conts]
    - [merge_funs]: those functions are used to merge borrows/loans with the
      *same ids* but different markers. This is necessary when doing a collapse
      (see the computation of joins). If [merge_funs] are not provided, we check
      that there are no markers.
    - [ctx]
    - [abs_id0]
    - [abs_id1]

    We return the updated context as well as the id of the new abstraction which
    results from the merge. *)
val merge_into_first_abstraction :
  Meta.span ->
  abs_kind ->
  ?diagnostic:merge_diagnostics ->
  can_end:bool ->
  with_abs_conts:bool ->
  merge_duplicates_funcs option ->
  eval_ctx ->
  AbsId.id ->
  AbsId.id ->
  eval_ctx * AbsId.id

val ctx_drop_carrierless_owned_regions : AbsId.Set.t -> eval_ctx -> eval_ctx

(** Reorder the fresh abstractions, as well as the loans and borrows inside
    them.

    We do this in order to enforce some structure in the environments: this
    allows us to find fixed-points. Note that this function needs to be called
    typically after we merge abstractions together (see {!reduce_ctx} and
    {!collapse_ctx} for instance).

    TODO: in the future it would be better to implement a more general matching
    algorithm, both for the joins and for checking whether two environments are
    equivalent.

    Inputs:
    - [span]
    - [allow_markers]: disables some sanity checks (which check that projection
      markers don't appear).
    - [old_abs_ids]
    - [eval_ctx] *)
val reorder_fresh_abs : Meta.span -> bool -> AbsId.Set.t -> eval_ctx -> eval_ctx

(** Whether top-level ignored slots and structured values belong to a positional
    continuation layout rather than a destructured ownership bag. *)
val abs_has_fixed_avalue_layout : abs -> bool

(** Project a context to only preserve the values appearing on the left or the
    values appearing on the right.

    The [proj_marker] must be [PLeft] or [PRight]. *)
val project_context :
  Meta.span -> AbsId.Set.t -> proj_marker -> eval_ctx -> eval_ctx

(** Introduce a continuation expression to a region abstraction.

    We use this for instance for loops and joins (after branchings): in the
    joined context, we replace the abstraction continuations of the fresh
    abstractions to reflect the fact that they should be introduced by the
    loop/join. Existing synthesis-input owners retain their original sentinel:
    joining their branch copies does not introduce a new input owner. *)
val add_abs_cont_to_abs : Meta.span -> eval_ctx -> abs -> abs_fun -> abs

(** Normalize parent-return projections before assigning branch markers.
    Already-produced outputs become independent capture abstractions; the
    residual continuation retains its current inputs and call stages. With
    [loop_level_outputs] (the reduction of a loop context), the values given
    back to the returned references of a call with a staged backward function
    stay in the residual abstraction as level-1 outputs of the call. *)
val normalize_abs_for_join :
  ?loop_level_outputs:bool -> Meta.span -> eval_ctx -> abs -> abs list
