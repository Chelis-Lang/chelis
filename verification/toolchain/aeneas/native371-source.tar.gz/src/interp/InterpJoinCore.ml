(** Core definitions for the [joins] *)

open Types
open Values
open Contexts
open InterpUtils
open InterpBorrowsCore

type updt_env_kind =
  | AbsInLeft of AbsId.id
  | LoanInLeft of BorrowId.id
  | LoansInLeft of BorrowId.Set.t
  | AbsInRight of AbsId.id
  | LoanInRight of BorrowId.id
  | LoansInRight of BorrowId.Set.t
[@@deriving show]

(** Utility exception *)
exception ValueMatchFailure of updt_env_kind

(** Utility exception *)
exception Distinct of string

(** Normalize only private root shared lifetimes that end with one owner. *)
let normalize_private_shared_regions (span : Meta.span) (ctx : eval_ctx) :
    eval_ctx =
  let candidate (abs : abs) =
    abs.can_end
    && RegionId.Set.cardinal abs.regions.owned > 1
    && AbsId.Set.is_empty abs.parents
    && AbsLevelSet.is_empty abs.ended_subabs
    && abs.call_scopes = []
  in

  if
    not
      (List.exists
         (function EAbs abs -> candidate abs | EBinding _ | EFrame -> false)
         ctx.env)
  then ctx

  else
    let source_regions =
      RegionId.Map.fold
        (fun rid binding regions ->
          match binding with
          | MetadataFresh -> regions

          | MetadataSource source ->
              let regions = RegionId.Set.add rid regions in
              match source with
              | RVar (Free source) -> RegionId.Set.add source regions
              | _ -> regions)
        ctx.metadata_bindings RegionId.Set.empty
    in

    let replacements = ref AbsId.Map.empty in
    let normalize (abs : abs) =
      let owned = abs.regions.owned in
      let mentions_owned (ty : ty) =
        let visitor =
          object
            inherit [_] iter_ty
            method! visit_region_id () rid =
              if RegionId.Set.mem rid owned then raise Utils.Found
          end
        in

        try
          let () = visitor#visit_ty () ty in
          false
        with Utils.Found -> true
      in

      let root_shared (av : tavalue) =
        match av.ty with
        | TRef (RVar (Free rid), referent, RShared)
          when RegionId.Set.mem rid owned && not (mentions_owned referent) ->
            (
              match av.value with
              | ABorrow (ASharedBorrow (PNone, _, _)) -> true
              | ALoan (ASharedLoan (PNone, _, payload, child)) ->
                  (match child.value with AIgnored _ -> true | _ -> false)
                  && not (mentions_owned payload.ty)
                  && not
                       (ValuesUtils.value_has_loans_or_borrows
                          (Some span) ctx.type_ctx.type_infos payload.value)
              | _ -> false
            )
        | _ -> false
      in

      if
        candidate abs
        && RegionId.Set.is_empty (RegionId.Set.inter owned source_regions)
        && List.for_all root_shared abs.avalues
      then
        let external_refs =
          object (self)
            inherit [_] iter_env as super
            method! visit_abs () other =
              if other.abs_id <> abs.abs_id then super#visit_abs () other
            method! visit_region_id () rid =
              if RegionId.Set.mem rid owned then raise Utils.Found
            method! visit_mvalue () value = self#visit_tvalue () value
          end
        in

        let continuation_refs =
          object (self)
            inherit [_] iter_abs
            method! visit_tavalue () _ = ()
            method! visit_ty () ty =
              if mentions_owned ty then raise Utils.Found
            method! visit_mvalue () value = self#visit_tvalue () value
          end
        in

        try
          let () = external_refs#visit_env () ctx.env in
          let () = continuation_refs#visit_abs () abs in
          let canonical = RegionId.Set.choose owned in
          let r_subst rid =
            if RegionId.Set.mem rid owned then canonical else rid
          in

          let normalized =
            Substitute.abs_subst_ids
              { Substitute.empty_id_subst with r_subst }
              abs
          in
          let () = Invariants.opt_type_check_abs span ctx normalized in
          replacements := AbsId.Map.add abs.abs_id normalized !replacements
        with Utils.Found -> ()
    in

    let () =
      List.iter
        (function EAbs abs -> normalize abs | EBinding _ | EFrame -> ())
        ctx.env
    in
    if AbsId.Map.is_empty !replacements then ctx
    else
      let env =
        List.map
          (function
            | EAbs abs as entry ->
                (match AbsId.Map.find_opt abs.abs_id !replacements with
                | Some normalized -> EAbs normalized
                | None -> entry)
            | entry -> entry)
          ctx.env
      in
      { ctx with env }

(** Information about the way contexts were joined *)
type join_info = {
  joined_ctx : eval_ctx;  (** The result of the join *)
  symbolic_to_value : (tvalue * tvalue) SymbolicValueId.Map.t;
      (** Map from fresh symbolic value to the values coming from the left and
          right contexts *)
(*
```ocaml
*)
  symbolic_to_value_metadata : region_metadata_bindings;
      (** Authenticated metadata for the registered predecessors. *)
(*
```
*)
  fixed_abs_ids : AbsId.Set.t;
      (** The abstractions the join kept unchanged (see
          {!compute_fixed_abs_ids}) *)
}

type join_info_or_update = (join_info, updt_env_kind) result

(** A small utility.

    Remark: we use projection markers, meaning we compute maps from/to pairs of
    (projection marker, borrow/loan id). This allows us to use this utility
    during a reduce phase (when we simplify the environment and all markers
    should be [PNone]) as well as during a collapse (where we actually have
    markers because we performed a join and are progressively transforming the
    environment to get rid of those markers). *)
type abs_borrows_loans_maps = {
  abs_ids : AbsId.id list;
  abs_to_borrows : MarkedUniqueBorrowId.Set.t AbsId.Map.t;
  abs_to_non_unique_borrows : MarkedBorrowId.Set.t AbsId.Map.t;
  abs_to_loans : MarkedLoanId.Set.t AbsId.Map.t;
  borrow_to_abs : AbsId.Set.t MarkedUniqueBorrowId.Map.t;
  non_unique_borrow_to_abs : AbsId.Set.t MarkedBorrowId.Map.t;
      (** A map from a non unique borrow id (in case of shared borrows) to the
          set of region abstractions refering to this borrow *)
  loan_to_abs : AbsId.Set.t MarkedLoanId.Map.t;
  abs_to_borrow_projs : MarkedNormSymbProj.Set.t AbsId.Map.t;
  abs_to_loan_projs : MarkedNormSymbProj.Set.t AbsId.Map.t;
  borrow_proj_to_abs : AbsId.Set.t MarkedNormSymbProj.Map.t;
  loan_proj_to_abs : AbsId.Set.t MarkedNormSymbProj.Map.t;
}

type tvalue_matcher = tvalue -> tvalue -> tvalue

let abs_borrows_loans_maps_to_string (_ctx : eval_ctx)
    (m : abs_borrows_loans_maps) : string =
  let {
    abs_ids;
    abs_to_borrows;
    abs_to_non_unique_borrows;
    abs_to_loans;
    borrow_to_abs;
    non_unique_borrow_to_abs;
    loan_to_abs;
    abs_to_borrow_projs;
    abs_to_loan_projs;
    borrow_proj_to_abs;
    loan_proj_to_abs;
  } =
    m
  in
  "{\n  abs_ids: "
  ^ Print.list_to_string AbsId.to_string abs_ids
  ^ ",\n  abs_to_borrows: "
  ^ AbsId.Map.to_string None
      (MarkedUniqueBorrowId.Set.to_string None)
      abs_to_borrows
  ^ ",\n  abs_to_non_unique_borrows: "
  ^ AbsId.Map.to_string None
      (MarkedBorrowId.Set.to_string None)
      abs_to_non_unique_borrows
  ^ ",\n  abs_to_loans: "
  ^ AbsId.Map.to_string None (MarkedLoanId.Set.to_string None) abs_to_loans
  ^ ",\n  borrow_to_abs: "
  ^ MarkedUniqueBorrowId.Map.to_string None (AbsId.Set.to_string None)
      borrow_to_abs
  ^ ",\n  non_unique_borrow_to_abs: "
  ^ MarkedBorrowId.Map.to_string None (AbsId.Set.to_string None)
      non_unique_borrow_to_abs
  ^ ",\n  loan_to_abs: "
  ^ MarkedLoanId.Map.to_string None (AbsId.Set.to_string None) loan_to_abs
  (* TOOD: improve printing of those: *)
  ^ ",\n  abs_to_borrow_projs: "
  ^ AbsId.Map.to_string None
      (MarkedNormSymbProj.Set.to_string None)
      abs_to_borrow_projs
  ^ ",\n  abs_to_loan_projs: "
  ^ AbsId.Map.to_string None
      (MarkedNormSymbProj.Set.to_string None)
      abs_to_loan_projs
  ^ ",\n  borrow_proj_to_abs: "
  ^ MarkedNormSymbProj.Map.to_string None (AbsId.Set.to_string None)
      borrow_proj_to_abs
  ^ ",\n  loan_proj_to_abs: "
  ^ MarkedNormSymbProj.Map.to_string None (AbsId.Set.to_string None)
      loan_proj_to_abs
  ^ "\n}"

(** See {!module:Aeneas.InterpLoopsMatchCtxs.MakeMatcher} and [Matcher].

    This module contains primitive match functions to instantiate the generic
    {!module:Aeneas.InterpLoopsMatchCtxs.MakeMatcher} functor.

    Remark: all the functions receive as input the left context and the right
    context. This is useful for printing, lookups, and also in order to check
    the ended regions. *)
module type PrimMatcher = sig
  val span : Meta.span

  (** Should we fail hard or make errors recoverable? *)
  val recover : bool

  val match_etys : eval_ctx -> eval_ctx -> ety -> ety -> ety
  val match_rtys : eval_ctx -> eval_ctx -> rty -> rty -> rty

  (** The input primitive values are not equal *)
  val match_distinct_literals :
    tvalue_matcher ->
    eval_ctx ->
    eval_ctx ->
    ety ->
    literal ->
    literal ->
    tvalue

  (** The input ADTs don't have the same variant *)
  val match_distinct_adts :
    tvalue_matcher ->
    eval_ctx ->
    eval_ctx ->
    ety ->
    ety ->
    adt_value ->
    ety ->
    adt_value ->
    tvalue

  (** The meta-value is the result of a match. *)
  val match_shared_borrows :
    tvalue_matcher ->
    eval_ctx ->
    eval_ctx ->
    ety ->
    borrow_id ->
    shared_borrow_id ->
    borrow_id ->
    shared_borrow_id ->
    borrow_id * shared_borrow_id

  (** The input parameters are:
      - [match_values]
      - [ty]
      - [bid0]: first borrow id
      - [bv0]: first borrowed value
      - [bid1]
      - [bv1]
      - [bv]: the result of matching [bv0] with [bv1] *)
  val match_mut_borrows :
    tvalue_matcher ->
    eval_ctx ->
    eval_ctx ->
    ety ->
    borrow_id ->
    tvalue ->
    borrow_id ->
    tvalue ->
    tvalue ->
    borrow_id * tvalue

  (** Match two mutable borrows with distinct ids whose borrowed values hold
      distinct mutable borrows (or distinct symbolic values holding mutable
      borrows), i.e., borrows of the regions nested in the region of the outer
      borrows (see {!InterpMatchCtxs.distinct_nested_mut_borrows}). The input
      parameters are:
      - [match_values]
      - [ty]
      - [bid0]: first borrow id
      - [bv0]: first borrowed value
      - [bid1]
      - [bv1]

      Returns the matched value. *)
  val match_distinct_nested_mut_borrows :
    tvalue_matcher ->
    eval_ctx ->
    eval_ctx ->
    ety ->
    borrow_id ->
    tvalue ->
    borrow_id ->
    tvalue ->
    tvalue

  (** Parameters:
      - [match_values]
      - [ctx0]
      - [ctx1]
      - [ty]
      - [id0]
      - [id1]
      - [v0]: the original payload of the left loan
      - [v1]: the original payload of the right loan
  *)
  val match_shared_loans :
    tvalue_matcher ->
    eval_ctx ->
    eval_ctx ->
    ety ->
    loan_id ->
    loan_id ->
    tvalue ->
    tvalue ->
    tvalue

  (** Parameters:
      - [match_values]
      - [ctx0]
      - [ctx1]
      - [loan_is_left]
      - [loan_id]
      - [shared_value]
      - [other_value] *)
  val match_shared_loan_with_other :
    tvalue_matcher ->
    eval_ctx ->
    eval_ctx ->
    loan_is_left:bool ->
    ty ->
    loan_id ->
    tvalue ->
    tvalue ->
    tvalue

  (** Parameters:
      - [match_values]
      - [ctx0]
      - [ctx1]
      - [loan_is_left]
      - [loan_id]
      - [other_value] *)
  val match_mut_loan_with_other :
    tvalue_matcher ->
    eval_ctx ->
    eval_ctx ->
    loan_is_left:bool ->
    ty ->
    loan_id ->
    tvalue ->
    tvalue

  val match_mut_loans :
    tvalue_matcher ->
    eval_ctx ->
    eval_ctx ->
    ety ->
    loan_id ->
    loan_id ->
    tvalue

  (** The result may be bottom when an input symbolic value has ended borrows.
  *)
  val match_symbolic_values :
    tvalue_matcher ->
    eval_ctx ->
    eval_ctx ->
    symbolic_value ->
    symbolic_value ->
    tvalue

  (** Match a symbolic value with a value which is not symbolic.

      If the boolean is [true], it means the symbolic value comes from the
      *left* environment. Otherwise it comes from the right environment (it is
      important when throwing exceptions, for instance when we need to end loans
      in one of the two environments). *)
  val match_symbolic_with_other :
    tvalue_matcher ->
    eval_ctx ->
    eval_ctx ->
    symbolic_is_left:bool ->
    symbolic_value ->
    tvalue ->
    tvalue

  (** Match a bottom value with a value which is not bottom.

      If the boolean is [true], it means the bottom value comes from the *left*
      environment. Otherwise it comes from the right environment (it is
      important when throwing exceptions, for instance when we need to end loans
      in one of the two environments). *)
  val match_bottom_with_other :
    tvalue_matcher ->
    eval_ctx ->
    eval_ctx ->
    bottom_is_left:bool ->
    tvalue ->
    tvalue

  (** The input ADTs don't have the same variant *)
  val match_distinct_aadts :
    tvalue_matcher ->
    eval_ctx ->
    eval_ctx ->
    rty ->
    adt_avalue ->
    rty ->
    adt_avalue ->
    rty ->
    tavalue

  (** Parameters:
      - [match_values]
      - [ctx0]
      - [ctx1]
      - [ty0]
      - [pm0]
      - [bid0]
      - [ty1]
      - [pm1]
      - [bid1]
      - [ty]: result of matching ty0 and ty1 *)
  val match_ashared_borrows :
    tvalue_matcher ->
    eval_ctx ->
    eval_ctx ->
    rty ->
    proj_marker ->
    borrow_id ->
    shared_borrow_id ->
    rty ->
    proj_marker ->
    borrow_id ->
    shared_borrow_id ->
    rty ->
    tavalue

  (** Parameters:
      - [match_values]
      - [ctx0]
      - [ctx1]
      - [ty0]
      - [pm0]
      - [bid0]
      - [av0]
      - [ty1]
      - [pm1]
      - [bid1]
      - [av1]
      - [ty]: result of matching ty0 and ty1
      - [av]: result of matching av0 and av1 *)
  val match_amut_borrows :
    tvalue_matcher ->
    eval_ctx ->
    eval_ctx ->
    rty ->
    proj_marker ->
    borrow_id ->
    tavalue ->
    rty ->
    proj_marker ->
    borrow_id ->
    tavalue ->
    rty ->
    tavalue ->
    tavalue

  (** Parameters:
      - [match_values]
      - [ctx0]
      - [ctx1]
      - [ty0]
      - [pm0]
      - [ids0]
      - [v0]
      - [av0]
      - [ty1]
      - [pm1]
      - [ids1]
      - [v1]
      - [av1]
      - [ty]: result of matching ty0 and ty1
      - [v]: result of matching v0 and v1
      - [av]: result of matching av0 and av1 *)
  val match_ashared_loans :
    tvalue_matcher ->
    eval_ctx ->
    eval_ctx ->
    rty ->
    proj_marker ->
    loan_id ->
    tvalue ->
    tavalue ->
    rty ->
    proj_marker ->
    loan_id ->
    tvalue ->
    tavalue ->
    rty ->
    tvalue ->
    tavalue ->
    tavalue

  (** Parameters:
      - [match_values]
      - [ctx0]
      - [ctx1]
      - [ty0]
      - [pm0]
      - [id0]
      - [av0]
      - [ty1]
      - [pm1]
      - [id1]
      - [av1]
      - [ty]: result of matching ty0 and ty1
      - [av]: result of matching av0 and av1 *)
  val match_amut_loans :
    tvalue_matcher ->
    eval_ctx ->
    eval_ctx ->
    rty ->
    proj_marker ->
    borrow_id ->
    tavalue ->
    rty ->
    proj_marker ->
    borrow_id ->
    tavalue ->
    rty ->
    tavalue ->
    tavalue

  (** Match the loans of a region the abstractions do not own (nested borrows:
      e.g., the loan of the outer region of a [&'a mut C<'b>] in the
      abstraction of ['b], which only lends the inner borrows of [C]).

      Parameters: as for [match_aignored_mut_borrow], [child] being the result
      of matching the children. *)
  val match_aignored_mut_loan :
    tvalue_matcher ->
    eval_ctx ->
    eval_ctx ->
    rty * proj_marker * borrow_id option * tavalue ->
    rty * proj_marker * borrow_id option * tavalue ->
    ty ->
    tavalue ->
    tavalue

  val match_aignored_mut_borrow :
    tvalue_matcher ->
    eval_ctx ->
    eval_ctx ->
    rty * borrow_id option * tavalue ->
    rty * borrow_id option * tavalue ->
    ty ->
    tavalue ->
    tavalue

  val match_aended_ignored_mut_borrow :
    tvalue_matcher ->
    eval_ctx ->
    eval_ctx ->
    rty * aended_ignored_mut_borrow ->
    rty * aended_ignored_mut_borrow ->
    ty ->
    tavalue ->
    tavalue ->
    tavalue

  (** Parameters:
      - [match_values]
      - [ctx0]
      - [ctx1]
      - [ty0]
      - [pm0]
      - [proj0]
      - [ty1]
      - [pm1]
      - [proj1]
      - [ty]: result of matching ty0 and ty1
      - [proj_ty]: result of matching proj_ty0 and proj_ty1 *)
  val match_aproj_borrows :
    tvalue_matcher ->
    eval_ctx ->
    eval_ctx ->
    rty ->
    proj_marker ->
    aproj_borrows ->
    rty ->
    proj_marker ->
    aproj_borrows ->
    rty ->
    rty ->
    tavalue

  (** Parameters:
      - [match_values]
      - [ctx0]
      - [ctx1]
      - [ty0]
      - [pm0]
      - [proj0]
      - [ty1]
      - [pm1]
      - [proj1]
      - [ty]: result of matching ty0 and ty1
      - [proj_ty]: result of matching proj_ty0 and proj_ty1 *)
  val match_aproj_loans :
    tvalue_matcher ->
    eval_ctx ->
    eval_ctx ->
    rty ->
    proj_marker ->
    aproj_loans ->
    rty ->
    proj_marker ->
    aproj_loans ->
    rty ->
    rty ->
    tavalue

  (** Match latent parent-return dependencies, not active loan owners. *)
  val match_apending_loans :
    proj_marker -> borrow_id -> proj_marker -> borrow_id -> rty -> tavalue

  (** Match complete symbolic dependencies with consistent root correspondence. *)
  val match_apending_symbolic_loans :
    eval_ctx ->
    eval_ctx ->
    proj_marker ->
    symbolic_pending_slot ->
    proj_marker ->
    symbolic_pending_slot ->
    rty ->
    rty ->
    tavalue

  (** Match two arbitrary avalues whose constructors don't match (this function
      is typically used to raise the proper exception). *)
  val match_avalues :
    tvalue_matcher -> eval_ctx -> eval_ctx -> tavalue -> tavalue -> tavalue
end

module type Matcher = sig
  val span : Meta.span

  (** Match two values.

      Rem.: this function raises exceptions of type
      {!Aeneas.InterpLoopsCore.ValueMatchFailure}. *)
  val match_tvalues : eval_ctx -> eval_ctx -> tvalue -> tvalue -> tvalue

  (** Match two avalues.

      [shared_shell_owners] supplies the effective current masks of matched
      logical abstractions. [None] retains ordinary structural region matching.
      Each shared shell must belong to its own supplied owner. Its outer region
      does not add a canonical correspondence. Other coordinates remain strict.

      Rem.: this function raises exceptions of type
      {!Aeneas.InterpLoopsCore.ValueMatchFailure}. *)
  val match_tavalues :
    shared_shell_owners:(region_id_set * region_id_set) option ->
    eval_ctx -> eval_ctx -> tavalue -> tavalue -> tavalue
end

(* 
```ocaml
*)
type region_match_diagnostic_pair = eval_ctx * eval_ctx * ty * ty

type region_match_diagnostic_origin =
  region_id * string * region_match_diagnostic_pair option
  * (symbolic_value * symbolic_value) option

type region_match_diagnostic = {
  type_pair : region_match_diagnostic_pair option ref;
  symbolic_pair : (symbolic_value * symbolic_value) option ref;
  origins : region_match_diagnostic_origin RegionId.Map.t ref;
  registrations : int ref;
  registration_location : string option ref;
  observe :
    string -> RegionId.InjSubst.t -> region_id -> region_id -> exn option -> unit;
}
(* 
```
*)

(** See {!module:InterpLoopsMatchCtxs.MakeCheckEquivMatcher} and
    {!module-type:InterpLoopsCore.CheckEquivMatcher}.

    Very annoying: functors only take modules as inputs... *)
module type MatchCheckEquivState = sig
  val span : Meta.span

  (** Should we fail hard or make errors recoverable? *)
  val recover : bool

  (** [true] if we check equivalence between contexts, [false] if we compute a
      mapping from a source context to a target context. *)
  val check_equiv : bool

  val rid_map : RegionId.InjSubst.t ref
  val region_diagnostic : region_match_diagnostic option


  (** Substitution for the loan and borrow ids - used only if [check_equiv] is
      true *)
  val blid_map : BorrowId.InjSubst.t ref

  (** Substitution for the borrow ids - used only if [check_equiv] is false *)
  val borrow_id_map : BorrowId.InjSubst.t ref

  (** Substitution for the loans ids - used only if [check_equiv] is false *)
  val loan_id_map : BorrowId.InjSubst.t ref

  val sid_map : SymbolicValueId.InjSubst.t ref
  val sid_to_value_map : tvalue SymbolicValueId.Map.t ref
  val aid_map : AbsId.InjSubst.t ref
  val lookup_shared_value_in_ctx0 : BorrowId.id -> tvalue
  val lookup_shared_value_in_ctx1 : BorrowId.id -> tvalue
end

module type CheckEquivMatcher = sig
  include PrimMatcher

  val match_aid : abs_id -> abs_id -> abs_id
  val match_aidl : abs_id list -> abs_id list -> abs_id list
  val match_aids : abs_id_set -> abs_id_set -> abs_id_set
  val match_rid : region_id -> region_id -> region_id
  val match_rids : region_id_set -> region_id_set -> region_id_set
  val match_borrow_id : borrow_id -> borrow_id -> borrow_id
  val match_borrow_idl : borrow_id list -> borrow_id list -> borrow_id list
  val match_borrow_ids : borrow_id_set -> borrow_id_set -> borrow_id_set
  val match_loan_id : loan_id -> loan_id -> loan_id
  val match_loan_idl : loan_id list -> loan_id list -> loan_id list
  val match_loan_ids : loan_id_set -> loan_id_set -> loan_id_set

  val match_symbolic_value_ids :
    symbolic_value_id -> symbolic_value_id -> symbolic_value_id
end

(** See {!InterpLoopsMatchCtxs.match_ctxs} *)
type ids_maps = {
  aid_map : AbsId.InjSubst.t;
  blid_map : BorrowId.InjSubst.t;
      (** Substitution for the loan and borrow ids *)
  borrow_id_map : BorrowId.InjSubst.t;  (** Substitution for the borrow ids *)
  loan_id_map : BorrowId.InjSubst.t;  (** Substitution for the loan ids *)
  rid_map : RegionId.InjSubst.t;
  sid_map : SymbolicValueId.InjSubst.t;
  sid_to_value_map : tvalue SymbolicValueId.Map.t;
}
[@@deriving show]

let ids_maps_to_string (ctx : eval_ctx) (m : ids_maps) : string =
  let {
    aid_map;
    blid_map;
    borrow_id_map;
    loan_id_map;
    rid_map;
    sid_map;
    sid_to_value_map;
  } =
    m
  in
  let indent = Some "    " in
  "{" ^ "\n  aid_map = "
  ^ AbsId.InjSubst.to_string indent aid_map
  ^ "\n  blid_map = "
  ^ BorrowId.InjSubst.to_string indent blid_map
  ^ "\n  borrow_id_map = "
  ^ BorrowId.InjSubst.to_string indent borrow_id_map
  ^ "\n  loan_id_map = "
  ^ BorrowId.InjSubst.to_string indent loan_id_map
  ^ "\n  rid_map = "
  ^ RegionId.InjSubst.to_string indent rid_map
  ^ "\n  sid_map = "
  ^ SymbolicValueId.InjSubst.to_string indent sid_map
  ^ "\n  sid_to_value_map = "
  ^ SymbolicValueId.Map.to_string indent (tvalue_to_string ctx) sid_to_value_map
  ^ "\n}"

type borrow_loan_corresp = {
  borrow_to_loan_id_map : BorrowId.InjSubst.t;
  loan_to_borrow_id_map : BorrowId.InjSubst.t;
  borrow_to_loan_proj_map : SymbolicValueId.InjSubst.t;
  loan_to_borrow_proj_map : SymbolicValueId.InjSubst.t;
}
[@@deriving show]

(* Very annoying: functors only take modules as inputs... *)
module type MatchJoinState = sig
  (** The kind to use for the fresh abstractions *)
  val fresh_abs_kind : abs_kind

  (** Do the abstractions keep the level-1 outputs of their calls (see
      {!loop_level_outputs})? *)
  val loop_level_outputs : bool

  (** The abstractions introduced when performing the matches *)
  val nabs : abs list ref
  val metadata_bindings : region_metadata_bindings ref

  val span : Meta.span

  (** Whenever we create fresh abstractions, do we provide an abstraction
      expression or not? We do not need to compute abstraction expressions when
      computing fixed-points (but we need them for the synthesis). *)
  val with_abs_conts : bool

  (** Map from the fresh symbolic values to the values coming from the left and
      right environment and whose join led to the introduction of the symbolic
      value *)
  val symbolic_to_value : (tvalue * tvalue) SymbolicValueId.Map.t ref

  (** Resolve a shared payload on its input branch, including lenders which
      retained-payload reconciliation has transferred into fresh abstractions.
  *)
  val lookup_shared_value : is_left:bool -> eval_ctx -> borrow_id -> tvalue

  (** If [true] we throw a special kind of exception when encountering *some*
      errors to make them recoverable (and we do not save errors). *)
  val recover : bool
end

(** Split an environment between some old abstractions and dummy values and the
    new abstractions and dummy values.

    Returns: (fixed, new abs, new dummies) *)
let ctx_split (span : Meta.span) (old_aids : AbsId.Set.t)
    (old_dids : DummyVarId.Set.t) (ctx : eval_ctx) :
    env * abs list * tvalue list =
  let is_fresh_did (id : DummyVarId.id) : bool =
    not (DummyVarId.Set.mem id old_dids)
  in
  let is_fresh_abs_id (id : AbsId.id) : bool =
    not (AbsId.Set.mem id old_aids)
  in
  (* Filter the new abstractions and dummy variables (there shouldn't be any new dummy variable
     though) in the target context *)
  let is_fresh (ee : env_elem) : bool =
    match ee with
    | EBinding (BVar _, _) | EFrame -> false
    | EBinding (BDummy bv, _) -> is_fresh_did bv
    | EAbs abs -> is_fresh_abs_id abs.abs_id
  in
  let new_eel, filt_env = List.partition is_fresh ctx.env in
  let is_abs ee =
    match ee with
    | EAbs _ -> true
    | _ -> false
  in
  let new_absl, new_dummyl = List.partition is_abs new_eel in
  let new_absl =
    List.map
      (fun ee ->
        match ee with
        | EAbs abs -> abs
        | _ -> [%craise] span "Unreachable")
      new_absl
  in
  let new_dummyl =
    List.map
      (fun ee ->
        match ee with
        | EBinding (BDummy _, v) -> v
        | _ -> [%craise] span "Unreachable")
      new_dummyl
  in
  (filt_env, new_absl, new_dummyl)

let ids_sets_empty_borrows_loans (ids : ids_sets) : ids_sets =
  let {
    aids;
    blids = _;
    borrow_ids = _;
    loan_ids = _;
    shared_loans_to_values = _;
    unique_borrow_ids = _;
    shared_borrow_ids = _;
    non_unique_shared_borrow_ids = _;
    dids;
    rids;
    sids;
  } =
    ids
  in
  let empty = BorrowId.Set.empty in
  let ids =
    {
      aids;
      blids = empty;
      borrow_ids = empty;
      unique_borrow_ids = UniqueBorrowIdSet.empty;
      shared_borrow_ids = SharedBorrowId.Set.empty;
      non_unique_shared_borrow_ids = BorrowId.Set.empty;
      shared_loans_to_values = BorrowId.Map.empty;
      loan_ids = empty;
      dids;
      rids;
      sids;
    }
  in
  ids

(** Small utility: add a projection marker to a typed avalue. This can be used
    in combination with List.map to add markers to an entire abstraction *)
let tavalue_add_marker (span : Meta.span) (ctx : eval_ctx) (pm : proj_marker)
    (av : tavalue) : tavalue =
  let obj =
    object (self)
      inherit [_] map_tavalue as super

      method! visit_borrow_content in_shared bc =
        match (in_shared, bc) with
        | true, VSharedBorrow _ -> super#visit_borrow_content in_shared bc
        | true, VMutBorrow _ ->
            (* A shared payload may hold a mutable borrow (e.g., the field
               [native : &'n mut T] of the payload of [&C<'n>], or of a copy of
               it, see [InterpJoin.reborrow_ashared_loans]): it is only read
               through the loan, and its loan is in another abstraction. *)
            super#visit_borrow_content in_shared bc
        | _ -> [%craise] span "Unexpected borrow outside a shared payload"

      method! visit_loan_content in_shared lc =
        match (in_shared, lc) with
        | true, VSharedLoan _ -> super#visit_loan_content in_shared lc
        | _ -> [%craise] span "Unexpected loan outside a shared payload"

      method! visit_proj_marker _ pm =
        (* We do this to make sure we don't miss a projection marker *)
        [%sanity_check] span (pm <> PNone);
        pm

      method! visit_ASymbolic _ pm0 aproj =
        [%sanity_check] span (pm0 = PNone);
        ASymbolic (pm, aproj)

      method! visit_symbolic_value in_shared sv =
        (* Payload ownership inherits its enclosing shared loan's marker;
           separate region projectors retain its nested symbolic ownership. *)
        [%sanity_check] span
          (in_shared || not (symbolic_value_has_borrows (Some span) ctx sv));
        sv

      method! visit_aloan_content env lc =
        match lc with
        | AMutLoan (pm0, bid, av) ->
            [%sanity_check] span (pm0 = PNone);
            super#visit_aloan_content env (AMutLoan (pm, bid, av))
        | ASharedLoan (pm0, bid, value, child) ->
            [%sanity_check] span (pm0 = PNone);
            ASharedLoan
              ( pm,
                bid,
                self#visit_tvalue true value,
                self#visit_tavalue env child )
        | AEndedSharedLoan (pm0, value, child) ->
            [%sanity_check] span (pm0 = PNone);
            AEndedSharedLoan
              (pm, self#visit_tvalue true value, self#visit_tavalue env child)
        | AIgnoredMutLoan (pm0, None, child) ->
            [%sanity_check] span (pm0 = PNone);
            AIgnoredMutLoan (PNone, None, self#visit_tavalue env child)
        | AIgnoredMutLoan (pm0, (Some _ as bid), child) ->
            [%sanity_check] span (pm0 = PNone);
            super#visit_aloan_content env (AIgnoredMutLoan (pm, bid, child))
        | AIgnoredSharedLoan _
        | AEndedMutLoan _
        | AEndedIgnoredMutLoan _ ->
            (* These carriers own no outer marker. Their live children do;
               metadata and dependency ids remain unchanged. *)
            super#visit_aloan_content env lc

      method! visit_aborrow_content env bc =
        match bc with
        | AMutBorrow (pm0, bid, av) ->
            [%sanity_check] span (pm0 = PNone);
            super#visit_aborrow_content env (AMutBorrow (pm, bid, av))
        | ASharedBorrow (pm0, bid, sid) ->
            [%sanity_check] span (pm0 = PNone);
            super#visit_aborrow_content env (ASharedBorrow (pm, bid, sid))
        | AProjSharedBorrow (pm0, borrows) ->
            [%sanity_check] span (pm0 = PNone);
            super#visit_aborrow_content env (AProjSharedBorrow (pm, borrows))
        | AIgnoredMutBorrow _
        | AEndedIgnoredMutBorrow _
        | AEndedMutBorrow _
        | AEndedSharedBorrow -> super#visit_aborrow_content env bc
    end
  in
  obj#visit_tavalue false av

(** Small utility: add a projection marker to a typed evalue. This can be used
    in combination with List.map to add markers to an entire abstraction *)
let tevalue_add_marker (span : Meta.span) (ctx : eval_ctx) (pm : proj_marker)
    (ev : tevalue) : tevalue =
  let obj =
    object (self)
      inherit [_] map_tavalue as super
      method! visit_borrow_content _ _ = [%craise] span "Unexpected borrow"
      method! visit_loan_content _ _ = [%craise] span "Unexpected loan"

      method! visit_proj_marker _ pm =
        (* We do this to make sure we don't miss a projection marker *)
        [%sanity_check] span (pm <> PNone);
        pm

      method! visit_tevalue _ ev = super#visit_tevalue ev.ty ev

      (*
```ocaml
      *)
      method! visit_ECallEndpoints env witnesses body =
        let parent_carriers =
          List.map
            (fun (branch, parent, mask, regions, producer) ->
              [%sanity_check] span (branch = PNone);
              (pm, parent, mask, regions, self#visit_tevalue env producer))
            witnesses.parent_carriers
        in
        ECallEndpoints ({ witnesses with parent_carriers }, self#visit_tevalue env body)
      (*
```
      *)
      method! visit_ESymbolic _ pm0 aproj =
        [%sanity_check] span (pm0 = PNone);
        ESymbolic (pm, aproj)

      method! visit_symbolic_value _ sv =
        (* Symbolic values can appear in shared values *)
        [%sanity_check] span
          (not (symbolic_value_has_borrows (Some span) ctx sv));
        sv

      method! visit_eloan_content ty lc =
        match lc with
        | EMutLoan (pm0, bid, av) ->
            [%sanity_check] span (pm0 = PNone);
            super#visit_eloan_content ty (EMutLoan (pm, bid, av))
        | EIgnoredMutLoan (pm0, None, child) ->
            [%sanity_check] span (pm0 = PNone);
            EIgnoredMutLoan (PNone, None, self#visit_tevalue ty child)
        | EIgnoredMutLoan (pm0, (Some _ as bid), child) ->
            [%sanity_check] span (pm0 = PNone);
            super#visit_eloan_content ty (EIgnoredMutLoan (pm, bid, child))
        | EEndedMutLoan _ | EEndedIgnoredMutLoan _ ->
            super#visit_eloan_content ty lc

      method! visit_eborrow_content env bc =
        match bc with
        | EMutBorrow (pm0, bid, av) ->
            [%sanity_check] span (pm0 = PNone);
            super#visit_eborrow_content env (EMutBorrow (pm, bid, av))
        | EIgnoredMutBorrow _ | EEndedIgnoredMutBorrow _ | EEndedMutBorrow _ ->
            super#visit_eborrow_content env bc
    end
  in
  obj#visit_tevalue ev.ty ev

(** Small utility: add a projection marker to an abs continuation. *)
let abs_cont_add_marker (span : Meta.span) (ctx : eval_ctx) (pm : proj_marker)
    (cont : abs_cont) : abs_cont =
  let add_marker = Option.map (tevalue_add_marker span ctx pm) in
  let { output; input } = cont in
  { output = add_marker output; input = add_marker input }

(** Nested borrows: do the joins and matches of a context keep the values given
    back to the returned references of the calls with a staged backward
    function in the abstractions of the calls, as level-1 outputs (see
    {!InterpAbs.normalize_abs_for_join})? They do in the contexts of a loop:
    the computation of its fixed point ([fresh_abs_kind] is [Loop]), the
    matches of the loop synthesis ([loop], whose fresh abstractions are
    [WithCont]), and the join (and its matches) of the contexts of a statement
    which go to the same [continue] or [break] ([loop], see
    [InterpStatements.join_contexts_by_destination]); the join of the branches
    of a statement which fall through, and its match, keep the snapshot of
    these values. *)
let loop_level_outputs ~(loop : bool) (fresh_abs_kind : abs_kind) : bool =
  loop
  ||
  match fresh_abs_kind with
  | Loop _ -> true
  | _ -> false

(** Normalize an abstraction and mark its residual and independent captures
    (see {!loop_level_outputs} for [loop_level_outputs]). *)
let abs_add_marker (span : Meta.span) ~(loop_level_outputs : bool)
    (ctx : eval_ctx) (pm : proj_marker) (abs : abs) : abs list =
  List.map
    (fun abs ->
      {
        abs with
        avalues = List.map (tavalue_add_marker span ctx pm) abs.avalues;
        cont = Option.map (abs_cont_add_marker span ctx pm) abs.cont;
      })
    (InterpAbs.normalize_abs_for_join ~loop_level_outputs span ctx abs)

(** Whether a region group of a function call has a staged backward function
    ([SymbolicToPureTypes.back_sig_stage_map], see [Pure.back_sg_info.early]).
    [call] are the abstractions of the call, as introduced by
    [eval_function_call_symbolic_from_inst_sig]: their values are the
    projections of the inputs and of the output, whose types are those of the
    instantiated signature, and their regions are those of their groups. *)
let fun_call_is_staged (ctx : eval_ctx) (call : abs list) : bool =
  (* The stage map is a property of the types: it only reads [type_ctx] *)
  let decls_ctx : decls_ctx =
    {
      crate = ctx.crate;
      graph_of_uses =
        {
          graph = LlbcAstUtils.AnyDeclIdMap.empty;
          locals = LlbcAstUtils.AnyDeclIdSet.empty;
        };
      type_ctx = ctx.type_ctx;
      fun_ctx = ctx.fun_ctx;
      global_decls_to_extract = GlobalDeclId.Map.empty;
      trait_decls_to_extract = TraitDeclId.Map.empty;
      trait_impls_to_extract = TraitImplId.Map.empty;
    }
  in
  let groups =
    List.filter_map
      (fun (abs : abs) ->
        match abs.kind with
        | FunCall (_, gid) -> Some (gid, abs)
        | _ -> None)
      call
  in
  let group_of_region =
    List.fold_left
      (fun map (gid, (abs : abs)) ->
        RegionId.Set.fold
          (fun rid map -> RegionId.Map.add rid gid map)
          abs.regions.owned map)
      RegionId.Map.empty groups
  in
  (* The regions which are not regions of the call (e.g., ['static]) are in no
     group of the call *)
  let get_region_group (r : region) : region_group_id =
    match r with
    | RVar (Free rid) -> (
        match RegionId.Map.find_opt rid group_of_region with
        | Some g -> g
        | None -> RegionGroupId.of_int (-1))
    | _ -> RegionGroupId.of_int (-1)
  in
  match groups with
  | [] -> false
  | (_, abs) :: _ -> (
      match List.rev_map (fun (v : tavalue) -> v.ty) abs.avalues with
      | [] -> false
      | output :: rev_inputs ->
          let inputs = List.rev rev_inputs in
          List.exists
            (fun (gid, _) ->
              SymbolicToPureTypes.back_sig_is_nested None decls_ctx
                get_region_group gid inputs output
              && SymbolicToPureTypes.back_sig_stage_map None decls_ctx
                   get_region_group gid inputs output
                 <> [])
            groups)

(** Nested borrows: the abstractions of the function calls of [ctx] which have
    a staged backward function (see [fun_call_is_staged]), together with the
    abstractions they depend on, transitively: the abstractions owning the
    regions which appear in them (e.g., in the type of a symbolic value they
    received), those holding the other side of their loans and borrows, and
    the other abstractions of the same calls. Provided [untouched] (the
    abstractions which a join keeps unchanged) holds all of those. The
    abstractions holding projectors over the same symbolic values (e.g., the
    call which consumed the reference a staged call returned, or the loop
    abstraction of an enclosing loop which lends the reborrowed value) are
    added as well when they are untouched. Returns the endable ones.

    A join which merges or normalizes some of these abstractions makes them
    differ from their versions in the joined contexts: the join (or a loop)
    then merges them into a fresh join (or loop) abstraction whose continuation
    holds the staged backward function of the call before its earlier stages
    are applied (see [SymbolicToPureAbs.einput_to_texpr]). *)
let untouched_staged_call_abs_ids (ctx : eval_ctx) (untouched : AbsId.Set.t) :
    AbsId.Set.t =
  let abs0 = ctx_get_abs ctx in
  let calls =
    AbsId.Map.fold
      (fun _ (abs : abs) calls ->
        match abs.kind with
        | FunCall (call_id, _) ->
            FunCallId.Map.update call_id
              (fun call -> Some (abs :: Option.value call ~default:[]))
              calls
        | _ -> calls)
      abs0 FunCallId.Map.empty
  in
  (* The regions, the loan (and borrow) identifiers and the symbolic values
     which appear in an abstraction. The regions include those of the
     meta-values it retains; the identifiers and the symbolic values do not
     (the loans of a meta-value are not live). *)
  let contents (abs : abs) :
      RegionId.Set.t * BorrowId.Set.t * SymbolicValueId.Set.t =
    let rids = ref RegionId.Set.empty in
    let ids = ref BorrowId.Set.empty in
    let svs = ref SymbolicValueId.Set.empty in
    let visitor =
      object (self)
        inherit [_] iter_abs
        method! visit_region_id _ rid = rids := RegionId.Set.add rid !rids

        method! visit_borrow_id in_meta id =
          if not in_meta then ids := BorrowId.Set.add id !ids

        method! visit_loan_id in_meta id =
          if not in_meta then ids := BorrowId.Set.add id !ids

        method! visit_symbolic_value_id in_meta id =
          if not in_meta then svs := SymbolicValueId.Set.add id !svs

        method! visit_mvalue _ v = self#visit_tvalue true v
      end
    in
    visitor#visit_abs false { abs with cont = None };
    (!rids, !ids, !svs)
  in
  let contents = AbsId.Map.map contents abs0 in
  let region_owners =
    AbsId.Map.fold
      (fun _ (abs : abs) owners ->
        RegionId.Set.fold
          (fun rid owners -> RegionId.Map.add rid abs.abs_id owners)
          abs.regions.owned owners)
      abs0 RegionId.Map.empty
  in
  (* The abstractions in which each element of [get] appears *)
  let holders get =
    let map =
      AbsId.Map.fold
        (fun abs_id c map ->
          List.fold_left
            (fun map x ->
              let h = Option.value (Hashtbl.find_opt map x) ~default:[] in
              Hashtbl.replace map x (abs_id :: h);
              map)
            map (get c))
        contents (Hashtbl.create 64)
    in
    fun x ->
      AbsId.Set.of_list (Option.value (Hashtbl.find_opt map x) ~default:[])
  in
  let id_holders = holders (fun (_, ids, _) -> BorrowId.Set.elements ids) in
  let sv_holders =
    holders (fun (_, _, svs) -> SymbolicValueId.Set.elements svs)
  in
  let dependencies (abs : abs) : AbsId.Set.t * AbsId.Set.t =
    let rids, ids, svs = AbsId.Map.find abs.abs_id contents in
    let deps =
      RegionId.Set.fold
        (fun rid deps ->
          match RegionId.Map.find_opt rid region_owners with
          | Some id -> AbsId.Set.add id deps
          | None -> deps)
        rids AbsId.Set.empty
    in
    let deps =
      BorrowId.Set.fold
        (fun id deps -> AbsId.Set.union (id_holders id) deps)
        ids deps
    in
    let deps =
      match abs.kind with
      | FunCall (call_id, _) ->
          List.fold_left
            (fun deps (abs : abs) -> AbsId.Set.add abs.abs_id deps)
            deps
            (FunCallId.Map.find call_id calls)
      | _ -> deps
    in
    let observers =
      SymbolicValueId.Set.fold
        (fun sv obs -> AbsId.Set.union (sv_holders sv) obs)
        svs AbsId.Set.empty
    in
    ( AbsId.Set.remove abs.abs_id deps,
      AbsId.Set.diff (AbsId.Set.remove abs.abs_id observers) deps )
  in
  (* The closure of a set of endable abstractions, if their dependencies are
     all untouched (the observers are added when they are) *)
  let rec close (ids : AbsId.Set.t) (todo : abs_id list) : AbsId.Set.t option =
    match todo with
    | [] -> Some ids
    | id :: todo ->
        let abs = AbsId.Map.find id abs0 in
        if not abs.can_end then close ids todo
        else if not (AbsId.Set.mem id untouched) then None
        else
          let deps, observers = dependencies abs in
          let observers =
            AbsId.Set.filter
              (fun id ->
                let abs = AbsId.Map.find id abs0 in
                (not abs.can_end) || AbsId.Set.mem id untouched)
              observers
          in
          let next = AbsId.Set.diff (AbsId.Set.union deps observers) ids in
          close (AbsId.Set.union next ids) (AbsId.Set.elements next @ todo)
  in
  let staged =
    FunCallId.Map.fold
      (fun _ (call : abs list) staged ->
        let ids = List.map (fun (abs : abs) -> abs.abs_id) call in
        if
          not
            (List.for_all
               (fun (abs : abs) ->
                 (not abs.can_end) || AbsId.Set.mem abs.abs_id untouched)
               call)
        then staged
        else if not (fun_call_is_staged ctx call) then staged
        else
          match close (AbsId.Set.of_list ids) ids with
          | Some ids -> AbsId.Set.union ids staged
          | None -> staged)
      calls AbsId.Set.empty
  in
  AbsId.Set.filter (fun id -> (AbsId.Map.find id abs0).can_end) staged

let compute_fixed_abs_ids (ctx0 : eval_ctx) (ctx1 : eval_ctx) : AbsId.Set.t =
  let aids0 = ctx_get_abs_ids ctx0 in
  let aids1 = ctx_get_abs_ids ctx1 in
  let abs0 = ctx_get_abs ctx0 in
  let abs1 = ctx_get_abs ctx1 in
  let abs_ids = AbsId.Set.inter aids0 aids1 in
  AbsId.Set.filter
    (fun aid ->
      let a0 = AbsId.Map.find aid abs0 in
      let a1 = AbsId.Map.find aid abs1 in
      (* We ignore the continuation expressions: when computing fixed points we
         might remove/add continuations while the presence/absence shouldn't
         have an impact on the way we match/unify contexts. *)
      { a0 with cont = None } = { a1 with cont = None })
    abs_ids
