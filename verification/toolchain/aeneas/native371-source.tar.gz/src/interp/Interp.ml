open Cps
open InterpUtils
open InterpProjectors
open InterpBorrows
open InterpStatements
open LlbcAstUtils
open Types
open TypesUtils
open Values
open ValuesUtils
open LlbcAst
open Contexts
open Errors
module SA = SymbolicAst

(** The local logger *)
let log = Logging.interp_log

(** Compute the type information for every *type definition* in a list of
    declarations. This type definition information is later used to easily
    compute the information of arbitrary types.

    Rem.: pay attention to the difference between type definitions and types!
    Rem.: this definition is in Interp.ml and not in TypesAnalysis.ml because
    otherwise we have cyclic dependencies. *)
let analyze_type_declarations (crate : crate)
    (decls : type_declaration_group list) : TypesAnalysis.type_infos =
  let open TypesAnalysis in
  List.fold_left
    (fun infos decl ->
      try
        [%recover_internal_errors_opt_span] None (fun () ->
            analyze_type_declaration_group None crate infos decl)
      with CFailure error ->
        let fmt_env : Print.fmt_env = Charon.Print.crate_to_fmt_env crate in
        let decls = Charon.GAstUtils.g_declaration_group_to_list decl in
        let decl_id_to_string (id : TypeDeclId.id) : string =
          match TypeDeclId.Map.find_opt id crate.type_decls with
          | None -> show_type_decl_id id
          | Some d ->
              Print.name_to_string fmt_env d.item_meta.name
              ^ " ("
              ^ span_to_string d.item_meta.span
              ^ ")"
        in
        let decls = List.map decl_id_to_string decls in
        let decls = String.concat "\n" decls in
        [%save_error_opt_span] error.span
          ("Encountered an error when analyzing the following type \
            declarations group:\n" ^ decls);
        infos)
    TypeDeclId.Map.empty decls

let compute_contexts (crate : crate) : decls_ctx =
  let crate_graph = Deps.compute_graph_of_uses crate in
  let type_decls_list, _, _, _, _, _ = split_declarations crate.declarations in
  let fmt_env : Print.fmt_env = Charon.Print.crate_to_fmt_env crate in

  (* Split the declaration groups between the declaration kinds (types, functions, etc.) *)
  let type_decls_groups, _, _, _, _, mixed_groups =
    split_declarations_to_group_maps crate.declarations
  in
  let mixed_groups =
    List.filter
      (fun group -> not (mixed_declaration_group_is_supported group))
      mixed_groups
  in
  (* Report unsupported mixed groups without rejecting Lean's native recursive
     function/implementation groups. *)
  (if mixed_groups <> [] then
     (* We detected mixed groups: print a nice error message *)
     let item_id_to_string (id : item_id) : string =
       let kind = item_id_to_kind_name id in
       let meta = LlbcAstUtils.crate_get_item_meta crate id in
       let s =
         match meta with
         | None -> show_item_id id
         | Some meta ->
             kind ^ "(" ^ span_to_string meta.span ^ "): "
             ^ Print.name_to_string fmt_env meta.name
       in
       "- " ^ s
     in
     let group_to_msg (i : int) (g : mixed_declaration_group) : string =
       let ids = g_declaration_group_to_list g in
       let decls = List.map item_id_to_string ids in
       (* If the definitions are external, add information about where they
          are (transitively) used in the local crate *)
       let local_uses = Deps.compute_local_uses crate_graph ids in
       let local_uses =
         List.map
           (fun (info : Deps.item_info) ->
             item_id_to_string info.id ^ ": " ^ span_to_string info.span)
           (Deps.ItemInfoSet.to_list local_uses)
       in
       let local_uses =
         if local_uses <> [] then
           "\n\n\
            The declarations in this group are (transitively) used at the \
            following location(s):\n"
           ^ String.concat "\n" local_uses
         else ""
       in
       "# Group "
       ^ string_of_int (i + 1)
       ^ ":\n" ^ String.concat "\n" decls ^ local_uses ^ "\n"
     in
     let msgs = List.mapi group_to_msg mixed_groups in
     let msgs = String.concat "\n\n" msgs in
     [%save_error_opt_span] None
       ("Detected groups of mixed mutually recursive definitions (such as a \
         type mutually recursive with a function, or a function mutually \
         recursive with a trait implementation):\n\n" ^ msgs));

  (* Compute the set of ids which appear in the declaration groups: only those
     should be extracted.

     Note that Charon includes extra definitions in the crate as they needed for
     pretty printing. The set of declarations to extract is given by the [declarations]
     field.
  *)
  let type_decl_ids = ref TypeDeclId.Set.empty in
  let fun_decl_ids = ref FunDeclId.Set.empty in
  let global_decl_ids = ref GlobalDeclId.Set.empty in
  let trait_decl_ids = ref TraitDeclId.Set.empty in
  let trait_impl_ids = ref TraitImplId.Set.empty in

  let visitor =
    object
      inherit [_] iter_crate

      method! visit_type_decl_id _ id =
        TypeDeclId.Set.add_in_place id type_decl_ids

      method! visit_fun_decl_id _ id =
        FunDeclId.Set.add_in_place id fun_decl_ids

      method! visit_global_decl_id _ id =
        GlobalDeclId.Set.add_in_place id global_decl_ids

      method! visit_trait_decl_id _ id =
        TraitDeclId.Set.add_in_place id trait_decl_ids

      method! visit_trait_impl_id _ id =
        TraitImplId.Set.add_in_place id trait_impl_ids
    end
  in
  List.iter (visitor#visit_declaration_group ()) crate.declarations;

  let type_decls = crate.type_decls in
  let to_extract =
    TypeDeclId.Map.filter
      (fun id _ -> TypeDeclId.Set.mem id !type_decl_ids)
      type_decls
  in
  let type_infos = analyze_type_declarations crate type_decls_list in
  let type_ctx = { type_decls_groups; type_decls; type_infos; to_extract } in

  let fun_decls = crate.fun_decls in
  let to_extract =
    FunDeclId.Map.filter
      (fun id _ -> FunDeclId.Set.mem id !fun_decl_ids)
      fun_decls
  in
  let fun_infos = FunsAnalysis.analyze_module crate fun_decls in
  let fun_ctx = { fun_decls; fun_infos; to_extract } in

  let global_decls_to_extract =
    GlobalDeclId.Map.filter
      (fun id _ -> GlobalDeclId.Set.mem id !global_decl_ids)
      crate.global_decls
  in

  let trait_decls_to_extract =
    TraitDeclId.Map.filter
      (fun id _ -> TraitDeclId.Set.mem id !trait_decl_ids)
      crate.trait_decls
  in

  let trait_impls_to_extract =
    TraitImplId.Map.filter
      (fun id _ -> TraitImplId.Set.mem id !trait_impl_ids)
      crate.trait_impls
  in

  {
    crate;
    graph_of_uses = crate_graph;
    type_ctx;
    fun_ctx;
    global_decls_to_extract;
    trait_decls_to_extract;
    trait_impls_to_extract;
  }

(** Instantiate a function signature for a symbolic execution.

    We return a new context because we compute and add the type normalization
    map in the same step. *)
let symbolic_instantiate_fun_sig (span : Meta.span) (ctx : eval_ctx)
    (sg : bound_fun_sig) (_kind : item_source) : eval_ctx * inst_fun_sig =
  let tr_self = UnknownTrait "symbolic_instantiate_fun_sig" in
  let generics =
    Substitute.generic_args_of_params_erase_regions (Some span)
      sg.item_binder_params
  in
  let inst_sg = instantiate_fun_sig (Some span) ctx generics tr_self sg in
  let region_groups =
    List.map (fun (g : region_var_group) -> g.id) inst_sg.regions_hierarchy
  in
  let ctx = { ctx with region_groups;
      metadata_bindings = TypesUtils.merge_metadata_bindings (Some span)
        ctx.metadata_bindings inst_sg.metadata_bindings } in
  (* Return *)
  (ctx, inst_sg)

(** Solve body annotations from the instantiated signature before execution.
    Assignments add static constraints, never new runtime bindings.
    Keep stored source regions until all producer and borrower constraints bind.
    Runtime erasure would remove the constructor output and session input relation. *)
(* ```ocaml *)
let instantiate_symbolic_body_annotations span (ctx : eval_ctx)
    (inst_sg : inst_fun_sig) (body : expr_body) : expr_body =
(* ``` *)

  let open Expressions in
  let bindings = Hashtbl.create 32 in
  let next_body_region = ref body.bound_body_regions in
  let callable_regions = ref [] in
  let collect_callable_regions =
    object
      inherit [_] iter_ty
      method! visit_RBody _ id =
        callable_regions := RBody id :: !callable_regions
    end
  in
(* ```ocaml *)
  let declarations_changed =
    List.fold_left
      (fun changed (param : region_param) ->
        let variable = Free param.index in
        let source = RVar variable in
        let instantiated = inst_sg.declaration_region_subst variable in
        let target =
          match instantiated with
          | RVar (Free execution) -> (
              match RegionId.Map.find_opt execution inst_sg.body_region_map with
              | Some transported when transported <> execution ->
                  RVar (Free transported)
              | None | Some _ -> instantiated)
          | _ -> instantiated
        in
        Hashtbl.add bindings source target;
        changed || target <> source)
      false inst_sg.declaration_regions
  in
  let declaration_binding_count = Hashtbl.length bindings in
  let rec resolve declaration region =
    match region with
    | RVar (Free _) when declaration -> (
        match Hashtbl.find_opt bindings region with
        | None -> region
        | Some target -> target)
(* ``` *)
    | RBody _ -> (
        match Hashtbl.find_opt bindings region with
        | None -> region
        | Some target -> resolve false target)
    | RStatic | RVar _ | RErased -> region
  in
(*
```ocaml
*)
  let unify incoming_left incoming_right =
    let left = resolve false incoming_left in
    let right = resolve false incoming_right in
(*
```
*)
    if left <> right then
      match (left, right) with
      | RErased, _ | _, RErased -> ()
      | RBody _, _ -> Hashtbl.add bindings left right
      | _, RBody _ -> Hashtbl.add bindings right left
(* ```ocaml *)
      | _ -> [%craise] span "Body annotations have incompatible concrete regions."
(* ``` *)

  in
(* ```ocaml *)
  let constrain right_declaration left_ty right_ty =
    List.iter
      (fun (left, right) ->
        unify (resolve true left) (resolve right_declaration right))
      (body_annotation_region_pairs span left_ty right_ty)
(* ``` *)

  in
  (* Assignments can shorten lifetimes through proved covariant positions.
     Mutable referents and unknown nominal parameters still need equality. *)
  let constrain_use source destination =
    let region covariant source destination =
      let source = resolve true source in
      let destination = resolve true destination in
      match covariant, source, destination with
(*
```ocaml
*)
      | true, RStatic, RVar (Free destination)
        when List.exists
          (fun (group : region_var_group) -> List.mem destination group.regions)
          inst_sg.regions_hierarchy -> ()
(*
```
*)

      | true, RVar (Free source), RVar (Free destination)
        when source <> destination ->
          let group region =
            List.find_opt
              (fun (group : region_var_group) -> List.mem region group.regions)
              inst_sg.regions_hierarchy
          in
          let valid =
            match group source, group destination with
            | Some source, Some destination ->
                source.id = destination.id
                || RegionGroupId.Set.mem destination.id
                     (Charon.GAstUtils.list_ancestor_region_groups
                        inst_sg.regions_hierarchy source.id)
            | _ -> false
          in
          if not valid then
            [%craise] span "Body annotations have incompatible concrete regions."
      | _ -> unify destination source
    in
    iter_assignment_regions span ctx.type_ctx.type_decls region source destination
  in
  (* ``` *)
  let locals =
    List.fold_left
      (fun locals (local : local) -> LocalId.Map.add local.index local locals)
      LocalId.Map.empty body.locals.locals
  in
  let fields ty variant =
    match ty with
    | TAdt { id = TTuple; generics } -> generics.types
    | TAdt { id = TAdtId id; generics } ->
        let decl = ctx_lookup_type_decl span ctx id in
        Substitute.type_decl_get_instantiated_field_types decl variant generics
    | _ -> [%craise] span "Invalid aggregate annotation."
  in
  let rec place_ty (p : place) =
    match p.kind with
    | PlaceLocal id -> (LocalId.Map.find id locals).local_ty
    | PlaceGlobal _ -> p.ty
    | PlaceProjection (parent, projection) -> (
        let ty = place_ty parent in
        match (projection, ty) with
        | Deref, TRef (_, inner, _)
        | Deref, TRawPtr (inner, _)
        | Deref, TAdt { id = TBuiltin TBox; generics = { types = [inner]; _ } } ->
            inner
        | Field (ProjTuple _, field), _ -> FieldId.nth (fields ty None) field
        | Field (ProjAdt (_, variant), field), _ ->
            FieldId.nth (fields ty variant) field
        | ProjIndex _, TArray (inner, _) | ProjIndex _, TSlice inner -> inner
        | _ -> p.ty)
  in
  let operand_ty = function
    | Copy place | Move place -> place_ty place
    | Constant constant -> constant.ty
  in
  let callable_signature nominal (target : fun_sig region_binder) =
    let actual =
      [%unwrap_opt_span] (Some span)
        (Substitute.lookup_fndef_sig ctx.crate nominal)
        "Could not lookup function-item signature"
    in
    let actual =
      if target.binder_regions = [] then
        let regions =
          List.map
            (fun (param : region_param) ->
              let region = RBody (RegionId.of_int !next_body_region) in
              incr next_body_region;
              (param.index, region))
            actual.binder_regions
        in
        let subst =
          Substitute.subst_remove_binder_zero
            { Substitute.empty_bound_sb_subst with
              r_sb_subst = (fun id -> List.assoc id regions) }
        in
        { binder_regions = [];
          binder_value =
            Substitute.st_substitute_visitor#visit_fun_sig subst
              actual.binder_value }
      else { actual with binder_regions = target.binder_regions }
    in
    let () = collect_callable_regions#visit_ty () (TFnPtr actual) in
    TFnPtr actual
  in
  let ret = List.hd body.locals.locals in
  let inputs, _ =
    Collections.List.split_at (List.tl body.locals.locals) body.locals.arg_count
  in
  constrain false ret.local_ty inst_sg.output;
  List.iter2 (fun (local : local) ty -> constrain false local.local_ty ty)
    inputs inst_sg.inputs;
  let constraints =
    object
      inherit [_] iter_statement as super
      method! visit_ty _ _ = ()
      method! visit_constant_expr env constant =
        let () =
          match constant.kind with
          | CFnDef _ -> collect_callable_regions#visit_ty () constant.ty
          | _ -> ()
        in
        super#visit_constant_expr env constant
      method! visit_place env place =
        constrain true place.ty (place_ty place);
        super#visit_place env place
      method! visit_statement env statement =
        (match statement.kind with
        | Assign (dest, rvalue) -> (
            let dest_ty = place_ty dest in
            match rvalue with
            | Use operand -> constrain_use (operand_ty operand) dest_ty
            | RvRef (place, kind, _) ->
                let kind =
                  match kind with
                  | BShared | BShallow -> RShared
                  | BMut | BTwoPhaseMut | BUniqueImmutable -> RMut
                in
                constrain true dest_ty (TRef (RErased, place_ty place, kind))
            | UnaryOp
                (Cast (CastFnPtr (source, target)), operand) ->
                let actual_source = operand_ty operand in
                constrain true source actual_source;
                constrain true dest_ty target;
                (match (actual_source, target) with
                | TFnDef nominal, TFnPtr target ->
                    constrain true (TFnPtr target) (callable_signature nominal target)
                | TFnPtr _, TFnPtr _ -> constrain true actual_source target
                | _ -> [%craise] span "Invalid callable cast annotation.")
            | UnaryOp (Cast (CastUnsize (_, target, _)), _) ->
                constrain true dest_ty target
            | Aggregate (AggregatedAdt (tref, variant, field), operands) ->
                if tref.id <> TTuple then constrain true dest_ty (TAdt tref);
                let expected = fields dest_ty variant in
                let expected =
                  match field with
                  | None -> expected
                  | Some field -> [FieldId.nth expected field]
                in
(*
```ocaml
*)
                List.iter2
                  (fun ty operand -> constrain_use (operand_ty operand) ty)
                  expected operands
(*
```
*)

            | Aggregate (AggregatedArray (element, length), operands) ->
                constrain true dest_ty (TArray (element, length));
                List.iter (fun operand -> constrain true element (operand_ty operand))
                  operands
            | _ -> ())
        | Call { func = FnOpRegular nominal; args; dest } -> (
            (* Trait calls constrain body metadata from their actual Rust signature. *)
            let signature =
              match nominal.kind with
              | TraitMethod (tr, method_name, _) ->
                  [%cassert] span
                    (tr.trait_decl_ref.binder_regions = [])
                    "A trait call contains unexpected bound regions.";
                  let method_sig =
                    [%unwrap_opt_span] (Some span)
                      (Substitute.lookup_flat_method_sig ctx.crate
                         tr.trait_decl_ref.binder_value.id method_name)
                      "Could not lookup a trait method signature"
                  in
                  let trait_args = tr.trait_decl_ref.binder_value.generics in
                  let method_args = nominal.generics in
                  let arguments : generic_args =
                    {
                      regions = trait_args.regions @ method_args.regions;
                      types = trait_args.types @ method_args.types;
                      const_generics =
                        trait_args.const_generics @ method_args.const_generics;
                      trait_refs = trait_args.trait_refs @ method_args.trait_refs;
                    }
                  in
                  Some
                    (Substitute.apply_args_to_item_binder tr.kind arguments
                       Substitute.st_substitute_visitor#visit_fun_sig method_sig)
              | FunId _ ->
                  Option.map
                    (fun signature -> signature.binder_value)
                    (Substitute.lookup_fndef_sig ctx.crate
                       { binder_regions = []; binder_value = nominal })
            in
            match signature with
            | Some signature ->
                List.iter2
                  (fun ty operand -> constrain true ty (operand_ty operand))
                  signature.inputs args;
                constrain true (place_ty dest) signature.output
            | None -> ())
        | Call { func = FnOpDynamic operand; args; dest } -> (
            match operand_ty operand with
            | TFnPtr { binder_regions = []; binder_value = signature } ->
                List.iter2
                  (fun ty operand -> constrain true ty (operand_ty operand))
                  signature.inputs args;
                constrain true (place_ty dest) signature.output
            | _ -> ())
        | _ -> ());
        super#visit_statement env statement
    end
  in
  constraints#visit_block () body.body;
  (* Instantiate each source-signature existential once, after all constraints. *)
  List.iter
    (fun region ->
      match resolve false region with
      | RBody _ as root -> unify root (RVar (Free (ctx.fresh_region_id ())))
      | RStatic | RVar _ | RErased -> ())
    !callable_regions;
(* ```ocaml *)
(* ``` *)
(* ```ocaml *)
  let annotation_region region =
    match region with
    | RBody _ -> resolve false region
    | RVar (Free _) -> resolve true region
    | RStatic | RVar (Bound _) | RErased -> region
  in
  let annotations_changed =
    if not declarations_changed
       && Hashtbl.length bindings = declaration_binding_count then false
    else
      let inspection =
        object
          inherit [_] iter_statement
          method! visit_region _ region =
            if annotation_region region <> region then raise Utils.Found
        end
      in
      try
        List.iter (fun (local : local) ->
          inspection#visit_ty () local.local_ty) body.locals.locals;
        inspection#visit_block () body.body;
        false
      with Utils.Found -> true
  in
  if not annotations_changed then body
  else
(* ``` *)
  let substitution =
    object
      inherit [_] map_statement
      method! visit_region _ region = annotation_region region
    end
  in
  let locals =
    List.map
      (fun (local : local) ->
        let local_ty = substitution#visit_ty () local.local_ty in
        if local_ty = local.local_ty then local else { local with local_ty })
      body.locals.locals
  in
  { body with
    locals = { body.locals with locals };
    body = substitution#visit_block () body.body }


(** Initialize an evaluation context to execute a function.

    Introduces local variables initialized in the following manner:
    - input arguments are initialized as symbolic values
    - the remaining locals are initialized as [⊥] Abstractions are introduced
      for the regions present in the function signature.

    We return:
    - the initialized evaluation context
    - the list of symbolic values introduced for the input values
    - the instantiated function signature
    - the body with fixed region annotations *)
let initialize_symbolic_context_for_fun (ctx : decls_ctx)
    (marked_ids : marked_ids) (fdef : fun_decl) :
    eval_ctx * symbolic_value list * inst_fun_sig * expr_body
    * (symbolic_value * tvalue) list =
  (* The abstractions are not initialized the same way as for function
   * calls: they contain *loan* projectors, because they "provide" us
   * with the input values (which behave as if they had been returned
   * by some function calls...).
   * Also, note that we properly set the set of parents of every abstraction:
   * this should not be necessary, as those abstractions should never be
   * *automatically* ended (because ending some borrows requires to end
   * one of them), but rather selectively ended when generating code
   * for each of the backward functions. We do it only because we can
   * do it, and because it gives a bit of sanity.
   *)
  let span = fdef.item_meta.span in

  (* Create the context.

     We start with an empty list of region groups, then update the list of
     region groups when analyzing the function signature. *)
  let ctx =
    initialize_eval_ctx (Some span) ctx [] fdef.generics.types
      fdef.generics.const_generics marked_ids
  in
  (* Instantiate the signature. This updates the context because we compute
     at the same time the list of region groups. *)
  let ctx, inst_sg =
    symbolic_instantiate_fun_sig span ctx (bound_fun_sig_of_decl fdef) fdef.src
  in
  (* Create fresh symbolic values for the inputs *)
  let input_svs =
    List.map (fun ty -> mk_fresh_symbolic_value span ctx ty) inst_sg.inputs
  in
  (* Initialize the abstractions as empty (i.e., with no avalues) abstractions *)
  let call_id = ctx.fresh_fun_call_id () in
  [%sanity_check] span (call_id = FunCallId.zero);
  let compute_abs_avalues (rg_id : region_group_id) (abs : abs)
      (ctx : eval_ctx) :
      tavalue list * abs_cont option * call_scope list =
    (* Project over the values - we use *loan* projectors, as explained above *)
    let avalues =
      List.map
        (fun (sv : symbolic_value) ->
          mk_aproj_loans_value_from_symbolic_value ctx.type_ctx.type_infos ctx.metadata_bindings abs.regions.owned sv sv.sv_ty)
        input_svs
    in
    (* The continuation expression *)
    let cont : abs_cont =
      (* We only create an input expression: no output is needed (we're only
         interested in computing *which* values get consumed upon ending a
         lifetime) *)
      let inputs =
        List.map
          (fun (sv : symbolic_value) ->
            mk_eproj_loans_value_from_symbolic_value ctx.type_ctx.type_infos
              abs.regions.owned sv sv.sv_ty)
          input_svs
      in
      (* Note that we don't really care about the type of the input *)
      let input =
        { value = EApp (EInputAbs rg_id, [ inputs ]); ty = mk_unit_ty }
      in
      { output = None; input = Some input }
    in
    (avalues, Some cont, [])
  in
  let region_can_end _ = false in
  let ctx =
    create_push_abstractions_from_abs_region_groups
      (fun rg_id -> SynthInput rg_id)
      inst_sg.abs_regions_hierarchy region_can_end compute_abs_avalues ctx
  in
(*
```ocaml
*)
  let physical_candidates =
    let groups = inst_sg.abs_regions_hierarchy in
    let rec parent_regions visited ids =
      List.fold_left
        (fun (visited, regions) id ->
          if AbsId.Set.mem id visited then (visited, regions)
          else
            let group = List.find
              (fun (group : LlbcAst.abs_region_group) -> group.id = id) groups in
            let visited, inherited =
              parent_regions (AbsId.Set.add id visited) group.parents in
            (visited, RegionId.Set.union regions
              (RegionId.Set.union inherited (RegionId.Set.of_list group.regions))))
        (visited, RegionId.Set.empty) ids in
    List.fold_left
      (fun candidates (group : LlbcAst.abs_region_group) ->
        let owned = RegionId.Set.of_list group.regions in
        let _, ancestors = parent_regions
          (AbsId.Set.singleton group.id) group.parents in
        let paths = List.concat (List.mapi
          (fun input ty ->
            List.map (fun path -> (input, path))
              (physical_input_paths span ctx owned ancestors ty))
          inst_sg.inputs) in
        if paths = [] then candidates
        else AbsId.Map.add group.id paths candidates)
      AbsId.Map.empty groups in
(*
```
*)
  (* Frozen input lenders keep their declaration identities. Execution borrows
     flow through distinct, endable transports with actual return bindings. *)
  let ctx, body_sg, body_input_svs, input_bindings =
    let needs_transport ty =
      List.exists
        (fun (group : LlbcAst.abs_region_group) ->
          let owned = RegionId.Set.of_list group.regions in
          RegionsHierarchy.back_ty_routes_for_regions
            ctx.type_ctx.type_decls ctx.type_ctx.type_infos
            (fun region -> region_in_set region owned) ty
          |> List.exists (fun route -> route <> []))
        inst_sg.abs_regions_hierarchy
    in
    if AbsId.Map.is_empty physical_candidates
       && not (List.exists needs_transport inst_sg.inputs)
    then (ctx, inst_sg, input_svs, [])
    else
      let aggregate = TAdt { id = TTuple;
        generics = mk_generic_args_from_types (inst_sg.inputs @ [ inst_sg.output ]) } in
      let _, refreshed, bindings =
        ty_refresh_regions_with_metadata (Some span) ctx.type_ctx.type_infos
          ctx.fresh_region_id ctx.metadata_bindings aggregate
      in
      let refreshed_types =
        match refreshed with
        | TAdt { id = TTuple; generics } -> generics.types
        | _ -> [%internal_error] span
      in
      let inputs, output =
        Collections.List.split_at refreshed_types (List.length inst_sg.inputs)
      in
      let output = [%unwrap_with_span] span (List.nth_opt output 0)
        "Missing refreshed function output" in
      let region_map = List.fold_left
        (fun mappings -> function
          | RVar (Free source), RVar (Free execution) ->
              (match RegionId.Map.find_opt source mappings with
              | None -> RegionId.Map.add source execution mappings
              | Some previous ->
                  [%sanity_check] span (previous = execution);
                  mappings)
          | _ -> mappings)
        RegionId.Map.empty (body_annotation_region_pairs span aggregate refreshed)
      in
      let region id = Option.value (RegionId.Map.find_opt id region_map)
        ~default:id in
      let abs_map = AbsId.Map.of_list
        (List.map (fun (group : LlbcAst.abs_region_group) ->
          (group.id, ctx.fresh_abs_id ())) inst_sg.abs_regions_hierarchy) in
      let abs_id id = AbsId.Map.find id abs_map in
      let body_sg = { inst_sg with
        inputs; output; metadata_bindings = bindings;
        body_region_map = region_map;
(* ``` *)
        regions_hierarchy = List.map
          (fun (group : region_var_group) ->
            { group with regions = List.map region group.regions })
          inst_sg.regions_hierarchy;
        abs_regions_hierarchy = List.map
          (fun (group : LlbcAst.abs_region_group) ->
            { id = abs_id group.id; regions = List.map region group.regions;
              parents = List.map abs_id group.parents })
          inst_sg.abs_regions_hierarchy }
      in
      let ctx = ctx_with_metadata_bindings ctx bindings in
      let body_input_svs = List.map2
        (fun (original : symbolic_value) ty ->
          if original.sv_ty = ty then original
          else mk_fresh_symbolic_value span ctx ty)
        input_svs inputs in
      let input_bindings = List.filter_map
        (fun ((original : symbolic_value), (execution : symbolic_value)) ->
          if original.sv_id = execution.sv_id then None
          else Some (execution,
            mk_tvalue_from_symbolic_value ctx.type_ctx.type_infos
              ctx.metadata_bindings original))
        (List.combine input_svs body_input_svs) in
      let ancestry =
        if AbsId.Map.is_empty physical_candidates then None
        else Some { source_hierarchy = inst_sg.regions_hierarchy;
                    body_hierarchy = body_sg.regions_hierarchy } in
      let immutable_origins = ref AbsId.Map.empty in
      let compute_transport (rg_id : region_group_id) (abs : abs)
          (ctx : eval_ctx) =
        let source_owner = [%unwrap_with_span] span
          (List.find_map
            (function
              | EAbs source when source.kind = SynthInput rg_id -> Some source
              | EBinding _ | EAbs _ | EFrame -> None)
            ctx.env) "Missing immutable input owner" in
        let args = List.map2
          (fun original ty ->
            (mk_tvalue_from_symbolic_value ctx.type_ctx.type_infos
              ctx.metadata_bindings original, ty))
          input_svs inputs in
        let outputs = List.map
          (fun (arg, ty) -> apply_proj_borrows_on_input_value span ctx
            abs.regions.owned arg ty) args in
        let loans = List.map
          (fun (sv : symbolic_value) ->
            mk_aproj_loans_value_from_symbolic_value ctx.type_ctx.type_infos
              ctx.metadata_bindings abs.regions.owned sv sv.sv_ty)
          body_input_svs in
        let positions =
          let paths side ty = RegionsHierarchy.back_ty_paths_for_regions
            ctx.type_ctx.type_decls ctx.type_ctx.type_infos
            (fun region -> region_in_set region abs.regions.owned) ty
            |> List.map (fun path -> (side, path)) in
          List.sort_uniq Stdlib.compare
            (List.concat_map (paths true) inputs
             @ List.concat_map (paths false) inputs) in
        let pending_slots =
          symbolic_pending_inputs span ctx abs.regions.owned positions true outputs
          @ symbolic_pending_inputs span ctx abs.regions.owned positions false loans
          |> List.sort_uniq Stdlib.compare in
        (*
```ocaml
        *)
        let carrier_origins = List.filter_map
          (fun (input_index, (original_root, transport_root)) ->
            let original_mask = RegionId.Set.inter source_owner.regions.owned
              (ty_regions ctx.type_ctx.type_infos original_root.sv_ty) in
            if RegionId.Set.is_empty original_mask then None
            else Some ({ source_owner = source_owner.abs_id; region_group = rg_id;
              source_role = FunctionInputOrigin input_index;
              original_root; transport_root; original_mask }
              : carrier_origin))
          (List.mapi (fun index pair -> (index, pair))
            (List.combine input_svs body_input_svs)) in
        immutable_origins :=
          AbsId.Map.add source_owner.abs_id carrier_origins !immutable_origins;
        (*
```
        *)
        let roots = List.map (fun root -> (true, root, root)) outputs
          @ List.map (fun root -> (false, root, root)) loans in
        let witnesses = { roots; expansions = []; projections = [];
          (*
```ocaml
          *)
(*
```ocaml
*)
(* ```ocaml *)
          carrier_origins; input_correspondences = []; carrier_conversions = []; physical_returns = [];
(* ``` *)
          return_routes = []; parent_carriers = [] } in
(*
```
*)
          (*
```
          *)
        let call_scopes = List.map
(*
```ocaml
*)
          (fun (_, slot) ->
            PendingParameterScope ({ slot; positions; witnesses } : call_pending_scope))
(*
```
*)
          pending_slots in
(*
```ocaml
*)
        let call_scopes =
          let paths = Option.value
            (AbsId.Map.find_opt source_owner.abs_id physical_candidates) ~default:[] in
          List.fold_right
            (fun (input_index, value_path) scopes ->
              let origin = List.find
                (fun (origin : carrier_origin) ->
                  origin.source_role = FunctionInputOrigin input_index)
                carrier_origins in
              let proj_regions = RegionId.Set.inter abs.regions.owned
                (ty_regions ctx.type_ctx.type_infos origin.transport_root.sv_ty) in
              let duplicate = List.exists
                (function
                  | PendingParameterScope scope ->
                      scope.slot.root_sv_id = origin.transport_root.sv_id
                      && scope.slot.proj_ty = origin.transport_root.sv_ty
                      && scope.slot.value_path = value_path
                      && RegionId.Set.equal scope.slot.proj_regions proj_regions
                  | PhysicalInputScope scope ->
                      scope.physical_slot.origin = origin
                      && scope.physical_slot.value_path = value_path
                      && RegionId.Set.equal scope.physical_slot.proj_regions proj_regions)
                scopes in
              if duplicate then scopes
              else
(*
```ocaml
*)
                let physical_slot = { origin; proj_regions; value_path } in
                let ancestry = [%unwrap_with_span] span ancestry
                  "A physical input lacks declaration ancestry" in
                let scope = { physical_slot; ancestry; witnesses } in
                let () = Invariants.check_physical_input_scope span ctx abs scope in
                PhysicalInputScope scope :: scopes)
(*
```
*)
            paths call_scopes in
(*
```
*)
        let output = List.map
          (fun (arg, ty) -> apply_eproj_borrows_on_input_value span ctx
            abs.regions.owned arg ty) args |> mk_etuple ~borrow_proj:true in
        let input = List.map2
          (fun (original : symbolic_value) (sv : symbolic_value) ->
            let supplied = mk_eproj_loans_value_from_symbolic_value
              ctx.type_ctx.type_infos abs.regions.owned sv sv.sv_ty in
            let meta : mconsumed_symb = { sv_id = sv.sv_id;
              proj_ty = sv.sv_ty; proj_regions = abs.regions.owned } in
            List.fold_left
              (fun supplied (pm, (slot : symbolic_pending_slot)) ->
                if slot.root_sv_id <> original.sv_id
                   && slot.root_sv_id <> sv.sv_id then supplied
                else
                  let base = { value = ESymbolic (pm, EPendingSymbolicLoans slot);
                    ty = slot.proj_ty } in
                  { supplied with value = ERecombine (base, [ (meta, supplied) ]) })
              supplied pending_slots)
          input_svs body_input_svs |> mk_etuple ~borrow_proj:false in
        let input = { input with value = ECallEndpoints (witnesses, input) } in
        let input = { input with value = ECallProtocol (positions, input) } in
        let pending = List.map (fun (pm, slot) ->
          ({ value = ASymbolic (pm, APendingSymbolicLoans slot);
            ty = slot.proj_ty } : tavalue)) pending_slots in
        (outputs @ loans @ pending,
         Some { output = Some output; input = Some input }, call_scopes)
      in
      let ctx = create_push_abstractions_from_abs_region_groups
        (fun _ -> WithCont) body_sg.abs_regions_hierarchy
        (fun _ -> true) compute_transport ctx in
      (* Keep the actual input transport lineage in its immutable owner.
         Execution transports can end before a nested return reaches that owner. *)
      let ctx = ctx_map_abs
        (fun abs ->
          match AbsId.Map.find_opt abs.abs_id !immutable_origins, abs.cont with
          | Some carrier_origins, Some cont ->
              let witnesses : call_endpoint_witnesses =
                { roots = List.map (fun root -> (false, root, root)) abs.avalues;
                  expansions = []; projections = []; carrier_origins;
                  input_correspondences = []; carrier_conversions = [];
                  physical_returns = []; return_routes = []; parent_carriers = [] }
              in
              let input = Option.map
                (fun input -> { input with value = ECallEndpoints (witnesses, input) })
                cont.input in
              { abs with cont = Some { cont with input } }
          | _ -> abs)
        ctx in
      (ctx, body_sg, body_input_svs, input_bindings)
  in
  (* Split the variables between return var, inputs and remaining locals *)
  let body = [%add_loc] body_as_body_exn fdef.body in
(*
```ocaml
*)
  let body = instantiate_symbolic_body_annotations span ctx body_sg body in
(*
```
*)

(* ```ocaml *)
  let runtime_annotations = object
    inherit [_] map_statement as super
    method! visit_ty _ ty =
      ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings ty
    method! visit_type_decl_ref _ tref =
      let _, generics = ty_as_adt
        (ty_erase_regions_with_metadata ctx.type_ctx.type_infos
          ctx.metadata_bindings (TAdt tref)) in
      { tref with generics }
    method! visit_trait_ref _ trait = trait
    method! visit_fn_operand _ operand = operand
    method! visit_unsizing_metadata env metadata =
      match metadata with
      | MetaVTable _ -> metadata
      | _ -> super#visit_unsizing_metadata env metadata
    method! visit_constant_expr env constant =
      match constant.kind with
      | CFnDef _ -> constant
      | _ -> super#visit_constant_expr env constant
  end in
  let body = { body with body = runtime_annotations#visit_block () body.body } in
(* ``` *)
  let ret_var = List.hd body.locals.locals in
  let input_vars, local_vars =
    Collections.List.split_at (List.tl body.locals.locals) body.locals.arg_count
  in
(* ```ocaml *)
  let local_vars = List.map
    (fun (local : local) ->
      { local with local_ty = runtime_annotations#visit_ty () local.local_ty })
    local_vars in
(* ``` *)
  (* MIR body regions do not identify signature lifetimes.
     Check annotations, then retain instantiated callable metadata. *)
  let instantiate_local var ty =
    let var = local_instantiate_ty span ctx.type_ctx.type_infos var ty in
    let local_ty = ty_erase_regions_with_metadata ctx.type_ctx.type_infos
      ctx.metadata_bindings ty in
    if var.local_ty = local_ty then var else { var with local_ty }
  in

  let ret_var = instantiate_local ret_var body_sg.output in
  let input_vars = List.map2 instantiate_local input_vars body_sg.inputs in
  (* Push the return variable (initialized with ⊥) *)
  let ctx = ctx_push_uninitialized_var span ctx ret_var in
  (* Push the input variables (initialized with symbolic values) *)
  let input_values =
    List.map
      (mk_tvalue_from_symbolic_value ctx.type_ctx.type_infos ctx.metadata_bindings)
      body_input_svs
  in
  [%ldebug
    "input vars and values:\n"
    ^ String.concat "\n"
        (List.map
           (fun ((var, value) : local * tvalue) ->
             local_to_string ctx var ^ " -> " ^ tvalue_to_string ctx value)
           (List.combine input_vars input_values))];
  let ctx = ctx_push_vars span ctx (List.combine input_vars input_values) in
  (* Push the remaining local variables (initialized with ⊥) *)
  let ctx = ctx_push_uninitialized_vars span ctx local_vars in
  let state_indices = ModelStateInputs.for_decl ctx.crate fdef in
  let state_slots =
    List.mapi
      (fun offset index ->
        let input = List.nth input_vars index in
        let slot =
          {
            input with
            index =
              Expressions.LocalId.of_int
                (List.length body.locals.locals + offset);
            name = Option.map (fun name -> name ^ "_final") input.name;
          }
        in
        (input.index, slot))
      state_indices
  in
  let ctx = ctx_push_uninitialized_vars span ctx (List.map snd state_slots) in
  let ctx =
    {
      ctx with
      consumed_state_slots =
        List.map
          (fun (input, (slot : local)) -> (input, slot.index))
          state_slots;
    }
  in
  (* Return *)
  (ctx, input_svs, inst_sg, body, input_bindings)

(** Small helper.

    This is a continuation function called by the symbolic interpreter upon
    reaching the [return] instruction when synthesizing a *backward* function:
    this continuation takes care of doing the proper manipulations to finish the
    synthesis (mostly by ending abstractions). *)
let evaluate_function_symbolic_synthesize_backward_from_return (config : config)
    (fdef : fun_decl) (inst_sg : inst_fun_sig) (back_id : RegionGroupId.id)
    (ret_value : tvalue) (ctx : eval_ctx) : SA.expr =
  let span = fdef.item_meta.span in
  [%ltrace
    "- fname: "
    ^ Print.EvalCtx.name_to_string ctx fdef.item_meta.name
    ^ "\n- back_id: "
    ^ RegionGroupId.to_string back_id
    ^ "\n- ctx:\n"
    ^ Print.Contexts.eval_ctx_to_string ~span:(Some span) ctx];
  (* We need to instantiate the function signature - to retrieve
   * the return type. Note that it is important to re-generate
   * an instantiation of the signature, so that we use fresh
   * region ids for the return abstractions. *)
  let _, ret_inst_sg =
    symbolic_instantiate_fun_sig span ctx (bound_fun_sig_of_decl fdef) fdef.src
  in
  let ret_inst_sg =
    bind_inst_fun_sig_metadata_from_signature span ctx.type_ctx.type_infos
      ctx.metadata_bindings ret_inst_sg inst_sg
  in
  let metadata_bindings =
    TypesUtils.merge_metadata_bindings (Some span) ctx.metadata_bindings
      ret_inst_sg.metadata_bindings
  in
  let ctx = { ctx with metadata_bindings } in
  let ret_rty = ret_inst_sg.output in

  (* We need to find the parents regions/abstractions of the region we
     will end - this will allow us to, first, mark the other return
     regions as non-endable, and, second, end those parent regions in
     proper order. *)
  let parent_rgs =
    list_ancestor_region_groups inst_sg.regions_hierarchy back_id
  in
  let parent_input_abs_ids =
    RegionGroupId.mapi
      (fun rg_id rg ->
        if RegionGroupId.Set.mem rg_id parent_rgs then Some rg.id else None)
      inst_sg.abs_regions_hierarchy
  in
  let parent_input_abs_ids =
    List.filter_map (fun x -> x) parent_input_abs_ids
  in

  (* Insert the return value in the return abstractions (by applying
   * borrow projections) *)
  let ctx =
    let compute_abs_avalues (rg_id : region_group_id) (abs : abs)
        (ctx : eval_ctx) :
        tavalue list * abs_cont option * call_scope list =
      (* Create the abstraction values *)
      let avalue =
        apply_proj_borrows_on_input_value span ctx abs.regions.owned ret_value
          ret_rty
      in
      (* Create the abstraction continuation expression *)
      let cont : abs_cont =
        let output =
          apply_eproj_borrows_on_input_value span ctx abs.regions.owned
            ret_value ret_rty
        in
        let input = EApp (EOutputAbs rg_id, []) in
        let input = { value = input; ty = ret_rty } in
        { output = Some output; input = Some input }
      in
      ([ avalue ], Some cont, [])
    in

    (* Initialize and insert the abstractions in the context.

       We take care of allowing to end only the regions which should end (note
       that this is important for soundness: this is part of the borrow checking).
       Also see the documentation of the [can_end] field of [abs] for more
       information. *)
    let parent_and_current_rgs = RegionGroupId.Set.add back_id parent_rgs in
    let region_can_end rid = RegionGroupId.Set.mem rid parent_and_current_rgs in
    [%sanity_check] span (region_can_end back_id);
    let ctx =
      create_push_abstractions_from_abs_region_groups
        (fun rg_id -> SynthRet rg_id)
        ret_inst_sg.abs_regions_hierarchy region_can_end compute_abs_avalues ctx
    in
    ctx
  in
  [%ltrace
    "After putting the return value in the proper abstraction:\n" ^ "\n- ctx:\n"
    ^ Print.Contexts.eval_ctx_to_string ~span:(Some span) ctx];

  (* We now need to end the proper *input* abstractions - pay attention
     to the fact that we end the *input* abstractions, not the *return*
     abstractions (of course, the corresponding return abstractions will
     automatically be ended, because they consumed values coming from the
     input abstractions...) *)
  (* End the parent abstractions and the current abstraction - note that we
     end them in an order which follows the regions hierarchy: it should lead
     to generated code which has a better consistency between the parent
     and children backward functions.
   *)
  let current_abs_id =
    (RegionGroupId.nth inst_sg.abs_regions_hierarchy back_id).id
  in
  [%ltrace "ending input abstraction: " ^ AbsId.to_string current_abs_id];

  let target_abs_ids = List.append parent_input_abs_ids [ current_abs_id ] in

  (* Set the abstrations as endable *)
  let ctx = InterpBorrowsCore.update_endable ctx target_abs_ids ~can_end:true in

  (* Actually end them *)
  let ctx, cc =
    fold_left_apply_continuation
      (fun id ctx -> end_abs config span id 0 ctx)
      target_abs_ids ctx
  in
  (* Generate the Return node *)
  let return_expr =
    SA.Return (SynthesizeSymbolic.capture_context ctx, None, [])
  in
  (* Apply *)
  cc return_expr

(** Evaluate a function with the symbolic interpreter.

    We return:
    - the list of symbolic values introduced for the input values (this is
      useful for the synthesis)
    - the symbolic AST generated by the symbolic execution

    If [synthesize] is [true]: we synthesize the symbolic AST that is used for
    the translation. Otherwise, we do not (the symbolic execution then simply
    borrow-checks the function). *)
let evaluate_function_symbolic_inner (synthesize : bool) (decls_ctx : decls_ctx)
    (marked_ids : marked_ids) (fdef : fun_decl) :
    symbolic_value list * SA.expr option =
  (* Debug *)
  let span = fdef.item_meta.span in
  let name_to_string () =
    Print.name_to_string
      (Print.Contexts.decls_ctx_to_fmt_env decls_ctx)
      fdef.item_meta.name
  in
  [%ltrace name_to_string ()];

  (* Create the evaluation context *)
  let ctx, input_svs, inst_sg, body, input_bindings =
    initialize_symbolic_context_for_fun decls_ctx marked_ids fdef
  in
  [%ltrace "initial context:\n" ^ eval_ctx_to_string ctx];

  let regions_hierarchy =
    RegionsHierarchy.compute_regions_hierarchy_for_sig (Some span) ctx.crate
      (bound_fun_sig_of_decl fdef)
  in

  (* Create the continuation to finish the evaluation *)
  let config = mk_config SymbolicMode in
  let finish (res : statement_eval_res) (ctx : eval_ctx) =
    let ctx0 = ctx in
    [%ltrace
      "cf_finish:\n"
      ^ Cps.show_statement_eval_res res
      ^ "\n- ctx:\n" ^ eval_ctx_to_string ctx];

    match res with
    | Return ->
        (* We have to "play different endings":
         * - one execution for the forward function
         * - one execution per backward function
         * We then group everything together.
         *)
        (* There are two cases:
         - if this is a forward translation, we retrieve the returned value.
         - if this is a backward translation, we introduce "return"
           abstractions to consume the return value, then end all the
           abstractions up to the one in which we are interested.
        *)
        (* Live and dropped inputs remain authoritative. A genuinely moved
           input leaves a deferred obligation for the consuming-call ABI. *)
        let states, ctx, cc_states =
          List.fold_left
            (fun (states, ctx, cc) (index, (input, slot)) ->
              let source =
                match (ctx_lookup_var_value span ctx input).value with
                | VBottom -> slot
                | _ -> input
              in
              if
                bottom_in_value ctx.type_ctx.type_infos ctx.ended_regions
                  (ctx_lookup_var_value span ctx source)
              then ((index, None) :: states, ctx, cc)
              else
                let value, ctx, next =
                  InterpExpressions.eval_operand config span
                    (Expressions.Move
                       (InterpUtils.mk_place_from_var_id ctx span source))
                    ctx
                in
                [%sanity_check] span
                  (not (bottom_in_value ctx.type_ctx.type_infos ctx.ended_regions value));
                let ctx =
                  ctx_push_dummy_var ctx (ctx.fresh_dummy_var_id ()) value
                in
                ((index, Some value) :: states, ctx, cc_comp cc next))
            ([], ctx, fun e -> e)
            (List.combine
               (ModelStateInputs.for_decl ctx.crate fdef)
               ctx.consumed_state_slots)
        in
        let states = List.rev states in
        (* Whatever the scenario, we need to pop the frame and retrieve the returned value *)
        let ret_value, ctx, cc_pop =
          (* Do not pop the locals if this is a global and [borrow_check_globals]
           is false *)
          let pop_locals =
            if !Config.borrow_check_globals then true
            else not (Option.is_some fdef.is_global_initializer)
          in
          let static_locals =
            match fdef.body with
            | StructuredBody body ->
                InterpStatements.promoted_constant_locals body
            | _ -> Expressions.LocalId.Set.empty
          in
          pop_frame config span ~static_locals ~pop_locals
            ~pop_return_value:true ctx
        in
        let cc_pop = cc_comp cc_states cc_pop in
        let ret_value = Option.get ret_value in
        let ctx_return = ctx in
        [%ltrace
          "after popping the frame:\n- returned value:\n"
          ^ tvalue_to_string ctx_return ret_value
          ^ "\n\n- ctx:\n"
          ^ eval_ctx_to_string ctx_return];

        (* Forward translation: generate the Return node *)
        let ctx_return = SynthesizeSymbolic.capture_context ctx_return in
        let fwd_e = cc_pop (SA.Return (ctx_return, Some ret_value, states)) in
        (* Backward translation: introduce "return"
           abstractions to consume the return value, then end all the
           abstractions up to the one in which we are interested.
        *)
        let finish_back_eval back_id =
          evaluate_function_symbolic_synthesize_backward_from_return config fdef
            inst_sg back_id ret_value ctx
        in
        let back_el =
          RegionGroupId.mapi
            (fun gid _ -> (gid, cc_pop (finish_back_eval gid)))
            regions_hierarchy
        in
        let back_el = RegionGroupId.Map.of_list back_el in
        (* Put everything together *)
        let ctx0 = SynthesizeSymbolic.capture_context ctx0 in
        SA.ForwardEnd (Some (ctx_return, ret_value), ctx0, fwd_e, back_el)
    | Panic ->
        (* Note that as we explore all the execution branches, one of
         * the executions can lead to a panic *)
        SA.Panic
    | Unit | Break _ | Continue _ ->
        [%craise] span
          ("evaluate_function_symbolic failed on: " ^ name_to_string ()
         ^ "\nUnexpected result: "
          ^ show_statement_eval_res res)
  in

  (* Evaluate the function *)
  let symbolic =
    try
      [%recover_internal_errors] fdef.item_meta.span (fun () ->
          let ctx_resl, cc = eval_function_body config body.body ctx in
          let el = List.map (fun (ctx, res) -> finish res ctx) ctx_resl in
          (* Finish synthesizing *)
          if synthesize then
            Some (List.fold_right
              (fun (execution, original) next ->
                SA.IntroSymbolic
                  (ctx, None, execution, SA.VaSingleValue original, next))
              input_bindings (cc el))
          else None)
    with CFailure error ->
      let name = name_to_string () in
      let name_pattern =
        TranslateCore.name_to_pattern_string_for_error
          (Some fdef.item_meta.span) decls_ctx fdef.item_meta.name
      in
      let action = if synthesize then "translate" else "borrow-check" in
      [%warn_recovered_opt_span] error.span
        ("Could not " ^ action ^ " the body of function '" ^ name
       ^ " because of previous error\nName pattern: '" ^ name_pattern ^ "'"
       ^ "\nDefinition span: "
        ^ Errors.raw_span_to_string fdef.item_meta.span
        ^ compute_local_uses_error_message decls_ctx (IdFun fdef.def_id));
      if synthesize then Some (Error (error.span, error.msg)) else None
  in
  (* Return *)
  (input_svs, symbolic)

let evaluate_function_symbolic (synthesize : bool) (decls_ctx : decls_ctx)
    (marked_ids : marked_ids) (fdef : fun_decl) :
    symbolic_value list * SA.expr option =
  let log = Logging.carrier_events_log in
  if Logging.L.Debug < log#effective_level then
    evaluate_function_symbolic_inner synthesize decls_ctx marked_ids fdef
  else
    with_carrier_metadata_scope (FunDeclId.to_string fdef.def_id) fdef.item_meta.span
      (fun () ->
        evaluate_function_symbolic_inner synthesize decls_ctx marked_ids fdef)

module Test = struct
  (** Test a unit function (taking no arguments) by evaluating it in an empty
      environment. *)
  let test_unit_function (crate : crate) (decls_ctx : decls_ctx)
      (fid : FunDeclId.id) : unit =
    (* Retrieve the function declaration *)
    let fdef = FunDeclId.Map.find fid crate.fun_decls in
    let body = [%add_loc] body_as_body_exn fdef.body in
    let span = fdef.item_meta.span in

    (* Debug *)
    [%ltrace
      Print.name_to_string
        (Print.Contexts.decls_ctx_to_fmt_env decls_ctx)
        fdef.item_meta.name];

    (* Sanity check - *)
    [%sanity_check] span (fdef.generics = empty_generic_params);
    [%sanity_check] span (body.locals.arg_count = 0);

    (* Create the evaluation context *)
    let ctx =
      initialize_eval_ctx (Some span) decls_ctx [] [] [] empty_marked_ids
    in

    (* Insert the (uninitialized) local variables *)
    let ctx = ctx_push_uninitialized_vars span ctx body.locals.locals in

    (* Create the continuation to check the function's result *)
    let config = mk_config ConcreteMode in
    let check (res : statement_eval_res) (ctx : eval_ctx) =
      match res with
      | Return ->
          (* Ok: drop the local variables and finish *)
          pop_frame config span ~pop_locals:true ~pop_return_value:true ctx
      | _ ->
          [%craise] span
            ("Unit test failed (concrete execution) on: "
            ^ Print.name_to_string
                (Print.Contexts.decls_ctx_to_fmt_env decls_ctx)
                fdef.item_meta.name)
    in
    (* Evaluate the function *)
    let ctx_resl, _ = eval_function_body config body.body ctx in
    let _ = List.map (fun (ctx, res) -> check res ctx) ctx_resl in
    ()

  (** Small helper: return true if the function is a *transparent* unit function
      (no parameters, no arguments) - TODO: move *)
  let fun_decl_is_transparent_unit (def : fun_decl) : bool =
    body_is_known def.body
    && def.generics = empty_generic_params
    && def.signature.inputs = []

  (** Test all the unit functions in a list of function definitions *)
  let test_unit_functions (crate : crate) : unit =
    let unit_funs =
      FunDeclId.Map.filter
        (fun _ -> fun_decl_is_transparent_unit)
        crate.fun_decls
    in
    let decls_ctx = compute_contexts crate in
    let test_unit_fun _ (def : fun_decl) : unit =
      test_unit_function crate decls_ctx def.def_id
    in
    FunDeclId.Map.iter test_unit_fun unit_funs
end
