(** This module implements support to match contexts for loops.

    The matching functions are used for instance to compute joins, or to check
    if two contexts are equivalent (modulo conversion). *)

open Types
open Values
open Contexts
open TypesUtils
open ValuesUtils
open Cps
open InterpUtils
open InterpBorrowsCore
open InterpAbs
open InterpJoinCore
module S = SynthesizeSymbolic

(** The local logger *)
let log = Logging.match_ctxs_log

let compute_abs_borrows_loans_maps (span : Meta.span) (explore : abs -> bool)
    (ctx : eval_ctx) (env : env) : abs_borrows_loans_maps =
  let abs_ids = ref [] in
  let abs_to_borrows = ref AbsId.Map.empty in
  let abs_to_non_unique_borrows = ref AbsId.Map.empty in
  let abs_to_loans = ref AbsId.Map.empty in
  let abs_to_borrow_projs = ref AbsId.Map.empty in
  let abs_to_loan_projs = ref AbsId.Map.empty in
  let borrow_to_abs = ref MarkedUniqueBorrowId.Map.empty in
  let non_unique_borrow_to_abs = ref MarkedBorrowId.Map.empty in
  let loan_to_abs = ref MarkedLoanId.Map.empty in
  let borrow_proj_to_abs = ref MarkedNormSymbProj.Map.empty in
  let loan_proj_to_abs = ref MarkedNormSymbProj.Map.empty in

  let module R (M : Collections.Map) (S : Collections.Set) = struct
    (*
       [check_singleton_sets]: check that the mapping maps to a singleton.
       We need to tweak the behavior of the sanity checks because
       of the following cases:
       - when computing the map from borrow ids (with marker) to the region
         abstractions they belong to, the marked borrow ids can map to a single
         region abstraction, i.e., to a singleton set of region abstraction ids
       - however, when computing the mapping from region abstractions to
         the borrow ids they contain, this time we do map abstraction ids
         to sets which can compute strictly more than one value
       Also: note that it is possible to copy symbolic values containing borrows
       (if those borrows are shared borrows for instance).
    *)
    let register_mapping (to_string : M.key -> S.elt -> string)
        (check_singleton_sets : bool) (map : S.t M.t ref) (id0 : M.key)
        (id1 : S.elt) : unit =
      (* Update the mapping *)
      map :=
        M.update id0
          (fun ids ->
            match ids with
            | None -> Some (S.singleton id1)
            | Some ids ->
                (* Check that we are allowed to map id0 to a set which is not
                   a singleton *)
                if check_singleton_sets then
                  [%craise] span
                    ("Internal error, please file an issue.\n\
                      Key already registered: " ^ to_string id0 id1);
                (* Check that the mapping was not already registered *)
                if S.mem id1 ids then
                  [%craise] span
                    ("Internal error, please file an issue.\n\
                      Found an already registered mapping: " ^ to_string id0 id1
                    );
                (* Update *)
                Some (S.add id1 ids))
          !map

    let register_abs_id (id : AbsId.id) (map : S.t AbsId.Map.t ref) =
      if AbsId.Map.mem id !map then () else map := AbsId.Map.add id S.empty !map
  end in
  let module RAbsUniqueBorrow = R (AbsId.Map) (MarkedUniqueBorrowId.Set) in
  let module RAbsBorrow = R (AbsId.Map) (MarkedBorrowId.Set) in
  let module RAbsLoan = R (AbsId.Map) (MarkedLoanId.Set) in
  let module RBorrowAbs = R (MarkedBorrowId.Map) (AbsId.Set) in
  let module RUniqueBorrowAbs = R (MarkedUniqueBorrowId.Map) (AbsId.Set) in
  let module RLoanAbs = R (MarkedLoanId.Map) (AbsId.Set) in
  let module RAbsSymbProj = R (AbsId.Map) (MarkedNormSymbProj.Set) in
  let module RSymbProjAbs = R (MarkedNormSymbProj.Map) (AbsId.Set) in
  let register_abs_id abs_id =
    RAbsUniqueBorrow.register_abs_id abs_id abs_to_borrows;
    RAbsBorrow.register_abs_id abs_id abs_to_non_unique_borrows;
    RAbsLoan.register_abs_id abs_id abs_to_loans;
    RAbsSymbProj.register_abs_id abs_id abs_to_borrow_projs;
    RAbsSymbProj.register_abs_id abs_id abs_to_loan_projs
  in
  let uborrow_to_string (pm, bid, sid) =
    let b =
      match sid with
      | None -> "mut_borrow@" ^ BorrowId.to_string bid
      | Some sid ->
          "shared_borrow@" ^ BorrowId.to_string bid ^ "(^"
          ^ SharedBorrowId.to_string sid
          ^ ")"
    in
    Print.Values.add_proj_marker pm b
  in
  let borrow_to_string (pm, bid) =
    "borrow@" ^ BorrowId.to_string bid |> Print.Values.add_proj_marker pm
  in
  let loan_to_string (pm, bid) =
    "loan@" ^ BorrowId.to_string bid |> Print.Values.add_proj_marker pm
  in
  let abs_id_to_string aid = "abs@" ^ AbsId.to_string aid in
  let binding_to_string fmt0 fmt1 x0 x1 = fmt0 x0 ^ " -> " ^ fmt1 x1 in
  let borrow_proj_to_string x =
    "@borrow_proj(" ^ marked_norm_symb_proj_to_string ctx x ^ ")"
  in
  let loan_proj_to_string x =
    "@loan_proj(" ^ marked_norm_symb_proj_to_string ctx x ^ ")"
  in
  let register_borrow_id (abs : abs) pm bid sid =
    RAbsUniqueBorrow.register_mapping
      (binding_to_string abs_id_to_string uborrow_to_string)
      false abs_to_borrows abs.abs_id (pm, bid, sid);
    let already_registered =
      match AbsId.Map.find_opt abs.abs_id !abs_to_non_unique_borrows with
      | Some ids -> MarkedBorrowId.Set.mem (pm, bid) ids
      | None -> false
    in
    if not already_registered then
      RAbsBorrow.register_mapping
        (binding_to_string abs_id_to_string borrow_to_string)
        false abs_to_non_unique_borrows abs.abs_id (pm, bid);
    RUniqueBorrowAbs.register_mapping
      (binding_to_string uborrow_to_string abs_id_to_string)
      true borrow_to_abs (pm, bid, sid) abs.abs_id;
    if not already_registered then
      RBorrowAbs.register_mapping
        (binding_to_string borrow_to_string abs_id_to_string)
        false non_unique_borrow_to_abs (pm, bid) abs.abs_id
  in

  let register_loan_id (abs : abs) pm bid =
    RAbsLoan.register_mapping
      (binding_to_string abs_id_to_string loan_to_string)
      false abs_to_loans abs.abs_id (pm, bid);
    RLoanAbs.register_mapping
      (binding_to_string loan_to_string abs_id_to_string)
      true loan_to_abs (pm, bid) abs.abs_id
  in
  (* The borrow projections registered so far, split between the ordinary
     projections and the shared reborrow projections ([AsbProjReborrows]) *)
  let owner_borrow_projs = ref MarkedNormSymbProj.Set.empty in
  let shared_borrow_projs = ref MarkedNormSymbProj.Set.empty in
  let register_borrow_proj ?(shared = false) abs pm (proj : symbolic_proj) =
    let norm_proj_ty = normalize_proj_ty ctx.type_ctx.type_infos abs.regions.owned proj.proj_ty in
    let proj : marked_norm_symb_proj =
      { pm; sv_id = proj.sv_id; norm_proj_ty }
    in
    (* An ordinary borrow projection owns the borrows it projects: at most one
       abstraction holds it. A shared reborrow projection holds shared
       reborrows of these borrows while the original symbolic payload stays: it
       can coexist with other shared reborrow projections. It can also coexist
       with the ordinary projection, but only if the projected borrows are all
       shared (copies of a shared borrow are independent). The owner of a
       projected mutable borrow and a reborrow of it must not coexist. The
       check does not depend on the order in which we visit the
       abstractions. *)
    let binding_str () =
      binding_to_string borrow_proj_to_string abs_id_to_string proj abs.abs_id
    in
    let check_shared_only () =
      if
        ty_has_mut_borrow_for_region_in_set ctx.type_ctx.type_infos
          (RegionId.Set.singleton (RegionId.of_int 0))
          norm_proj_ty
      then
        [%craise] span
          ("Internal error, please file an issue.\n\
            A projection of a mutable borrow and a shared reborrow of it are \
            in two abstractions: " ^ binding_str ())
    in
    if shared then begin
      if MarkedNormSymbProj.Set.mem proj !owner_borrow_projs then
        check_shared_only ();
      shared_borrow_projs := MarkedNormSymbProj.Set.add proj !shared_borrow_projs
    end
    else begin
      if MarkedNormSymbProj.Set.mem proj !owner_borrow_projs then
        [%craise] span
          ("Internal error, please file an issue.\n\
            Key already registered: " ^ binding_str ());
      if MarkedNormSymbProj.Set.mem proj !shared_borrow_projs then
        check_shared_only ();
      owner_borrow_projs := MarkedNormSymbProj.Set.add proj !owner_borrow_projs
    end;
    (* These maps record owner membership, not the number of shared copies.
       Independent shared projections can occupy the same abstraction.
       The ordinary projection check above still requires a unique owner. *)
    let registered =
      match AbsId.Map.find_opt abs.abs_id !abs_to_borrow_projs with
      | Some projs -> MarkedNormSymbProj.Set.mem proj projs
      | None -> false
    in
    if not registered then begin
      RAbsSymbProj.register_mapping
        (binding_to_string abs_id_to_string borrow_proj_to_string)
        false abs_to_borrow_projs abs.abs_id proj;
      RSymbProjAbs.register_mapping
        (binding_to_string borrow_proj_to_string abs_id_to_string)
        false borrow_proj_to_abs proj abs.abs_id
    end
  in
  let register_loan_proj abs pm (proj : symbolic_proj) =
    let norm_proj_ty = normalize_proj_ty ctx.type_ctx.type_infos abs.regions.owned proj.proj_ty in
    let proj : marked_norm_symb_proj =
      { pm; sv_id = proj.sv_id; norm_proj_ty }
    in
    RAbsSymbProj.register_mapping
      (binding_to_string abs_id_to_string loan_proj_to_string)
      false abs_to_loan_projs abs.abs_id proj;
    RSymbProjAbs.register_mapping
      (binding_to_string loan_proj_to_string abs_id_to_string)
      true loan_proj_to_abs proj abs.abs_id
  in

  let explore_abs =
    object (self : 'self)
      inherit [_] iter_tavalue as super

      (** Make sure we don't register the ignored ids *)
      method! visit_aloan_content (abs, pm) lc =
        [%sanity_check] span (pm = PNone);
        match lc with
        | AMutLoan (npm, lid, child) ->
            (* Add the current marker when visiting the loan id *)
            self#visit_loan_id (abs, npm) lid;
            (* Recurse with the old marker *)
            super#visit_tavalue (abs, pm) child
        | ASharedLoan (npm, lid, sv, child) ->
            (* Add the current marker when visiting the loan ids and the shared value *)
            self#visit_loan_id (abs, npm) lid;
            self#visit_tvalue (abs, npm) sv;
            (* Recurse with the old marker *)
            self#visit_tavalue (abs, pm) child
        | AIgnoredMutLoan (_, _, child) | AIgnoredSharedLoan child ->
            [%sanity_check] span (pm = PNone);
            (* Ignore the id of the loan, if there is *)
            self#visit_tavalue (abs, pm) child
        | AEndedMutLoan { child; given_back; given_back_meta = _ }
        | AEndedIgnoredMutLoan { child; given_back; _ } ->
            self#visit_tavalue (abs, pm) child;
            self#visit_tavalue (abs, pm) given_back
        | AEndedSharedLoan (npm, sv, child) ->
            (* Only the outer loan ended. The concrete payload still owns its
               nested loans and borrows, with the original branch marker. *)
            self#visit_tvalue (abs, npm) sv;
            self#visit_tavalue (abs, pm) child

      (** Make sure we don't register the ignored ids *)
      method! visit_aborrow_content (abs, pm) bc =
        [%sanity_check] span (pm = PNone);
        match bc with
        | AMutBorrow (npm, bid, child) ->
            (* Add the current marker when visiting the borrow id *)
            register_borrow_id abs npm bid None;
            (* Recurse with the old marker *)
            self#visit_tavalue (abs, pm) child
        | ASharedBorrow (npm, bid, sid) ->
            (* Add the current marker when visiting the borrow id *)
            register_borrow_id abs npm bid (Some sid)
        | AProjSharedBorrow (npm, asb) ->
            List.iter
              (function
                | AsbBorrow (bid, sid) ->
                    register_borrow_id abs npm bid (Some sid)
                | AsbProjReborrows proj ->
                    register_borrow_proj ~shared:true abs npm proj)
              asb
        | AIgnoredMutBorrow (_, child) ->
            [%sanity_check] span (pm = PNone);
            (* Ignore the id of the borrow, if there is *)
            self#visit_tavalue (abs, pm) child
        | AEndedIgnoredMutBorrow { child; given_back; given_back_meta = _ } ->
            self#visit_tavalue (abs, pm) child;
            self#visit_tavalue (abs, pm) given_back
        | AEndedMutBorrow (_, child) -> self#visit_tavalue (abs, pm) child
        | AEndedSharedBorrow -> ()

      method! visit_VSharedBorrow (abs, pm) bid sid =
        register_borrow_id abs pm bid (Some sid)

      method! visit_VReservedMutBorrow (abs, pm) bid sid =
        register_borrow_id abs pm bid (Some sid)

      method! visit_VMutBorrow (abs, pm) bid value =
        register_borrow_id abs pm bid None;
        self#visit_tvalue (abs, pm) value

      method! visit_borrow_id _ _ = [%internal_error] span
      method! visit_loan_id (abs, pm) lid = register_loan_id abs pm lid
      method! visit_ASymbolic (abs, _) pm proj = self#visit_aproj (abs, pm) proj

      method! visit_aproj ((abs, pm) as env) proj =
        let visit_children children =
          List.iter (fun (_, child) -> self#visit_aproj env child) children
        in
        (* ```ocaml *)
        match proj with
        | ATransportedProj (transport, child) ->
            self#visit_aproj (carrier_coordinate_abs transport abs, pm) child
        (* ``` *)
        | AProjLoans { proj; consumed; borrows } ->
            register_loan_proj abs pm proj;
            visit_children consumed;
            visit_children borrows
        | AProjBorrows { proj; loans } ->
            register_borrow_proj abs pm proj;
            visit_children loans
        | AEndedProjLoans { proj = _; consumed; borrows } ->
            visit_children consumed;
            visit_children borrows
        | AEndedProjBorrows { mvalues = _; loans } -> visit_children loans
        | APendingLoans _ | APendingSymbolicLoans _ | AEmpty -> ()
      (* ```ocaml *)
      method! visit_ATransportedValue (abs, pm) transport child =
        self#visit_tavalue (carrier_coordinate_abs transport abs, pm) child
      (* ``` *)
    end
  in

  env_iter_abs
    (fun abs ->
      register_abs_id abs.abs_id;
      if explore abs then (
        abs_to_borrows :=
          AbsId.Map.add abs.abs_id MarkedUniqueBorrowId.Set.empty
            !abs_to_borrows;
        abs_to_non_unique_borrows :=
          AbsId.Map.add abs.abs_id MarkedBorrowId.Set.empty
            !abs_to_non_unique_borrows;
        abs_to_loans :=
          AbsId.Map.add abs.abs_id MarkedLoanId.Set.empty !abs_to_loans;
        abs_ids := abs.abs_id :: !abs_ids;
        List.iter (explore_abs#visit_tavalue (abs, PNone)) abs.avalues)
      else ())
    env;

  (* Rem.: there is no need to reverse the abs ids, because we explored the environment
     starting with the freshest values and abstractions *)
  {
    abs_ids = !abs_ids;
    abs_to_borrows = !abs_to_borrows;
    abs_to_non_unique_borrows = !abs_to_non_unique_borrows;
    abs_to_loans = !abs_to_loans;
    borrow_to_abs = !borrow_to_abs;
    non_unique_borrow_to_abs = !non_unique_borrow_to_abs;
    loan_to_abs = !loan_to_abs;
    abs_to_borrow_projs = !abs_to_borrow_projs;
    abs_to_loan_projs = !abs_to_loan_projs;
    borrow_proj_to_abs = !borrow_proj_to_abs;
    loan_proj_to_abs = !loan_proj_to_abs;
  }

(** The mutable borrows held by a value and its symbolic values holding mutable
    borrows, in traversal order. With [shared]: the borrows held by a value
    and its symbolic values holding borrows of non-static regions (see
    {!distinct_nested_mut_borrows}). *)
let value_borrow_holders ~(shared : bool) (span : Meta.span) (ctx : eval_ctx)
    (v : tvalue) : [ `Borrow of BorrowId.id | `Symbolic of SymbolicValueId.id ] list
    =
  let holders = ref [] in
  let visitor =
    object
      inherit [_] iter_tvalue as super
      method! visit_ty _ _ = ()

      method! visit_VMutBorrow env bid bv =
        holders := `Borrow bid :: !holders;
        super#visit_VMutBorrow env bid bv

      method! visit_VSharedBorrow _ bid _ =
        if shared then holders := `Borrow bid :: !holders

      method! visit_VReservedMutBorrow _ bid _ =
        if shared then holders := `Borrow bid :: !holders

      method! visit_symbolic_value _ sv =
        let holds =
          if shared then
            ValuesUtils.symbolic_value_has_borrows (Some span)
              ctx.type_ctx.type_infos sv
            && TypesUtils.ty_has_free_regions ctx.type_ctx.type_infos sv.sv_ty
          else
            ValuesUtils.symbolic_value_has_mut_borrows span
              ctx.type_ctx.type_infos sv
        in
        if holds then holders := `Symbolic sv.sv_id :: !holders
    end
  in
  visitor#visit_tvalue () v;
  List.rev !holders

(** Does an abstraction of a context hold loans of the values borrowed by one
    of the borrows [bids]: pending loans (the loans of the values given back
    through them, see {!InterpBorrows.destructure_abs}) or loans under an
    ignored loan of one of them (the loans of a nested region of the borrowed
    value, e.g., in a loop abstraction)? *)
let ctx_holds_loans_under_borrows (ctx : eval_ctx) (bids : BorrowId.Set.t) :
    bool =
  let visitor =
    object
      inherit [_] iter_eval_ctx as super
      method! visit_ty _ _ = ()
      method! visit_tevalue _ _ = ()

      method! visit_APendingLoans _ bid =
        if BorrowId.Set.mem bid bids then raise Utils.Found

      method! visit_AIgnoredMutLoan env pm bid child =
        (match bid with
        | Some bid when BorrowId.Set.mem bid bids -> raise Utils.Found
        | _ -> ());
        super#visit_AIgnoredMutLoan env pm bid child
    end
  in
  try
    visitor#visit_eval_ctx () ctx;
    false
  with Utils.Found -> true

(** Are [MB bid0 bv0] and [MB bid1 bv1] distinct mutable borrows whose borrowed
    values hold distinct mutable borrows (nested borrows)? Matching the borrowed
    values would join those inner borrows independently of the outer ones (see
    {!PrimMatcher.match_distinct_nested_mut_borrows}). Borrowed values holding
    loans or bottoms are matched structurally: the join ends those loans first.

    Inner shared borrows count as well when an abstraction holds loans of the
    values borrowed by [bid0] or [bid1] (see {!ctx_holds_loans_under_borrows};
    e.g., the region group of the nested region of a call which gave back a
    fresh borrow of a [&'b mut Vec<&'a T>], or the loop abstraction of that
    region): the region of a shared borrow nested in a mutable borrow is also
    given back through the outer borrow, and the abstraction of the nested
    region would neither be a child of the abstraction joining the outer
    borrows nor hold the pending loans of the values given back through them.
    Otherwise the inner shared borrows are matched structurally, as before
    (e.g., the iterators of two slices selected by
    [if c { &mut left } else { &mut right }]). *)
let distinct_nested_mut_borrows (span : Meta.span) (ctx0 : eval_ctx)
    (ctx1 : eval_ctx) (bid0 : borrow_id) (bv0 : tvalue) (bid1 : borrow_id)
    (bv1 : tvalue) : bool =
  bid0 <> bid1
  && (not (tvalue_has_loans bv0 || tvalue_has_loans bv1))
  && (not (tvalue_has_bottom ctx0 bv0 || tvalue_has_bottom ctx1 bv1))
  &&
  let bids = BorrowId.Set.of_list [ bid0; bid1 ] in
  let shared =
    ctx_holds_loans_under_borrows ctx0 bids
    || ctx_holds_loans_under_borrows ctx1 bids
  in
  value_borrow_holders ~shared span ctx0 bv0
  <> value_borrow_holders ~shared span ctx1 bv1

(** Does a symbolic value hold nested borrows which a join cannot introduce
    (joining it with a distinct symbolic value introduces one abstraction per
    region of a fresh symbolic value, holding the projections of that region
    only)? Nested borrows whose regions are all ['static] (the type has no
    region arguments, e.g. an enum with a [&'static [&'static str]] field)
    have no lender to track. Nested borrows which are all under shared
    borrows (e.g., the [IntoIter<(&'a String, &'b (Vec<String>, Vec<&'c T>))>]
    of a loop over a sorted map view) give nothing back through the outer
    borrows: the abstraction of a nested region does not depend on the values
    given back to the outer ones, exactly as for the region parameters of an
    ADT behind a shared borrow ([&'a Foo<'b>]). Only nested borrows under a
    mutable borrow are unsupported. *)
let symbolic_value_has_unsupported_nested_borrows (span : Meta.span)
    (ctx : eval_ctx) (sv : symbolic_value) : bool =
  let infos = ctx.type_ctx.type_infos in
  (not (ty_no_regions infos sv.sv_ty))
  && ty_has_nested_borrows (Some span) infos sv.sv_ty
  && ty_has_borrow_under_mut (Some span) infos sv.sv_ty

(** Match complete regionful types without changing nominal argument positions.
    Stored positions establish correspondence. Metadata compatibility uses that
    correspondence without adding new region mappings. *)
let rec match_types (span : Meta.span) ~(recover : bool) (ctx0 : eval_ctx)
    (ctx1 : eval_ctx) (match_distinct_types : ty -> ty -> ty)
    (match_regions : region -> region -> region)
    (match_metadata_regions : region -> region -> region)
    (match_metadata_types : ty -> ty -> ty) (ty0 : ty) (ty1 : ty) : ty =
  let match_rec =
    match_types span ~recover ctx0 ctx1 match_distinct_types match_regions
      match_metadata_regions match_metadata_types
  in
  match (ty0, ty1) with
  | ( TAdt { id = id0; generics = generics0 },
      TAdt { id = id1; generics = generics1 } ) ->
      [%cassert_recover] recover span (id0 = id1) "Not the same ADT ids";
      [%cassert_recover] recover span
        (generics0.const_generics = generics1.const_generics)
        "Not the same const generics";
      (* Trait witnesses do not contribute storage or region correspondences. *)
      let erase_trait_refs =
        let erase = new Substitute.erase_runtime_regions_visitor in
        List.map (erase#visit_trait_ref 0)
      in
      [%cassert_recover] recover span
        (erase_trait_refs generics0.trait_refs
        = erase_trait_refs generics1.trait_refs)
        "Not the same trait refs";
      let id = id0 in
      let const_generics = generics1.const_generics in
      let trait_refs = generics1.trait_refs in
      let info = projection_adt_info ctx0.type_ctx.type_infos id0 in
      let map_args is_stored match_stored match_metadata args0 args1 =
        let rec map index args0 args1 =
          match (args0, args1) with
          | [], [] -> []
          | arg0 :: args0, arg1 :: args1 ->
              let arg =
                if is_stored index then match_stored arg0 arg1
                else match_metadata arg0 arg1
              in
              arg :: map (index + 1) args0 args1
          | _ -> [%craise_recover] recover span "Different generic argument arities"
        in
        map 0 args0 args1
      in
      let regions =
        map_args (projection_region_is_stored info) match_regions
          match_metadata_regions generics0.regions generics1.regions
      in
      let types =
        map_args (projection_type_is_stored info) match_rec
          match_metadata_types generics0.types generics1.types
      in
      let generics = { regions; types; const_generics; trait_refs } in
      TAdt { id; generics }
  | TArray (ty0, len0), TArray (ty1, len1) ->
      [%cassert_recover] recover span (len0 = len1)
        "Arrays with different lengths";
      TArray (match_rec ty0 ty1, len0)
  | TSlice ty0, TSlice ty1 -> TSlice (match_rec ty0 ty1)
  | TVar vid0, TVar vid1 ->
      [%cassert_recover] recover span (vid0 = vid1)
        "Not the same type variables";
      let vid = vid0 in
      TVar vid
  | TLiteral lty0, TLiteral lty1 ->
      [%cassert_recover] recover span (lty0 = lty1) "Not the same literal types";
      ty0
  | TNever, TNever -> ty0
  | TRef (r0, ty0, k0), TRef (r1, ty1, k1) ->
      let r = match_regions r0 r1 in
      let ty = match_rec ty0 ty1 in
      [%cassert_recover] recover span (k0 = k1) "Not the same reference kind";
      let k = k0 in
      TRef (r, ty, k)
  | TRawPtr (ty0, rk0), TRawPtr (ty1, rk1) ->
      [%cassert_recover] recover span (rk0 = rk1)
        "Not the same raw pointer types";
      let ty = match_rec ty0 ty1 in
      TRawPtr (ty, rk0)
  | TFnDef _, TFnDef _
  | TFnPtr _, TFnPtr _ -> match_metadata_types ty0 ty1
  | TDynTrait _, TDynTrait _ ->
      [%craise_recover] recover span "Not implemented yet"
  | TPtrMetadata ty0, TPtrMetadata ty1 ->
      let ty = match_rec ty0 ty1 in
      TPtrMetadata ty
  | _ -> match_distinct_types ty0 ty1

(** Transport a complete dependency through an established root/region mapping. *)
let rename_symbolic_pending_slot root_sv_id rename_region
    (slot : symbolic_pending_slot) : symbolic_pending_slot =
  let proj_ty = map_free_region_aliases rename_region slot.proj_ty in
  let proj_regions =
    RegionId.Set.fold
      (fun rid regions ->
        match rename_region (RVar (Free rid)) with
        | RVar (Free rid) -> RegionId.Set.add rid regions
        | _ -> raise (Distinct "Pending mask has no corresponding runtime region"))
      slot.proj_regions RegionId.Set.empty
  in
  { slot with root_sv_id; proj_ty; proj_regions }

module MakeMatcher (M : PrimMatcher) : Matcher = struct
  let span = M.span

  let rec match_tvalues (ctx0 : eval_ctx) (ctx1 : eval_ctx) (v0 : tvalue)
      (v1 : tvalue) : tvalue =
    [%ldebug
      "- v0: " ^ tvalue_to_string ctx0 v0 ^ "\n- v1: "
      ^ tvalue_to_string ctx1 v1];
    let match_rec = match_tvalues ctx0 ctx1 in
    let ty = M.match_etys ctx0 ctx1 v0.ty v1.ty in
    match (v0.value, v1.value) with
    | VLiteral lv0, VLiteral lv1 ->
        if lv0 = lv1 then v1
        else M.match_distinct_literals match_rec ctx0 ctx1 ty lv0 lv1
    | VAdt av0, VAdt av1 ->
        if av0.variant_id = av1.variant_id then
          let fields = List.combine av0.fields av1.fields in
          let fields = List.map (fun (f0, f1) -> match_rec f0 f1) fields in
          let value : value = VAdt { variant_id = av0.variant_id; fields } in
          { value; ty = v1.ty }
        else M.match_distinct_adts match_rec ctx0 ctx1 ty v0.ty av0 v1.ty av1
    | VBottom, VBottom -> v0
    | VBorrow (VMutBorrow (bid0, bv0)), VBorrow (VMutBorrow (bid1, bv1))
      when distinct_nested_mut_borrows span ctx0 ctx1 bid0 bv0 bid1 bv1 ->
        M.match_distinct_nested_mut_borrows match_rec ctx0 ctx1 ty bid0 bv0 bid1
          bv1
    | VBorrow bc0, VBorrow bc1 ->
        let bc =
          match (bc0, bc1) with
          | VSharedBorrow (bid0, sid0), VSharedBorrow (bid1, sid1) ->
              let bid, sid =
                M.match_shared_borrows match_rec ctx0 ctx1 ty bid0 sid0 bid1
                  sid1
              in
              VSharedBorrow (bid, sid)
          | VMutBorrow (bid0, bv0), VMutBorrow (bid1, bv1) ->
              let bv = match_rec bv0 bv1 in
              let bid, bv =
                M.match_mut_borrows match_rec ctx0 ctx1 ty bid0 bv0 bid1 bv1 bv
              in
              VMutBorrow (bid, bv)
          | VReservedMutBorrow (bid0, sid0), VReservedMutBorrow (bid1, sid1)
            when bid0 = bid1 ->
              (* Argument evaluation may branch between reserving a method
                 receiver and activating it. Both paths still reserve the
                 same shared loan: match its borrower identity without
                 activating it or turning it into an ordinary shared borrow.
                 The loan payload is matched at its owning occurrence. *)
              let bid, sid =
                M.match_shared_borrows match_rec ctx0 ctx1 ty bid0 sid0 bid1
                  sid1
              in
              VReservedMutBorrow (bid, sid)
          | VReservedMutBorrow _, _
          | _, VReservedMutBorrow _
          | VSharedBorrow _, VMutBorrow _
          | VMutBorrow _, VSharedBorrow _ ->
              (* Distinct reservations need activation before they can be
                 reconciled; mixing reservation/borrow kinds is not a shared
                 reborrow and must not manufacture independent ownership. *)
              [%craise_recover] M.recover M.span
                "Cannot match distinct reservations or different borrow kinds"
        in
        { value = VBorrow bc; ty }
    | VLoan lc0, VLoan lc1 -> begin
        match (lc0, lc1) with
        | VSharedLoan (id0, sv0), VSharedLoan (id1, sv1) ->
            M.match_shared_loans match_rec ctx0 ctx1 ty id0 id1 sv0 sv1
        | VMutLoan id0, VMutLoan id1 ->
            M.match_mut_loans match_rec ctx0 ctx1 ty id0 id1
        | VSharedLoan _, VMutLoan _ | VMutLoan _, VSharedLoan _ ->
            (* TODO: *)
            [%craise_recover] M.recover M.span "Unimplemented"
      end
    | VSymbolic sv0, VSymbolic sv1 ->
        (* Joining a symbolic value with itself introduces nothing, and the
           other supported nested borrows need no abstraction of a nested
           region depending on an outer one (see
           [symbolic_value_has_unsupported_nested_borrows]). *)
        let unsupported_nested ctx (sv : symbolic_value) =
          sv0 <> sv1
          && symbolic_value_has_unsupported_nested_borrows span ctx sv
        in
        [%cassert_recover] M.recover M.span
          (not (unsupported_nested ctx0 sv0))
          "Nested borrows are not supported yet.";
        [%cassert_recover] M.recover M.span
          (not (unsupported_nested ctx1 sv1))
          "Nested borrows are not supported yet.";
        (* Match *)
        M.match_symbolic_values match_rec ctx0 ctx1 sv0 sv1
    | VLoan (VMutLoan id), _ ->
        M.match_mut_loan_with_other match_rec ctx0 ctx1 ~loan_is_left:true ty id
          v1
    | _, VLoan (VMutLoan id) ->
        M.match_mut_loan_with_other match_rec ctx0 ctx1 ~loan_is_left:false ty
          id v0
    | VLoan (VSharedLoan (id, sv)), _ ->
        M.match_shared_loan_with_other match_rec ctx0 ctx1 ~loan_is_left:true ty
          id sv v1
    | _, VLoan (VSharedLoan (id, sv)) ->
        M.match_shared_loan_with_other match_rec ctx0 ctx1 ~loan_is_left:false
          ty id sv v0
    | VSymbolic sv, _ ->
        M.match_symbolic_with_other match_rec ctx0 ctx1 ~symbolic_is_left:true
          sv v1
    | _, VSymbolic sv ->
        M.match_symbolic_with_other match_rec ctx0 ctx1 ~symbolic_is_left:false
          sv v0
    | VBottom, _ ->
        M.match_bottom_with_other match_rec ctx0 ctx1 ~bottom_is_left:true v1
    | _, VBottom ->
        M.match_bottom_with_other match_rec ctx0 ctx1 ~bottom_is_left:false v0
    | _ ->
        [%ltrace
          "Unexpected match case:\n- value0: "
          ^ tvalue_to_string ~span:(Some M.span) ctx0 v0
          ^ "\n- value1: "
          ^ tvalue_to_string ~span:(Some M.span) ctx1 v1];
        [%craise_recover] M.recover M.span "Unexpected"

  and match_tavalues ~shared_shell_owners (ctx0 : eval_ctx) (ctx1 : eval_ctx)
      (v0 : tavalue) (v1 : tavalue) : tavalue =
    [%ldebug
      "- value0: "
      ^ tavalue_to_string ~span:(Some M.span) ctx0 v0
      ^ "\n- ty0: " ^ ty_to_string ctx0 v0.ty ^ "\n- value1: "
      ^ tavalue_to_string ~span:(Some M.span) ctx1 v1
      ^ "\n- ty1: " ^ ty_to_string ctx1 v1.ty];

    let match_rec = match_tvalues ctx0 ctx1 in
    let match_arec = match_tavalues ~shared_shell_owners ctx0 ctx1 in
    let ty =
      match (v0.value, v1.value) with
      | ASymbolic (_, APendingSymbolicLoans _),
        ASymbolic (_, APendingSymbolicLoans _) ->
          (* The dependency matcher checks these non-owning shells without
             creating a region correspondence from their types. *)
          v1.ty
      | ABorrow (ASharedBorrow _), ABorrow (ASharedBorrow _)
      | ALoan (ASharedLoan _), ALoan (ASharedLoan _) ->
          (* A shared reference shell owns its outer region, not the regions
             mentioned by its referent type. Referent ownership is checked
             through the loan payload and abstract child/projectors. In
             particular, an absent enum field may mention an ended region. *)
          ignore
            (M.match_etys ctx0 ctx1 (ty_erase_regions_with_metadata ctx0.type_ctx.type_infos ctx0.metadata_bindings v0.ty)
               (ty_erase_regions_with_metadata ctx1.type_ctx.type_infos ctx1.metadata_bindings v1.ty));
          let r0, _, kind0 = ty_get_ref v0.ty in
          let r1, referent1, kind1 = ty_get_ref v1.ty in
          (match shared_shell_owners with
          | Some (owned0, owned1) ->
              let () =
                [%cassert_recover] M.recover M.span
                  (kind0 = RShared && kind1 = RShared)
                  "An ordinary shared shell has a different reference kind"
              in
              let () =
                [%cassert_recover] M.recover M.span
                  (match r0, r1 with
                  | RVar (Free rid0), RVar (Free rid1) ->
                      RegionId.Set.mem rid0 owned0 && RegionId.Set.mem rid1 owned1
                  | _ -> false)
                  "An ordinary shared shell lies outside its current owner"
              in
              v1.ty
          | None ->
              let shell =
                M.match_rtys ctx0 ctx1
                  (mk_ref_ty r0 mk_unit_ty kind0)
                  (mk_ref_ty r1 mk_unit_ty kind1)
              in
              let region, _, kind = ty_get_ref shell in
              mk_ref_ty region referent1 kind)
      (* ```ocaml *)
      | ATransportedValue _, ATransportedValue _
      | ASymbolic (_, ATransportedProj _), ASymbolic (_, ATransportedProj _) ->
          v1.ty
      (* ``` *)
      | AIgnored _, AIgnored _
      | ABorrow (AProjSharedBorrow _), ABorrow (AProjSharedBorrow _)
      | ABorrow (AEndedMutBorrow _), ABorrow (AEndedMutBorrow _)
      | ABorrow AEndedSharedBorrow, ABorrow AEndedSharedBorrow
      | ABorrow (AEndedIgnoredMutBorrow _), ABorrow (AEndedIgnoredMutBorrow _)
      | ALoan (AEndedMutLoan _), ALoan (AEndedMutLoan _)
      | ALoan (AEndedIgnoredMutLoan _), ALoan (AEndedIgnoredMutLoan _)
      | ASymbolic (_, AEndedProjLoans _), ASymbolic (_, AEndedProjLoans _)
      | ASymbolic (_, AEndedProjBorrows _), ASymbolic (_, AEndedProjBorrows _)
      | ASymbolic (_, AEmpty), ASymbolic (_, AEmpty)
      | ALoan (AEndedSharedLoan _), ALoan (AEndedSharedLoan _) ->
          (* These shells carry no direct region ownership. Their operational
             payloads and explicit projections are still matched below. *)
          ignore
            (M.match_etys ctx0 ctx1 (ty_erase_regions_with_metadata ctx0.type_ctx.type_infos ctx0.metadata_bindings v0.ty)
               (ty_erase_regions_with_metadata ctx1.type_ctx.type_infos ctx1.metadata_bindings v1.ty));
          v1.ty
      | ABorrow (ASharedBorrow _), ABorrow (AProjSharedBorrow (_, [ AsbBorrow _ ]))
        ->
          (* See the matching of the values below: the projection's type is the
             type of the value it projects (e.g., [&'a &'b T] for the borrow of
             region ['b]), not the type of the borrow. *)
          v0.ty
      | ABorrow (AProjSharedBorrow (_, [ AsbBorrow _ ])), ABorrow (ASharedBorrow _)
        ->
          v1.ty
      | _ -> M.match_rtys ctx0 ctx1 v0.ty v1.ty
    in
    match (v0.value, v1.value) with
    | ASymbolic (pm0, APendingSymbolicLoans slot0),
      ASymbolic (pm1, APendingSymbolicLoans slot1) ->
        M.match_apending_symbolic_loans ctx0 ctx1 pm0 slot0 pm1 slot1 v0.ty v1.ty
    (* ```ocaml *)
    | ATransportedValue (transport0, child0),
      ATransportedValue (transport1, child1) ->
        [%cassert_recover] M.recover M.span
          (transport0.receiver_regions = transport1.receiver_regions)
          "Carrier coordinate receivers differ";
        let shared_shell_owners =
          match shared_shell_owners with
          | None -> None
          | Some _ -> Some (transport0.current_regions, transport1.current_regions)
        in
        let child =
          match_tavalues ~shared_shell_owners ctx0 ctx1 child0 child1
        in
        { value = ATransportedValue (transport1, child); ty }
    (* ``` *)
    | AAdt av0, AAdt av1 ->
        [%ldebug "Matching ADTs"];
        if av0.variant_id = av1.variant_id && av0.borrow_proj = av1.borrow_proj
        then
          let borrow_proj = av0.borrow_proj in
          let fields = List.combine av0.fields av1.fields in
          let fields = List.map (fun (f0, f1) -> match_arec f0 f1) fields in
          let value : avalue =
            AAdt { borrow_proj; variant_id = av0.variant_id; fields }
          in
          { value; ty }
        else (* Merge *)
          M.match_distinct_aadts match_rec ctx0 ctx1 v0.ty av0 v1.ty av1 ty
    | AIgnored _, AIgnored _ -> mk_aignored M.span ctx0.type_ctx.type_infos ty None
    | ABorrow bc0, ABorrow bc1 -> (
        [%ldebug "borrows"];
        match (bc0, bc1) with
        | ASharedBorrow (pm0, bid0, sid0), ASharedBorrow (pm1, bid1, sid1) ->
            [%ldebug "shared borrows"];
            M.match_ashared_borrows match_rec ctx0 ctx1 v0.ty pm0 bid0 sid0
              v1.ty pm1 bid1 sid1 ty
        | AMutBorrow (pm0, bid0, av0), AMutBorrow (pm1, bid1, av1) ->
            [%ldebug "mut borrows"];
            [%ldebug "mut borrows: matching children values"];
            let av = match_arec av0 av1 in
            [%ldebug "mut borrows: matched children values"];
            M.match_amut_borrows match_rec ctx0 ctx1 v0.ty pm0 bid0 av0 v1.ty
              pm1 bid1 av1 ty av
        | AIgnoredMutBorrow (bid0, child0), AIgnoredMutBorrow (bid1, child1) ->
            let child = match_arec child0 child1 in
            M.match_aignored_mut_borrow match_rec ctx0 ctx1
              (v0.ty, bid0, child0) (v1.ty, bid1, child1) ty child
        | ( AEndedIgnoredMutBorrow
              ({ child = child0; given_back = given_back0; given_back_meta = _ }
               as bc0),
            AEndedIgnoredMutBorrow
              ({ child = child1; given_back = given_back1; given_back_meta = _ }
               as bc1) ) ->
            let child = match_arec child0 child1 in
            let given_back = match_arec given_back0 given_back1 in
            M.match_aended_ignored_mut_borrow match_rec ctx0 ctx1 (v0.ty, bc0)
              (v1.ty, bc1) ty child given_back
        | ASharedBorrow (pm0, bid0, sid0), AProjSharedBorrow (pm1, [ AsbBorrow (bid1, sid1) ])
        | AProjSharedBorrow (pm0, [ AsbBorrow (bid0, sid0) ]), ASharedBorrow (pm1, bid1, sid1)
          ->
            (* One context holds the shared borrow of a loan in the region of
               the abstraction as a plain borrow, the other as the projection of
               a value holding only that borrow: the same ownership (see the
               merge of such a pair in {!InterpAbs.merge_abstractions}, which
               turns it into a plain borrow). E.g., the collapse of the join of
               a loop fixed point with a context whose call projected a
               captured [&'a &'b str] merges the borrow of the fixed point with
               the projection of the target; the target context, projected
               before the collapse, keeps the projection. Both end the same
               shared borrow and give nothing back. *)
            M.match_ashared_borrows match_rec ctx0 ctx1 v0.ty pm0 bid0 sid0
              v1.ty pm1 bid1 sid1 ty
        | AProjSharedBorrow (pm0, asb0), AProjSharedBorrow (pm1, asb1) ->
            [%sanity_check_recover] M.recover M.span (pm0 = pm1);
            [%sanity_check_recover] M.recover M.span
              (List.length asb0 = List.length asb1);
            let asb =
              List.map2
                (fun b0 b1 ->
                  match (b0, b1) with
                  | AsbBorrow (bid0, sid0), AsbBorrow (bid1, sid1) -> (
                      let av =
                        M.match_ashared_borrows match_rec ctx0 ctx1 v0.ty PNone
                          bid0 sid0 v1.ty PNone bid1 sid1 ty
                      in
                      match av.value with
                      | ABorrow (ASharedBorrow (_, bid, sid)) ->
                          AsbBorrow (bid, sid)
                      | _ -> [%internal_error] M.span)
                  | AsbProjReborrows proj0, AsbProjReborrows proj1 -> (
                      let proj_ty =
                        M.match_rtys ctx0 ctx1 proj0.proj_ty proj1.proj_ty
                      in
                      let av =
                        M.match_aproj_borrows match_rec ctx0 ctx1 proj0.proj_ty
                          PNone
                          { proj = proj0; loans = [] }
                          proj1.proj_ty PNone
                          { proj = proj1; loans = [] }
                          proj_ty proj_ty
                      in
                      match av.value with
                      | ASymbolic (_, AProjBorrows { proj; _ }) ->
                          AsbProjReborrows proj
                      | _ -> [%internal_error] M.span)
                  | _ ->
                      [%craise_recover] M.recover M.span
                        "Distinct shared reborrow projections")
                asb0 asb1
            in
            { value = ABorrow (AProjSharedBorrow (pm0, asb)); ty }
        | AEndedMutBorrow (_, child0), AEndedMutBorrow (meta1, child1) ->
            let child = match_arec child0 child1 in
            { value = ABorrow (AEndedMutBorrow (meta1, child)); ty }
        | AEndedSharedBorrow, AEndedSharedBorrow ->
            { value = ABorrow AEndedSharedBorrow; ty }
        | _ ->
            (* TODO: getting there is not necessarily inconsistent (it may
               just be because the environments don't match) so we may want
               to call a specific function (which could raise the proper
               exception).
            *)
            [%craise_recover] M.recover M.span "Unexpected")
    | ALoan lc0, ALoan lc1 -> (
        [%ldebug "loans"];
        (* TODO: maybe we should enforce that the ids are always exactly the same -
           without matching *)
        match (lc0, lc1) with
        | ASharedLoan (pm0, id0, sv0, av0), ASharedLoan (pm1, id1, sv1, av1) ->
            [%ldebug "shared loans"];
            let sv = match_rec sv0 sv1 in
            let av = match_arec av0 av1 in
            M.match_ashared_loans match_rec ctx0 ctx1 v0.ty pm0 id0 sv0 av0
              v1.ty pm1 id1 sv1 av1 ty sv av
        | AEndedSharedLoan (pm0, sv0, av0), AEndedSharedLoan (pm1, sv1, av1) ->
            (* The outer loan has ended, but its retained payload can still
               own live nested loans. Match those and the child structurally;
               unlike EValue snapshots this is operational state. *)
            [%sanity_check_recover] M.recover M.span (pm0 = pm1);
            let sv = match_rec sv0 sv1 in
            let av = match_arec av0 av1 in
            { value = ALoan (AEndedSharedLoan (pm0, sv, av)); ty }
        | AMutLoan (pm0, id0, av0), AMutLoan (pm1, id1, av1) ->
            [%ldebug "mut loans"];
            [%ldebug "mut loans: matching children values"];
            let av = match_arec av0 av1 in
            [%ldebug "mut loans: matched children values"];
            M.match_amut_loans match_rec ctx0 ctx1 v0.ty pm0 id0 av0 v1.ty pm1
              id1 av1 ty av
        | AEndedMutLoan l0, AEndedMutLoan l1 ->
            let child = match_arec l0.child l1.child in
            let given_back = match_arec l0.given_back l1.given_back in
            { value = ALoan (AEndedMutLoan { l1 with child; given_back }); ty }
        | AEndedIgnoredMutLoan l0, AEndedIgnoredMutLoan l1 ->
            let child = match_arec l0.child l1.child in
            let given_back = match_arec l0.given_back l1.given_back in
            {
              value = ALoan (AEndedIgnoredMutLoan { l1 with child; given_back });
              ty;
            }
        | AIgnoredMutLoan (pm0, bid0, child0), AIgnoredMutLoan (pm1, bid1, child1) ->
            (* Nested borrows: the abstraction of the inner region of a
               [&'a mut C<'b>] lends the inner borrows of the value it gave to
               the region ['a] (see {!InterpBorrows.destructure_abs}) *)
            let child = match_arec child0 child1 in
            M.match_aignored_mut_loan match_rec ctx0 ctx1
              (v0.ty, pm0, bid0, child0) (v1.ty, pm1, bid1, child1) ty child
        | AIgnoredSharedLoan child0, AIgnoredSharedLoan child1 ->
            (* Nested borrows: a destructured abstraction may hold an ignored
               shared loan nested in another value (e.g., the shared loan of a
               closure captured by shared reference, which captures a shared
               reference, in a field of the ignored loan of the reborrow of the
               visiting closure, see
               [InterpAbs.merge_abstractions_merge_loan_borrow_pairs]). It has
               no id: match the children *)
            let child = match_arec child0 child1 in
            { value = ALoan (AIgnoredSharedLoan child); ty }
        | _ -> [%craise_recover] M.recover M.span "Unreachable")
    | ASymbolic (pm0, proj0), ASymbolic (pm1, proj1) ->
        [%ldebug "Matching symbolic avalues"];
        [%sanity_check_recover] M.recover M.span (pm0 = pm1);
        (* Metadata records past transfers, not current ownership. Preserve
           the target history while matching every operational descendant at
           its original position and abstraction level. *)
        let match_children children0 children1 =
          [%sanity_check_recover] M.recover M.span
            (List.length children0 = List.length children1);
          let child_ty fallback = function
            (* ```ocaml *)
            | ATransportedProj (transport, _) -> transport.current.sv_ty
            (* ``` *)
            | AProjLoans p -> p.proj.proj_ty
            | AProjBorrows p -> p.proj.proj_ty
            | APendingLoans _ | APendingSymbolicLoans _
            | AEndedProjLoans _ | AEndedProjBorrows _ | AEmpty -> fallback
          in
          List.map2
            (fun (_, child0) (meta1, child1) ->
              let child =
                match_arec
                  {
                    value = ASymbolic (pm0, child0);
                    ty = child_ty v0.ty child0;
                  }
                  {
                    value = ASymbolic (pm1, child1);
                    ty = child_ty v1.ty child1;
                  }
              in
              match child.value with
              | ASymbolic (_, proj) -> (meta1, proj)
              | _ -> [%internal_error] M.span)
            children0 children1
        in
        let value =
          match (proj0, proj1) with
          (* ```ocaml *)
          | ATransportedProj (transport0, child0),
            ATransportedProj (transport1, child1) ->
              [%cassert_recover] M.recover M.span
                (transport0.receiver_regions = transport1.receiver_regions)
                "Carrier coordinate receivers differ";
              let shared_shell_owners =
                match shared_shell_owners with
                | None -> None
                | Some _ ->
                    Some (transport0.current_regions, transport1.current_regions)
              in
              let child = match_tavalues ~shared_shell_owners ctx0 ctx1
                { value = ASymbolic (pm0, child0); ty = transport0.current.sv_ty }
                { value = ASymbolic (pm1, child1); ty = transport1.current.sv_ty } in
              (match child.value with
              | ASymbolic (_, child) ->
                  ASymbolic (pm1, ATransportedProj (transport1, child))
              | _ -> [%internal_error] M.span)
          (* ``` *)
          | AProjBorrows p0, AProjBorrows p1 -> (
              let proj_ty =
                M.match_rtys ctx0 ctx1 p0.proj.proj_ty p1.proj.proj_ty
              in
              let root =
                M.match_aproj_borrows match_rec ctx0 ctx1 v0.ty pm0
                  { p0 with loans = [] } v1.ty pm1 { p1 with loans = [] } ty
                  proj_ty
              in
              let loans = match_children p0.loans p1.loans in
              match root.value with
              | ASymbolic (pm, AProjBorrows p) ->
                  ASymbolic (pm, AProjBorrows { p with loans })
              | _ -> [%internal_error] M.span)
          | AProjLoans p0, AProjLoans p1 -> (
              let proj_ty =
                M.match_rtys ctx0 ctx1 p0.proj.proj_ty p1.proj.proj_ty
              in
              let root =
                M.match_aproj_loans match_rec ctx0 ctx1 v0.ty pm0
                  { p0 with consumed = []; borrows = [] }
                  v1.ty pm1
                  { p1 with consumed = []; borrows = [] }
                  ty proj_ty
              in
              let consumed = match_children p0.consumed p1.consumed in
              let borrows = match_children p0.borrows p1.borrows in
              match root.value with
              | ASymbolic (pm, AProjLoans p) ->
                  ASymbolic (pm, AProjLoans { p with consumed; borrows })
              | _ -> [%internal_error] M.span)
          | AEndedProjLoans p0, AEndedProjLoans p1 ->
              let consumed = match_children p0.consumed p1.consumed in
              let borrows = match_children p0.borrows p1.borrows in
              ASymbolic (pm1, AEndedProjLoans { p1 with consumed; borrows })
          | AEndedProjBorrows p0, AEndedProjBorrows p1 ->
              let loans = match_children p0.loans p1.loans in
              ASymbolic (pm1, AEndedProjBorrows { p1 with loans })
          | APendingLoans bid0, APendingLoans bid1 ->
              (M.match_apending_loans pm0 bid0 pm1 bid1 ty).value
          | AEmpty, AEmpty -> ASymbolic (pm1, AEmpty)
          | _ -> [%craise_recover] M.recover M.span "Distinct projector shapes"
        in
        { value; ty }
    | _ ->
        [%ldebug "default case"];
        M.match_avalues match_rec ctx0 ctx1 v0 v1
end

module MakeJoinMatcher (S : MatchJoinState) = struct
  (** Small utility *)
  let span = S.span

  let recover = S.recover
  let retain_metadata (ctx : eval_ctx) bindings =
      let bindings =
        merge_metadata_bindings (Some span) !S.metadata_bindings bindings
      in
      let () = S.metadata_bindings := bindings in
      ctx_with_metadata_bindings ctx bindings
    let push_abs (abs : abs) : unit = S.nabs := abs :: !S.nabs
  let push_absl (absl : abs list) : unit = List.iter push_abs absl

  (** Cache for joined symbolic values: when the same pair [(id0, id1)] of
      source/target symbolic value ids is encountered more than once, we reuse
      the previously created fresh symbolic value. This ensures that values
      which are shared in both the source and target contexts remain shared
      after the join.

      Note that it happens that symbolic values can get duplicated when
      performing copies. *)
  let joined_sv_cache :
(* ```ocaml *)
      (SymbolicValueId.id * SymbolicValueId.id, tvalue) Hashtbl.t =
    Hashtbl.create 16

  (** Cache for joined shared loans: when borrows of the same pair [(bid0, bid1)]
      of distinct source/target shared loans are encountered more than once
      (e.g., [x -> Some (SB l0), y -> SB l0] and
      [x -> Some (SB l1), y -> SB l1]), they all borrow the joined loan
      introduced for the first one. Introducing a loan per borrow would split
      a loan which is shared by several borrows in both contexts, and the
      joined context would no longer match them. *)
  let joined_shared_loan_cache : (BorrowId.id * BorrowId.id, BorrowId.id) Hashtbl.t
      =
    Hashtbl.create 16

  (* A shared payload can remain live in another branch or owner.
     Its copied borrowers need distinct occurrence identifiers. *)
  let matching_shared_copy = ref false

  (*
```ocaml
  *)
  let prepare_shared_payload ~merge_lender (ctx : eval_ctx) (v : tvalue) : tvalue =
    let copy =
      object (self)
        inherit [_] map_tvalue as super

        method! visit_VSharedBorrow _ bid _ =
          VSharedBorrow (bid, ctx.fresh_shared_borrow_id ())

        method! visit_tvalue env v =
          match v.value with
          | VLoan (VSharedLoan (_, child)) ->
              if merge_lender then super#visit_tvalue env v
              else self#visit_tvalue env child
          | VLoan (VMutLoan _) | VBorrow (VMutBorrow _)
            when merge_lender -> super#visit_tvalue env v
          | VLoan (VMutLoan _) | VBorrow (VMutBorrow _ | VReservedMutBorrow _)
            ->
              [%craise_recover] S.recover span
                "Cannot copy exclusive ownership through a shared payload"
          | VSymbolic sv ->
              [%cassert_recover] S.recover span
                (merge_lender || not (ty_has_mut_borrows ctx.type_ctx.type_infos sv.sv_ty))
                "Cannot copy symbolic mutable borrows through a shared payload";
              [%cassert_recover] S.recover span
                (not (symbolic_value_has_ended_regions ctx.type_ctx.type_infos ctx.ended_regions sv))
                "Cannot copy ended borrows through a shared payload";
              v
          | _ -> super#visit_tvalue env v
      end
    in
    copy#visit_tvalue () v

  let match_shared_payloads ~merge_lender match_rec ctx0 ctx1 sv0 sv1 =
    let was_shared_copy = !matching_shared_copy in
    Fun.protect
      ~finally:(fun () -> matching_shared_copy := was_shared_copy)
      (fun () ->
        let () = matching_shared_copy := true in
        match_rec
          (prepare_shared_payload ~merge_lender ctx0 sv0)
          (prepare_shared_payload ~merge_lender ctx1 sv1))
  (*
```
  *)

  let shared_copy_projector (ctx : eval_ctx) (av : tavalue) : tavalue =
    if not !matching_shared_copy then av
    else
      match av.value with
      | ASymbolic (pm, AProjBorrows p)
        when p.loans = [] && not (ty_has_mut_borrows ctx.type_ctx.type_infos p.proj.proj_ty) ->
          let proj = p.proj in
          (* The source symbol remains in its original loan. Reborrow its
             shared projection instead of consuming that occurrence. *)
          let ty =
            mk_ref_ty
              (RVar (Free (ctx.fresh_region_id ())))
              proj.proj_ty RShared
          in
          {
            value = ABorrow (AProjSharedBorrow (pm, [ AsbProjReborrows proj ]));
            ty;
          }
      | _ -> av

  let add_symbolic_value (sv_id : SymbolicValueId.id) (left : tvalue)
      (right : tvalue) : unit =
    (*
    ```ocaml
    *)
    let log = Logging.carrier_events_log in
    [%ldebug "Source ABI predecessor registration:"
      ^ "\njoined root: " ^ SymbolicValueId.to_string sv_id
      ^ "\nraw left predecessor: " ^ Values.show_tvalue left
      ^ "\nraw right predecessor: " ^ Values.show_tvalue right
      ^ "\nmetadata bindings: "
      ^ carrier_metadata_bindings !S.metadata_bindings];
    (*
    ```
    *)
    S.symbolic_to_value :=
      SymbolicValueId.Map.add sv_id (left, right) !S.symbolic_to_value

  let add_fresh_symbolic_value_from_no_regions_ty (ctx : eval_ctx) ty
      (left : tvalue) (right : tvalue) : tvalue =
    let sv = mk_fresh_symbolic_tvalue_from_no_regions_ty span ctx ty in
    let sv_id = [%add_loc] symbolic_tvalue_get_id span sv in
    add_symbolic_value sv_id left right;
    sv

  let add_fresh_symbolic_value (ctx : eval_ctx) ty (left : tvalue)
      (right : tvalue) : tvalue =
    let sv = mk_fresh_symbolic_tvalue span ctx ty in
    let sv_id = [%add_loc] symbolic_tvalue_get_id span sv in
    add_symbolic_value sv_id left right;
    sv

  let match_etys _ _ ty0 ty1 =
    [%sanity_check_recover] S.recover span (ty0 = ty1);
    ty0

  let match_rtys _ _ ty0 ty1 =
    (* The types must be equal - in effect, this forbids to match symbolic
       values containing borrows *)
    [%sanity_check_recover] S.recover span (ty0 = ty1);
    ty0

  let match_distinct_literals (_ : tvalue_matcher) (ctx0 : eval_ctx)
      (_ : eval_ctx) (ty : ety) (v0 : literal) (v1 : literal) : tvalue =
    add_fresh_symbolic_value_from_no_regions_ty ctx0 ty
      { value = VLiteral v0; ty }
      { value = VLiteral v1; ty }

  (* Helper *)
  let no_loans_no_bottoms_to_symbolic_value_with_borrows (ctx0 : eval_ctx)
      (ctx1 : eval_ctx) (v0 : tvalue) (v1 : tvalue) : tvalue =
    [%sanity_check_recover] S.recover span (not (tvalue_has_loans v0));
    [%sanity_check_recover] S.recover span (not (tvalue_has_bottom ctx0 v0));
    [%sanity_check_recover] S.recover span (not (tvalue_has_loans v1));
    [%sanity_check_recover] S.recover span (not (tvalue_has_bottom ctx1 v1));

    (* Introduce a fresh region id for each erased region appearing in the type.

       TODO: we might have to do some unification to determine whether some
       regions should be equal or not. *)
    let fresh_regions, ty_with_regions, bindings =
      ty_refresh_regions_with_metadata (Some span) ctx0.type_ctx.type_infos
        ctx0.fresh_region_id !S.metadata_bindings v0.ty
    in
    let ctx0 = retain_metadata ctx0 bindings in
    let ctx1 = ctx_with_metadata_bindings ctx1 bindings in

    (* Introduce a fresh symbolic value for the join *)
    let sv = add_fresh_symbolic_value ctx0 ty_with_regions v0 v1 in
    let sv_s = tvalue_as_symbolic span sv in

    (* Project the ADTs into different region abstractions. With nested
       borrows, the abstraction of a region nested in the borrows of another
       region depends on the abstraction of that region: it is its child (like
       the region groups of a function call), because its borrows can only end
       once the outer borrow has given back the value holding them. *)
    let abs_ids =
      List.map (fun rid -> (rid, ctx0.fresh_abs_id ())) fresh_regions
    in
    let parents (rid : RegionId.id) : AbsId.Set.t =
      List.fold_left
        (fun parents (rid', abs_id') ->
          if
            rid' <> rid
            && RegionId.Set.mem rid
                 (TypesAnalysis.compute_outlive_proj_ty (Some span)
                    ctx0.type_ctx.type_decls
                    ctx0.type_ctx.type_infos
                    (RegionId.Set.singleton rid')
                    ty_with_regions)
          then AbsId.Set.add abs_id' parents
          else parents)
        AbsId.Set.empty abs_ids
    in
    let project (rid : RegionId.id) =
      let regions = RegionId.Set.singleton rid in
      let avl0, output0 =
        convert_value_to_output_avalues span ctx0 PLeft v0 regions
          ty_with_regions
      in
      let avl1, output1 =
        convert_value_to_output_avalues span ctx1 PRight v1 regions
          ty_with_regions
      in
      let avl0 = List.map (shared_copy_projector ctx0) avl0 in
      let avl1 = List.map (shared_copy_projector ctx0) avl1 in
      let av : tavalue =
        let proj : symbolic_proj =
          { sv_id = sv_s.sv_id; proj_ty = ty_with_regions }
        in
        let value =
          ASymbolic (PNone, AProjLoans { proj; consumed = []; borrows = [] })
        in
        { value; ty = ty_with_regions }
      in

      (* Create the abstraction expression *)
      let cont : abs_cont option =
        if S.with_abs_conts then
          (* Only the mutable borrows of the projected region give values
             back: a region which only appears under shared borrows (e.g.,
             the ['a] of a closure capturing [&'a T] and [&'b mut U]) has an
             empty continuation, like the loan projections of the loop
             abstractions it is later merged with. *)
          if
            TypesUtils.ty_has_mut_borrow_for_region_in_set
              ctx0.type_ctx.type_infos regions ty_with_regions
          then
            (* We used to generate a continuation of the following shape:
               {[
                 join(|(s0 <: Option<&'a mut (T)>)|, Option::Some (︙MB l0))︙) :=
                 ⌊s1 <: Option<&'a mut (T)>⌋
               ]}

               but joins in abstraction outputs are a bit annoying to handle
               when merging continuations, so now we generate something like this:

               {[
                 (|(s0 <: Option<&'a mut (T)>)|, Option::Some (︙MB l0))︙) :=
                 let x := ⌊s1 <: Option<&'a mut (T)>⌋ in
                 (x, x)
               ]}

               TODO: generalize the merge of continuations and revert the changes.
            *)
            let input : tevalue =
              let proj : esymbolic_proj =
                { sv_id = sv_s.sv_id; proj_ty = ty_with_regions }
              in
              let value =
                ESymbolic
                  (PNone, EProjLoans { proj; consumed = []; borrows = [] })
              in
              let input = { value; ty = ty_with_regions } in

              (* Create the let-binding *)
              let fvar = mk_fresh_abs_fvar ty_with_regions in
              let pair = mk_etuple ~borrow_proj:false [ fvar; fvar ] in
              let pat = mk_epat_from_fvar fvar in
              mk_let span regions pat input pair
            in

            let output =
              mk_simpl_etuple ~borrow_proj:true [ output0; output1 ]
            in
            Some { output = Some output; input = Some input }
          else
            Some
              {
                output = Some (mk_simpl_etuple ~borrow_proj:true []);
                input = Some (mk_simpl_etuple ~borrow_proj:false []);
              }
        else None
      in

      (* Generate the abstraction *)
      let abs =
        {
          abs_id = List.assoc rid abs_ids;
          kind = S.fresh_abs_kind;
          can_end = true;
          parents = parents rid;
          regions = { owned = RegionId.Set.singleton rid };
          ended_subabs = AbsLevelSet.empty;
          avalues = avl0 @ avl1 @ [ av ];
(*
```ocaml
*)
          call_scopes = [];
(*
```
*)
          cont;
        }
      in
      [%ldebug "Pushing abs:\n" ^ abs_to_string span ctx0 abs];
      push_abs abs
    in
    List.iter project fresh_regions;

    (* *)
    sv

  (* Helper *)
  let to_symbolic_value_with_borrows (ctx0 : eval_ctx) (ctx1 : eval_ctx)
      (v0 : tvalue) (v1 : tvalue) : tvalue =
    if tvalue_has_bottom ctx0 v0 || tvalue_has_bottom ctx1 v1 then (
      (* We have to pay attention to the case where we need to join a value containing *outer*
         loans with a value containing bottoms. For instance, when joining:
         {[
           v -> bottom   U   v -> SL l 0
         ]}

         A problem is that we can't move [SL l 0] to a region abstraction or an
         anonymous values, because it is an **outer** loan: doing so would allow the
         loan to live indefinitely, and in particuler we would be allowed to
         overwrite [v] without ending it.

         A possibility is to force [l] to end, but then it might lead to a borrow
         checking issue later on, when trying to use the borrow [l]. Our solution is
         to use a shared loan containing the value bottom, leading to the following
         environment:

         {[
           v -> SL l' bottom
           abs { SB l', SL l 0 }
         ]}

         This way, the borrow [l] is preserved, but upon overwriting [v] we have to
         en [l'], which in turns requires ending [l]. We also can't *read* from [v],
         because after we ended the loan, [v] maps to [bottom] (we can only write to
         it). Also note that the shared borrow [l'] can't be used in any way (in
         particular, it can't be dereferenced).

         Finally, this solution works for mutable borrows/loans:
         {[
           v -> bottom   U   v -> ML l

             ~>

           v -> SL l' bottom
           abs { SB l', ML l }
         ]} *)
      let has_outer_loans =
        tvalue_has_outer_loans v0 || tvalue_has_outer_loans v1
      in
      (* Move the values to region abstractions *)
      let abs_kind = S.fresh_abs_kind in
      let to_absl pm ctx v =
        let absl, bindings = convert_value_to_abstractions span abs_kind ~can_end:true ctx v in let ctx = retain_metadata ctx bindings in List.concat_map
          (abs_add_marker span ~loop_level_outputs:S.loop_level_outputs ctx pm)
          absl
      in
      let absl = to_absl PLeft ctx0 v0 @ to_absl PRight ctx1 v1 in
      (* If there are outer loans, wrap the bottom inside a shared loan, and add
         a corresponding borrow to all the region abstractions *)
      let v = mk_bottom span ctx0.type_ctx.type_infos (ty_erase_regions_with_metadata ctx0.type_ctx.type_infos ctx0.metadata_bindings v0.ty) in
      let v, absl =
        if has_outer_loans then
          let lid = ctx0.fresh_borrow_id () in
          let referent, bindings = unowned_rty_of_ety span ctx0 v0.ty in
          let _ = retain_metadata ctx0 bindings in
          let absl =
            List.map
              (fun (abs : abs) ->
                let rid = RegionId.Set.choose abs.regions.owned in
                let sb : tavalue =
                  {
                    value =
                      ABorrow
                        (ASharedBorrow
                           (PNone, lid, ctx0.fresh_shared_borrow_id ()));
                    ty = TRef (RVar (Free rid), referent, RShared);
                  }
                in
                { abs with avalues = sb :: abs.avalues })
              absl
          in
          let v : tvalue =
            { value = VLoan (VSharedLoan (lid, v)); ty = v.ty }
          in
          (v, absl)
        else (v, absl)
      in
      List.iter push_abs absl;
      v)
    else if tvalue_has_outer_loans v0 || tvalue_has_outer_loans v1 then (
      (* Note the values can't contain bottoms (the case where they contain
         bottom values is handled above) *)
      (* We put everything in the same region *)
      let rid = ctx0.fresh_region_id () in
      let rty0, bindings0 = retained_value_rty span ctx0 v0 in
      let ctx0 = retain_metadata ctx0 bindings0 in
      let avl0, input0, bindings0, owned0 =
        convert_value_to_input_avalues span ctx0 PLeft v0 rid
          rty0
      in
      let ctx0 = retain_metadata ctx0 bindings0 in
      let rty1, bindings1 = retained_value_rty span ctx1 v1 in
      let ctx1 = retain_metadata ctx1 bindings1 in
      let avl1, input1, bindings1, owned1 =
        convert_value_to_input_avalues span ctx1 PRight v1 rid
          rty1
      in
      let ctx1 = retain_metadata ctx1 bindings1 in
      let _, ty, bindings =
        ty_refresh_regions_with_metadata (Some span) ctx0.type_ctx.type_infos
          (fun _ -> rid) !S.metadata_bindings v0.ty
      in
      let ctx0 = retain_metadata ctx0 bindings in
      let ctx1 = ctx_with_metadata_bindings ctx1 bindings in
      let owned = RegionId.Set.union owned0 owned1 in

      let lid = ctx0.fresh_borrow_id () in
      if tvalue_has_mutable_loans v0 || tvalue_has_mutable_loans v1 then (
        [%cassert_recover] S.recover span
          (ty_no_regions ctx0.type_ctx.type_infos v0.ty)
          "Not implemented yet";
        let ref_ty = mk_ref_ty (RVar (Free rid)) ty RMut in
        let av : tavalue =
          let value =
            ABorrow (AMutBorrow (PNone, lid, mk_aignored span ctx0.type_ctx.type_infos ty None))
          in
          { value; ty = ref_ty }
        in
        let output : tevalue =
          let value = EBorrow (EMutBorrow (PNone, lid, mk_eignored ty)) in
          { value; ty = ref_ty }
        in
        let input : tevalue =
          (* We need this to make sure no values are filtered when translating *)
          let wrap (v : tevalue) : tevalue =
            { value = EMutBorrowInput v; ty = ref_ty }
          in
          let value = EJoinMarkers (wrap input0, wrap input1) in
          let ty = input0.ty in
          { value; ty }
        in

        (* Create the abstraction expression *)
        let cont : abs_cont option =
          if S.with_abs_conts then
            Some { output = Some output; input = Some input }
          else None
        in

        let abs =
          {
            abs_id = ctx0.fresh_abs_id ();
            kind = S.fresh_abs_kind;
            can_end = true;
            parents = AbsId.Set.empty;
            regions = { owned };
            ended_subabs = AbsLevelSet.empty;
            avalues = av :: (avl0 @ avl1);
(*
```ocaml
*)
            call_scopes = [];
(*
```
*)
            cont;
          }
        in
        push_abs abs;

        let value = VLoan (VMutLoan lid) in
        let ty = v0.ty in
        { value; ty })
      else (
        [%ldebug
          "- v0:\n" ^ tvalue_to_string ctx0 v0 ^ "\n\n- v1:\n"
          ^ tvalue_to_string ctx1 v1];
        (* Case where there are only shared loans. The values may hold
           shared borrows (e.g., the payload [E (SL l (s : Vec<&'a u32>))] of
           a shared reborrow of [&'b NM<'a>] after a match which borrows a
           field). *)
        if
          (tvalue_has_shared_loans v0 || tvalue_has_shared_loans v1)
          && (not (tvalue_has_mutable_loans v0))
          && (not (tvalue_has_mutable_loans v1))
          && (not (value_has_mut_borrows (Some span) ctx0 v0.value))
          && not (value_has_mut_borrows (Some span) ctx1 v1.value)
        then (
          (* The outer region holds the joined borrow and original loans.
             The child owns the stored payload regions and their source
             projections. It keeps those regions and callable metadata
             separate from the lifetime of the outer shared loan. *)
          let is_loan (av : tavalue) =
            match av.value with
            | ALoan _ -> true
            | _ -> false
          in
          let nested = not (ty_no_regions ctx0.type_ctx.type_infos v0.ty) in
          let nested_rid = if nested then ctx0.fresh_region_id () else rid in
          let payload_regions, payload_ty, bindings =
            ty_refresh_regions_with_metadata (Some span)
              ctx0.type_ctx.type_infos ctx0.fresh_region_id
              !S.metadata_bindings v0.ty
          in
          let ctx0 = retain_metadata ctx0 bindings in
          let ctx1 = ctx_with_metadata_bindings ctx1 bindings in
          let ref_ty = mk_ref_ty (RVar (Free rid)) payload_ty RShared in
          let av : tavalue =
            let value =
              ABorrow
                (ASharedBorrow (PNone, lid, ctx0.fresh_shared_borrow_id ()))
            in
            { value; ty = ref_ty }
          in
          let sv = add_fresh_symbolic_value ctx0 payload_ty v0 v1 in
          let nested_regions = RegionId.Set.of_list payload_regions in
          let nested_borrows pm ctx v =
            (* Outside of the loans, the join consumes the nested borrows of
               the value (see [convert_value_to_input_avalues]) *)
            let rty, bindings = retained_value_rty span ctx v in
            let ctx = retain_metadata ctx bindings in
            let avl, _, bindings, owned =
              convert_value_to_input_avalues span ctx pm v nested_rid rty
            in
            let ctx = retain_metadata ctx bindings in
            let outside = List.filter (fun av -> not (is_loan av)) avl in
            (* The loans keep their payloads in the abstraction of [rid]: their
               nested borrows are reborrowed (shared), as for a copy of a
               shared payload (see [shared_copy_projector]) *)
            let rec inside (v : tvalue) (ty : ty) : abstract_shared_borrows =
              match (v.value, ty) with
              | VAdt adt, TAdt { id; generics } ->
                  let field_types =
                    ctx_adt_get_instantiated_field_types span ctx id
                      adt.variant_id generics
                  in
                  List.concat (List.map2 inside adt.fields field_types)
              | VLoan (VSharedLoan (_, payload)), _ ->
                  InterpProjectors.apply_proj_borrows_on_shared_borrow span ctx
                    nested_regions payload ty
              | _ -> []
            in
            let reborrows : tavalue list =
              match inside v payload_ty with
              | [] -> []
              | asb ->
                  [
                    {
                      value = ABorrow (AProjSharedBorrow (pm, asb));
                      ty =
                        mk_ref_ty
                          (RVar (Free (ctx0.fresh_region_id ())))
                          payload_ty RShared;
                    };
                  ]
            in
            (outside @ reborrows, owned)
          in
          let nested_avl, nested_owned =
            if nested then
              let left, owned0 = nested_borrows PLeft ctx0 v0 in
              let right, owned1 = nested_borrows PRight ctx1 v1 in
              ( left @ right,
                RegionId.Set.union nested_regions
                  (RegionId.Set.union owned0 owned1) )
            else ([], RegionId.Set.singleton nested_rid)
          in
          [%sanity_check_recover] S.recover span
            (nested || List.for_all is_loan (avl0 @ avl1));
          let empty_cont () : abs_cont option =
            if S.with_abs_conts then
              Some
                {
                  output = Some (mk_etuple ~borrow_proj:true []);
                  input = Some (mk_etuple ~borrow_proj:false []);
                }
            else None
          in
          let abs =
            {
              abs_id = ctx0.fresh_abs_id ();
              kind = S.fresh_abs_kind;
              can_end = true;
              parents = AbsId.Set.empty;
              regions = { owned = RegionId.Set.singleton rid };
              ended_subabs = AbsLevelSet.empty;
              avalues = av :: List.filter is_loan (avl0 @ avl1);
(*
```ocaml
*)
              call_scopes = [];
(*
```
*)
              cont = empty_cont ();
            }
          in
          push_abs abs;
          [%ltrace "abs:\n" ^ abs_to_string span ctx0 abs];
          (if nested then
             let sv_s = tvalue_as_symbolic span sv in
             let proj : symbolic_proj =
               { sv_id = sv_s.sv_id; proj_ty = payload_ty }
             in
             let loans : tavalue =
               {
                 value =
                   ASymbolic
                     (PNone, AProjLoans { proj; consumed = []; borrows = [] });
                 ty = payload_ty;
               }
             in
             let nested_abs =
               {
                 abs_id = ctx0.fresh_abs_id ();
                 kind = S.fresh_abs_kind;
                 can_end = true;
                 parents = AbsId.Set.singleton abs.abs_id;
                 regions = { owned = nested_owned };
                 ended_subabs = AbsLevelSet.empty;
                 avalues = nested_avl @ [ loans ];
(*
```ocaml
*)
                 call_scopes = [];
(*
```
*)
                 cont = empty_cont ();
               }
             in
             push_abs nested_abs;
             [%ltrace "nested abs:\n" ^ abs_to_string span ctx0 nested_abs]);

          let value = VLoan (VSharedLoan (lid, sv)) in
          { value; ty = v0.ty })
        else [%craise_recover] S.recover span "Not implemented yet"))
    else begin
      (* The values hold no outer loans, but they can hold loans below a
         borrow: for instance a shared loan of a field of a mutably borrowed
         value, which a shared borrow of the branch still holds. The fresh
         symbolic value cannot hold such a loan: end it in its branch first,
         then retry the join (see [InterpJoin.join_ctxs_list]). *)
      let end_inner_loan ~(is_left : bool) (v : tvalue) =
        match InterpBorrowsCore.get_first_loan_in_value v with
        | Some (VSharedLoan (id, _) | VMutLoan id) ->
            raise
              (ValueMatchFailure
                 (if is_left then LoanInLeft id else LoanInRight id))
        | None -> ()
      in
      end_inner_loan ~is_left:true v0;
      end_inner_loan ~is_left:false v1;
      no_loans_no_bottoms_to_symbolic_value_with_borrows ctx0 ctx1 v0 v1
    end

  let match_distinct_adts (_ : tvalue_matcher) (ctx0 : eval_ctx)
      (ctx1 : eval_ctx) (_ : ety) (ty0 : ty) (adt0 : adt_value) (ty1 : ty)
      (adt1 : adt_value) : tvalue =
    let v0 : tvalue = { value = VAdt adt0; ty = ty0 } in
    let v1 : tvalue = { value = VAdt adt1; ty = ty1 } in

    (* For now we treat the case with borrows separately *)
    to_symbolic_value_with_borrows ctx0 ctx1 v0 v1

  let match_shared_borrows match_rec (ctx0 : eval_ctx) (ctx1 : eval_ctx)
      (ty : ety) (bid0 : borrow_id) (sid0 : shared_borrow_id) (bid1 : borrow_id)
      (sid1 : shared_borrow_id) : borrow_id * shared_borrow_id =
    if bid0 = bid1 then
      (* We always generate a fresh borrow id: borrows may be duplicated, and
         we have to make sure that shared borrow ids remain unique.
       *)
      let sid = ctx0.fresh_shared_borrow_id () in
      (bid0, sid)
    else if Hashtbl.mem joined_shared_loan_cache (bid0, bid1) then
      (* Another borrow of the same pair of loans: it borrows the same joined
         loan (see [joined_shared_loan_cache]) *)
      let sid = ctx0.fresh_shared_borrow_id () in
      (Hashtbl.find joined_shared_loan_cache (bid0, bid1), sid)
    else
      (* We replace bid0 and bid1 with a fresh borrow id, and introduce
         an abstraction which links all of them:
         {[
           { SB bid0, SB bid1, SL bid2 }
         ]}
      *)
      let rid = ctx0.fresh_region_id () in
      let bid2 = ctx0.fresh_borrow_id () in
      Hashtbl.add joined_shared_loan_cache (bid0, bid1) bid2;

      (* Lookup the shared values and match them *)
      let sv0 = S.lookup_shared_value ~is_left:true ctx0 bid0 in
      let sv1 = S.lookup_shared_value ~is_left:false ctx1 bid1 in
      let sv =
        match_shared_payloads ~merge_lender:false match_rec ctx0 ctx1 sv0 sv1
      in

      (* Only the outer reference belongs to [rid]. Nested concrete borrows
         retain their loan identities; their erased type annotations need
         unowned witnesses, not the outer region or a static lifetime. *)
      let bv_ty, bindings = retained_value_rty span ctx0 sv in
      let ctx0 = retain_metadata ctx0 bindings in
      [%sanity_check_recover] S.recover span (ty_is_rty ctx0.type_ctx.type_infos bv_ty);
      let borrow_ty = mk_ref_ty (RVar (Free rid)) bv_ty RShared in
      [%sanity_check_recover] S.recover span (ty_erase_regions_with_metadata ctx0.type_ctx.type_infos ctx0.metadata_bindings borrow_ty = ty);
      let mk_aborrow pm bid sid : tavalue =
        { value = ABorrow (ASharedBorrow (pm, bid, sid)); ty = borrow_ty }
      in
      let borrows =
        [ mk_aborrow PLeft bid0 sid0; mk_aborrow PRight bid1 sid1 ]
      in
      let loan = ASharedLoan (PNone, bid2, sv, mk_aignored span ctx0.type_ctx.type_infos bv_ty None) in
      (* Note that an aloan has a borrow type *)
      let loan : tavalue = { value = ALoan loan; ty = borrow_ty } in

      let avalues = List.append borrows [ loan ] in

      (* Create the abstraction expression *)
      let cont : abs_cont option =
        if S.with_abs_conts then
          let output = Some (mk_etuple ~borrow_proj:true []) in
          let input = Some (mk_etuple ~borrow_proj:false []) in
          Some { output; input }
        else None
      in

      (* Generate the abstraction *)
      let abs =
        {
          abs_id = ctx0.fresh_abs_id ();
          kind = S.fresh_abs_kind;
          can_end = true;
          parents = AbsId.Set.empty;
          regions = { owned = RegionId.Set.singleton rid };
          ended_subabs = AbsLevelSet.empty;
          avalues;
(*
```ocaml
*)
          call_scopes = [];
(*
```
*)
          cont;
        }
      in
      push_abs abs;

      (* Return the new borrow *)
      (* We always generate a fresh borrow id: borrows may be duplicated, and
         we have to make sure that shared borrow ids remain unique.
      *)
      let sid = ctx0.fresh_shared_borrow_id () in
      (bid2, sid)

  let match_mut_borrows (_ : tvalue_matcher) (ctx0 : eval_ctx) (_ : eval_ctx)
      (ty : ety) (bid0 : borrow_id) (_bv0 : tvalue) (bid1 : borrow_id)
      (_bv1 : tvalue) (bv : tvalue) : borrow_id * tvalue =
    (* We distinguish two cases, depending on whether the borrow ids are the same
       or not. *)
    if bid0 = bid1 then (bid0, bv)
    else
      (* We replace bid0 and bid1 with a fresh borrow id (bid2), and introduce
         an abstraction which links all of them. This time we have to introduce
         markers:
         {[
           { |MB bid0|, ︙MB bid1︙, ML bid2 }
         ]}
      *)
      let rid = ctx0.fresh_region_id () in
      let bid2 = ctx0.fresh_borrow_id () in

      (* Nested borrows stay in the joined operational payload. This
         abstraction transfers only the outer mutable reference. *)
      let _, _, kind = ty_as_ref ty in
      let bv_ty, bindings = unowned_rty_of_ety span ctx0 bv.ty in
      let ctx0 = retain_metadata ctx0 bindings in
      [%sanity_check_recover] S.recover span (ty_is_rty ctx0.type_ctx.type_infos bv_ty);
      let borrow_ty = mk_ref_ty (RVar (Free rid)) bv_ty kind in
      [%sanity_check_recover] S.recover span (ty_erase_regions_with_metadata ctx0.type_ctx.type_infos ctx0.metadata_bindings borrow_ty = ty);

      (* Generate the avalues for the abstraction *)
      let mk_aborrow (pm : proj_marker) (bid : borrow_id) : tavalue =
        let value =
          ABorrow (AMutBorrow (pm, bid, mk_aignored span ctx0.type_ctx.type_infos bv_ty None))
        in
        { value; ty = borrow_ty }
      in
      let borrows = [ mk_aborrow PLeft bid0; mk_aborrow PRight bid1 ] in

      let loan = AMutLoan (PNone, bid2, mk_aignored span ctx0.type_ctx.type_infos bv_ty None) in
      (* Note that an aloan has a borrow type *)
      let loan : tavalue = { value = ALoan loan; ty = borrow_ty } in

      let avalues = List.append borrows [ loan ] in

      (* Generate the abstraction expression.

         We need to duplicate the input (loan) but we can't have twice the same loan
         in an abstraction expression, so we create something of the shape:
         {[
           output := (|MB bid0|, ︙MB bid1︙)
           input := let x = ML bid2 in (x, x)
         ]}
      *)
      let owned = RegionId.Set.singleton rid in
      let cont : abs_cont option =
        if S.with_abs_conts then
          let input : tevalue =
            let loan = EMutLoan (PNone, bid2, mk_eignored bv_ty) in
            (* Note that an eloan has a borrow type *)
            let loan : tevalue = { value = ELoan loan; ty = borrow_ty } in

            (* Create the let-binding *)
            let fvar = mk_fresh_abs_fvar borrow_ty in
            let pair = mk_etuple ~borrow_proj:false [ fvar; fvar ] in
            let pat = mk_epat_from_fvar fvar in
            mk_let span owned pat loan pair
          in
          let output : tevalue =
            let mk_output (pm : proj_marker) (bid : borrow_id) : tevalue =
              let value = EBorrow (EMutBorrow (pm, bid, mk_eignored bv_ty)) in
              { value; ty = borrow_ty }
            in
            mk_etuple ~borrow_proj:true
              [ mk_output PLeft bid0; mk_output PRight bid1 ]
          in
          Some { output = Some output; input = Some input }
        else None
      in

      (* Generate the abstraction *)
      let abs =
        {
          abs_id = ctx0.fresh_abs_id ();
          kind = S.fresh_abs_kind;
          can_end = true;
          parents = AbsId.Set.empty;
          regions = { owned };
          ended_subabs = AbsLevelSet.empty;
          avalues;
(*
```ocaml
*)
          call_scopes = [];
(*
```
*)
          cont;
        }
      in
      push_abs abs;

      (* Return the new borrow *)
      (bid2, bv)

  (** Join [MB bid0 bv0] and [MB bid1 bv1] as a whole, keeping a concrete
      borrow: [MB bid2 sv] with a fresh borrow [bid2] and a fresh symbolic value
      [sv]. This is the join of the two borrows into a fresh symbolic
      reference ({!to_symbolic_value_with_borrows}) followed by the expansion
      of that reference into [MB bid2 sv] (see
      {!InterpProjectors.apply_proj_loans_on_symbolic_expansion}), for the
      references whose type holds nested borrows through a type argument (e.g.,
      [&'b mut Vec<&'a T>]), which a symbolic value cannot hold. The
      abstraction of the outer region borrows [bid0]/[bid1] and lends [bid2]
      (as in {!match_mut_borrows}); the abstraction of a nested region is its
      child: it borrows the nested borrows of [bv0]/[bv1], holds the pending
      loans of the values given back through [bid0]/[bid1] (see
      {!InterpAbs.convert_value_to_output_avalues}) and lends the nested
      loans of [sv] through the ignored loan of [bid2]. This is the shape of
      the region groups of a call which gives back a fresh borrow through a
      field holding [&'b mut Vec<&'a T>]. *)
  let join_nested_mut_borrows_expanded (ctx0 : eval_ctx) (ctx1 : eval_ctx)
      (ty : ety) (bid0 : borrow_id) (bv0 : tvalue) (bid1 : borrow_id)
      (bv1 : tvalue) : tvalue =
    let mk_borrow (bid : borrow_id) (bv : tvalue) : tvalue =
      { value = VBorrow (VMutBorrow (bid, bv)); ty }
    in
    let v0 = mk_borrow bid0 bv0 in
    let v1 = mk_borrow bid1 bv1 in
    let fresh_regions, ty_with_regions, bindings =
      ty_refresh_regions_with_metadata (Some span) ctx0.type_ctx.type_infos
        ctx0.fresh_region_id !S.metadata_bindings ty
    in
    let ctx0 = retain_metadata ctx0 bindings in
    let ctx1 = ctx_with_metadata_bindings ctx1 bindings in
    let outer_rid, bv_ty =
      match ty_with_regions with
      | TRef (RVar (Free rid), bv_ty, RMut) -> (rid, bv_ty)
      | _ -> [%craise_recover] S.recover span "Expected a mutable reference"
    in
    [%cassert_recover] S.recover span
      (not (ty_has_regions_in_set ctx0.type_ctx.type_infos
              (RegionId.Set.singleton outer_rid) bv_ty))
      "Nested mutable borrows are not supported yet";
    let bid2 = ctx0.fresh_borrow_id () in
    let sv = add_fresh_symbolic_value ctx0 bv_ty bv0 bv1 in
    let sv_s = tvalue_as_symbolic span sv in
    let abs_ids =
      List.map (fun rid -> (rid, ctx0.fresh_abs_id ())) fresh_regions
    in
    let parents (rid : RegionId.id) : AbsId.Set.t =
      List.fold_left
        (fun parents (rid', abs_id') ->
          if
            rid' <> rid
            && RegionId.Set.mem rid
                 (TypesAnalysis.compute_outlive_proj_ty (Some span)
                    ctx0.type_ctx.type_decls
                    ctx0.type_ctx.type_infos
                    (RegionId.Set.singleton rid')
                    ty_with_regions)
          then AbsId.Set.add abs_id' parents
          else parents)
        AbsId.Set.empty abs_ids
    in
    let project (rid : RegionId.id) =
      let regions = RegionId.Set.singleton rid in
      let avl0, output0 =
        convert_value_to_output_avalues span ctx0 PLeft v0 regions
          ty_with_regions
      in
      let avl1, output1 =
        convert_value_to_output_avalues span ctx1 PRight v1 regions
          ty_with_regions
      in
      let avl0 = List.map (shared_copy_projector ctx0) avl0 in
      let avl1 = List.map (shared_copy_projector ctx0) avl1 in
      (* The loans of [MB bid2 sv] in this region *)
      let loan : tavalue * tevalue =
        if rid = outer_rid then
          ( {
              value =
                ALoan (AMutLoan (PNone, bid2, mk_aignored span ctx0.type_ctx.type_infos bv_ty None));
              ty = ty_with_regions;
            },
            {
              value = ELoan (EMutLoan (PNone, bid2, mk_eignored bv_ty));
              ty = ty_with_regions;
            } )
        else
          ( {
              value =
                ALoan
                  (AIgnoredMutLoan
                     ( PNone, Some bid2,
                       mk_aproj_loans_value_from_symbolic_value ctx0.type_ctx.type_infos ctx0.metadata_bindings regions sv_s bv_ty ));
              ty = ty_with_regions;
            },
            {
              value =
                ELoan
                  (EIgnoredMutLoan
                     ( PNone, Some bid2,
                       mk_eproj_loans_value_from_symbolic_value
                         ctx0.type_ctx.type_infos regions sv_s bv_ty ));
              ty = ty_with_regions;
            } )
      in
      let loan_av, loan_ev = loan in
      let cont : abs_cont option =
        if S.with_abs_conts then
          (* As in {!no_loans_no_bottoms_to_symbolic_value_with_borrows}: only
             the mutable borrows of the projected region give values back. *)
          if
            TypesUtils.ty_has_mut_borrow_for_region_in_set
              ctx0.type_ctx.type_infos regions ty_with_regions
          then
            let input : tevalue =
              let fvar = mk_fresh_abs_fvar ty_with_regions in
              let pair = mk_etuple ~borrow_proj:false [ fvar; fvar ] in
              let pat = mk_epat_from_fvar fvar in
              mk_let span regions pat loan_ev pair
            in
            let output =
              mk_simpl_etuple ~borrow_proj:true [ output0; output1 ]
            in
            Some { output = Some output; input = Some input }
          else
            Some
              {
                output = Some (mk_simpl_etuple ~borrow_proj:true []);
                input = Some (mk_simpl_etuple ~borrow_proj:false []);
              }
        else None
      in
      let abs =
        {
          abs_id = List.assoc rid abs_ids;
          kind = S.fresh_abs_kind;
          can_end = true;
          parents = parents rid;
          regions = { owned = regions };
          ended_subabs = AbsLevelSet.empty;
          avalues = avl0 @ avl1 @ [ loan_av ];
(*
```ocaml
*)
          call_scopes = [];
(*
```
*)
          cont;
        }
      in
      [%ldebug "Pushing abs:\n" ^ abs_to_string span ctx0 abs];
      push_abs abs
    in
    List.iter project fresh_regions;
    { value = VBorrow (VMutBorrow (bid2, sv)); ty }

  let match_distinct_nested_mut_borrows (_ : tvalue_matcher) (ctx0 : eval_ctx)
      (ctx1 : eval_ctx) (ty : ety) (bid0 : borrow_id) (bv0 : tvalue)
      (bid1 : borrow_id) (bv1 : tvalue) : tvalue =
    (* Matching the borrowed values would join their distinct inner borrows in
       abstractions of the nested regions which are not children of the
       abstraction joining the outer borrows and miss the loans given back
       through the outer borrows. Join the two borrows as a whole instead,
       like a symbolic value with a concrete borrow: the abstraction of a
       nested region of the fresh symbolic value is a child of the abstraction
       of the outer region and holds the pending loans of the outer borrows
       (see {!InterpAbs.convert_value_to_output_avalues}). A reference whose
       type holds nested borrows through a type argument stays a concrete
       borrow of a fresh symbolic value. *)
    if ety_has_nested_borrows (Some span) ctx0.type_ctx.type_infos ty then
      join_nested_mut_borrows_expanded ctx0 ctx1 ty bid0 bv0 bid1 bv1
    else
      let mk_borrow (bid : borrow_id) (bv : tvalue) : tvalue =
        { value = VBorrow (VMutBorrow (bid, bv)); ty }
      in
      to_symbolic_value_with_borrows ctx0 ctx1 (mk_borrow bid0 bv0)
        (mk_borrow bid1 bv1)

  (*
```ocaml
  *)
  let match_shared_loans (match_rec : tvalue_matcher) (ctx0 : eval_ctx)
      (ctx1 : eval_ctx) (ty : ety) (id0 : loan_id) (id1 : loan_id)
      (sv0 : tvalue) (sv1 : tvalue) : tvalue =
    if id0 <> id1
       && (tvalue_has_borrows (Some span) ctx0 sv0
           || tvalue_has_borrows (Some span) ctx1 sv1)
    then
      if value_has_mut_borrows (Some span) ctx0 sv0.value
         || value_has_mut_borrows (Some span) ctx1 sv1.value
      then raise (ValueMatchFailure (LoanInRight id1))
      else
        to_symbolic_value_with_borrows ctx0 ctx1
          { value = VLoan (VSharedLoan (id0, sv0)); ty }
          { value = VLoan (VSharedLoan (id1, sv1)); ty }
    else
    let sv = match_rec sv0 sv1 in
    [%ldebug
      "- id0: " ^ BorrowId.to_string id0 ^ "\n- id1: " ^ BorrowId.to_string id1
      ^ "\n- sv: " ^ tvalue_to_string ctx0 sv];
    (* Remark: if we dive inside data-structures (by using a shared borrow) the shared
       values might themselves contain shared loans, which need to be matched. For this
       reason, we destructure the shared values (see {!destructure_abs}).  *)
    if id0 = id1 then { value = VLoan (VSharedLoan (id0, sv)); ty }
    else begin
      (* Sanity checks *)
      [%cassert_recover] S.recover span
        (not (ety_has_nested_borrows (Some span) ctx0.type_ctx.type_infos ty))
        "Nested borrows are not supported yet.";

      (* We need to introduce a fresh shared loan. *)
      let rid = ctx0.fresh_region_id () in
      let nbid = ctx0.fresh_borrow_id () in

      let kind = RShared in
      (* The payload holds no borrows (checked above), but its type may (e.g.
         [[View<'_>; 1]]): see {!match_shared_loan_with_other}. *)
      let bv_ty, bindings = unowned_rty_of_ety span ctx0 ty in
      let ctx0 = retain_metadata ctx0 bindings in
      let borrow_ty = mk_ref_ty (RVar (Free rid)) bv_ty kind in

      let borrow_av =
        let ty = borrow_ty in
        let value =
          ABorrow (ASharedBorrow (PNone, nbid, ctx0.fresh_shared_borrow_id ()))
        in
        mk_tavalue span ctx0.type_ctx.type_infos ty value
      in

      let mk_loan_av (pm : proj_marker) (lid : loan_id) : tavalue =
        let ty = borrow_ty in
        (* Note that we allow the shared value to contain loans!
           For this reason we introduce fresh symbolic values. *)
        let sv' = add_fresh_symbolic_value ctx0 bv_ty sv sv in
        let value =
          ALoan (ASharedLoan (pm, lid, sv', mk_aignored span ctx0.type_ctx.type_infos bv_ty None))
        in
        mk_tavalue span ctx0.type_ctx.type_infos ty value
      in

      let avalues =
        [ borrow_av; mk_loan_av PLeft id0; mk_loan_av PRight id1 ]
      in

      let owned = RegionId.Set.singleton rid in
      let cont : abs_cont option =
        if S.with_abs_conts then
          Some
            {
              output = Some (mk_etuple ~borrow_proj:true []);
              input = Some (mk_etuple ~borrow_proj:false []);
            }
        else None
      in

      (* Generate the abstraction *)
      let abs =
        {
          abs_id = ctx0.fresh_abs_id ();
          kind = S.fresh_abs_kind;
          can_end = true;
          parents = AbsId.Set.empty;
          regions = { owned };
          ended_subabs = AbsLevelSet.empty;
          avalues;
(*
```ocaml
*)
          call_scopes = [];
(*
```
*)
          cont;
        }
      in
      push_abs abs;

      (* Return the new loan *)
      { value = VLoan (VSharedLoan (nbid, sv)); ty }
    end
  (*
```
  *)

  let match_mut_loans (_match_rec : tvalue_matcher) (ctx0 : eval_ctx)
      (_ctx1 : eval_ctx) (ty : ety) (id0 : loan_id) (id1 : loan_id) : tvalue =
    if id0 = id1 then { value = VLoan (VMutLoan id0); ty }
    else begin
      (* We need to introduce a fresh loan and a fresh region abstraction *)
      let rid = ctx0.fresh_region_id () in
      let nbid = ctx0.fresh_borrow_id () in

      let kind = RMut in
      (*
```ocaml
      *)
      let child_regions, bv_ty, bindings =
        if ty_has_borrows (Some span) ctx0.type_ctx.type_infos ty then
          ty_refresh_regions_with_metadata (Some span) ctx0.type_ctx.type_infos
            ctx0.fresh_region_id !S.metadata_bindings ty
        else
          let ty, bindings = unowned_rty_of_ety span ctx0 ty in
          ([], ty, bindings)
      in
      (*
```
      *)
      let ctx0 = retain_metadata ctx0 bindings in
      let borrow_ty = mk_ref_ty (RVar (Free rid)) bv_ty kind in

      let borrow_av =
        let ty = borrow_ty in
        let value =
          ABorrow (AMutBorrow (PNone, nbid, mk_aignored span ctx0.type_ctx.type_infos bv_ty None))
        in
        mk_tavalue span ctx0.type_ctx.type_infos ty value
      in

      let mk_loan_av (pm : proj_marker) (lid : loan_id) : tavalue =
        let ty = borrow_ty in
        let value = ALoan (AMutLoan (pm, lid, mk_aignored span ctx0.type_ctx.type_infos bv_ty None)) in
        mk_tavalue span ctx0.type_ctx.type_infos ty value
      in

      let avalues =
        [ borrow_av; mk_loan_av PLeft id0; mk_loan_av PRight id1 ]
      in

      let owned = RegionId.Set.singleton rid in
      let cont : abs_cont option =
        if S.with_abs_conts then
          let input : tevalue =
            let mk_loan pm lid =
              let loan = EMutLoan (pm, lid, mk_eignored bv_ty) in
              (* Note that an eloan has a borrow type *)
              { value = ELoan loan; ty = borrow_ty }
            in
            let lv = mk_loan PLeft id0 in
            let rv = mk_loan PRight id1 in
            let v = EJoinMarkers (lv, rv) in
            { value = v; ty = borrow_ty }
          in
          let output : tevalue =
            let value = EBorrow (EMutBorrow (PNone, nbid, mk_eignored bv_ty)) in
            { value; ty = borrow_ty }
          in
          Some { output = Some output; input = Some input }
        else None
      in

      (* Generate the abstraction *)
      let abs =
        {
          abs_id = ctx0.fresh_abs_id ();
          kind = S.fresh_abs_kind;
          can_end = true;
          parents = AbsId.Set.empty;
          regions = { owned };
          ended_subabs = AbsLevelSet.empty;
          avalues;
(*
```ocaml
*)
          call_scopes = [];
(*
```
*)
          cont;
        }
      in
      push_abs abs;
      (*
```ocaml
      *)
      List.iter
        (fun region ->
          let ignored = mk_aignored span ctx0.type_ctx.type_infos bv_ty None in
          let loan pm id : tavalue =
            { value = ALoan (AIgnoredMutLoan (pm, Some id, ignored));
              ty = borrow_ty }
          in
          let pending : tavalue =
            { value = ASymbolic (PNone, APendingLoans nbid); ty = bv_ty }
          in
          let loan_input pm id : tevalue =
            { value = ELoan (EIgnoredMutLoan (pm, Some id, mk_eignored bv_ty));
              ty = borrow_ty }
          in
          let cont =
            if not S.with_abs_conts then None
            else
              let output : tevalue =
                { value = EBorrow
                    (EIgnoredMutBorrow (Some nbid, mk_eignored bv_ty));
                  ty = borrow_ty }
              in
              let input : tevalue =
                { value = EJoinMarkers
                    (loan_input PLeft id0, loan_input PRight id1);
                  ty = borrow_ty }
              in
              Some { output = Some output; input = Some input }
          in
          push_abs
            { abs_id = ctx0.fresh_abs_id (); kind = S.fresh_abs_kind;
              can_end = true; parents = AbsId.Set.singleton abs.abs_id;
              regions = { owned = RegionId.Set.singleton region };
              ended_subabs = AbsLevelSet.empty;
              avalues = [ loan PLeft id0; loan PRight id1; pending ];
(*
```ocaml
*)
              call_scopes = []; cont })
(*
```
*)
        child_regions;
      (*
```
      *)

      (* Return the new loan *)
      { value = VLoan (VMutLoan nbid); ty }
    end

  let match_symbolic_values_aux (_ : tvalue_matcher) (ctx0 : eval_ctx)
      (ctx1 : eval_ctx) (sv0 : symbolic_value) (sv1 : symbolic_value) :
      tvalue =
    let id0 = sv0.sv_id in
    let id1 = sv1.sv_id in
    if id0 = id1 && sv0 = sv1 then (
      let value0 = mk_tvalue_from_symbolic_value ctx0.type_ctx.type_infos
        ctx0.metadata_bindings sv0 in
      let value1 = mk_tvalue_from_symbolic_value ctx1.type_ctx.type_infos
        ctx1.metadata_bindings sv1 in
      (* We keep the same id, but we need to register the mapping *)
      add_symbolic_value id0 value0 value1;
      (* Return *)
      value0)
    else (
      (* The caller should have checked that the symbolic values don't contain
         unsupported nested borrows, but we can check more *)
      [%sanity_check_recover] S.recover span
        (not (symbolic_value_has_unsupported_nested_borrows span ctx0 sv0));
      (* TODO: the symbolic values may contain bottoms: we're being conservatice,
         and fail (for now) if part of a symbolic value contains a bottom.
         A more general approach would be to introduce a symbolic value
         with some ended regions. *)
      [%cassert_recover] S.recover span
        ((not (symbolic_value_has_ended_regions ctx0.type_ctx.type_infos ctx0.ended_regions sv0))
        && not (symbolic_value_has_ended_regions ctx1.type_ctx.type_infos ctx1.ended_regions sv1))
        "Unimplemented";
      [%ldebug "ty: " ^ ty_to_string ctx0 sv0.sv_ty];
      (* If the symbolic values contain regions, we need to introduce abstractions *)
      if ty_has_borrows (Some span) ctx0.type_ctx.type_infos sv0.sv_ty then (
        (* Let's say we join:
           {[
             s0 : S<'0, '1>
             s1 : S<'2, '3>
           ]}

           We introduce a fresh symbolic value with fresh regions, as well as
           one abstraction per region. It looks like so:
           {[
             join s0 s1 ~> s2 : S<'a, 'b>,
               A0('a) {
                 |proj_borrows (s0 <: S<'a, 'b>)|,
                 !proj_borrows (s1 <: S<'a, 'b>)!,
                 proj_loans (s2 : S<'a, 'b>)
               }
               A1('b) {
                 |proj_borrows (s0 <: S<'a, 'b>)|,
                 !proj_borrows (s1 <: S<'a, 'b>)!,
                 proj_loans (s2 : S<'a, 'b>)
               }
           ]}
        *)
        (* Introduce one region abstraction per region appearing in the symbolic value *)
        (*
        ```ocaml
        *)
        let () =
          let log = Logging.carrier_events_log in
          [%ldebug "Source ABI refresh input:"
            ^ "\nraw left symbol: " ^ Values.show_symbolic_value sv0
            ^ "\nraw right symbol: " ^ Values.show_symbolic_value sv1
            ^ "\nleft evidence: " ^ InterpBorrows.runtime_type_metadata_view ctx0 [sv0.sv_ty]
            ^ "\nright evidence: " ^ InterpBorrows.runtime_type_metadata_view ctx1 [sv1.sv_ty]
            ^ "\nmetadata bindings: "
            ^ carrier_metadata_bindings !S.metadata_bindings]
        in
        (*
        ```
        *)
        let bindings = ref !S.metadata_bindings in
        let fresh_regions, proj_ty =
          ty_refresh_regions (Some span) ctx0.type_ctx.type_infos
            ~metadata_bindings:(Some bindings) ctx0.fresh_region_id sv0.sv_ty
        in
        let bindings = !bindings in
        (*
        ```ocaml
        *)
        let () =
          let log = Logging.carrier_events_log in
          [%ldebug "Source ABI refresh output:"
            ^ "\nsource root: " ^ SymbolicValueId.to_string sv0.sv_id
            ^ "\nfresh regions: "
            ^ String.concat "," (List.map RegionId.to_string fresh_regions)
            ^ "\nraw refreshed type: " ^ Types.show_ty proj_ty
            ^ "\nmetadata bindings: "
            ^ carrier_metadata_bindings bindings]
        in
        (*
        ```
        *)
        let ctx0 = retain_metadata ctx0 bindings in
        let svj =
          add_fresh_symbolic_value ctx0 proj_ty
            { value = VSymbolic sv0; ty = sv0.sv_ty }
            { value = VSymbolic sv1; ty = sv1.sv_ty }
        in
        let proj_s0 =
          mk_aproj_borrows PLeft sv0.sv_id proj_ty |> shared_copy_projector ctx0
        in
        let proj_s1 =
          mk_aproj_borrows PRight sv1.sv_id proj_ty
          |> shared_copy_projector ctx0
        in
        let symbol = get_symbolic_tvalue span svj in
        let proj_svj = mk_aproj_loans PNone symbol.sv_id proj_ty in
        let avalues = [ proj_s0; proj_s1; proj_svj ] in
        List.iter
          (fun rid ->
            let owned = RegionId.Set.singleton rid in
            (* The abstraction expression continuation *)
            let cont : abs_cont option =
              if S.with_abs_conts then
                (* The continuation should be of the shape (this is similar to
                   the case of mutable borrows):
                   {[
                     output := (|proj_borrows (s0 <: ...)|, ︙proj_borrows (s1 <: ...︙)
                     input := let x = proj_loans (s2 : ...) in (x, x)
                   ]}

                   Note that we introduce projections only if the symbolic values
                   contain mutable borrows for the projected regions. Otherwise
                   we ignore them.
                *)
                if
                  ty_has_mut_borrow_for_region_in_set ctx0.type_ctx.type_infos
                    owned proj_ty
                then
                  let proj_s0 = mk_eproj_borrows PLeft sv0.sv_id proj_ty in
                  let proj_s1 = mk_eproj_borrows PRight sv1.sv_id proj_ty in
                  let proj_svj = mk_eproj_loans PNone symbol.sv_id proj_ty in
                  let input : tevalue =
                    let loan = proj_svj in
                    (* Create the let-binding *)
                    let fvar = mk_fresh_abs_fvar proj_ty in
                    let pair = mk_etuple ~borrow_proj:false [ fvar; fvar ] in
                    let pat = mk_epat_from_fvar fvar in
                    mk_let span owned pat loan pair
                  in
                  let output : tevalue =
                    mk_etuple ~borrow_proj:true [ proj_s0; proj_s1 ]
                  in
                  Some { output = Some output; input = Some input }
                else
                  Some
                    {
                      output = Some (mk_simpl_etuple ~borrow_proj:true []);
                      input = Some (mk_simpl_etuple ~borrow_proj:false []);
                    }
              else None
            in
            (* Create the abstraction *)
            let abs =
              {
                abs_id = ctx0.fresh_abs_id ();
                kind = S.fresh_abs_kind;
                can_end = true;
                parents = AbsId.Set.empty;
                regions = { owned };
                ended_subabs = AbsLevelSet.empty;
                avalues;
(*
```ocaml
*)
                call_scopes = [];
(*
```
*)
                cont;
              }
            in
            push_abs abs)
          fresh_regions;
        svj)
      else
        (* Otherwise we simply introduce a fresh symbolic value, or reuse a
           previously created one if the same pair was already joined. *)
        match Hashtbl.find_opt joined_sv_cache (id0, id1) with
        | Some svj -> svj
        | None ->
            let sv =
              add_fresh_symbolic_value ctx0 sv0.sv_ty
                { value = VSymbolic sv0; ty = sv0.sv_ty }
                { value = VSymbolic sv1; ty = sv1.sv_ty }
            in
            Hashtbl.add joined_sv_cache (id0, id1) sv;
            sv)

  let match_symbolic_values match_rec (ctx0 : eval_ctx) (ctx1 : eval_ctx)
      (sv0 : symbolic_value) (sv1 : symbolic_value) : tvalue =
    if
      symbolic_value_has_ended_regions ctx0.type_ctx.type_infos ctx0.ended_regions sv0
      || symbolic_value_has_ended_regions ctx1.type_ctx.type_infos ctx1.ended_regions sv1
    then
      to_symbolic_value_with_borrows ctx0 ctx1
        (mk_tvalue_from_symbolic_value ctx0.type_ctx.type_infos ctx0.metadata_bindings sv0)
        (mk_tvalue_from_symbolic_value ctx1.type_ctx.type_infos ctx1.metadata_bindings sv1)
    else
      (* Branch-local region renaming can give the same symbolic id distinct
         live region annotations. Join those projections just like any other
         distinct symbolic values rather than identifying their lifetimes. *)
      match_symbolic_values_aux match_rec ctx0 ctx1 sv0 sv1
(* ``` *)

  let match_symbolic_with_other (_ : tvalue_matcher) (ctx0 : eval_ctx)
      (ctx1 : eval_ctx) ~(symbolic_is_left : bool) (sv : symbolic_value)
      (v : tvalue) : tvalue =
    let sv = mk_tvalue_from_symbolic_value ctx0.type_ctx.type_infos ctx0.metadata_bindings sv in
    let v0, v1 = if symbolic_is_left then (sv, v) else (v, sv) in
    to_symbolic_value_with_borrows ctx0 ctx1 v0 v1

  let match_bottom_with_other (_ : tvalue_matcher) (ctx0 : eval_ctx)
      (ctx1 : eval_ctx) ~(bottom_is_left : bool) (v : tvalue) : tvalue =
    let value_is_left = not bottom_is_left in
    (* If there are outer loans in the non-bottom value, raise an exception.
       Otherwise, convert it to an abstraction and return [Bottom].
    *)
    let with_borrows = false in
    match
      InterpBorrowsCore.get_first_outer_loan_or_borrow_in_value with_borrows v
    with
    | Some (BorrowContent _) ->
        (* Can't get there: we only ask for outer *loans* *)
        [%craise] span "Unreachable"
    | Some (LoanContent lc) -> (
        match lc with
        | VSharedLoan (id, _) | VMutLoan id ->
            if value_is_left then raise (ValueMatchFailure (LoanInLeft id))
            else raise (ValueMatchFailure (LoanInRight id)))
    | None ->
        let ctx = if value_is_left then ctx0 else ctx1 in
        (* The joined value is bottom: if the value holds nested mutable
           borrows, which region abstractions cannot hold, end them in its
           branch first *)
        Option.iter
          (fun id ->
            raise
              (ValueMatchFailure
                 (if value_is_left then LoanInLeft id else LoanInRight id)))
          (value_nested_mut_borrows_owner span ~shared_payloads:false ctx v);
        (* Convert the value to an abstraction *)
        let absl, bindings = convert_value_to_abstractions span S.fresh_abs_kind ~can_end:true ctx v in let ctx = retain_metadata ctx bindings in (* Add a marker to the abstraction indicating the provenance of the value *)
        let pm = if value_is_left then PLeft else PRight in
        let absl =
          List.concat_map
            (abs_add_marker span ~loop_level_outputs:S.loop_level_outputs ctx pm)
            absl
        in
        push_absl absl;
        mk_bottom span ctx0.type_ctx.type_infos v.ty

  let match_shared_loan_with_other (match_rec : tvalue_matcher)
      (ctx0 : eval_ctx) (ctx1 : eval_ctx) ~(loan_is_left : bool) (ty : ety)
      (lid : loan_id) (shared_value : tvalue) (other : tvalue) : tvalue =
    let loan_ctx, other_ctx =
      if loan_is_left then (ctx0, ctx1) else (ctx1, ctx0)
    in
    (* Keep borrowed payloads in the shared wrapper protocol. Its payload
       regions remain separate from the lifetime of the outer loan. *)
    if
      tvalue_has_borrows (Some span) loan_ctx shared_value
      || tvalue_has_borrows (Some span) other_ctx other
    then begin
      if
        value_has_mut_borrows (Some span) loan_ctx shared_value.value
        || value_has_mut_borrows (Some span) other_ctx other.value
      then
        if S.recover then raise Errors.RFailure
        else
          raise
            (ValueMatchFailure
               (if loan_is_left then LoanInLeft lid else LoanInRight lid))
      else
        let loan : tvalue =
          { value = VLoan (VSharedLoan (lid, shared_value)); ty }
        in
        let left, right =
          if loan_is_left then (loan, other) else (other, loan)
        in
        to_symbolic_value_with_borrows ctx0 ctx1 left right
    end
    else begin
    (* Sanity checks *)
    [%cassert_recover] S.recover span
      (not (ety_has_nested_borrows (Some span) ctx0.type_ctx.type_infos ty))
      "Unimplemented";
    [%cassert_recover] S.recover span
      (not
         (ValuesUtils.value_has_loans_or_borrows (Some span)
            ctx0.type_ctx.type_infos shared_value.value))
      "Unimplemented";

    (* Join the inner value. *)
    let joined_value =
      if loan_is_left then match_rec shared_value other
      else match_rec other shared_value
    in

    (* We need a shared loan of the joined value. If the join of the inner
       values is itself a shared loan (the other value holds outer loans, see
       [to_symbolic_value_with_borrows]), borrow from it: a shared loan of a
       shared loan lends the same value, and nesting them would give the
       joined value a shape which a later iteration of a loop, where the inner
       loan has ended, cannot match (a shared value holding loans). Otherwise,
       introduce a fresh shared loan. *)
    let rid = ctx0.fresh_region_id () in
    let nbid, fresh_loan =
      match joined_value.value with
      | VLoan (VSharedLoan (inner, _)) -> (inner, false)
      | _ -> (ctx0.fresh_borrow_id (), true)
    in

    let kind = RShared in
    (* The payload holds no borrows (checked above), but its type may: e.g. an
       empty array [[View<'_>; 0]] behind a promoted [&[]]. Only the outer
       reference belongs to [rid]: reify the erased regions of the payload
       type with distinct, unowned witnesses, as {!match_shared_borrows} does
       for the retained payload. *)
    let bv_ty, bindings = unowned_rty_of_ety span ctx0 ty in
    let ctx0 = retain_metadata ctx0 bindings in
    let borrow_ty = mk_ref_ty (RVar (Free rid)) bv_ty kind in

    let borrow_av =
      let ty = borrow_ty in
      let value =
        ABorrow (ASharedBorrow (PNone, nbid, ctx0.fresh_shared_borrow_id ()))
      in
      mk_tavalue span ctx0.type_ctx.type_infos ty value
    in

    let loan_av : tavalue =
      let ty = borrow_ty in
      let pm = if loan_is_left then PLeft else PRight in
      let value =
        ALoan (ASharedLoan (pm, lid, shared_value, mk_aignored span ctx0.type_ctx.type_infos bv_ty None))
      in
      mk_tavalue span ctx0.type_ctx.type_infos ty value
    in

    let avalues = [ borrow_av; loan_av ] in

    let owned = RegionId.Set.singleton rid in
    let cont : abs_cont option =
      if S.with_abs_conts then
        Some
          {
            output = Some (mk_etuple ~borrow_proj:true []);
            input = Some (mk_etuple ~borrow_proj:false []);
          }
      else None
    in

    (* Generate the abstraction *)
    let abs =
      {
        abs_id = ctx0.fresh_abs_id ();
        kind = S.fresh_abs_kind;
        can_end = true;
        parents = AbsId.Set.empty;
        regions = { owned };
        ended_subabs = AbsLevelSet.empty;
        avalues;
(*
```ocaml
*)
        call_scopes = [];
(*
```
*)
        cont;
      }
    in
    push_abs abs;

    (* Return the new loan *)
    if fresh_loan then { value = VLoan (VSharedLoan (nbid, joined_value)); ty }
    else joined_value
    end

  let match_mut_loan_with_other (_match_rec : tvalue_matcher) (ctx0 : eval_ctx)
      (ctx1 : eval_ctx) ~(loan_is_left : bool) (ty : ety) (lid : loan_id)
      (other : tvalue) : tvalue =
    let other_ctx = if loan_is_left then ctx1 else ctx0 in
    (* A missing input still needs a real giveback. *)
    if other.value = VBottom then
      raise
        (ValueMatchFailure
           (if loan_is_left then LoanInLeft lid else LoanInRight lid));

    let loan_ctx, loan_pm, other_pm =
      if loan_is_left then (ctx0, PLeft, PRight) else (ctx1, PRight, PLeft)
    in

    [%ldebug
      "- loan id: " ^ BorrowId.to_string lid ^ "\n- ty: "
      ^ ty_to_string loan_ctx ty ^ "\n- other:\n"
      ^ tvalue_to_string other_ctx other
      ^ "\n- other.ty: "
      ^ ty_to_string other_ctx other.ty];

    if
      tvalue_has_borrows (Some span) other_ctx other
      && ty_has_mut_borrows other_ctx.type_ctx.type_infos other.ty
    then begin
      (* Preserve the field loan and each actual nested supplier. *)
      let abstractions, joined, bindings = join_mut_loan_with_nested_input span ctx0 ~loan_ctx ~other_ctx ~abs_kind:S.fresh_abs_kind ~with_abs_conts:S.with_abs_conts ~loan_pm ~other_pm ~loan_id:lid ~other in let _ = retain_metadata ctx0 bindings in push_absl abstractions;
      joined
    end
    else
    (* We need to introduce a fresh loan and a fresh region abstraction *)
    let rid = ctx0.fresh_region_id () in
    let nbid = ctx0.fresh_borrow_id () in

    let kind = RMut in
    (* This ignored slot can receive a later payload after the current
       borrow's regions have ended. Its witnesses must remain unowned. *)
    let bv_ty, bindings = unowned_rty_of_ety span loan_ctx ty in
    let ctx0 = retain_metadata ctx0 bindings in
    let borrow_ty = mk_ref_ty (RVar (Free rid)) bv_ty kind in

    let borrow_av =
      let ty = borrow_ty in
      let value =
        ABorrow (AMutBorrow (PNone, nbid, mk_aignored span ctx0.type_ctx.type_infos bv_ty None))
      in
      mk_tavalue span ctx0.type_ctx.type_infos ty value
    in

    let loan_av : tavalue =
      let ty = borrow_ty in
      let value =
        ALoan (AMutLoan (loan_pm, lid, mk_aignored span ctx0.type_ctx.type_infos bv_ty None))
      in
      mk_tavalue span ctx0.type_ctx.type_infos ty value
    in

    let other_rty, bindings = retained_value_rty span other_ctx other in
    let other_ctx = retain_metadata other_ctx bindings in
    let other_avl, other_input, bindings, owned =
      convert_value_to_input_avalues span other_ctx other_pm other rid
        other_rty
    in
    let ctx0 = retain_metadata ctx0 bindings in
    let avalues = [ borrow_av; loan_av ] @ other_avl in
    
    let owned = RegionId.Set.add rid owned in
    let cont : abs_cont option =
      if S.with_abs_conts then
        let input : tevalue =
          let loan : tevalue =
            let loan = EMutLoan (loan_pm, lid, mk_eignored bv_ty) in
            (* Note that an eloan has a borrow type *)
            { value = ELoan loan; ty = borrow_ty }
          in
          let other_input : tevalue =
            (* We need this to make sure no values are filtered when translating *)
            { value = EMutBorrowInput other_input; ty = borrow_ty }
          in
          let lv, rv =
            if loan_is_left then (loan, other_input) else (other_input, loan)
          in
          let v = EJoinMarkers (lv, rv) in
          { value = v; ty = borrow_ty }
        in
        let output : tevalue =
          let value = EBorrow (EMutBorrow (PNone, nbid, mk_eignored bv_ty)) in
          { value; ty = borrow_ty }
        in
        Some { output = Some output; input = Some input }
      else None
    in
    
    (* Generate the abstraction *)
    let abs =
      {
        abs_id = ctx0.fresh_abs_id ();
        kind = S.fresh_abs_kind;
        can_end = true;
        parents = AbsId.Set.empty;
        regions = { owned };
        ended_subabs = AbsLevelSet.empty;
        avalues;
(*
```ocaml
*)
        call_scopes = [];
(*
```
*)
        cont;
      }
    in
    push_abs abs;
    
    (* Return the new loan *)
    { value = VLoan (VMutLoan nbid); ty }

  (* As explained in comments: we don't use the join matcher to join avalues,
     only concrete values *)

  let match_apending_loans pm0 bid0 pm1 bid1 ty : tavalue =
    [%sanity_check_recover] S.recover span (pm0 = PNone && pm1 = PNone);
    [%cassert_recover] S.recover span (bid0 = bid1)
      "Distinct pending parent dependencies";
    { value = ASymbolic (PNone, APendingLoans bid0); ty }

  (* Actual source values establish correspondence and mask transport.
     Dependency records preserve that correspondence, not new owners. *)
  let match_apending_symbolic_loans ctx0 ctx1 pm0 slot0 pm1 slot1 ty0 ty : tavalue =
    [%sanity_check_recover] S.recover span (pm0 = PNone && pm1 = PNone);
    let source_roots =
      SymbolicValueId.Map.fold
        (fun root (left, right) found ->
          let left = value_strip_shared_loans left in
          let right = value_strip_shared_loans right in
          match (left.value, right.value) with
          | VSymbolic left, VSymbolic right
            when left.sv_id = slot0.root_sv_id
                 && right.sv_id = slot1.root_sv_id ->
              (match found with
              | None -> Some (root, left, right)
              | Some (previous, _, _) when previous = root -> found
              | Some _ ->
                  [%craise_recover] S.recover span
                    "Ambiguous pending symbolic root correspondence")
          | _ -> found)
        !S.symbolic_to_value None
    in
    let root =
      match source_roots with
      | Some (root, _, _) -> root
      | None when slot0.root_sv_id = slot1.root_sv_id -> slot0.root_sv_id
      | None ->
          [%craise_recover] S.recover span
            "No established pending symbolic root correspondence"
    in
    let left_to_right =
      match source_roots with
      | Some (_, left, right) ->
          [%sanity_check_recover] S.recover span
            (slot0.proj_ty = left.sv_ty && slot1.proj_ty = right.sv_ty);
          projection_metadata_renaming span ctx0.type_ctx.type_infos
            left.sv_ty right.sv_ty
      | None -> RegionId.Map.empty
    in
    [%cassert_recover] S.recover span
      (map_free_region_aliases
         (rename_projection_metadata_region left_to_right) ty0 = ty)
      "Distinct pending symbolic dependency types";
    let mapped_left =
      rename_symbolic_pending_slot slot1.root_sv_id
        (rename_projection_metadata_region left_to_right) slot0
    in
    [%cassert_recover] S.recover span (mapped_left = slot1)
      "Distinct complete pending symbolic dependencies";
    let root_ty = ref None in
    let add_root_ty ty =
      match !root_ty with
      | None -> root_ty := Some ty
      | Some previous ->
          [%sanity_check_recover] S.recover span (previous = ty)
    in
    let visitor =
      object
        inherit [_] iter_eval_ctx as super
        method! visit_ty _ _ = ()
        method! visit_symbolic_value _ sv =
          if sv.sv_id = root then add_root_ty sv.sv_ty

        method! visit_AProjLoans env proj =
          if proj.proj.sv_id = root then add_root_ty proj.proj.proj_ty;
          super#visit_AProjLoans env proj

        method! visit_EProjLoans env proj =
          if proj.proj.sv_id = root then add_root_ty proj.proj.proj_ty;
          super#visit_EProjLoans env proj
      end
    in
    visitor#visit_eval_ctx () ctx0;
    visitor#visit_eval_ctx () ctx1;
    List.iter (visitor#visit_abs ()) !S.nabs;
    let root_ty =
      match !root_ty with
      | Some ty -> ty
      | None when root = slot0.root_sv_id -> slot0.proj_ty
      | None ->
          [%craise_recover] S.recover span
            "Missing actual joined symbolic carrier type"
    in
    let transport ctx source slot =
      let renaming =
        projection_metadata_renaming span ctx.type_ctx.type_infos
          source.sv_ty root_ty
      in
      let slot =
        rename_symbolic_pending_slot root
          (rename_projection_metadata_region renaming) slot
      in
      [%sanity_check_recover] S.recover span (slot.proj_ty = root_ty);
      slot
    in
    let slot0 =
      match source_roots with
      | Some (_, left, _) -> transport ctx0 left slot0
      | None ->
          [%sanity_check_recover] S.recover span (slot0.proj_ty = root_ty);
          slot0
    in
    let slot1 =
      match source_roots with
      | Some (_, _, right) -> transport ctx1 right slot1
      | None -> slot1
    in
    [%cassert_recover] S.recover span (slot0 = slot1)
      "Distinct joined pending symbolic masks or paths";
    {
      value = ASymbolic (PNone, APendingSymbolicLoans slot0);
      ty = slot0.proj_ty;
    }

  let match_aignored_mut_loan (_match_rec : tvalue_matcher) (_ctx0 : eval_ctx)
      (_ctx1 : eval_ctx)
      ((_ty0, pm0, bid0, _child0) : rty * proj_marker * borrow_id option * tavalue)
      ((_ty1, pm1, bid1, _child1) : rty * proj_marker * borrow_id option * tavalue) (ty : ty)
      (child : tavalue) : tavalue =
    (* For now we only support the case where the loans are the same *)
    [%cassert_recover] S.recover span (pm0 = pm1 && bid0 = bid1) "Unimplemented";
    { value = ALoan (AIgnoredMutLoan (pm0, bid0, child)); ty }

  let match_aignored_mut_borrow (_match_rec : tvalue_matcher) (_ctx0 : eval_ctx)
      (_ctx1 : eval_ctx)
      ((_ty0, bid0, _child0) : rty * borrow_id option * tavalue)
      ((_ty1, bid1, _child1) : rty * borrow_id option * tavalue) (ty : ty)
      (child : tavalue) : tavalue =
    (* For now we only support the case where the borrows are the same *)
    [%cassert_recover] S.recover span (bid0 = bid1) "Unimplemented";
    { value = ABorrow (AIgnoredMutBorrow (bid0, child)); ty }

  let match_aended_ignored_mut_borrow (_match_rec : tvalue_matcher)
      (_ctx0 : eval_ctx) (_ctx1 : eval_ctx)
      ((_ty0, bc0) : rty * aended_ignored_mut_borrow)
      ((_ty1, bc1) : rty * aended_ignored_mut_borrow) (ty : ty)
      (child : tavalue) (given_back : tavalue) : tavalue =
    (* For now we only support the case where we have the same values on
       the left and on the right *)
    [%cassert_recover] S.recover span
      (bc0.given_back_meta = bc1.given_back_meta)
      "Unimplemented";
    {
      value =
        ABorrow
          (AEndedIgnoredMutBorrow
             { child; given_back; given_back_meta = bc0.given_back_meta });
      ty;
    }

  let match_distinct_aadts _ _ _ _ _ _ _ =
    [%craise_recover] S.recover span "Unreachable"

  let match_ashared_borrows _ _ _ _ _ _ =
    [%craise_recover] S.recover span "Unreachable"

  let match_amut_borrows _ _ _ _ _ _ _ _ _ _ =
    [%craise_recover] S.recover span "Unreachable"

  let match_ashared_loans _ _ _ _ _ _ _ _ _ _ _ _ _ =
    [%craise_recover] S.recover span "Unreachable"

  let match_amut_loans _ _ _ _ _ _ _ _ _ _ =
    [%craise_recover] S.recover span "Unreachable"

  let match_aproj_borrows _ _ _ _ _ _ _ _ _ _ =
    [%craise_recover] S.recover span "Unreachable"

  let match_aproj_loans _ _ _ _ _ _ _ _ _ _ =
    [%craise_recover] S.recover span "Unreachable"

  let match_avalues _ _ _ _ = [%craise_recover] S.recover span "Unreachable"
end

(** Remove the shared loans which only one of two shared payloads holds at a
    given position: a join introduces the loans of the reborrowed components of
    a joined payload next to it rather than inside it (see
    {!flatten_shared_loan_view}). The identities of these loans are matched
    through their own borrows and holders. *)
let rec align_shared_loans (v0 : tvalue) (v1 : tvalue) : tvalue * tvalue =
  match (v0.value, v1.value) with
  | VLoan (VSharedLoan (lid0, sv0)), VLoan (VSharedLoan (lid1, sv1)) ->
      let sv0, sv1 = align_shared_loans sv0 sv1 in
      ( { v0 with value = VLoan (VSharedLoan (lid0, sv0)) },
        { v1 with value = VLoan (VSharedLoan (lid1, sv1)) } )
  | VLoan (VSharedLoan (_, sv0)), _ -> align_shared_loans sv0 v1
  | _, VLoan (VSharedLoan (_, sv1)) -> align_shared_loans v0 sv1
  | VAdt adt0, VAdt adt1
    when adt0.variant_id = adt1.variant_id
         && List.length adt0.fields = List.length adt1.fields ->
      let fields0, fields1 =
        List.split (List.map2 align_shared_loans adt0.fields adt1.fields)
      in
      ( { v0 with value = VAdt { adt0 with fields = fields0 } },
        { v1 with value = VAdt { adt1 with fields = fields1 } } )
  | _ -> (v0, v1)

(* 
```ocaml
*)
let region_match_diagnostics_enabled () =
  let log = Logging.carrier_events_log in
  !Config.print_error_diagnostics || !Config.print_error_emitters
  || Logging.L.Debug >= log#effective_level

let make_region_match_diagnostic span (fixed_ids : ids_sets)
    (ctx0 : eval_ctx) (ctx1 : eval_ctx) =
  let log = Logging.carrier_events_log in
  if not (region_match_diagnostics_enabled ()) then None
  else try
    let type_pair = ref None in
    let symbolic_pair = ref None in
    let origins = ref RegionId.Map.empty in
    let registrations = ref 0 in
    let registration_location = ref None in
    let field label analyze =
      "\n" ^ label ^ ": "
      ^ (try analyze () with error ->
           "analysis unavailable: " ^ Printexc.to_string error)
    in
    let bounded text =
      if String.length text <= 16384 then text
      else String.sub text 0 16384 ^ "\nanalysis unavailable: output limit"
    in
    let region_set ids =
      if RegionId.Set.cardinal ids > 128 then
        "analysis unavailable: region-set limit"
      else RegionId.Set.to_string None ids
    in
    let source ctx region =
      let rec resolve visited steps region =
        if steps = 64 then failwith "Metadata alias depth limit"
        else
          match region with
          | RVar (Free id) ->
              if RegionId.Set.mem id visited then
                failwith "Metadata alias cycle"
              else
                (match RegionId.Map.find_opt id ctx.metadata_bindings with
                | Some (MetadataSource target) when target <> region ->
                    Types.show_region region ^ " -> "
                    ^ resolve (RegionId.Set.add id visited) (steps + 1) target
                | Some (MetadataSource target) ->
                    Types.show_region region ^ " -> MetadataSource "
                    ^ Types.show_region target
                | Some MetadataFresh ->
                    Types.show_region region
                    ^ " -> MetadataFresh. Authentic source unavailable."
                | None ->
                    Types.show_region region
                    ^ " -> no metadata binding. Authentic source unavailable.")
          | _ -> "authentic source " ^ Types.show_region region
      in
      resolve RegionId.Set.empty 0 region
    in
    let type_view ctx ty =
      let nodes = ref 0 in
      let rows = ref [] in
      let add row = rows := row :: !rows in
      let visitor =
        object (self)
          inherit [_] iter_ty as super
          method! visit_region path region =
            add (path ^ ": "
                 ^ (try source ctx region with error ->
                      "analysis unavailable: " ^ Printexc.to_string error))
          method! visit_ty path ty =
            incr nodes;
            if !nodes > 256 || String.length path > 2048 then
              failwith "Type occurrence limit";
            match ty with
            | TAdt tref ->
                let info = match tref.id with
                  | TAdtId id ->
                      TypeDeclId.Map.find_opt id ctx.type_ctx.type_infos
                  | _ -> None
                in
                let membership stored metadata =
                  match tref.id, info with
                  | TAdtId _, None -> "classification unavailable"
                  | _, None -> "stored=true, metadata=false"
                  | _, Some info ->
                      "stored=" ^ string_of_bool (stored info)
                      ^ ", metadata=" ^ string_of_bool (metadata info)
                in
                let declaration = match tref.id with
                  | TAdtId id -> "TAdtId " ^ TypeDeclId.to_string id
                  | TTuple -> "TTuple"
                  | TBuiltin _ -> "TBuiltin"
                in
                let nominal = path ^ "/" ^ declaration in
                List.iteri (fun index region ->
                  let occurrence = nominal ^ "/region[" ^ string_of_int index ^ "]" in
                  let key = RegionId.of_int index in
                  add (occurrence ^ ": "
                       ^ membership
                           (fun info -> RegionId.Set.mem key info.TypesAnalysis.stored_regions)
                           (fun info -> RegionId.Set.mem key info.TypesAnalysis.metadata_regions));
                  self#visit_region occurrence region) tref.generics.regions;
                List.iteri (fun index ty ->
                  let occurrence = nominal ^ "/type[" ^ string_of_int index ^ "]" in
                  let key = TypeVarId.of_int index in
                  add (occurrence ^ ": "
                       ^ membership
                           (fun info -> TypeVarId.Set.mem key info.TypesAnalysis.stored_type_params)
                           (fun info -> TypeVarId.Set.mem key info.TypesAnalysis.metadata_type_params));
                  self#visit_ty occurrence ty) tref.generics.types;
                List.iter (self#visit_trait_ref (nominal ^ "/trait"))
                  tref.generics.trait_refs
            | TRef (region, child, _) ->
                self#visit_region (path ^ "/reference.region") region;
                self#visit_ty (path ^ "/reference.type") child
            | _ -> super#visit_ty (path ^ "/nested") ty
        end
      in
      visitor#visit_ty "root" ty;
      bounded (Types.show_ty ty ^ "\n" ^ String.concat "\n" (List.rev !rows))
    in
    let physical ctx target =
      let nodes = ref 0 in
      let matches = ref [] in
      let rec value frame binder position (tv : tvalue) =
        incr nodes;
        if !nodes > 128 || List.length position > 64 then
          failwith "Physical occurrence limit";
        match tv.value with
        | VSymbolic sv when sv = target ->
            matches :=
              (show_var_binder binder ^ ", frame=" ^ string_of_int frame
               ^ ", position="
               ^ String.concat "/" (List.map show_value_path_step (List.rev position))
               ^ ", runtime type=" ^ bounded (Types.show_ty tv.ty)) :: !matches
        | VAdt adt ->
            List.iteri (fun index child ->
              value frame binder (PField (adt.variant_id, index) :: position) child)
              adt.fields
        | VBorrow (VMutBorrow (_, child)) | VLoan (VSharedLoan (_, child)) ->
            value frame binder (PDeref :: position) child
        | _ -> ()
      in
      let rec bindings frame count = function
        | [] -> ()
        | _ when !matches <> [] -> ()
        | _ when count = 256 -> failwith "Environment binding limit"
        | EBinding (binder, tv) :: rest ->
            value frame binder [] tv;
            bindings frame (count + 1) rest
        | EFrame :: rest -> bindings (frame + 1) (count + 1) rest
        | EAbs _ :: rest -> bindings frame (count + 1) rest
      in
      bindings 0 0 ctx.env;
      match !matches with
      | [] -> "analysis unavailable: no physical symbolic occurrence"
      | matches -> String.concat "\n" (List.rev matches)
    in
    let masks ctx =
      let rec scan count masks = function
        | [] -> masks
        | _ when count = 128 -> failwith "Ownership environment limit"
        | EAbs abs :: rest ->
            scan (count + 1)
              (("abs=" ^ AbsId.to_string abs.abs_id
                ^ " owned=" ^ region_set abs.regions.owned) :: masks) rest
        | _ :: rest -> scan count masks rest
      in
      String.concat "\n" (List.rev (scan 0 [] ctx.env))
    in
    let describe_pair pair symbols =
      match pair with
      | None -> "\ntype pair: analysis unavailable: no active type match"
      | Some (left, right, ty0, ty1) ->
          field "left complete type and occurrences" (fun () -> type_view left ty0)
          ^ field "right complete type and occurrences" (fun () -> type_view right ty1)
          ^ (match symbols with
             | None -> "\nsymbolic pair: analysis unavailable: no active symbolic match"
             | Some (sv0, sv1) ->
                 field "left symbolic value" (fun () -> bounded (show_symbolic_value sv0))
                 ^ field "right symbolic value" (fun () -> bounded (show_symbolic_value sv1))
                 ^ field "left binder and physical position" (fun () -> physical left sv0)
                 ^ field "right binder and physical position" (fun () -> physical right sv1))
    in
    let observe operation before rid0 rid1 failure =
      if region_match_diagnostics_enabled () then
      try
        let operation = match !registration_location with
          | None -> operation
          | Some location -> operation ^ "\n" ^ location
        in
        match failure with
        | None ->
            if not (RegionId.InjSubst.mem rid0 before) then
              if !registrations < 128 then (
                origins := RegionId.Map.add rid0
                  (rid1, operation, !type_pair, !symbolic_pair) !origins;
                incr registrations)
              else ()
        | Some error ->
            (*
```ocaml
*)
            let forward = field "existing forward entry and registration origin" (fun () ->
              if RegionId.InjSubst.cardinal before > 256 then
                failwith "Region correspondence limit";
              match RegionId.InjSubst.find_opt rid0 before with
              | None -> "absent"
              | Some target ->
                  let entry = Types.show_region (RVar (Free rid0))
                    ^ " -> " ^ Types.show_region (RVar (Free target)) in
                  if RegionId.Set.mem rid0 fixed_ids.rids then
                    entry ^ "\norigin: fixed_ids.rids identity"
                    ^ "\nprior type/symbolic pair: analysis unavailable: fixed identity initialization"
                    ^ field "prior left authentic source" (fun () -> source ctx0 (RVar (Free rid0)))
                    ^ field "prior right authentic source" (fun () -> source ctx1 (RVar (Free target)))
                  else
                    match RegionId.Map.find_opt rid0 !origins with
                    | Some (recorded, origin, pair, symbols) when recorded = target ->
                        entry ^ "\norigin: " ^ origin
                        ^ describe_pair pair symbols
                        ^ (match pair with
                           | Some (left, right, _, _) ->
                               field "prior left authentic source" (fun () -> source left (RVar (Free rid0)))
                               ^ field "prior right authentic source" (fun () -> source right (RVar (Free target)))
                           | None ->
                               field "prior left authentic source" (fun () -> source ctx0 (RVar (Free rid0)))
                               ^ field "prior right authentic source" (fun () -> source ctx1 (RVar (Free target))))
                    | _ ->
                        entry ^ "\norigin: analysis unavailable: registration record limit"
                        ^ "\nprior type/symbolic pair: analysis unavailable: registration record limit"
                        ^ "\nprior left authentic source: analysis unavailable: registration context"
                        ^ "\nprior right authentic source: analysis unavailable: registration context")
            in
            (*
```
*)
            let inverse = field "existing inverse entry and registration origin" (fun () ->
              if RegionId.InjSubst.cardinal before > 256 then
                failwith "Region correspondence limit";
              let existing = RegionId.InjSubst.fold
                (fun key target found ->
                  if target = rid1 then Some key else found) before None
              in
              match existing with
              | None -> "absent"
              | Some key ->
                  let entry = Types.show_region (RVar (Free key))
                    ^ " -> " ^ Types.show_region (RVar (Free rid1)) in
                  if RegionId.Set.mem key fixed_ids.rids then
                    entry ^ "\norigin: fixed_ids.rids identity"
                    ^ field "existing left authentic source" (fun () -> source ctx0 (RVar (Free key)))
                    ^ field "existing right authentic source" (fun () -> source ctx1 (RVar (Free rid1)))
                  else
                    match RegionId.Map.find_opt key !origins with
                    | Some (target, origin, pair, symbols) when target = rid1 ->
                        entry ^ "\norigin: " ^ origin
                        ^ describe_pair pair symbols
                        ^ (match pair with
                           | Some (left, right, _, _) ->
                               field "existing left authentic source" (fun () -> source left (RVar (Free key)))
                               ^ field "existing right authentic source" (fun () -> source right (RVar (Free rid1)))
                           | None ->
                               field "existing left authentic source" (fun () -> source ctx0 (RVar (Free key)))
                               ^ field "existing right authentic source" (fun () -> source ctx1 (RVar (Free rid1))))
                    | _ -> entry ^ "\norigin: analysis unavailable: registration record limit")
            in
            let left, right = match !type_pair with
              | Some (left, right, _, _) -> left, right
              | None -> ctx0, ctx1
            in
            let event =
              "Carrier rejected region correspondence event:"
              ^ "\nsource span: " ^ Errors.span_to_string span
              ^ "\noriginal exception: " ^ Printexc.to_string error
              ^ "\nregistration operation: " ^ operation
              ^ "\nleft execution region: " ^ Types.show_region (RVar (Free rid0))
              ^ "\nright execution region: " ^ Types.show_region (RVar (Free rid1))
              (*
```ocaml
*)
              ^ forward ^ inverse ^ describe_pair !type_pair !symbolic_pair
              (*
```
*)
              ^ field "failed left authentic source" (fun () -> source left (RVar (Free rid0)))
              ^ field "failed right authentic source" (fun () -> source right (RVar (Free rid1)))
              ^ field "left ownership masks" (fun () -> masks left)
              ^ field "right ownership masks" (fun () -> masks right)
              ^ field "fixed_ids.rids" (fun () -> region_set fixed_ids.rids)
            in
            if !Config.print_error_diagnostics || !Config.print_error_emitters then
              Printf.eprintf "%s\n%!" event
            else [%ldebug event]
      with error ->
        (try
           [%ldebug
             "Carrier region correspondence analysis unavailable event:"
             ^ "\nsource span: " ^ Errors.span_to_string span
             ^ "\nanalysis exception: " ^ Printexc.to_string error]
         with _ -> ())
    in
    Some { type_pair; symbolic_pair; origins; registrations; registration_location; observe }
  with error ->
    (try
       [%ldebug
         "Carrier region correspondence analysis unavailable event:"
         ^ "\nanalysis exception: " ^ Printexc.to_string error]
     with _ -> ());
    None
(* 
```
*)

module MakeCheckEquivMatcher (S : MatchCheckEquivState) : CheckEquivMatcher =
struct
  let span = S.span
  let recover = S.recover

  module MkGetSetM (Id : Identifiers.Id) = struct
    module Inj = Id.InjSubst

    let add (msg : string) (m : Inj.t ref) (k0 : Id.id) (k1 : Id.id) =
      (* Check if k0 is already registered as a key *)
      match Inj.find_opt k0 !m with
      | None ->
          (* Not registered: check if k1 is in the set of values,
             otherwise add the binding *)
          if Inj.Set.mem k1 (Inj.elements !m) then
            raise
              (Distinct
                 (msg ^ "adding [k0=" ^ Id.to_string k0 ^ " -> k1="
                ^ Id.to_string k1 ^ " ]: k1 already in the set of elements"))
          else (
            m := Inj.add k0 k1 !m;
            k1)
      | Some k1' ->
          (* It is: check that the bindings are consistent *)
          if k1 <> k1' then
            raise (Distinct (msg ^ "conflicting binding: " ^ Id.to_string k0
              ^ " -> " ^ Id.to_string k1' ^ ", requested " ^ Id.to_string k1))
          else k1

    (*
```ocaml
*)
    let match_e ?observe (msg : string) (m : Inj.t ref) (k0 : Id.id) (k1 : Id.id) : Id.id =
      match observe with
      | None -> add msg m k0 k1
      | Some observe ->
          let before = !m in
          try
            let result = add msg m k0 k1 in
            (try observe before k0 k1 None with _ -> ());
            result
          with Distinct _ as error ->
            let trace = Printexc.get_raw_backtrace () in
            (try observe before k0 k1 (Some error) with _ -> ());
            Printexc.raise_with_backtrace error trace

    let match_el ?observe (msg : string) (m : Inj.t ref) (kl0 : Id.id list)
        (kl1 : Id.id list) : Id.id list =
      if List.length kl0 != List.length kl1 then
        raise (Distinct "Not the same number of elements");
      List.map (fun (k0, k1) -> match_e ?observe msg m k0 k1) (List.combine kl0 kl1)
    (*
```
*)

    (** Figuring out mappings between sets of ids is hard in all generality...
        We use the fact that the fresh ids should have been generated the same
        way (i.e., in the same order) and match the ids two by two in increasing
        order.

        The ids which are already mapped keep their images: only the other ids
        are matched by order. An id can be preserved from one context to the
        other while the ids around it are regenerated, which changes its rank
        in the set: for instance an abstraction of a loop fixed point which the
        join of the next iteration leaves untouched, next to abstractions which
        the join regenerates, all of them parents of the same abstraction. When
        the ranks agree, this is the matching by order. *)
    (*
```ocaml
*)
    let match_es ?observe (msg : string) (m : Inj.t ref) (ks0 : Id.Set.t)
        (ks1 : Id.Set.t) : Id.Set.t =
      if Id.Set.cardinal ks0 <> Id.Set.cardinal ks1 then
        raise (Distinct "Not the same number of elements");
      let mapped0, unmapped0 = Id.Set.partition (fun k0 -> Inj.mem k0 !m) ks0 in
      let mapped1 = Id.Set.map (fun k0 -> Inj.find k0 !m) mapped0 in
      if not (Id.Set.subset mapped1 ks1) then
        raise (Distinct (msg ^ "an id is already mapped outside of the set"));
      let unmapped1 = Id.Set.diff ks1 mapped1 in
      ignore
        (match_el ?observe msg m (Id.Set.elements unmapped0) (Id.Set.elements unmapped1));
      ks1
    (*
```
*)
  end

  module GetSetRid = MkGetSetM (RegionId)

  (*
```ocaml
*)
  let match_rid_with_origin origin rid0 rid1 =
    match S.region_diagnostic with
    | None -> GetSetRid.match_e "match_rid: " S.rid_map rid0 rid1
    | Some _ when not (region_match_diagnostics_enabled ()) ->
        GetSetRid.match_e "match_rid: " S.rid_map rid0 rid1
    | Some diagnostic ->
        GetSetRid.match_e ~observe:(diagnostic.observe origin)
          "match_rid: " S.rid_map rid0 rid1

  let match_rid = match_rid_with_origin "region correspondence"

  let match_rids ids0 ids1 =
    match S.region_diagnostic with
    | None -> GetSetRid.match_es "match_rids: " S.rid_map ids0 ids1
    | Some _ when not (region_match_diagnostics_enabled ()) ->
        GetSetRid.match_es "match_rids: " S.rid_map ids0 ids1
    | Some diagnostic ->
        GetSetRid.match_es
          ~observe:(diagnostic.observe "abstraction owned region set")
          "match_rids: " S.rid_map ids0 ids1
  (*
```
*)

  module GetSetBid = MkGetSetM (BorrowId)

  let match_blid msg = GetSetBid.match_e msg S.blid_map
  let match_blidl msg = GetSetBid.match_el msg S.blid_map
  let match_blids msg = GetSetBid.match_es msg S.blid_map

  let match_borrow_id =
    if S.check_equiv then match_blid "match_borrow_id: "
    else GetSetBid.match_e "match_borrow_id: " S.borrow_id_map

  let match_borrow_idl =
    if S.check_equiv then match_blidl "match_borrow_idl: "
    else GetSetBid.match_el "match_borrow_idl: " S.borrow_id_map

  let match_borrow_ids =
    if S.check_equiv then match_blids "match_borrow_ids: "
    else GetSetBid.match_es "match_borrow_ids: " S.borrow_id_map

  let match_loan_id =
    if S.check_equiv then match_blid "match_loan_id: "
    else GetSetBid.match_e "match_loan_id: " S.loan_id_map

  let match_loan_idl =
    if S.check_equiv then match_blidl "match_loan_idl: "
    else GetSetBid.match_el "match_loan_idl: " S.loan_id_map

  let match_loan_ids =
    if S.check_equiv then match_blids "match_loan_ids: "
    else GetSetBid.match_es "match_loan_ids: " S.loan_id_map

  module GetSetSid = MkGetSetM (SymbolicValueId)
  module GetSetAid = MkGetSetM (AbsId)

  let match_aid = GetSetAid.match_e "match_aid: " S.aid_map
  let match_aidl = GetSetAid.match_el "match_aidl: " S.aid_map
  let match_aids = GetSetAid.match_es "match_aids: " S.aid_map

  (** *)
  let match_etys (_ : eval_ctx) (_ : eval_ctx) ty0 ty1 =
    if ty0 <> ty1 then raise (Distinct "match_etys") else ty0

  (*
```ocaml
*)
  let match_rtys_impl (ctx0 : eval_ctx) (ctx1 : eval_ctx) ty0 ty1 =
    let match_distinct_types ty0 ty1 =
      raise
        (Distinct
           ("match_rtys:\n- ty0: " ^ ty_to_string ctx0 ty0 ^ "\n- ty1: "
          ^ ty_to_string ctx1 ty1))
    in
    let rename_metadata_region = function
      | RVar (Free rid) as r ->
          (match RegionId.InjSubst.find_opt rid !S.rid_map with
          | Some rid -> RVar (Free rid)
          | None -> r)
      | r -> r
    in
    let match_metadata_regions r0 r1 =
      if
        rename_metadata_region (metadata_region ctx0.metadata_bindings r0)
        <> metadata_region ctx1.metadata_bindings r1
      then
        raise (Distinct "Distinct metadata regions");
      r1
    in
    let match_metadata_types ty0 ty1 =
      if
        map_free_region_aliases rename_metadata_region
          (resolve_projection_metadata_ty ctx0 ty0)
        <> resolve_projection_metadata_ty ctx1 ty1
      then
        raise (Distinct "Distinct metadata types");
      ty1
    in
    (* Establish correspondence from complete stored positions before metadata.
       A callback may precede the reference with which it shares a lifetime. *)
    let storage =
      projection_metadata_renaming ~mismatch:(Distinct "Distinct stored types")
        span ctx0.type_ctx.type_infos ty0 ty1
    in
    RegionId.Map.iter
      (fun rid0 r1 ->
        match r1 with
        | RVar (Free rid1) ->
            (try ignore (match_rid_with_origin "stored-position prepass" rid0 rid1)
             with Distinct message ->
               raise (Distinct (message ^ "\nFirst stored type: "
                 ^ ty_to_string ctx0 ty0 ^ "\nSecond stored type: "
                 ^ ty_to_string ctx1 ty1)))
        | _ -> raise (Distinct "Distinct stored regions"))
      storage;
    let match_regions r0 r1 =
      match (r0, r1) with
      | RStatic, RStatic -> r1
      | RVar (Free rid0), RVar (Free rid1) ->
          let rid = match_rid_with_origin "structural type reference" rid0 rid1 in
          RVar (Free rid)
      | _ -> raise (Distinct "match_rtys")
    in
    match_types span ~recover ctx0 ctx1 match_distinct_types match_regions
      match_metadata_regions match_metadata_types ty0 ty1

  let match_rtys ctx0 ctx1 ty0 ty1 =
    match S.region_diagnostic with
    | None -> match_rtys_impl ctx0 ctx1 ty0 ty1
    | Some _ when not (region_match_diagnostics_enabled ()) ->
        match_rtys_impl ctx0 ctx1 ty0 ty1
    | Some diagnostic ->
        let previous = !(diagnostic.type_pair) in
        diagnostic.type_pair := Some (ctx0, ctx1, ty0, ty1);
        Fun.protect
          ~finally:(fun () -> diagnostic.type_pair := previous)
          (fun () -> match_rtys_impl ctx0 ctx1 ty0 ty1)
  (*
```
*)

  let match_distinct_literals (_ : tvalue_matcher) (ctx0 : eval_ctx)
      (_ : eval_ctx) (ty : ety) (_ : literal) (_ : literal) : tvalue =
    mk_fresh_symbolic_tvalue_from_no_regions_ty span ctx0 ty

  let match_distinct_adts (_ : tvalue_matcher) (_ : eval_ctx) (_ : eval_ctx)
      (_ty : ety) _ (_adt0 : adt_value) _ (_adt1 : adt_value) : tvalue =
    raise (Distinct "match_distinct_adts")

  let match_shared_borrows (match_tvalues : tvalue -> tvalue -> tvalue)
      (ctx0 : eval_ctx) (ctx1 : eval_ctx) (_ty : ety) (bid0 : borrow_id)
      (_sid0 : shared_borrow_id) (bid1 : borrow_id) (_sid1 : shared_borrow_id) :
      borrow_id * shared_borrow_id =
    [%ldebug
      "bid0: " ^ BorrowId.to_string bid0 ^ ", bid1: " ^ BorrowId.to_string bid1];

    let bid = match_borrow_id bid0 bid1 in
    (* If we don't check for equivalence (i.e., we apply a fixed-point),
       we lookup the shared values and match them.
    *)
    let _ =
      if S.check_equiv then ()
      else
        let v0 = S.lookup_shared_value_in_ctx0 bid0 in
        let v1 = S.lookup_shared_value_in_ctx1 bid1 in
        [%ldebug
          "looked up values:" ^ "sv0: "
          ^ tvalue_to_string ~span:(Some span) ctx0 v0
          ^ ", sv1: "
          ^ tvalue_to_string ~span:(Some span) ctx1 v1];

        let v0, v1 = align_shared_loans v0 v1 in
        let _ = match_tvalues v0 v1 in
        ()
    in
    (* The shared borrow id doesn't really matter but it's always safer to refresh it *)
    (bid, ctx0.fresh_shared_borrow_id ())

  let match_mut_borrows (_ : tvalue_matcher) (_ : eval_ctx) (_ : eval_ctx)
      (_ty : ety) (bid0 : borrow_id) (_bv0 : tvalue) (bid1 : borrow_id)
      (_bv1 : tvalue) (bv : tvalue) : borrow_id * tvalue =
    let bid = match_borrow_id bid0 bid1 in
    (bid, bv)

  let match_distinct_nested_mut_borrows (match_tvalues : tvalue_matcher)
      (ctx0 : eval_ctx) (ctx1 : eval_ctx) (ty : ety) (bid0 : borrow_id)
      (bv0 : tvalue) (bid1 : borrow_id) (bv1 : tvalue) : tvalue =
    let bv = match_tvalues bv0 bv1 in
    let bid, bv =
      match_mut_borrows match_tvalues ctx0 ctx1 ty bid0 bv0 bid1 bv1 bv
    in
    { value = VBorrow (VMutBorrow (bid, bv)); ty }

  (*
```ocaml
  *)
  let match_shared_loans (match_rec : tvalue_matcher) (_ : eval_ctx)
      (_ : eval_ctx) (ty : ety) (id0 : loan_id) (id1 : loan_id)
      (sv0 : tvalue) (sv1 : tvalue) : tvalue =
    let sv = match_rec sv0 sv1 in
    let id = match_loan_id id0 id1 in
    { value = VLoan (VSharedLoan (id, sv)); ty }
  (*
```
  *)

  let match_mut_loans (_ : tvalue_matcher) (_ : eval_ctx) (_ : eval_ctx)
      (ty : ety) (bid0 : loan_id) (bid1 : loan_id) : tvalue =
    let bid = match_loan_id bid0 bid1 in
    { value = VLoan (VMutLoan bid); ty }

  let match_symbolic_value_ids (id0 : symbolic_value_id)
      (id1 : symbolic_value_id) : symbolic_value_id =
    if S.check_equiv then (
      [%sanity_check_recover] S.recover span
        (not (SymbolicValueId.Map.mem id0 !S.sid_to_value_map));

      (* Create the joined symbolic value *)
      GetSetSid.match_e "ids: " S.sid_map id0 id1)
    else (
      (* Check: fixed values are fixed *)
      [%sanity_check_recover] S.recover span
        (match SymbolicValueId.InjSubst.find_opt id0 !S.sid_map with
        | None -> true
        | Some id1' -> id1 = id1');

      (* Create the joined symbolic value *)
      GetSetSid.match_e "ids: " S.sid_map id0 id1)

  let match_symbolic_values (_ : tvalue_matcher) (ctx0 : eval_ctx)
      (ctx1 : eval_ctx) (sv0 : symbolic_value) (sv1 : symbolic_value) : tvalue =
    let id0 = sv0.sv_id in
    let id1 = sv1.sv_id in

    [%ldebug
      "\n- sv0: "
      ^ symbolic_value_to_string ctx0 sv0
      ^ "\n- sv1: "
      ^ symbolic_value_to_string ctx1 sv1];

    (* If we don't check for equivalence, we also update the map from sids
       to values *)
    if S.check_equiv then
      (* Create the joined symbolic value *)
      let sv_id = GetSetSid.match_e "ids: " S.sid_map id0 id1 in

      (*
```ocaml
*)
      let sv_ty =
        match S.region_diagnostic with
        | None -> match_rtys ctx0 ctx1 sv0.sv_ty sv1.sv_ty
        | Some _ when not (region_match_diagnostics_enabled ()) ->
            match_rtys ctx0 ctx1 sv0.sv_ty sv1.sv_ty
        | Some diagnostic ->
            let previous = !(diagnostic.symbolic_pair) in
            diagnostic.symbolic_pair := Some (sv0, sv1);
            Fun.protect
              ~finally:(fun () -> diagnostic.symbolic_pair := previous)
              (fun () -> match_rtys ctx0 ctx1 sv0.sv_ty sv1.sv_ty)
      in
      (*
```
*)
      let sv = { sv_id; sv_ty } in
      mk_tvalue_from_symbolic_value ctx0.type_ctx.type_infos ctx0.metadata_bindings sv
    else (
      (* Check: fixed values are fixed *)
      [%sanity_check_recover] S.recover span
        (id0 = id1
        ||
        match SymbolicValueId.InjSubst.find_opt id0 !S.sid_map with
        | None -> true
        | Some id1' -> id1 = id1');
      [%ldebug
        "Current mapping: "
        ^ Print.option_to_string (tvalue_to_string ctx1)
            (SymbolicValueId.Map.find_opt id0 !S.sid_to_value_map)];

      let sv1 = mk_tvalue_from_symbolic_value ctx1.type_ctx.type_infos ctx1.metadata_bindings sv1 in
      (* We check consistency explicitly and raise [Distinct] on mismatch
         instead of relying on [add_strict_or_unchanged], whose [Assert_failure]
         would bypass [try_match_ctxs]'s recovery mechanism. *)
      (match SymbolicValueId.Map.find_opt id0 !S.sid_to_value_map with
      | Some sv1' when sv1 <> sv1' ->
          raise (Distinct "match_symbolic_values: incoherent value mapping")
      | _ -> ());
      S.sid_to_value_map :=
        SymbolicValueId.Map.add_strict_or_unchanged id0 sv1 !S.sid_to_value_map;

      (* Return - the returned value is not used: we can return whatever
         we want *)
      mk_tvalue_from_symbolic_value ctx0.type_ctx.type_infos ctx0.metadata_bindings sv0)

  let match_symbolic_with_other (_ : tvalue_matcher) (_ : eval_ctx)
      (_ : eval_ctx) ~(symbolic_is_left : bool) (sv : symbolic_value)
      (v : tvalue) : tvalue =
    if S.check_equiv then raise (Distinct "match_symbolic_with_other")
    else (
      [%sanity_check_recover] S.recover span symbolic_is_left;
      let id = sv.sv_id in
      (* Check: fixed values are fixed *)
      [%sanity_check_recover] S.recover span
        (not (SymbolicValueId.InjSubst.mem id !S.sid_map));
      (* Update the binding for the target symbolic value.
         See the comment in [match_symbolic_values] for why we avoid
         [add_strict_or_unchanged] and check consistency explicitly. *)
      (match SymbolicValueId.Map.find_opt id !S.sid_to_value_map with
      | Some v' when v <> v' ->
          raise (Distinct "match_symbolic_with_other: incoherent value mapping")
      | _ -> ());
      S.sid_to_value_map := SymbolicValueId.Map.add id v !S.sid_to_value_map;
      (* Return - the returned value is not used, so we can return whatever we want *)
      v)

  let match_bottom_with_other (_ : tvalue_matcher) (ctx0 : eval_ctx)
      (ctx1 : eval_ctx) ~(bottom_is_left : bool) (v : tvalue) : tvalue =
    (* It can happen that some variables get initialized in some branches
       and not in some others, which causes problems when matching. *)
    (* TODO: the returned value is not used, while it should: in generality it
       should be ok to match a fixed-point with the environment we get at
       a continue, where the fixed point contains some bottom values. *)
    let value_is_left = not bottom_is_left in
    let ctx = if value_is_left then ctx0 else ctx1 in
    if
      bottom_is_left && not (value_has_loans_or_borrows (Some span) ctx v.value)
    then mk_bottom span ctx0.type_ctx.type_infos v.ty
    else
      raise
        (Distinct
           ("match_bottom_with_other:\n- bottom value is in left environment: "
           ^ Print.bool_to_string bottom_is_left
           ^ "\n- value to match with bottom:\n" ^ show_tvalue v))

  let match_shared_loan_with_other (_ : tvalue_matcher) (_ : eval_ctx)
      (_ : eval_ctx) ~(loan_is_left : bool) (_ : ety) (_ : loan_id) (_ : tvalue)
      (_ : tvalue) : tvalue =
    let _ = loan_is_left in
    raise (Distinct "match_mut_loan_with_other")

  let match_mut_loan_with_other (_ : tvalue_matcher) (_ : eval_ctx)
      (_ : eval_ctx) ~(loan_is_left : bool) (_ : ety) (_ : loan_id) (_ : tvalue)
      : tvalue =
    let _ = loan_is_left in
    raise (Distinct "match_mut_loan_with_other")

  let match_distinct_aadts _ _ _ _ _ _ _ =
    raise (Distinct "match_distinct_adts")

  let match_ashared_borrows (_ : tvalue_matcher) (ctx0 : eval_ctx)
      (_ : eval_ctx) _ty0 pm0 bid0 _sid0 _ty1 pm1 bid1 _sid1 ty : tavalue =
    (* We are checking whether that two environments are equivalent:
       there shouldn't be any projection markers *)
    [%sanity_check_recover] S.recover span (pm0 = PNone && pm1 = PNone);
    let bid = match_borrow_id bid0 bid1 in
    (* It's always safer to refresh shared borrow ids *)
    let sid = ctx0.fresh_shared_borrow_id () in
    let value = ABorrow (ASharedBorrow (PNone, bid, sid)) in
    { value; ty }

  let match_amut_borrows (_ : tvalue_matcher) (_ : eval_ctx) (_ : eval_ctx) _ty0
      pm0 bid0 _av0 _ty1 pm1 bid1 _av1 ty av : tavalue =
    (* We are checking whether that two environments are equivalent:
       there shouldn't be any projection markers *)
    [%sanity_check_recover] S.recover span (pm0 = PNone && pm1 = PNone);
    let bid = match_borrow_id bid0 bid1 in
    let value = ABorrow (AMutBorrow (PNone, bid, av)) in
    { value; ty }

  let match_ashared_loans (_ : tvalue_matcher) (_ : eval_ctx) (_ : eval_ctx)
      _ty0 pm0 id0 _v0 _av0 _ty1 pm1 id1 _v1 _av1 ty v av : tavalue =
    (* We are checking whether that two environments are equivalent:
       there shouldn't be any projection markers *)
    [%sanity_check_recover] S.recover span (pm0 = PNone && pm1 = PNone);
    let bid = match_loan_id id0 id1 in
    let value = ALoan (ASharedLoan (PNone, bid, v, av)) in
    { value; ty }

  let match_amut_loans (_ : tvalue_matcher) (ctx0 : eval_ctx) (ctx1 : eval_ctx)
      _ty0 pm0 id0 _av0 _ty1 pm1 id1 _av1 ty av : tavalue =
    (* We are checking whether that two environments are equivalent:
       there shouldn't be any projection markers *)
    [%sanity_check_recover] S.recover span (pm0 = PNone && pm1 = PNone);
    [%ldebug
      "- id0: " ^ BorrowId.to_string id0 ^ "\n- id1: " ^ BorrowId.to_string id1
      ^ "\n- ty: " ^ ty_to_string ctx0 ty ^ "\n- av: "
      ^ tavalue_to_string ~span:(Some span) ctx1 av];

    let id = match_loan_id id0 id1 in
    let value = ALoan (AMutLoan (PNone, id, av)) in
    { value; ty }

  let match_apending_loans pm0 bid0 pm1 bid1 ty : tavalue =
    [%sanity_check_recover] S.recover span (pm0 = PNone && pm1 = PNone);
    let bid = match_borrow_id bid0 bid1 in
    { value = ASymbolic (PNone, APendingLoans bid); ty }

  let match_apending_symbolic_loans ctx0 ctx1 pm0
      (slot0 : symbolic_pending_slot) pm1 (slot1 : symbolic_pending_slot) ty0 ty :
      tavalue =
    [%sanity_check_recover] S.recover span (pm0 = PNone && pm1 = PNone);
    [%sanity_check_recover] S.recover span
      (ty_is_rty ctx0.type_ctx.type_infos slot0.proj_ty
       && ty_is_rty ctx1.type_ctx.type_infos slot1.proj_ty);
    let known_root =
      SymbolicValueId.InjSubst.find_opt slot0.root_sv_id !S.sid_map
    in
    let known_value =
      SymbolicValueId.Map.find_opt slot0.root_sv_id !S.sid_to_value_map
    in
    let root_matches =
      (match known_root with
      | None -> true
      | Some root -> root = slot1.root_sv_id)
      && (match known_value with
         | None -> true
         | Some { value = VSymbolic sv; _ } -> sv.sv_id = slot1.root_sv_id
         | Some _ -> false)
      && (Option.is_some known_root || Option.is_some known_value
          || slot0.root_sv_id = slot1.root_sv_id)
    in
    if not root_matches then
      raise (Distinct "No established pending symbolic root correspondence");
    (match (known_root, known_value) with
    | None, None ->
        ignore (match_symbolic_value_ids slot0.root_sv_id slot1.root_sv_id)
    | _ -> ());
    let rename_region = function
      | RVar (Free rid) as r ->
          (match RegionId.InjSubst.find_opt rid !S.rid_map with
          | Some rid -> RVar (Free rid)
          | None -> r)
      | r -> r
    in
    ignore (match_rtys ctx0 ctx1 ty0 ty);
    ignore (match_rtys ctx0 ctx1 slot0.proj_ty slot1.proj_ty);
    let mapped_slot =
      rename_symbolic_pending_slot slot1.root_sv_id rename_region slot0
    in
    if
      mapped_slot.root_sv_id <> slot1.root_sv_id
      || mapped_slot.proj_regions <> slot1.proj_regions
      || mapped_slot.ancestor_path <> slot1.ancestor_path
      || mapped_slot.value_path <> slot1.value_path
    then
      raise (Distinct "Distinct complete pending symbolic dependencies");
    { value = ASymbolic (PNone, APendingSymbolicLoans slot1); ty }

  let match_aignored_mut_loan (_match_rec : tvalue_matcher) (_ctx0 : eval_ctx)
      (_ctx1 : eval_ctx)
      ((_ty0, pm0, bid0, _child0) : rty * proj_marker * borrow_id option * tavalue)
      ((_ty1, pm1, bid1, _child1) : rty * proj_marker * borrow_id option * tavalue) (ty : ty)
      (child : tavalue) : tavalue =
    if pm0 <> pm1 then raise (Distinct "Distinct ignored parent branch scopes");
    let bid =
      match (bid0, bid1) with
      | None, None -> None
      | Some bid0, Some bid1 -> Some (match_loan_id bid0 bid1)
      | _ -> raise (Distinct "match_aignored_mut_loan: bids")
    in
    { value = ALoan (AIgnoredMutLoan (pm1, bid, child)); ty }

  let match_aignored_mut_borrow (_match_rec : tvalue_matcher) (_ctx0 : eval_ctx)
      (_ctx1 : eval_ctx)
      ((_ty0, bid0, _child0) : rty * borrow_id option * tavalue)
      ((_ty1, bid1, _child1) : rty * borrow_id option * tavalue) (ty : ty)
      (child : tavalue) : tavalue =
    let bid =
      match (bid0, bid1) with
      | None, None -> None
      | Some bid0, Some bid1 -> Some (match_borrow_id bid0 bid1)
      | _ -> raise (Distinct "match_aignored_mut_borrow: bids")
    in
    { value = ABorrow (AIgnoredMutBorrow (bid, child)); ty }

  let match_aended_ignored_mut_borrow (_match_rec : tvalue_matcher)
      (_ctx0 : eval_ctx) (_ctx1 : eval_ctx)
      ((_ty0, bc0) : rty * aended_ignored_mut_borrow)
      ((_ty1, _bc1) : rty * aended_ignored_mut_borrow) (ty : ty)
      (child : tavalue) (given_back : tavalue) : tavalue =
    (* We take the meta information from the left - it doesn't really matter *)
    let given_back_meta = bc0.given_back_meta in
    {
      value =
        ABorrow (AEndedIgnoredMutBorrow { child; given_back; given_back_meta });
      ty;
    }

  let match_aproj_borrows (_match_values : tvalue_matcher) (ctx0 : eval_ctx)
      (ctx1 : eval_ctx) _ty0 pm0 (proj0 : aproj_borrows) _ty1 pm1
      (proj1 : aproj_borrows) ty proj_ty : tavalue =
    [%ldebug
      "- proj0: "
      ^ aproj_borrows_to_string ctx0 proj0
      ^ "\n- proj1: "
      ^ aproj_borrows_to_string ctx1 proj1];
    [%sanity_check_recover] S.recover span (pm0 = PNone && pm1 = PNone);
    let { proj = proj0; loans = loans0 } : aproj_borrows = proj0 in
    let { proj = proj1; loans = loans1 } : aproj_borrows = proj1 in
    [%sanity_check_recover] S.recover span (loans0 = [] && loans1 = []);
    (* Match the ids of the symbolic values *)
    let sv_id = match_symbolic_value_ids proj0.sv_id proj1.sv_id in
    let proj : symbolic_proj = { sv_id; proj_ty } in
    { value = ASymbolic (PNone, AProjBorrows { proj; loans = [] }); ty }

  let match_aproj_loans (_match_values : tvalue_matcher) (ctx0 : eval_ctx)
      (ctx1 : eval_ctx) _ty0 pm0 (proj0 : aproj_loans) _ty1 pm1
      (proj1 : aproj_loans) ty proj_ty : tavalue =
    [%ldebug
      "- proj0: "
      ^ aproj_loans_to_string ctx0 proj0
      ^ "\n- proj1: "
      ^ aproj_loans_to_string ctx1 proj1];
    [%sanity_check_recover] S.recover span (pm0 = PNone && pm1 = PNone);
    let { proj = proj0; consumed = consumed0; borrows = borrows0 } : aproj_loans
        =
      proj0
    in
    let { proj = proj1; consumed = consumed1; borrows = borrows1 } : aproj_loans
        =
      proj1
    in
    [%sanity_check_recover] S.recover span (consumed0 = [] && consumed1 = []);
    [%sanity_check_recover] S.recover span (borrows0 = [] && borrows1 = []);
    (* Match the ids of the symbolic values *)
    let sv_id = match_symbolic_value_ids proj0.sv_id proj1.sv_id in
    let proj : symbolic_proj = { sv_id; proj_ty } in
    let proj = AProjLoans { proj; consumed = []; borrows = [] } in
    { value = ASymbolic (PNone, proj); ty }

  let match_avalues (_ : tvalue_matcher) (ctx0 : eval_ctx) (ctx1 : eval_ctx) v0
      v1 =
    [%ldebug
      "avalues don't match:\n- v0: "
      ^ tavalue_to_string ~span:(Some span) ctx0 v0
      ^ "\n- v1: "
      ^ tavalue_to_string ~span:(Some span) ctx1 v1];
    raise (Distinct "match_avalues")
end

(** Comparison view of a shared loan whose payload holds shared loans (the
    loans of reborrowed components, as for [for (x, y) in &v]): the payload
    without its loans, followed by one shared loan per inner loan, in the same
    region. Joining two such loans with distinct identifiers yields this flat
    form (the joined payload, and one joined loan per joined inner borrow),
    while a fixed point which did not have to join them keeps the nested form.
    Both denote the same shared ownership. *)
let flatten_shared_loan_view (span : Meta.span) (ctx : eval_ctx) (av : tavalue)
    : tavalue list * eval_ctx =
  match (av.value, av.ty) with
  | ALoan (ASharedLoan (pm, lid, sv, child)), TRef (region, _, RShared) ->
      let inner = ref [] in
      let metadata_bindings = ref ctx.metadata_bindings in
      let visitor =
        object (self)
          inherit [_] map_tvalue as super

          method! visit_tvalue env v =
            match v.value with
            | VLoan (VSharedLoan (lid, v)) ->
                let v = self#visit_tvalue env v in
                let ctx = ctx_with_metadata_bindings ctx !metadata_bindings in
                let rty, bindings = retained_value_rty span ctx v in
                let () = metadata_bindings := bindings in
                let child = mk_aignored span ctx.type_ctx.type_infos rty None in
                let value = ALoan (ASharedLoan (pm, lid, v, child)) in
                let loan : tavalue = { value; ty = TRef (region, rty, RShared) } in
                inner := loan :: !inner;
                v
            | _ -> super#visit_tvalue env v
        end
      in
      let sv = visitor#visit_tvalue () sv in
      let values =
        { av with value = ALoan (ASharedLoan (pm, lid, sv, child)) }
        :: List.rev !inner
      in
      (values, ctx_with_metadata_bindings ctx !metadata_bindings)
  | _ -> ([ av ], ctx)

type local_bag_operand =
  | LocalValue of eval_ctx * tavalue
  | LocalGroup of bool * symbolic_value_id * rty

type local_bag_remainder = {
  remainder_stage : string;
  remainder_step : int;
  remainder_reason : string;
  left_count : int;
  right_count : int;
  left_prefix : local_bag_operand list;
  right_prefix : local_bag_operand list;
}

type local_bag_payload =
  | LocalPair of local_bag_operand * local_bag_operand
  | LocalRemainder of local_bag_remainder
  | LocalFinish

type local_bag_failure = {
  local_stage : string;
  local_step : int;
  local_candidate : int;
  local_context0 : eval_ctx;
  local_context1 : eval_ctx;
  local_payload : local_bag_payload;
  local_exception : exn;
  local_trace : Printexc.raw_backtrace;
  local_before : ids_maps option;
  local_at_rejection : ids_maps;
  local_exhaustions : local_bag_remainder list;
  local_exhaustions_omitted : int;
}

let local_correspondence_maps (rids, blids, bids, lids, aids, sids, values, _) : ids_maps =
  { rid_map = rids; blid_map = blids; borrow_id_map = bids; loan_id_map = lids;
    aid_map = aids; sid_map = sids; sid_to_value_map = values }

let local_failure_read = function None -> None | Some cell -> !cell
let local_failure_write cell value = match cell with None -> () | Some cell -> cell := value

let local_failure_rank entry =
  ((match entry.local_stage with "owned-set-finish" -> 3 | "groups" -> 2
    | "shared-values" -> 1 | _ -> 0), entry.local_step)

let local_failure_keep cell value =
  match local_failure_read cell, value with
  | _, None -> ()
  | None, Some _ -> local_failure_write cell value
  | Some previous, Some current ->
      if local_failure_rank current > local_failure_rank previous then
        local_failure_write cell value

let local_operand_prefix operand side values =
  let rec take remaining = function
    | [] -> []
    | _ when remaining = 0 -> []
    | value :: rest -> operand side value :: take (remaining - 1) rest
  in take 2 values

(* Select one local candidate. Selection does not establish a terminal cause. *)
let sole_abs_candidate candidate env =
  let rec scan found remaining = function
    | [] -> (match found with Some abs -> abs == candidate | None -> false)
    | _ when remaining = 0 -> false
    | EAbs abs :: rest ->
        (match found with None -> scan (Some abs) (remaining - 1) rest | Some _ -> false)
    | _ :: rest -> scan found (remaining - 1) rest
  in
  scan None 128 env

let report_local_rejection ~(span : Meta.span) ~check_kind ~check_equiv
    ~check_can_end (ctx0 : eval_ctx) (ctx1 : eval_ctx) (abs0 : abs) (abs1 : abs) before after failure trace inner =
  try
    let exception Limit in
    let output = Buffer.create 4096 in
    let omitted = ref 0 in
    let emit text =
      if String.length text > 24064 - Buffer.length output then raise Limit;
      Buffer.add_string output text
    in
    let integer name n = emit (name ^ "=" ^ string_of_int n ^ "\n") in
    let bounded name text =
      integer (name ^ "-bytes") (String.length text);
      if String.length text > 256 then incr omitted;
      emit (name ^ "=" ^ String.sub text 0 (Stdlib.min 256 (String.length text)) ^ "\n")
    in
    let set name ids =
      let count = RegionId.Set.cardinal ids in
      integer (name ^ "-count") count;
      if count > 128 then (incr omitted; integer (name ^ "-omitted") count)
      else (emit (name ^ "={"); RegionId.Set.iter
        (fun id -> emit (RegionId.to_string id ^ ",")) ids; emit "}\n")
    in
    let check_type ty =
      let nodes = ref 0 in
      let rec visit depth ty =
        incr nodes;
        if depth > 12 || !nodes > 64 then raise Limit;
        match ty with
        | TAdt tref ->
            let args = tref.generics in
            if List.length args.regions > 16 || List.length args.types > 16
               || args.const_generics <> [] || args.trait_refs <> [] then raise Limit;
            List.iter (visit (depth + 1)) args.types
        | TRef (_, child, _) -> visit (depth + 1) child
        | TLiteral _ | TVar _ -> ()
        | _ -> raise Limit
      in visit 0 ty
    in
    let formatted label printer value =
      emit (label ^ ":\n");
      let written = ref 0 in
      let write text start count =
        if count > 4096 - !written || count > 24064 - Buffer.length output then raise Limit;
        written := !written + count;
        Buffer.add_substring output text start count
      in
      let formatter = Format.make_formatter write (fun () -> ()) in
      printer formatter value;
      Format.pp_print_flush formatter ();
      emit "\n"
    in
    let region_source ctx region =
      let rec resolve steps seen = function
        | RVar (Free id) as region ->
            if steps = 0 || RegionId.Set.mem id seen then (incr omitted; emit "source-alias-limit\n")
            else (match RegionId.Map.find_opt id ctx.metadata_bindings with
              | Some (MetadataSource source) -> resolve (steps - 1) (RegionId.Set.add id seen) source
              | Some MetadataFresh ->
                  emit "source=MetadataFresh\n";
                  formatted "terminal-free-source" Types.pp_region region
              | None -> formatted "terminal-free-source" Types.pp_region region)
        | region -> formatted "terminal-source" Types.pp_region region
      in resolve 16 RegionId.Set.empty region
    in
    let raw_type ctx owned effective label ty =
      try
        check_type ty;
        formatted label Types.pp_ty ty;
        if ty_is_rty ctx.type_ctx.type_infos ty then (
          let stored = ty_regions ctx.type_ctx.type_infos ty in
          set "stored-regions" stored;
          set "owner-selected" (RegionId.Set.inter owned stored);
          set "effective-selected" (RegionId.Set.inter effective stored));
        let visitor = object
          inherit [_] iter_ty as super
          method! visit_region _ region =
            formatted "raw-region" Types.pp_region region;
            region_source ctx region
          method! visit_TAdt env tref =
            (match tref.id with
            | TAdtId id ->
                emit ("nominal-id=" ^ TypeDeclId.to_string id ^ "\n");
                (match TypeDeclId.Map.find_opt id ctx.type_ctx.type_infos with
                | None -> incr omitted; emit "nominal-summary-unavailable\n"
                | Some info ->
                    set "nominal-stored-regions" info.stored_regions;
                    set "nominal-metadata-regions" info.metadata_regions;
                    let parameters name ids =
                      let count = TypeVarId.Set.cardinal ids in
                      integer (name ^ "-count") count;
                      if count > 32 then (incr omitted; integer (name ^ "-omitted") count)
                      else TypeVarId.Set.iter (fun id -> emit (name ^ "=" ^ TypeVarId.to_string id ^ "\n")) ids
                    in
                    parameters "nominal-stored-types" info.stored_type_params;
                    parameters "nominal-metadata-types" info.metadata_type_params)
            | _ -> ());
            super#visit_TAdt env tref
        end in
        visitor#visit_ty () ty
      with Limit -> incr omitted; emit "type-or-budget-omitted\n"
    in
    let left_nodes = ref 0 in
    let right_nodes = ref 0 in
    let left_descriptors = ref 0 in
    let right_descriptors = ref 0 in
    let comparison_values left side ctx owned values =
      set (side ^ "-owned") owned;
      integer (side ^ "-avalue-count") (List.length values);
      let nodes = if left then left_nodes else right_nodes in
      let descriptors = if left then left_descriptors else right_descriptors in
      let point (path, depth, effective) tag =
        incr nodes;
        if !nodes > 64 || depth > 12 then raise Limit;
        let path = path ^ "/" ^ tag ^ "[" ^ string_of_int !nodes ^ "]" in
        if String.length path > 1024 then raise Limit;
        emit ("value-walk-path=" ^ path ^ "\n");
        (path, depth + 1, effective)
      in
      let visitor = object (self)
        inherit [_] iter_tavalue as super
        method! visit_ty _ _ = ()
        method! visit_mvalue _ _ = incr omitted
        method! visit_mconsumed_symb _ _ = incr omitted
        method! visit_mgiven_back_symb _ _ = incr omitted
        method! visit_tavalue env (value : tavalue) =
          let ((_, _, effective) as env) = point env "avalue" in
          emit ("avalue-kind=" ^ (match value.value with
            | AAdt _ -> "AAdt" | ALoan _ -> "ALoan" | ABorrow _ -> "ABorrow"
            | ASymbolic _ -> "ASymbolic" | ATransportedValue _ -> "ATransportedValue"
            | AIgnored _ -> "AIgnored") ^ "\n");
          (match value.value with
          | ABorrow borrow -> emit ("borrow-kind=" ^ (match borrow with
              | AMutBorrow _ -> "AMutBorrow" | ASharedBorrow _ -> "ASharedBorrow"
              | AIgnoredMutBorrow _ -> "AIgnoredMutBorrow" | AEndedMutBorrow _ -> "AEndedMutBorrow"
              | AEndedSharedBorrow -> "AEndedSharedBorrow"
              | AEndedIgnoredMutBorrow _ -> "AEndedIgnoredMutBorrow"
              | AProjSharedBorrow _ -> "AProjSharedBorrow") ^ "\n")
          | ALoan loan -> emit ("loan-kind=" ^ (match loan with
              | AMutLoan _ -> "AMutLoan" | ASharedLoan _ -> "ASharedLoan"
              | AEndedMutLoan _ -> "AEndedMutLoan" | AEndedSharedLoan _ -> "AEndedSharedLoan"
              | AIgnoredMutLoan _ -> "AIgnoredMutLoan"
              | AEndedIgnoredMutLoan _ -> "AEndedIgnoredMutLoan"
              | AIgnoredSharedLoan _ -> "AIgnoredSharedLoan") ^ "\n")
          | AAdt adt ->
              integer "actual-field-count" (List.length adt.fields);
              emit ("borrow-projection=" ^ string_of_bool adt.borrow_proj ^ "\n");
              emit ("variant=" ^ (match adt.variant_id with None -> "none"
                | Some id -> VariantId.to_string id) ^ "\n")
          | _ -> ());
          set "effective-owned" effective;
          raw_type ctx owned effective "avalue-type" value.ty;
          super#visit_tavalue env value
        method! visit_tevalue env (value : tevalue) =
        let ((_, _, effective) as env) = point env "expression-value" in
        raw_type ctx owned effective "expression-type" value.ty;
        super#visit_tevalue env value
      method! visit_eproj env proj = super#visit_eproj (point env "expression-projector") proj
      method! visit_tvalue env (value : tvalue) =
          let ((_, _, effective) as env) = point env "concrete-value" in
          raw_type ctx owned effective "concrete-type" value.ty;
          super#visit_tvalue env value
        method! visit_aproj env proj =
        let env = point env "projector" in
        emit ("projector-kind=" ^ (match proj with
          | AProjLoans _ -> "AProjLoans" | AProjBorrows _ -> "AProjBorrows"
          | AEndedProjLoans _ -> "AEndedProjLoans" | AEndedProjBorrows _ -> "AEndedProjBorrows"
          | ATransportedProj _ -> "ATransportedProj" | APendingLoans _ -> "APendingLoans"
          | APendingSymbolicLoans _ -> "APendingSymbolicLoans" | AEmpty -> "AEmpty") ^ "\n");
        super#visit_aproj env proj
        method! visit_symbolic_proj env (proj : symbolic_proj) =
          let _, _, effective = point env "symbolic-projector" in
          emit ("symbolic-id=" ^ SymbolicValueId.to_string proj.sv_id ^ "\n");
          raw_type ctx owned effective "projector-type" proj.proj_ty
        method! visit_symbolic_value env (value : symbolic_value) =
          let _, _, effective = point env "symbolic-value" in
          emit ("symbolic-id=" ^ SymbolicValueId.to_string value.sv_id ^ "\n");
          raw_type ctx owned effective "symbolic-type" value.sv_ty
        method! visit_proj_marker _ marker =
          emit ("marker=" ^ (match marker with PNone -> "PNone"
            | PLeft -> "PLeft" | PRight -> "PRight") ^ "\n")
        method! visit_borrow_id _ id = emit ("borrow-id=" ^ BorrowId.to_string id ^ "\n")
        method! visit_loan_id _ id = emit ("loan-id=" ^ BorrowId.to_string id ^ "\n")
        method! visit_shared_borrow_id _ id = emit ("shared-borrow-id=" ^ SharedBorrowId.to_string id ^ "\n")
        method private transport env (transport : carrier_coordinate_transport) =
          incr descriptors;
          if !descriptors > 8 then raise Limit;
          let path, depth, effective = point env "transport" in
          set "receiver-mask" transport.receiver_regions;
          set "current-mask" transport.current_regions;
          emit ("receiver-id=" ^ SymbolicValueId.to_string transport.receiver.sv_id ^ "\n");
          emit ("current-id=" ^ SymbolicValueId.to_string transport.current.sv_id ^ "\n");
          raw_type ctx owned effective "receiver-type" transport.receiver.proj_ty;
          raw_type ctx owned transport.current_regions "current-type" transport.current.sv_ty;
          (path, depth, transport.current_regions)
        method! visit_ATransportedValue env transport child =
          self#visit_tavalue (self#transport env transport) child
        method! visit_ATransportedProj env transport child =
          self#visit_aproj (self#transport env transport) child
      end in
      (try List.iteri (fun index value ->
         visitor#visit_tavalue (side ^ "/avalues[" ^ string_of_int index ^ "]", 0, owned) value) values
       with Limit -> incr omitted; emit "value-walk-omitted\n")
    in
    let owner side ctx (abs : abs) =
      emit (side ^ "-owner=" ^ AbsId.to_string abs.abs_id ^ "\n");
      comparison_values (side = "source") ("optional-owner-walk/" ^ side) ctx abs.regions.owned abs.avalues
    in
    let maps actual_context label (rids, blids, bids, lids, aids, sids, values, _) =
      emit (label ^ "\n");
      let remaining = ref 128 in
      let row kind left right =
        if !remaining = 0 then raise Limit;
        decr remaining;
        emit (kind ^ "=" ^ left ^ "->" ^ right ^ "\n")
      in
      (try
        RegionId.InjSubst.Map.iter (fun a b -> row "region" (RegionId.to_string a) (RegionId.to_string b)) (RegionId.InjSubst.to_map rids);
        BorrowId.InjSubst.Map.iter (fun a b -> row "shared-borrow" (BorrowId.to_string a) (BorrowId.to_string b)) (BorrowId.InjSubst.to_map blids);
        BorrowId.InjSubst.Map.iter (fun a b -> row "borrow" (BorrowId.to_string a) (BorrowId.to_string b)) (BorrowId.InjSubst.to_map bids);
        BorrowId.InjSubst.Map.iter (fun a b -> row "loan" (BorrowId.to_string a) (BorrowId.to_string b)) (BorrowId.InjSubst.to_map lids);
        AbsId.InjSubst.Map.iter (fun a b -> row "abstraction" (AbsId.to_string a) (AbsId.to_string b)) (AbsId.InjSubst.to_map aids);
        SymbolicValueId.InjSubst.Map.iter (fun a b -> row "symbolic" (SymbolicValueId.to_string a) (SymbolicValueId.to_string b)) (SymbolicValueId.InjSubst.to_map sids);
        SymbolicValueId.Map.iter (fun id (value : tvalue) ->
          row "symbolic-to-value" (SymbolicValueId.to_string id) "typed-value";
          raw_type actual_context abs1.regions.owned abs1.regions.owned "mapped-value-type" value.ty) values
      with Limit -> incr omitted; emit "map-tail-omitted\n")
    in
    let render_failure label failure trace =
      emit (label ^ "\n");
      (match failure with
      | Distinct msg -> emit "exception=Distinct\n"; bounded "message" msg
      | Errors.RFailure -> emit "exception=Errors.RFailure\n"
      | ValueMatchFailure _ -> emit "exception=ValueMatchFailure\n"; incr omitted
      | _ -> emit "exception=other\n"; incr omitted);
      let count = Printexc.raw_backtrace_length trace in
      integer "guard-stack-slots" count;
      for index = 0 to Stdlib.min 15 (count - 1) do
        let slot = Printexc.convert_raw_backtrace_slot (Printexc.get_raw_backtrace_slot trace index) in
        match Printexc.Slot.location slot with
        | None -> emit "guard-location=unavailable\n"
        | Some location -> bounded "guard-file" location.filename; integer "guard-line" location.line_number
      done;
      if count > 16 then (incr omitted; integer "guard-stack-omitted" (count - 16))
    in
    (try
      emit "role=selected-LOCAL-abstraction-candidate-rejection\n";
      emit "candidate-count=1\n";
      emit ("source-owner=" ^ AbsId.to_string abs0.abs_id ^ "\ncurrent-owner=" ^ AbsId.to_string abs1.abs_id ^ "\n");
      render_failure "outer-candidate-exception" failure trace;
      let () = bounded "source-abstraction-kind" (show_abs_kind abs0.kind) in
      let () = bounded "current-abstraction-kind" (show_abs_kind abs1.kind) in
      let () = bounded "check-kind" (string_of_bool check_kind) in
      let () = bounded "check-equiv" (string_of_bool check_equiv) in
      let () = bounded "check-can-end" (string_of_bool check_can_end) in
      let () = bounded "source-span" (Errors.span_to_string span) in
      let maps_record actual_context label (maps_record : ids_maps) =
        maps actual_context label (maps_record.rid_map, maps_record.blid_map,
          maps_record.borrow_id_map, maps_record.loan_id_map, maps_record.aid_map,
          maps_record.sid_map, maps_record.sid_to_value_map, None)
      in
      let operand entry left label = function
        | LocalValue (actual_context, value) ->
            emit (label ^ ":actual-comparison-value\n");
            comparison_values left label actual_context
              (if left then abs0.regions.owned else abs1.regions.owned) [value]
        | LocalGroup (loan, sid, mask) ->
            emit (label ^ ":actual-comparison-group\n");
            emit ("loan=" ^ string_of_bool loan ^ "\n");
            emit ("symbolic-id=" ^ SymbolicValueId.to_string sid ^ "\n");
            raw_type (if left then entry.local_context0 else entry.local_context1)
              (if left then abs0.regions.owned else abs1.regions.owned)
              (if left then abs0.regions.owned else abs1.regions.owned)
              "actual-normalized-mask" mask
      in
      let remainder entry row =
        bounded "LOCAL-bag-exhaustion-stage" row.remainder_stage;
        (if row.remainder_stage = "positional-values" then
           emit "LOCAL-positional-index=unavailable\n"
         else integer "LOCAL-bag-exhaustion-step" row.remainder_step);
        bounded "LOCAL-bag-exhaustion-predicate" row.remainder_reason;
        integer "actual-left-remainder-count" row.left_count;
        integer "actual-right-remainder-count" row.right_count;
        integer "left-remainder-omitted" (Stdlib.max 0 (row.left_count - List.length row.left_prefix));
        integer "right-remainder-omitted" (Stdlib.max 0 (row.right_count - List.length row.right_prefix));
        List.iter (operand entry true "actual-left-remainder") row.left_prefix;
        List.iter (operand entry false "actual-right-remainder") row.right_prefix
      in
      (match inner with
      | None -> emit "direct-bag-evidence=unavailable\n"
      | Some entry ->
          emit "attribution=retained-rejected-trial-not-a-unique-terminal-cause\n";
          bounded "actual-comparison-stage" entry.local_stage;
          (if entry.local_stage = "positional-values" then (
             emit "actual-positional-index=unavailable\n";
             emit "guard-path=actual-comparison-stage-and-raw-guard-location\n")
           else (
             integer "actual-comparison-step" entry.local_step;
             integer "actual-local-candidate-index" entry.local_candidate;
             emit "guard-path=actual-comparison-stage/step/candidate-and-raw-guard-location\n"));
          render_failure "original-inner-exception-before-rollback"
            entry.local_exception entry.local_trace;
          (match entry.local_payload with
          | LocalPair (left, right) ->
              emit "direct-payload=actual-pair\n";
              operand entry true "actual-left-operand" left;
              operand entry false "actual-right-operand" right;
              (match left, right with
              | LocalGroup (loan0, sid0, mask0), LocalGroup (loan1, sid1, mask1) ->
                  bounded "group-direct-predicate"
                    (if loan0 <> loan1 || mask0 <> mask1 then
                       "loan0 = loan1 AND mask0 = mask1"
                     else "RecoverCEM.match_symbolic_value_ids sid0 sid1");
                  emit ("loan-flags-equal=" ^ string_of_bool (loan0 = loan1) ^ "\n");
                  emit ("normalized-masks-equal=" ^ string_of_bool (mask0 = mask1) ^ "\n");
                  emit ("source-group-symbol=" ^ SymbolicValueId.to_string sid0 ^ "\n");
                  emit ("current-group-symbol=" ^ SymbolicValueId.to_string sid1 ^ "\n")
              | _ -> emit "value-direct-predicate=original-inner-exception-and-raw-guard-location\n")
          | LocalRemainder row ->
              emit "direct-payload=actual-unmatched-remainder-no-pair\n";
              emit "child-rejection-evidence=unavailable\n";
              remainder entry row
          | LocalFinish ->
              emit "direct-payload=owned-set-finish-no-value-pair\n";
              set "actual-left-owned-set" abs0.regions.owned;
              set "actual-right-owned-set" abs1.regions.owned);
          (match entry.local_before with
          | None -> emit "maps-before-inner-trial=not-captured-for-unpaired-guard\n"
          | Some before -> maps_record entry.local_context1 "maps-before-inner-trial" before);
          maps_record entry.local_context1 "maps-at-inner-rejection-before-rollback" entry.local_at_rejection;
          integer "LOCAL-exhaustions-omitted" entry.local_exhaustions_omitted;
          List.iter (remainder entry) (List.rev entry.local_exhaustions));
      maps ctx1 "maps-before-outer-candidate" before;
      emit "outer-map-limit=inner-bag-rollback-may-precede-this-snapshot\n";
      maps ctx1 "maps-at-outer-candidate-catch" after;
      owner "source" ctx0 abs0;
      owner "current" ctx1 abs1
     with Limit -> incr omitted
        | _ -> incr omitted; (try emit "optional-analysis-unavailable\n" with _ -> ()));
    Buffer.add_string output ("omitted-sections=" ^ string_of_int !omitted ^ "\n");
    (try Printf.eprintf "Selected LOCAL abstraction-candidate rejection:\n%s%!" (Buffer.contents output) with _ -> ())
  with _ -> (try Printf.eprintf "Selected LOCAL abstraction-candidate diagnostic unavailable.\n%!" with _ -> ())


let match_ctxs (span : Meta.span) ~(check_equiv : bool)
    ?(check_kind : bool = true) ?(check_can_end : bool = true)
    ?selected_pair
    ~(recoverable : bool) (fixed_ids : ids_sets)
    (lookup_shared_value_in_ctx0 : BorrowId.id -> tvalue)
    (lookup_shared_value_in_ctx1 : BorrowId.id -> tvalue) (ctx0 : eval_ctx)
    (ctx1 : eval_ctx) : ids_maps =
  [%ltrace
    "\n- fixed_ids:\n" ^ show_ids_sets fixed_ids ^ "\n\n- ctx0:\n"
    ^ eval_ctx_to_string ~span:(Some span) ~filter:false ctx0
    ^ "\n\n- ctx1:\n"
    ^ eval_ctx_to_string ~span:(Some span) ~filter:false ctx1
    ^ "\n"];

  (* Initialize the maps and instantiate the matcher *)
  let module IdMap (Id : Identifiers.Id) = struct
    let mk_map_ref (ids : Id.Set.t) : Id.InjSubst.t ref =
      ref
        (Id.InjSubst.of_list (List.map (fun x -> (x, x)) (Id.Set.elements ids)))
  end in
  let rid_map =
    let module IdMap = IdMap (RegionId) in
    IdMap.mk_map_ref fixed_ids.rids
  in
  let blid_map =
    let module IdMap = IdMap (BorrowId) in
    IdMap.mk_map_ref fixed_ids.blids
  in
  let borrow_id_map =
    let module IdMap = IdMap (BorrowId) in
    IdMap.mk_map_ref fixed_ids.borrow_ids
  in
  let loan_id_map =
    let module IdMap = IdMap (BorrowId) in
    IdMap.mk_map_ref fixed_ids.loan_ids
  in
  let aid_map =
    let module IdMap = IdMap (AbsId) in
    IdMap.mk_map_ref fixed_ids.aids
  in
  let sid_map =
    let module IdMap = IdMap (SymbolicValueId) in
    IdMap.mk_map_ref fixed_ids.sids
  in
  (* In case we don't try to check equivalence but want to compute a mapping
     from a source context to a target context, we use a map from symbolic
     value ids to values (rather than to ids).
  *)
  let sid_to_value_map : tvalue SymbolicValueId.Map.t ref =
    ref SymbolicValueId.Map.empty
  in
  let region_diagnostic = make_region_match_diagnostic span fixed_ids ctx0 ctx1 in


  (*
```ocaml
*)
  let save_maps () =
    ( !rid_map,
      !blid_map,
      !borrow_id_map,
      !loan_id_map,
      !aid_map,
      !sid_map,
      !sid_to_value_map,
      (match region_diagnostic with
       | Some diagnostic when region_match_diagnostics_enabled () ->
           Some (!(diagnostic.origins), !(diagnostic.registrations))
       | _ -> None) )
  in
  let restore_maps
      ( rid_map0,
        blid_map0,
        borrow_id_map0,
        loan_id_map0,
        aid_map0,
        sid_map0,
        sid_to_value_map0,
        diagnostic0 ) =
    rid_map := rid_map0;
    blid_map := blid_map0;
    borrow_id_map := borrow_id_map0;
    loan_id_map := loan_id_map0;
    aid_map := aid_map0;
    sid_map := sid_map0;
    sid_to_value_map := sid_to_value_map0;
    (match region_diagnostic, diagnostic0 with
    | Some diagnostic, Some (origins, registrations)
      when region_match_diagnostics_enabled () ->
        diagnostic.origins := origins;
        diagnostic.registrations := registrations
    | _ -> ())
  in
  (*
```
*)

  let module S : MatchCheckEquivState = struct
    let span = span
    let recover = recoverable
    let check_equiv = check_equiv
    let rid_map = rid_map
    let region_diagnostic = region_diagnostic
    let blid_map = blid_map
    let borrow_id_map = borrow_id_map
    let loan_id_map = loan_id_map
    let sid_map = sid_map
    let sid_to_value_map = sid_to_value_map
    let aid_map = aid_map
    let lookup_shared_value_in_ctx0 = lookup_shared_value_in_ctx0
    let lookup_shared_value_in_ctx1 = lookup_shared_value_in_ctx1
  end in
  let module CEM = MakeCheckEquivMatcher (S) in
  let module M = MakeMatcher (CEM) in
  (* When matching abstractions we allow backtracking, so we need an alternative
     version of the matchers where [recover] is true *)
  let module RecoverS : MatchCheckEquivState = struct
    let span = span
    let recover = true
    let check_equiv = check_equiv
    let rid_map = rid_map
    let region_diagnostic = region_diagnostic
    let blid_map = blid_map
    let borrow_id_map = borrow_id_map
    let loan_id_map = loan_id_map
    let sid_map = sid_map
    let sid_to_value_map = sid_to_value_map
    let aid_map = aid_map
    let lookup_shared_value_in_ctx0 = lookup_shared_value_in_ctx0
    let lookup_shared_value_in_ctx1 = lookup_shared_value_in_ctx1
  end in
  let module RecoverCEM = MakeCheckEquivMatcher (RecoverS) in
  let module RecoverM = MakeMatcher (RecoverCEM) in
  (* Match the environments - we assume that they have the same structure
     (and fail if they don't) *)

  (* Small utility: check that ids are fixed/mapped to themselves *)
  let ids_are_fixed (ids : ids_sets) : bool =
    let {
      aids;
      blids;
      borrow_ids;
      loan_ids;
      shared_loans_to_values = _;
      unique_borrow_ids;
      shared_borrow_ids = _;
      non_unique_shared_borrow_ids = _;
      dids;
      rids;
      sids;
    } =
      ids
    in
    AbsId.Set.subset aids fixed_ids.aids
    && BorrowId.Set.subset blids fixed_ids.blids
    && BorrowId.Set.subset borrow_ids fixed_ids.borrow_ids
    && UniqueBorrowIdSet.subset unique_borrow_ids fixed_ids.unique_borrow_ids
    && BorrowId.Set.subset loan_ids fixed_ids.loan_ids
    && DummyVarId.Set.subset dids fixed_ids.dids
    && RegionId.Set.subset rids fixed_ids.rids
    && SymbolicValueId.Set.subset sids fixed_ids.sids
  in

  (* Rem.: this function raises exceptions of type [Distinct] or [RFailure]
     (in the latter case: if [recover] is true) *)
  let match_abstractions ~(recover : bool)
      ~(diagnostic : local_bag_failure option ref option)
      (abs0 : abs) (abs1 : abs) : unit =
    let {
      abs_id = abs_id0;
      kind = kind0;
      can_end = can_end0;
      parents = parents0;
      regions = { owned = regions0 };
      ended_subabs = ended_subabs0;
      avalues = avalues0;
      (* We ignore the continuations *)
      cont = _;
    } =
      abs0
    in

    let {
      abs_id = abs_id1;
      kind = kind1;
      can_end = can_end1;
      parents = parents1;
      regions = { owned = regions1 };
      ended_subabs = ended_subabs1;
      avalues = avalues1;
      (* We ignore the continuations *)
      cont = _;
    } =
      abs1
    in

    let match_aid = if recover then RecoverCEM.match_aid else CEM.match_aid in
    let match_aids =
      if recover then RecoverCEM.match_aids else CEM.match_aids
    in
    let match_rids =
      if recover then RecoverCEM.match_rids else CEM.match_rids
    in
    let shared_shell_owners = Some (regions0, regions1) in
    let match_tavalues =
      if recover then RecoverM.match_tavalues else M.match_tavalues
    in

    let raise_distinct msg =
      (* ```ocaml *)
      [%ltrace "Abstraction guard failure: " ^ msg];
      (* ``` *)
      if recover then raise Errors.RFailure else raise (Distinct msg)
    in

    let _ = match_aid abs_id0 abs_id1 in
    if check_kind && kind0 <> kind1 then
      raise_distinct "match_abstractions: kind";
    if check_can_end && can_end0 <> can_end1 then
      raise_distinct "match_abstractions: can_end";
    (* When checking equivalence, the parents must be the same. When matching a
       source (fixed-point) context with a target context, the parents are
       checked once all the abstractions have been matched (see below). *)
    if check_equiv then ignore (match_aids parents0 parents1);
    (* 
```ocaml
*)
    let match_owned_regions () =
      match region_diagnostic with
      | None -> match_rids regions0 regions1
      | Some _ when not (region_match_diagnostics_enabled ()) ->
          match_rids regions0 regions1
      | Some diagnostic ->
          let previous = !(diagnostic.registration_location) in
          let mask ids =
            if RegionId.Set.cardinal ids <= 128 then RegionId.Set.to_string None ids
            else "analysis unavailable: ownership mask limit"
          in
          diagnostic.registration_location := Some
            ("left abstraction=" ^ AbsId.to_string abs_id0 ^ ", owned=" ^ mask regions0
             ^ "\nright abstraction=" ^ AbsId.to_string abs_id1 ^ ", owned=" ^ mask regions1);
          Fun.protect
            ~finally:(fun () -> diagnostic.registration_location := previous)
            (fun () -> match_rids regions0 regions1)
    in
    (* 
```
*)

    if not (AbsLevelSet.equal ended_subabs0 ended_subabs1) then
      raise_distinct
        "Region abstractions with distinct sets of ended sub-abstractions";

    [%ldebug "match_abstractions: matching values"];
    (*
```ocaml
    *)
    let parent_key regions (av : tavalue) =
      let identity =
        match av.value with
        | ASymbolic (_, APendingLoans parent) -> Some (false, parent)
        | ALoan (AIgnoredMutLoan (_, Some parent, _)) -> Some (true, parent)
        | _ -> None
      in
      Option.map
        (fun (loan, parent) ->
          (loan, parent, normalize_proj_ty ctx0.type_ctx.type_infos regions av.ty))
        identity
    in
    let avalues1 =
      let expected =
        List.filter_map (parent_key regions0) avalues0
        |> List.map (fun (loan, parent, mask) ->
             let known =
               BorrowId.InjSubst.find_opt parent
                 (if check_equiv then !blid_map else !borrow_id_map)
             in
             Option.map (fun parent -> (loan, parent, mask)) known)
      in
      if List.exists Option.is_none expected then avalues1
      else
        let expected = List.map Option.get expected in
        let available =
          List.filter_map
            (fun value ->
              Option.map (fun key -> (key, value)) (parent_key regions1 value))
            avalues1
        in
        let rec align available = function
          | [] -> if available = [] then Some [] else None
          | key :: rest ->
              let selected, remaining = List.partition (fun (k, _) -> k = key) available in
              match selected with
              | [ (_, value) ] ->
                  Option.map (fun rest -> value :: rest) (align remaining rest)
              | _ -> None
        in
        match align available expected with
        | None -> avalues1
        | Some ordered ->
            let ordered = ref ordered in
            List.map
              (fun value ->
                match parent_key regions1 value with
                | None -> value
                | Some _ ->
                    let selected = List.hd !ordered in
                    ordered := List.tl !ordered;
                    selected)
              avalues1
    in
    (*
```
    *)
    let match_positional () =
      if List.length avalues0 <> List.length avalues1 then
        raise_distinct "Region abstractions with not the same number of values";
      List.iter2
        (fun v0 v1 ->
          ignore (match_tavalues ~shared_shell_owners ctx0 ctx1 v0 v1))
        (* ```ocaml *)
        avalues0 avalues1;
      ignore (match_owned_regions ())
        (* ``` *)
    in
    (* Ownership bags have neither positional ADT wrappers nor observable
       partitions of childless shared projections. Compare their disjoint
       masks as a whole, while keeping mutable state, operational histories
       and concrete referents in the ordinary positional matcher. *)
    let collect_ownership ctx regions values =
      let borrows = ref SymbolicValueId.Map.empty in
      let loans = ref SymbolicValueId.Map.empty in
      let shared = ref [] in
      let metadata_ctx = ref ctx in
      let add groups (proj : symbolic_proj) =
        let mask = normalize_proj_ty ctx.type_ctx.type_infos regions proj.proj_ty in
        groups :=
          SymbolicValueId.Map.update proj.sv_id
            (function
              | None -> Some mask
              | Some previous ->
                  Some (norm_proj_tys_union span ctx previous mask))
            !groups
      in
      let rec collect (av : tavalue) tail =
        match av.value with
        | AAdt adt -> List.fold_right collect adt.fields tail
        | value when is_aignored value -> tail
        | ABorrow (ASharedBorrow _ | AProjSharedBorrow _) ->
            shared := av :: !shared;
            tail
        | ALoan (ASharedLoan (_, _, sv, child))
          when is_aignored child.value
               && (not
                     (InterpUtils.value_has_mut_borrows (Some span) ctx
                        sv.value))
               && not (tvalue_has_mutable_loans sv) ->
            let values, ctx = flatten_shared_loan_view span !metadata_ctx av in
            let () = metadata_ctx := ctx in
            let () = shared := List.rev_append values !shared in
            tail
        | ASymbolic (PNone, proj)
          when not (InterpBorrows.proj_has_ownership proj) ->
            (* Fully ended histories add no ownership to the bag. This is
               only a comparison view: keep the actual history and its
               continuation in the target abstraction. *)
            tail
        | ASymbolic (PNone, AProjBorrows { proj; loans = [] })
          when not (ty_has_mut_borrows ctx.type_ctx.type_infos proj.proj_ty)
          ->
            add borrows proj;
            tail
        | ASymbolic (PNone, AProjLoans { proj; consumed = []; borrows = [] })
          when not (ty_has_mut_borrows ctx.type_ctx.type_infos proj.proj_ty)
          ->
            add loans proj;
            tail
        | _ -> av :: tail
      in
      let values = List.fold_right collect values [] in
      let groups =
        SymbolicValueId.Map.fold
          (fun sid mask groups -> (false, sid, mask) :: groups)
          !borrows []
      in
      let groups =
        SymbolicValueId.Map.fold
          (fun sid mask groups -> (true, sid, mask) :: groups)
          !loans groups
      in
      (values, !shared, groups, !metadata_ctx)
    in
    let match_ownership_bags () =
      let values0, shared0, groups0, ctx0 =
        collect_ownership ctx0 regions0 avalues0
      in
      let values1, shared1, groups1, ctx1 =
        collect_ownership ctx1 regions1 avalues1
      in
      let value_operand left value = LocalValue ((if left then ctx0 else ctx1), value) in
      let group_operand _ (loan, sid, mask) = LocalGroup (loan, sid, mask) in
      let capture stage step candidate before payload failure trace =
        match diagnostic with
        | None -> ()
        | Some _ ->
            (try
               let entry = {
                 local_stage = stage; local_step = step; local_candidate = candidate;
                 local_context0 = ctx0; local_context1 = ctx1;
                 local_payload = payload (); local_exception = failure; local_trace = trace;
                 local_before = Option.map local_correspondence_maps before;
                 local_at_rejection = local_correspondence_maps (save_maps ());
                 local_exhaustions = []; local_exhaustions_omitted = 0 }
               in
               local_failure_keep diagnostic (Some entry)
             with _ -> ())
      in
      let raise_local_exhaustion stage step operand left right reason =
        match diagnostic with
        | None -> raise_distinct reason
        | Some cell ->
            try raise_distinct reason
            with (Distinct _ | Errors.RFailure | ValueMatchFailure _) as failure ->
              let trace = try Some (Printexc.get_raw_backtrace ()) with _ -> None in
              (try
                 let remainder = {
                   remainder_stage = stage; remainder_step = step; remainder_reason = reason;
                   left_count = List.length left; right_count = List.length right;
                   left_prefix = local_operand_prefix operand true left;
                   right_prefix = local_operand_prefix operand false right }
                 in
                 (match !cell, trace with
                 | None, Some trace ->
                     capture stage step (-1) None (fun () -> LocalRemainder remainder) failure trace
                 | Some entry, _ ->
                     if List.length entry.local_exhaustions < 4 then
                       cell := Some { entry with local_exhaustions = remainder :: entry.local_exhaustions }
                     else cell := Some { entry with
                       local_exhaustions_omitted = entry.local_exhaustions_omitted + 1 }
                 | None, None -> ())
               with _ -> ());
              (match trace with Some trace -> Printexc.raise_with_backtrace failure trace
               | None -> raise_notrace failure)
      in
      let rec match_bag stage step match_one operand left right finish =
        let entry = local_failure_read diagnostic in
        match left with
        | [] ->
            if right <> [] then
              (match diagnostic with
              | None -> raise_distinct "Unmatched abstraction ownership"
              | Some _ -> raise_local_exhaustion stage step operand [] right
                  "Unmatched abstraction ownership")
            else finish ()
        | value0 :: left ->
            let best =
              try match diagnostic with None -> None | Some _ -> Some (ref None)
              with _ -> None
            in
            let rec choose candidate prefix = function
              | [] ->
                  (match diagnostic with
                  | None -> raise_distinct "No matching abstraction ownership"
                  | Some _ ->
                      local_failure_write diagnostic entry;
                      local_failure_keep diagnostic (local_failure_read best);
                      raise_local_exhaustion stage step operand (value0 :: left) right
                        "No matching abstraction ownership")
              | value1 :: rest -> (
                  let maps = save_maps () in
                  local_failure_write diagnostic entry;
                  try
                    (try match_one value0 value1
                     with (Distinct _ | Errors.RFailure | ValueMatchFailure _) as failure
                       when Option.is_some diagnostic ->
                       let trace = try Some (Printexc.get_raw_backtrace ()) with _ -> None in
                       (try match trace with
                        | Some trace ->
                            capture stage step candidate (Some maps)
                              (fun () -> LocalPair (operand true value0, operand false value1))
                              failure trace
                        | None -> () with _ -> ());
                       (match trace with Some trace -> Printexc.raise_with_backtrace failure trace
                        | None -> raise_notrace failure));
                    match_bag stage (step + 1) match_one operand left
                      (List.rev_append prefix rest) finish;
                    local_failure_write diagnostic entry
                  with Distinct _ | Errors.RFailure | ValueMatchFailure _ ->
                    (try local_failure_keep best (local_failure_read diagnostic) with _ -> ());
                    local_failure_write diagnostic entry;
                    restore_maps maps;
                    choose (candidate + 1) (value1 :: prefix) rest)
            in
            choose 0 [] right
      in
      let match_value v0 v1 =
        ignore (RecoverM.match_tavalues ~shared_shell_owners ctx0 ctx1 v0 v1)
      in
      let match_group (loan0, sid0, mask0) (loan1, sid1, mask1) =
        if loan0 <> loan1 || mask0 <> mask1 then
          raise_distinct "Different shared projection coverage";
        ignore (RecoverCEM.match_symbolic_value_ids sid0 sid1)
      in
      (* Remaining values can carry mutable continuation arguments/results.
         Their order is part of the ABI, unlike shared-only coverage groups. *)
      if List.length values0 <> List.length values1 then
        (match diagnostic with
        | None -> raise_distinct "Different continuation ownership arities"
        | Some _ -> raise_local_exhaustion "positional-values" (-1) value_operand values0 values1
            "Different continuation ownership arities");
      List.iter2
        (fun v0 v1 ->
          try match_value v0 v1
          with (Distinct _ | Errors.RFailure | ValueMatchFailure _) as failure
            when Option.is_some diagnostic ->
            let trace = try Some (Printexc.get_raw_backtrace ()) with _ -> None in
            (try match trace with
             | Some trace -> capture "positional-values" (-1) (-1) None
                 (fun () -> LocalPair (value_operand true v0, value_operand false v1)) failure trace
             | None -> () with _ -> ());
            (match trace with Some trace -> Printexc.raise_with_backtrace failure trace
             | None -> raise_notrace failure))
        values0 values1;
      match_bag "shared-values" 0 match_value value_operand shared0 shared1 (fun () ->
          match_bag "groups" 0 match_group group_operand groups0 groups1
            (fun () ->
              try ignore (match_owned_regions ())
              with (Distinct _ | Errors.RFailure | ValueMatchFailure _) as failure
                when Option.is_some diagnostic ->
                let trace = try Some (Printexc.get_raw_backtrace ()) with _ -> None in
                (try match trace with
                 | Some trace -> capture "owned-set-finish" 0 (-1) None
                     (fun () -> LocalFinish) failure trace
                 | None -> () with _ -> ());
                (match trace with Some trace -> Printexc.raise_with_backtrace failure trace
                 | None -> raise_notrace failure)))
    in
    (* The positions of the values which [collect_ownership] keeps positional
       (the values which carry continuation inputs or outputs) *)
    let positional_indices ctx regions (avalues : tavalue list) : int list =
      List.filter_map
        (fun (i, av) ->
          let values, _, _, _ = collect_ownership ctx regions [ av ] in
          if values = [] then None else Some i)
        (List.mapi (fun i av -> (i, av)) avalues)
    in
    (if abs_has_fixed_avalue_layout abs0 && abs_has_fixed_avalue_layout abs1
     then (
       (* The top-level shared-only values of an abstraction with pending loans
          or ignored loans (e.g., the shared borrows and loans of the
          abstractions a loop abstraction absorbed) carry no continuation
          input or output: their order is the order in which the abstractions
          were merged, which may differ between the fixed point and the
          context entering the loop. If the positional match fails, match
          them as a bag, provided that the other values have the same
          positions in both abstractions (the positions of the pending loans
          and projectors of a staged continuation are indices in the list of
          values) and that no value is an ADT (whose fields are positional). *)
       let maps = save_maps () in
       try match_positional ()
       with (Distinct _ | Errors.RFailure | ValueMatchFailure _) as e ->
         let flat (avalues : tavalue list) =
           List.for_all
             (fun (av : tavalue) ->
               match av.value with
               | AAdt _ -> false
               | _ -> true)
             avalues
         in
         if
           flat avalues0 && flat avalues1
           && positional_indices ctx0 regions0 avalues0
              = positional_indices ctx1 regions1 avalues1
         then (
           restore_maps maps;
           match_ownership_bags ())
         else raise e)
     else match_ownership_bags ());
(*
```ocaml
*)
    let physical_count scopes =
      List.fold_left
        (fun count -> function PhysicalInputScope _ -> count + 1 | PendingParameterScope _ -> count)
        0 scopes in
    if physical_count abs0.call_scopes <> physical_count abs1.call_scopes then
      raise_distinct "Physical input interfaces have different cardinalities";
    let match_symbolic =
      if recover then RecoverCEM.match_symbolic_values else CEM.match_symbolic_values in
    let match_values =
      if recover then RecoverM.match_tvalues else M.match_tvalues in
    List.iter
      (function
      | PendingParameterScope _ -> ()
      | PhysicalInputScope scope0 ->
        let slot0 = scope0.physical_slot in
        let origin0 = slot0.origin in
        let same_path = function
          | PendingParameterScope _ -> false
          | PhysicalInputScope scope1 ->
            let slot1 = scope1.physical_slot in
            let origin1 = slot1.origin in
            slot0.value_path = slot1.value_path
            && origin0.source_owner = origin1.source_owner
            && origin0.region_group = origin1.region_group
            && origin0.source_role = origin1.source_role
            && origin0.original_root = origin1.original_root
            && RegionId.Set.equal origin0.original_mask origin1.original_mask in
        let rec find = function
          | [] -> raise_distinct "A physical input interface lacks its canonical path"
          | (PhysicalInputScope scope1 as scope) :: rest when same_path scope ->
              if List.exists same_path rest then
                raise_distinct "A physical input interface has duplicate canonical paths";
              scope1
          | _ :: rest -> find rest in
        let scope1 = find abs1.call_scopes in
        if not (same_physical_input_ancestry_topology scope0.ancestry scope1.ancestry) then
          raise_distinct "Physical input interfaces have incompatible declaration ancestry";
        let slot1 = scope1.physical_slot in
        ignore (match_rids slot0.proj_regions slot1.proj_regions);
        ignore (match_symbolic (match_values ctx0 ctx1) ctx0 ctx1
          origin0.transport_root slot1.origin.transport_root))
      abs0.call_scopes;
(*
```
*)
    [%ldebug "match_abstractions: values matched OK"];
    ()
  in

  let pop_var var =
    env_pop_var
      (fun _ ->
        raise
          (Distinct
             ("Missing var in right environment: "
             ^ real_var_binder_to_string ctx1 var)))
      var
  in
  let pop_dummy id =
    env_pop_dummy
      (fun _ ->
        raise
          (Distinct
             ("Missing dummy var in right environment: "
            ^ DummyVarId.to_string id)))
      id
  in
  let pop_first_dummy =
    env_pop_first_dummy (fun _ ->
        raise (Distinct "Missing dummy var in right environment"))
  in
  let pop_abs id =
    env_pop_abs
      (fun _ ->
        raise
          (Distinct ("Missing abs in right environment: " ^ AbsId.to_string id)))
      id
  in

  (* Pop the first abs matching [abs0].
     We repeatedly attempt to match, saving the state before matching and
     restoring it if it failed. *)
  let pop_first_matching_abs abs0 env =
    [%ltrace
      "Trying to match abs:\n"
      ^ abs_to_string span ctx0 abs0
      ^ "\n\nIn environment:\n"
      ^ eval_ctx_to_string { ctx1 with env = List.rev env }];
    env_pop_binding
      (fun _ ->
        (try Printf.eprintf "LOCAL abstraction-search exhaustion: source-owner=%s\n%!"
           (AbsId.to_string abs0.abs_id) with _ -> ());
        (* ```ocaml *)
        try raise (Distinct "Could not find a matching abs in right environment")
        with failure ->
          let trace = Printexc.get_raw_backtrace () in
          (try
             if check_equiv && not recoverable
                && (!Config.print_error_diagnostics || !Config.print_error_emitters)
             then begin
               let exception Limit in
               let output = Buffer.create 4096 in
               let omitted = ref 0 in
               let inventory_complete = ref false in
               let operands_complete = ref false in
               let continuations_complete = ref false in
               let emit text =
                 if String.length text > 261632 - Buffer.length output then raise Limit;
                 Buffer.add_string output text
               in
               let formatted label printer value =
                 emit (label ^ ":\n");
                 let write text start count =
                   if count > 261632 - Buffer.length output then raise Limit;
                   Buffer.add_substring output text start count
                 in
                 let formatter = Format.make_formatter write (fun () -> ()) in
                 printer formatter value;
                 Format.pp_print_flush formatter ();
                 emit "\n"
               in
               let section label action =
                 try action () with
                 | Limit -> incr omitted
                 | _ ->
                     incr omitted;
                     (try emit (label ^ "-unavailable\n") with _ -> ())
               in
               section "inventory" (fun () ->
                   emit "role=fatal-equivalence-abstraction-exhaustion\n";
                   formatted "source-span" Format.pp_print_string (Errors.span_to_string span);
                   emit ("check-equiv=" ^ string_of_bool check_equiv
                         ^ "\ncheck-kind=" ^ string_of_bool check_kind
                         ^ "\ncheck-can-end=" ^ string_of_bool check_can_end ^ "\n");
                   emit ("source-owner=" ^ AbsId.to_string abs0.abs_id ^ "\n");
                   let candidates = List.fold_left
                     (fun count -> function EAbs _ -> count + 1 | _ -> count) 0 env in
                   emit ("remaining-binding-count=" ^ string_of_int (List.length env)
                         ^ "\nremaining-candidate-count=" ^ string_of_int candidates ^ "\n");
                   List.iteri (fun index entry ->
                       emit ("binding-index=" ^ string_of_int index ^ "\n");
                       match entry with
                       | EAbs owner ->
                           emit ("binding-kind=abstraction\ncandidate-owner="
                                 ^ AbsId.to_string owner.abs_id ^ "\n")
                       | EBinding (BVar _, _) -> emit "binding-kind=variable\n"
                       | EBinding (BDummy _, _) -> emit "binding-kind=dummy\n"
                       | EFrame -> emit "binding-kind=frame\n") env;
                   inventory_complete := true);
               section "source" (fun () -> formatted "raw-source-owner" Values.pp_abs abs0);
               section "maps" (fun () ->
                   emit "current-correspondence-maps:\n";
                   let pair label left right =
                     emit (label ^ "=" ^ left ^ "->" ^ right ^ "\n")
                   in
                   AbsId.InjSubst.iter (fun a b -> pair "abstraction" (AbsId.to_string a) (AbsId.to_string b)) !aid_map;
                   BorrowId.InjSubst.iter (fun a b -> pair "borrow-loan" (BorrowId.to_string a) (BorrowId.to_string b)) !blid_map;
                   BorrowId.InjSubst.iter (fun a b -> pair "borrow" (BorrowId.to_string a) (BorrowId.to_string b)) !borrow_id_map;
                   BorrowId.InjSubst.iter (fun a b -> pair "loan" (BorrowId.to_string a) (BorrowId.to_string b)) !loan_id_map;
                   RegionId.InjSubst.iter (fun a b -> pair "region" (RegionId.to_string a) (RegionId.to_string b)) !rid_map;
                   SymbolicValueId.InjSubst.iter (fun a b -> pair "symbol" (SymbolicValueId.to_string a) (SymbolicValueId.to_string b)) !sid_map;
                   SymbolicValueId.Map.iter (fun id value ->
                       emit ("symbol-value=" ^ SymbolicValueId.to_string id ^ "\n");
                       formatted "mapped-value" Values.pp_tvalue value) !sid_to_value_map);
               section "operands" (fun () ->
                   List.iter (function
                     | EAbs owner -> formatted "raw-right-owner" Values.pp_abs owner
                     | _ -> ()) env;
                   formatted "source-metadata" Types.pp_region_metadata_bindings ctx0.metadata_bindings;
                   formatted "right-metadata" Types.pp_region_metadata_bindings ctx1.metadata_bindings;
                   formatted "raw-source-environment" Values.pp_env ctx0.env;
                   formatted "raw-right-environment" Values.pp_env ctx1.env;
                   emit "raw-environment-opaque-fields=unavailable\n";
                   incr omitted);
               section "continuations" (fun () ->
                   let complete = ref true in
                   let regions label ids =
                     emit (label ^ "={");
                     RegionId.Set.iter (fun id -> emit (RegionId.to_string id ^ ",")) ids;
                     emit "}\n"
                   in
                   let witness_fields (witnesses : call_endpoint_witnesses) =
                     List.iter (fun (from_input, original, actual) ->
                         emit ("endpoint-root-input=" ^ string_of_bool from_input ^ "\n");
                         formatted "endpoint-original-root" Values.pp_tavalue original;
                         formatted "endpoint-actual-root" Values.pp_tavalue actual) witnesses.roots;
                     List.iter (fun (symbol, expansion) ->
                         formatted "endpoint-expansion-symbol" Values.pp_symbolic_value symbol;
                         formatted "endpoint-expansion" Values.pp_symbolic_expansion expansion) witnesses.expansions;
                     List.iter (fun (projector, mask, actual) ->
                         formatted "endpoint-projector" Values.pp_symbolic_proj projector;
                         regions "endpoint-mask" mask;
                         formatted "endpoint-actual" Values.pp_tavalue actual) witnesses.projections;
                     List.iter (formatted "endpoint-origin" Values.pp_carrier_origin) witnesses.carrier_origins;
                     List.iter (fun correspondence ->
                         formatted "endpoint-correspondence" Values.pp_call_input_correspondence correspondence;
                         List.iter (formatted "endpoint-source-path" Values.pp_value_path_step) correspondence.input_source_path;
                         List.iter (formatted "endpoint-input-path" Values.pp_value_path_step) correspondence.input_path) witnesses.input_correspondences;
                     List.iter (formatted "endpoint-conversion" Values.pp_input_carrier_conversion) witnesses.carrier_conversions;
                     List.iter (formatted "endpoint-physical-return" Values.pp_input_physical_return) witnesses.physical_returns;
                     List.iter (formatted "endpoint-return-route" Values.pp_input_return_route) witnesses.return_routes;
                     List.iter (fun (marker, borrow, ty, mask, expression) ->
                         formatted "endpoint-parent-marker" Values.pp_proj_marker marker;
                         emit ("endpoint-parent-borrow=" ^ BorrowId.to_string borrow ^ "\n");
                         formatted "endpoint-parent-type" Types.pp_ty ty;
                         regions "endpoint-parent-mask" mask;
                         formatted "endpoint-parent-expression" Values.pp_tevalue expression) witnesses.parent_carriers;
                     complete := false;
                     incr omitted;
                     emit "endpoint-nested-opaque-payloads=unavailable\n"
                   in
                   let visitor = object
                     inherit [_] iter_tavalue
                     method! visit_ty _ _ = ()
                     method! visit_call_endpoint_witnesses _ witnesses = witness_fields witnesses
                     method! visit_EValue _ _ _ =
                       complete := false;
                       incr omitted;
                       emit "captured-environment=unavailable\n"
                   end in
                   let owner (owner : abs) =
                     emit ("continuation-owner=" ^ AbsId.to_string owner.abs_id ^ "\n");
(*
```ocaml
*)
                     List.iter (fun scope ->
                       (match scope with
                       | PendingParameterScope scope ->
                           formatted "pending-slot" Values.pp_symbolic_pending_slot scope.slot;
                           List.iter (fun (from_input, path) ->
                             emit ("pending-position-input=" ^ string_of_bool from_input ^ "\n");
                             List.iter (fun position ->
                               emit ("pending-position=" ^ string_of_bool position ^ "\n")) path)
                             scope.positions
                       | PhysicalInputScope scope ->
                           formatted "physical-input-slot" Values.pp_physical_input_slot scope.physical_slot);
                       witness_fields (ValuesUtils.call_scope_witnesses scope)) owner.call_scopes;
(*
```
*)
                     List.iter (visitor#visit_tavalue ()) owner.avalues;
                     match owner.cont with
                     | None -> emit "continuation=absent\n"
                     | Some cont ->
                         formatted "raw-continuation" Values.pp_abs_cont cont;
                         visitor#visit_abs_cont () cont
                   in
                   owner abs0;
                   List.iter (function EAbs abs -> owner abs | _ -> ()) env;
                   continuations_complete := !complete);
               Buffer.add_string output
                 ("\ninventory-complete=" ^ string_of_bool !inventory_complete
                  ^ "\noperands-complete=" ^ string_of_bool !operands_complete
                  ^ "\ncontinuations-complete=" ^ string_of_bool !continuations_complete
                  ^ "\nomitted-sections=" ^ string_of_int !omitted ^ "\n");
               Printf.eprintf "Fatal equivalence exhaustion:\n%s%!" (Buffer.contents output)
             end
           with _ -> ());
          Printexc.raise_with_backtrace failure trace)
        (* ``` *)
      (fun e ->
        match e with
        | EAbs abs1 ->
            (* Save the maps to make sure we can backtrack *)
            let maps = save_maps () in
            (* ```ocaml *)
            [%ltrace
              "Candidate abstraction pair:\n- abs0:\n"
              ^ abs_to_string span ctx0 abs0
              ^ "\n- abs1:\n" ^ abs_to_string span ctx1 abs1
              ^ "\n- saved maps:\n"
              ^ ids_maps_to_string ctx1
                  { aid_map = !aid_map; blid_map = !blid_map;
                    borrow_id_map = !borrow_id_map; loan_id_map = !loan_id_map;
                    rid_map = !rid_map; sid_map = !sid_map;
                    sid_to_value_map = !sid_to_value_map }];
            (* ``` *)
            (* Attempt matching *)
            let diagnostic =
              try if sole_abs_candidate abs1 env then Some (ref None) else None
              with _ -> None
            in
            begin
              try
                match_abstractions ~recover:true ~diagnostic abs0 abs1;
                local_failure_write diagnostic None;
                [%ltrace "Found matching abs:\n" ^ abs_to_string span ctx1 abs1];
                Some abs1
              (* ```ocaml *)
              with (Distinct _ | Errors.RFailure) as failure ->
                (match diagnostic with
                | None -> ()
                | Some cell ->
                    (try
                       let rejection_trace = Printexc.get_raw_backtrace () in
                       (match selected_pair with None -> ()
                        | Some pair -> pair := Some (abs0, abs1));
                       report_local_rejection ~span ~check_kind ~check_equiv ~check_can_end ctx0 ctx1 abs0 abs1 maps (save_maps ()) failure rejection_trace !cell
                     with _ -> ()));
                [%ltrace
                  "Rejected abstraction pair: "
                  ^ AbsId.to_string abs0.abs_id ^ " -> "
                  ^ AbsId.to_string abs1.abs_id
                  ^ "\n- failure: " ^ Printexc.to_string failure
                  ^ "\n- first guard stack:\n" ^ Printexc.get_backtrace ()];
                let () =
                  let log = Logging.carrier_events_log in
                  if Logging.L.Debug >= log#effective_level then
                    try
                      [%ldebug
                        "Carrier rejected abstraction candidate event:"
                        ^ "\nsource span: " ^ Errors.span_to_string span
                        ^ "\noriginal exception: " ^ Printexc.to_string failure
                        ^ "\nowned cardinality rejection: "
                        ^ string_of_bool
                            (match failure with
                            | Distinct "Not the same number of elements" ->
                                RegionId.Set.cardinal abs0.regions.owned
                                <> RegionId.Set.cardinal abs1.regions.owned
                            | _ -> false)
                        ^ "\nsource raw owner: " ^ Values.show_abs abs0
                        ^ "\nsource pending scopes: "
                        ^ String.concat "\n"
                            (List.map Values.show_call_scope abs0.call_scopes)
                        ^ "\ncurrent raw owner: " ^ Values.show_abs abs1
                        ^ "\ncurrent pending scopes: "
                        ^ String.concat "\n"
                            (List.map Values.show_call_scope abs1.call_scopes)]
                    with _ -> ()
                in
              (* ``` *)
                (* Restore the state and continue exploring *)
                restore_maps maps;
                None
              | ValueMatchFailure _ as failure when Option.is_some diagnostic ->
                let rejection_trace = try Some (Printexc.get_raw_backtrace ()) with _ -> None in
                (try match diagnostic, rejection_trace with
                 | Some cell, Some trace ->
                     (match selected_pair with None -> ()
                      | Some pair -> pair := Some (abs0, abs1));
                     report_local_rejection ~span ~check_kind ~check_equiv ~check_can_end ctx0 ctx1 abs0 abs1 maps (save_maps ()) failure trace !cell
                 | _ -> () with _ -> ());
                (match rejection_trace with
                 | Some trace -> Printexc.raise_with_backtrace failure trace
                 | None -> raise_notrace failure)
            end
        | _ -> None)
      env
  in

  (* We reorder [env0] to have the variables, fixed abstractions and fixed
     dummy variables, then:
     - the dummy variables
     - the non-fixed abstractions

     We then repeatedly pop the first element from the environment and match it
     with an element from [env1]. For the fixed elements and the variabels it is
     easy: we simply lookup the corresponding element in [env1]:
     - for the fixed abstractions and variables the values should be the same
     - for the variables, the values should be equivalent

     Then, we attempt to match the abstractions. We attempt to allow the abstractions
     to be in an arbitrary order, so match every abstraction [abs0] from the left
     environment with every abstraction from the right environment, stopping when
     a match is successful (and saving the state before any match, while restoring
     it if a match failed). Note that in full generality we may need to backtrack:
     for now we don't.
  *)
  let ctx0 =
    let fixed, non_fixed =
      List.partition
        (fun (e : env_elem) ->
          match e with
          | EBinding (BVar _, _) -> true
          | EBinding (BDummy id, _) -> DummyVarId.Set.mem id fixed_ids.dids
          | EAbs abs -> AbsId.Set.mem abs.abs_id fixed_ids.aids
          | EFrame -> true)
        ctx0.env
    in
    let abs, dummys =
      List.partition
        (fun (e : env_elem) ->
          match e with
          | EAbs _ -> true
          | _ -> false)
        non_fixed
    in
    (* When checking equivalence, the parents of an abstraction are matched
       with the abstraction ([match_aids]), which can only use the ids already
       mapped: otherwise it maps them by order, which can contradict the mapping
       found for their own abstractions (a join can introduce an abstraction
       before its parents). Match the parents first: the environment lists the
       latest element first, so a parent comes after its children. *)
    let abs =
      if not check_equiv then abs
      else
        let by_id =
          List.fold_left
            (fun m (e : env_elem) ->
              match e with
              | EAbs a -> AbsId.Map.add a.abs_id e m
              | _ -> m)
            AbsId.Map.empty abs
        in
        let visited = ref AbsId.Set.empty in
        let sorted = ref [] in
        let rec visit (e : env_elem) =
          match e with
          | EAbs a when not (AbsId.Set.mem a.abs_id !visited) ->
              visited := AbsId.Set.add a.abs_id !visited;
              AbsId.Set.iter
                (fun p -> Option.iter visit (AbsId.Map.find_opt p by_id))
                a.parents;
              sorted := e :: !sorted
          | _ -> ()
        in
        List.iter visit (List.rev abs);
        !sorted
    in
    { ctx0 with env = abs @ dummys @ fixed }
  in
  [%ltrace
    "\n- fixed_ids:\n" ^ show_ids_sets fixed_ids
    ^ "\n\n- ctx0 after reordering the elements:\n"
    ^ eval_ctx_to_string ~span:(Some span) ~filter:false ctx0
    ^ "\n"];

  (* Rem.: this function raises exceptions of type [Distinct] *)
  let rec match_envs (env0 : env) (env1 : env) : unit =
    [%ldebug
      "match_envs:\n\n- fixed_ids:\n" ^ show_ids_sets fixed_ids
      ^ "\n\n- rid_map: "
      ^ RegionId.InjSubst.show_t !rid_map
      ^ "\n- blid_map: "
      ^ BorrowId.InjSubst.show_t !blid_map
      ^ "\n- sid_map: "
      ^ SymbolicValueId.InjSubst.show_t !sid_map
      ^ "\n- aid_map: "
      ^ AbsId.InjSubst.show_t !aid_map
      ^ "\n\n- ctx0:\n"
      ^ eval_ctx_to_string ~span:(Some span) ~filter:false
          { ctx0 with env = List.rev env0 }
      ^ "\n\n- ctx1:\n"
      ^ eval_ctx_to_string ~span:(Some span) ~filter:false
          { ctx1 with env = List.rev env1 }
      ^ "\n\n"];
    match env0 with
    | EBinding (BDummy b0, v0) :: env0' ->
        (* Check whether the dummy value is fixed or not *)
        let v1, env1' =
          if DummyVarId.Set.mem b0 fixed_ids.dids then (
            let v1, env1' = pop_dummy b0 env1 in
            (* Fixed values: the values must be equal *)
            [%sanity_check_recover] S.recover span (v0 = v1);
            (* The ids present in the left value must be fixed *)
            let ids, _ = compute_tvalue_ids v0 in
            [%sanity_check_recover] S.recover span
              ((not S.check_equiv) || ids_are_fixed ids);
            (v1, env1'))
          else pop_first_dummy env1
        in
        (* Match the values - allows to compute mappings (which
           are the identity actually) *)
        let _ = M.match_tvalues ctx0 ctx1 v0 v1 in
        match_envs env0' env1'
    | EBinding (BVar b0, v0) :: env0' ->
        let v1, env1' = pop_var b0 env1 in
        (* Match the values *)
        let _ = M.match_tvalues ctx0 ctx1 v0 v1 in
        (* Continue *)
        match_envs env0' env1'
    | EAbs abs0 :: env0' ->
        (* Same as for the dummy values: there are two cases *)
        if AbsId.Set.mem abs0.abs_id fixed_ids.aids then (
          [%ldebug "match_envs: matching abs: fixed abs"];
          let abs1, env1' = pop_abs abs0.abs_id env1 in
          (* Still in the prefix: the abstractions must be the same *)
          [%sanity_check_recover] S.recover span (abs0 = abs1);
          (* Their ids must be fixed *)
          let ids, _ = compute_abs_ids abs0 in
          [%sanity_check_recover] S.recover span
            ((not S.check_equiv) || ids_are_fixed ids);
          (* Continue *)
          match_envs env0' env1')
        else (
          [%ldebug "match_envs: matching abs: not fixed abs"];
          let _abs1, env1' = pop_first_matching_abs abs0 env1 in
          (* No need to match the abstractions: we already did during the lookup *)
          (* Continue *)
          match_envs env0' env1')
    | [] ->
        (* Done: just check that the right environment is empty *)
        if env1 = [] then ()
        else
          raise
            (Distinct
               "The right environment has more elements than the left \
                environment")
    | EFrame :: _ ->
        (* This is unexpected *)
        [%internal_error] span
  in

  (* Match the environments.

     Rem.: we don't match the ended regions (would it make any sense actually?) *)
  (* Remove the frame delimiter (the first element of an environment is a frame delimiter) *)
  let env0 = List.rev ctx0.env in
  let env1 = List.rev ctx1.env in
  let env0, env1 =
    match (env0, env1) with
    | EFrame :: env0, EFrame :: env1 -> (env0, env1)
    | _ -> [%craise] span "Unreachable"
  in

  match_envs env0 env1;
  (* Every parent of an abstraction of the target context must correspond to a
     parent of the matching abstraction of the source context. The source
     abstraction may have more parents: they are ended before it, which only
     restricts the order in which the target borrows are ended (e.g., the loop
     abstractions of a fixed point where the region abstractions of a call in
     the loop body were joined with the abstractions of the loop entry). *)
  if not check_equiv then begin
    let abs0 = env_get_abs ctx0.env in
    let abs1 = env_get_abs ctx1.env in
    let aid_map = AbsId.InjSubst.to_map !aid_map in
    AbsId.InjSubst.Map.iter
      (fun aid0 aid1 ->
        match (AbsId.Map.find_opt aid0 abs0, AbsId.Map.find_opt aid1 abs1) with
        | Some abs0, Some abs1 ->
            let parents0 =
              AbsId.Set.filter_map
                (fun p -> AbsId.InjSubst.Map.find_opt p aid_map)
                abs0.parents
            in
            if not (AbsId.Set.subset abs1.parents parents0) then
              raise
                (Distinct
                   ("match_abstractions: the parents of "
                  ^ AbsId.to_string aid1 ^ " are not parents of "
                  ^ AbsId.to_string aid0))
        | _ -> ())
      aid_map
  end;
  (* The fixed abstractions are matched with themselves ([match_envs] checks
     that they are equal), so their symbolic values map to themselves. A join
     can introduce fresh symbolic values in them: expanding a symbolic value
     also expands its copies in the shared loans of the frozen input
     abstractions, and the join of the branches where it was expanded
     differently gives the loan value a fresh symbolic value, which is an
     output of the join (see [compute_ctx_fresh_ordered_symbolic_values]).
     Only the values no other element mapped are added. *)
  if not check_equiv then
    List.iter
      (fun (e : env_elem) ->
        match e with
        | EAbs abs when AbsId.Set.mem abs.abs_id fixed_ids.aids ->
            let _, { sids_to_values } = compute_abs_ids abs in
            SymbolicValueId.Map.iter
              (fun sid sv ->
                if not (SymbolicValueId.Map.mem sid !sid_to_value_map) then
                  sid_to_value_map :=
                    SymbolicValueId.Map.add sid
                      (mk_tvalue_from_symbolic_value ctx0.type_ctx.type_infos ctx0.metadata_bindings sv)
                      !sid_to_value_map)
              sids_to_values
        | _ -> ())
      ctx0.env;
  let maps =
    {
      aid_map = !aid_map;
      blid_map = !blid_map;
      borrow_id_map = !borrow_id_map;
      loan_id_map = !loan_id_map;
      rid_map = !rid_map;
      sid_map = !sid_map;
      sid_to_value_map = !sid_to_value_map;
    }
  in
  maps

let try_match_ctxs (span : Meta.span) ~(check_equiv : bool)
    ?(check_kind : bool = true) ?(check_can_end : bool = true)
    ?selected_pair
    (fixed_ids : ids_sets) (lookup_shared_value_in_ctx0 : BorrowId.id -> tvalue)
    (lookup_shared_value_in_ctx1 : BorrowId.id -> tvalue) (ctx0 : eval_ctx)
    (ctx1 : eval_ctx) : ids_maps option =
  try
    Some
      (match_ctxs span ~check_equiv ~check_kind ~check_can_end ?selected_pair ~recoverable:true
         fixed_ids lookup_shared_value_in_ctx0 lookup_shared_value_in_ctx1 ctx0
         ctx1)
  with
  | Distinct msg ->
      let () = [%ltrace "distinct: " ^ msg] in
      None

  | ValueMatchFailure k ->
      let () = [%ltrace "distinct: ValueMatchFailure" ^ show_updt_env_kind k] in
      None

  | Errors.RFailure ->
      let () = [%ltrace "unexpected failure"] in
      None

let ctxs_are_equivalent (span : Meta.span) (fixed_ids : ids_sets)
    (ctx0 : eval_ctx) (ctx1 : eval_ctx) : bool =
  let lookup_shared_value _ = [%craise] span "Unreachable" in
  Option.is_some
    (try_match_ctxs span ~check_equiv:true fixed_ids lookup_shared_value
       lookup_shared_value ctx0 ctx1)

let prepare_match_ctx_with_target (config : config) (span : Meta.span)
    ?(loop : bool = false) ~(recoverable : bool) (fresh_abs_kind : abs_kind)
    (src_ctx : eval_ctx) : cm_fun =
 fun tgt_ctx ->
  (* Debug *)
  [%ldebug
    "- src_ctx: "
    ^ eval_ctx_to_string ~span:(Some span) src_ctx
    ^ "\n- tgt_ctx: "
    ^ eval_ctx_to_string ~span:(Some span) tgt_ctx];
  (* End the loans which lead to mismatches when joining *)
  let rec reorganize_join_tgt : cm_fun =
   fun tgt_ctx ->
    (* We match only the values which appear in both environments *)
    let dummy_ids0 = env_get_dummy_var_ids src_ctx.env in
    let dummy_ids1 = env_get_dummy_var_ids tgt_ctx.env in
    let dummy_ids = DummyVarId.Set.inter dummy_ids0 dummy_ids1 in
    let abs_ids = compute_fixed_abs_ids src_ctx tgt_ctx in

    let filt_src_env, _, _ = ctx_split span abs_ids dummy_ids src_ctx in
    let filt_tgt_env, _, _ = ctx_split span abs_ids dummy_ids tgt_ctx in

    [%ldebug
      "reorganize_join_tgt:" ^ "\n- filt_src_ctx: "
      ^ env_to_string span src_ctx filt_src_env
      ^ "\n- filt_tgt_ctx: "
      ^ env_to_string span tgt_ctx filt_tgt_env];

    (* Remove the abstractions *)
    let filter (ee : env_elem) : bool =
      match ee with
      | EBinding _ -> true
      | EAbs _ | EFrame -> false
    in
    let filt_src_env = List.filter filter filt_src_env in
    let filt_tgt_env = List.filter filter filt_tgt_env in

    (* Match the values to check if there are loans to eliminate *)
    let nabs = ref [] in
    let metadata_bindings =
      ref (merge_metadata_bindings (Some span) src_ctx.metadata_bindings tgt_ctx.metadata_bindings)
    in

    let module S : MatchJoinState = struct
      let span = span
      let fresh_abs_kind = fresh_abs_kind
      let loop_level_outputs = loop_level_outputs ~loop fresh_abs_kind
      let nabs = nabs
      let metadata_bindings = metadata_bindings

      (* We're only preparing the match by ending loans, etc., and shouldn't introduce
         fresh region abstractions: this parameter is not relevant (and we set it to
         false by default).
      *)
      let with_abs_conts = false
      let symbolic_to_value = ref SymbolicValueId.Map.empty
      let recover = recoverable

      let lookup_shared_value ~is_left:_ ctx bid =
        InterpBorrowsCore.ctx_lookup_shared_value span ctx bid
    end in
    let module BaseJM = MakeJoinMatcher (S) in
    let module JM = struct
      include BaseJM

      let match_mut_loan_with_other match_rec ctx0 ctx1 ~loan_is_left ty lid (other : tvalue) =

        if not loan_is_left
           && not (is_symbolic other.value)
           && not (is_bottom other.value)

           && not (ValuesUtils.value_has_loans_or_borrows (Some span)
                     ctx0.type_ctx.type_infos other.value)
        then raise (ValueMatchFailure (LoanInRight lid))

        else
          BaseJM.match_mut_loan_with_other match_rec ctx0 ctx1 ~loan_is_left
            ty lid other
    end in
    let module M = MakeMatcher (JM) in
    try
      (* Match the bindings which appear in both environments *)
      (* TODO: we shouldn't filter the locals (they should appear in both envs)? *)
      let src_dummy_ids = env_get_dummy_var_ids filt_src_env in
      let src_local_ids = env_get_local_ids filt_src_env in
      let tgt_dummy_ids = env_get_dummy_var_ids filt_tgt_env in
      let tgt_local_ids = env_get_local_ids filt_tgt_env in
      let dummy_ids = DummyVarId.Set.inter src_dummy_ids tgt_dummy_ids in
      let local_ids =
        Expressions.LocalId.Set.inter src_local_ids tgt_local_ids
      in
      (* We need to filter the environments further *)
      let keep (e : env_elem) : bool =
        match e with
        | EBinding (BDummy id, _) when DummyVarId.Set.mem id dummy_ids -> true
        | EBinding (BVar v, _)
          when Expressions.LocalId.Set.mem v.index local_ids -> true
        | _ -> false
      in
      let filt_src_env = List.filter keep filt_src_env in
      let filt_tgt_env = List.filter keep filt_tgt_env in
      [%sanity_check_recover] S.recover span
        (List.length filt_src_env = List.length filt_tgt_env);
      let _ =
        List.iter
          (fun (var0, var1) ->
            match (var0, var1) with
            | EBinding (BDummy b0, v0), EBinding (BDummy b1, v1) ->
                [%sanity_check_recover] S.recover span (b0 = b1);
                let _ = M.match_tvalues src_ctx tgt_ctx v0 v1 in
                ()
            | EBinding (BVar b0, v0), EBinding (BVar b1, v1) ->
                [%sanity_check_recover] S.recover span (b0 = b1);
                let _ = M.match_tvalues src_ctx tgt_ctx v0 v1 in
                ()
            | _ -> [%craise] span "Unexpected")
          (List.combine filt_src_env filt_tgt_env)
      in
      (* The dummy values which only appear in the target are converted to
         region abstractions by the join, which cannot hold nested mutable
         borrows (see {!InterpJoin.join_ctxs}): end them first *)
      List.iter
        (function
          | EBinding (BDummy did, v) when not (DummyVarId.Set.mem did dummy_ids0)
            ->
              Option.iter
                (fun id -> raise (ValueMatchFailure (LoanInRight id)))
                (value_nested_mut_borrows_owner span ~shared_payloads:true
                   tgt_ctx v)
          | _ -> ())
        tgt_ctx.env;
      (* No exception was thrown: continue *)
      [%ldebug
        "reorganize_join_tgt: done with borrows/loans:" ^ "\n- filt_src_ctx: "
        ^ env_to_string span src_ctx filt_src_env
        ^ "\n- filt_tgt_ctx: "
        ^ env_to_string span tgt_ctx filt_tgt_env];
      (tgt_ctx, fun e -> e)
    with ValueMatchFailure e ->
      (* Exception: end the corresponding borrows, and continue *)
      let ctx, cc =
        match e with
        | LoanInRight bid ->
            [%ldebug "LoanInRight: " ^ BorrowId.to_string bid];
            InterpBorrows.end_loan config span bid tgt_ctx
        | LoansInRight bids ->
            [%ldebug "LoansInRight: " ^ BorrowId.Set.to_string None bids];
            InterpBorrows.end_loans config span bids tgt_ctx
        | AbsInRight _ | AbsInLeft _ | LoanInLeft _ | LoansInLeft _ ->
            [%craise] span "Unexpected"
      in
      comp cc (reorganize_join_tgt ctx)
  in
  (* Apply the reorganization *)
  let ctx, cc = reorganize_join_tgt tgt_ctx in
  Invariants.check_invariants span ctx;
  (ctx, cc)
