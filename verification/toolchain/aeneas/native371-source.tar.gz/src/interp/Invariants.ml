(* The following module defines functions to check that some invariants
 * are always maintained by evaluation contexts *)

open Types
open Values
open Contexts
open TypesUtils
open InterpUtils
open InterpBorrowsCore

(** The local logger *)
let log = Logging.invariants_log

(*
```ocaml
*)
let check_physical_input_scope span ctx (owner : abs) (scope : physical_input_scope) =
        let slot = scope.physical_slot in
        let origin = slot.origin in
        let canonical = ctx_lookup_abs ctx origin.source_owner in
        check_function_input_interface span ctx scope.witnesses origin canonical;
        [%sanity_check] span
          (ValuesUtils.same_region_hierarchy_topology scope.ancestry.source_hierarchy
            scope.ancestry.body_hierarchy);
        let ancestors hierarchy =
          let groups = Charon.GAstUtils.list_ancestor_region_groups
            hierarchy origin.region_group in
          List.fold_left
            (fun regions (group : region_var_group) ->
              if RegionGroupId.Set.mem group.id groups then
                List.fold_left (fun regions region -> RegionId.Set.add region regions)
                  regions group.regions
              else regions)
            RegionId.Set.empty hierarchy in
        let source_parents = ancestors scope.ancestry.source_hierarchy in
        let body_parents = ancestors scope.ancestry.body_hierarchy in
        let root = origin.transport_root in
        [%sanity_check] span
          (List.mem origin scope.witnesses.carrier_origins
           && ty_is_rty ctx.type_ctx.type_infos root.sv_ty
           && not (RegionId.Set.is_empty slot.proj_regions)
           && RegionId.Set.equal slot.proj_regions
                (RegionId.Set.inter owner.regions.owned
                  (ty_regions ctx.type_ctx.type_infos root.sv_ty)));
        [%sanity_check] span
          (List.mem slot.value_path
            (InterpProjectors.physical_input_paths span ctx canonical.regions.owned
              source_parents origin.original_root.sv_ty)
           && List.mem slot.value_path
            (InterpProjectors.physical_input_paths span ctx owner.regions.owned
              body_parents root.sv_ty));
        ()
(*
```
*)
type borrow_info = {
  loan_kind : ref_kind;
  loan_in_abs : bool;  (** true if the loan was found in an abstraction *)
  found_borrow : bool;
      (** [true] if we found the borrow (note that we start by registering the
          loans appearing in the context, and then check that all corresponding
          borrows appear: we thus don't need a [found_loan] field).

          This is only useful for mutable borrows, as any mutable loan has a
          unique corresponding mutable borrow (and vice-versa). *)
  shared_borrow_ids : SharedBorrowId.Set.t;
      (** For shared borrows: the set of unique shared borrow ids found in the
          context *)
}
[@@deriving show]

type outer_borrow_info = {
  outer_borrow : bool;  (** true if the value is borrowed *)
  outer_shared : bool;  (** true if the value is borrowed as shared *)
}

let set_outer_mut (info : outer_borrow_info) : outer_borrow_info =
  { info with outer_borrow = true }

let set_outer_shared (_info : outer_borrow_info) : outer_borrow_info =
  { outer_borrow = true; outer_shared = true }

let ids_reprs_to_string (indent : string) (reprs : BorrowId.id BorrowId.Map.t) :
    string =
  BorrowId.Map.to_string (Some indent) BorrowId.to_string reprs

let borrows_infos_to_string (indent : string)
    (infos : borrow_info BorrowId.Map.t) : string =
  BorrowId.Map.to_string (Some indent) show_borrow_info infos

type borrow_kind = BMut | BShared | BReserved [@@deriving show]

(** Check that:
    - loans and borrows are correctly related
    - a two-phase borrow can't point to a value inside an abstraction *)
let check_loans_borrows_relation_invariant (span : Meta.span) (ctx : eval_ctx) :
    unit =
  (* We do this in two phases:
     - we first register the loans
     - then register the borrows *)
  (* Link all the borrow ids to a borrow information *)
  let borrows_infos : borrow_info BorrowId.Map.t ref = ref BorrowId.Map.empty in
  let shared_borrow_ids = ref SharedBorrowId.Set.empty in
  let context_to_string () : string =
    eval_ctx_to_string ~span:(Some span) ctx
    ^ "\n- info:\n"
    ^ borrows_infos_to_string "  " !borrows_infos
  in
  (* Ignored loans - when we find an ignored loan while building the borrows_infos
     map, we register it in this list; once the borrows_infos map is completely
     built, we check that all the borrow ids of the ignored loans are in this
     map *)
  let ignored_loans : (ref_kind * BorrowId.id) list ref = ref [] in

  (* First, register all the loans *)
  (* Some utilities to register the loans *)
  let register_ignored_loan (rkind : ref_kind) (bid : BorrowId.id) : unit =
    ignored_loans := (rkind, bid) :: !ignored_loans
  in

  let register_shared_loan (loan_in_abs : bool) (bid : BorrowId.id) : unit =
    let infos = !borrows_infos in
    (* Insert the loan info *)
    let info =
      {
        loan_kind = RShared;
        loan_in_abs;
        found_borrow = false;
        shared_borrow_ids = SharedBorrowId.Set.empty;
      }
    in
    let infos = BorrowId.Map.add bid info infos in
    (* Update *)
    borrows_infos := infos
  in

  let register_mut_loan (loan_in_abs : bool) (bid : BorrowId.id) : unit =
    let infos = !borrows_infos in
    (* Sanity checks *)
    [%sanity_check] span (not (BorrowId.Map.mem bid infos));
    (* Add the mapping for the loan info *)
    let info =
      {
        loan_kind = RMut;
        loan_in_abs;
        found_borrow = false;
        shared_borrow_ids = SharedBorrowId.Set.empty;
      }
    in
    let infos = BorrowId.Map.add bid info infos in
    (* Update *)
    borrows_infos := infos
  in

  let loans_visitor =
    object
      inherit [_] iter_eval_ctx as super

      (* Live ownership is not stored in types or continuation metadata. *)
      method! visit_ty _ _ = ()
      method! visit_abs_cont _ _ = ()

      method! visit_EBinding _ binder v =
        let inside_abs = false in
        super#visit_EBinding inside_abs binder v

      method! visit_EAbs _ abs =
        let inside_abs = true in
        super#visit_EAbs inside_abs abs

      method! visit_loan_content inside_abs lc =
        (* Register the loan *)
        let _ =
          match lc with
          | VSharedLoan (bid, _) -> register_shared_loan inside_abs bid
          | VMutLoan bid -> register_mut_loan inside_abs bid
        in
        (* Continue exploring *)
        super#visit_loan_content inside_abs lc

      method! visit_aloan_content inside_abs lc =
        let _ =
          match lc with
          | AMutLoan (_, bid, _) -> register_mut_loan inside_abs bid
          | ASharedLoan (_, bid, _, _) -> register_shared_loan inside_abs bid
          | AIgnoredMutLoan (_, Some bid, _) -> register_ignored_loan RMut bid
          | AIgnoredMutLoan (_, None, _)
          | AIgnoredSharedLoan _
          | AEndedMutLoan { given_back = _; child = _; given_back_meta = _ }
          | AEndedSharedLoan (_, _, _)
          | AEndedIgnoredMutLoan { given_back = _; child = _; _ } ->
              (* Do nothing *)
              ()
        in
        (* Continue exploring *)
        super#visit_aloan_content inside_abs lc
    end
  in

  (* Visit *)
  let inside_abs = false in
  loans_visitor#visit_eval_ctx inside_abs ctx;

  (* Then, register all the borrows *)
  (* Some utilities to register the borrows *)
  let find_info (bid : BorrowId.id) : borrow_info =
    match BorrowId.Map.find_opt bid !borrows_infos with
    | Some info -> info
    | None ->
        [%craise] span
          ("Internal error: please find an issue.\n\nCould not find borrow b@"
         ^ BorrowId.to_string bid)
  in

  let update_info (bid : BorrowId.id) (info : borrow_info) : unit =
    (* Update the info *)
    let infos =
      BorrowId.Map.update bid
        (fun x ->
          match x with
          | Some _ -> Some info
          | None -> [%craise] span "Unreachable")
        !borrows_infos
    in
    borrows_infos := infos
  in

  let register_ignored_borrow = register_ignored_loan in

  let register_borrow (kind : borrow_kind) (bid : BorrowId.id)
      (sid : SharedBorrowId.id option) : unit =
    [%sanity_check] span (kind = BMut || Option.is_some sid);
    (* Lookup the info *)
    let info = find_info bid in
    (* Check that the borrow kind is consistent *)
    (match (info.loan_kind, kind) with
    | RShared, (BShared | BReserved) | RMut, BMut -> ()
    | _ ->
        [%ltrace
          "- kind: " ^ show_borrow_kind kind ^ "\n- info.loan_kind: "
          ^ show_ref_kind info.loan_kind
          ^ "\n- bid: " ^ BorrowId.to_string bid ^ "\n- sid : "
          ^ Print.option_to_string SharedBorrowId.to_string sid];
        [%craise] span "Invariant not satisfied");
    (* Check that shared borrow ids are unique *)
    (match sid with
    | None -> ()
    | Some sid ->
        [%sanity_check] span
          (not (SharedBorrowId.Set.mem sid !shared_borrow_ids));
        shared_borrow_ids := SharedBorrowId.Set.add sid !shared_borrow_ids);
    (* A reserved borrow can't point to a value inside an abstraction *)
    [%sanity_check] span (kind <> BReserved || not info.loan_in_abs);
    (* Insert the borrow id *)
    [%sanity_check] span (info.loan_kind = RShared || not info.found_borrow);
    [%sanity_check] span
      (match sid with
      | None -> true
      | Some sid -> not (SharedBorrowId.Set.mem sid info.shared_borrow_ids));
    let info =
      {
        info with
        found_borrow = true;
        shared_borrow_ids =
          (match sid with
          | None -> info.shared_borrow_ids
          | Some sid -> SharedBorrowId.Set.add sid info.shared_borrow_ids);
      }
    in
    (* Update the info in the map *)
    update_info bid info
  in

  let borrows_visitor =
    object
      inherit [_] iter_eval_ctx as super
      method! visit_ty _ _ = ()
      method! visit_abs_cont _ _ = ()

      method! visit_abstract_shared_borrow _ asb =
        match asb with
        | AsbBorrow (bid, sid) -> (
            match BorrowId.Map.find_opt bid !borrows_infos with
            | Some info ->
                if info.loan_kind = RMut then
                  (* The mutable borrow is inside a shared projection: it is
                     frozen by the outer shared context. We don't register it
                     because [register_borrow] doesn't allow (RMut, BShared),
                     and the borrow is already tracked by the concrete
                     [VMutBorrow] in the context. *)
                  ()
                else register_borrow BShared bid (Some sid)
            | None ->
                (* The loan for this borrow was already ended (e.g., because
                   the mutable region was ended before the shared region).
                   The [AsbBorrow] is a stale reference in a shared
                   projection — this is fine. *)
                ())
        | AsbProjReborrows _ -> ()

      method! visit_borrow_content env bc =
        (* Register the loan *)
        let _ =
          match bc with
          | VSharedBorrow (bid, sid) -> register_borrow BShared bid (Some sid)
          | VMutBorrow (bid, _) -> register_borrow BMut bid None
          | VReservedMutBorrow (bid, sid) ->
              register_borrow BReserved bid (Some sid)
        in
        (* Continue exploring *)
        super#visit_borrow_content env bc

      method! visit_aborrow_content env bc =
        let _ =
          match bc with
          | AMutBorrow (_, bid, _) -> register_borrow BMut bid None
          | ASharedBorrow (_, bid, sid) ->
              register_borrow BShared bid (Some sid)
          | AIgnoredMutBorrow (Some bid, _) -> register_ignored_borrow RMut bid
          | AIgnoredMutBorrow (None, _)
          | AEndedMutBorrow _
          | AEndedIgnoredMutBorrow _
          | AEndedSharedBorrow
          | AProjSharedBorrow _ ->
              (* Do nothing *)
              ()
        in
        (* Continue exploring *)
        super#visit_aborrow_content env bc
    end
  in

  (* Visit *)
  borrows_visitor#visit_eval_ctx () ctx;

  (* Debugging *)
  [%ldebug "About to check context invariant:\n" ^ context_to_string ()];

  (* Finally, check that everything is consistant *)
  (* First, check all the ignored loans are present at the proper place *)
  List.iter
    (fun (rkind, bid) ->
      let info = find_info bid in
      [%sanity_check] span (info.loan_kind = rkind))
    !ignored_loans;

  (* Then, check the borrow infos *)
  BorrowId.Map.iter
    (fun _ (info : borrow_info) ->
      (* If the loan is a mutable loan, then the corresponding borrow must appear somewhere *)
      [%sanity_check] span (info.loan_kind <> RMut || info.found_borrow))
    !borrows_infos

(** Check that:
    - borrows/loans can't contain ⊥ or reserved mut borrows
    - shared loans can't contain mutable loans *)
let check_borrowed_values_invariant (span : Meta.span) (ctx : eval_ctx) : unit =
  let visitor =
    object
      inherit [_] iter_eval_ctx as super
      method! visit_ty _ _ = ()
      method! visit_abs_cont _ _ = ()

      method! visit_VBottom info =
        (* No ⊥ inside borrowed values *)
        [%sanity_check] span
          (Config.allow_bottom_below_borrow || not info.outer_borrow)

      method! visit_loan_content info lc =
        (* Update the info *)
        let info =
          match lc with
          | VSharedLoan (_, _) -> set_outer_shared info
          | VMutLoan _ ->
              (* No mutable loan inside a shared loan *)
              [%sanity_check] span (not info.outer_shared);
              set_outer_mut info
        in
        (* Continue exploring *)
        super#visit_loan_content info lc

      method! visit_borrow_content info bc =
        (* Update the info *)
        let info =
          match bc with
          | VSharedBorrow _ -> set_outer_shared info
          | VReservedMutBorrow _ ->
              [%sanity_check] span (not info.outer_borrow);
              set_outer_shared info
          | VMutBorrow (_, _) -> set_outer_mut info
        in
        (* Continue exploring *)
        super#visit_borrow_content info bc

      method! visit_aloan_content info lc =
        (* Update the info *)
        let info =
          match lc with
          | AMutLoan (_, _, _) -> set_outer_mut info
          | ASharedLoan (_, _, _, _) -> set_outer_shared info
          | AEndedMutLoan { given_back = _; child = _; given_back_meta = _ } ->
              set_outer_mut info
          | AEndedSharedLoan (_, _, _) -> set_outer_shared info
          | AIgnoredMutLoan (_, _, _) -> set_outer_mut info
          | AEndedIgnoredMutLoan { given_back = _; child = _; _ } ->
              set_outer_mut info
          | AIgnoredSharedLoan _ -> set_outer_shared info
        in
        (* Continue exploring *)
        super#visit_aloan_content info lc

      method! visit_aborrow_content info bc =
        (* Update the info *)
        let info =
          match bc with
          | AMutBorrow (_, _, _) -> set_outer_mut info
          | ASharedBorrow _ | AEndedSharedBorrow -> set_outer_shared info
          | AIgnoredMutBorrow _ | AEndedMutBorrow _ | AEndedIgnoredMutBorrow _
            -> set_outer_mut info
          | AProjSharedBorrow _ -> set_outer_shared info
        in
        (* Continue exploring *)
        super#visit_aborrow_content info bc
    end
  in

  (* Explore *)
  let info = { outer_borrow = false; outer_shared = false } in
  visitor#visit_eval_ctx info ctx

let check_literal_type (span : Meta.span) (cv : literal) (ty : literal_type) :
    unit =
  match (cv, ty) with
  | VScalar (SignedScalar (sv_ty, _)), TInt int_ty ->
      [%sanity_check] span (sv_ty = int_ty)
  | VScalar (UnsignedScalar (sv_ty, _)), TUInt int_ty ->
      [%sanity_check] span (sv_ty = int_ty)
  | VFloat fv, TFloat float_ty when fv.float_ty = float_ty -> ()
  | VBool _, TBool | VChar _, TChar -> ()
  | _ -> [%craise] span "Erroneous typing"

(** Pending inputs retain the whole carrier and witness paths, but own no loans. *)
let check_symbolic_pending_slot (span : Meta.span) (ctx : eval_ctx)
    (regions : RegionId.Set.t) (ty : ty) (slot : symbolic_pending_slot) : unit =
  let type_infos = ctx.type_ctx.type_infos in
  [%sanity_check] span (ty = slot.proj_ty && ty_is_rty type_infos slot.proj_ty);
  [%sanity_check] span
    (RegionId.Set.equal slot.proj_regions
       (RegionId.Set.inter regions (ty_regions type_infos slot.proj_ty)));
  [%sanity_check] span (not (RegionId.Set.is_empty slot.proj_regions));
  [%sanity_check] span (slot.ancestor_path <> []);
  let _, received = RegionsHierarchy.back_path_raw_stage slot.ancestor_path in
  [%sanity_check] span received;
  let rec check_value_path ty = function
    | [] -> ()
    | PDeref :: path -> (
        match ty with
        | TRef (_, ref_ty, RMut) -> check_value_path ref_ty path
        | _ -> [%craise] span "Pending carrier path dereferences a non-mutable type")
    | PField (variant_id, index) :: path -> (
        [%sanity_check] span (index >= 0);
        match ty with
        | TAdt { id; generics } -> (
            let fields =
              ctx_adt_get_instantiated_field_types span ctx id variant_id generics
            in
            match List.nth_opt fields index with
            | Some field_ty -> check_value_path field_ty path
            | None -> [%craise] span "Pending carrier path selects a missing field")
        | _ -> [%craise] span "Pending carrier path selects a field of a non-ADT")
  in
  check_value_path slot.proj_ty slot.value_path

(** If [lookups] is [true] whenever we encounter a loan/borrow we lookup the
    corresponding borrow/loan to check its type. This only works when checking
    non-partial environments. *)
let check_typing_invariant_visitor span ctx (lookups : bool) =
  (* TODO: the type of aloans doens't make sense: they have a type
   * of the shape [& (mut) T] where they should have type [T]...
   * This messes a bit the type invariant checks when checking the
   * children. In order to isolate the problem (for future modifications)
   * we introduce this function, so that we can easily spot all the involved
   * places.
   *)
  let aloan_get_expected_child_type (ty : ty) : ty =
    let _, ty, _ = ty_get_ref ty in
    ty
  in
  (* The types with erased regions of the symbolic values that we find *)
  let sv_etys = ref SymbolicValueId.Map.empty in
  let check_symbolic_value_ety sv_id ty =
    match SymbolicValueId.Map.find_opt sv_id !sv_etys with
    | None -> sv_etys := SymbolicValueId.Map.add sv_id ty !sv_etys
    | Some ty1 -> [%sanity_check] span (ty1 = ty)
  in
  let check_symbolic_value_type sv_id ty =
    check_symbolic_value_ety sv_id (TypesUtils.ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings ty)
  in
  object
(*
```ocaml
*)
    inherit [_] iter_eval_ctx_carrier_coordinates as super
(*
```
*)
    method! visit_ty _ _ = ()

    (* Type checks below inspect operational values explicitly. Continuation
       expressions contain only historical metadata and type annotations. *)
    method! visit_abs_cont _ _ = ()
    method! visit_abs _ abs = super#visit_abs (Some abs) abs

    method! visit_EBinding info binder v =
      (* We also check that the regions are erased *)
      [%sanity_check] span (ty_is_ety ctx.type_ctx.type_infos v.ty);
      super#visit_EBinding info binder v

    method! visit_symbolic_value inside_abs v =
      (* Check that the types have regions *)
      [%sanity_check] span (ty_is_rty ctx.type_ctx.type_infos v.sv_ty);
      super#visit_symbolic_value inside_abs v

    method! visit_tvalue info tv =
      (* Check that the types have erased regions *)
      [%sanity_check] span (ty_is_ety ctx.type_ctx.type_infos tv.ty);
      (* Check the current pair (value, type) *)
      (match (tv.value, tv.ty) with
      | VLiteral cv, TLiteral ty -> check_literal_type span cv ty
      (* ADT case *)
      | VAdt av, TAdt { id = TAdtId def_id; generics } ->
          (* Retrieve the definition to check the variant id, the number of
           * parameters, etc. *)
          let def = ctx_lookup_type_decl span ctx def_id in
          (* Check the number of parameters *)
          [%sanity_check] span
            (List.length generics.regions = List.length def.generics.regions);
          [%sanity_check] span
            (List.length generics.types = List.length def.generics.types);
          (* Check that the variant id is consistent *)
          (match (av.variant_id, def.kind) with
          | Some variant_id, Enum variants ->
              [%sanity_check] span
                (VariantId.to_int variant_id < List.length variants)
          | None, Struct _ -> ()
          | _ -> [%craise] span "Erroneous typing");
          (* Check that the field types are correct *)
          let field_types =
            ctx_type_get_instantiated_field_etypes span ctx def_id av.variant_id
              generics
          in
          let fields_with_types = List.combine av.fields field_types in
          List.iter
            (fun ((v, ty) : tvalue * ty) -> [%sanity_check] span (v.ty = ty))
            fields_with_types
      (* Tuple case *)
      | VAdt av, TAdt { id = TTuple; generics } ->
          [%sanity_check] span (generics.regions = []);
          [%sanity_check] span (generics.const_generics = []);
          [%sanity_check] span (av.variant_id = None);
          (* Check that the fields have the proper values - and check that there
           * are as many fields as field types at the same time *)
          let fields_with_types = List.combine av.fields generics.types in
          List.iter
            (fun ((v, ty) : tvalue * ty) -> [%sanity_check] span (v.ty = ty))
            fields_with_types
      (* Builtin type case *)
      | VAdt av, TArray (inner_ty, len) ->
          [%sanity_check] span
            (List.for_all (fun (v : tvalue) -> v.ty = inner_ty) av.fields);
          (* The length is necessarily concrete *)
          let len =
            Scalars.get_val
              (ValuesUtils.literal_as_scalar
                 (TypesUtils.constant_expr_as_literal len))
          in
          [%sanity_check] span (Z.of_int (List.length av.fields) = len)
      | VAdt _, TSlice _ -> [%craise] span "Unexpected slice value"
      | VAdt av, TAdt { id = TBuiltin aty_id; generics } -> (
          [%sanity_check] span (av.variant_id = None);
          match
            ( aty_id,
              av.fields,
              generics.regions,
              generics.types,
              generics.const_generics )
          with
          (* Box *)
          | TBox, [ inner_value ], [], [ inner_ty ], [] ->
              [%sanity_check] span (inner_value.ty = inner_ty)
          | TStr, _, _, _, _ -> [%craise] span "Unexpected str value"
          | _ -> [%craise] span "Erroneous type")
      | VBottom, _ -> (* Nothing to check *) ()
      | VBorrow bc, TRef (_, ref_ty, rkind) -> (
          match (bc, rkind) with
          | VSharedBorrow (bid, _), RShared | VReservedMutBorrow (bid, _), RMut
            -> (
              if
                (* Lookup the borrowed value to check it has the proper type.
                   Note that we ignore the marker: we will check it when
                   checking the loan itself. *)
                lookups
              then
                let _, glc = ctx_lookup_loan span ek_all bid ctx in
                match glc with
                | Concrete (VSharedLoan (_, sv))
                | Abstract (ASharedLoan (_, _, sv, _)) ->
                    [%sanity_check] span (sv.ty = ref_ty)
                | _ -> [%craise] span "Inconsistent context")
          | VMutBorrow (_, bv), RMut ->
              [%sanity_check] span
                ((* Check that the borrowed value has the proper type *)
                 bv.ty = ref_ty)
          | _ -> [%craise] span "Erroneous typing")
      | VLoan lc, ty -> (
          match lc with
          | VSharedLoan (_, sv) -> [%sanity_check] span (sv.ty = ty)
          | VMutLoan bid -> (
              if lookups then
                (* Lookup the borrowed value to check it has the proper type. *)
                let glc = lookup_borrow span ek_all (UMut bid) ctx in
                match glc with
                | Concrete (VMutBorrow (_, bv)) ->
                    [%sanity_check] span (bv.ty = ty)
                | Abstract (AMutBorrow (_, _, sv)) ->
                    [%sanity_check] span (TypesUtils.ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings sv.ty = ty)
                | _ -> [%craise] span "Inconsistent context"))
      | VSymbolic sv, ty ->
          check_symbolic_value_type sv.sv_id sv.sv_ty;
          let ty' = TypesUtils.ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings sv.sv_ty in
          if (!Config.print_error_diagnostics || !Config.print_error_emitters)
             && ty' <> ty
          then (
            let raw label text =
              let limit = 65536 in
              let length = String.length text in
              let shown = Stdlib.min limit length in
              let text = if shown = length then text else String.sub text 0 shown in
              Printf.eprintf "%s bytes=%d shown=%d:\n%s\n%!"
                label length shown text;
              if shown < length then
                Printf.eprintf "%s: truncated at the %d-character type text limit\n%!"
                  label limit
            in
            Printf.eprintf "Symbolic concrete typing mismatch: symbolic=%s\n"
              (SymbolicValueId.to_string sv.sv_id);
            raw "symbolic rty" (Types.show_ty sv.sv_ty);
            raw "concrete ety" (Types.show_ty ty);
            raw "resolved symbolic ety" (Types.show_ty ty');
            let relevant = ref RegionId.Set.empty in
            let regions =
              object
                inherit [_] iter_ty
                method! visit_region _ = function
                  | RVar (Free rid) ->
                      relevant := RegionId.Set.add rid !relevant
                  | _ -> ()
              end
            in
            regions#visit_ty () sv.sv_ty;
            regions#visit_ty () ty;
            regions#visit_ty () ty';
            let seen = ref RegionId.Set.empty in
            let remaining = ref 32 in
            let rec emit rid =
              if !remaining > 0 && not (RegionId.Set.mem rid !seen) then (
                decr remaining;
                seen := RegionId.Set.add rid !seen;
                match RegionId.Map.find_opt rid ctx.metadata_bindings with
                | None ->
                    Printf.eprintf "typing metadata: %s -> absent\n"
                      (RegionId.to_string rid)
                | Some MetadataFresh ->
                    Printf.eprintf "typing metadata: %s -> fresh\n"
                      (RegionId.to_string rid)
                | Some (MetadataSource source) ->
                    Printf.eprintf "typing metadata: %s -> %s\n"
                      (RegionId.to_string rid) (Types.show_region source);
                    (match source with RVar (Free next) -> emit next | _ -> ()))
            in
            RegionId.Set.iter emit !relevant;
            if !remaining = 0 then
              Printf.eprintf "typing metadata: 32-key diagnostic limit\n";
            Printf.eprintf "%!");
          [%sanity_check] span (ty' = ty)
      | VLiteral (VStr _), TAdt { id = TBuiltin TStr; _ } -> ()
      | _ ->
          [%ltrace
            "Erroneous typing:\n- value: " ^ tvalue_to_string ctx tv
            ^ "\n- type: " ^ ty_to_string ctx tv.ty];
          [%craise] span "Erroneous typing");
      (* Continue exploring to inspect the subterms *)
      super#visit_tvalue info tv

    (* TODO: there is a lot of duplication with {!visit_tvalue}
     * which is quite annoying. There might be a way of factorizing
     * that by factorizing the definitions of value and avalue, but
     * the generation of visitors then doesn't work properly (TODO:
     * report that). Still, it is actually not that problematic
     * because this code shouldn't change a lot in the future,
     * so the cost of maintenance should be pretty low.
     *)
    method! visit_tavalue info atv =
      (* Check that the types have regions *)
      [%sanity_check] span (ty_is_rty ctx.type_ctx.type_infos atv.ty);
      (* Check the current pair (value, type) *)
      (match (atv.value, atv.ty) with
(*
```ocaml
*)
      | ATransportedValue (transport, child), ty ->
          [%sanity_check] span (ty = child.ty);
          [%sanity_check] span
            (ValuesUtils.carrier_coordinate_return_matches transport)
(*
```
*)
      (* ADT case *)
      | AAdt av, TAdt { id = TAdtId def_id; generics } ->
          (* Retrieve the definition to check the variant id, the number of
           * parameters, etc. *)
          let def = ctx_lookup_type_decl span ctx def_id in
          (* Check the number of parameters *)
          [%sanity_check] span
            (List.length generics.regions = List.length def.generics.regions);
          [%sanity_check] span
            (List.length generics.types = List.length def.generics.types);
          [%sanity_check] span
            (List.length generics.const_generics
            = List.length def.generics.const_generics);
          (* Check that the variant id is consistent *)
          (match (av.variant_id, def.kind) with
          | Some variant_id, Enum variants ->
              [%sanity_check] span
                (VariantId.to_int variant_id < List.length variants)
          | None, Struct _ -> ()
          | _ -> [%craise] span "Erroneous typing");
          (* Check that the field types are correct *)
          let field_types =
            Substitute.type_decl_get_instantiated_field_types def av.variant_id
              generics
          in
          let fields_with_types = List.combine av.fields field_types in
          List.iter
            (fun ((v, ty) : tavalue * ty) -> [%sanity_check] span (v.ty = ty))
            fields_with_types
      (* Tuple case *)
      | AAdt av, TAdt { id = TTuple; generics } ->
          [%sanity_check] span (generics.regions = []);
          [%sanity_check] span (generics.const_generics = []);
          [%sanity_check] span (av.variant_id = None);
          (* Check that the fields have the proper values - and check that there
           * are as many fields as field types at the same time *)
          let fields_with_types = List.combine av.fields generics.types in
          List.iter
            (fun ((v, ty) : tavalue * ty) -> [%sanity_check] span (v.ty = ty))
            fields_with_types
      | AAdt av, TArray (inner_ty, len) ->
          [%sanity_check] span (av.variant_id = None);
          [%sanity_check] span
            (List.for_all (fun (v : tavalue) -> v.ty = inner_ty) av.fields);
          let len =
            Scalars.get_val
              (ValuesUtils.literal_as_scalar
                 (TypesUtils.constant_expr_as_literal len))
          in
          [%sanity_check] span (Z.of_int (List.length av.fields) = len)
      (* Builtin type case *)
      | AAdt av, TAdt { id = TBuiltin aty_id; generics } -> (
          [%sanity_check] span (av.variant_id = None);
          match
            ( aty_id,
              av.fields,
              generics.regions,
              generics.types,
              generics.const_generics )
          with
          (* Box *)
          | TBox, [ boxed_value ], [], [ boxed_ty ], [] ->
              [%sanity_check] span (boxed_value.ty = boxed_ty)
          | _ -> [%craise] span "Erroneous type")
      | ABorrow bc, TRef (region, ref_ty, rkind) -> (
          let abs = Option.get info in
          (* Check the borrow content *)
          match (bc, rkind) with
          | AMutBorrow (_, _, av), RMut ->
              (* Check that the region is owned by the abstraction *)
              [%sanity_check] span (region_is_owned abs region);
              (* Check that the child value has the proper type *)
              [%sanity_check] span (av.ty = ref_ty)
          | ASharedBorrow (_, bid, _), RShared -> (
              (* Check that the region is owned by the abstraction *)
              [%sanity_check] span (region_is_owned abs region);
              if lookups then
                (* Lookup the borrowed value to check it has the proper type *)
                let _, glc = ctx_lookup_loan span ek_all bid ctx in
                match glc with
                | Concrete (VSharedLoan (_, sv))
                | Abstract (ASharedLoan (_, _, sv, _)) ->
                    [%sanity_check] span
                      (sv.ty = TypesUtils.ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings ref_ty)
                | _ -> [%craise] span "Inconsistent context")
          | AIgnoredMutBorrow (_opt_bid, av), RMut ->
              [%sanity_check] span (av.ty = ref_ty)
          | ( AEndedIgnoredMutBorrow { given_back; child; given_back_meta = _ },
              RMut ) ->
              [%sanity_check] span (given_back.ty = ref_ty);
              [%sanity_check] span (child.ty = ref_ty)
          | AProjSharedBorrow _, RShared -> ()
          | AEndedMutBorrow (_meta, av), RMut ->
              (* Check that the region is owned by the abstraction *)
              [%sanity_check] span (region_is_owned abs region);
              (* Check that the child value has the proper type *)
              [%sanity_check] span (av.ty = ref_ty)
          | AEndedSharedBorrow, RShared -> ()
          | _ ->
              [%ltrace
                "Inconsistent context:\n- abs:\n" ^ abs_to_string span ctx abs
                ^ "\n\n- value:\n" ^ tavalue_to_string ctx atv ^ "\n\n- ty:\n"
                ^ ty_to_string ctx atv.ty];
              [%craise] span "Inconsistent context")
      | ALoan lc, aty -> (
          let abs = Option.get info in
          match lc with
          | AMutLoan (_, bid, child_av) | AIgnoredMutLoan (_, Some bid, child_av)
            -> (
              (* Check that the region is owned by the abstraction *)
              let region, _, _ = ty_as_ref aty in
              begin
                match lc with
                | AMutLoan _ ->
                    [%sanity_check] span (region_is_owned abs region)
                | _ -> ()
              end;
              let borrowed_aty = aloan_get_expected_child_type aty in
              [%sanity_check] span (child_av.ty = borrowed_aty);
              if lookups then
                (* Lookup the borrowed value to check it has the proper type *)
                let glc = lookup_borrow span ek_all (UMut bid) ctx in
                match glc with
                | Concrete (VMutBorrow (_, bv)) ->
                    [%sanity_check] span
                      (bv.ty = TypesUtils.ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings borrowed_aty)
                | Abstract (AMutBorrow (_, _, sv)) ->
                    [%sanity_check] span
                      (TypesUtils.ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings sv.ty
                      = TypesUtils.ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings borrowed_aty)
                | _ -> [%craise] span "Inconsistent context")
          | AIgnoredMutLoan (_, None, child_av) ->
              let borrowed_aty = aloan_get_expected_child_type aty in
              [%sanity_check] span (child_av.ty = borrowed_aty)
          | ASharedLoan (_, _, sv, child_av) | AEndedSharedLoan (_, sv, child_av)
            ->
              (* Check that the region is owned by the abstraction *)
              let region, _, _ = ty_as_ref aty in
              [%sanity_check] span (region_is_owned abs region);
              let borrowed_aty = aloan_get_expected_child_type aty in
              [%sanity_check] span
                (sv.ty = TypesUtils.ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings borrowed_aty);
              (* TODO: the type of aloans doesn't make sense, see above *)
              [%sanity_check] span (child_av.ty = borrowed_aty)
          | AEndedMutLoan { given_back; child; given_back_meta = _ }
          | AEndedIgnoredMutLoan { given_back; child; _ } ->
              (* Check that the region is owned by the abstraction *)
              let region, _, _ = ty_as_ref aty in
              begin
                match lc with
                | AEndedMutLoan _ ->
                    [%sanity_check] span (region_is_owned abs region)
                | _ -> ()
              end;
              let borrowed_aty = aloan_get_expected_child_type aty in
              [%sanity_check] span (given_back.ty = borrowed_aty);
              [%sanity_check] span (child.ty = borrowed_aty)
          | AIgnoredSharedLoan child_av ->
              [%sanity_check] span
                (child_av.ty = aloan_get_expected_child_type aty))
      | ASymbolic (_, aproj), ty -> (
          match aproj with
          | APendingLoans bid ->
              let abs = Option.get info in
              [%sanity_check] span (ty_has_regions_in_set ctx.type_ctx.type_infos abs.regions.owned ty);
              (* A pending projection refers to a still-live parent borrower,
                 never to a loan owner with a coincidentally equal numeric id.
                 Like the other lookups, this only holds in complete
                 environments (a join checks abstractions in partial ones). *)
              if lookups then
                let child_ty =
                  match lookup_borrow span ek_all (UMut bid) ctx with
                  | Concrete (VMutBorrow (_, child)) -> child.ty
                  | Abstract (AMutBorrow (_, _, child)) -> child.ty
                  | _ ->
                      [%craise] span
                        "Pending loan parent is not a mutable borrower"
                in
                [%sanity_check] span
                  (ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings ty = ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings child_ty)
          | APendingSymbolicLoans slot ->
              let abs = Option.get info in
              check_symbolic_value_type slot.root_sv_id slot.proj_ty;
              check_symbolic_pending_slot span ctx abs.regions.owned ty slot
          | AProjLoans { proj; _ } ->
              check_symbolic_value_type proj.sv_id ty;
              let abs = Option.get info in
              (* ```ocaml *)
              if !Config.sanity_checks
                 && not (ty_has_regions_in_set ctx.type_ctx.type_infos
                           abs.regions.owned proj.proj_ty) then
                [%craise] span
                  ("Internal error, please file an issue\n"
                  ^ "Live projection loan has no selected owned position:\n"
                  ^ "- owner: " ^ AbsId.to_string abs.abs_id
                  ^ "\n- symbolic root: " ^ SymbolicValueId.to_string proj.sv_id
                  ^ "\n- marker and actual value: " ^ tavalue_to_string ctx atv
                  ^ "\n- owned: " ^ RegionId.Set.to_string None abs.regions.owned
                  ^ "\n- complete stored type: " ^ ty_to_string ctx atv.ty
                  ^ "\n- complete projection type: " ^ ty_to_string ctx proj.proj_ty
                  ^ "\n- normalized mask: "
                  ^ ty_to_string ctx
                      (normalize_proj_ty ctx.type_ctx.type_infos
                         abs.regions.owned proj.proj_ty)
                  ^ "\n- complete owner:\n" ^ abs_to_string span ctx abs);
              (* ``` *)
          | AProjBorrows { proj; _ } ->
              check_symbolic_value_type proj.sv_id ty;
              [%sanity_check] span (ty_has_free_regions ctx.type_ctx.type_infos proj.proj_ty)
          | AEndedProjLoans { proj = _; consumed; borrows } ->
              let abs = Option.get info in
              let expected_ty = ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings ty in
              let check_return (meta : mconsumed_symb) sv_id =
                let returned_ty = ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings meta.proj_ty in
                [%sanity_check] span
                  (sv_id = meta.sv_id && returned_ty = expected_ty);
                check_symbolic_value_ety sv_id returned_ty
              in
              let check_live owned (meta : mconsumed_symb) (proj : symbolic_proj) =
                (* Payload and receiver views may independently name regions.
                   The live view must refer to the actual return and select
                   owned storage; global checks enforce ownership coverage. *)
                check_return meta proj.sv_id;
                [%sanity_check] span
                  (ty_is_rty ctx.type_ctx.type_infos proj.proj_ty
                  && ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings proj.proj_ty = expected_ty
                  && ty_has_regions_in_set ctx.type_ctx.type_infos owned proj.proj_ty)
              in
              let rec check_child owned ((meta : mconsumed_symb), child) =
                match child with
(*
```ocaml
*)
                | ATransportedProj (transport, child) ->
                    [%sanity_check] span
                      (transport.current.sv_id = meta.sv_id
                       && transport.current.sv_ty = meta.proj_ty
                       && ValuesUtils.carrier_coordinate_return_matches transport);
                    check_child transport.current_regions (meta, child)
(*
```
*)
                | AProjBorrows { proj; loans } ->
(*
```ocaml
*)
                    check_live owned meta proj;
                    List.iter (check_child owned) loans
(*
```
*)
                | AProjLoans { proj; consumed; borrows } ->
(*
```ocaml
*)
                    check_live owned meta proj;
                    List.iter (check_child owned) consumed;
                    List.iter (check_child owned) borrows
(*
```
*)
                | AEndedProjLoans { proj; consumed; borrows } ->
                    check_return meta proj;
(*
```ocaml
*)
                    List.iter (check_child owned) consumed;
                    List.iter (check_child owned) borrows
(*
```
*)
                | AEndedProjBorrows { mvalues; loans } ->
                    check_return meta mvalues.consumed;
                    let returned_ty =
                      ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings mvalues.given_back.sv_ty
                    in
                    [%sanity_check] span (returned_ty = expected_ty);
                    check_symbolic_value_ety mvalues.given_back.sv_id
                      returned_ty;
                    List.iter (check_child owned) loans
                | AEmpty -> ()
                | APendingLoans _ | APendingSymbolicLoans _ ->
                    [%craise] span
                      "A pending parent input cannot be a historical projector \
                       child"
              in
(*
```ocaml
*)
              List.iter (check_child abs.regions.owned) consumed;
              List.iter (check_child abs.regions.owned) borrows
(*
```
*)
          | ATransportedProj _ | AEndedProjBorrows _ | AEmpty -> ())
      | AIgnored _, _ -> ()
      | _ ->
          [%ltrace
            "Erroneous typing:" ^ "\n- raw value: " ^ show_tavalue atv
            ^ "\n- value: "
            ^ tavalue_to_string ~span:(Some span) ctx atv
            ^ "\n- type: " ^ ty_to_string ctx atv.ty];
          [%internal_error] span);
      (* Continue exploring to inspect the subterms *)
      super#visit_tavalue info atv
  end

let check_typing_invariant (span : Meta.span) (ctx : eval_ctx) (lookups : bool)
    : unit =
  (check_typing_invariant_visitor span ctx lookups)#visit_eval_ctx
    (None : abs option)
    ctx

type proj_borrows_info = {
  abs_id : AbsId.id;
  regions : RegionId.Set.t;
  proj_ty : rty;  (** The regions shouldn't be erased *)
  as_shared_value : bool;  (** True if the value is below a shared borrow *)
}
[@@deriving show]

type proj_loans_info = {
  abs_id : AbsId.id;
  regions : RegionId.Set.t;
  proj_ty : rty;
}
[@@deriving show]

type sv_info = {
  env_count : int;
  aproj_borrows : proj_borrows_info list;
  aproj_loans : proj_loans_info list;
}
[@@deriving show]

let proj_borrows_info_to_string (ctx : eval_ctx) (info : proj_borrows_info) :
    string =
  let { abs_id; regions; proj_ty; as_shared_value } = info in
  "{ abs_id = " ^ AbsId.to_string abs_id ^ "; regions = "
  ^ RegionId.Set.to_string None regions
  ^ "; proj_ty = " ^ ty_to_string ctx proj_ty ^ "; as_shared_value = "
  ^ Print.bool_to_string as_shared_value
  ^ "}"

let proj_loans_info_to_string (ctx : eval_ctx) (info : proj_loans_info) : string
    =
  let { abs_id; regions; proj_ty } = info in
  "{ abs_id = " ^ AbsId.to_string abs_id ^ "; regions = "
  ^ RegionId.Set.to_string None regions
  ^ "; proj_ty = " ^ ty_to_string ctx proj_ty ^ "}"

let sv_info_to_string (ctx : eval_ctx) (info : sv_info) : string =
  let { env_count = _; aproj_borrows; aproj_loans } = info in
  "{\n  aproj_borrows = ["
  ^ String.concat ", "
      (List.map (proj_borrows_info_to_string ctx) aproj_borrows)
  ^ "];\n  aproj_loans = ["
  ^ String.concat ", " (List.map (proj_loans_info_to_string ctx) aproj_loans)
  ^ "]\n}"

(** Check the invariants over the symbolic values.

    - a symbolic value can't be both in proj_borrows and in the concrete env
      (this is why we preemptively expand copyable symbolic values)
    - if a symbolic value contains regions: there is at most one occurrence of
      this value in the concrete env
    - if there is an aproj_borrows in the environment, there must also be a
      corresponding aproj_loans
    - aproj_loans are mutually disjoint
    - consuming borrow projections are disjoint from all other borrow
      projections; nonconsuming shared observations may alias each other
    - the union of the aproj_loans contains the aproj_borrows applied on the
      same symbolic values
    - all symbolic evalues should contain mutable borrows/loans *)
let check_symbolic_values (span : Meta.span) (ctx : eval_ctx) : unit =
  (* Small utility *)
  let module M = SymbolicValueId.Map in
  let infos : sv_info M.t ref = ref M.empty in
  let pending_slots = ref [] in
  let lookup_info (sv_id : symbolic_value_id) : sv_info =
    match M.find_opt sv_id !infos with
    | Some info -> info
    | None -> { env_count = 0; aproj_borrows = []; aproj_loans = [] }
  in
  let update_info (sv_id : symbolic_value_id) (info : sv_info) =
    infos := M.add sv_id info !infos
  in
  (* Symbolic values whose references all point to static data (the values of
     globals, see [eval_global_as_fresh_symbolic_value]): the lender of their
     borrows is the static storage, which is not represented. *)
  let static_svs = ref SymbolicValueId.Set.empty in
  let is_static_ty (ty : ty) : bool =
    let has_region = ref false in
    let only_static = ref true in
    let visitor =
      object
        inherit [_] TypesAnalysis.iter_storage_ty ctx.type_ctx.type_infos

        method! visit_region _ r =
          has_region := true;
          if r <> RStatic then only_static := false
      end
    in
    visitor#visit_ty () ty;
    !has_region && !only_static
  in
  let add_env_sv (sv_id : symbolic_value_id) : unit =
    let info = lookup_info sv_id in
    let info = { info with env_count = info.env_count + 1 } in
    update_info sv_id info
  in
  let add_aproj_borrows abs_id regions (proj : symbolic_proj) as_shared_value :
      unit =
    let sv_id = proj.sv_id in
    let info = lookup_info sv_id in
    let binfo = { abs_id; regions; proj_ty = proj.proj_ty; as_shared_value } in
    let info = { info with aproj_borrows = binfo :: info.aproj_borrows } in
    update_info sv_id info
  in
  let add_aproj_loans abs_id regions (proj : symbolic_proj) : unit =
    let sv = proj.sv_id in
    let info = lookup_info sv in
    let linfo = { abs_id; regions; proj_ty = proj.proj_ty } in
    let info = { info with aproj_loans = linfo :: info.aproj_loans } in
    update_info sv info
  in
  (* Visitor *)
  let visited_evalues = EvalueTbl.create 16 in
  let obj =
    object (self)
(*
```ocaml
*)
      inherit [_] iter_eval_ctx_carrier_coordinates as super
(*
```
*)
      val mutable aproj_depth = 0
      val mutable eproj_depth = 0
      val mutable runtime_pending = []
      val mutable continuation_pending = []
      val mutable slot_protocols = []
      val mutable declared_raw_paths = None
      val mutable endpoint_scope = None
      val mutable scoped_evalues = visited_evalues
      method! visit_ty _ _ = ()

      (* Actual endpoint coverage uses storage summaries, not ownership registration. *)
      method private actual_endpoint_masks regions actual =
        let masks = ref [] in
        let add ty =
          [%sanity_check] span (ty_is_rty ctx.type_ctx.type_infos ty);
          masks :=
            RegionId.Set.inter regions (ty_regions ctx.type_ctx.type_infos ty)
            :: !masks
        in
        let visitor =
          object
            inherit [_] iter_tavalue as super
            val mutable has_endpoint = false
            method! visit_ty _ _ = ()
            method! visit_borrow_id _ _ = has_endpoint <- true
            method! visit_loan_id _ _ = has_endpoint <- true
            method! visit_symbolic_proj _ (proj : symbolic_proj) =
              has_endpoint <- true;
              add proj.proj_ty
            method! visit_msymbolic_value_id _ _ = has_endpoint <- true

            method! visit_symbolic_value _ sv =
              has_endpoint <- true;
              add sv.sv_ty

            method! visit_msymbolic_value _ sv =
              has_endpoint <- true;
              add sv.sv_ty

            method! visit_ended_proj_borrow_meta _ meta =
              has_endpoint <- true;
              add meta.given_back.sv_ty

            method! visit_aproj env proj =
              match proj with
              | APendingLoans _ | APendingSymbolicLoans _ ->
                  [%craise] span "A pending shell cannot be an actual endpoint witness"
              | _ -> super#visit_aproj env proj

            method! visit_tavalue env value =
              let previous = has_endpoint in
              has_endpoint <- false;
              super#visit_tavalue env value;
              (match value.value with
              | ALoan (AEndedMutLoan _) -> has_endpoint <- true
              | ASymbolic (_, AEndedProjLoans _) -> has_endpoint <- true
              | _ -> ());
              let actual = has_endpoint in
              if actual then add value.ty;
              has_endpoint <- previous || actual
          end
        in
        visitor#visit_tavalue () actual;
        !masks

      (* Real endpoint projectors prove identity and masks, never runtime ownership. *)
      (* Original roots bind declaration coordinates. Actual roots prove supplied storage. *)
      method private endpoint_projectors (owner : abs) (witnesses : call_endpoint_witnesses) =
        let regions = owner.regions.owned in
        let projectors = ref [] in
        let actual_masks = ref [] in
        let add ((from_input, original, actual) as root_row) sv_id full_ty =
          let mask =
            RegionId.Set.inter regions (ty_regions ctx.type_ctx.type_infos full_ty)
          in
          if not (RegionId.Set.is_empty mask) then
            [%classert] span
              (let matched = List.exists (RegionId.Set.equal mask) !actual_masks in
               let () =
                 if not matched then (
                   try
                     let exception Diagnostic_limit in
                     let output = Buffer.create 8192 in
                     let omitted_types = ref 0 in
                     let omitted_sets = ref 0 in
                     let omitted_walks = ref 0 in
                     let omitted_descriptors = ref 0 in
                     let bytes = ref 0 in
                     let emit text =
                       let size = String.length text in
                       if size > 32512 - !bytes then raise Diagnostic_limit;
                       bytes := !bytes + size;
                       Buffer.add_string output text
                     in
                     let integer label value = emit (label ^ "=" ^ string_of_int value ^ "\n") in
                     let set label regions =
                       let count = RegionId.Set.cardinal regions in
                       integer (label ^ "-count") count;
                       if count > 128 then (incr omitted_sets; integer (label ^ "-omitted") count)
                       else (
                         emit (label ^ "={");
                         RegionId.Set.iter (fun key -> emit (RegionId.to_string key ^ ",")) regions;
                         emit "}\n")
                     in
                     let parameters label parameters =
                       let count = TypeVarId.Set.cardinal parameters in
                       integer (label ^ "-count") count;
                       if count > 32 then (incr omitted_sets; integer (label ^ "-omitted") count)
                       else (
                         emit (label ^ "={");
                         TypeVarId.Set.iter (fun key -> emit (TypeVarId.to_string key ^ ",")) parameters;
                         emit "}\n")
                     in
                     let check_type ty =
                       let nodes = ref 0 in
                       let rec visit depth ty =
                         incr nodes;
                         if depth > 12 || !nodes > 64 then raise Diagnostic_limit;
                         match ty with
                         | TAdt tref ->
                             let args = tref.generics in
                             if List.length args.regions > 16 || List.length args.types > 16
                                || args.const_generics <> [] || args.trait_refs <> [] then
                               raise Diagnostic_limit;
                             List.iter (visit (depth + 1)) args.types
                         | TRef (_, child, _) -> visit (depth + 1) child
                         | TLiteral _ | TVar _ -> ()
                         | _ -> raise Diagnostic_limit
                       in
                       visit 0 ty
                     in
                     let raw_type label ty =
                       emit (label ^ ":\n");
                       match (try check_type ty; true with Diagnostic_limit -> false) with
                       | false -> incr omitted_types; emit "raw-type-omitted-before-render\n"
                       | true ->
                           let written = ref 0 in
                           let write text start length =
                             if length > 4096 - !written || length > 32512 - !bytes then
                               raise Diagnostic_limit;
                             written := !written + length;
                             bytes := !bytes + length;
                             Buffer.add_substring output text start length
                           in
                           let formatter = Format.make_formatter write (fun () -> ()) in
                           (try
                              Types.pp_ty formatter ty;
                              Format.pp_print_flush formatter ()
                            with Diagnostic_limit ->
                              incr omitted_types);
                           emit "\n";
                           let summaries =
                             object
                               inherit [_] iter_ty as super
                               method! visit_TAdt env tref =
                                 (match tref.id with
                                 | TAdtId id ->
                                     emit ("nominal-id=" ^ TypeDeclId.to_string id ^ "\n");
                                     let info = TypeDeclId.Map.find id ctx.type_ctx.type_infos in
                                     set "stored-regions" info.stored_regions;
                                     set "metadata-regions" info.metadata_regions;
                                     parameters "stored-types" info.stored_type_params;
                                     parameters "metadata-types" info.metadata_type_params
                                 | _ -> ());
                                 super#visit_TAdt env tref
                             end
                           in
                           summaries#visit_ty () ty
                     in
                     let nodes = ref 0 in
                     let preflight =
                       object
                         inherit [_] iter_tavalue as super
                         method! visit_ty _ _ = ()
                         method! visit_tavalue depth (value : tavalue) =
                           incr nodes;
                           if depth > 12 || !nodes > 128 then raise Diagnostic_limit;
                           check_type value.ty;
                           super#visit_tavalue (depth + 1) value
                         method! visit_tvalue depth (value : tvalue) =
                           incr nodes;
                           if depth > 12 || !nodes > 128 then raise Diagnostic_limit;
                           check_type value.ty;
                           super#visit_tvalue (depth + 1) value
                         method! visit_tevalue depth (value : tevalue) =
                           incr nodes;
                           if depth > 12 || !nodes > 128 then raise Diagnostic_limit;
                           check_type value.ty;
                           super#visit_tevalue (depth + 1) value
                         method! visit_eproj depth proj =
                           incr nodes;
                           if depth > 12 || !nodes > 128 then raise Diagnostic_limit;
                           super#visit_eproj (depth + 1) proj
                         method! visit_aproj depth proj =
                           incr nodes;
                           if depth > 12 || !nodes > 128 then raise Diagnostic_limit;
                           super#visit_aproj (depth + 1) proj
                         method! visit_abstract_shared_borrow depth borrow =
                           incr nodes;
                           if depth > 12 || !nodes > 128 then raise Diagnostic_limit;
                           super#visit_abstract_shared_borrow (depth + 1) borrow
                         method! visit_symbolic_proj _ (proj : symbolic_proj) = check_type proj.proj_ty
                         method! visit_symbolic_value _ (value : symbolic_value) = check_type value.sv_ty
                         method! visit_msymbolic_value _ (value : symbolic_value) = check_type value.sv_ty
                         method! visit_ended_proj_borrow_meta _ meta = check_type meta.given_back.sv_ty
                         method! visit_mvalue _ _ = ()
                       end
                     in
                     emit ("owner=" ^ AbsId.to_string owner.abs_id ^ "\n");
                     set "owner-owned" regions;
                     emit ("from-input=" ^ string_of_bool from_input ^ "\n");
                     let rec row_index index remaining = function
                       | [] -> emit "root-row-not-found\n"
                       | row :: _ when row == root_row -> integer "root-row" index
                       | _ when remaining = 0 -> integer "root-row-scan-omitted-lower-bound" 1
                       | _ :: rest -> row_index (index + 1) (remaining - 1) rest
                     in
                     row_index 0 4096 witnesses.roots;
                     emit ("failed-endpoint=" ^ SymbolicValueId.to_string sv_id ^ "\n");
                     set "failed-declaration-mask" mask;
                     raw_type "failed-declaration-type" full_ty;
                     raw_type "original-root-type" original.ty;
                     raw_type "actual-root-type" actual.ty;
                     (try
                        preflight#visit_tavalue 0 original;
                        preflight#visit_tavalue 0 actual;
                        let visited = ref 0 in
                        let descriptors = ref 0 in
                        let walk =
                          object (walk)
                            inherit [_] iter_tavalue as super
                            method! visit_ty _ _ = ()
                            method! visit_mvalue _ _ = ()
                            method! visit_mconsumed_symb _ _ = ()
                            method! visit_mgiven_back_symb _ _ = ()
                            method private point (side, path, depth, effective) tag =
                              incr visited;
                              if !visited > 128 || depth > 12 then raise Diagnostic_limit;
                              let path = path ^ "/" ^ tag ^ "[" ^ string_of_int !visited ^ "]" in
                              if String.length path > 1024 then raise Diagnostic_limit;
                              emit ("path=" ^ path ^ "\n");
                              (side, path, depth + 1, effective)
                            method private transport env (transport : carrier_coordinate_transport) =
                              let side, path, depth, _ = walk#point env "transport" in
                              incr descriptors;
                              if !descriptors > 8 then (
                                incr omitted_descriptors;
                                raise Diagnostic_limit);
                              emit ("receiver-id=" ^ SymbolicValueId.to_string transport.receiver.sv_id ^ "\n");
                              emit ("current-id=" ^ SymbolicValueId.to_string transport.current.sv_id ^ "\n");
                              set "receiver-mask" transport.receiver_regions;
                              set "current-mask" transport.current_regions;
                              raw_type "receiver-type" transport.receiver.proj_ty;
                              raw_type "current-type" transport.current.sv_ty;
                              (side, path, depth, transport.current_regions)
                            method! visit_ATransportedValue env transport child =
                              walk#visit_tavalue (walk#transport env transport) child
                            method! visit_ATransportedProj env transport child =
                              walk#visit_aproj (walk#transport env transport) child
                            method! visit_ETransportedValue env transport child =
                              walk#visit_tevalue (walk#transport env transport) child
                            method! visit_ETransportedProj env transport child =
                              walk#visit_eproj (walk#transport env transport) child
                            method! visit_tevalue env (value : tevalue) =
                              super#visit_tevalue (walk#point env "evalue") value
                            method! visit_eproj env proj =
                              super#visit_eproj (walk#point env "expression-projector") proj
                            method! visit_borrow_id env id =
                              ignore (walk#point env "borrow-id");
                              emit ("borrow-id=" ^ BorrowId.to_string id ^ "\n")
                            method! visit_loan_id env id =
                              ignore (walk#point env "loan-id");
                              emit ("loan-id=" ^ BorrowId.to_string id ^ "\n")
                            method! visit_shared_borrow_id env id =
                              ignore (walk#point env "shared-borrow-id");
                              emit ("shared-borrow-id=" ^ SharedBorrowId.to_string id ^ "\n")
                            method! visit_symbolic_value_id env id =
                              ignore (walk#point env "endpoint-id");
                              emit ("endpoint-id=" ^ SymbolicValueId.to_string id ^ "\n")
                            method! visit_tavalue env (value : tavalue) =
                              let ((side, _, _, effective) as env) = walk#point env "avalue" in
                              let contributes = side && self#actual_endpoint_masks regions value <> [] in
                              if contributes then (
                                emit "actual-contributing-node\n";
                                emit ("node-kind=" ^ (match value.value with
                                  | AAdt _ -> "AAdt" | ALoan _ -> "ALoan"
                                  | ABorrow _ -> "ABorrow" | ASymbolic _ -> "ASymbolic"
                                  | ATransportedValue _ -> "ATransportedValue"
                                  | AIgnored _ -> "AIgnored") ^ "\n");
                                raw_type "node-type" value.ty;
                                set "recorded-owner-selected" (RegionId.Set.inter regions
                                  (ty_regions ctx.type_ctx.type_infos value.ty));
                                set "effective-owned" effective;
                                set "effective-selected" (RegionId.Set.inter effective
                                  (ty_regions ctx.type_ctx.type_infos value.ty)));
                              super#visit_tavalue env value
                            method! visit_aproj env proj =
                              super#visit_aproj (walk#point env "projector") proj
                            method! visit_symbolic_proj env (proj : symbolic_proj) =
                              let side, path, _, effective = walk#point env "symbolic-projector" in
                              emit ("endpoint-id=" ^ SymbolicValueId.to_string proj.sv_id ^ "\n");
                              if not side && proj.sv_id = sv_id && proj.proj_ty = full_ty then
                                emit ("failing-declaration-path=" ^ path ^ "\n");
                              raw_type "endpoint-type" proj.proj_ty;
                              set "endpoint-effective-owned" effective;
                              set "endpoint-owner-selected" (RegionId.Set.inter regions
                                (ty_regions ctx.type_ctx.type_infos proj.proj_ty));
                              set "endpoint-effective-selected" (RegionId.Set.inter effective
                                (ty_regions ctx.type_ctx.type_infos proj.proj_ty))
                            method! visit_symbolic_value env (value : symbolic_value) =
                              let _, _, _, effective = walk#point env "symbolic-value" in
                              emit ("symbolic-value-id=" ^ SymbolicValueId.to_string value.sv_id ^ "\n");
                              raw_type "symbolic-value-type" value.sv_ty;
                              set "symbolic-owner-selected" (RegionId.Set.inter regions
                                (ty_regions ctx.type_ctx.type_infos value.sv_ty));
                              set "symbolic-effective-owned" effective;
                              set "symbolic-effective-selected" (RegionId.Set.inter effective
                                (ty_regions ctx.type_ctx.type_infos value.sv_ty))
                            method! visit_msymbolic_value_id env id =
                              ignore (walk#point env "ended-projector");
                              emit ("ended-projector-id=" ^ SymbolicValueId.to_string id ^ "\n")
                            method! visit_msymbolic_value env (value : symbolic_value) = walk#visit_symbolic_value env value
                            method! visit_ended_proj_borrow_meta env meta =
                              walk#visit_symbolic_value env meta.given_back
                          end
                        in
                        walk#visit_tavalue (false, "original", 0, regions) original;
                        walk#visit_tavalue (true, "actual", 0, regions) actual
                      with Diagnostic_limit -> incr omitted_walks);
                     Buffer.add_string output
                       ("omitted-types=" ^ string_of_int !omitted_types
                        ^ " omitted-sets=" ^ string_of_int !omitted_sets
                        ^ " omitted-walk-tails-lower-bound=" ^ string_of_int !omitted_walks
                        ^ " omitted-descriptors-lower-bound=" ^ string_of_int !omitted_descriptors ^ "\n");
                     (try Printf.eprintf "Endpoint row failure operands:\n%s\n%!" (Buffer.contents output)
                      with _ -> ())
                   with _ ->
                     (try Printf.eprintf "Endpoint row diagnostic unavailable.\n%!" with _ -> ()))
               in
               matched)
              (lazy ("A declaration endpoint has no matching actual storage mask: "
               ^ ty_to_string ctx full_ty ^ "\nactual masks: "
               ^ Print.list_to_string RegionId.Set.show !actual_masks));
          projectors := (from_input, sv_id, full_ty, mask) :: !projectors
        in
        let live from_input (proj : symbolic_proj) =
          add from_input proj.sv_id proj.proj_ty
        in
        let rec collect from_input ty = function
          (* ```ocaml *)
          | ATransportedProj (transport, child) ->
              collect from_input transport.current.sv_ty child
          (* ``` *)
          | AProjLoans loans ->
              live from_input loans.proj;
              children from_input loans.consumed;
              children from_input loans.borrows
          | AProjBorrows borrows ->
              live from_input borrows.proj;
              children from_input borrows.loans
          | AEndedProjLoans loans ->
              add from_input loans.proj ty;
              children from_input loans.consumed;
              children from_input loans.borrows
          | AEndedProjBorrows borrows ->
              add from_input borrows.mvalues.consumed ty;
              (* The actual return transition supplies its own endpoint type. *)
              add from_input borrows.mvalues.given_back.sv_id
                borrows.mvalues.given_back.sv_ty;
              children from_input borrows.loans
          | APendingLoans _ | APendingSymbolicLoans _ ->
              [%craise] span "A pending shell cannot be a declaration endpoint witness"
          | AEmpty -> ()
        and children from_input = function
          | [] -> ()
          | ((meta : mconsumed_symb), child) :: rest ->
              collect from_input meta.proj_ty child;
              children from_input rest
        in
        let visitor =
          object
            inherit [_] iter_tavalue as super
            method! visit_ty _ _ = ()

            method! visit_tavalue from_input value =
              match value.value with
              | ASymbolic (_, proj) -> collect from_input value.ty proj
              | _ -> super#visit_tavalue from_input value

            method! visit_symbolic_proj from_input proj = live from_input proj
          end
        in
        List.iter
          (fun ((_, original, actual) as root_row) ->
            actual_masks := self#actual_endpoint_masks regions actual;
            visitor#visit_tavalue root_row original)
          witnesses.roots;
        List.iteri
          (fun row ((proj : symbolic_proj), mask, (actual : tavalue)) ->
            [%sanity_check] span
              (List.exists
                 (fun ((source : symbolic_value), _) ->
                   source.sv_id = proj.sv_id
                   && ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings source.sv_ty
                      = ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings proj.proj_ty)
                 witnesses.expansions);
            [%classert] span
              (* ```ocaml *)
              (let exact =
                 proj.proj_ty = actual.ty
                 && ty_is_rty ctx.type_ctx.type_infos actual.ty
                 && RegionId.Set.equal mask
                      (RegionId.Set.inter regions
                         (ty_regions ctx.type_ctx.type_infos proj.proj_ty))
               in
               if not exact then begin
                 let stored = ty_regions ctx.type_ctx.type_infos proj.proj_ty in
                 let raw label text =
                   let shown = Stdlib.min 65536 (String.length text) in
                   Printf.eprintf "%s bytes=%d shown=%d:\n%s\n%!"
                     label (String.length text) shown (String.sub text 0 shown)
                 in
                 Printf.eprintf
                   "Projection failure tuple: owner=%s kind=%s row=%d source=%s type-equal=%b actual-is-rty=%b mask-equal=%b recorded=%s owned=%s stored=%s selected=%s\n%!"
                   (AbsId.to_string owner.abs_id) (show_abs_kind owner.kind) row
                   (SymbolicValueId.to_string proj.sv_id)
                   (proj.proj_ty = actual.ty)
                   (ty_is_rty ctx.type_ctx.type_infos actual.ty)
                   (RegionId.Set.equal mask (RegionId.Set.inter regions stored))
                   (RegionId.Set.show mask) (RegionId.Set.show regions)
                   (RegionId.Set.show stored)
                   (RegionId.Set.show (RegionId.Set.inter regions stored));
                 raw "raw projector" (show_symbolic_proj proj);
                 raw "raw actual type" (Types.show_ty actual.ty);
                 raw "raw actual value" (show_tavalue actual);
                 let summary label ty =
                   match ty with
                   | TAdt { id = TAdtId id; _ } ->
                       let info = TypeDeclId.Map.find id ctx.type_ctx.type_infos in
                       Printf.eprintf
                         "Projection nominal summary: %s id=%s stored-regions=%s metadata-regions=%s stored-types=%s metadata-types=%s\n%!"
                         label (TypeDeclId.to_string id)
                         (RegionId.Set.show info.stored_regions)
                         (RegionId.Set.show info.metadata_regions)
                         (TypeVarId.Set.show info.stored_type_params)
                         (TypeVarId.Set.show info.metadata_type_params)
                   | _ -> ()
                 in
                 let summaries label ty =
                   summary (label ^ "/outer") ty;
                   match ty with
                   | TAdt tref ->
                       Option.iter (summary (label ^ "/type0"))
                         (List.nth_opt tref.generics.types 0);
                       Option.iter (summary (label ^ "/type1"))
                         (List.nth_opt tref.generics.types 1)
                   | _ -> ()
                 in
                 summaries "projector" proj.proj_ty;
                 summaries "actual" actual.ty
               end;
               exact)
              (* ``` *)
              (lazy ("An authentic projection changes its exact source view: "
               ^ ty_to_string ctx proj.proj_ty ^ "\nactual: "
               ^ ty_to_string ctx actual.ty ^ "\nrecorded mask: "
               ^ RegionId.Set.show mask ^ "\nowner: "
               ^ RegionId.Set.show regions));
            let actual_masks = self#actual_endpoint_masks regions actual in
            if not (RegionId.Set.is_empty mask) then
              [%sanity_check] span
                (List.exists (RegionId.Set.equal mask) actual_masks))
          witnesses.projections;
        !projectors

      method private check_pending_endpoints (slot : symbolic_pending_slot) endpoints =
        let from_input =
          match slot.ancestor_path with
          | root_returned :: _ -> not root_returned
          | [] -> [%craise] span "A pending carrier needs a root side"
        in
        [%sanity_check] span
          (List.exists
             (fun (input, sv_id, full_ty, mask) ->
               input = from_input
               && sv_id = slot.root_sv_id
               && full_ty = slot.proj_ty
               && RegionId.Set.equal slot.proj_regions mask)
             endpoints)

      method private check_pending_declaration slot paths =
        [%sanity_check] span
          (List.exists (fun (_, path) -> path = slot.ancestor_path) paths);
        match
          List.find_opt
            (fun (key, _) -> equal_symbolic_pending_slot key slot)
            slot_protocols
        with
        | None -> slot_protocols <- (slot, paths) :: slot_protocols
        | Some (_, previous) -> [%sanity_check] span (previous = paths)

      method private check_pending_scope (owner : abs) (scope : call_pending_scope) =
        check_symbolic_pending_slot span ctx owner.regions.owned
          scope.slot.proj_ty scope.slot;
        self#check_pending_declaration scope.slot
          (RegionsHierarchy.back_positions_raw_paths scope.positions);
        self#check_pending_endpoints scope.slot
          (self#endpoint_projectors owner scope.witnesses)

(*
```ocaml
*)
      method private check_physical_scope (owner : abs) (scope : physical_input_scope) =
(*
```ocaml
*)
        check_physical_input_scope span ctx owner scope;
        let slot = scope.physical_slot in
        let root = slot.origin.transport_root in
(*
```
*)
        [%sanity_check] span
          (List.exists
            (fun (from_input, id, ty, mask) ->
              not from_input && id = root.sv_id && ty = root.sv_ty
              && RegionId.Set.equal mask slot.proj_regions)
            (self#endpoint_projectors owner scope.witnesses))
(*
```
*)

      method! visit_ECallProtocol abs positions body =
        let previous_paths = declared_raw_paths in
        let previous_values = scoped_evalues in
        declared_raw_paths <-
          Some (RegionsHierarchy.back_positions_raw_paths positions);
        scoped_evalues <- EvalueTbl.create 16;
        super#visit_ECallProtocol abs positions body;
        declared_raw_paths <- previous_paths;
        scoped_evalues <- previous_values

      method! visit_ECallEndpoints abs witnesses body =
        let owner : abs = Option.get abs in
        let previous_endpoints = endpoint_scope in
        let previous_values = scoped_evalues in
        endpoint_scope <-
          Some (self#endpoint_projectors owner witnesses);
        scoped_evalues <- EvalueTbl.create 16;
        super#visit_ECallEndpoints abs witnesses body;
        endpoint_scope <- previous_endpoints;
        scoped_evalues <- previous_values

      method! visit_abs _ abs =
        (* Validate shared expressions once per owner and declaration scope.
           Concrete metadata and saved environments stay opaque, so occurrence
           counts remain exact. Projection validity depends on the owner's
           regions and the nearest retained call protocol. Endpoint witnesses
           prove the exact root identity, type, and owned-storage mask. *)
        EvalueTbl.clear scoped_evalues;
        runtime_pending <- [];
        continuation_pending <- [];
        slot_protocols <- [];
        super#visit_abs (Some abs) abs;
        (* Stored witnesses are checked explicitly, never by the ownership visitor. *)
(*
```ocaml
*)
        List.iter
          (function
            | PendingParameterScope scope -> self#check_pending_scope abs scope
            | PhysicalInputScope scope -> self#check_physical_scope abs scope)
          abs.call_scopes;
(*
```
*)
        [%sanity_check] span
          (List.for_all
             (fun slot ->
               List.exists
                 (fun (scope : call_pending_scope) ->
                   equal_symbolic_pending_slot slot scope.slot)
                 (ValuesUtils.parameter_scopes abs.call_scopes))
             runtime_pending);
        (match abs.cont with
        | None -> ()
        | Some _ ->
            let runtime =
              List.sort_uniq compare_symbolic_pending_slot runtime_pending
            in
            let continuation =
              List.sort_uniq compare_symbolic_pending_slot continuation_pending
            in
            [%classert] span
              (List.length runtime = List.length continuation
              && List.for_all2 equal_symbolic_pending_slot runtime continuation)
              (lazy ("Pending runtime and continuation slots differ:\n"
                ^ abs_to_string span ctx abs)))

      method! visit_tevalue abs value =
        if not (EvalueTbl.mem scoped_evalues value) then (
          EvalueTbl.add scoped_evalues value ();
          (match value.value with
          | ECallProtocol (_, body) | ECallEndpoints (_, body) ->
              [%sanity_check] span (value.ty = body.ty)
          | ESymbolic (_, EPendingSymbolicLoans slot) ->
              let owner = Option.get abs in
              check_symbolic_pending_slot span ctx owner.regions.owned value.ty slot;
              (match endpoint_scope with
              | None ->
                  [%craise] span "A pending carrier needs its actual declaration endpoints"
              | Some endpoints -> self#check_pending_endpoints slot endpoints);
              (match declared_raw_paths with
              | None ->
                  [%craise] span "A pending carrier needs its declared call protocol"
              | Some paths -> self#check_pending_declaration slot paths)
          | _ -> ());
          super#visit_tevalue abs value)

      method! visit_VSymbolic _ sv =
        if is_static_ty sv.sv_ty then
          static_svs := SymbolicValueId.Set.add sv.sv_id !static_svs;
        add_env_sv sv.sv_id

      method! visit_abstract_shared_borrow abs asb =
        let abs = Option.get abs in
        match asb with
        | AsbBorrow _ -> ()
        | AsbProjReborrows proj ->
            add_aproj_borrows abs.abs_id abs.regions.owned proj true

      method! visit_aproj abs aproj =
        if aproj_depth > 0 then
          (match aproj with
          | APendingLoans _ | APendingSymbolicLoans _ ->
              [%craise] span "A pending dependency cannot be a historical projector child"
          | _ -> ());
        (let abs = Option.get abs in
         match aproj with
         | AProjLoans { proj; _ } ->
             add_aproj_loans abs.abs_id abs.regions.owned proj
         | AProjBorrows { proj; _ } ->
             add_aproj_borrows abs.abs_id abs.regions.owned proj false
         | APendingSymbolicLoans slot ->
             runtime_pending <- slot :: runtime_pending;
             pending_slots := slot :: !pending_slots
         | ATransportedProj _ | APendingLoans _ | AEndedProjLoans _ | AEndedProjBorrows _ | AEmpty ->
             ());
        aproj_depth <- aproj_depth + 1;
        super#visit_aproj abs aproj;
        aproj_depth <- aproj_depth - 1

      method! visit_eproj abs eproj =
        if eproj_depth > 0 then
          (match eproj with
          | EPendingLoans _ | EPendingSymbolicLoans _ ->
              [%craise] span "A pending dependency cannot be a historical projector child"
          | _ -> ());
        (let abs = Option.get abs in
         match eproj with
         | EProjLoans { proj; consumed = _; borrows = _ }
         | EProjBorrows { proj; loans = _ } ->
             (* Symbolic projections in evalues should be over values which contain
                mutable borrows/loans *)
             if
               not
                 (ty_has_mut_borrow_for_region_in_set ctx.type_ctx.type_infos
                    abs.regions.owned proj.proj_ty)
             then (
               [%ldebug
                 "Abs contains evalues with no mutable borrows/loans:\n"
                 ^ abs_to_string span ctx abs ^ "\n\nProblematic eproj:\n"
                 ^ eproj_to_string ctx eproj];
               [%internal_error] span)
         | EPendingSymbolicLoans slot ->
             continuation_pending <- slot :: continuation_pending
         | ETransportedProj _ | EPendingLoans _ | EEndedProjLoans _ | EEndedProjBorrows _ | EEmpty ->
             ());
        eproj_depth <- eproj_depth + 1;
        super#visit_eproj abs eproj;
        eproj_depth <- eproj_depth - 1
    end
  in
  (* Collect the information *)
  obj#visit_eval_ctx None ctx;
  (* A dependency can outlive its root value, but any retained root stays exact. *)
  if !pending_slots <> [] then (
    let roots =
      object
        inherit [_] iter_eval_ctx
        method! visit_ty _ _ = ()
        method! visit_abs_cont _ _ = ()

        method! visit_VSymbolic _ sv =
          List.iter
            (fun (slot : symbolic_pending_slot) ->
              if slot.root_sv_id = sv.sv_id then
                [%sanity_check] span (sv.sv_ty = slot.proj_ty))
            !pending_slots
      end
    in
    roots#visit_eval_ctx () ctx);

  (* Check *)
  let check_info id info =
    [%ldebug
      "checking info (sid: "
      ^ SymbolicValueId.to_string id
      ^ "):\n" ^ sv_info_to_string ctx info];
    if info.aproj_borrows = [] && info.aproj_loans = [] then ()
    else if info.aproj_loans = [] && SymbolicValueId.Set.mem id !static_svs then
      (* Borrows of static data, lent by the static storage *)
      ()
    else (
      (* The borrows of a symbolic value must come from somewhere: if we find a
         symbolic values with live borrows (and particular a projection over the
         borrows of a symbolic value), there *must* be a projection over its loans
         (otherwise its borrows don't have corresponding loans). *)
      if info.aproj_borrows <> [] && info.aproj_loans = [] then
        [%craise] span
          ("Symbolic borrows of s@"
          ^ SymbolicValueId.to_string id
          ^ " have no lender:\n" ^ sv_info_to_string ctx info);
      (* Check that the loan projections don't intersect and compute
         the normalized union of those projections *)
      let aproj_loans =
        List.map
          (fun (linfo : proj_loans_info) ->
            normalize_proj_ty ctx.type_ctx.type_infos linfo.regions linfo.proj_ty)
          info.aproj_loans
      in

      (* There should be at least one loan proj *)
      let loan_proj_union =
        match aproj_loans with
        | [] -> [%internal_error] span
        | loan_proj_union :: aproj_loans ->
            List.fold_left
              (fun loan_proj_union proj_ty ->
                norm_proj_tys_union span ctx loan_proj_union proj_ty)
              loan_proj_union aproj_loans
      in

      (* Consuming projections remain linear. Shared reborrow observations may
         overlap each other, but each must be covered by the lenders and must
         not overlap a consuming projection of the same value which moves
         mutable borrows. A consuming projection whose projected regions only
         hold shared borrows moves copyable references: an observation of
         the same borrows (for instance the child abstraction of a call which
         took a shared borrow of the value, and which outlives the end of the
         outer borrow) stays valid. *)
      let union_of (keep : proj_borrows_info -> bool) =
        List.fold_left
          (fun union (binfo : proj_borrows_info) ->
            if binfo.as_shared_value || not (keep binfo) then union
            else
              let proj_ty = normalize_proj_ty ctx.type_ctx.type_infos binfo.regions binfo.proj_ty in
              Some
                (match union with
                | None -> proj_ty
                | Some union -> norm_proj_tys_union span ctx union proj_ty))
          None info.aproj_borrows
      in
      let consuming_union = union_of (fun _ -> true) in
      let linear_union =
        union_of (fun binfo ->
            ty_has_mut_borrow_for_region_in_set ctx.type_ctx.type_infos
              binfo.regions binfo.proj_ty)
      in
      Option.iter
        (fun proj_ty ->
          [%sanity_check] span
            (norm_proj_ty_contains span ctx loan_proj_union proj_ty))
        consuming_union;
      List.iter
        (fun (binfo : proj_borrows_info) ->
          if binfo.as_shared_value then (
            let proj_ty = normalize_proj_ty ctx.type_ctx.type_infos binfo.regions binfo.proj_ty in
            [%sanity_check] span
              (norm_proj_ty_contains span ctx loan_proj_union proj_ty);
            Option.iter
              (fun linear ->
                if norm_proj_tys_intersect span ctx linear proj_ty then
                  [%craise] span
                    ("A shared observation overlaps a consuming projection of \
                      s@"
                    ^ SymbolicValueId.to_string id
                    ^ ":\n" ^ sv_info_to_string ctx info))
              linear_union))
        info.aproj_borrows)
  in

  M.iter check_info !infos

(** Check that all abstraction ids are unique *)
let check_unique_abs_ids (span : Meta.span) (ctx : eval_ctx) : unit =
  let ids = ref AbsId.Set.empty in
  env_iter_abs
    (fun (abs : abs) ->
      [%sanity_check] span (not (AbsId.Set.mem abs.abs_id !ids));
      ids := AbsId.Set.add abs.abs_id !ids)
    ctx.env

let check_invariants (span : Meta.span) (ctx : eval_ctx) : unit =
  if !Config.sanity_checks then (
    [%ltrace
      "Checking invariants in context:\n"
      ^ eval_ctx_to_string ~span:(Some span) ctx];
    check_loans_borrows_relation_invariant span ctx;
    check_borrowed_values_invariant span ctx;
    check_typing_invariant span ctx true;
    check_symbolic_values span ctx;
    check_unique_abs_ids span ctx)

let check_typing_invariant (span : Meta.span) (ctx : eval_ctx) : unit =
  if !Config.sanity_checks then check_typing_invariant span ctx true

let opt_type_check_abs (span : Meta.span) (ctx : eval_ctx) (abs : abs) : unit =
  if !Config.sanity_checks then
    (check_typing_invariant_visitor span ctx false)#visit_abs None abs

let opt_type_check_absl (span : Meta.span) (ctx : eval_ctx) (absl : abs list) :
    unit =
  if !Config.sanity_checks then
    List.iter
      ((check_typing_invariant_visitor span ctx false)#visit_abs None)
      absl
