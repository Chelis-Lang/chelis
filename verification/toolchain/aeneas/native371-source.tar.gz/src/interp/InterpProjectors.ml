open Types
open Values
open Contexts
open TypesUtils
open ValuesUtils
open InterpUtils
open InterpBorrowsCore

(** The local logger *)
let log = Logging.projectors_log

(*
```ocaml
*)
let physical_input_paths _span ctx owned ancestors root_ty =
  let infos = ctx.type_ctx.type_infos in
  let mask ty = RegionId.Set.inter owned (ty_regions infos ty) in
  let selected = mask root_ty in
  let rec walk seen path ty =
    match ty with
    | TRef (region, payload, RMut) ->
        let returned_at = path @ [PDeref] in
        let here =
          if region_in_set region ancestors
             && RegionId.Set.equal selected (mask payload)
          then [returned_at] else [] in
        here @ walk seen returned_at payload
    | TAdt { id = TTuple; generics } ->
        fields seen path None generics.types
    | TAdt { id = TAdtId id; generics } when not (TypeDeclId.Set.mem id seen) ->
        let declaration = TypeDeclId.Map.find id ctx.type_ctx.type_decls in
        let seen = TypeDeclId.Set.add id seen in
        let variant variant_id =
          fields seen path variant_id
            (Substitute.type_decl_get_instantiated_field_types
               declaration variant_id generics) in
        (match declaration.kind with
        | Struct _ -> variant None
        | Enum variants ->
            List.concat (List.mapi
              (fun index _ -> variant (Some (VariantId.of_int index))) variants)
        | _ -> [])
    | _ -> []
  and fields seen path variant_id children =
    List.concat (List.mapi
      (fun index ty -> walk seen (path @ [PField (variant_id, index)]) ty)
      children)
  in
  if RegionId.Set.is_empty selected then []
  else walk TypeDeclId.Set.empty [] root_ty
(*
```
*)

(** Static storage owns the static positions of a symbolic value.
    A generic call can shorten their lifetimes but cannot transfer ownership.
    Other positions retain the caller's regions and their original lenders. *)
let project_static_region source target =
  if source = RStatic then RStatic else target

let rec project_static source target =
  match (source, target) with
  | TAdt source, TAdt target ->
      let generics =
        {
          target.generics with
          regions = List.map2 project_static_region source.generics.regions target.generics.regions;
          types = List.map2 project_static source.generics.types target.generics.types;
        }
      in
      TAdt { target with generics }
  | TRef (sr, source, _), TRef (tr, target, kind) ->
      TRef (project_static_region sr tr, project_static source target, kind)
  | TArray (source, _), TArray (target, len) ->
      TArray (project_static source target, len)
  | TSlice source, TSlice target -> TSlice (project_static source target)
  | _ -> target

let symbolic_borrow_projection_ty span ctx source target =
  let needs_static =
    compare_rtys span ctx false ( || )
      (fun source target -> source = RStatic && target <> RStatic)
      source target
  in
  if not needs_static then target else project_static source target

(** [ty] shouldn't contain erased regions *)
let rec apply_proj_borrows_on_shared_borrow (span : Meta.span) (ctx : eval_ctx)
    (regions : RegionId.Set.t) (v : tvalue) (ty : ty) : abstract_shared_borrows
    =
  let ty =
    match v.value with
    | VSymbolic s when ty_has_regions_in_set ctx.type_ctx.type_infos regions ty ->
        symbolic_borrow_projection_ty span ctx s.sv_ty ty
    | _ -> ty
  in
  [%ldebug
    "- ty: " ^ ty_to_string ctx ty ^ "\n- v.ty: " ^ ty_to_string ctx v.ty];
  (* Sanity check - TODO: move those elsewhere (here we perform the check at every
   * recursive call which is a bit overkill...) *)
  let ety = ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings ty in
  [%sanity_check] span (ty_is_rty ctx.type_ctx.type_infos ty && ety = v.ty);
  (* Project - if there are no regions from the abstraction in the type, return [_] *)
  if not (ty_has_regions_in_set ctx.type_ctx.type_infos regions ty) then []
  else
    match (v.value, ty) with
    | VLiteral _, TLiteral _ ->
        [%ldebug "literals"];
        []
    | VAdt adt, TAdt { id; generics } ->
        [%ldebug "adts"];
        (* Retrieve the types of the fields *)
        let field_types =
          ctx_adt_get_instantiated_field_types span ctx id adt.variant_id
            generics
        in

        (* Project over the field values *)
        let fields_types = List.combine adt.fields field_types in
        let proj_fields =
          List.map
            (fun (fv, fty) ->
              apply_proj_borrows_on_shared_borrow span ctx regions fv fty)
            fields_types
        in
        List.concat proj_fields
    | VBottom, _ -> [%craise] span "Unreachable"
    | VBorrow bc, TRef (r, ref_ty, kind) ->
        [%ldebug "borrow"];
        (* Retrieve the bid of the borrow and the asb of the projected borrowed value *)
        let bid, asb =
          (* Not in the set: dive *)
          match (bc, kind) with
          | VMutBorrow (bid, bv), RMut ->
              (* Apply the projection on the borrowed value *)
              let asb =
                apply_proj_borrows_on_shared_borrow span ctx regions bv ref_ty
              in
              (bid, asb)
          | VSharedBorrow (bid, _), RShared ->
              (* Lookup the shared value *)
              let ek = ek_all in
              let sv = ctx_lookup_loan span ek bid ctx in
              let asb =
                match sv with
                | _, Concrete (VSharedLoan (_, sv))
                | _, Abstract (ASharedLoan (_, _, sv, _)) ->
                    apply_proj_borrows_on_shared_borrow span ctx regions sv
                      ref_ty
                | _ -> [%craise] span "Unexpected"
              in
              (bid, asb)
          | VReservedMutBorrow _, _ ->
              [%craise] span
                "Can't apply a proj_borrow over a reserved mutable borrow"
          | _ -> [%craise] span "Unreachable"
        in
        let asb =
          (* Check if the region is in the set of projected regions (note that
           * we never project over static regions) *)
          if region_in_set r regions then
            let sid' = ctx.fresh_shared_borrow_id () in
            AsbBorrow (bid, sid') :: asb
          else asb
        in
        asb
    | VLoan (VSharedLoan (_, sv)), _ ->
        (* A concrete loan wrapper protects storage; it is not another
           reference occurrence in the type being projected. *)
        apply_proj_borrows_on_shared_borrow span ctx regions sv ty
    | VLoan (VMutLoan _), _ -> [%craise] span "Unreachable"
    | VSymbolic s, _ ->
        [%ldebug "symbolic"];
        (* Check that the projection doesn't contain ended regions *)
        [%sanity_check] span
          (not
             (projections_intersect span ctx ctx.ended_regions s.sv_ty regions
                ty));
        let proj : symbolic_proj = { sv_id = s.sv_id; proj_ty = ty } in
        [ AsbProjReborrows proj ]
    | VAdt adt, TArray (ty, _) ->
        List.flatten
          (List.map
             (fun v ->
               apply_proj_borrows_on_shared_borrow span ctx regions v ty)
             adt.fields)
    | _ -> [%craise] span ("Unexpected value: " ^ tvalue_to_string ctx v)

let rec apply_proj_borrows (span : Meta.span) (check_symbolic_no_ended : bool)
    (ctx : eval_ctx) (regions : RegionId.Set.t) (v : tvalue) (ty : rty) :
    tavalue =
  let ty =
    match v.value with
    | VSymbolic s when ty_has_regions_in_set ctx.type_ctx.type_infos regions ty ->
        symbolic_borrow_projection_ty span ctx s.sv_ty ty
    | _ -> ty
  in
  (* Sanity check - TODO: move this elsewhere (here we perform the check at every
   * recursive call which is a bit overkill...) *)
  let ety = ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings ty in
  [%sanity_check] span (ty_is_rty ctx.type_ctx.type_infos ty && ety = v.ty);
  (* Project - if there are no regions from the abstraction in the type, return [_] *)
  if not (ty_has_regions_in_set ctx.type_ctx.type_infos regions ty) then
    { value = AIgnored (Some v); ty }
  else
    let value : avalue =
      match (v.value, ty) with
      | VLiteral _, TLiteral _ -> AIgnored (Some v)
      | VAdt adt, TAdt { id; generics } ->
          (* Retrieve the types of the fields *)
          let field_types =
            ctx_adt_get_instantiated_field_types span ctx id adt.variant_id
              generics
          in
          (* Project over the field values *)
          let fields_types = List.combine adt.fields field_types in
          let proj_fields =
            List.map
              (fun (fv, fty) ->
                apply_proj_borrows span check_symbolic_no_ended ctx regions fv
                  fty)
              fields_types
          in
          AAdt
            {
              borrow_proj = true;
              variant_id = adt.variant_id;
              fields = proj_fields;
            }
      | VAdt adt, TArray (elem_ty, _) ->
          let proj_fields =
            List.map
              (fun fv ->
                apply_proj_borrows span check_symbolic_no_ended ctx regions fv
                  elem_ty)
              adt.fields
          in
          AAdt
            {
              borrow_proj = true;
              variant_id = adt.variant_id;
              fields = proj_fields;
            }
      | VBottom, _ -> [%craise] span "Unreachable"
      | VBorrow bc, TRef (r, ref_ty, kind) ->
          if
            (* Check if the region is in the set of projected regions (note that
             * we never project over static regions) *)
            region_in_set r regions
          then
            (* In the set *)
            let bc =
              match (bc, kind) with
              | VMutBorrow (bid, bv), RMut ->
                  (* Apply the projection on the borrowed value *)
                  let bv =
                    apply_proj_borrows span check_symbolic_no_ended ctx regions
                      bv ref_ty
                  in
                  AMutBorrow (PNone, bid, bv)
              | VSharedBorrow (bid, sid), RShared ->
                  (* Rem.: we don't need to also apply the projection on the
                     borrowed value, because for as long as the abstraction
                     lives then the shared borrow lives, which means that the
                     whole value is borrowed (and thus immutable).
                     This is not the case if the current borrow is not to be
                     projected to the current abstraction: if this happens,
                     then maybe there are borrows *inside* the shared value
                     which belong to the current abstraction, meaning we
                     need to lookup the shared value and project it (see the
                     other branch of the [if then else]).
                  *)
                  ASharedBorrow (PNone, bid, sid)
              | VReservedMutBorrow _, _ ->
                  [%craise] span
                    "Can't apply a proj_borrow over a reserved mutable borrow"
              | _ -> [%craise] span "Unreachable"
            in
            ABorrow bc
          else
            (* Not in the set: ignore the borrow, but project the borrowed
               value (maybe some borrows *inside* the borrowed value are in
               the region set) *)
            let bc =
              match (bc, kind) with
              | VMutBorrow (bid, bv), RMut ->
                  (* Apply the projection on the borrowed value *)
                  let bv =
                    apply_proj_borrows span check_symbolic_no_ended ctx regions
                      bv ref_ty
                  in
                  (* If the referenced type contains the region, we still need
                   * to remember it *)
                  let opt_bid =
                    if ty_has_regions_in_set ctx.type_ctx.type_infos regions ref_ty then Some bid
                    else None
                  in
                  (* Return *)
                  AIgnoredMutBorrow (opt_bid, bv)
              | VSharedBorrow (bid, _), RShared ->
                  (* Lookup the shared value *)
                  let ek = ek_all in
                  let sv = ctx_lookup_loan span ek bid ctx in
                  let asb =
                    match sv with
                    | _, Concrete (VSharedLoan (_, sv))
                    | _, Abstract (ASharedLoan (_, _, sv, _)) ->
                        apply_proj_borrows_on_shared_borrow span ctx regions sv
                          ref_ty
                    | _ -> [%craise] span "Unexpected"
                  in
                  AProjSharedBorrow (PNone, asb)
              | VReservedMutBorrow _, _ ->
                  [%craise] span
                    "Can't apply a proj_borrow over a reserved mutable borrow"
              | _ -> [%craise] span "Unreachable"
            in
            ABorrow bc
      | VLoan _, _ -> [%craise] span "Unreachable"
      | VSymbolic s, _ ->
          (* Check that the projection doesn't contain already ended regions,
           * if necessary *)
          if check_symbolic_no_ended then (
            let ty1 = s.sv_ty in
            let rset1 = ctx.ended_regions in
            let ty2 = ty in
            let rset2 = regions in
            [%ltrace
              "- ty1: " ^ ty_to_string ctx ty1 ^ "\n- rset1: "
              ^ RegionId.Set.to_string None rset1
              ^ "\n- ty2: " ^ ty_to_string ctx ty2 ^ "\n- rset2: "
              ^ RegionId.Set.to_string None rset2
              ^ "\n"];
            [%sanity_check] span
              (not (projections_intersect span ctx rset1 ty1 rset2 ty2)));
          ASymbolic
            ( PNone,
              AProjBorrows
                { proj = { sv_id = s.sv_id; proj_ty = ty }; loans = [] } )
      | _ ->
          [%ltrace
            "unexpected inputs:\n- input value: "
            ^ tvalue_to_string ~span:(Some span) ctx v
            ^ "\n- proj rty: " ^ ty_to_string ctx ty];
          [%internal_error] span
    in
    { value; ty }

let rec apply_eproj_borrows (span : Meta.span) (check_symbolic_no_ended : bool)
    (ctx : eval_ctx) (regions : RegionId.Set.t) (v : tvalue) (ty : rty) :
    tevalue =
  let ty =
    match v.value with
    | VSymbolic s when ty_has_regions_in_set ctx.type_ctx.type_infos regions ty ->
        symbolic_borrow_projection_ty span ctx s.sv_ty ty
    | _ -> ty
  in
  (* Sanity check - TODO: move this elsewhere (here we perform the check at every
   * recursive call which is a bit overkill...) *)
  let ety = ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings ty in
  [%sanity_check] span (ty_is_rty ctx.type_ctx.type_infos ty && ety = v.ty);
  (* Project - if there are no regions from the abstraction in the type, return [_] *)
  if not (ty_has_regions_in_set ctx.type_ctx.type_infos regions ty) then { value = EIgnored; ty }
  else
    let value : evalue =
      match (v.value, ty) with
      | VLiteral _, TLiteral _ -> EIgnored
      | VAdt adt, TAdt { id; generics } ->
          (* Retrieve the types of the fields *)
          let field_types =
            ctx_adt_get_instantiated_field_types span ctx id adt.variant_id
              generics
          in
          (* Project over the field values *)
          let fields_types = List.combine adt.fields field_types in
          let proj_fields =
            List.map
              (fun (fv, fty) ->
                apply_eproj_borrows span check_symbolic_no_ended ctx regions fv
                  fty)
              fields_types
          in
          (* The value given back to a nominal ADT holding mutable borrows of
             the projected regions is consumed as the whole ADT by the stages
             of the backward functions which receive it at the levels >= 1
             (see [gtranslate_adt_fields]): e.g., a closure capturing
             [&'a Env] and [&'b mut Sink<'r>], passed by value, whose stage
             for ['r] receives the closure given back when ['b] ends. Retain
             the values of its other fields, as [apply_proj_borrows] does
             ([AIgnored (Some _)]) and as
             [apply_eproj_loans_on_symbolic_expansion] does for the loans.
             Outputs treat them as ignored values (see
             [InterpAbs.project_output_at_level]). *)
          let proj_fields =
            match id with
            | TAdtId _
              when ty_has_mut_borrow_for_region_in_set ctx.type_ctx.type_infos
                     regions ty ->
                List.map2
                  (fun (field : tevalue) ((fv, _) : tvalue * rty) ->
                    match field.value with
                    | EIgnored when not (bottom_in_value ctx.type_ctx.type_infos ctx.ended_regions fv)
                      ->
                        mk_evalue ctx.env field.ty fv
                    | _ -> field)
                  proj_fields fields_types
            | _ -> proj_fields
          in
          EAdt
            {
              borrow_proj = true;
              variant_id = adt.variant_id;
              fields = proj_fields;
            }
      | VAdt adt, TArray (elem_ty, _) ->
          let proj_fields =
            List.map
              (fun fv ->
                apply_eproj_borrows span check_symbolic_no_ended ctx regions fv
                  elem_ty)
              adt.fields
          in
          EAdt
            {
              borrow_proj = true;
              variant_id = adt.variant_id;
              fields = proj_fields;
            }
      | VBottom, _ -> [%craise] span "Unreachable"
      | VBorrow bc, TRef (r, ref_ty, kind) ->
          if
            (* Check if the region is in the set of projected regions (note that
             * we never project over static regions) *)
            region_in_set r regions
          then
            (* In the set *)
            match (bc, kind) with
            | VMutBorrow (bid, bv), RMut ->
                (* Apply the projection on the borrowed value *)
                let bv' =
                  apply_eproj_borrows span check_symbolic_no_ended ctx regions
                    bv ref_ty
                in
                EBorrow (EMutBorrow (PNone, bid, bv'))
            | VSharedBorrow (_, _), RShared ->
                (* We do not need to track shared borrows *)
                EIgnored
            | VReservedMutBorrow _, _ ->
                [%craise] span
                  "Can't apply a proj_borrow over a reserved mutable borrow"
            | _ -> [%craise] span "Unreachable"
          else begin
            (* Not in the set: ignore the borrow, but project the borrowed
               value (maybe some borrows *inside* the borrowed value are in
               the region set) *)
            match (bc, kind) with
            | VMutBorrow (bid, bv), RMut ->
                (* Apply the projection on the borrowed value *)
                let bv =
                  apply_eproj_borrows span check_symbolic_no_ended ctx regions
                    bv ref_ty
                in
                (* If the referenced type contains the region, we still need
                 * to remember it *)
                let opt_bid =
                  if ty_has_regions_in_set ctx.type_ctx.type_infos regions ref_ty then Some bid
                  else None
                in
                (* Return *)
                EBorrow (EIgnoredMutBorrow (opt_bid, bv))
            | VSharedBorrow (_, _), RShared ->
                (* We ignore shared borrows *)
                EIgnored
            | VReservedMutBorrow _, _ ->
                [%craise] span
                  "Can't apply a proj_borrow over a reserved mutable borrow"
            | _ -> [%craise] span "Unreachable"
          end
      | VLoan _, _ -> [%craise] span "Unreachable"
      | VSymbolic s, _ ->
          (* Check that the projection doesn't contain already ended regions,
           * if necessary *)
          if check_symbolic_no_ended then (
            let ty1 = s.sv_ty in
            let rset1 = ctx.ended_regions in
            let ty2 = ty in
            let rset2 = regions in
            [%ltrace
              "- ty1: " ^ ty_to_string ctx ty1 ^ "\n- rset1: "
              ^ RegionId.Set.to_string None rset1
              ^ "\n- ty2: " ^ ty_to_string ctx ty2 ^ "\n- rset2: "
              ^ RegionId.Set.to_string None rset2
              ^ "\n"];
            [%sanity_check] span
              (not (projections_intersect span ctx rset1 ty1 rset2 ty2)));
          (* Only introduce a projection if the value contains mutable
             borrows which intersect the current regions *)
          let type_infos = ctx.type_ctx.type_infos in
          if ty_has_mut_borrow_for_region_in_set type_infos regions ty then
            ESymbolic
              ( PNone,
                EProjBorrows
                  { proj = { sv_id = s.sv_id; proj_ty = ty }; loans = [] } )
          else EIgnored
      | _ ->
          [%ltrace
            "unexpected inputs:\n- input value: "
            ^ tvalue_to_string ~span:(Some span) ctx v
            ^ "\n- proj rty: " ^ ty_to_string ctx ty];
          [%internal_error] span
    in
    { value; ty }

let symbolic_expansion_non_borrow_to_value (span : Meta.span)
    (type_infos : TypesAnalysis.type_infos)
    (metadata_bindings : region_metadata_bindings)
    (sv : symbolic_value) (see : symbolic_expansion) : tvalue =
  let ty = ty_erase_regions_with_metadata type_infos metadata_bindings sv.sv_ty in
  let value =
    match see with
    | SeLiteral cv -> VLiteral cv
    | SeAdt (variant_id, fields) ->
        let fields =
          List.map (mk_tvalue_from_symbolic_value type_infos metadata_bindings) fields
        in
        VAdt { variant_id; fields }
    | SeMutRef (_, _) | SeSharedRef (_, _) ->
        [%craise] span "Unexpected symbolic reference expansion"
  in
  { value; ty }

let symbolic_expansion_non_shared_borrow_to_value (span : Meta.span)
    (type_infos : TypesAnalysis.type_infos)
    (metadata_bindings : region_metadata_bindings)
    (sv : symbolic_value) (see : symbolic_expansion) : tvalue =
  match see with
  | SeMutRef (bid, bv) ->
      let ty = ty_erase_regions_with_metadata type_infos metadata_bindings sv.sv_ty in
      let bv = mk_tvalue_from_symbolic_value type_infos metadata_bindings bv in
      let value = VBorrow (VMutBorrow (bid, bv)) in
      { value; ty }
  | SeSharedRef (_, _) ->
      [%craise] span "Unexpected symbolic shared reference expansion"
  | _ -> symbolic_expansion_non_borrow_to_value span type_infos metadata_bindings sv see

(** Apply (and reduce) a projector over loans to a value.

    Remark: we need the evaluation context only to access the type declarations.

    TODO: detailed comments. See [apply_proj_borrows] *)
let apply_proj_loans_on_symbolic_expansion (span : Meta.span)
    (regions : RegionId.Set.t) (see : symbolic_expansion) (original_sv_ty : rty)
    (proj_ty : rty) (ctx : eval_ctx) : tavalue =
  (* Sanity check: if we have a proj_loans over a symbolic value, it should
   * contain regions which we will project *)
  (* ```ocaml *)
  if !Config.print_error_diagnostics
     && not (ty_has_regions_in_set ctx.type_ctx.type_infos regions original_sv_ty)
  then
    Printf.eprintf "Loan expansion source proof:\n- regions: %s\n- original type: %s\n- projection type: %s\n- expansion: %s\n- source bindings: %s\n%!"
      (RegionId.Set.to_string None regions)
      (Types.show_ty original_sv_ty)
      (Types.show_ty proj_ty)
      (Values.show_symbolic_expansion see)
      (carrier_metadata_bindings ctx.metadata_bindings);
  (* ``` *)
  [%sanity_check] span (ty_has_regions_in_set ctx.type_ctx.type_infos regions original_sv_ty);
  (* Match *)
  let (value, ty) : avalue * ty =
    match (see, proj_ty) with
    | SeLiteral lit, TLiteral _ ->
        ( AIgnored (Some { value = VLiteral lit; ty = original_sv_ty }),
          original_sv_ty )
    | SeAdt (variant_id, fields), TAdt { id = adt_id; generics } ->
        let nominal = match adt_id with TAdtId _ -> true | _ -> false in
        (* Project over the field values *)
        let field_types =
          ctx_adt_get_instantiated_field_types span ctx adt_id variant_id
            generics
        in
        (* ```ocaml *)
        let fields =
          List.map2
            (fun sv field_ty ->
              let field =
                mk_aproj_loans_value_from_symbolic_value ctx.type_ctx.type_infos
                  ctx.metadata_bindings regions sv field_ty
              in
              if nominal && field.ty <> field_ty then { field with ty = field_ty }
              else field)
            fields field_types
        in
        ( AAdt { borrow_proj = false; variant_id; fields },
          if nominal then proj_ty else original_sv_ty )
        (* ``` *)
    | SeMutRef (bid, spc), TRef (r, ref_ty, RMut) ->
        (* Sanity check *)
        [%sanity_check] span (projection_masks_equal span ctx regions spc.sv_ty ref_ty);
        (* Apply the projector to the borrowed value *)
        let child_av =
          mk_aproj_loans_value_from_symbolic_value ctx.type_ctx.type_infos ctx.metadata_bindings regions spc ref_ty
        in
        let child_av =
          if child_av.ty = ref_ty then child_av
          else { child_av with ty = ref_ty }
        in
        (* Check if the region is in the set of projected regions (note that
         * we never project over static regions) *)
        if region_in_set r regions then
          (* In the set: keep *)
          (ALoan (AMutLoan (PNone, bid, child_av)), ref_ty)
        else
          (* Not in the set: ignore *)
          (* If the type of the referenced value contains the region, we still
             need to remember it *)
          let opt_bid =
            if ty_has_regions_in_set ctx.type_ctx.type_infos regions ref_ty then Some bid else None
          in
          (ALoan (AIgnoredMutLoan (PNone, opt_bid, child_av)), ref_ty)
    | SeSharedRef (bid, spc), TRef (r, ref_ty, RShared) ->
        (* Sanity check *)
        [%sanity_check] span (projection_masks_equal span ctx regions spc.sv_ty ref_ty);
        (* Apply the projector to the borrowed value *)
        let child_av =
          mk_aproj_loans_value_from_symbolic_value ctx.type_ctx.type_infos ctx.metadata_bindings regions spc ref_ty
        in
        let child_av =
          if child_av.ty = ref_ty then child_av
          else { child_av with ty = ref_ty }
        in
        (* Check if the region is in the set of projected regions (note that
         * we never project over static regions) *)
        if region_in_set r regions then
          (* In the set: keep *)
          let shared_value = mk_tvalue_from_symbolic_value ctx.type_ctx.type_infos ctx.metadata_bindings spc in
          (ALoan (ASharedLoan (PNone, bid, shared_value, child_av)), ref_ty)
        else
          (* Not in the set: ignore *)
          (ALoan (AIgnoredSharedLoan child_av), ref_ty)
    | _ -> [%craise] span "Unreachable"
  in
  { value; ty }

let apply_eproj_loans_on_symbolic_expansion (span : Meta.span)
    (regions : RegionId.Set.t) (see : symbolic_expansion) (original_sv_ty : rty)
    (proj_ty : rty) (ctx : eval_ctx) : tevalue =
  (* Sanity check: if we have a proj_loans over a symbolic value, it should
   * contain regions which we will project *)
  [%sanity_check] span (ty_has_regions_in_set ctx.type_ctx.type_infos regions original_sv_ty);
  let type_infos = ctx.type_ctx.type_infos in
  (* Match *)
  let (value, ty) : evalue * ty =
    match (see, proj_ty) with
    | SeLiteral _, TLiteral _ -> (EIgnored, original_sv_ty)
    | SeAdt (variant_id, see_fields), TAdt { id = adt_id; generics } ->
        (* Project over the field values *)
        let field_types =
          ctx_adt_get_instantiated_field_types span ctx adt_id variant_id
            generics
        in
        let fields =
          List.map2
            (mk_eproj_loans_value_from_symbolic_value type_infos regions)
            see_fields field_types
        in
        (* A projected mutable loan inside a nominal ADT is consumed as the
           whole ADT by the backward function which receives it (see
           [gtranslate_adt_fields]): its other fields must be supplied, even
           though that function only reads the projected ones. Retain their
           symbolic values as meta-values, exactly as the corresponding
           avalue projection does ([AIgnored (Some _)]). A tuple is rebuilt as
           a whole when it is a field of such an ADT (e.g. the [(usize, &'a mut
           T)] of an [Option] returned by [Enumerate::next]), so its fields are
           retained too; where a tuple is filtered instead (its own fields
           consumed separately), [einput_to_texpr] ignores the meta-values.
           Boxes are the identity: they keep ignoring those fields. *)
        let fields =
          match adt_id with
          | (TAdtId _ | TTuple)
            when ty_has_mut_borrow_for_region_in_set type_infos regions proj_ty
            ->
              List.map2
                (fun (field : tevalue) (sv : symbolic_value) ->
                  match field.value with
                  | EIgnored ->
                      mk_evalue [] field.ty (mk_tvalue_from_symbolic_value ctx.type_ctx.type_infos ctx.metadata_bindings sv)
                  | _ -> field)
                fields see_fields
          | _ -> fields
        in
        (EAdt { borrow_proj = false; variant_id; fields }, original_sv_ty)
    | SeMutRef (bid, spc), TRef (r, ref_ty, RMut) ->
        (* Sanity check *)
        [%sanity_check] span (projection_masks_equal span ctx regions spc.sv_ty ref_ty);
        (* Apply the projector to the borrowed value *)
        let child_av =
          mk_eproj_loans_value_from_symbolic_value type_infos regions spc ref_ty
        in
        let child_av =
          if child_av.ty = ref_ty then child_av
          else { child_av with ty = ref_ty }
        in
        (* Check if the region is in the set of projected regions (note that
         * we never project over static regions) *)
        if region_in_set r regions then
          (* In the set: keep *)
          (ELoan (EMutLoan (PNone, bid, child_av)), ref_ty)
        else
          (* Not in the set: ignore *)
          (* If the type of the referenced value contains the region, we still
             need to remember it *)
          let opt_bid =
            if ty_has_regions_in_set ctx.type_ctx.type_infos regions ref_ty then Some bid else None
          in
          (ELoan (EIgnoredMutLoan (PNone, opt_bid, child_av)), ref_ty)
    | SeSharedRef (_, _), TRef (_, _, RShared) ->
        (* We ignore shared borrows/loans in the abstraction expressions *)
        (EIgnored, proj_ty)
    | _ -> [%craise] span "Unreachable"
  in
  { value; ty }

(** [ty] shouldn't have erased regions *)
let apply_proj_borrows_on_input_value (span : Meta.span) (ctx : eval_ctx)
    (regions : RegionId.Set.t) (v : tvalue) (ty : rty) : tavalue =
  [%ltrace "- v: " ^ tvalue_to_string ctx v ^ "\n- ty: " ^ ty_to_string ctx ty];
  [%sanity_check] span (ty_is_rty ctx.type_ctx.type_infos ty);
  let check_symbolic_no_ended = true in
  apply_proj_borrows span check_symbolic_no_ended ctx regions v ty

let apply_eproj_borrows_on_input_value (span : Meta.span) (ctx : eval_ctx)
    (regions : RegionId.Set.t) (v : tvalue) (ty : rty) : tevalue =
  [%ltrace "- v: " ^ tvalue_to_string ctx v ^ "\n- ty: " ^ ty_to_string ctx ty];
  [%sanity_check] span (ty_is_rty ctx.type_ctx.type_infos ty);
  let check_symbolic_no_ended = true in
  apply_eproj_borrows span check_symbolic_no_ended ctx regions v ty

let symbolic_pending_inputs _span ctx regions positions from_input roots =
  let aligned = RegionsHierarchy.back_positions_raw_paths positions in
  let slots = ref [] in
  (*
```ocaml
  *)
  let witnesses ty =
    List.concat_map
      (fun (route, value_path) ->
        List.map (fun sides -> (sides, value_path))
          (RegionsHierarchy.back_route_sides route))
      (RegionsHierarchy.back_ty_routes_with_paths_for_regions
         ctx.type_ctx.type_decls ctx.type_ctx.type_infos
         (fun region -> region_in_set region regions) ty)
  in
  let register prefix pm (proj : symbolic_proj) =
    let proj_regions =
      RegionId.Set.inter regions (ty_regions ctx.type_ctx.type_infos proj.proj_ty)
    in
    if not (RegionId.Set.is_empty proj_regions) then
      List.iter
        (fun (route, value_path) ->
          if route <> [] then
            match List.assoc_opt (from_input, prefix @ route) aligned with
            | Some ancestor_path
              when snd (RegionsHierarchy.back_path_raw_stage ancestor_path) ->
                let slot : symbolic_pending_slot =
                  {
                    root_sv_id = proj.sv_id;
                    proj_ty = proj.proj_ty;
                    proj_regions;
                    ancestor_path;
                    value_path;
                  }
                in
                slots := (pm, slot) :: !slots
            | _ -> ())
        (witnesses proj.proj_ty)
        (*
```
        *)
  in
  let visitor =
    object (self)
      inherit [_] iter_tavalue
      method! visit_ASymbolic prefix pm = function
        | AProjBorrows { proj; _ } | AProjLoans { proj; _ } ->
            register prefix pm proj
        | _ -> ()
      method! visit_AIgnoredMutBorrow prefix _ child =
        self#visit_tavalue (prefix @ [ false ]) child
      method! visit_AMutBorrow prefix _ _ child =
        self#visit_tavalue prefix child
      method! visit_ASharedBorrow _ _ _ _ = ()
      method! visit_AProjSharedBorrow _ _ _ = ()
      method! visit_AIgnoredMutLoan prefix _ _ child =
        self#visit_tavalue (prefix @ [ false ]) child
      method! visit_AMutLoan prefix _ _ child =
        self#visit_tavalue prefix child
      method! visit_ty _ _ = ()
    end
  in
  List.iter (visitor#visit_tavalue []) roots;
  List.sort_uniq Stdlib.compare !slots
