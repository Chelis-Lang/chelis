open Values
open Types
open Contexts

(** End removable shared-loan tags, retaining their payload and branch
    ownership. *)
val eliminate_shared_loans : Meta.span -> eval_ctx -> eval_ctx

(** Merge an abstraction into another abstraction in a context.

    This function is similar to {!InterpBorrows.merge_into_abstraction}.

    Parameters:
    - [loop_id]
    - [abs_kind]
    - [can_end]
    - [with_abs_conts]
    - [ctx]
    - [aid0]
    - [aid1] *)
val merge_into_first_abstraction :
  Meta.span ->
  abs_kind ->
  can_end:bool ->
  recoverable:bool ->
  with_abs_conts:bool ->
  eval_ctx ->
  abs_id ->
  abs_id ->
  eval_ctx * abs_id

val convert_fresh_dummy_values_to_abstractions :
  Meta.span -> abs_kind -> DummyVarId.Set.t -> eval_ctx -> eval_ctx

(** Reduce a context to simplify it, by merging abstractions together for
    instance.

    We use this to compute fixed-points: this is equivalent to a widening
    operation. Only abstract borrower slots trigger a loan/borrow merge.
    Concrete borrows in retained shared payloads remain edges between their
    owners: merging cannot discharge them without changing the payload's value.

    **IMPORTANT**: the big difference between [reduce] and [collapse] is that
    [collapse] operates on an environment with markers (the goal is to eliminate
    them) while [reduce] operates on an environment without markers.

    Arguments:
    - config
    - span
    - sequence: used to save the sequence of merged abstractions, in reverse
      order (the last merge is pushed to the front of the list).
    - loop: the context of the loop synthesis, whose abstractions keep the
      level-1 outputs of their calls (see {!InterpJoinCore.loop_level_outputs})
    - with_abs_conts
    - fresh abs kind
    - fixed abstraction ids
    - ctx *)
val reduce_ctx :
  config ->
  Meta.span ->
  ?diagnostic:InterpAbs.merge_diagnostics ->
  ?sequence:(abs_id * abs_id * abs_id) list ref option ->
  ?loop:bool ->
  with_abs_conts:bool ->
  abs_kind ->
  AbsId.Set.t ->
  DummyVarId.Set.t ->
  eval_ctx ->
  eval_ctx

type borrow_or_proj =
  | Borrow of borrow_id
  | Proj of RegionId.Set.t * symbolic_proj
  | SharedProj of RegionId.Set.t * abstract_shared_borrows
and replay_diagnostic = {
  replay_index : int;
  replay_recorded : abs_id * abs_id * abs_id;
  replay_resolved_left : abs_id;
  replay_resolved_right : abs_id;
  replay_normalized_left : abs_id;
  replay_normalized_right : abs_id;
  replay_normalization_begin : int;
  replay_normalization_end : int;
  replay_case : string;
  replay_result : abs_id option;
  replay_map_before : abs_id AbsId.Map.t;
  replay_map_after : abs_id AbsId.Map.t;
  replay_before : eval_ctx;
  replay_after : eval_ctx;
}
and replay_diagnostics = {
  replay_native : InterpAbs.merge_diagnostics;
  mutable replay_count : int;
  replay_records : replay_diagnostic option array;
}

(** Collapse an environment, merging the duplicated borrows/loans.

    This function simply calls {!collapse_ctx} with the proper merging
    functions.

    We do this because when we join environments, we may introduce duplicated
    loans and borrows. See the explanations for {!join_ctxs}.

    Retained shared payloads are matched in their original branch order; any
    abstractions created to own nested borrows or loans remain in the context
    and participate in subsequent reduction and collapse steps until stable.
    Complementary markers in the same abstraction are reconciled without
    composing its continuation with itself, strictly reducing its markers.
    Same-branch shared borrows supplied by a loan inside the same abstraction
    are discharged without composing the continuation again. Retained payload
    loan tags are removed only when no borrowers remain anywhere in the context;
    their concrete values and all externally used ownership survive.

    Arguments:
    - config
    - span
    - sequence: used to save the sequence of merged abstractions, in reverse
      order (the last merge is pushed to the front of the list).
    - the shared borrows we had to introduce in region abstractions to eliminate
      markers (if we find a marked borrow and its corresponding loan doesn't
      have a marker, it's safe to remove the marker because it is tantamount to
      adding a shared borrow in the other environment, which we're allowed to
      do). The last borrow to add is pushed to the front of the list (the order
      is important, like with the abstraction merges, because it controls the
      offsets at which to introduce the borrows). Copies of nested shared
      borrows are inserted at the containing top-level slot, without changing
      the original aggregate's layout.
    - untouched: the abstractions the join kept unchanged in both contexts
      (see {!InterpJoin.join_ctxs}); the final canonicalization of the
      marker-free components leaves those of the calls with a staged backward
      function alone (see {!InterpJoinCore.untouched_staged_call_abs_ids})
    - preserved_abs_ids: unchanged source owners whose partition a match replay
      must retain during reduction
    - loop: see {!reduce_ctx}
    - loop id
    - fixed ids
    - with_abs_conts
    - ctx *)
val collapse_ctx :
  config ->
  Meta.span ->
  ?diagnostic:InterpAbs.merge_diagnostics ->
  ?sequence:(abs_id * abs_id * abs_id) list ref option ->
  ?shared_borrows_seq:
    (abs_id * int * proj_marker * borrow_or_proj * ty) list ref option ->
  ?untouched:AbsId.Set.t ->
  ?loop:bool ->
  ?preserved_abs_ids:AbsId.Set.t ->
  abs_kind ->
  recoverable:bool ->
  with_abs_conts:bool ->
  eval_ctx ->
  eval_ctx

(** It can happen that we want to join then collapse two environments, then
    apply the exact same sequence of merges resulting from the collapse
    operation to one of the two original environments (before the join).

    [collapse_ctx] allows saving the sequence of merges which have been
    performed for this reason. [collapse_ctx_no_markers_following_sequence] can
    then use this sequence and apply it on the left or right environment. Note
    that this environment *should not have markers*.

    Also note that the sequence of merges the function expects should have the
    merges ordered from the first to perform to the last. This means that if it
    was computed by, e.g., [collapse_ctx], one should reverse the sequence
    before calling [collapse_ctx_no_markers_following_sequence]. [loop]: see
    {!reduce_ctx}. *)
val collapse_ctx_no_markers_following_sequence :
  Meta.span ->
  ?diagnostic:replay_diagnostics ->
  ?loop:bool ->
  (abs_id * abs_id * abs_id) list ->
  (abs_id * int * proj_marker * borrow_or_proj * ty) list ->
  abs_kind ->
  with_abs_conts:bool ->
  eval_ctx ->
  eval_ctx
