open Types
open Values
open Contexts
open ValuesUtils
open TypesUtils
open InterpUtils
open InterpBorrowsCore
open InterpBorrows

(** The local logger *)
let log = Logging.abs_log

(* Ignored mutable payload slots must outlive the current payload's temporary
   regions: replacing that payload must not turn a later giveback into bottom. *)
let unowned_rty_of_ety span (ctx : eval_ctx) (ty : ety) : rty * region_metadata_bindings =
  [%sanity_check] span (ty_is_ety ctx.type_ctx.type_infos ty);
  if ty_is_rty ctx.type_ctx.type_infos ty then (ty, ctx.metadata_bindings)
  else
    let _, ty, bindings =
      ty_refresh_regions_with_metadata (Some span) ctx.type_ctx.type_infos
        ~region_is_live:(Some (fun _ -> false))
        ctx.fresh_region_id ctx.metadata_bindings ty
    in
    (ty, bindings)

(* A retained payload remains an operational value: its nested borrows are not
   also projected as abstract borrows. Reify only erased type annotations with
   distinct, unowned witnesses. In particular, do not identify them with the
   outer loan's owned region or turn them into static lifetimes. Symbolic
   payloads already carry their actual region type, which must be preserved. *)
let retained_value_rty span (ctx : eval_ctx) (v : tvalue) : rty * region_metadata_bindings =
  match (value_strip_shared_loans v).value with
  | VSymbolic sv -> (sv.sv_ty, ctx.metadata_bindings)
  | _ -> unowned_rty_of_ety span ctx v.ty

let shared_borrow_referent_ty span (ctx : eval_ctx) bid : ty * region_metadata_bindings =
  match snd (ctx_lookup_loan span ek_all bid ctx) with
  | Concrete (VSharedLoan (_, sv)) -> retained_value_rty span ctx sv
  | Abstract (ASharedLoan (_, _, _, child)) -> (child.ty, ctx.metadata_bindings)
  | _ -> [%internal_error] span

(* Move the whole shared-loan payload into one abstraction. Recursively
   extracting its inner loans would duplicate the inner borrows between their
   extracted loan and the residual outer payload. The residual value returned
   here is used only in an opaque continuation snapshot, never as a second
   operational owner. *)
let shared_loan_to_avalue span (ctx : eval_ctx) pm (rid : RegionId.id) (v : tvalue) : tavalue * tvalue * region_metadata_bindings =
  match v.value with
  | VLoan (VSharedLoan (bid, sv)) ->
      let rty, bindings = retained_value_rty span ctx sv in
      let ty = mk_ref_ty (RVar (Free rid)) rty RShared in
      let ignored = mk_aignored span ctx.type_ctx.type_infos rty None in
      let value = ALoan (ASharedLoan (pm, bid, sv, ignored)) in
      ({ value; ty }, sv, bindings)
  | _ -> [%internal_error] span

let convert_value_to_input_avalues (span : Meta.span) (ctx : eval_ctx)
    (pm : proj_marker) (v : tvalue) (rid : RegionId.id) (rty : rty) :
    tavalue list * tevalue * region_metadata_bindings * RegionId.Set.t =
  let metadata_bindings = ref ctx.metadata_bindings in
  let owned_regions = ref (RegionId.Set.singleton rid) in
  let rec to_input (v : tvalue) (rty : rty) : tavalue list * tevalue =
    let ctx = ctx_with_metadata_bindings ctx !metadata_bindings in
    let () =
      [%sanity_check] span
        (ty_erase_regions_with_metadata ctx.type_ctx.type_infos !metadata_bindings rty = v.ty)
    in
    match v.value with
    | VLiteral _ -> ([], mk_evalue ctx.env rty v)
    | VAdt { variant_id; fields } ->
        let field_types =
          match rty with
          | TAdt { id; generics } ->
              ctx_adt_get_instantiated_field_types span ctx id variant_id
                generics
          | _ -> [%internal_error] span
        in
        let avll, fields = List.split (List.map2 to_input fields field_types) in
        let value = EAdt { borrow_proj = false; variant_id; fields } in
        (List.flatten avll, { value; ty = rty })
    | VBottom -> ([], mk_ebottom rty)
    | VBorrow (VSharedBorrow (bid, sid)) ->
        let _, ref_ty, kind = ty_as_ref rty in
        [%sanity_check] span (kind = RShared);
        let av : tavalue =
          {
            value = ABorrow (ASharedBorrow (pm, bid, sid));
            ty = mk_ref_ty (RVar (Free rid)) ref_ty RShared;
          }
        in
        ([ av ], mk_evalue ctx.env rty v)
    | VBorrow (VMutBorrow _ | VReservedMutBorrow _) ->
        [%craise] span "Nested mutable borrows are not supported yet"
    | VLoan lc -> (
        match lc with
        | VSharedLoan _ ->
            let av, sv, bindings = shared_loan_to_avalue span ctx pm rid v in
            let () = metadata_bindings := bindings in
            let _, rty, _ = ty_as_ref av.ty in
            ([ av ], mk_evalue ctx.env rty sv)
        | VMutLoan bid ->
            let ty = mk_ref_ty (RVar (Free rid)) rty RMut in
            let av : tavalue =
              {
                value = ALoan (AMutLoan (pm, bid, mk_aignored span ctx.type_ctx.type_infos rty None));
                ty;
              }
            in
            let input : tevalue =
              { value = ELoan (EMutLoan (pm, bid, mk_eignored rty)); ty }
            in
            ([ av ], input))
    | VSymbolic sv ->
        [%cassert] span
          (not (ty_has_mut_borrows ctx.type_ctx.type_infos sv.sv_ty))
          "Nested mutable borrows are not supported yet";
        (* The payload leaves the operational context. Keep its shared
           ownership live independently of the captured forward value. *)
        let fresh_region =
          if ty_has_stored_metadata ctx.type_ctx.type_infos sv.sv_ty then
            ctx.fresh_region_id
          else fun () -> rid
        in
        let regions, proj_ty, updated_bindings =
          ty_refresh_regions_with_metadata (Some span) ctx.type_ctx.type_infos
            ~region_is_live:(Some (fun r -> not (RegionId.Set.mem r ctx.ended_regions)))
            fresh_region !metadata_bindings sv.sv_ty
        in
        let () = metadata_bindings := updated_bindings in
        let () =
          owned_regions :=
            List.fold_left (fun regions rid -> RegionId.Set.add rid regions)
              !owned_regions regions
        in
        let avalues : tavalue list =
          if regions = [] then []
          else
            [
              {
                value =
                  ASymbolic
                    ( pm,
                      AProjBorrows
                        { proj = { sv_id = sv.sv_id; proj_ty }; loans = [] } );
                ty = proj_ty;
              };
            ]
        in
        (avalues, mk_evalue ctx.env rty v)
  in
  let avalues, input = to_input v rty in
  (avalues, input, !metadata_bindings, !owned_regions)

let convert_value_to_abstractions (span : Meta.span) (abs_kind : abs_kind)
    ~(can_end : bool) (ctx : eval_ctx) (v : tvalue) : abs list * region_metadata_bindings =
  [%ltrace tvalue_to_string ctx v];
  (* Convert the value to a list of avalues *)
  let absl = ref [] in
  let metadata_bindings = ref ctx.metadata_bindings in
(*
```ocaml
*)
  let push_abs ?abs_id ?owned_regions ?(parents = AbsId.Set.empty)
(*
```ocaml
*)
      ?(call_scopes = []) (r_id : RegionId.id) (avalues : tavalue list)
(*
```
*)
      (output : tevalue option) (input : tevalue option) : unit =
(*
```
*)
    let ctx = ctx_with_metadata_bindings ctx !metadata_bindings in
    let owned = match owned_regions with
      | Some regions -> regions
      | None -> RegionId.Set.singleton r_id
    in
    if avalues = [] then ()
    else begin
      (* There should be output and input expressions *)
      let output = [%unwrap_with_span] span output "Unexpected error" in
      let input = [%unwrap_with_span] span input "Unexpected error" in
(*
```ocaml
*)
      let input = List.fold_left
        (fun body scope -> { body with value = ECallEndpoints (ValuesUtils.call_scope_witnesses scope, body) })
        input call_scopes in
(*
```
*)
      (* Create the abs - note that we keep the order of the avalues as it is
         (unlike the environments) *)
      [%ldebug
        "avalues:\n"
        ^ String.concat "\n"
            (List.map
               (fun (v : tavalue) ->
                 tavalue_to_string ctx v ^ " : " ^ ty_to_string ctx v.ty)
               avalues)];
      let abs =
(*
```ocaml
*)
        { abs_id = (match abs_id with Some id -> id | None -> ctx.fresh_abs_id ()); kind = abs_kind; can_end; parents; regions = { owned }; ended_subabs = AbsLevelSet.empty; avalues; cont = Some { output = Some output; input = Some input }; call_scopes }
(*
```
*)
      in
      [%ldebug "abs:\n" ^ abs_to_string span ctx abs];
      Invariants.opt_type_check_abs span ctx abs;
      (* Add to the list of abstractions *)
      absl := abs :: !absl
    end
  in

(*
```ocaml
*)
  let nested_source lid =
    let sources = ref [] in
    AbsId.Map.iter
      (fun _ owner ->
        let obj = object
          inherit [_] iter_abs_with_levels as super
          method incr_level level = level + 1
          method! visit_tavalue level value =
            match value.value with
            | ABorrow (AMutBorrow (_, actual, child)) when actual = lid ->
                sources := (owner, level, value.ty, child.ty) :: !sources
            | _ -> super#visit_tavalue level value
        end in
        obj#visit_abs 0 owner)
      (ctx_get_abs ctx);
    let owner, level, reference_ty, payload_ty =
      match List.sort_uniq Stdlib.compare !sources with
      | [ source ] -> source
      | [] -> [%craise] span "A nested conversion lacks its actual loan borrower"
      | _ -> [%craise] span "A nested conversion has different loan borrowers"
    in
    let scopes = List.concat_map
      (fun (_, abstraction) -> parameter_scopes abstraction.call_scopes)
      (AbsId.Map.bindings (ctx_get_abs ctx)) in
    let matches = List.concat_map
      (fun (scope : call_pending_scope) ->
        List.concat_map
          (fun (origin : carrier_origin) ->
            List.filter_map
              (fun (proof : call_input_correspondence) ->
(* ```ocaml *)
                if proof.input_origin <> origin || proof.input_root <> origin.transport_root then None
(* ``` *)

                else match InterpBorrows.call_input_borrow_reference span ctx proof lid with
                | Some (reference, payload) when reference = reference_ty
                  && payload = payload_ty ->
(* ```ocaml *)
                    let relative = match proof.input_source.sv_ty with
                      | TRef (_, _, RMut) -> [ PDeref ]
                      | _ -> [] in
                    let path = proof.input_source_path @ relative in
                    let source_ty = InterpBorrows.input_return_route_ty ctx
                      origin.transport_root.sv_ty path in
                    let selected_ty = Option.bind
                      (InterpBorrows.call_input_actual_path proof path)
                      (InterpBorrows.input_return_route_ty ctx proof.instantiated_input) in
(* ``` *)
                    (match source_ty, selected_ty with
                    | Some source, Some selected when selected = payload_ty
                      && projection_metadata_types_equal ctx
                        (RegionId.Map.of_list proof.input_relation) source payload_ty ->
                        (match origin.source_role with
                        | FunctionInputOrigin _ ->
                            InterpBorrowsCore.check_function_input_interface
                              span ctx scope.witnesses origin
                              (ctx_lookup_abs ctx origin.source_owner)
                        | OrdinaryCallOutputOrigin declaration ->
                            let canonical = ctx_lookup_abs ctx origin.source_owner in
                            [%cassert] span
                              (canonical.kind = FunCall (declaration.output_call, origin.region_group)
                               && declaration.instantiated_output = origin.original_root.sv_ty)
                              "A nested conversion changes its declared output source");
                        Some (scope, origin, proof, path)
                    | _ -> None)
                | _ -> None)
              scope.witnesses.input_correspondences)
          scope.witnesses.carrier_origins)
      scopes in
    let paths = List.sort_uniq Stdlib.compare
      (List.map (fun (_, origin, proof, path) -> origin, proof, path) matches) in
    [%cassert] span (List.length paths <= 1)
      "A nested conversion has different complete source declarations";
    (owner, level, reference_ty, payload_ty, matches)
  in
(*
```
*)
  (* Convert a value to abstractions *)
  let rec to_abs (v : tvalue) (rty : rty) : unit =
    let ctx = ctx_with_metadata_bindings ctx !metadata_bindings in
    match v.value with
    | VLiteral _ | VBottom -> ()
    | VAdt { variant_id; fields } ->
        let field_types =
          match rty with
          | TAdt { id; generics } ->
              ctx_adt_get_instantiated_field_types span ctx id variant_id generics
          | _ -> [%internal_error] span
        in
        List.iter2 to_abs fields field_types
    | VBorrow bc -> (
        let region, _, kind = ty_as_ref rty in
        match bc with
        | VSharedBorrow (bid, sid) ->
            (* Push a region abstraction for this borrow *)
            let rid = ctx.fresh_region_id () in
            let ref_ty, bindings = shared_borrow_referent_ty span ctx bid in
            let () = metadata_bindings := bindings in
            let () =
              match region with
              | RVar (Free original)
                when RegionId.Map.find_opt original bindings <> Some MetadataFresh ->
                  let source = metadata_region bindings region in
                  metadata_bindings := RegionId.Map.add rid (MetadataSource source) bindings
              | _ -> ()
            in
            let ty = TRef (RVar (Free rid), ref_ty, kind) in
            let value = ABorrow (ASharedBorrow (PNone, bid, sid)) in
            let value : tavalue = { value; ty } in
            let ev_out = Some (mk_etuple ~borrow_proj:true []) in
            let ev_in = Some (mk_etuple ~borrow_proj:false []) in
            push_abs rid [ value ] ev_out ev_in
        | VMutBorrow (bid, bv) ->
(* ```ocaml *)
            (match bv.value with
             | VLoan (VMutLoan loan) ->
                 Printf.eprintf
                   "Nested mutable conversion source:\nouter borrower: %s\ninner loan: %s\ncomplete operand: %s\n%!"
                   (BorrowId.to_string bid) (BorrowId.to_string loan)
                   (show_tvalue v);
                 List.iter
                   (function
                     | EAbs source ->
                         Printf.eprintf
                           "Nested conversion declaration:\nowner: %s\nvalues: %s\nscopes: %s\n%!"
                           (AbsId.to_string source.abs_id)
                           (String.concat "\n" (List.map show_tavalue source.avalues))
                           (String.concat "\n" (List.map
                             (fun scope -> ValuesUtils.call_scope_slot_to_string scope ^ "\n" ^ String.concat "\n" (List.map show_carrier_origin (ValuesUtils.call_scope_witnesses scope).carrier_origins))
                             source.call_scopes))
                     | _ -> ())
                   ctx.env
             | _ -> ());
(* ``` *)
(*
```ocaml
*)
            let source = match bv.value with
              | VLoan (VMutLoan lid)
                when ty_has_borrows (Some span) ctx.type_ctx.type_infos bv.ty ->
                  let source = match lookup_borrow span ek_all (UMut lid) ctx with
                    | Concrete (VMutBorrow (actual, _)) when actual = lid -> None
                    | Abstract (AMutBorrow (_, actual, _)) when actual = lid ->
                        Some (nested_source lid)
                    | _ -> [%craise] span "A nested conversion changes its actual loan borrower" in
                  Some (lid, source)
              | _ -> None in
            let child_regions, ref_ty, updated_bindings =
              match source with
              | Some (_, Some (_, _, _, payload_ty, _)) ->
                  ty_refresh_regions_with_metadata (Some span)
                    ctx.type_ctx.type_infos ctx.fresh_region_id !metadata_bindings payload_ty
              | Some (_, None) ->
                  ty_refresh_regions_with_metadata (Some span)
                    ctx.type_ctx.type_infos ctx.fresh_region_id !metadata_bindings bv.ty
              | None ->
                  let ty, bindings = unowned_rty_of_ety span ctx bv.ty in
                  ([], ty, bindings)
            in
            metadata_bindings := updated_bindings;
(*
```
*)
            let ctx = ctx_with_metadata_bindings ctx updated_bindings in
            (* Create an avalue to push - note that we use [AIgnore] for the inner avalue *)
            let rid = ctx.fresh_region_id () in
            let ty = TRef (RVar (Free rid), ref_ty, kind) in
            let av : tavalue =
              let ignored = mk_aignored span ctx.type_ctx.type_infos ref_ty None in
              let av = ABorrow (AMutBorrow (PNone, bid, ignored)) in
              { value = av; ty }
            in
            (* Create the output expression *)
            let output : tevalue =
              let ignored = mk_eignored ref_ty in
              let value = EBorrow (EMutBorrow (PNone, bid, ignored)) in
              { value; ty }
            in
            (* Recursively explore the expression to look for shared loans
               and create the input expression *)
            let avl, input, updated_bindings, owned_regions =
              convert_value_to_input_avalues span ctx PNone bv rid ref_ty
            in
            metadata_bindings := updated_bindings;
            let parent = ctx.fresh_abs_id () in
(*
```ocaml
*)
            let child_ids = List.map (fun region -> region, ctx.fresh_abs_id ()) child_regions in
            let conversions = match source with
              | None | Some (_, None) -> []
              | Some (lid, Some (source_owner, source_level, source_reference, source_payload, sources)) ->
                  List.concat_map
                    (fun (child_region, child_owner) ->
                      List.filter_map
                        (fun (scope, origin, proof, path) ->
                          let relation = projection_metadata_renaming span
                            ctx.type_ctx.type_infos source_payload ref_ty in
                          let source_relation = RegionId.Map.of_list proof.input_relation in
(* ```ocaml *)
                          let root_ty =
                            let rename region =
                              let actual = rename_projection_metadata_region source_relation region in
                              rename_projection_metadata_region relation actual in
                            map_free_region_aliases rename origin.transport_root.sv_ty in
(* ``` *)

                          let slot_regions = RegionId.Set.fold
                            (fun region result ->
                              let actual = match RegionId.Map.find_opt region source_relation with
                                | Some (RVar (Free mapped)) -> mapped
                                | _ -> region in
                              match RegionId.Map.find_opt actual relation with
                              | Some (RVar (Free mapped)) -> RegionId.Set.add mapped result
                              | _ -> result)
                            scope.slot.proj_regions RegionId.Set.empty in
                          if not (RegionId.Set.mem child_region slot_regions) then None
                          else
                            let slot = { scope.slot with proj_ty = root_ty;
                              proj_regions = RegionId.Set.singleton child_region } in
                            let conversion : input_carrier_conversion =
                              { conversion_origin = origin; conversion_slot = slot;
                                conversion_input = proof; conversion_parent_borrow = bid;
                                conversion_returned_borrow = lid; conversion_parent_owner = parent;
                                conversion_owner = child_owner; conversion_source_owner = source_owner.abs_id;
                                conversion_source_level = source_level;
                                conversion_source_regions = source_owner.regions.owned;
                                conversion_source_reference = source_reference;
                                conversion_source_payload = source_payload;
                                conversion_receiver_payload = ref_ty; conversion_returned_at = path;
                                conversion_relation = RegionId.Map.bindings relation } in
                            let witnesses = { scope.witnesses with carrier_conversions = [ conversion ] } in
                            Some (child_owner, { scope with slot; witnesses }))
                        sources)
                    child_ids in
            push_abs ~abs_id:parent ~owned_regions
(*
```ocaml
*)
              ~call_scopes:(List.map (fun (_, scope) -> PendingParameterScope scope) conversions)
(*
```
*)
              rid (av :: avl) (Some output) (Some input);
(*
```
*)
            (match bv.value with
            | VLoan (VMutLoan lid) ->
                List.iter
                  (fun (child_region, child_owner) ->
                    let ignored = mk_aignored span ctx.type_ctx.type_infos ref_ty None in
                    let returned : tavalue =
                      { value = ALoan (AIgnoredMutLoan (PNone, Some lid, ignored)); ty }
                    in
                    let pending : tavalue =
                      { value = ASymbolic (PNone, APendingLoans bid); ty = ref_ty }
                    in
                    let output : tevalue =
                      { value = EBorrow (EIgnoredMutBorrow (Some bid, mk_eignored ref_ty)); ty }
                    in
                    let input : tevalue =
                      { value = ELoan (EIgnoredMutLoan (PNone, Some lid, mk_eignored ref_ty)); ty }
                    in
(*
```ocaml
*)
                    let call_scopes = List.filter_map
                      (fun (owner, scope) ->
                        if owner = child_owner then Some (PendingParameterScope scope) else None)
                      conversions in
(*
```ocaml
*)
                    push_abs ~abs_id:child_owner ~call_scopes
(*
```
*)
                      ~parents:(AbsId.Set.singleton parent) child_region
                      [ returned; pending ] (Some output) (Some input))
                  child_ids
(*
```
*)
            | _ -> ())
        | VReservedMutBorrow _ ->
            (* This borrow should have been activated *)
            [%craise] span "Unexpected")
    | VLoan _ ->
        let rid = ctx.fresh_region_id () in
        let rty, bindings = retained_value_rty span ctx v in
        let ctx = ctx_with_metadata_bindings ctx bindings in
        let avl, input, updated_bindings, owned_regions =
          convert_value_to_input_avalues span ctx PNone v rid
            rty
        in
        metadata_bindings := updated_bindings;
        (* Create a let-binding to ignore the input *)
        let rids = owned_regions in
        let input : tevalue =
          let value =
            ELet
              ( rids,
                mk_epat_ignored input.ty,
                input,
                mk_etuple ~borrow_proj:true [] )
          in
          { value; ty = mk_unit_ty }
        in
        (* *)
        let output = mk_eignored mk_unit_ty in
        push_abs ~owned_regions rid avl (Some output) (Some input)
    | VSymbolic sv ->
        (* Check that there are no nested borrows in the symbolic value -
           we don't support this case yet *)
        [%cassert] span
          (not
             (ty_has_nested_borrows (Some span) ctx.type_ctx.type_infos sv.sv_ty))
          "Nested borrows are not supported yet";

        (* Introduce one abstraction per live region *)
        let regions, ty, updated_bindings = refresh_live_regions_in_ty span ctx sv.sv_ty in
        metadata_bindings := updated_bindings;
        RegionId.Map.iter
          (fun _ rid ->
            let proj : symbolic_proj = { sv_id = sv.sv_id; proj_ty = ty } in
            let nv = ASymbolic (PNone, AProjBorrows { proj; loans = [] }) in
            let nv : tavalue = { value = nv; ty } in
            (* Abstraction expression *)
            let output =
              ESymbolic
                ( PNone,
                  EProjBorrows
                    { proj = { sv_id = sv.sv_id; proj_ty = ty }; loans = [] } )
            in
            let output = { value = output; ty } in
            let input = mk_evalue ctx.env ty v in
            (* *)
            push_abs rid [ nv ] (Some output) (Some input))
          regions
  in

  (* Apply *)
  let rty, bindings = retained_value_rty span ctx v in
  let () = metadata_bindings := bindings in
  let () = to_abs v rty in
  (* Return *)
  (List.rev !absl, !metadata_bindings)

(** The outermost borrow or loan of a value which region abstractions cannot
    hold because of the mutable borrows below it: a mutable borrow whose
    borrowed value holds mutable borrows outside of shared loans (nested
    borrows, see [convert_value_to_input_avalues]), or, if [shared_payloads], a
    shared loan whose payload holds mutable borrows (see
    {!InterpBorrows.destructure_abs}). Ending its loan (see
    {!InterpBorrows.end_loan}) gives the nested borrows back. *)
let value_nested_mut_borrows_owner (span : Meta.span) ~(shared_payloads : bool)
    (ctx : eval_ctx) (v : tvalue) : BorrowId.id option =
  let exception Owner of BorrowId.id in
  let has_mut_borrows_outside_shared_loans (v : tvalue) : bool =
    let visitor =
      object
        inherit [_] iter_tvalue
        method! visit_ty _ _ = ()
        method! visit_VSharedLoan _ _ _ = ()
        method! visit_VMutBorrow _ _ _ = raise Utils.Found

        method! visit_symbolic_value _ sv =
          if ty_has_mut_borrows ctx.type_ctx.type_infos sv.sv_ty then
            raise Utils.Found
      end
    in
    try
      visitor#visit_tvalue () v;
      false
    with Utils.Found -> true
  in
  let visitor =
    object
      inherit [_] iter_tvalue as super

      method! visit_VMutBorrow env bid bv =
        if has_mut_borrows_outside_shared_loans bv then raise (Owner bid)
        else super#visit_VMutBorrow env bid bv

      method! visit_VSharedLoan env lid sv =
        if shared_payloads && value_has_mut_borrows (Some span) ctx sv.value
        then raise (Owner lid)
        else super#visit_VSharedLoan env lid sv
    end
  in
  try
    visitor#visit_tvalue () v;
    None
  with Owner id -> Some id

let convert_value_to_output_avalues (span : Meta.span) (ctx : eval_ctx)
    (pm : proj_marker) (v : tvalue) (regions : RegionId.Set.t) (proj_ty : ty) :
    tavalue list * tevalue =
  [%ltrace tvalue_to_string ctx v];
  
  let keep_region (r : region) =
    match r with
    | RVar (Free rid) -> RegionId.Set.mem rid regions
    | _ -> false
  in
  
  (* Borrows nested in a projected mutable borrow belong to the abstractions
     of their own regions (see the [else] branch of the [VBorrow] case below):
     only nesting within the projected regions is unsupported. *)
  let check_nested_regions (ref_ty : ty) : unit =
    [%cassert] span
      (not (ty_has_regions_in_set ctx.type_ctx.type_infos regions ref_ty))
      "Nested mutable borrows are not supported yet"
  in
  
  (* Convert a value to abstractions *)
  let rec to_output (v : tvalue) (proj_ty : ty) : tavalue list * tevalue =
    match (v.value, proj_ty) with
    | VLiteral _, _ -> ([], mk_eignored proj_ty)
    | VBottom, _ -> [%internal_error] span
    | VAdt { variant_id; fields }, TAdt { id; generics } ->
        let field_types =
          ctx_adt_get_instantiated_field_types span ctx id variant_id generics
        in
        let avalues, outputs =
          List.split (List.map2 to_output fields field_types)
        in
        ( List.flatten avalues,
          {
            value = EAdt { borrow_proj = true; variant_id; fields = outputs };
            ty = proj_ty;
          } )
    | VBorrow bc, TRef (rid, ref_ty, _) ->
        if keep_region rid then
          match bc with
          | VSharedBorrow (bid, sid) ->
              (* The caller installs this fragment in the projection's owner;
                 no new abstraction is introduced here. A shared borrow gives
                 nothing back: its output is ignored, with the type of the
                 borrow (it can be a field of an ADT whose other fields give
                 values back, see [bind_output]). *)
              let value = ABorrow (ASharedBorrow (pm, bid, sid)) in
              let value : tavalue = { value; ty = proj_ty } in
              ([ value ], mk_eignored proj_ty)
          | VMutBorrow (bid, _) ->
              check_nested_regions ref_ty;
              (* Create an avalue to push - note that we use [AIgnore] for the inner avalue *)
              let av : tavalue =
                let ignored = mk_aignored span ctx.type_ctx.type_infos ref_ty None in
                let av = ABorrow (AMutBorrow (pm, bid, ignored)) in
                { value = av; ty = proj_ty }
              in
              (* Create the output expression *)
              let output : tevalue =
                let ignored = mk_eignored ref_ty in
                let value = EBorrow (EMutBorrow (pm, bid, ignored)) in
                { value; ty = proj_ty }
              in
              ([ av ], output)
          | VReservedMutBorrow _ ->
              (* This borrow should have been activated *)
              [%craise] span "Unexpected"
        else begin
          match bc with
          | VMutBorrow (bid, bv) when ty_has_regions_in_set ctx.type_ctx.type_infos regions ref_ty ->
              (* Nested borrows: the outer borrow belongs to another region,
                 but the borrowed value holds borrows of the projected
                 regions. As in the destructured form of an ignored mutable
                 borrow (see {!InterpBorrows.destructure_abs}): the borrows
                 of the borrowed value stay at the current level, and the
                 loans of the value given back when [bid] ends are a pending
                 dependency on this parent borrow. The pending loans carry
                 the marker of their side of the join. *)
              let avl, child = to_output bv ref_ty in
              let pending : tavalue =
                {
                  value = ASymbolic (pm, APendingLoans bid);
                  ty = isolate_projection_ty ~refreshed:(ref RegionId.Map.empty)
                    ctx.type_ctx.type_infos regions ctx.fresh_region_id ref_ty;
                }
              in
              let output : tevalue =
                {
                  value = EBorrow (EIgnoredMutBorrow (Some bid, child));
                  ty = proj_ty;
                }
              in
              (avl @ [ pending ], output)
          | VSharedBorrow (bid, _) when ty_has_regions_in_set ctx.type_ctx.type_infos regions ref_ty
            -> (
              (* Nested borrows behind a shared borrow of another region: the
                 borrows of the projected regions live in the shared value,
                 which the projection's owner reborrows (shared), exactly as
                 for the inputs of a function call (see
                 {!InterpProjectors.apply_proj_borrows}). Dropping them would
                 leave this side of a join without the ownership that the
                 other side holds for these regions. *)
              let asb =
                match ctx_lookup_loan span ek_all bid ctx with
                | _, Concrete (VSharedLoan (_, sv))
                | _, Abstract (ASharedLoan (_, _, sv, _)) ->
                    InterpProjectors.apply_proj_borrows_on_shared_borrow span
                      ctx regions sv ref_ty
                | _ -> [%craise] span "Unexpected"
              in
              match asb with
              | [] -> ([], mk_eignored proj_ty)
              | _ ->
                  let value = ABorrow (AProjSharedBorrow (pm, asb)) in
                  ([ { value; ty = proj_ty } ], mk_eignored proj_ty))
          | _ -> ([], mk_eignored proj_ty)
        end
    | VLoan _, _ ->
        (* TODO: should we project it or not (in which region abstraction should we put it)?
           We probably need to look at the borrows *inside*. *)
        [%craise] span "Not implemented yet"
    | VSymbolic sv, _ ->
        (* Check that there are no nested borrows in the symbolic value -
           we don't support this case yet *)
        [%cassert] span
          (not
             (ty_has_nested_borrows (Some span) ctx.type_ctx.type_infos sv.sv_ty))
          "Nested borrows are not supported yet";
  
        (* Check if there is an intersection with the current regions *)
        if ty_has_regions_in_set ctx.type_ctx.type_infos regions proj_ty then
          let proj : symbolic_proj = { sv_id = sv.sv_id; proj_ty } in
          let nv = ASymbolic (pm, AProjBorrows { proj; loans = [] }) in
          let nv : tavalue = { value = nv; ty = proj_ty } in
          (* Abstraction expression *)
          let output =
            ESymbolic
              ( pm,
                EProjBorrows
                  { proj = { sv_id = sv.sv_id; proj_ty }; loans = [] } )
          in
          let output = { value = output; ty = proj_ty } in
          (* *)
          ([ nv ], output)
        else ([], mk_eignored proj_ty)
    | _ -> [%internal_error] span
  in
  
  (* Apply *)
  to_output v proj_ty

(** Keep both physical return dependencies with complete owned types. *)
let join_mut_loan_with_nested_input span (ctx : eval_ctx)
    ~(loan_ctx : eval_ctx) ~(other_ctx : eval_ctx) ~abs_kind ~with_abs_conts
    ~loan_pm ~other_pm ~loan_id ~(other : tvalue) :
    abs list * tvalue * region_metadata_bindings =
  let metadata_bindings =
    merge_metadata_bindings (Some span) ctx.metadata_bindings
      (merge_metadata_bindings (Some span) loan_ctx.metadata_bindings
         other_ctx.metadata_bindings)
  in
  let ctx = ctx_with_metadata_bindings ctx metadata_bindings in
  let other_ctx = ctx_with_metadata_bindings other_ctx metadata_bindings in
  let original_child_ty =
    match lookup_borrow span ek_all (UMut loan_id) loan_ctx with
    | Concrete (VMutBorrow (_, child)) -> child.ty
    | Abstract (AMutBorrow (_, _, child)) ->
        ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings child.ty
    | _ -> [%internal_error] span
  in
  [%sanity_check] span (original_child_ty = other.ty);
  let field_regions, field_ty, metadata_bindings =
    match other.value with
    | VSymbolic sv ->
        let regions, ty, metadata_bindings = refresh_live_regions_in_ty span other_ctx sv.sv_ty in
        (List.map snd (RegionId.Map.bindings regions), ty, metadata_bindings)
    | _ ->
        ty_refresh_regions_with_metadata (Some span) ctx.type_ctx.type_infos
          ctx.fresh_region_id ctx.metadata_bindings other.ty
  in
  let ctx = ctx_with_metadata_bindings ctx metadata_bindings in
  let other_ctx = ctx_with_metadata_bindings other_ctx metadata_bindings in
  [%sanity_check] span
    (ty_is_rty ctx.type_ctx.type_infos field_ty
    && ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings field_ty = other.ty);
  let storage_region = ctx.fresh_region_id () in
  let storage_bid = ctx.fresh_borrow_id () in
  let storage_ty = mk_ref_ty (RVar (Free storage_region)) field_ty RMut in
  let ignored ty = mk_aignored span ctx.type_ctx.type_infos ty None in
  let make_abs regions parents avalues output input =
    {
      abs_id = ctx.fresh_abs_id ();
      kind = abs_kind;
      can_end = true;
      parents;
      regions = { owned = regions };
      ended_subabs = AbsLevelSet.empty;
      avalues;
      cont =
        (if with_abs_conts then
           Some { output = Some output; input = Some input }
         else None);
(*
```ocaml
*)
      call_scopes = [];
(*
```
*)
    }
  in
  let owner =
    make_abs (RegionId.Set.singleton storage_region) AbsId.Set.empty
      [
        {
          value = ABorrow (AMutBorrow (PNone, storage_bid, ignored field_ty));
          ty = storage_ty;
        };
        {
          value = ALoan (AMutLoan (loan_pm, loan_id, ignored field_ty));
          ty = storage_ty;
        };
      ]
      {
        value = EBorrow (EMutBorrow (PNone, storage_bid, mk_eignored field_ty));
        ty = storage_ty;
      }
      (let original =
         {
           value = ELoan (EMutLoan (loan_pm, loan_id, mk_eignored field_ty));
           ty = storage_ty;
         }
       in
       let native =
         {
           value = EMutBorrowInput (mk_evalue other_ctx.env field_ty other);
           ty = storage_ty;
         }
       in
       let left, right =
         if loan_pm = PLeft then (original, native) else (native, original)
       in
       { value = EJoinMarkers (left, right); ty = storage_ty })
  in
  let children =
    List.map
      (fun rid ->
        let regions = RegionId.Set.singleton rid in
        let native, native_output =
          match other.value with
          | VSymbolic _ ->
              let projection =
                InterpProjectors.apply_proj_borrows span true other_ctx regions
                  other field_ty
              in
              let output =
                InterpProjectors.apply_eproj_borrows span true other_ctx regions
                  other field_ty
              in
              let av_marker =
                object
                  inherit [_] map_tavalue
                  method! visit_proj_marker _ _ = other_pm
                end
              in
              let ev_marker =
                object
                  inherit [_] map_tevalue
                  method! visit_proj_marker _ _ = other_pm
                end
              in
              ([ av_marker#visit_tavalue () projection ],
               ev_marker#visit_tevalue () output)
          | _ ->
              convert_value_to_output_avalues span other_ctx other_pm other
                regions field_ty
        in
        let returned : tavalue =
          {
            value = ALoan (AIgnoredMutLoan (loan_pm, Some loan_id, ignored field_ty));
            ty = storage_ty;
          }
        in
        let pending : tavalue =
          { value = ASymbolic (PNone, APendingLoans storage_bid); ty = field_ty }
        in
        let output =
          mk_etuple ~borrow_proj:true
            [
              {
                value =
                  ELoan (EIgnoredMutLoan (loan_pm, Some loan_id, mk_eignored field_ty));
                ty = storage_ty;
              };
              native_output;
            ]
        in
        let supplier = mk_fresh_abs_fvar field_ty in
        let input =
          mk_let span regions (mk_epat_from_fvar supplier)
            { value = ESymbolic (PNone, EPendingLoans storage_bid); ty = field_ty }
            (mk_etuple ~borrow_proj:false [ supplier; supplier ])
        in
        make_abs regions (AbsId.Set.singleton owner.abs_id)
          (returned :: native @ [ pending ]) output input)
      field_regions
  in
  let abstractions = owner :: children in
  List.iter (Invariants.opt_type_check_abs span ctx) abstractions;
  (abstractions, { value = VLoan (VMutLoan storage_bid); ty = other.ty }, metadata_bindings)



(** Simplify the duplicated shared borrows in a region abstraction.

    {[
      abs { SB l0, SB l0 } ~> abs { SB l0 }
    ]}

    Note that this function supports projection markers: when merging two
    borrows we take the union of the markers. *)
let abs_simplify_duplicated_borrows (_span : Meta.span) (ctx : eval_ctx)
    (abs : abs) : abs =
  let join_pm (pm0 : proj_marker) (pm1 : proj_marker) : proj_marker =
    match (pm0, pm1) with
    | PNone, _ | _, PNone -> PNone
    | PLeft, PRight | PRight, PLeft -> PNone
    | PRight, PRight -> PRight
    | PLeft, PLeft -> PLeft
  in

  (* We first filter the borrows which are duplicated *)
  let shared_borrows = ref BorrowId.Map.empty in
  let shared_projs = ref [] in
  let shared_proj_key asb =
    List.map
      (function
        | AsbBorrow (bid, _) -> `Borrow bid
        | AsbProjReborrows proj ->
            `Proj (normalize_symbolic_proj ctx.type_ctx.type_infos abs.regions.owned proj))
      asb
  in
  let keep_avalue (av : tavalue) : bool =
    match av.value with
    | ABorrow (ASharedBorrow (pm, bid, _)) -> begin
        match BorrowId.Map.find_opt bid !shared_borrows with
        | None ->
            shared_borrows := BorrowId.Map.add bid pm !shared_borrows;
            true
        | Some pm' ->
            let pm = join_pm pm pm' in
            shared_borrows := BorrowId.Map.add bid pm !shared_borrows;
            false
      end
    | ABorrow (AProjSharedBorrow (pm, asb)) -> (
        let key = shared_proj_key asb in
        match List.assoc_opt key !shared_projs with
        | None ->
            shared_projs := (key, pm) :: !shared_projs;
            true
        | Some pm' ->
            shared_projs :=
              (key, join_pm pm pm') :: List.remove_assoc key !shared_projs;
            false)
    | _ -> true
  in
  let avalues = List.filter keep_avalue abs.avalues in

  (* We update the projection markers of the remaining borrows *)
  let update_avalue (av : tavalue) : tavalue =
    match av.value with
    | ABorrow (ASharedBorrow (_, bid, sid)) ->
        let pm = BorrowId.Map.find bid !shared_borrows in
        { av with value = ABorrow (ASharedBorrow (pm, bid, sid)) }
    | ABorrow (AProjSharedBorrow (_, asb)) ->
        let pm = List.assoc (shared_proj_key asb) !shared_projs in
        { av with value = ABorrow (AProjSharedBorrow (pm, asb)) }
    | _ -> av
  in
  let avalues = List.map update_avalue avalues in

  (* Update the abstraction *)
  { abs with avalues }

type merge_duplicates_funcs = {
  merge_amut_borrows :
    borrow_id ->
    rty ->
    proj_marker ->
    tavalue ->
    rty ->
    proj_marker ->
    tavalue ->
    tavalue;
      (** Parameters:
          - [id]
          - [ty0]
          - [pm0]
          - [child0]
          - [ty1]
          - [pm1]
          - [child1]

          The children should be [AIgnored]. *)
  merge_ashared_borrows :
    borrow_id ->
    rty ->
    proj_marker ->
    shared_borrow_id ->
    rty ->
    proj_marker ->
    shared_borrow_id ->
    tavalue;
      (** Parameters:
          - [id]
          - [ty0]
          - [pm0]
          - [sid0]
          - [ty1]
          - [pm1]
          - [sid1] *)
  merge_amut_loans :
    loan_id ->
    rty ->
    proj_marker ->
    tavalue ->
    rty ->
    proj_marker ->
    tavalue ->
    tavalue;
      (** Parameters:
          - [id]
          - [ty0]
          - [pm0]
          - [child0]
          - [ty1]
          - [pm1]
          - [child1]

          The children should be [AIgnored]. *)
  merge_ashared_loans :
    eval_ctx ->
    loan_id ->
    rty ->
    proj_marker ->
    tvalue ->
    tavalue ->
    rty ->
    proj_marker ->
    tvalue ->
    tavalue ->
    tavalue;
      (** Parameters:
          - [ids]
          - [ty0]
          - [pm0]
          - [sv0]
          - [child0]
          - [ty1]
          - [pm1]
          - [sv1]
          - [child1]

          The children are already reconciled and identical. Use their real
          region type for the wrapper's referent, retaining its owned outer
          region; the original referent types need not equal the child's. *)
  merge_aended_shared_loans :
    eval_ctx ->
    rty ->
    proj_marker ->
    tvalue ->
    tavalue ->
    rty ->
    proj_marker ->
    tvalue ->
    tavalue ->
    tavalue;
      (** Merge corresponding retained payloads; both children have already been
          reconciled structurally. Preserve the reconciled child's real region
          type as the wrapper's referent type, while retaining the wrapper's
          owned outer region. *)
  drain_new_abstractions : unit -> abs list * region_metadata_bindings;
      (** Transfer any owners introduced while matching concrete payloads. *)
}
and merge_diagnostic = {
  merge_index : int;
  merge_phase : string;
  merge_step : int;
  merge_fixed : AbsId.Set.t option;
  merge_preserved : AbsId.Set.t;
  merge_before : eval_ctx;
  merge_left : abs;
  merge_right : abs;
  merge_isolated_left : abs;
  merge_isolated_right : abs;
  merge_left_coordinates : RegionId.id RegionId.Map.t;
  merge_right_coordinates : RegionId.id RegionId.Map.t;
  merge_after : eval_ctx;
  merge_result : abs_id;
  mutable merge_normalization_callback : (abs_id * abs_id * abs_id) option;
  mutable merge_selection :
    (string * (Format.formatter -> unit) * (string * bool) list) option;
}
and merge_diagnostics = {
  mutable trace_count : int;
  mutable trace_phase : string;
  mutable trace_step : int;
  mutable trace_fixed : AbsId.Set.t option;
  mutable trace_preserved : AbsId.Set.t;
  mutable trace_callback_unavailable : int;
  trace_records : merge_diagnostic option array;
}

(** Split ownership into coherent branch projections. Concrete retained shared
    payloads are indivisible: their enclosing marker owns the whole payload.
    Abstract children are projected in place, preserving their positional shape
    and ended wrappers rather than flattening their ownership into the parent.
*)
let tavalue_split_marker (span : Meta.span) (_ctx : eval_ctx) (av : tavalue) :
    tavalue list =
  let project branch =
    let visitor =
      object (self)
        inherit [_] map_tavalue as super

        method! visit_proj_marker _ pm =
          [%sanity_check] span (pm = PNone || pm = branch);
          branch

        method! visit_tavalue env av =
          let marker =
            match av.value with
            | ABorrow
                ( AMutBorrow (pm, _, _)
                | ASharedBorrow (pm, _, _)
                | AProjSharedBorrow (pm, _) )
            | ALoan
                ( AMutLoan (pm, _, _)
                | AIgnoredMutLoan (pm, _, _)
                | ASharedLoan (pm, _, _, _)
                | AEndedSharedLoan (pm, _, _) )
            | ASymbolic (pm, _) -> Some pm
            | _ -> None
          in
          match marker with
          | Some pm when pm <> PNone && pm <> branch ->
              let value =
                match av.value with
                | ALoan
                    ( ASharedLoan (_, _, _, child)
                    | AEndedSharedLoan (_, _, child) ) ->
                    let child = self#visit_tavalue env child in
                    if is_aignored child.value then AIgnored None
                    else ALoan (AIgnoredSharedLoan child)
                | _ -> AIgnored None
              in
              { av with value }
          | _ -> super#visit_tavalue env av

        (* A shared payload contains concrete ownership, not independently
           marked abstract slots. Do not reinterpret or re-project it. *)
        method! visit_ASharedLoan env pm bid sv child =
          ASharedLoan
            ( self#visit_proj_marker env pm,
              bid,
              sv,
              self#visit_tavalue env child )

        method! visit_AEndedSharedLoan env pm sv child =
          AEndedSharedLoan
            (self#visit_proj_marker env pm, sv, self#visit_tavalue env child)
      end
    in
    visitor#visit_tavalue () av
  in
  if is_aignored av.value then [ av ]
  else
    List.filter
      (fun (av : tavalue) -> not (is_aignored av.value))
      [ project PLeft; project PRight ]

let abs_split_markers (span : Meta.span) (ctx : eval_ctx) (abs : abs) : abs =
  {
    abs with
    avalues = List.concat (List.map (tavalue_split_marker span ctx) abs.avalues);
  }

(** Nested borrows: the level-1 outputs of a function-call abstraction held
    inside the arguments of its continuation.

    When an ancestor region of the call ends, the value it gives back for a
    borrow projector of the call's output holds inner borrows of the region of
    the abstraction: the loan projector of that output in the abstraction then
    records them as [borrows] (see {!InterpBorrows.end_proj_loans_symbolic}).
    The abstraction owns these borrows: they are outputs of its backward
    function at level 1 (e.g., [Option::as_deref_mut] gives back, for the frame
    given back through the returned reference, the inner borrows the caller
    lent to it: [⌊s@40, borrows=[(s@46)]⌋]), while the loan projector itself is
    an input at level 0. The value given back to a returned reference of a
    call whose backward function is staged (an ended ignored mutable loan of
    its output, see {!normalize_abs_for_join}) holds such outputs as well. We
    return the symbolic values of these borrows, as the level-0 arguments of
    the continuation hold them (the borrows under a shared borrow are not given
    back: their loan projectors are ignored there). *)
let abs_call_level_output_svs (abs : abs) : SymbolicValueId.Set.t =
  match
    Option.bind abs.cont
      (fun cont -> Option.map call_protocol_body cont.input)
  with
  | Some { value = EApp (EFunCall _, (_ :: _ as args)); _ } ->
      let staged = List.length args >= 2 in
      let svs = ref SymbolicValueId.Set.empty in
      let visitor =
        object (self)
          inherit [_] iter_tevalue as super

          method! visit_ESymbolic given_back pm proj =
            (match proj with
            | EProjLoans { borrows; _ } ->
                List.iter
                  (fun (_, (borrow : eproj)) ->
                    match borrow with
                    | EProjBorrows { proj; _ } ->
                        svs := SymbolicValueId.Set.add proj.sv_id !svs
                    | _ -> ())
                  borrows
            | EProjBorrows { proj; _ } when given_back ->
                svs := SymbolicValueId.Set.add proj.sv_id !svs
            | _ -> ());
            super#visit_ESymbolic given_back pm proj

          method! visit_EEndedIgnoredMutLoan given_back loan =
            if staged then (
              self#visit_tevalue given_back loan.child;
              self#visit_tevalue true loan.given_back)
            else super#visit_EEndedIgnoredMutLoan given_back loan
        end
      in
      (* The arguments of level 0 come last (see [split_call_cont_level_outputs]) *)
      List.iter
        (visitor#visit_tevalue false)
        (List.nth args (List.length args - 1));
      !svs
  | _ -> SymbolicValueId.Set.empty

(** Auxiliary function for {!merge_abstractions}.

    Phase 1 of the merge: we simplify all loan/borrow pairs, if a loan is in the
    left abstraction and its corresponding borrow is in the right abstraction.

    Important: this is asymmetric (the loan must be in the left abstraction),
    except for the level-1 outputs of a function call in the left abstraction
    (see {!abs_call_level_output_svs}) which the right abstraction lends: the
    composition of their continuations splits the one of the call (see
    {!merge_abs_conts_aux}).

    Example:
    {[
      abs0 { ML l0, MB l1 } |><| abs1 { MB l0 }
          ~~> abs1 { MB l1 }
    ]}

    But:
    {[
      abs1 { MB l0 } |><| abs0 { ML l0, MB l1 }
          ~~> abs1 { MB l0, ML l0, MB l1 }
    ]}

    We return the list of merged values.

    **Remark:** we assume the abstractions have been destructured and that the
    markers have been split (if markers are allowed). *)
let merge_abstractions_merge_loan_borrow_pairs (span : Meta.span)
    ~(allow_markers : bool) ~(with_abs_conts : bool) (ctx : eval_ctx)
    (abs0 : abs) (abs1 : abs) :
    tavalue list * MarkedNormSymbProjSet.t
    * (proj_marker * borrow_id * ty) list =
  [%ltrace ""];

  (* Sanity check: no markers appear unless we allow merging duplicates.
     Also, the borrows must be disjoint, and the loans must be disjoint. *)
  if not allow_markers then (
    let visitor =
      object
        inherit [_] iter_abs
        method! visit_proj_marker _ pm = [%sanity_check] span (pm = PNone)
      end
    in
    visitor#visit_abs () abs0;
    visitor#visit_abs () abs1);

  (* Merge.

     We take the values in the left abstraction and add the values from
     the right abstraction one at a time. Whenever we add a value, we go
     through all the *left* values in the abstraction to check if we need
     to eliminate a shared borrow because there is already a shared loan,
     or to check if we need to merge a mutable borrow and a mutable loan, etc.

     Note that we also filter the left avalues to remove ended loans, etc.
  *)
  let keep_avalue (av : tavalue) =
    match av.value with
    | ASymbolic (_, (APendingLoans _ | APendingSymbolicLoans _)) -> true
    | _ -> tavalue_has_ownership span ctx av
  in
  let left_avalues = ref (List.filter keep_avalue abs0.avalues) in
  (* Ignored carriers do not change the child's level. Give-back children do:
     never cancel a nested sub-abstraction against a root loan. *)
  (*
```ocaml
  *)
  let iter_left f =
    let visitor =
      object (self)
        inherit [_] iter_tavalue_with_levels as super
        method incr_level (regions, level) = (regions, level + 1)

        method! visit_tavalue ((regions, level) as env) av =
          match av.value with
          | ATransportedValue (transport, child) ->
              self#visit_tavalue (transport.current_regions, level) child
          | ASymbolic (pm, ATransportedProj (transport, child)) ->
              self#visit_tavalue (transport.current_regions, level)
                { value = ASymbolic (pm, child); ty = transport.current.sv_ty }
          | _ ->
              if level = 0 then f regions av;
              super#visit_tavalue env av
      end
    in
    List.iter (visitor#visit_tavalue (abs0.regions.owned, 0)) !left_avalues
  in
  let exists_left f =
    try
      iter_left (fun regions av -> if f regions av then raise Utils.Found);
      false
    with Utils.Found -> true
  in
  let map_left f =
    let visitor =
      object (self)
        inherit [_] map_abs_with_levels as super
        method incr_level (regions, level) = (regions, level + 1)

        method! visit_tavalue ((regions, level) as env) av =
          match av.value with
          | ATransportedValue (transport, child) ->
              { av with value = ATransportedValue (transport,
                  self#visit_tavalue (transport.current_regions, level) child) }
          | ASymbolic (pm, ATransportedProj (transport, child)) ->
              let child = self#visit_tavalue (transport.current_regions, level)
                { value = ASymbolic (pm, child); ty = transport.current.sv_ty } in
              let proj = match child.value with
                | ASymbolic (pm', proj) when pm' = pm -> proj
                | AIgnored _ -> AEmpty
                | _ -> [%internal_error] span in
              { av with value = ASymbolic (pm, ATransportedProj (transport, proj)) }
          | _ ->
              let av = super#visit_tavalue env av in
              if level = 0 then f regions av else av
      end
    in
    left_avalues :=
      List.filter keep_avalue
        (List.map (visitor#visit_tavalue (abs0.regions.owned, 0)) !left_avalues)
  in
  let left_norm_proj_loans = ref MarkedNormSymbProjSet.empty in
  let discharged_shared_projs = ref MarkedNormSymbProjSet.empty in
  let resolved_parent_dependencies = ref [] in
  iter_left (fun regions av ->
      match av.value with
      | ASymbolic (pm, AProjLoans { proj; _ }) ->
          let norm_proj_ty =
            normalize_proj_ty ctx.type_ctx.type_infos regions proj.proj_ty
          in
          left_norm_proj_loans :=
            MarkedNormSymbProjSet.add
              { pm; sv_id = proj.sv_id; norm_proj_ty }
              !left_norm_proj_loans
      | _ -> ());
  let has_shared_loan pm bid =
    exists_left (fun _ av ->
        match av.value with
        | ALoan (ASharedLoan (pm', bid', _, _)) -> pm = pm' && bid = bid'
        | _ -> false)
  in
  let has_proj_loan regions pm (proj : symbolic_proj) =
    let norm_proj_ty = normalize_proj_ty ctx.type_ctx.type_infos regions proj.proj_ty in
(* ```ocaml *)
    let key : marked_norm_symb_proj = { pm; sv_id = proj.sv_id; norm_proj_ty } in
    MarkedNormSymbProjSet.mem key !left_norm_proj_loans
    || MarkedNormSymbProjSet.exists
         (fun loan ->
           loan.pm = pm && loan.sv_id = proj.sv_id
           && norm_proj_tys_equal span ctx loan.norm_proj_ty norm_proj_ty)
         !left_norm_proj_loans
  in
  (* A shared observation on one branch is also subsumed by loans which the
     merged abstraction holds on both branches (for instance the loans of a
     payload which a join replaced by a fresh symbol, see
     [InterpJoin.join_ctxs]). Consuming projections must match the marker of
     the loans they cancel. *)
  let observes_proj_loan regions pm (proj : symbolic_proj) =
    has_proj_loan regions pm proj
    || (pm <> PNone && has_proj_loan regions PNone proj)
  in
  let left_level_output_svs = abs_call_level_output_svs abs0 in
  let rec reduce_right regions (av : tavalue) : tavalue =
    let ignored () = mk_aignored span ctx.type_ctx.type_infos av.ty None in
    match av.value with
    (* ```ocaml *)
    | ATransportedValue (transport, child) ->
        { av with value = ATransportedValue (transport,
            reduce_right transport.current_regions child) }
    | ASymbolic (pm, ATransportedProj (transport, child)) ->
        let child = reduce_right transport.current_regions
          { value = ASymbolic (pm, child); ty = transport.current.sv_ty } in
        let proj = match child.value with
          | ASymbolic (pm', proj) when pm' = pm -> proj
          | AIgnored _ -> AEmpty
          | _ -> [%internal_error] span in
        { av with value = ASymbolic (pm, ATransportedProj (transport, proj)) }
    (* ``` *)
    | AAdt adt ->
        {
          av with
          value = AAdt { adt with fields = List.map (reduce_right regions) adt.fields };
        }
    | ALoan (AIgnoredMutLoan (pm, bid, child)) ->
        { av with value = ALoan (AIgnoredMutLoan (pm, bid, reduce_right regions child)) }
    | ALoan (AEndedMutLoan lc) ->
        {
          av with
          value =
            ALoan (AEndedMutLoan { lc with child = reduce_right regions lc.child });
        }
    | ALoan (AEndedIgnoredMutLoan lc) ->
        {
          av with
          value =
            ALoan
              (AEndedIgnoredMutLoan { lc with child = reduce_right regions lc.child });
        }
    | ALoan (AEndedSharedLoan (pm, value, child)) ->
        {
          av with
          value = ALoan (AEndedSharedLoan (pm, value, reduce_right regions child));
        }
    | ALoan (AIgnoredSharedLoan child) ->
        (* Nested in another value, e.g. a field of an ignored mutable loan
           (the abstractions are destructured, see
           {!InterpBorrows.destructure_abs}): the field keeps its type *)
        { av with value = ALoan (AIgnoredSharedLoan (reduce_right regions child)) }
    | ABorrow (AIgnoredMutBorrow (bid, child)) ->
        {
          av with
          value = ABorrow (AIgnoredMutBorrow (bid, reduce_right regions child));
        }
    | ABorrow (AEndedIgnoredMutBorrow bc) ->
        {
          av with
          value =
            ABorrow
              (AEndedIgnoredMutBorrow { bc with child = reduce_right regions bc.child });
        }
    | ABorrow (AMutBorrow (pm, bid, child)) ->
        [%sanity_check] span (is_aignored child.value);
        let matched = ref false in
        map_left (fun _ left ->
            match left.value with
            | ALoan (AMutLoan (pm', bid', child)) when pm = pm' && bid = bid' ->
                [%sanity_check] span ((not !matched) && is_aignored child.value);
                matched := true;
                mk_aignored span ctx.type_ctx.type_infos left.ty None
            | _ -> left);
        if !matched then ignored () else av
    | ABorrow (ASharedBorrow (pm, bid, _)) ->
        if has_shared_loan pm bid then ignored () else av
    | ABorrow (AProjSharedBorrow (pm, borrows)) ->
        let borrows =
          List.filter
            (function
              | AsbBorrow (bid, _) -> not (has_shared_loan pm bid)
              | AsbProjReborrows proj -> not (observes_proj_loan regions pm proj))
            borrows
        in
        if borrows = [] then ignored ()
        else { av with value = ABorrow (AProjSharedBorrow (pm, borrows)) }
    | ASymbolic (pm, AProjBorrows { proj; loans }) when has_proj_loan regions pm proj ->
        let norm_proj_ty = normalize_proj_ty ctx.type_ctx.type_infos regions proj.proj_ty in
        let matched = ref false in
        (* Nested borrows: the borrows of the left loan projector (the inner
           borrows of the values given back for the projected value, which the
           left abstraction owns: level-1 outputs of a call, see
           [abs_call_level_output_svs]) and the loans of the right borrow
           projector over the same values (the right abstraction lends these
           inner borrows) cancel out: the merged abstraction borrows and lends
           them (its continuation passes one to the other, see
           [merge_abs_conts_aux]). *)
        let loans = ref loans in
        let cancel_nested_borrows left_regions borrows =
          let rec current_view regions = function
            | ATransportedProj (transport, child) ->
                current_view transport.current_regions child
            | proj -> (regions, proj) in
          List.filter
            (fun ((_, borrow) : mconsumed_symb * aproj) ->
              let left_regions, borrow = current_view left_regions borrow in
              match borrow with
              | AProjBorrows { proj = bproj; loans = [] } ->
                  let bnorm =
                    normalize_proj_ty ctx.type_ctx.type_infos left_regions bproj.proj_ty
                  in
                  let rec remove = function
                    | [] -> None
                    | ((_, (loan : aproj)) as x) :: rest -> (
                        let right_regions, loan = current_view regions loan in
                        match loan with
                        | AProjLoans
                            { proj = lproj; consumed = []; borrows = [] }
                          when lproj.sv_id = bproj.sv_id
                               && norm_proj_tys_equal span ctx
                                    (normalize_proj_ty ctx.type_ctx.type_infos
                                      right_regions lproj.proj_ty)
                                    bnorm -> Some rest
                        | _ -> Option.map (fun rest -> x :: rest) (remove rest))
                  in
                  begin
                    match remove !loans with
                    | Some rest ->
                        loans := rest;
                        false
                    | None -> true
                  end
              | _ -> true)
            borrows
        in
        map_left (fun left_regions left ->
            match left.value with
            | ASymbolic (pm', AProjLoans loan)
              when loan.proj.sv_id = proj.sv_id
                   && pm' = pm
                   && norm_proj_tys_equal span ctx
                        (normalize_proj_ty ctx.type_ctx.type_infos
                          left_regions loan.proj.proj_ty)
                        norm_proj_ty ->
(* ``` *)
                [%sanity_check] span (not !matched);
                (* ```ocaml *)
                [%ltrace
                  "Matched operational discharge:\n- left owner: "
                  ^ AbsId.to_string abs0.abs_id
                  ^ "\n- right owner: " ^ AbsId.to_string abs1.abs_id
                  ^ "\n- left owned: " ^ RegionId.Set.to_string None abs0.regions.owned
                  ^ "\n- right owned: " ^ RegionId.Set.to_string None abs1.regions.owned
                  ^ "\n- matched loan: " ^ tavalue_to_string ctx left
                  ^ "\n- matched borrow: " ^ tavalue_to_string ctx av
                  ^ "\n- loan normalized mask: "
                  ^ ty_to_string ctx
                      (normalize_proj_ty ctx.type_ctx.type_infos left_regions loan.proj.proj_ty)
                  ^ "\n- borrow normalized mask: " ^ ty_to_string ctx norm_proj_ty];
                (* ``` *)
                matched := true;
                let ended =
                  AEndedProjLoans
                    {
                      proj = loan.proj.sv_id;
                      consumed = loan.consumed;
                      borrows = cancel_nested_borrows left_regions loan.borrows;
                    }
                in
                if proj_has_ownership ended then
                  { left with value = ASymbolic (pm', ended) }
                else mk_aignored span ctx.type_ctx.type_infos left.ty None
            | _ -> left);
        [%sanity_check] span !matched;
        let loans = !loans in
        (* Shared backward outputs may be absent from the lender's
           continuation. Record the actual ownership discharge so composition
           can retire the borrower's output without inventing an input or
           treating the later absence of ownership as evidence. *)
        if
          loans = []
          && not (ty_has_mut_borrows ctx.type_ctx.type_infos proj.proj_ty)
        then
          discharged_shared_projs :=
            MarkedNormSymbProjSet.add
              { pm; sv_id = proj.sv_id; norm_proj_ty }
              !discharged_shared_projs;
        let ended =
          AEndedProjLoans { proj = proj.sv_id; consumed = loans; borrows = [] }
        in
        if proj_has_ownership ended then
          { av with value = ASymbolic (pm, ended) }
        else ignored ()
    | ASymbolic (pm, AProjLoans { proj; consumed = []; borrows = [] })
      when (not with_abs_conts)
           || SymbolicValueId.Set.mem proj.sv_id left_level_output_svs ->
        (* Nested borrows: a level-1 output of the call of the left
           abstraction, which the right abstraction lends. Without
           continuations (the shapes of a loop fixed point, see
           {!InterpLoopsFixedPoint}), the left abstraction lost the call which
           identified the value as such an output (e.g., the budget given back
           by [collect] to the closure of [map], whose abstractions lend each
           other the inner borrows of the budget): a borrow projector of the
           left and a loan projector of the right over the same value and
           projection type also cancel out. The fixed point is only a shape:
           each context matched with it is reduced with continuations, which
           cancel the pair only through this rule, and the match fails
           otherwise. *)
        let norm_proj_ty = normalize_proj_ty ctx.type_ctx.type_infos regions proj.proj_ty in
        let matched = ref false in
        map_left (fun left_regions left ->
            match left.value with
            | ASymbolic (pm', AProjBorrows { proj = bproj; loans = [] })
              when (not !matched) && bproj.sv_id = proj.sv_id && pm' = pm
                   && normalize_proj_ty ctx.type_ctx.type_infos left_regions bproj.proj_ty
                      = norm_proj_ty ->
                matched := true;
                mk_aignored span ctx.type_ctx.type_infos left.ty None
            | _ -> left);
        if !matched then ignored () else av
    | ALoan _ | ABorrow _ | ASymbolic _ | AIgnored _ -> av
  in
  let right_avalues =
    List.filter keep_avalue (List.map (reduce_right abs1.regions.owned) abs1.avalues)
  in
  (*
```
  *)
  (* Nested borrows: the pending loans of a parent borrow [bid] (the loans of
     the inner borrows of the value given back when [bid] ends, see
     {!InterpBorrows.destructure_abs}) and an ignored loan of [bid] whose
     inner loans were all merged away (it only receives the inner borrows of
     that value, as borrows) cancel out: the merged abstraction lends and
     borrows back the same inner borrows. E.g., at the end of a loop
     iteration over [bump(&mut r)] with [r : &'a mut Counter<'b>], the
     abstraction of ['b] at the loop entry lends the counter to the call
     (ignored loan of the reborrow), and the region group ['b] of the call
     lends the inner borrows of the counter it gives back (pending loans).
     With markers, the ignored loan of a reborrow which only exists in one
     branch is only in the projection of that branch (see
     {!tavalue_split_marker}), like the pending loans of that reborrow: they
     cancel out one to one. With several levels of nesting (e.g., the
     abstraction of ['c] for a reborrow of a [&'a mut C<'b, D<'c>>] where [C]
     holds a [&'b mut D<'c>]), the ignored loan of the outer reborrow holds
     the ignored loan of the inner one: the inner loan cancels out with the
     pending loans of the inner borrow first, then the outer one with those of
     the outer borrow. A shared loan held by an ignored loan (possibly behind
     the ignored shared loan of another region), whose shared borrows this
     merge eliminated and which no other value borrows, is endable (as in
     {!end_endable_shared_loans_at_abs}): only its child can hold ownership.
     Its shared value cannot be accessed anymore: the shared borrows it
     contains are dead (as in
     {!InterpBorrows.eliminate_ended_shared_loans}), e.g. the [&'b T] captured
     by a closure [F<'b>] given back behind a [&'a F<'b>] field of a closure
     reborrowed as [&mut]. Dropping them releases their loans (the loans of
     ['b], held behind the ignored shared loan of ['a]), which a later merge of
     the abstraction of ['b] cancels in turn. *)
  let pending_loan regions pm bid mask (av : tavalue) =
      match av.value with
      | ASymbolic (pending_pm, APendingLoans bid') ->
          pm = pending_pm && bid = bid'
          && normalize_proj_ty ctx.type_ctx.type_infos regions av.ty = mask
      | _ -> false
  in
  let rec remove_first f = function
    | [] -> []
    | x :: xs -> if f x then xs else x :: remove_first f xs
  in
  let live_borrows =
    lazy
      (let others =
         List.filter
           (function
             | EAbs (abs : abs) ->
                 abs.abs_id <> abs0.abs_id && abs.abs_id <> abs1.abs_id
             | _ -> true)
           ctx.env
       in
       let merged =
         { abs0 with avalues = !left_avalues @ right_avalues; cont = None }
       in
       BorrowId.Set.union (fst (compute_env_ids others)).borrow_ids
         (fst (compute_abs_ids merged)).borrow_ids)
  in
  (* The pending loans left once [av] and its nested ignored loans cancel out
     with some of [pendings], if they all do *)
  let rec cancel_loan loan_regions pending_regions (pendings : tavalue list)
        resolved (av : tavalue) =
      match av.value with
      | ALoan (AIgnoredMutLoan (pm, Some bid, child)) -> (
          let mask = normalize_proj_ty ctx.type_ctx.type_infos loan_regions child.ty in
          match cancel_loan loan_regions pending_regions pendings resolved child with
          | Some (pendings, resolved)
            when List.exists (pending_loan pending_regions pm bid mask) pendings ->
              Some
                (remove_first (pending_loan pending_regions pm bid mask) pendings,
                 (pm, bid, mask) :: resolved)
          | _ -> None)
      | AAdt adt ->
          List.fold_left
            (fun pending field ->
              Option.bind pending
                (fun (pendings, resolved) ->
                  cancel_loan loan_regions pending_regions pendings resolved field))
            (Some (pendings, resolved)) adt.fields
      | ALoan (ASharedLoan (_, bid, sv, child))
        when InterpBorrows.value_has_only_shared_borrows ctx sv
             && not (BorrowId.Set.mem bid (Lazy.force live_borrows)) ->
          cancel_loan loan_regions pending_regions pendings resolved child
      | ALoan (AIgnoredSharedLoan child) ->
          cancel_loan loan_regions pending_regions pendings resolved child
      | _ ->
          if tavalue_has_ownership span ctx av then None
          else Some (pendings, resolved)
  in
  let cancel loan_regions pending_regions (loans : tavalue list)
        (pendings : tavalue list) =
      List.fold_left
        (fun (loans, pendings) (av : tavalue) ->
          match av.value with
          | ALoan (AIgnoredMutLoan (_, Some _, _)) -> (
              match cancel_loan loan_regions pending_regions pendings
                      !resolved_parent_dependencies av with
              | Some (pendings, resolved) ->
                  let () = resolved_parent_dependencies := resolved in
                  (remove_first (( == ) av) loans, pendings)
              | None -> (loans, pendings))
          | _ -> (loans, pendings))
        (loans, pendings) loans
  in
  let left_avalues, right_avalues = cancel abs0.regions.owned abs1.regions.owned !left_avalues right_avalues in
  let right_avalues, left_avalues = cancel abs1.regions.owned abs0.regions.owned right_avalues left_avalues in
  (left_avalues @ right_avalues, !discharged_shared_projs,
   !resolved_parent_dependencies)

let shared_payloads_correspond (sv0 : tvalue) (sv1 : tvalue) =
  if sv0 = sv1 then true
  else
    let ids0, _ = compute_tvalue_ids sv0 in
    let ids1, _ = compute_tvalue_ids sv1 in
    (not (BorrowId.Set.is_empty (BorrowId.Set.inter ids0.blids ids1.blids)))
    || not
         (SymbolicValueId.Set.is_empty
            (SymbolicValueId.Set.inter ids0.sids ids1.sids))

(** Auxiliary function for {!merge_abstractions}.

    Phase 2 of the merge: we remove markers, by merging pairs of the same
    element with different markers into one element without markers.

    Example:
    {[
      |MB l0|, MB l1, ︙MB l0︙
           ~~>
      MB l0, MB l1
    ]} *)
let rec merge_abstractions_merge_markers (span : Meta.span)
    (merge_funs : merge_duplicates_funcs) (ctx : eval_ctx)
    (owned_regions : RegionId.Set.t) (avalues : tavalue list) : tavalue list =
  [%ltrace
    "- avalues:\n"
    ^ String.concat ", " (List.map (tavalue_to_string ctx) avalues)];

  (* We simply iterate through the list of avalues create during the first phase,
     and progressively add them back: if we find a value with a complementary marker,
     we merge the values together, otherwise we add it to the list of values. *)
  let complementary_markers pm0 pm1 =
    (pm0 = PLeft && pm1 = PRight) || (pm0 = PRight && pm1 = PLeft)
  in

  let rec merge_child (child0 : tavalue) (child1 : tavalue) : tavalue =
    [%sanity_check] span
      (ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings child0.ty = ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings child1.ty);
    match (child0.value, child1.value) with
    | AIgnored _, AIgnored _ ->
        (* Keep the left projection's type witnesses together. The two
           ignored children may carry distinct unowned regions, which are
           deliberately not identified when the abstractions are merged. *)
        child0
    | AIgnored _, _ -> child1
    | _, AIgnored _ -> child0
    | AAdt adt0, AAdt adt1 ->
        [%sanity_check] span
          (adt0.borrow_proj = adt1.borrow_proj
          && adt0.variant_id = adt1.variant_id
          && List.length adt0.fields = List.length adt1.fields);
        let fields = List.map2 merge_child adt0.fields adt1.fields in
        { child0 with value = AAdt { adt0 with fields } }
    | _ -> (
        match
          merge_abstractions_merge_markers span merge_funs ctx owned_regions
            [ child0; child1 ]
        with
        | [ child ] -> child
        | _ ->
            [%craise] span "Incompatible retained shared-loan child ownership")
  in

  (* Some utility functions *)
  (* Merge two aborrow contents - return [Some] if they were merged into a single value,
     return [None] otherwise.
   *)
  let try_merge_aborrow_contents (ty0 : rty) (bc0 : aborrow_content) (ty1 : rty)
      (bc1 : aborrow_content) : tavalue option =
    match (bc0, bc1) with
    | AMutBorrow (pm0, id0, child0), AMutBorrow (pm1, id1, child1)
      when id0 = id1 ->
        [%sanity_check] span (complementary_markers pm0 pm1);
        Some (merge_funs.merge_amut_borrows id0 ty0 pm0 child0 ty1 pm1 child1)
    | ASharedBorrow (pm0, id0, sid0), ASharedBorrow (pm1, id1, sid1)
      when id0 = id1 && complementary_markers pm0 pm1 ->
        (* Independent copies of a shared borrow can coexist on one branch. *)
        Some (merge_funs.merge_ashared_borrows id0 ty0 pm0 sid0 ty1 pm1 sid1)
    | ASharedBorrow (pm0, id0, _), AProjSharedBorrow (pm1, [ AsbBorrow (id1, _) ])
      when id0 = id1 && complementary_markers pm0 pm1 ->
        (* One branch holds the shared borrow of the loan in this region as a
           plain borrow (e.g., the borrow of a join), the other as the
           projection of a value holding only that borrow (e.g., the input of a
           function call). Both are the same ownership. *)
        Some
          {
            value =
              ABorrow (ASharedBorrow (PNone, id0, ctx.fresh_shared_borrow_id ()));
            ty = ty0;
          }
    | AProjSharedBorrow (pm0, [ AsbBorrow (id0, _) ]), ASharedBorrow (pm1, id1, _)
      when id0 = id1 && complementary_markers pm0 pm1 ->
        Some
          {
            value =
              ABorrow (ASharedBorrow (PNone, id1, ctx.fresh_shared_borrow_id ()));
            ty = ty1;
          }
    | AProjSharedBorrow (pm0, asb0), AProjSharedBorrow (pm1, asb1)
      when complementary_markers pm0 pm1
           && List.length asb0 = List.length asb1
           && List.for_all2
                (fun b0 b1 ->
                  match (b0, b1) with
                  | AsbBorrow (bid0, _), AsbBorrow (bid1, _) -> bid0 = bid1
                  | AsbProjReborrows p0, AsbProjReborrows p1 ->
                      p0.sv_id = p1.sv_id
                      && normalize_proj_ty ctx.type_ctx.type_infos owned_regions p0.proj_ty
                         = normalize_proj_ty ctx.type_ctx.type_infos owned_regions p1.proj_ty
                  | _ -> false)
                asb0 asb1 ->
        let asb =
          List.map
            (function
              | AsbBorrow (bid, _) ->
                  AsbBorrow (bid, ctx.fresh_shared_borrow_id ())
              | AsbProjReborrows _ as proj -> proj)
            asb0
        in
        Some { value = ABorrow (AProjSharedBorrow (PNone, asb)); ty = ty0 }
    | _ ->
        (* Nothing to merge *)
        None
  in

  let try_merge_aloan_contents (ty0 : rty) (lc0 : aloan_content) (ty1 : rty)
      (lc1 : aloan_content) : tavalue option =
    [%ldebug
      "- lc0: "
      ^ aloan_content_to_string ctx lc0
      ^ "\n- lc1: "
      ^ aloan_content_to_string ctx lc1];
    match (lc0, lc1) with
    | AMutLoan (pm0, id0, child0), AMutLoan (pm1, id1, child1) when id0 = id1 ->
        [%sanity_check] span (complementary_markers pm0 pm1);
        (* Merge *)
        Some (merge_funs.merge_amut_loans id0 ty0 pm0 child0 ty1 pm1 child1)
    | ASharedLoan (pm0, id0, sv0, child0), ASharedLoan (pm1, id1, sv1, child1)
      when id0 = id1 ->
        [%sanity_check] span (complementary_markers pm0 pm1);
        let child = merge_child child0 child1 in
        Some
          (merge_funs.merge_ashared_loans ctx id0 ty0 pm0 sv0 child ty1 pm1 sv1
             child)
    (*
```ocaml
    *)
    | ASharedLoan (pm0, id, sv0, child0), AEndedSharedLoan (pm1, sv1, child1)
    | AEndedSharedLoan (pm0, sv0, child0), ASharedLoan (pm1, id, sv1, child1)
      when complementary_markers pm0 pm1
           && normalize_proj_ty ctx.type_ctx.type_infos owned_regions ty0
              = normalize_proj_ty ctx.type_ctx.type_infos owned_regions ty1
           && sv0 = sv1 ->
        let child = merge_child child0 child1 in
        Some
          (merge_funs.merge_ashared_loans ctx id ty0 pm0 sv0 child ty1 pm1 sv1
             child)
    (*
```
    *)
    | AEndedSharedLoan (pm0, sv0, child0), AEndedSharedLoan (pm1, sv1, child1)
      when complementary_markers pm0 pm1
           && ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings ty0 = ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings ty1
           && shared_payloads_correspond sv0 sv1 ->
        let child = merge_child child0 child1 in
        Some
          (merge_funs.merge_aended_shared_loans ctx ty0 pm0 sv0 child ty1 pm1
             sv1 child)
    | _ ->
        (* Nothing to merge *)
        None
  in

  (* ```ocaml *)
  let rec try_merge_projs ?regions ((ty0, pm0, proj0) : ty * proj_marker * aproj)
      ((ty1, pm1, proj1) : ty * proj_marker * aproj) : tavalue option =
    let owned_regions = Option.value regions ~default:owned_regions in
  (* ``` *)
    (* Children inherit their enclosing marker. Reconcile them before removing
       complementary markers from the root; concatenating their lists would
       turn two branch-local owners into simultaneous owners. Historical
       give-back records must agree, rather than being rewritten as live ids,
       except for the value given back by a projector of shared borrows only:
       each branch which ended the projector generated a fresh one, and no
       continuation consumes it (a loan projector without mutable loans has no
       backward input), so the left record is kept. *)
    let records_agree (meta0 : mconsumed_symb) (meta1 : mconsumed_symb) =
      meta0 = meta1
      || { meta0 with sv_id = meta1.sv_id } = meta1
         && not (ty_has_mut_borrows ctx.type_ctx.type_infos meta0.proj_ty)
    in
    let rec merge_children children0 children1 =
      match (children0, children1) with
      | [], [] -> Some []
      | (meta0, child0) :: tail0, (meta1, child1) :: tail1
        when records_agree meta0 meta1 -> (
          (* A record which agrees only up to the given-back value of a
             projector of shared borrows only may hold the ended loan
             projector of that value: both branches ended it, each on its own
             fresh value, which no continuation consumes either. The left
             record is kept for it as well. *)
          let child1 =
            match child1 with
            | AEndedProjLoans ended
              when meta0.sv_id <> meta1.sv_id && ended.proj = meta1.sv_id ->
                AEndedProjLoans { ended with proj = meta0.sv_id }
            | _ -> child1
          in
          let child_ty (meta : mconsumed_symb) = function
            (* ```ocaml *)
            | ATransportedProj (transport, _) -> transport.current.sv_ty
            (* ``` *)
            | AProjBorrows { proj; _ } | AProjLoans { proj; _ } -> proj.proj_ty
            | APendingSymbolicLoans slot -> slot.proj_ty
            | APendingLoans _ | AEndedProjBorrows _ | AEndedProjLoans _ | AEmpty
              -> meta.proj_ty
          in
          match
            ( try_merge_projs ~regions:owned_regions
                (child_ty meta0 child0, pm0, child0)
                (child_ty meta1 child1, pm1, child1),
              merge_children tail0 tail1 )
          with
          | Some { value = ASymbolic (PNone, child); _ }, Some tail ->
              Some ((meta0, child) :: tail)
          | _ -> None)
      | _ -> None
    in
    let symbolic proj : tavalue option =
      Some { value = ASymbolic (PNone, proj); ty = ty0 }
    in
    match (proj0, proj1) with
    (* ```ocaml *)
    | ATransportedProj (transport0, child0),
      ATransportedProj (transport1, child1) when transport0 = transport1 ->
        Option.map
          (fun (child : tavalue) ->
            match child.value with
            | ASymbolic (_, child) ->
                ({ value = ASymbolic (PNone, ATransportedProj (transport0, child));
                   ty = ty0 } : tavalue)
            | _ -> [%internal_error] span)
          (try_merge_projs ~regions:transport0.current_regions
             (transport0.current.sv_ty, pm0, child0)
             (transport1.current.sv_ty, pm1, child1))
    (* ``` *)
    | APendingLoans bid0, APendingLoans bid1
      when bid0 = bid1
           && complementary_markers pm0 pm1
           && normalize_proj_ty ctx.type_ctx.type_infos owned_regions ty0
              = normalize_proj_ty ctx.type_ctx.type_infos owned_regions ty1 ->
        symbolic (APendingLoans bid0)
    | APendingSymbolicLoans slot0, APendingSymbolicLoans slot1
      when equal_symbolic_pending_slot slot0 slot1
           && complementary_markers pm0 pm1 ->
        symbolic (APendingSymbolicLoans slot0)
    | AProjBorrows proj0, AProjBorrows proj1
      when proj0.proj.sv_id = proj1.proj.sv_id
           && projections_intersect span ctx owned_regions proj0.proj.proj_ty
                owned_regions proj1.proj.proj_ty -> (
        [%sanity_check] span (complementary_markers pm0 pm1);
        (* A projector is an atomic continuation state. Partial overlap is not
           equality: retain both branch-marked roots until their complete
           ownership components can be reconciled. *)
        if
          normalize_proj_ty ctx.type_ctx.type_infos owned_regions proj0.proj.proj_ty
          <> normalize_proj_ty ctx.type_ctx.type_infos owned_regions proj1.proj.proj_ty
        then None
        else
          match merge_children proj0.loans proj1.loans with
          | None -> None
          | Some loans -> symbolic (AProjBorrows { proj0 with loans }))
    | AProjLoans proj0, AProjLoans proj1
      when proj0.proj.sv_id = proj1.proj.sv_id
           && projections_intersect span ctx owned_regions proj0.proj.proj_ty
                owned_regions proj1.proj.proj_ty -> (
        [%sanity_check] span (complementary_markers pm0 pm1);
        if
          normalize_proj_ty ctx.type_ctx.type_infos owned_regions proj0.proj.proj_ty
          <> normalize_proj_ty ctx.type_ctx.type_infos owned_regions proj1.proj.proj_ty
        then None
        else
          match
            ( merge_children proj0.consumed proj1.consumed,
              merge_children proj0.borrows proj1.borrows )
          with
          | Some consumed, Some borrows ->
              symbolic (AProjLoans { proj0 with consumed; borrows })
          | _ -> None)
    | AEndedProjLoans proj0, AEndedProjLoans proj1
      when proj0.proj = proj1.proj && complementary_markers pm0 pm1 -> (
        match
          ( merge_children proj0.consumed proj1.consumed,
            merge_children proj0.borrows proj1.borrows )
        with
        | Some consumed, Some borrows ->
            symbolic (AEndedProjLoans { proj0 with consumed; borrows })
        | _ -> None)
    | AEndedProjBorrows proj0, AEndedProjBorrows proj1
      when proj0.mvalues = proj1.mvalues && complementary_markers pm0 pm1 -> (
        match merge_children proj0.loans proj1.loans with
        | Some loans -> symbolic (AEndedProjBorrows { proj0 with loans })
        | None -> None)
    | AEmpty, AEmpty -> symbolic AEmpty
    | _ -> None
  in

  (* Attempt to merge two avalues, if they are mergeable.

     Return [Some] with the result of the merge if it occurred, and [None]
     if the two values can't be merged (because they are of two different
     kinds for instance). *)
  let rec try_merge_avalues (av0 : tavalue) (av1 : tavalue) : tavalue option =
    match (av0.value, av1.value) with
    | ( ABorrow (AIgnoredMutBorrow (bid0, child0)),
        ABorrow (AIgnoredMutBorrow (bid1, child1)) )
      when bid0 = bid1 ->
        Option.map
          (fun child ->
            { av0 with value = ABorrow (AIgnoredMutBorrow (bid0, child)) })
          (try_merge_child child0 child1)
    | ( ALoan (AIgnoredMutLoan (pm0, bid0, child0)),
        ALoan (AIgnoredMutLoan (pm1, bid1, child1)) )
      when complementary_markers pm0 pm1 && bid0 = bid1 ->
        Option.map
          (fun child ->
            { av0 with value = ALoan (AIgnoredMutLoan (PNone, bid0, child)) })
          (try_merge_child child0 child1)
    | ABorrow (AEndedIgnoredMutBorrow bc0), ABorrow (AEndedIgnoredMutBorrow bc1)
      when bc0.given_back_meta = bc1.given_back_meta ->
        Option.bind (try_merge_child bc0.child bc1.child) (fun child ->
            Option.map
              (fun given_back ->
                {
                  av0 with
                  value =
                    ABorrow
                      (AEndedIgnoredMutBorrow { bc0 with child; given_back });
                })
              (try_merge_child bc0.given_back bc1.given_back))
    | ALoan (AEndedIgnoredMutLoan lc0), ALoan (AEndedIgnoredMutLoan lc1)
      when lc0.given_back_meta = lc1.given_back_meta
           && lc0.given_back_env = lc1.given_back_env ->
        Option.bind (try_merge_child lc0.child lc1.child) (fun child ->
            Option.map
              (fun given_back ->
                {
                  av0 with
                  value =
                    ALoan (AEndedIgnoredMutLoan { lc0 with child; given_back });
                })
              (try_merge_child lc0.given_back lc1.given_back))
    | ALoan (AEndedMutLoan lc0), ALoan (AEndedMutLoan lc1)
      when lc0.given_back_meta = lc1.given_back_meta ->
        Option.bind (try_merge_child lc0.child lc1.child) (fun child ->
            Option.map
              (fun given_back ->
                {
                  av0 with
                  value = ALoan (AEndedMutLoan { lc0 with child; given_back });
                })
              (try_merge_child lc0.given_back lc1.given_back))
    | AAdt adt0, AAdt adt1
      when adt0.borrow_proj = adt1.borrow_proj
           && adt0.variant_id = adt1.variant_id
           && List.length adt0.fields = List.length adt1.fields ->
        let rec merge_fields xs ys =
          match (xs, ys) with
          | [], [] -> Some []
          | x :: xs, y :: ys ->
              Option.bind (try_merge_child x y) (fun field ->
                  Option.map
                    (fun fields -> field :: fields)
                    (merge_fields xs ys))
          | _ -> None
        in
        Option.map
          (fun fields -> { av0 with value = AAdt { adt0 with fields } })
          (merge_fields adt0.fields adt1.fields)
    | ALoan c0, ALoan c1 -> try_merge_aloan_contents av0.ty c0 av1.ty c1
    | ABorrow c0, ABorrow c1 -> try_merge_aborrow_contents av0.ty c0 av1.ty c1
    | ASymbolic (pm0, proj0), ASymbolic (pm1, proj1) ->
        try_merge_projs (av0.ty, pm0, proj0) (av1.ty, pm1, proj1)
    | _ -> None
  and try_merge_child (child0 : tavalue) (child1 : tavalue) : tavalue option =
    if ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings child0.ty <> ty_erase_regions_with_metadata ctx.type_ctx.type_infos ctx.metadata_bindings child1.ty then None
    else
      match (child0.value, child1.value) with
      | AIgnored _, AIgnored _ ->
          (* The merged value keeps the type of [av0] (see [try_merge_avalues]):
             keep its ignored children, whose unowned regions may differ from
             those of [av1] (see [merge_child]) *)
          Some child0
      | AIgnored _, _ -> Some child1
      | _, AIgnored _ -> Some child0
      | _ -> try_merge_avalues child0 child1
  in

  let avalues = reconcile_shared_borrow_groups avalues in
  let merged = ref [] in let add_avalue (av : tavalue) : unit =
    let rec add avl =
      match avl with
      | [] -> [ av ]
      | av' :: avl -> (
          match try_merge_avalues av av' with
          | None ->
              (* No merge: continue *)
              av' :: add avl
          | Some av'' ->
              (* The two values were merged together: introduce the merged value
               and stop the exploration *)
              av'' :: avl)
    in
    merged := add !merged
  in
  
  List.iter add_avalue avalues;
  
  (* Childless projections of shared-only values have no backward state. One
     branch may own a whole mask while the other partitions it across region
     groups. Reconcile only equal disjoint unions, retaining the left branch's
     partition and types; partial coverage and descendant histories stay marked. *)
  let groups =
    List.fold_left
      (fun groups (av : tavalue) ->
        match av.value with
        | ASymbolic (((PLeft | PRight) as pm), AProjBorrows { proj; loans = [] })
          when not (ty_has_mut_borrows ctx.type_ctx.type_infos proj.proj_ty) ->
            let mask = normalize_proj_ty ctx.type_ctx.type_infos owned_regions proj.proj_ty in
            let add = function
              | None -> Some mask
              | Some previous ->
                  Some (norm_proj_tys_union span ctx previous mask)
            in
            SymbolicValueId.Map.update proj.sv_id
              (fun previous ->
                let left, right = Option.value previous ~default:(None, None) in
                Some
                  (match pm with
                  | PLeft -> (add left, right)
                  | PRight -> (left, add right)
                  | PNone -> [%internal_error] span))
              groups
        | _ -> groups)
      SymbolicValueId.Map.empty !merged
  in
  let balanced =
    SymbolicValueId.Map.fold
      (fun sid (left, right) balanced ->
        match (left, right) with
        | Some left, Some right when left = right ->
            SymbolicValueId.Set.add sid balanced
        | _ -> balanced)
      groups SymbolicValueId.Set.empty
  in
  if SymbolicValueId.Set.is_empty balanced then !merged
  else
    List.filter_map
      (fun (av : tavalue) ->
        match av.value with
        | ASymbolic
            ( ((PLeft | PRight) as pm),
              AProjBorrows ({ proj; loans = [] } as borrow) )
          when SymbolicValueId.Set.mem proj.sv_id balanced ->
            if pm = PLeft then
              Some { av with value = ASymbolic (PNone, AProjBorrows borrow) }
            else None
        | _ -> Some av)
      !merged

(** Information about a borrow which is output by a continuation and which was
    bound in a let binding.

    We distinguish different cases, depending on whether the borrow has a marker
    or not. *)
type bound_borrow = (proj_marker * AbsFVarId.id * ty) list

(** Similar to [bound_borrow] but for symbolic projections *)
type bound_symbolic = (proj_marker * norm_proj_ty * AbsFVarId.id * ty) list

type pending_symbolic_scope =
  (bool * bool list) list * call_endpoint_witnesses

(*
```ocaml
*)
(*
```ocaml
*)
let merge_call_endpoint_witnesses
    (left : call_endpoint_witnesses) (right : call_endpoint_witnesses) =
  if left == right then left
  else
    let merge_rows left right =
      if left == right then left else List.sort_uniq Stdlib.compare (left @ right) in
    {
      roots = merge_rows left.roots right.roots;
      expansions = merge_rows left.expansions right.expansions;
      projections = merge_rows left.projections right.projections;
      carrier_origins = merge_rows left.carrier_origins right.carrier_origins;
      input_correspondences = merge_rows left.input_correspondences right.input_correspondences;
      carrier_conversions = merge_rows left.carrier_conversions right.carrier_conversions;
      physical_returns = merge_rows left.physical_returns right.physical_returns;
      return_routes = merge_rows left.return_routes right.return_routes;
      parent_carriers = merge_rows left.parent_carriers right.parent_carriers;
    }
(*
```
*)

let pending_symbolic_input_scopes span (stored : call_scope list)
(*
```
*)
    (inputs : tevalue option list) =
  let scopes = ref SymbolicPendingSlotMap.empty in
  let ownership_key slot (endpoints : call_endpoint_witnesses) =

    List.filter
      (fun (origin : carrier_origin) ->
        origin.original_root.sv_id = slot.root_sv_id
        || origin.transport_root.sv_id = slot.root_sv_id)
      endpoints.carrier_origins

    |> List.sort_uniq Stdlib.compare
  in
  let register slot positions endpoints =
    let scope =
      match SymbolicPendingSlotMap.find_opt slot !scopes with
      | None -> (positions, endpoints)
      | Some (previous_positions, previous_endpoints) ->
          [%cassert] span (positions = previous_positions)
            "A pending parameter has different call namespaces";
          let () =
            (*
```ocaml
            *)
            if (!Config.print_error_diagnostics || !Config.print_error_emitters)
              && ownership_key slot previous_endpoints <> ownership_key slot endpoints then
              Printf.eprintf
                "Pending ownership source failure:\nslot: %s\nprevious: %s\ncurrent: %s\n%!"
                (show_symbolic_pending_slot slot)
                (String.concat "\n" (List.map show_carrier_origin
                  (ownership_key slot previous_endpoints)))
                (String.concat "\n" (List.map show_carrier_origin
                  (ownership_key slot endpoints)));
            (*
```
            *)
            [%cassert] span
              (ownership_key slot previous_endpoints = ownership_key slot endpoints)
              "A pending parameter changes its complete stored ownership key"
          in
          (positions, merge_call_endpoint_witnesses previous_endpoints endpoints)
    in
    scopes := SymbolicPendingSlotMap.add slot scope !scopes
  in
  List.iter
    (fun (scope : call_pending_scope) ->
      register scope.slot scope.positions scope.witnesses)
(*
```ocaml
*)
    (parameter_scopes stored);
(*
```
*)
  let visitor =
    object (self)
      inherit [_] iter_tevalue

      method! visit_ECallProtocol _ positions body =
        self#visit_tevalue (Some positions, None) body

      method! visit_ECallEndpoints (positions, _) endpoints body =
        self#visit_tevalue (positions, Some endpoints) body

      method! visit_EPendingSymbolicLoans (positions, endpoints) slot =
        let positions =
          [%unwrap_with_span] span positions
            "A pending parameter has no original call protocol"
        in
        let endpoints =
          [%unwrap_with_span] span endpoints
            "A pending parameter has no actual call endpoints"
        in
        register slot positions endpoints
    end
  in
  List.iter (Option.iter (visitor#visit_tevalue (None, None))) inputs;
  !scopes

let scope_pending_symbolic_input span scopes slot (input : tevalue) : tevalue =
  let positions, endpoints =
    [%unwrap_with_span] span (SymbolicPendingSlotMap.find_opt slot scopes)
      "A pending parameter lost its original call scope"
  in
  let input = { input with value = ECallEndpoints (endpoints, input) } in
  { input with value = ECallProtocol (positions, input) }

(*
```ocaml
*)
let retain_call_scopes span (avalues : tavalue list)
    (stored : call_scope list) : call_scope list =
(*
```
*)
  let scopes = pending_symbolic_input_scopes span stored [] in
  let retained = ref SymbolicPendingSlotMap.empty in
  let visitor =
    object
      inherit [_] iter_tavalue

      method! visit_APendingSymbolicLoans _ slot =
        let scope =
          [%unwrap_with_span] span (SymbolicPendingSlotMap.find_opt slot scopes)
            ("A pending runtime dependency lost its original call scope:\n"
            ^ show_symbolic_pending_slot slot)
        in
        retained := SymbolicPendingSlotMap.add slot scope !retained
    end
  in
  List.iter (visitor#visit_tavalue ()) avalues;
(*
```ocaml
*)
  let parameters = List.map
    (fun (slot, (positions, witnesses)) ->
      PendingParameterScope { slot; positions; witnesses })
    (SymbolicPendingSlotMap.bindings !retained) in
(*
```ocaml
*)
  let rec retain_physical scope stored =
    match stored with
    | [] -> [PhysicalInputScope scope]
    | PhysicalInputScope previous :: rest
      when previous.physical_slot = scope.physical_slot ->
        [%cassert] span
          (same_physical_input_ancestry_topology previous.ancestry scope.ancestry)
          "Physical input scopes have incompatible declaration ancestry";
        let witnesses = merge_call_endpoint_witnesses previous.witnesses scope.witnesses in
        if witnesses == previous.witnesses then stored
        else PhysicalInputScope { previous with witnesses } :: rest
    | previous :: rest ->
        let retained = retain_physical scope rest in
        if retained == rest then stored else previous :: retained in
(*
```
*)
  List.fold_right
    (fun scope retained ->
      match scope with
      | PendingParameterScope _ -> retained
      | PhysicalInputScope scope -> retain_physical scope retained)
    stored parameters
(*
```
*)


type input_binding =
  | ConcreteInput of BorrowId.id
  | SymbolicInput of norm_symb_proj
  | PendingInput of BorrowId.id * norm_proj_ty
  | PendingSymbolicInput of symbolic_pending_slot

type bound_inputs_outputs = {
  borrows : bound_borrow BorrowId.Map.t;
  symbolic : bound_symbolic SymbolicValueId.Map.t;
  all_bindings : (BorrowId.id, norm_symb_proj) Either.t list;
      (** We use this to remember the order in which values were inserted: we
          use this to properly order the outputs of the composed continuation.

          Note that as we do not store the projectors and as we allow removing
          values from the maps above, the values in [all_bindings] may contain
          duplicates, or may contain values which are not actually bound anymore
          (this is fine, because we only use this list to give us an order). *)
  input_loans : (AbsFVarId.id * proj_marker list * ty) BorrowId.Map.t;
      (** Map from an input loan id to:
          - the free variable introduced to re-bind it
          - the list of projection markers encountered in the merged
            continuations (we collect the list of projection markers to compute
            their union: the merged continuation will use the union) *)
  input_symbolic : (AbsFVarId.id * proj_marker list * ty) NormSymbProjMap.t;
      (** Distinct views of one symbolic value are distinct continuation inputs.
      *)
  input_pending :
    (norm_proj_ty * AbsFVarId.id * proj_marker list * ty) list BorrowId.Map.t;
      (** Deferred inputs have their own namespace and retain their region mask.
      *)
  input_pending_symbolic :
    (AbsFVarId.id * proj_marker list * ty) SymbolicPendingSlotMap.t;
  pending_symbolic_scopes : pending_symbolic_scope SymbolicPendingSlotMap.t;
  all_input_bindings : input_binding list;
      (** Same purpose as [all_bindings], but for the inputs *)
}

let bound_borrow_to_string ((bid, b) : BorrowId.id * bound_borrow) : string =
  Print.list_to_string
    (fun (pm, fid, _ty) ->
      "fv@" ^ AbsFVarId.to_string fid ^ " <- "
      ^ Print.Values.add_proj_marker pm ("l@" ^ BorrowId.to_string bid))
    b

let bound_symbolic_to_string (ctx : eval_ctx)
    ((sid, b) : SymbolicValueId.id * bound_symbolic) : string =
  Print.list_to_string
    (fun (pm, norm_proj_ty, fid, _ty) ->
      "fv@" ^ AbsFVarId.to_string fid ^ " <- "
      ^ Print.Values.add_proj_marker pm
          ("s@"
          ^ SymbolicValueId.to_string sid
          ^ " <: "
          ^ ty_to_string ctx norm_proj_ty))
    b

let input_loan_to_string
    ((bid, (fid, pml, _ty)) :
      BorrowId.id * (AbsFVarId.id * proj_marker list * ty)) : string =
  let bid = BorrowId.to_string bid in
  "fv@" ^ AbsFVarId.to_string fid ^ " <- "
  ^ Print.list_to_string (fun pm -> Print.Values.add_proj_marker pm bid) pml

let input_symbolic_to_string (ctx : eval_ctx)
    ((proj, (fid, pml, _ty)) :
      norm_symb_proj * (AbsFVarId.id * proj_marker list * ty)) : string =
  let sv =
    "s@"
    ^ SymbolicValueId.to_string proj.sv_id
    ^ " <: "
    ^ ty_to_string ctx proj.norm_proj_ty
  in
  "fv@" ^ AbsFVarId.to_string fid ^ " <- "
  ^ Print.list_to_string (fun pm -> Print.Values.add_proj_marker pm sv) pml

let bound_inputs_outputs_to_string (ctx : eval_ctx) (b : bound_inputs_outputs) :
    string =
  let {
    borrows;
    symbolic;
    all_bindings;
    input_loans;
    input_symbolic;
    input_pending = _;
    input_pending_symbolic = _;
    pending_symbolic_scopes = _;
    all_input_bindings;
  } =
    b
  in
  let bindings_to_string (bindings : (loan_id, norm_symb_proj) Either.t list) :
      string =
    Print.list_to_string
      (fun x ->
        match x with
        | Either.Left lid -> "l@" ^ BorrowId.to_string lid
        | Right proj -> norm_symb_proj_to_string ctx proj)
      bindings
  in
  "{\n  borrows: "
  ^ Print.list_to_string bound_borrow_to_string (BorrowId.Map.bindings borrows)
  ^ "\n  symbolic: "
  ^ Print.list_to_string
      (bound_symbolic_to_string ctx)
      (SymbolicValueId.Map.bindings symbolic)
  ^ "\n  all_bindings: "
  ^ bindings_to_string all_bindings
  ^ "\n  input_loans: "
  ^ Print.list_to_string input_loan_to_string
      (BorrowId.Map.bindings input_loans)
  ^ "\n  input_symbolic: "
  ^ Print.list_to_string
      (input_symbolic_to_string ctx)
      (NormSymbProjMap.bindings input_symbolic)
  ^ "\n  input_bindings: "
  ^ Print.list_to_string
      (function
        | ConcreteInput bid -> "l@" ^ BorrowId.to_string bid
        | SymbolicInput proj -> norm_symb_proj_to_string ctx proj
        | PendingInput (bid, _) -> "pending@" ^ BorrowId.to_string bid
        | PendingSymbolicInput slot -> show_symbolic_pending_slot slot)
      all_input_bindings
  ^ "\n}"

let bound_inputs_outputs_add_borrow (span : Meta.span) (bid : BorrowId.id)
    (pm : proj_marker) (fvid : AbsFVarId.id) (ty : ty)
    (out : bound_inputs_outputs) : bound_inputs_outputs =
  let borrow = (pm, fvid, ty) in
  let borrows =
    BorrowId.Map.update bid
      (fun bound ->
        match bound with
        | None -> Some [ borrow ]
        | Some bound ->
            [%sanity_check] span
              (List.for_all
                 (fun (pm', _, _) -> not (proj_markers_intersect pm pm'))
                 bound);
            Some (borrow :: bound))
      out.borrows
  in
  { out with borrows; all_bindings = Left bid :: out.all_bindings }

(** Given an input loan, consume a registered output borrow. If there is no such
    output borrow, register the input (it will be an input of the composed
    continuation. *)
let bound_inputs_outputs_update_input_loan (span : Meta.span)
    (bid : BorrowId.id) (ty : ty) (pm : proj_marker)
    (out : bound_inputs_outputs) : bound_inputs_outputs * tevalue =
  let outputs = BorrowId.Map.find_opt bid out.borrows in
  let outputs =
    Option.bind outputs (fun bindings ->
        if
          List.exists
            (fun (marker, _, _) -> proj_markers_intersect pm marker)
            bindings
        then Some bindings
        else None)
  in
  match outputs with
  | None ->
      (* There is no corresponding input value: check if we already introduced a
       free variable for this loan (for a complementary projector), if not,
       introduce a fresh free variable *)
      let fid, input_loans =
        match BorrowId.Map.find_opt bid out.input_loans with
        | None ->
            let fid = fresh_abs_fvar_id () in
            (fid, BorrowId.Map.add bid (fid, [ pm ], ty) out.input_loans)
        | Some (fid, pml, ty') ->
            (fid, BorrowId.Map.add bid (fid, pm :: pml, ty') out.input_loans)
      in
      let v : tevalue = { value = EFVar fid; ty } in
      let out =
        {
          out with
          input_loans;
          all_input_bindings = ConcreteInput bid :: out.all_input_bindings;
        }
      in
      (* *)
      (out, v)
  | Some bound ->
      (* There is a corresponding output value: consume it *)
      (* Filter the bound values which intersect the current proj marker *)
      let bound, bound' =
        List.partition (fun (pm', _, _) -> proj_markers_intersect pm pm') bound
      in
      let bound, value =
        match (pm, bound) with
        | PLeft, [ (PLeft, fvid, ty) ] -> ([], { value = EFVar fvid; ty })
        | PRight, [ (PRight, fvid, ty) ] -> ([], { value = EFVar fvid; ty })
        | PLeft, [ (PNone, fvid, ty) ] ->
            ([ (PRight, fvid, ty) ], { value = EFVar fvid; ty })
        | PRight, [ (PNone, fvid, ty) ] ->
            ([ (PLeft, fvid, ty) ], { value = EFVar fvid; ty })
        | PNone, [ (PNone, fvid, ty) ] -> ([], { value = EFVar fvid; ty })
        | ( PNone,
            ( [ (PLeft, fvidl, tyl); (PRight, fvidr, tyr) ]
            | [ (PRight, fvidr, tyr); (PLeft, fvidl, tyl) ] ) ) ->
            let lv : tevalue = { value = EFVar fvidl; ty = tyl } in
            let rv : tevalue = { value = EFVar fvidr; ty = tyr } in
            ([], { value = EJoinMarkers (lv, rv); ty = tyl })
        | _ ->
            [%ldebug
              "- pm: " ^ show_proj_marker pm ^ "\n- bound:\n"
              ^ bound_borrow_to_string (bid, bound)];
            [%internal_error] span
      in
      let out =
        let bound =
          match bound @ bound' with
          | [] -> None
          | l -> Some l
        in
        {
          out with
          borrows = BorrowId.Map.update bid (fun _ -> bound) out.borrows;
        }
      in
      (out, value)

let bound_inputs_outputs_add_symbolic (sid : SymbolicValueId.id)
    (pm : proj_marker) (proj_ty : norm_proj_ty) (fvid : AbsFVarId.id) (ty : ty)
    (out : bound_inputs_outputs) : bound_inputs_outputs =
  let s = (pm, proj_ty, fvid, ty) in
  let symbolic =
    SymbolicValueId.Map.update sid
      (fun bound ->
        match bound with
        | None -> Some [ s ]
        | Some bound -> Some (s :: bound))
      out.symbolic
  in
  let key : norm_symb_proj = { sv_id = sid; norm_proj_ty = proj_ty } in
  { out with symbolic; all_bindings = Right key :: out.all_bindings }

let bound_inputs_outputs_update_input_symbolic (span : Meta.span)
    (ctx : eval_ctx) (sid : SymbolicValueId.id) (pm : proj_marker) (ty : ty)
    (proj_ty : norm_proj_ty) (out : bound_inputs_outputs) :
    bound_inputs_outputs * tevalue =
  let key : norm_symb_proj = { sv_id = sid; norm_proj_ty = proj_ty } in
  let register_input () =
    (* Complementary views share a parameter only when their whole masks agree. *)
(* ```ocaml *)
    let binding =
      match NormSymbProjMap.find_opt key out.input_symbolic with
      | Some binding -> Some (key, binding)
      | None ->
          NormSymbProjMap.fold
            (fun (candidate : norm_symb_proj) binding found ->
              if candidate.sv_id = sid
                 && norm_proj_tys_equal span ctx candidate.norm_proj_ty proj_ty
              then (
                [%cassert] span (found = None)
                  "A symbolic input has multiple equal ownership masks.";
                Some (candidate, binding))
              else found)
            out.input_symbolic None
    in
    let key, fid, input_symbolic =
      match binding with
      | None ->
          let fid = fresh_abs_fvar_id () in
          (key, fid, NormSymbProjMap.add key (fid, [ pm ], ty) out.input_symbolic)
      | Some (key, (fid, pml, ty')) ->
          (key, fid, NormSymbProjMap.add key (fid, pm :: pml, ty') out.input_symbolic)
    in
    let v : tevalue = { value = EFVar fid; ty } in
    let out =
      {
        out with
        input_symbolic;
        all_input_bindings = SymbolicInput key :: out.all_input_bindings;
      }
    in
    (* *)
    (out, v)
  in
  match SymbolicValueId.Map.find_opt sid out.symbolic with
  | None -> register_input ()
  | Some bound ->
      (* There is a corresponding output value: consume it *)
      (* Filter the bound values which intersect the current proj marker and projection *)
      let bound, bound' =
        List.partition
          (fun (pm', proj_ty', _, _) ->
            proj_markers_intersect pm pm'
            && norm_proj_tys_intersect span ctx proj_ty proj_ty')
          bound
      in
      if bound = [] then register_input ()
      else
        let bound, value =
          match (pm, bound) with
          | PLeft, [ (PLeft, proj_ty', fvid, ty) ] ->
              [%cassert] span (norm_proj_tys_equal span ctx proj_ty' proj_ty)
                "Symbolic continuation masks do not match.";
              ([], { value = EFVar fvid; ty })
          | PLeft, [ (PNone, proj_ty', fvid, ty) ] ->
              [%cassert] span (norm_proj_tys_equal span ctx proj_ty' proj_ty)
                "Symbolic continuation masks do not match.";
              ([ (PRight, proj_ty', fvid, ty) ], { value = EFVar fvid; ty })
          | PRight, [ (PRight, proj_ty', fvid, ty) ] ->
              [%cassert] span (norm_proj_tys_equal span ctx proj_ty' proj_ty)
                "Symbolic continuation masks do not match.";
              ([], { value = EFVar fvid; ty })
          | PRight, [ (PNone, proj_ty', fvid, ty) ] ->
              [%cassert] span (norm_proj_tys_equal span ctx proj_ty' proj_ty)
                "Symbolic continuation masks do not match.";
              ([ (PLeft, proj_ty', fvid, ty) ], { value = EFVar fvid; ty })
          | PNone, [ (PNone, proj_ty', fvid, ty') ] ->
              [%cassert] span (norm_proj_tys_equal span ctx proj_ty' proj_ty)
                "Symbolic continuation masks do not match.";
              ([], { value = EFVar fvid; ty = ty' })
          | ( PNone,
              ( [ (PLeft, proj_tyl, fvidl, tyl); (PRight, proj_tyr, fvidr, tyr) ]
              | [
                  (PRight, proj_tyr, fvidr, tyr); (PLeft, proj_tyl, fvidl, tyl);
                ] ) ) ->
              [%cassert] span (norm_proj_tys_equal span ctx proj_tyl proj_ty)
                "Symbolic continuation masks do not match.";
              [%cassert] span (norm_proj_tys_equal span ctx proj_tyr proj_ty)
                "Symbolic continuation masks do not match.";
(* ``` *)
              let lv : tevalue = { value = EFVar fvidl; ty = tyl } in
              let rv : tevalue = { value = EFVar fvidr; ty = tyr } in
              ([], { value = EJoinMarkers (lv, rv); ty = tyl })
          | _ -> [%internal_error] span
        in
        let out =
          let bound =
            match bound @ bound' with
            | [] -> None
            | l -> Some l
          in
          {
            out with
            symbolic =
              SymbolicValueId.Map.update sid (fun _ -> bound) out.symbolic;
          }
        in
        (out, value)

let bound_inputs_outputs_update_pending (bid : BorrowId.id) pm ty proj_ty
    (out : bound_inputs_outputs) : bound_inputs_outputs * tevalue =
  let entries =
    Option.value (BorrowId.Map.find_opt bid out.input_pending) ~default:[]
  in
  let rec register = function
    | [] ->
        let fid = fresh_abs_fvar_id () in
        (fid, [ (proj_ty, fid, [ pm ], ty) ])
    | (mask, fid, markers, original_ty) :: rest when mask = proj_ty ->
        let markers = if List.mem pm markers then markers else pm :: markers in
        (fid, (mask, fid, markers, original_ty) :: rest)
    | entry :: rest ->
        let fid, rest = register rest in
        (fid, entry :: rest)
  in
  let fid, entries = register entries in
  let out =
    {
      out with
      input_pending = BorrowId.Map.add bid entries out.input_pending;
      all_input_bindings = PendingInput (bid, proj_ty) :: out.all_input_bindings;
    }
  in
  (out, { value = EFVar fid; ty })

let bound_inputs_outputs_update_pending_symbolic span pm
    (slot : symbolic_pending_slot) (out : bound_inputs_outputs) :
    bound_inputs_outputs * tevalue =
  let fid, entries =
    match SymbolicPendingSlotMap.find_opt slot out.input_pending_symbolic with
    | None ->
        let fid = fresh_abs_fvar_id () in
        (fid, (fid, [ pm ], slot.proj_ty))
    | Some (fid, markers, ty) ->
        [%cassert] span (ty = slot.proj_ty)
          "A pending symbolic parameter changes its complete type";
        let markers = if List.mem pm markers then markers else pm :: markers in
        (fid, (fid, markers, ty))
  in
  let out =
    {
      out with
      input_pending_symbolic =
        SymbolicPendingSlotMap.add slot entries out.input_pending_symbolic;
      all_input_bindings =
        PendingSymbolicInput slot :: out.all_input_bindings;
    }
  in
  (out, { value = EFVar fid; ty = slot.proj_ty })

let tevalue_get_max_level ctx regions (v : tevalue) : int =
  let max_level = ref (-1) in
  let visitor =
    (* We count the ended loans: we want to decompose if we see something like this
       (the loan in the given back sub-value was ended):
       {[
         @ended_ignored_mut_borrow{
           child: (s@37 <: core::slice::iter::IterMut<'23, u16>);
           given_back: ended_eproj_loans) :=
         FunCall(abs_id@43)[...]
       ]}
     *)
    InterpBorrowsCore.get_max_sub_abs_visitor ~with_evalues:true
      ~with_ended:true
      ~pending_regions:regions
      ~pending_borrow_ty:(ty_has_mut_borrow_for_region_in_set ctx.type_ctx.type_infos)
      max_level
  in
  visitor#visit_tevalue 0 v;
  !max_level

(** Bind the outputs from an abs continuation.

    See the documentation of [abs_cont].

    We return the pattern (derived from the output) and the updated input (we
    might have replaced some loans with free variables, in case the output of
    the corresponding borrows were bound elsewhere). *)
let bind_outputs_from_output_input (span : Meta.span) (ctx : eval_ctx)
    (regions : RegionId.Set.t) (bound : bound_inputs_outputs ref)
    (output : tevalue) (input : tevalue) : tepat * tevalue =
  let describe_symbolic_binding () =
    "Nested symbolic continuation binding:\n- output:\n"
    ^ tevalue_to_string ctx output
    ^ "\n- input:\n"
    ^ tevalue_to_string ctx input
  in
  let scopes = Dynarray.create () in
  let rec pattern_arity (pat : tepat) =
    match pat.pat with
    | PBound -> 1
    | PIgnored -> 0
    | PAdt (_, fields) ->
        List.fold_left (fun count pat -> count + pattern_arity pat) 0 fields
    | POpen _ -> [%craise] span "Expected a closed continuation pattern"
  in
  (* Update the input value by substituting expressions (such as a mutable loan)
     whose input have been bound earlier (because we bound an abstraction continuation
     earlier which has a mutable borrow corresponding to this mutable loan) *)
  let rec update_input (regions : RegionId.Set.t) (input : tevalue) : tevalue =
    match input.value with
    (*
```ocaml
    *)
    | ETransportedValue (transport, child) ->
        let child' = update_input transport.current_regions child in
        if child' == child then input
        else { input with value = ETransportedValue (transport, child') }
    | ESymbolic (pm, ETransportedProj (transport, child)) ->
        let child = { value = ESymbolic (pm, child);
                      ty = transport.current.sv_ty } in
        let child = update_input transport.current_regions child in
        { input with value = ETransportedValue (transport, child) }
    (*
```
    *)
    | ECallProtocol (positions, body) ->
        { input with value = ECallProtocol (positions, update_input regions body) }
    | ECallEndpoints (witnesses, body) ->
        { input with value = ECallEndpoints (witnesses, update_input regions body) }
    | ELet (regions', pat, bvalue, next) ->
        (* Replacements are free variables (or joins of free variables), so
           they cannot capture these local binders. Keep the binders closed
           instead of repeatedly reopening and closing entire suffixes. *)
        let bvalue' = update_input regions' bvalue in
        Dynarray.add_last scopes (pattern_arity pat);
        let next' = update_input regions next in
        ignore (Dynarray.pop_last scopes);
        if bvalue' == bvalue && next' == next then input
        else { value = ELet (regions', pat, bvalue', next'); ty = next'.ty }
    | EJoinMarkers (left, right) ->
        let left = update_input regions left in
        let right = update_input regions right in
        { input with value = EJoinMarkers (left, right) }
    | EApp (f, args) ->
        let args = List.map (List.map (update_input regions)) args in
        { input with value = EApp (f, args) }
    | ERecombine (base, suppliers) ->
        let base = update_input regions base in
        let suppliers =
          List.map
            (fun (meta, value) -> (meta, update_input regions value))
            suppliers
        in
        { input with value = ERecombine (base, suppliers) }
    | EFVar _ -> input
    | EBVar var ->
        let frame = Dynarray.length scopes - var.scope - 1 in
        let index = AbsBVarId.to_int var.bvar_id in
        [%cassert] span
          (var.scope >= 0 && frame >= 0 && index >= 0
          && index < Dynarray.get scopes frame)
          "Unbound continuation variable";
        input
    | EBottom -> [%craise] span "Unreachable"
    | EAdt adt ->
        let fields = List.map (update_input regions) adt.fields in
        {
          value =
            EAdt
              {
                borrow_proj = adt.borrow_proj;
                variant_id = adt.variant_id;
                fields;
              };
          ty = input.ty;
        }
    | ELoan loan ->
        (* Check if this loan was previously bound *)
        begin
          match loan with
          | EMutLoan (pm, bid, child) ->
              [%cassert] span (is_eignored child.value) "Unimplemented";
              let bound', e =
                bound_inputs_outputs_update_input_loan span bid input.ty pm
                  !bound
              in
              bound := bound';
              e
          | EEndedMutLoan ended ->
              (* Ending the outer loan can leave live, same-level ownership
                 in its child. The given-back expression belongs to the next
                 level and must remain intact. *)
              let child = update_input regions ended.child in
              if child == ended.child then input
              else
                {
                  input with
                  value = ELoan (EEndedMutLoan { ended with child });
                }
          | EIgnoredMutLoan (pm, lid, child) ->
              {
                input with
                value =
                  ELoan (EIgnoredMutLoan (pm, lid, update_input regions child));
              }
          | EEndedIgnoredMutLoan ended ->
              let child = update_input regions ended.child in
              if child == ended.child then input
              else
                {
                  input with
                  value = ELoan (EEndedIgnoredMutLoan { ended with child });
                }
        end
    | ESymbolic (pm, proj) -> begin
        match proj with
        | EPendingLoans bid ->
            let mask = normalize_proj_ty ctx.type_ctx.type_infos regions input.ty in
            let updated, value =
              bound_inputs_outputs_update_pending bid pm input.ty mask !bound
            in
            bound := updated;
            value
        | EPendingSymbolicLoans slot ->
            [%cassert] span (input.ty = slot.proj_ty)
              "A pending symbolic input changes its complete type";
            let updated, value =
              bound_inputs_outputs_update_pending_symbolic span pm slot !bound
            in
            bound := updated;
            value
        | EProjLoans { proj; consumed; borrows } ->
            (* Not sure what to do in the following cases *)
            let () =
              if not (consumed = [] && borrows = []) then
                [%craise] span (describe_symbolic_binding ())
            in
            (* Check if this projection was previously bound *)
            let ty = proj.proj_ty in
            let norm_proj_ty = normalize_proj_ty ctx.type_ctx.type_infos regions ty in
            let bound', e =
              bound_inputs_outputs_update_input_symbolic span ctx proj.sv_id pm
                ty norm_proj_ty !bound
            in
            bound := bound';
            e
        | EEndedProjLoans { proj = _; consumed; borrows } ->
            (* Ending the intersecting borrow projectors gave values back to
               this loan projector (the [consumed] values, e.g., when a call
               abstraction whose borrow projector reborrowed the loans ended
               before a join). Like the given-back value of an ended mutable
               loan, they are the input of the continuation and must remain
               intact. *)
            let () =
              if
                not
                  (List.for_all (fun (_, child) -> child = EEmpty) consumed
                  && borrows = [])
              then [%craise] span (describe_symbolic_binding ())
            in
            input
        | EProjBorrows { proj; loans } ->
            let () =
              if not (loans = []) then
                [%craise] span (describe_symbolic_binding ())
            in
            let mask =
              normalize_proj_ty ctx.type_ctx.type_infos regions proj.proj_ty
            in
            let suppliers =
              Option.value
                (SymbolicValueId.Map.find_opt proj.sv_id !bound.symbolic)
                ~default:[]
            in
            [%cassert] span
              (List.exists
                 (fun (marker, supplier_mask, _, _) ->
                   proj_markers_intersect pm marker && supplier_mask = mask)
                 suppliers)
              "A returned borrow projection has no physical output supplier";
            let updated, supplier =
              bound_inputs_outputs_update_input_symbolic span ctx proj.sv_id pm
                proj.proj_ty mask !bound
            in
            bound := updated;
            supplier
        | EEndedProjBorrows _ ->
            [%craise] span (describe_symbolic_binding ())
        | EEmpty ->
            (* We shouldn't get here? *)
            [%craise] span "Unexpected"
        | ETransportedProj _ -> [%internal_error] span
      end
    | EBorrow _ ->
        [%craise] span "Nested borrows are not supported yet in this case"
    | EMutBorrowInput x ->
        { input with value = EMutBorrowInput (update_input regions x) }
    | EValue _ | EIgnored -> input
  in
  let rec bind_output (regions : RegionId.Set.t) (output : tevalue) : tepat =
    match output.value with
    (*
```ocaml
    *)
    | ETransportedValue (transport, child) ->
        bind_output transport.current_regions child
    | ESymbolic (pm, ETransportedProj (transport, child)) ->
        bind_output transport.current_regions
          { value = ESymbolic (pm, child); ty = transport.current.sv_ty }
    (*
```
    *)
    | ELet _ | EJoinMarkers _ | ERecombine _ | ECallProtocol _
    | ECallEndpoints _ | EBVar _ | EFVar _ | EApp _ | EMutBorrowInput _ ->
        (* Those expressions should not appear in the *output* expression
           (some of them might appear only in the *input* expression) *)
        [%craise] span ("Unexpected expression: " ^ tevalue_to_string ctx output)
    | EBottom ->
        (* We're not inside a loan or a borrow: simply ignore it *)
        { pat = PIgnored; ty = output.ty }
    | EAdt adt ->
        let pats = List.map (bind_output regions) adt.fields in
        { pat = PAdt (adt.variant_id, pats); ty = output.ty }
    | ELoan loan -> (
        match loan with
        | EIgnoredMutLoan (_, _, child) -> bind_output regions child
        | EMutLoan (_, _, child) ->
            [%cassert] span (is_eignored child.value)
              "A current output loan retains an owned child";
            bind_output regions child
        | EEndedMutLoan { child; given_back; _ }
        | EEndedIgnoredMutLoan { child; given_back; _ } ->
            let () =
              if not (tevalue_get_max_level ctx regions given_back < 0) then
                [%craise] span
                  ("A returned loan supplier was not decomposed:\n"
                  ^ describe_symbolic_binding ())
            in
            bind_output regions child)
    | EBorrow borrow ->
        (* Two cases depending on whether we are inside a loan or not *)
        begin
          match borrow with
          | EMutBorrow (pm, bid, child) ->
              [%cassert] span (is_eignored child.value) "Unimplemented";
              (* Compute the binding pattern *)
              let fid = fresh_abs_fvar_id () in
              let pat : tepat = { pat = POpen fid; ty = output.ty } in
              (* We need to register the binding *)
              bound :=
                bound_inputs_outputs_add_borrow span bid pm fid output.ty !bound;
              (* *)
              pat
          | EEndedIgnoredMutBorrow { child; given_back; given_back_meta = _ } ->
              (* The retained child is at the current level; [given_back] is
                 an input of the next continuation level. Decomposition must
                 have moved every real projection there into the call inputs
                 before we bind outputs. Inspect that value, not its type:
                 an ignored view can still mention mutable captures owned by
                 another receiver region. *)
              let () =
                if not (tevalue_get_max_level ctx regions given_back < 0) then
                  [%craise] span
                    ("Retained given-back continuation was not decomposed:\n"
                    ^ describe_symbolic_binding ())
              in
              bind_output regions child
          | EIgnoredMutBorrow (_, child) -> bind_output regions child
          | EEndedMutBorrow _ ->
              (* We shouldn't get there. If we find an ended borrow in a region
                 abstraction it means the abstraction was ended and thus removed
                 from the context: we shouldn't be in the process of merging it...
              *)
              [%craise] span "Unexpected"
        end
    | ESymbolic (pm, proj) ->
        (* If we get here it means the symbolic value gets projected (we can't ignore it) *)
        begin
          match proj with
          | EPendingLoans _ | EPendingSymbolicLoans _
          | EProjLoans _ | EEndedProjLoans _ ->
              (* We shouldn't reach a loan which is not itself inside a borrow *)
              [%craise] span "Unexpected"
          | EProjBorrows { proj; loans } ->
              let () =
                if not (loans = []) then
                  [%craise] span (describe_symbolic_binding ())
              in
              (* Compute the binding pattern *)
              let { sv_id; proj_ty } : esymbolic_proj = proj in
              let fid = fresh_abs_fvar_id () in
              let pat : tepat = { pat = POpen fid; ty = output.ty } in
              (* We need to register the binding *)
              let norm_ty = normalize_proj_ty ctx.type_ctx.type_infos regions proj_ty in
              bound :=
                bound_inputs_outputs_add_symbolic sv_id pm norm_ty fid proj_ty
                  !bound;
              (* *)
              pat
          | EEndedProjBorrows _ ->
              (* Same remark as for the ended borrows above *)
              [%craise] span "Unexpected"
          | EEmpty ->
              (* We shouldn't get here? *)
              [%craise] span "Unexpected"
          | ETransportedProj _ -> [%internal_error] span
        end
    | EValue _ ->
        (* We're not inside a loan or a borrow: simply ignore it *)
        { pat = PIgnored; ty = output.ty }
    | EIgnored ->
        (* We're not inside a loan or a borrow: simply ignore it *)
        { pat = PIgnored; ty = output.ty }
  in
  let input = update_input regions input in
  let pat = bind_output regions output in
  (pat, input)

(** Retain each complete current producer before its partial field pattern. *)
let mk_current_carrier_let span regions (pat : tepat) (producer : tevalue)
    (next : tevalue) : tevalue =
  (* Classify positions. *)
  let rec slots pat =
    match pat.pat with
    | PIgnored -> 1
    | POpen _ | PBound -> 2
    (* Combine flags. *)
    | PAdt (_, fields) ->
        List.fold_left (fun mask field -> mask lor slots field) 0 fields
  in

  (* Preserve current source identity. *)
  let aliases = ref [] in
  let rec retain pat =
    match (pat.pat, pat.ty) with
    (* Keep nominal sources. *)
    | PAdt _, TAdt adt
      when slots pat = 3
           && (match adt.id with TAdtId _ -> true | _ -> false) ->
        (* Bind source. *)
        let source = mk_fresh_abs_fvar pat.ty in
        let () = aliases := (pat, source) :: !aliases in
        mk_epat_from_fvar source
    (* Inspect tuple fields. *)
    | PAdt (variant, fields), _ ->
        { pat with pat = PAdt (variant, List.map retain fields) }
    | _ -> pat
  in

  (* Keep ownership bindings. *)
  let whole_pat = retain pat in
  (* Restore field binders. *)
  let next =
    List.fold_left
      (fun next (fields, source) -> mk_let span regions fields source next)
      next !aliases
  in
  (* Bind each whole source. *)
  mk_let span regions whole_pat producer next

(** [child_side]: at the outermost level boundaries (the ended ignored borrows
    and loans, and the ended loans), project the borrowed value (the child) at
    [level] instead of the value given back at [level - 1] (see
    [abs_cont_destructure_self_fed_level2]). The boundaries below them follow
    the given-back side. *)
let project_output_at_level ?(child_side = false) span ctx regions
    (level : int) (v : tevalue) : tevalue =
  (*
```ocaml
  *)
  let rec project ~first regions level (v : tevalue) : tevalue =
    let project_coordinates regions level v = project ~first regions level v in
    let project ?(first = first) level v = project ~first regions level v in
    (*
```
    *)
    let boundary ~child ~given_back =
      if level = 0 || (first && child_side) then
        project ~first:false level child
      else project ~first:false (level - 1) given_back
    in
    let stop (v : tevalue) =
      if level = 0 then v else { v with value = EIgnored }
    in
    match v.value with
    (*
```ocaml
    *)
    | ETransportedValue (transport, child) ->
        let child = project_coordinates transport.current_regions level child in
        { value = ETransportedValue (transport, child); ty = child.ty }
    | ESymbolic (pm, ETransportedProj (transport, child)) ->
        let child = project_coordinates transport.current_regions level
          { value = ESymbolic (pm, child); ty = transport.current.sv_ty } in
        { value = ETransportedValue (transport, child); ty = child.ty }
    (*
```
    *)
    | ELet _ | EJoinMarkers _ | ERecombine _ | ECallProtocol _
    | ECallEndpoints _ | EBVar _ | EApp _ ->
        [%craise] span "Unimplemented"
    | EAdt { borrow_proj; variant_id; fields } ->
        let fields = List.map (project level) fields in
        { v with value = EAdt { borrow_proj; variant_id; fields } }
    | ELoan lc -> (
        match lc with
        | EMutLoan (pm, lid, child) ->
            let child = project level child in
            if level = 0 then
              { v with value = ELoan (EMutLoan (pm, lid, child)) }
            else child
        | EEndedMutLoan { child; given_back; given_back_meta = _; _ } ->
            boundary ~child ~given_back
        | EIgnoredMutLoan (pm, lid, child) ->
            (* A loan of another region which was not ended: like a loan of
               the abstraction, it is not a level boundary (its given-back value
               does not exist yet); its child holds the values of the owned
               regions at the current level *)
            let child = project level child in
            if level = 0 then
              { v with value = ELoan (EIgnoredMutLoan (pm, lid, child)) }
            else child
        | EEndedIgnoredMutLoan { child; given_back; _ } ->
            boundary ~child ~given_back)
    | EBorrow bc -> (
        match bc with
        | EMutBorrow (pm, bid, child) ->
            let child = project level child in
            if level = 0 then
              { v with value = EBorrow (EMutBorrow (pm, bid, child)) }
            else child
        | EIgnoredMutBorrow (bid, child) ->
            if level = 0 then project 0 child
            else if
              level = 1
              && ty_has_mut_borrow_for_region_in_set ctx.type_ctx.type_infos
                   regions child.ty
            then
              match bid with
              | Some bid ->
                  {
                    value = ESymbolic (PNone, EPendingLoans bid);
                    ty =
                      isolate_projection_ty ~refreshed:(ref RegionId.Map.empty)
                        ctx.type_ctx.type_infos regions ctx.fresh_region_id child.ty;
                  }
              | None -> project level child
            else project level child
        | EEndedMutBorrow (mv, child) ->
            let child = project level child in
            if level = 0 then
              { v with value = EBorrow (EEndedMutBorrow (mv, child)) }
            else child
        | EEndedIgnoredMutBorrow { child; given_back; given_back_meta = _ } ->
            boundary ~child ~given_back)
    | ESymbolic (pm, proj) -> (
        match proj with
        | EProjLoans { proj = _; consumed; borrows } ->
            [%cassert] span
              (consumed = [] && borrows = [])
              ("Nested symbolic level projection: " ^ string_of_int level ^ "\n"
             ^ show_tevalue v);
            stop v
        | EProjBorrows { proj; loans = _ :: _ as loans } -> (
            (* The loans are those of the value given back when an ancestor
               region ended: they are one level deeper than the borrows (see
               [visit_eproj_borrows] in [iter_eval_ctx_with_abs_levels]), as the
               given-back value of an [EEndedIgnoredMutBorrow]. *)
            if level = 0 then
              {
                v with
                value = ESymbolic (pm, EProjBorrows { proj; loans = [] });
              }
            else if first && child_side then stop v
            else
              match loans with
              | [ (_, given_back) ] ->
                  project ~first:false (level - 1)
                    { v with value = ESymbolic (pm, given_back) }
              | _ ->
                  [%craise] span
                    ("Nested symbolic level projection: " ^ string_of_int level
                   ^ "\n" ^ show_tevalue v))
        | EProjBorrows { proj = _; loans = [] } -> stop v
        | EEndedProjLoans { proj = _; consumed; borrows } ->
            [%cassert] span
              (consumed = [] && borrows = [])
              ("Nested symbolic level projection: " ^ string_of_int level ^ "\n"
             ^ show_tevalue v);
            stop v
        | EEndedProjBorrows { mvalues = _; loans } ->
            [%cassert] span (loans = [])
              ("Nested symbolic level projection: " ^ string_of_int level ^ "\n"
             ^ show_tevalue v);
            stop v
        | ETransportedProj _ -> [%internal_error] span
        | EPendingLoans _ | EPendingSymbolicLoans _ | EEmpty -> stop v)
    | EFVar _ | EIgnored -> stop v
    | EValue _ ->
        (* The retained value of a field of a nominal ADT which holds none of
           the projected borrows (see [InterpProjectors.apply_eproj_borrows]):
           it is the same at every level, where the stages which receive the
           whole ADT need it *)
        v
    | EMutBorrowInput _ | EBottom -> [%craise] span "Unreachable"
  in
  project ~first:true regions level v

let project_avalue_to_evalue span (ctx : eval_ctx) (abs : abs) =
  (*
```ocaml
  *)
  let rec aproj_has_mut_state regions outer_ty proj =
    let has_mut_projection_ty =
      ty_has_mut_borrow_for_region_in_set ctx.type_ctx.type_infos regions in
    let children xs =
      List.exists (fun (_, child) -> aproj_has_mut_state regions outer_ty child) xs
    in
    (*
```
    *)
    match proj with
    | ATransportedProj (transport, child) ->
        aproj_has_mut_state transport.current_regions transport.current.sv_ty child
    | AProjLoans { proj; consumed; borrows } ->
        has_mut_projection_ty proj.proj_ty
        || children consumed || children borrows
    | AProjBorrows { proj; loans } ->
        has_mut_projection_ty proj.proj_ty || children loans
    | AEndedProjLoans { consumed; borrows; _ } ->
        has_mut_projection_ty outer_ty || children consumed || children borrows
    | AEndedProjBorrows { loans; _ } ->
        has_mut_projection_ty outer_ty || children loans
    | APendingLoans _ -> has_mut_projection_ty outer_ty
    | APendingSymbolicLoans slot -> has_mut_projection_ty slot.proj_ty
    | AEmpty -> false
  in
  let rec eproj_of_aproj (proj : aproj) : eproj =
    let children xs =
      List.map (fun (meta, child) -> (meta, eproj_of_aproj child)) xs
    in
    match proj with
    | ATransportedProj (transport, child) ->
        ETransportedProj (transport, eproj_of_aproj child)
    | AProjLoans { proj = { sv_id; proj_ty }; consumed; borrows } ->
        EProjLoans
          {
            proj = { sv_id; proj_ty };
            consumed = children consumed;
            borrows = children borrows;
          }
    | AProjBorrows { proj = { sv_id; proj_ty }; loans } ->
        EProjBorrows { proj = { sv_id; proj_ty }; loans = children loans }
    | AEndedProjLoans { proj; consumed; borrows } ->
        EEndedProjLoans
          { proj; consumed = children consumed; borrows = children borrows }
    | AEndedProjBorrows { mvalues; loans } ->
        EEndedProjBorrows { mvalues; loans = children loans }
    | APendingLoans bid -> EPendingLoans bid
    | APendingSymbolicLoans slot -> EPendingSymbolicLoans slot
    | AEmpty -> EEmpty
  in
  let rec evalue_of_avalue regions (x : tavalue) : tevalue =
    let child = evalue_of_avalue regions in
    let value =
      match x.value with
      | ATransportedValue (transport, inner) ->
          ETransportedValue
            (transport, evalue_of_avalue transport.current_regions inner)
      | AIgnored _ -> EIgnored
      | AAdt adt ->
          EAdt
            {
              borrow_proj = adt.borrow_proj;
              variant_id = adt.variant_id;
              fields = List.map child adt.fields;
            }
      | ASymbolic (pm, proj) ->
          if aproj_has_mut_state regions x.ty proj then
            ESymbolic (pm, eproj_of_aproj proj)
          else EIgnored
      | ALoan lc -> (
          match lc with
          | AMutLoan (pm, bid, av) -> ELoan (EMutLoan (pm, bid, child av))
          | AIgnoredMutLoan (pm, bid, av) -> ELoan (EIgnoredMutLoan (pm, bid, child av))
          | AEndedMutLoan lc ->
              ELoan
                (EEndedMutLoan
                   {
                     child = child lc.child;
                     given_back = child lc.given_back;
                     given_back_meta = lc.given_back_meta;
                     physical_returns = [];
                   })
          | AEndedIgnoredMutLoan lc ->
              ELoan
                (EEndedIgnoredMutLoan
                   {
                     child = child lc.child;
                     given_back = child lc.given_back;
                     given_back_meta = lc.given_back_meta;
                     given_back_env = lc.given_back_env;
                     physical_returns = [];
                   })
          | ASharedLoan (_, _, _, av)
          | AEndedSharedLoan (_, _, av)
          | AIgnoredSharedLoan av -> (child av).value)
      | ABorrow bc -> (
          match bc with
          | AMutBorrow (pm, bid, av) -> EBorrow (EMutBorrow (pm, bid, child av))
          | AIgnoredMutBorrow (bid, av) ->
              EBorrow (EIgnoredMutBorrow (bid, child av))
          | AEndedIgnoredMutBorrow bc ->
              EBorrow
                (EEndedIgnoredMutBorrow
                   {
                     child = child bc.child;
                     given_back = child bc.given_back;
                     given_back_meta = bc.given_back_meta;
                   })
          | ASharedBorrow _ | AEndedSharedBorrow | AProjSharedBorrow _ ->
              EIgnored
          | AEndedMutBorrow _ -> [%internal_error] span)
    in
    { value; ty = x.ty }
  in
  evalue_of_avalue abs.regions.owned

(** Nested borrows, depth 2 (see [abs_cont_destructure_input_output_levels]):
    the continuation of a call whose output holds, at level 2, only borrows of
    loans of level 1 which the same output holds on the given-back side.

    Input [&'c mut C] of the call, [C] holding [&'a mut F] and [F] holding
    borrows of the region [r] of the abstraction (e.g., a closure which captures
    a closure which captures a mutable borrow, passed by mutable reference). The
    positions of [r] are [cc] (level 0: the borrows the call consumed), [cg]
    (level 1: the value given back to [&'a mut F] when ['a] ends), [gc] (level
    1: the borrows of [r] in the [C] given back through [&'c mut C]) and [gg]
    (level 2: the value given back to the reborrow of [F] in that [C]). The
    staged backward function computes [gg] from [cg] (stage 1), then [cc] from
    [gc] (stage 2) (design section 1). When the caller dropped the given-back
    [C], the borrows of [gg] are those of the loans of [gc]: the continuation
    applies stage 1 to [cg] (the outputs of level 2, [EFunCallOutputs]) and
    gives these outputs to stage 2 as the values of the loans of [gc], as the
    translation of the end of the call does without a join. Returns the
    destructured continuation and the ids of these borrows (internal to the
    abstraction), or [None] for any other shape. *)
let abs_cont_destructure_self_fed_level2 (span : Meta.span) (ctx : eval_ctx)
    (regions : RegionId.Set.t) (abs_id : abs_id) (args : tevalue list list)
    (output : tevalue) (input : tevalue) :
    (tevalue * tevalue * BorrowId.Set.t) option =
  let project ?child_side level =
    project_output_at_level ?child_side span ctx regions level output
  in
  let has_state (v : tevalue) : bool =
    let visitor =
      object
        inherit [_] iter_tevalue
        method! visit_EBorrow _ _ = raise Utils.Found
        method! visit_ELoan _ _ = raise Utils.Found

        method! visit_ESymbolic _ _ proj =
          match proj with
          | EEmpty -> ()
          | _ -> raise Utils.Found
      end
    in
    try
      visitor#visit_tevalue () v;
      false
    with Utils.Found -> true
  in
  let exception Unsupported in
  (* The outputs of level 2, and the free variables bound to them *)
  let outputs2 = ref BorrowId.Map.empty in
  let rec pat_of (v : tevalue) : tepat =
    match v.value with
    | EAdt adt ->
        { pat = PAdt (adt.variant_id, List.map pat_of adt.fields); ty = v.ty }
    | EBorrow (EMutBorrow (PNone, bid, child))
      when is_eignored child.value && not (BorrowId.Map.mem bid !outputs2) ->
        let fid = fresh_abs_fvar_id () in
        outputs2 := BorrowId.Map.add bid fid !outputs2;
        { pat = POpen fid; ty = v.ty }
    | EIgnored | EValue _ -> { pat = PIgnored; ty = v.ty }
    | _ -> raise Unsupported
  in
  let used = ref BorrowId.Set.empty in
  let feed =
    object
      inherit [_] map_tevalue as super

      method! visit_tevalue env v =
        match v.value with
        | ELoan (EMutLoan (PNone, bid, child))
          when is_eignored child.value && BorrowId.Map.mem bid !outputs2 ->
            if BorrowId.Set.mem bid !used then raise Unsupported;
            used := BorrowId.Set.add bid !used;
            { v with value = EFVar (BorrowId.Map.find bid !outputs2) }
        | _ -> super#visit_tevalue env v
    end
  in
  try
    (* The child side holds nothing at level 2 *)
    if has_state (project ~child_side:true 2) then raise Unsupported;
    let outputs2_value = project 2 in
    let pat = pat_of outputs2_value in
    let fed = feed#visit_tevalue () (project 1) in
    if
      BorrowId.Map.is_empty !outputs2
      || BorrowId.Set.cardinal !used <> BorrowId.Map.cardinal !outputs2
    then raise Unsupported;
    (* The child side has no values for the positions of the other regions
       (e.g., the other captures of [C]): the stage receives the whole ADT,
       whose other fields it does not read (their placeholders are the values
       given back on the given-back side, as for the inputs of level 1). *)
    let rec placeholders (v : tevalue) (given_back : tevalue) : tevalue =
      match (v.value, given_back.value) with
      | EIgnored, EValue _ -> given_back
      | EAdt adt, EAdt adt'
        when adt.variant_id = adt'.variant_id
             && List.length adt.fields = List.length adt'.fields ->
          {
            v with
            value =
              EAdt
                {
                  adt with
                  fields = List.map2 placeholders adt.fields adt'.fields;
                };
          }
      | _ -> v
    in
    let inputs1 = placeholders (project ~child_side:true 1) (project 1) in
    let stage1 : tevalue =
      {
        value = EApp (EFunCallOutputs (abs_id, 0, 2), [ [ inputs1 ] ]);
        ty = outputs2_value.ty;
      }
    in
    let call = { input with value = EApp (EFunCall abs_id, [ fed ] :: args) } in
    Some
      ( project 0,
        mk_current_carrier_let span regions pat stage1 call,
        !used )
  with Unsupported -> None

(** Small trick to handle nested borrows.

    Considering the code below:
    {[
      struct IterMut<'a, T> {
          v : Option<&'a mut T>,
      }

      impl<'a, T> IterMut<'a, T> {
          fn next(&mut self) -> Option<&'a mut T>
      }

      fn iter_mut_loop<'a, T>(mut x : IterMut<'a, T>) {
          while let Some(_) = x.next() {}
      }
    ]}

    In the loop, after ending the outer lifetime we get an abstraction like this
    for the inner lifetime:
    {[
      @ended_ignored_mut_borrow((s@2 <: IterMut<'1, T>); ⌊s@3 <: IterMut<'1, T>⌋) :=
        FunCall(...)[(Some ⌊s@1 <: &'1 mut T⌋)]
    ]}

    We restructure it to:
    {[
      (s@2 <: IterMut<'1, T>) :=
        FunCall(...)[(⌊s@3 <: IterMut<'1, T>⌋); (Some ⌊s@1 <: &'1 mut T⌋)]
    ]}

    TODO: generalize to an arbitrary number of nestings and arbitrary relations
    input/output *)
let rec abs_cont_destructure_levels (span : Meta.span) (ctx : eval_ctx)
    (regions : RegionId.Set.t) (output : tevalue) (input : tevalue) :
    tevalue * tevalue * BorrowId.Set.t =
  match input.value with
  | ECallProtocol (positions, body) ->
      let output, body, pending =
        abs_cont_destructure_levels span ctx regions output body
      in
      (output, { input with value = ECallProtocol (positions, body) }, pending)
  | ECallEndpoints (witnesses, body) ->
      let output, body, pending =
        abs_cont_destructure_levels span ctx regions output body
      in
      (output, { input with value = ECallEndpoints (witnesses, body) }, pending)
  | EApp (EFunCall abs_id, args) ->
      (* Higher inputs are argument groups, highest level first. Keep these
         positions even when pure translation has already applied a group. *)
      let max_level = tevalue_get_max_level ctx regions output in
      if max_level <= 0 then (output, input, BorrowId.Set.empty)
      else (
        let self_fed =
          if max_level = 2 then
            abs_cont_destructure_self_fed_level2 span ctx regions abs_id args
              output input
          else None
        in
        match self_fed with
        | Some destructured -> destructured
        | None ->
            [%cassert] span (max_level = 1)
              ("Nested continuation depth " ^ string_of_int max_level
             ^ "\n- output:\n"
              ^ tevalue_to_string ctx output
              ^ "\n- input:\n"
              ^ tevalue_to_string ctx input);
            let input1 = project_output_at_level span ctx regions 1 output in
            let output = project_output_at_level span ctx regions 0 output in
            let input =
              { input with value = EApp (EFunCall abs_id, [ input1 ] :: args) }
            in
            (output, input, BorrowId.Set.empty))
  | _ -> (output, input, BorrowId.Set.empty)

(** [abs_cont_destructure_levels] for the continuations of abstractions whose
    values are not destructured with it: the depth-2 continuations which feed
    their own loans (see [abs_cont_destructure_self_fed_level2]) are only
    supported by [normalize_abs_for_join], which also removes these loans from
    the values. *)
let abs_cont_destructure_input_output_levels (span : Meta.span) (ctx : eval_ctx)
    (regions : RegionId.Set.t) (output : tevalue) (input : tevalue) :
    tevalue * tevalue =
  let output', input', internal =
    abs_cont_destructure_levels span ctx regions output input
  in
  (* The message is lazy: the values are only printed when the assertion
     fails (printing requires consistently typed values, and this runs on
     every continuation). *)
  [%classert] span
    (BorrowId.Set.is_empty internal)
    (lazy
      ("Nested continuation depth 2 (the continuation of a function call \
        which feeds its own loans of level 1 is composed before its \
        abstraction is normalized)\n- output:\n"
      ^ tevalue_to_string ctx output
      ^ "\n- input:\n"
      ^ tevalue_to_string ctx input));
  (output', input')

(** Does a continuation value hold borrow projectors? *)
let tevalue_has_proj_borrows (v : tevalue) : bool =
  let visitor =
    object
      inherit [_] iter_tevalue as super

      method! visit_ESymbolic env pm proj =
        (match proj with
        | EProjBorrows _ -> raise Utils.Found
        | _ -> ());
        super#visit_ESymbolic env pm proj
    end
  in
  try
    visitor#visit_tevalue () v;
    false
  with Utils.Found -> true

let normalize_abs_for_join ?(loop_level_outputs = false) span ctx (abs : abs) :
    abs list =
  (* Nested borrows: the backward function of a call which receives inputs at
     level 1 (see [abs_cont_destructure_input_output_levels]) is staged. The
     value given back to its returned reference (an ended ignored mutable loan
     of its output) holds inner borrows of the region of the abstraction:
     they are outputs of its stages before the last one, which compute them
     from the inputs of level 1 (e.g., [Option::expect] on the reborrow of a
     frame gives back, for the frame given back through the returned
     reference, the inner borrows of the value given back to its input).

     In the continuation of a loop, their values are not the snapshot of the
     value given back when the parent region ended: the later iterations give
     back the frame through the loop state (e.g., [loop_expect] in the test
     [nested-borrows-loop-reborrow]). The ended loan then stays in the
     continuation of the call, whose application gives them back at level 1
     (see [split_call_cont_level_outputs]), and its given-back value stays in
     the abstraction, like the loan projectors which hold level-1 outputs.
     The joins keep the capture of the snapshot below. *)
  (* The two output positions share one received storage reference.
     The first position consumes the original field return.
     The source position, not its type, identifies that supplier. *)
  let physical_return =
    match abs.cont with
    | Some
        {
          output = Some { value = EAdt { fields = [ returned; _ ]; _ }; _ };
          input =
            Some
              {
                value =
                  ELet
                    (_, { pat = PBound; _ }, producer,
                     { value = EAdt { fields = [ left; right ]; _ }; _ });
                _;
              };
        } -> (
        match (producer.value, left.value, right.value, returned.value) with
        | ( ESymbolic (_, (EPendingLoans _ | EProjLoans _)),
            EBVar left, EBVar right,
            ELoan (EEndedIgnoredMutLoan { child; given_back; _ }) )
          when left = right && left.scope = 0
               && AbsBVarId.to_int left.bvar_id = 0
               && is_eignored child.value ->
            Some given_back
        | _ -> None)
    | _ -> None
  in
  let physical_outputs = ref [] in
  let physical_output (loan : aended_ignored_mut_loan) =
    match physical_return with
    | Some supplied ->
        project_avalue_to_evalue span ctx abs loan.given_back = supplied
    | None -> false
  in
  let staged_call =
    loop_level_outputs
    &&
    match (abs.kind, abs.cont) with
    | ( FunCall _,
        Some
          {
            output = Some output;
            input = Some input;
          } ) -> (
        match (call_protocol_body input).value with
        | EApp (EFunCall _, args) ->
            List.length args >= 2
            || tevalue_get_max_level ctx abs.regions.owned output > 0
        | _ -> false)
    | _ -> false
  in
  let captures = ref [] in
  let level_outputs = ref [] in
  let kept_level_outputs = ref false in
  let visited = EvalueTbl.create 16 in
  let visitor =
    object (self)
      inherit [_] map_eval_ctx_with_abs_levels as super
      method incr_level level = level + 1
      method! visit_ty _ ty = ty
      method! visit_tvalue _ value = value

      method! visit_tavalue level value =
        if level <> 0 then value
        else
          match value.value with
          | ALoan (AEndedIgnoredMutLoan loan) ->
              let child = self#visit_tavalue level loan.child in
              if tavalue_has_ownership span ctx loan.given_back then
                if physical_output loan then
                  physical_outputs := loan.given_back :: !physical_outputs
                else if
                  staged_call
                  && tevalue_has_proj_borrows
                       (project_avalue_to_evalue span ctx abs loan.given_back)
                then level_outputs := loan.given_back :: !level_outputs
                else captures := loan :: !captures;
              child
          | _ -> super#visit_tavalue level value

      method! visit_tevalue level value =
        if level <> 0 then value
        else
          match EvalueTbl.find_opt visited value with
          | Some result -> result
          | None ->
              let result =
                match value.value with
                | ELoan (EEndedIgnoredMutLoan loan) ->
                    let child = self#visit_tevalue level loan.child in
                    if
                      (match physical_return with
                      | Some supplied -> supplied == loan.given_back
                      | None -> false)
                    then loan.given_back
                    else if staged_call && tevalue_has_proj_borrows loan.given_back
                    then (
                      kept_level_outputs := true;
                      {
                        value with
                        value = ELoan (EEndedIgnoredMutLoan { loan with child });
                      })
                    else child
                | _ -> super#visit_tevalue level value
              in
              EvalueTbl.add visited value result;
              result
    end
  in
  let avalues = List.map (visitor#visit_tavalue 0) abs.avalues in
  let cont = Option.map (visitor#visit_abs_cont 0) abs.cont in
  [%cassert] span
    (!level_outputs <> [] = !kept_level_outputs)
    "Nested borrows: the values given back to the returned references of a \
     function call disagree with its continuation";
  [%cassert] span
    (physical_return = None || List.length !physical_outputs = 1)
    "A physical field return disagrees with its owned output projection";
  let avalues =
    avalues @ List.rev !level_outputs @ List.rev !physical_outputs
  in
  let residual = { abs with avalues; cont } in
  let residual =
    destructure_abs span residual.kind ~can_end:residual.can_end ctx residual
  in
  let internal = ref BorrowId.Set.empty in
  let cont =
    match residual.cont with
    | Some { output = Some output; input = Some input } ->
        let output, input, self_fed =
          abs_cont_destructure_levels span ctx residual.regions.owned output
            input
        in
        internal := self_fed;
        Some { output = Some output; input = Some input }
    | cont -> cont
  in
  (* Depth 2 (see [abs_cont_destructure_self_fed_level2]): the continuation
     feeds the borrows given back at level 2 to their loans of level 1, which
     are no longer inputs of the residual abstraction. Remove both from its
     values: the loans, and the ended ignored loans which only give back these
     borrows (lifted to the root by an earlier destructuring, they are then
     captures above, or dropped by the destructuring). *)
  let avalues, captured =
    if BorrowId.Set.is_empty !internal then (residual.avalues, List.rev !captures)
    else
      let loans = ref BorrowId.Set.empty in
      (* The shared loans of the residual abstraction *)
      let shared_loans =
        let ids = ref BorrowId.Set.empty in
        let visitor =
          object
            inherit [_] iter_tavalue as super

            method! visit_ASharedLoan env pm lid v child =
              ids := BorrowId.Set.add lid !ids;
              super#visit_ASharedLoan env pm lid v child
          end
        in
        List.iter (visitor#visit_tavalue ()) residual.avalues;
        !ids
      in
      let only_internal_borrows (v : tavalue) : bool =
        let visitor =
          object
            inherit [_] iter_tavalue as super

            method! visit_tavalue env v =
              match v.value with
              | ABorrow (AMutBorrow (PNone, bid, child))
                when BorrowId.Set.mem bid !internal
                     && not (tavalue_has_ownership span ctx child) ->
                  ()
              (* A shared borrow of a shared loan of the same abstraction
                 (e.g., the shared field of a captured context whose mutable
                 fields are the internal borrows): it gives nothing back, and
                 its loan stays in the abstraction *)
              | ABorrow (ASharedBorrow (PNone, bid, _))
                when BorrowId.Set.mem bid shared_loans ->
                  ()
              | AAdt _ | AIgnored _ -> super#visit_tavalue env v
              | _ -> raise Utils.Found
          end
        in
        try
          visitor#visit_tavalue () v;
          true
        with Utils.Found -> false
      in
      let mentions_internal (v : tavalue) : bool =
        let visitor =
          object
            inherit [_] iter_tavalue

            method! visit_borrow_id _ bid =
              if BorrowId.Set.mem bid !internal then raise Utils.Found

            method! visit_loan_id _ bid =
              if BorrowId.Set.mem bid !internal then raise Utils.Found

            method! visit_tvalue _ _ = ()
          end
        in
        try
          visitor#visit_tavalue () v;
          false
        with Utils.Found -> true
      in
      let avalues =
        List.filter
          (fun (av : tavalue) ->
            match av.value with
            | ALoan (AMutLoan (PNone, bid, _)) when BorrowId.Set.mem bid !internal
              ->
                loans := BorrowId.Set.add bid !loans;
                false
            | ALoan (AEndedIgnoredMutLoan { child; given_back; _ })
              when (not (tavalue_has_ownership span ctx child))
                   && only_internal_borrows given_back ->
                false
            | _ -> true)
          residual.avalues
      in
      let captured =
        List.filter
          (fun (loan : aended_ignored_mut_loan) ->
            not (only_internal_borrows loan.given_back))
          (List.rev !captures)
      in
      [%classert] span
        (BorrowId.Set.equal !loans !internal
        && (not (List.exists mentions_internal avalues))
        && not
             (List.exists
                (fun (loan : aended_ignored_mut_loan) ->
                  mentions_internal loan.given_back)
                captured))
        (lazy
          ("Nested borrows: the borrows given back at level 2 of a function \
            call disagree with the loans of level 1 of its abstraction which \
            they feed:\n- fed: "
          ^ BorrowId.Set.to_string None !internal
          ^ "\n- loans: "
          ^ BorrowId.Set.to_string None !loans
          ^ "\n- abstraction:\n"
          ^ abs_to_string span ctx residual));
      (avalues, captured)
  in
  let residual = { residual with avalues; cont } in
  let captures =
    List.map
      (fun (loan : aended_ignored_mut_loan) ->
        [%sanity_check] span (AbsLevelSet.is_empty abs.ended_subabs);
        let cont =
          Option.map
            (fun _ ->
              let output =
                project_avalue_to_evalue span ctx abs loan.given_back
              in
              [%cassert] span
                (tevalue_get_max_level ctx abs.regions.owned output <= 0)
                "Nested ignored-loan continuation output";
              let input =
                if is_eignored output.value then mk_eignored output.ty
                else
                  {
                    value = EValue (loan.given_back_env, loan.given_back_meta);
                    ty = output.ty;
                  }
              in
              { output = Some output; input = Some input })
            abs.cont
        in
        (* This output was produced when the parent returned. Keep it separate
           from the residual call: the captured value may feed that call's
           own inputs, so combining them creates a false dependency cycle. *)
        let capture =
          {
            abs with
            abs_id = ctx.fresh_abs_id ();
            kind = Identity;
            can_end = true;
            ended_subabs = AbsLevelSet.empty;
            avalues = [ loan.given_back ];
(*
```ocaml
*)
            call_scopes =
(*
```
*)
              retain_call_scopes span [ loan.given_back ]
                abs.call_scopes;
            cont;
          }
        in
        let fresh_regions =
          RegionId.Map.of_list
            (List.map
               (fun rid -> (rid, ctx.fresh_region_id ()))
               (RegionId.Set.elements abs.regions.owned))
        in
        let r_subst rid =
          Option.value ~default:rid (RegionId.Map.find_opt rid fresh_regions)
        in
        let capture =
          Substitute.abs_subst_ids
            { Substitute.empty_id_subst with r_subst }
            capture
        in
        destructure_abs span Identity ~can_end:true ctx capture)
      captured
  in
  captures @ [ residual ]

let abs_cont_bind_outputs (span : Meta.span) (ctx : eval_ctx)
    (regions : RegionId.Set.t) (bound : bound_inputs_outputs ref)
    (cont : abs_cont) : tepat * tevalue =
  match (cont.output, cont.input) with
  | Some output, Some input ->
      let output, input =
        abs_cont_destructure_input_output_levels span ctx regions output input
      in
      bind_outputs_from_output_input span ctx regions bound output input
  | _ -> [%craise] span "Unreachable"

(** Create the output of a composed continuation, and its corresponding input
    expression (without the let-bindings).

    We simply list all the bound outputs which were not consumed (the free
    variables give us the inputs, and the borrow themselves give us the outputs)
    by following the order in which they were added to the map. *)
(* ```ocaml *)
let merge_abs_conts_generate_output (span : Meta.span) (ctx : eval_ctx)
    (all_bindings : (BorrowId.id, norm_symb_proj) Either.t list)
    (bound : bound_inputs_outputs) : tevalue * tevalue =
  let bindings = all_bindings in
  let borrows = ref bound.borrows in
  let symbolic = ref bound.symbolic in
  let outputs = ref [] in
  let inputs = ref [] in

  let add_output_binding (binding : (BorrowId.id, norm_symb_proj) Either.t) =
    match binding with
    | Left bid -> begin
        match BorrowId.Map.find_opt bid !borrows with
        | None -> ()
        | Some values ->
            let (output, input) : tevalue * tevalue =
              match values with
              | [ (pm, fid, ty) ] ->
                  let child_ty =
                    match ty with
                    | TRef (_, child_ty, RMut) -> child_ty
                    | _ -> [%internal_error] span
                  in
                  let output : tevalue =
                    {
                      value = EBorrow (EMutBorrow (pm, bid, mk_eignored child_ty));
                      ty;
                    }
                  in
                  let input : tevalue = { value = EFVar fid; ty } in
                  (output, input)
              | [ (PLeft, fidl, tyl); (PRight, fidr, tyr) ]
              | [ (PRight, fidr, tyr); (PLeft, fidl, tyl) ] ->
                  let inputl : tevalue = { value = EFVar fidl; ty = tyl } in
                  let inputr : tevalue = { value = EFVar fidr; ty = tyr } in
                  let input : tevalue =
                    { value = EJoinMarkers (inputl, inputr); ty = tyl }
                  in
                  let child_ty =
                    match tyl with
                    | TRef (_, child_ty, RMut) -> child_ty
                    | _ -> [%internal_error] span
                  in
                  let output =
                    {
                      value = EBorrow (EMutBorrow (PNone, bid, mk_eignored child_ty));
                      ty = tyl;
                    }
                  in
                  (output, input)
              | _ -> [%internal_error] span
            in
            borrows := BorrowId.Map.remove bid !borrows;
            outputs := output :: !outputs;
            inputs := input :: !inputs
      end
    | Right { sv_id; norm_proj_ty } -> begin
        match SymbolicValueId.Map.find_opt sv_id !symbolic with
        | None -> ()
        | Some values -> (
            let values, remaining =
              List.partition
                (fun (_, mask, _, _) -> norm_proj_tys_equal span ctx mask norm_proj_ty)
                values
            in
            match values with
            | [] -> ()
            | values ->
                let (output, input) : tevalue * tevalue =
                  match values with
                  | [ (pm, _norm_proj_ty, fid, ty) ] ->
                      let input : tevalue = { value = EFVar fid; ty } in
                      let output : tevalue =
                        {
                          value =
                            ESymbolic
                              ( pm,
                                EProjBorrows
                                  { proj = { sv_id; proj_ty = ty }; loans = [] }
                              );
                          ty;
                        }
                      in
                      (output, input)
                  | [
                      (PLeft, proj_tyl, fidl, tyl); (PRight, proj_tyr, fidr, tyr);
                    ]
                  | [
                      (PRight, proj_tyr, fidr, tyr); (PLeft, proj_tyl, fidl, tyl);
                    ] ->
                      [%sanity_check] span
                        (norm_proj_tys_equal span ctx proj_tyl proj_tyr);
(* ``` *)
                      let inputl : tevalue = { value = EFVar fidl; ty = tyl } in
                      let inputr : tevalue = { value = EFVar fidr; ty = tyr } in
                      let input : tevalue =
                        { value = EJoinMarkers (inputl, inputr); ty = tyl }
                      in
                      let output : tevalue =
                        {
                          value =
                            ESymbolic
                              ( PNone,
                                EProjBorrows
                                  {
                                    proj = { sv_id; proj_ty = tyl };
                                    loans = [];
                                  } );
                          ty = tyl;
                        }
                      in
                      (output, input)
                  | _ -> [%internal_error] span
                in
                symbolic :=
                  if remaining = [] then
                    SymbolicValueId.Map.remove sv_id !symbolic
                  else SymbolicValueId.Map.add sv_id remaining !symbolic;
                outputs := output :: !outputs;
                inputs := input :: !inputs)
      end
  in
  List.iter add_output_binding bindings;
  let input = mk_etuple ~borrow_proj:false (List.rev !inputs) in
  let output = mk_etuple ~borrow_proj:true (List.rev !outputs) in
  (output, input)

(** Create the input binding all inputs of a composed continuation. *)
let merge_abs_conts_generate_input (span : Meta.span) (ctx : eval_ctx)
    (all_bindings : input_binding list) (bound : bound_inputs_outputs) :
    tepat * tevalue =
  let bindings = all_bindings in
  let loans = ref bound.input_loans in
  let symbolic = ref bound.input_symbolic in
  let pending = ref bound.input_pending in
  let pending_symbolic = ref bound.input_pending_symbolic in
  let pats = ref [] in
  let inputs = ref [] in

  let add_input_binding (binding : input_binding) =
    match binding with
    | ConcreteInput bid -> begin
        match BorrowId.Map.find_opt bid !loans with
        | None -> ()
        | Some (fid, pml, ty) ->
            let pm =
              match pml with
              | [ pm ] -> pm
              | [ PLeft; PRight ] | [ PRight; PLeft ] -> PNone
              | _ -> [%internal_error] span
            in
            let pat : tepat = { pat = POpen fid; ty } in
            let child_ty =
              match ty with
              | TRef (_, child_ty, RMut) -> child_ty
              | _ -> [%internal_error] span
            in
            let input : tevalue =
              { value = ELoan (EMutLoan (pm, bid, mk_eignored child_ty)); ty }
            in
            loans := BorrowId.Map.remove bid !loans;
            pats := pat :: !pats;
            inputs := input :: !inputs
      end
    | SymbolicInput proj -> begin
        match NormSymbProjMap.find_opt proj !symbolic with
        | None -> ()
        | Some ((fid, pml, ty) as bsymb) ->
            let pm =
              match pml with
              | [ pm ] -> pm
              | [ PLeft; PRight ] | [ PRight; PLeft ] -> PNone
              | _ ->
                  [%ldebug
                    "Unexpected:\n" ^ input_symbolic_to_string ctx (proj, bsymb)];
                  [%internal_error] span
            in
            let pat : tepat = { pat = POpen fid; ty } in
            let input : tevalue =
              {
                value =
                  ESymbolic
                    ( pm,
                      EProjLoans
                        {
                          proj = { sv_id = proj.sv_id; proj_ty = ty };
                          consumed = [];
                          borrows = [];
                        } );
                ty;
              }
            in
            symbolic := NormSymbProjMap.remove proj !symbolic;
            pats := pat :: !pats;
            inputs := input :: !inputs
      end
    | PendingInput (bid, mask) -> (
        let entries =
          Option.value (BorrowId.Map.find_opt bid !pending) ~default:[]
        in
        let selected, rest =
          List.partition (fun (ty, _, _, _) -> ty = mask) entries
        in
        match selected with
        | [] -> ()
        | [ (_, fid, markers, ty) ] ->
            let pm =
              if
                List.mem PNone markers
                || (List.mem PLeft markers && List.mem PRight markers)
              then PNone
              else
                match markers with
                | [ pm ] -> pm
                | _ -> [%internal_error] span
            in
            pending := BorrowId.Map.add bid rest !pending;
            pats := { pat = POpen fid; ty } :: !pats;
            inputs :=
              { value = ESymbolic (pm, EPendingLoans bid); ty } :: !inputs
        | _ -> [%internal_error] span)
    | PendingSymbolicInput slot -> (
        match SymbolicPendingSlotMap.find_opt slot !pending_symbolic with
        | None -> ()
        | Some (fid, markers, ty) ->
            let pm =
              if
                List.mem PNone markers
                || (List.mem PLeft markers && List.mem PRight markers)
              then PNone
              else
                match markers with
                | [ pm ] -> pm
                | _ -> [%internal_error] span
            in
            pending_symbolic :=
              SymbolicPendingSlotMap.remove slot !pending_symbolic;
            pats := { pat = POpen fid; ty } :: !pats;
            let input =
              { value = ESymbolic (pm, EPendingSymbolicLoans slot); ty }
            in
            inputs :=
              scope_pending_symbolic_input span bound.pending_symbolic_scopes
                slot input :: !inputs)
  in
  List.iter add_input_binding bindings;
  let pat = mk_epat_tuple (List.rev !pats) in
  let input = mk_etuple ~borrow_proj:false (List.rev !inputs) in
  (pat, input)

(** Does an abstraction hold (possibly nested) loan projectors over one of the
    symbolic values [svs]? *)
let abs_lends_symbolic (abs : abs) (svs : SymbolicValueId.Set.t) : bool =
  let visitor =
    object
      inherit [_] iter_abs as super

      method! visit_AProjLoans env loans =
        if SymbolicValueId.Set.mem loans.proj.sv_id svs then raise Utils.Found;
        super#visit_AProjLoans env loans
    end
  in
  try
    List.iter (visitor#visit_tavalue ()) abs.avalues;
    false
  with Utils.Found -> true

(** Nested borrows: split the (destructured) continuation of a function-call
    abstraction whose loan projectors (or the values given back to its
    returned references) hold level-1 outputs of the call (see
    {!abs_call_level_output_svs}) into:
    - the application which computes these outputs from the inputs of level 1
      and above ([EFunCallOutputs], see {!abs_fun}); the returned output is the
      tuple of their borrow projectors (and given-back values);
    - the application which receives the inputs of level 0 (the loan projectors
      without their borrows) and computes the outputs of level 0.

    The composed continuation can then consume the level-1 outputs before it
    computes the level-0 inputs. *)
let rec split_call_cont_level_outputs (span : Meta.span) (ctx : eval_ctx)
    (output : tevalue) (input : tevalue) :
    (tevalue * tevalue) * (tevalue * tevalue) =
  match input.value with
  | ECallProtocol (positions, body) ->
      let (early_output, early_input), (output, input) =
        split_call_cont_level_outputs span ctx output body
      in
      let wrap body = { body with value = ECallProtocol (positions, body) } in
      ((early_output, wrap early_input), (output, wrap input))
  | ECallEndpoints (witnesses, body) ->
      let (early_output, early_input), (output, input) =
        split_call_cont_level_outputs span ctx output body
      in
      let wrap body = { body with value = ECallEndpoints (witnesses, body) } in
      ((early_output, wrap early_input), (output, wrap input))
  | EApp (EFunCall abs_id, args) -> (
      match List.rev args with
      | [] -> [%craise] span "Unreachable"
      | args0 :: rev_args_above ->
          let args_above = List.rev rev_args_above in
          let outputs = ref [] in
          let strip =
            object (self)
              inherit [_] map_tevalue as super

              method! visit_tevalue env v =
                match v.value with
                | ELoan (EEndedIgnoredMutLoan { child; given_back; _ })
                  when args_above <> [] && tevalue_has_proj_borrows given_back
                  ->
                    outputs := given_back :: !outputs;
                    self#visit_tevalue env child
                | _ -> super#visit_tevalue env v

              method! visit_ESymbolic env pm proj =
                match proj with
                | EProjLoans { proj; consumed; borrows = level_outputs }
                  when level_outputs <> [] ->
                    [%cassert] span (consumed = [])
                      "Nested borrows: a loan projector in the continuation of \
                       a function call consumed values and holds level-1 \
                       outputs of the call";
                    List.iter
                      (fun (_, (level_output : eproj)) ->
                        match level_output with
                        | EProjBorrows { proj; loans = [] } ->
                            outputs :=
                              {
                                value =
                                  ESymbolic
                                    (pm, EProjBorrows { proj; loans = [] });
                                ty = proj.proj_ty;
                              }
                              :: !outputs
                        | _ ->
                            [%craise] span
                              "Nested borrows: a level-1 output of a function \
                               call holds nested loans")
                      level_outputs;
                    ESymbolic (pm, EProjLoans { proj; consumed; borrows = [] })
                | _ -> super#visit_ESymbolic env pm proj
            end
          in
          (* The level-1 outputs of each argument of level 0, which is the
             value given back to an output of the call. The stage of the
             backward function which gives back the outputs of level 1 gives
             back, for such an output, the whole value (see
             [SymbolicToPureAbs.apply_call_stage_outputs]): when the value given
             back to a borrow of the output is nested in an ADT (e.g., the
             budget captured by [&mut] in the closure of a [Map] returned by
             [Iterator::map]), the output of level 1 is the ADT, with the value
             given back at the position of the borrow and the other fields
             ignored, not the value given back alone. *)
          let level_outputs_of (v : tevalue) : tevalue list =
            let saved = !outputs in
            outputs := [];
            ignore (strip#visit_tevalue () v);
            let collected = List.rev !outputs in
            outputs := saved;
            collected
          in
          let recombined_level_supplier base suppliers =
            [%cassert] span (level_outputs_of base = [])
              "A recombined current input contains an early call output";
            match
              List.filter
                (fun (_, supplier) -> level_outputs_of supplier <> [])
                suppliers
            with
            | [ (_, supplier) ] -> supplier
            | [] -> [%internal_error] span
            | _ ->
                [%craise] span
                  "Several recombination suppliers contain early call outputs"
          in
          let rec skeleton (v : tevalue) : tevalue option =
            match v.value with
            | ELoan (EEndedIgnoredMutLoan { child; given_back; _ })
              when tevalue_has_proj_borrows given_back ->
                [%cassert] span
                  (level_outputs_of child = [])
                  "Nested borrows: a value given back to an output of a \
                   function call holds level-1 outputs of the call at several \
                   depths";
                Some given_back
            | ESymbolic
                ( pm,
                  EProjLoans
                    {
                      consumed = [];
                      borrows = [ (_, EProjBorrows { proj; loans = [] }) ];
                      _;
                    } ) ->
                (* The value given back to the projected value (see
                   {!InterpBorrows.give_back_symbolic_value}): the borrows
                   project it with the type of the projected value *)
                Some
                  {
                    value = ESymbolic (pm, EProjBorrows { proj; loans = [] });
                    ty = proj.proj_ty;
                  }
            | ERecombine (base, suppliers) ->
                if level_outputs_of v = [] then None
                else skeleton (recombined_level_supplier base suppliers)
            | EAdt adt ->
                let fields = List.map skeleton adt.fields in
                if List.for_all Option.is_none fields then None
                else
                  Some
                    {
                      v with
                      value =
                        EAdt
                          {
                            adt with
                            fields =
                              List.map2
                                (fun (field : tevalue) skel ->
                                  match skel with
                                  | Some skel -> skel
                                  | None -> mk_eignored field.ty)
                                adt.fields fields;
                          };
                    }
            | _ ->
                [%cassert] span
                  (level_outputs_of v = [])
                  "Nested borrows: a level-1 output of a function call nested \
                   in a value given back to its output is not the value given \
                   back to a borrow of that output";
                None
          in
          let rec root_level_outputs (v : tevalue) : tevalue list =
            match (level_outputs_of v, v.value) with
            | [], _ -> []
            | outputs, (ELoan _ | ESymbolic _) -> outputs
            | _, ERecombine (base, suppliers) ->
                root_level_outputs (recombined_level_supplier base suppliers)
            | _ -> Option.to_list (skeleton v)
          in
          let level_outputs = List.concat_map root_level_outputs args0 in
          let args0 = List.map (strip#visit_tevalue ()) args0 in
          outputs := level_outputs;
          [%cassert] span (level_outputs <> []) "Unreachable";
          (* Only the level-1 outputs are supported *)
          let above = !outputs in
          List.iter
            (List.iter (fun v -> ignore (strip#visit_tevalue () v)))
            args_above;
          [%cassert] span
            (!outputs == above)
            "Nested borrows: a function call gives back values at level 2 \
             through the loan projectors of its continuation";
          let outputs1 = mk_simpl_etuple ~borrow_proj:true level_outputs in
          let input1 : tevalue =
            {
              value = EApp (EFunCallOutputs (abs_id, 0, 1), args_above);
              ty = outputs1.ty;
            }
          in
          let input0 =
            {
              input with
              value =
                EApp
                  (EFunCall abs_id, List.map (fun _ -> []) args_above @ [ args0 ]);
            }
          in
          ((outputs1, input1), (output, input0)))
  | _ ->
      [%craise] span
        ("Nested borrows: the continuation which holds level-1 outputs of a \
          function call is not the application of its backward function:\n"
        ^ tevalue_to_string ctx input)

(** Merge two abstraction continuations.

    We merge from the right to the left, i.e.: we merge the (input) loans from
    [abs0] with the (output) borrows from [abs1]. *)
let merge_abs_conts_aux (span : Meta.span) (ctx : eval_ctx) (abs0 : abs)
    (abs1 : abs) (cont0 : abs_cont) (cont1 : abs_cont) : abs_cont =
  [%ltrace
    "- cont0:\n  "
    ^ abs_cont_to_string span ctx ~indent:"  " cont0
    ^ "\n- cont1:\n  "
    ^ abs_cont_to_string span ctx ~indent:"  " cont1];

  (* The way we proceed is simple.

     Let's say we want to merge A1 into A0:
     {[
       A0 { MB l0, ML l1 } ⟦ MB l0 = ML l1 ⟧
       A1 { MB l1, MB l2, ML l3 } ⟦ (MB l1, MB l2) = if b then (ML l3, 1) else (0, ML l3) ⟧
     ]}

     We first bind all the output values of the continuation in A1 like so:
     {[
       let (v_l1, v_l2) = if b then (ML l3, 1) else (0, ML l3) in
     ]}

     We then update the continuation in A0 to substitute the loans (they are inputs)
     whose corresponding borrows are outputs of the continuation of A1, and bind the outputs
     of A0. It gives:
     {[
       let v_l0 = v_l1 in
     ]}

     We output all the outputs of A1 which are not "consumed" by inputs of A0,
     as well as all the outputs of A0:
     {[
       (v_l0, v_l2)
     ]}

     Finally, we introduce binders for the remaining inputs of *both* continuations.
     This allows us to control the order in which those inputs appear (this is
     important for the translation, because it has an effect on the type of the
     translated continuation).

     The final, composed continuation is:
     {[
       (MB l0, MB l2) =
         let v0 = ML l3 in
         let (v_l1, v_l2) = if b then (v0, 1) else (0, v0) in
         let v_l0 = v_l1 in
         (v_l0, v_l2)
     ]}
  *)

  (* Initialize the map containing the bound outputs *)
  let bound : bound_inputs_outputs =
    {
      borrows = BorrowId.Map.empty;
      symbolic = SymbolicValueId.Map.empty;
      all_bindings = [];
      input_loans = BorrowId.Map.empty;
      input_symbolic = NormSymbProjMap.empty;
      input_pending = BorrowId.Map.empty;
      input_pending_symbolic = SymbolicPendingSlotMap.empty;
      pending_symbolic_scopes =
        pending_symbolic_input_scopes span
          (abs0.call_scopes @ abs1.call_scopes)
          [ cont0.input; cont1.input ];
      all_input_bindings = [];
    }
  in
  let bound = ref bound in
  if
    not
      (Option.is_some cont0.output
      && Option.is_some cont0.input
      && Option.is_some cont1.output
      && Option.is_some cont1.input)
  then
    [%craise] span
      ("Cannot compose an uninitialized abstraction continuation:"
     ^ "\n- cont0 output/input: "
      ^ string_of_bool (Option.is_some cont0.output)
      ^ "/"
      ^ string_of_bool (Option.is_some cont0.input)
      ^ "\n- cont1 output/input: "
      ^ string_of_bool (Option.is_some cont1.output)
      ^ "/"
      ^ string_of_bool (Option.is_some cont1.input)
      ^ "\n- abs0:\n"
      ^ abs_to_string span ctx abs0
      ^ "\n- abs1:\n"
      ^ abs_to_string span ctx abs1
      ^ "\n- cont0:\n"
      ^ abs_cont_to_string span ctx ~indent:"  " cont0
      ^ "\n- cont1:\n"
      ^ abs_cont_to_string span ctx ~indent:"  " cont1);

  (* The continuations whose outputs we bind, in order: the second
     continuation, then the first one, while updating its inputs (the loans
     whose borrows are outputs of the second continuation become the variables
     bound to these outputs).

     Nested borrows: when one of the two continuations applies the backward
     function of a call whose level-1 outputs (see
     [abs_call_level_output_svs]) the other abstraction consumes, the other
     abstraction may give back inputs of that call at level 0 (e.g., the call
     which received the reborrow of a frame returned by [Option::as_deref_mut]
     consumes the inner borrows of the frame it gave back, which
     [as_deref_mut] gives back at level 1, and gives back the frame it
     received, an input of [as_deref_mut] at level 0). We then bind the
     level-1 outputs of the call first, then the other continuation, then the
     level-0 outputs of the call (see [split_call_cont_level_outputs]). *)
  let split_level_outputs (abs : abs) (other : abs) =
    let svs = abs_call_level_output_svs abs in
    (not (SymbolicValueId.Set.is_empty svs)) && abs_lends_symbolic other svs
  in
  let steps =
    let destructured (abs : abs) (cont : abs_cont) =
      match (cont.output, cont.input) with
      | Some output, Some input ->
          abs_cont_destructure_input_output_levels span ctx abs.regions.owned
            output input
      | _ -> [%craise] span "Unreachable"
    in
    let step (abs : abs) cont =
      let output, input = destructured abs cont in
      (abs.regions.owned, output, input)
    in
    let split (abs : abs) cont other other_cont =
      let output, input = destructured abs cont in
      let (outputs1, input1), (output0, input0) =
        split_call_cont_level_outputs span ctx output input
      in
      [
        (abs.regions.owned, outputs1, input1);
        step other other_cont;
        (abs.regions.owned, output0, input0);
      ]
    in
    if split_level_outputs abs0 abs1 then split abs0 cont0 abs1 cont1
    else if split_level_outputs abs1 abs0 then split abs1 cont1 abs0 cont0
    else [ step abs1 cont1; step abs0 cont0 ]
  in
  let steps =
    List.rev
      (List.fold_left
         (fun steps (regions, output, input) ->
           (* For the final order to be correct, because we bind the
              continuations in order, we need to reset the [all_bindings]
              field *)
           bound := { !bound with all_bindings = []; all_input_bindings = [] };
           let pat, inputs =
             bind_outputs_from_output_input span ctx regions bound output input
           in
           [%ltrace
             "- pat: " ^ tepat_to_string ctx pat ^ "\n- inputs: "
             ^ tevalue_to_string ctx inputs
             ^ "\n- bound_inputs_outputs:\n"
             ^ bound_inputs_outputs_to_string ctx !bound];
           (regions, pat, inputs, !bound.all_bindings, !bound.all_input_bindings)
           :: steps)
         [] steps)
  in

  (* Nested borrows: the pending loans of an abstraction (the loans of the
     value given back through a parent borrow, see
     {!InterpBorrows.destructure_abs}) are inputs of a join or loop
     continuation, which receives all the inputs of its abstraction, but a
     function-call continuation receives them through the stages of the
     backward function of the call: its expression does not mention them.
     When both abstractions hold the same pending loans (the two sides of a
     join, collapsed into one), the composed continuation receives them once,
     like the loans both sides hold. *)
  let register_held_pending (abs : abs) : unit =
    List.iter
      (fun (av : tavalue) ->
        match av.value with
        | ASymbolic (pm, APendingLoans bid) -> (
            let mask = normalize_proj_ty ctx.type_ctx.type_infos abs.regions.owned av.ty in
            match BorrowId.Map.find_opt bid !bound.input_pending with
            | Some entries ->
                let entries =
                  List.map
                    (fun ((m, fid, markers, ty) as entry) ->
                      if m = mask && not (List.mem pm markers) then
                        (m, fid, pm :: markers, ty)
                      else entry)
                    entries
                in
                bound :=
                  {
                    !bound with
                    input_pending =
                      BorrowId.Map.add bid entries !bound.input_pending;
                  }
            | None -> ())
        | ASymbolic (pm, APendingSymbolicLoans slot) -> (
            match
              SymbolicPendingSlotMap.find_opt slot !bound.input_pending_symbolic
            with
            | None -> ()
            | Some (fid, markers, ty) ->
                if not (List.mem pm markers) then
                  bound :=
                    {
                      !bound with
                      input_pending_symbolic =
                        SymbolicPendingSlotMap.add slot (fid, pm :: markers, ty)
                          !bound.input_pending_symbolic;
                    })
        | _ -> ())
      abs.avalues
  in
  register_held_pending abs0;
  register_held_pending abs1;

  (* Likewise, an abstraction may hold a mutable loan that its continuation
     does not consume: the copy of a shared payload holding a mutable borrow
     (see [InterpJoin.reborrow_ashared_loans]) holds the loan of the copied
     borrow, and ignores the value given back to it (the copy is only read),
     while the join of two such copies consumes it ([Join(abs)[ML l]]). When
     the two sides of a join hold the same loan and only one side consumes it,
     the composed continuation receives it once, for both sides. *)
  let register_held_loans (abs : abs) : unit =
    List.iter
      (fun (av : tavalue) ->
        match av.value with
        | ALoan (AMutLoan (pm, bid, _)) -> (
            match BorrowId.Map.find_opt bid !bound.input_loans with
            | Some (fid, [ pm' ], ty)
              when (pm = PLeft && pm' = PRight) || (pm = PRight && pm' = PLeft)
              ->
                bound :=
                  {
                    !bound with
                    input_loans =
                      BorrowId.Map.add bid (fid, [ pm; pm' ], ty)
                        !bound.input_loans;
                  }
            | _ -> ())
        | _ -> ())
      abs.avalues
  in
  register_held_loans abs0;
  register_held_loans abs1;

  (* Create the outputs for the composed continuation, and its corresponding inputs.

     We simply list all the bound outputs which were not consumed (the free variables
     give us the inputs, and the borrow themselves give us the outputs) by following
     the order in which they were added to the map.
  *)
  let output, output_input_expr =
    merge_abs_conts_generate_output span ctx
      (List.rev
         (List.concat_map (fun (_, _, _, bindings, _) -> bindings) steps))
      !bound
  in

  (* Create the input expression and pattern *)
  let input_pat, input_input =
    merge_abs_conts_generate_input span ctx
      (List.rev
         (List.concat_map
            (fun (_, _, _, _, input_bindings) -> input_bindings)
            steps))
      !bound
  in

  (* Create the let-bindings (this is the input expression) *)
  let input =
    List.fold_right
      (fun (regions, pat, inputs, _, _) input ->
        mk_current_carrier_let span regions pat inputs input)
      steps output_input_expr
  in
  let all_regions = RegionId.Set.union abs0.regions.owned abs1.regions.owned in
  let input = mk_let span all_regions input_pat input_input input in

  (* Sanity check: no free variables in the expressions *)
  [%sanity_check] span (not (tevalue_has_fvars input));
  [%sanity_check] span (not (tevalue_has_fvars output));

  (* The continuation itself *)
  let abs_cont = { output = Some output; input = Some input } in

  [%ltrace
    "After merging:" ^ "\n\n- abs0:\n"
    ^ abs_to_string span ctx abs0
    ^ "\n\n- abs1:\n"
    ^ abs_to_string span ctx abs1
    ^ "\n\n- abs_cont:\n"
    ^ abs_cont_to_string span ctx ~indent:"  " abs_cont];

  abs_cont

(** Merge the continuation expressions of two different abstractions. *)
(* ```ocaml *)
let merge_abs_conts (span : Meta.span) (ctx : eval_ctx) ~(with_abs_conts : bool)
    (abs0 : abs) (abs1 : abs) : abs_cont option =
  match (abs0.cont, abs1.cont) with
  | None, None | None, Some _ | Some _, None -> None
  | Some cont0, Some cont1 ->
      if with_abs_conts then
        match (cont0, cont1) with
        | ({ output = None; input = Some input0 },
           { output = None; input = Some input1 })
          when (match (call_protocol_body input0).value,
                       (call_protocol_body input1).value with
                | EApp (EInputAbs owner0, _), EApp (EInputAbs owner1, _) ->
                    owner0 = owner1
                | _ -> false)
               && input0 = input1
               && RegionId.Set.equal abs0.regions.owned abs1.regions.owned
               && AbsId.Set.equal abs0.parents abs1.parents ->
            (* Keep one exact declaration owner for duplicate branch copies. *)
            Some cont0
        | _ -> Some (merge_abs_conts_aux span ctx abs0 abs1 cont0 cont1)
      else None
(* ``` *)

(* Ownership is a projection mask, not every occurrence of a region that
     another abstraction happens to own. Protect previously unowned positions
     before the union (and later global region substitution) can broaden them.
     Apply the same operation to live A/E projections; consumed metadata has
     its own explicit region set and must retain its original history. *)
(* ```ocaml *)
let preserve_projection_masks (span : Meta.span) (ctx : eval_ctx)
    ?refreshed_regions
    ~(metadata_bindings : region_metadata_bindings ref) (regions : RegionId.Set.t)
(* ``` *)
    (abs : abs) : abs =
  (*
```ocaml
  *)
  (* ```ocaml *)
  let infos = ctx.type_ctx.type_infos in
  let retained_masks = Hashtbl.create 16 in
  let origin_key (origin : carrier_origin) =
    (origin.source_owner, origin.region_group, origin.original_root,
     origin.transport_root, origin.original_mask)
  in
  let execution_root (origin : carrier_origin) from_input (root : tavalue) =
    not from_input && root.ty = origin.transport_root.sv_ty
    && match root.value with
       | ASymbolic (_, AProjLoans { proj; _ }) ->
           proj.sv_id = origin.transport_root.sv_id
           && proj.proj_ty = origin.transport_root.sv_ty
       | ASymbolic (_, AEndedProjLoans { proj; _ }) ->
           proj = origin.transport_root.sv_id
       | _ -> false
  in
  let retain_mask (witnesses : call_endpoint_witnesses) (origin : carrier_origin) =
    match origin.source_role with
    | OrdinaryCallOutputOrigin declaration
      when declaration.output_owner = origin.source_owner
           && declaration.output_owner_kind =
                FunCall (declaration.output_call, origin.region_group)
           && declaration.instantiated_output = origin.original_root.sv_ty
           && origin.original_root.sv_id = origin.transport_root.sv_id ->
        let canonical = origin.original_root.sv_ty in
        let current = origin.transport_root.sv_ty in
        let selected =
          RegionId.Set.inter declaration.output_owner_regions (ty_regions infos canonical)
        in
        let count =
          List.fold_left
            (fun count (from_input, root, _) ->
              if execution_root origin from_input root then count + 1 else count)
            0 witnesses.roots
        in
        if count = 1 && RegionId.Set.equal selected origin.original_mask
           && complete_projection_types_compatible ctx canonical current then (
          let current_mask =
            transport_projection_regions span infos
              ~metadata_bindings:ctx.metadata_bindings canonical current selected
          in
          if ty_has_regions_in_set infos
               (RegionId.Set.diff regions current_mask) current then (
            [%cassert] span
              (norm_proj_tys_equal span ctx
                 (normalize_proj_ty infos selected canonical)
                 (normalize_proj_ty infos current_mask current))
              "A retained root changes its selected positions before isolation";
            Hashtbl.replace retained_masks (origin_key origin) current_mask))
    | _ -> ()
  in
  (* ``` *)
  let changes_mask owned ty =
    ty_has_regions_in_set infos (RegionId.Set.diff regions owned) ty
  in
  (* ```ocaml *)
  let witness_checks = ref 0 in
  let witness_changes (proj : symbolic_proj) mask (actual : tavalue) =
    let selected =
      RegionId.Set.inter abs.regions.owned
        (ty_regions ctx.type_ctx.type_infos proj.proj_ty)
    in
    let () =
      if (!Config.print_error_diagnostics || !Config.print_error_emitters)
         && not (RegionId.Set.equal mask selected)
         && !witness_checks < 8 then begin
        incr witness_checks;
        Printf.eprintf
          "Retained projection precheck: owner=%s before-owned=%s after-owned=%s recorded=%s before-selected=%s source=%s\n%!"
          (AbsId.to_string abs.abs_id)
          (RegionId.Set.to_string None abs.regions.owned)
          (RegionId.Set.to_string None regions)
          (RegionId.Set.to_string None mask)
          (RegionId.Set.to_string None selected)
          (SymbolicValueId.to_string proj.sv_id)
      end
    in
    changes_mask mask proj.proj_ty
    && proj.proj_ty = actual.ty
    && RegionId.Set.equal mask selected
  (* ``` *)
  in
  (* ``` *)
  (*
```ocaml
  *)
  let ignored_value_changes owned (value : tevalue) =
    value.value = EIgnored && changes_mask owned value.ty
  in
  let ignored_pattern_changes owned (pat : tepat) =
    pat.pat = PIgnored && changes_mask owned pat.ty
  in
  let is_tuple_ty = function
    | TAdt type_ref -> type_ref.id = TTuple
    | _ -> false
  in
  (*
```
  *)
  (*
```
  *)
  let needs_isolation =
    (* ```ocaml *)
    if RegionId.Set.is_empty regions then false
    (* ``` *)
    else
      (*
```ocaml
      *)
      let visited = Hashtbl.create 16 in
      (* ```ocaml *)
      let changed = ref false in
      (* ``` *)
      let visitor =
        object (self)
          inherit [_] iter_abs as super
          (* ```ocaml *)
          method! visit_abs env abs =
            List.iter
              (fun scope -> self#visit_call_endpoint_witnesses env (ValuesUtils.call_scope_witnesses scope))
              abs.call_scopes;
            super#visit_abs env abs
          (* ``` *)

          method! visit_tavalue env (value : tavalue) =
            (match value.value with
            (* ```ocaml *)
            | ASymbolic (_, APendingLoans _) when changes_mask env value.ty -> changed := true
            (* ``` *)
            | _ -> ());
            super#visit_tavalue env value

          method! visit_tevalue env (value : tevalue) =
            let seen =
              match Hashtbl.find_opt visited env with
              | Some seen -> seen
              | None ->
                  let seen = EvalueTbl.create 16 in
                  Hashtbl.add visited env seen;
                  seen
            in
            if not (EvalueTbl.mem seen value) then (
              EvalueTbl.add seen value ();
              (match value.value with
              (* ```ocaml *)
              | ESymbolic (_, EPendingLoans _) when changes_mask env value.ty -> changed := true
              (* ``` *)
              | EAdt adt
                when is_tuple_ty value.ty
                     (* ```ocaml *)
                     && List.exists (ignored_value_changes env) adt.fields -> changed := true
                     (* ``` *)
              | _ -> ());
              super#visit_tevalue env value)
          (*
```ocaml
          *)
          method! visit_tepat env (pat : tepat) =
            (match pat.pat with
            | PAdt (_, fields)
              when is_tuple_ty pat.ty
                   (* ```ocaml *)
                   && List.exists (ignored_pattern_changes env) fields -> changed := true
                   (* ``` *)
            | _ -> ());
            super#visit_tepat env pat
          (*
```
          *)

          method! visit_mconsumed_symb _ _ = ()

          method! visit_symbolic_proj owned (proj : symbolic_proj) =
            if changes_mask owned proj.proj_ty then changed := true

          method! visit_esymbolic_proj owned (proj : esymbolic_proj) =
            if changes_mask owned proj.proj_ty then changed := true

          (*
```ocaml
          *)
          method! visit_ATransportedProj env transport child =
            self#visit_carrier_coordinate_transport env transport;
            self#visit_aproj transport.current_regions child

          method! visit_ATransportedValue env transport child =
            self#visit_carrier_coordinate_transport env transport;
            self#visit_tavalue transport.current_regions child

          method! visit_ETransportedProj env transport child =
            self#visit_carrier_coordinate_transport env transport;
            self#visit_eproj transport.current_regions child

          method! visit_ETransportedValue env transport child =
            self#visit_carrier_coordinate_transport env transport;
            self#visit_tevalue transport.current_regions child
          (* ```ocaml *)
          method! visit_call_endpoint_witnesses env witnesses =
            List.iter (retain_mask witnesses) witnesses.carrier_origins;
            List.iter
              (fun (_, original, actual) ->
                self#visit_tavalue env original;
                self#visit_tavalue env actual)
              witnesses.roots;
            List.iter
              (fun (proj, mask, actual) ->
                if witness_changes proj mask actual then changed := true;
                self#visit_tavalue env actual)
              witnesses.projections;
            List.iter (self#visit_call_input_correspondence env)
              witnesses.input_correspondences;
            List.iter (self#visit_input_carrier_conversion env)
              witnesses.carrier_conversions;
            List.iter (self#visit_input_physical_return env) witnesses.physical_returns;
            List.iter (self#visit_input_return_route env) witnesses.return_routes;
            List.iter
              (fun (_, _, _, _, producer) -> self#visit_tevalue env producer)
              witnesses.parent_carriers

          method! visit_carrier_return_source env = function
            | SymbolicCarrierReturn route -> self#visit_input_return_route env route
            | PhysicalCarrierReturn receipts ->
                List.iter (self#visit_input_physical_return env) receipts

          method! visit_carrier_coordinate_transport env transport =
            super#visit_carrier_coordinate_transport env transport;
            self#visit_carrier_return_source env transport.return_source

          method! visit_mvalue env value = self#visit_tvalue env value
          (* ``` *)
          (* ```ocaml *)
          method! visit_ECallEndpoints env witnesses body =
            self#visit_call_endpoint_witnesses env witnesses;
            self#visit_tevalue env body
          (* ``` *)
          (* ``` *)
        end
      in
      (* ```ocaml *)
      visitor#visit_abs abs.regions.owned abs;
      !changed || Hashtbl.length retained_masks <> 0
      (* ``` *)
  in
  if not needs_isolation then abs
  else
    (*
```ocaml
    *)
    let isolated = Hashtbl.create 16 in
    let refreshed = ref RegionId.Map.empty in
    (* ```ocaml *)
    let isolate_owned owned ty =
      if not (ty_has_regions_in_set infos (RegionId.Set.diff regions owned) ty) then ty
      else
        let key = (owned, ty) in
        match Hashtbl.find_opt isolated key with
        | Some ty -> ty
        | None ->
            let result =
              isolate_projection_ty ~refreshed infos owned ctx.fresh_region_id ty
            in
            Hashtbl.add isolated key result;
            result
    in
    let transport_origin (origin : carrier_origin) =
      match Hashtbl.find_opt retained_masks (origin_key origin) with
      | None -> origin
      | Some owned ->
          let transport_root =
            { origin.transport_root with
              sv_ty = isolate_owned owned origin.transport_root.sv_ty }
          in
          { origin with transport_root }
    in
    let root_mask witnesses from_input root =
      List.fold_left
        (fun found origin ->
          match Hashtbl.find_opt retained_masks (origin_key origin) with
          | Some owned when execution_root origin from_input root ->
              [%cassert] span
                (Option.fold ~none:true ~some:(RegionId.Set.equal owned) found)
                "A retained execution root has distinct selected subsets";
              Some owned
          | _ -> found)
        None witnesses.carrier_origins
    (* ``` *)
    in
    (*
```
    *)
    let mapped = Hashtbl.create 16 in
    (* ```ocaml *)
    let actual_views = Hashtbl.create 16 in
    let rec actual_view owned =
      match Hashtbl.find_opt actual_views owned with
      | Some view -> view
      | None ->
          let values = EvalueTbl.create 16 in
          let view =
            object (self)
              inherit [_] map_tavalue as super
              method! visit_ty _ ty = isolate_owned owned ty
              (* Concrete annotations keep their complete source metadata. *)
              method! visit_tvalue env (value : tvalue) =
                let payload = self#visit_value env value.value in
                if payload == value.value then value
                else { value with value = payload }
              method! visit_mconsumed_symb _ value = value
              method! visit_mgiven_back_symb _ value = value
              method! visit_ATransportedProj env transport child =
                ATransportedProj
                  (transport, (actual_view transport.current_regions)#visit_aproj env child)
              method! visit_ATransportedValue env transport child =
                ATransportedValue
                  (transport, (actual_view transport.current_regions)#visit_tavalue env child)
              method! visit_ETransportedProj env transport child =
                ETransportedProj
                  (transport, (actual_view transport.current_regions)#visit_eproj env child)
              method! visit_ETransportedValue env transport child =
                ETransportedValue
                  (transport, (actual_view transport.current_regions)#visit_tevalue env child)
              method! visit_tevalue env value =
                match EvalueTbl.find_opt values value with
                | Some value -> value
                | None ->
                    let result = super#visit_tevalue env value in
                    EvalueTbl.add values value result;
                    result
            end
          in
          Hashtbl.add actual_views owned view;
          view
    in
    (* ``` *)
    let proof_reports = ref 0 in
    let bounded_ty ty =
      let text = ty_to_string ctx ty in
      if String.length text <= 4096 then text
      else String.sub text 0 4096 ^ " (type text limit)"
    in
    (* ``` *)
    let visitor =
      object (self)
        inherit [_] map_abs as super
        (* ```ocaml *)
        method! visit_abs env abs =
          let call_scopes =
            List.map
              (function Values.PendingParameterScope scope -> Values.PendingParameterScope { scope with witnesses = self#visit_call_endpoint_witnesses env scope.witnesses } | Values.PhysicalInputScope scope -> Values.PhysicalInputScope { scope with witnesses = self#visit_call_endpoint_witnesses env scope.witnesses })
              abs.call_scopes
          in
          let result = super#visit_abs env abs in
(*
```ocaml
*)
          { result with call_scopes }
(*
```
*)
        (* ``` *)

        method! visit_tavalue env (value : tavalue) =
          let value = super#visit_tavalue env value in
          match value.value with
          | ASymbolic (_, APendingLoans _) ->
              let ty = isolate_owned env value.ty in
              if ty = value.ty then value else { value with ty }
          | _ -> value

        method! visit_tevalue env (value : tevalue) =
          let cache =
            match Hashtbl.find_opt mapped env with
            | Some cache -> cache
            | None ->
                let cache = EvalueTbl.create 16 in
                Hashtbl.add mapped env cache;
                cache
          in
          match EvalueTbl.find_opt cache value with
          | Some value -> value
          | None ->
              let result = super#visit_tevalue env value in
              let result =
                match result.value with
                | ESymbolic (_, EPendingLoans _) ->
                    let ty = isolate_owned env result.ty in
                    if ty = result.ty then result else { result with ty }
                (*
```ocaml
                *)
                | EAdt adt
                  when is_tuple_ty result.ty
                       && List.exists (ignored_value_changes env) adt.fields ->
                    let fields =
                      List.map
                        (fun (field : tevalue) ->
                          if ignored_value_changes env field then
                            { field with ty = isolate_owned env field.ty }
                          else field)
                        adt.fields
                    in
                    mk_etuple ~borrow_proj:adt.borrow_proj fields
                | ECallProtocol (_, body) | ECallEndpoints (_, body)
                  when result.ty <> body.ty -> { result with ty = body.ty }
                | ELet (_, _, _, next)
                  when result.ty <> next.ty -> { result with ty = next.ty }
                (*
```
                *)
                | _ -> result
              in
              EvalueTbl.add cache value result;
              result
        (*
```ocaml
        *)
        method! visit_tepat env (pat : tepat) =
          let result = super#visit_tepat env pat in
          match result.pat with
          | PAdt (None, fields)
            when is_tuple_ty result.ty
                 && List.exists (ignored_pattern_changes env) fields ->
              let fields =
                List.map
                  (fun (field : tepat) ->
                    if ignored_pattern_changes env field then
                      { field with ty = isolate_owned env field.ty }
                    else field)
                  fields
              in
              mk_epat_tuple fields
          | _ -> result
        (*
```
        *)

        method! visit_mconsumed_symb _ value = value
        (* ```ocaml *)
        method! visit_call_endpoint_witnesses env witnesses =
          let producers =
            object (walk)
              inherit [_] map_tavalue
              method! visit_ty _ ty = ty
              method! visit_carrier_origin _ origin = transport_origin origin
              method! visit_tevalue env value = self#visit_tevalue env value
              method! visit_mvalue env value = walk#visit_tvalue env value
              method! visit_ATransportedProj _ transport child =
                ATransportedProj
                  (transport, walk#visit_aproj transport.current_regions child)
              method! visit_ATransportedValue _ transport child =
                ATransportedValue
                  (transport, walk#visit_tavalue transport.current_regions child)
              method! visit_ETransportedProj _ transport child =
                ETransportedProj
                  (transport, walk#visit_eproj transport.current_regions child)
              method! visit_ETransportedValue _ transport child =
                ETransportedValue
                  (transport, walk#visit_tevalue transport.current_regions child)
              method! visit_carrier_return_source env = function
                | SymbolicCarrierReturn route ->
                    SymbolicCarrierReturn (walk#visit_input_return_route env route)
                | PhysicalCarrierReturn receipts ->
                    PhysicalCarrierReturn
                      (List.map (walk#visit_input_physical_return env) receipts)
            end
          in
          (*
```
          *)
          let scoped_mask (proj : symbolic_proj) =
            List.find_map
              (fun (from_input, (root : tavalue), _) ->
                match root.value with
                | ASymbolic (_, AProjLoans { proj = root_proj; _ })
                  when root_proj = proj ->
                    root_mask witnesses from_input root
                | ASymbolic (_, AEndedProjLoans { proj = id; _ })
                  when id = proj.sv_id && root.ty = proj.proj_ty ->
                    root_mask witnesses from_input root
                | _ -> None)
              witnesses.roots
          in
          let roots =
            List.map
              (fun (from_input, root, actual) ->
                let current = producers#visit_tavalue env root in
                let supplied = producers#visit_tavalue env actual in
                match root_mask witnesses from_input root with
                | None -> (from_input, current, supplied)
                | Some owned ->
                    let view = actual_view owned in
                    [%cassert] span (root.ty = actual.ty)
                      "A retained root has a different complete actual execution type";
                    (from_input, view#visit_tavalue env current,
                     view#visit_tavalue env supplied))
              witnesses.roots
          in
          let projections =
            List.mapi
              (* ```ocaml *)
              (fun index (proj, mask, actual) ->
                let scoped = scoped_mask proj in
                if Option.is_none scoped && not (witness_changes proj mask actual)
                then (proj, mask, producers#visit_tavalue env actual)
                else
                  let owned = Option.value scoped ~default:mask in
              (* ``` *)
                  let () =
                    match scoped with
                    | None -> ()
                    | Some selected ->
                        [%cassert] span
                          (proj.proj_ty = actual.ty && RegionId.Set.equal mask selected)
                          "A retained projector has a different actual type or selected subset"
                  in
                  let before = proj.proj_ty in
                  let proj_ty = isolate_owned owned before in
                  let actual = producers#visit_tavalue env actual in
                  let actual = (actual_view owned)#visit_tavalue env actual in
                  (* ``` *)
                  let () =
                    if (!Config.print_error_diagnostics || !Config.print_error_emitters)
                       && !proof_reports < 16 then begin
                      incr proof_reports;
                      Printf.eprintf
                        "Retained projection selection: owner=%s row=%d before-owned=%s after-owned=%s recorded=%s before-selected=%s before=%s after=%s\n%!"
                        (AbsId.to_string abs.abs_id) index
                        (RegionId.Set.to_string None abs.regions.owned)
                        (RegionId.Set.to_string None regions)
                        (RegionId.Set.to_string None mask)
                        (RegionId.Set.to_string None
                           (RegionId.Set.inter abs.regions.owned
                              (ty_regions ctx.type_ctx.type_infos before)))
                        (bounded_ty before) (bounded_ty proj_ty)
                    end
                  in
                  ({ proj with proj_ty }, mask, actual))
              witnesses.projections
          in
          (* ```ocaml *)
          { witnesses with roots; projections;
            carrier_origins = List.map transport_origin witnesses.carrier_origins;
            input_correspondences =
              List.map (producers#visit_call_input_correspondence env)
                witnesses.input_correspondences;
            carrier_conversions =
              List.map (producers#visit_input_carrier_conversion env)
                witnesses.carrier_conversions;
            physical_returns =
              List.map (producers#visit_input_physical_return env) witnesses.physical_returns;
            return_routes =
              List.map (producers#visit_input_return_route env) witnesses.return_routes;
            parent_carriers =
              List.map
                (fun (branch, parent, mask, owned, producer) ->
                  (branch, parent, mask, owned, self#visit_tevalue env producer))
                witnesses.parent_carriers }
          (* ``` *)
        (* ```ocaml *)
        method! visit_ECallEndpoints env witnesses body =
          ECallEndpoints
            (self#visit_call_endpoint_witnesses env witnesses,
             self#visit_tevalue env body)
        (* ``` *)
        (* ``` *)

        method! visit_symbolic_proj owned (proj : symbolic_proj) =
          let proj_ty = isolate_owned owned proj.proj_ty in
          if proj_ty = proj.proj_ty then proj else { proj with proj_ty }

        method! visit_esymbolic_proj owned (proj : esymbolic_proj) =
          let proj_ty = isolate_owned owned proj.proj_ty in
          if proj_ty = proj.proj_ty then proj else { proj with proj_ty }

        method! visit_ATransportedProj _ transport child =
          ATransportedProj (transport, self#visit_aproj transport.current_regions child)

        method! visit_ATransportedValue _ transport child =
          ATransportedValue (transport, self#visit_tavalue transport.current_regions child)

        method! visit_ETransportedProj _ transport child =
          ETransportedProj (transport, self#visit_eproj transport.current_regions child)

        method! visit_ETransportedValue _ transport child =
          ETransportedValue (transport, self#visit_tevalue transport.current_regions child)
      end
    in
    (* Each isolated coordinate keeps its authenticated source class.
       Source aliases do not add ownership or selected positions. *)
    (* ```ocaml *)
    let result = visitor#visit_abs abs.regions.owned abs in
    metadata_bindings :=
      RegionId.Map.fold
        (fun original isolated bindings ->
          let source = metadata_region bindings (RVar (Free original)) in
          RegionId.Map.add isolated (MetadataSource source) bindings)
        !refreshed !metadata_bindings;
    (match refreshed_regions with None -> () | Some coordinates -> coordinates := !refreshed);
    result
    (*
```
    *)
    (* ``` *)

(** Auxiliary function.

    Merge two abstractions into one, without updating the context. *)
let merge_abstractions (span : Meta.span) (abs_kind : abs_kind)
    ?diagnostic_isolation
    ~(can_end : bool) (merge_funs : merge_duplicates_funcs option)
    (* ```ocaml *)
    ~(with_abs_conts : bool) ~(metadata_bindings : region_metadata_bindings ref)
    (ctx : eval_ctx) (abs0 : abs) (abs1 : abs) : abs =
    (* ``` *)
  [%ltrace
    "- abs0:\n"
    ^ abs_to_string span ctx abs0
    ^ "\n\n- abs1:\n"
    ^ abs_to_string span ctx abs1];
  (* ```ocaml *)
  [%ltrace
    "Merge origin contract:\n- left id: " ^ AbsId.to_string abs0.abs_id
    ^ "\n- left kind: " ^ show_abs_kind abs0.kind
    ^ "\n- left continuation: " ^ string_of_bool (Option.is_some abs0.cont)
    ^ "\n- right id: " ^ AbsId.to_string abs1.abs_id
    ^ "\n- right kind: " ^ show_abs_kind abs1.kind
    ^ "\n- right continuation: " ^ string_of_bool (Option.is_some abs1.cont)
    ^ "\n- supplied kind: " ^ show_abs_kind abs_kind
    ^ "\n- use continuations: " ^ string_of_bool with_abs_conts];
  (* ``` *)
  (* Sanity check: we can't merge an abstraction with itself *)
  [%sanity_check] span (abs0.abs_id <> abs1.abs_id);

  let abs0 = destructure_abs span abs0.kind ~can_end:abs0.can_end ctx abs0 in
  let abs1 = destructure_abs span abs1.kind ~can_end:abs1.can_end ctx abs1 in

  (* Compute the ancestor regions, owned regions, etc.
     Note that one of the two abstractions might a parent of the other *)
  let parents =
    AbsId.Set.diff
      (AbsId.Set.union abs0.parents abs1.parents)
      (AbsId.Set.of_list [ abs0.abs_id; abs1.abs_id ])
  in
  let regions =
    let owned = RegionId.Set.union abs0.regions.owned abs1.regions.owned in
    { owned }
  in

  (* ```ocaml *)
  let left_coordinates = Option.map (fun _ -> ref RegionId.Map.empty) diagnostic_isolation in
  let right_coordinates = Option.map (fun _ -> ref RegionId.Map.empty) diagnostic_isolation in
  let abs0 = preserve_projection_masks span ctx ?refreshed_regions:left_coordinates
      ~metadata_bindings regions.owned abs0 in
  let ctx = ctx_with_metadata_bindings ctx !metadata_bindings in
  let abs1 = preserve_projection_masks span ctx ?refreshed_regions:right_coordinates
      ~metadata_bindings regions.owned abs1 in
  let ctx = ctx_with_metadata_bindings ctx !metadata_bindings in
  (match diagnostic_isolation, left_coordinates, right_coordinates with
  | Some cell, Some left, Some right -> cell := Some (abs0, abs1, !left, !right)
  | _ -> ());
  (* ``` *)


  (* Simplify the duplicated shared borrows - TODO: is this really necessary? *)
  let abs0 = abs_simplify_duplicated_borrows span ctx abs0 in
  let abs1 = abs_simplify_duplicated_borrows span ctx abs1 in

  [%ldebug
    "After simplifying the duplicated shared borrows:\n- abs0:\n"
    ^ abs_to_string span ctx abs0
    ^ "\n\n- abs1:\n"
    ^ abs_to_string span ctx abs1];

  (* Phase 1: split the markers (note that the presence of markers is controlled
     by [merge_funs]: if it is [Some] then there can be markers, otherwise there
     can't be).

     We do so because it makes it easier to implement the merge, in cases like this:
     {[
       abs0 { ML l0 } |><| abs1 { |MB l0|, MB l1 }
     ]}

     If we split before merging we get:
     {[
       abs0 { |ML l0|, ︙ML l0︙ } |><| abs1 { |MB l0|, |MB l1|, ︙MB l1︙ }
           ~~> merge
       abs2 { ︙ML l0︙, |MB l1|, ︙MB l1︙ }
           ~~> simplify the complementary markers
       abs2 { ︙ML l0︙, MB l1 }
     ]}
  *)
  let allow_markers = Option.is_some merge_funs in
  let abs0, abs1 =
    if allow_markers then
      (abs_split_markers span ctx abs0, abs_split_markers span ctx abs1)
    else (abs0, abs1)
  in
  if allow_markers then
    [%ldebug
      "After splitting the markers:\n- abs0:\n"
      ^ abs_to_string span ctx abs0
      ^ "\n\n- abs1:\n"
      ^ abs_to_string span ctx abs1]
  else [%ldebug "Did not split the markers"];

  (* Phase 2: simplify the loans coming from the left abstraction with
     the borrows coming from the right abstraction. *)
  let avalues, discharged_shared_projs, resolved_parent_dependencies =
    merge_abstractions_merge_loan_borrow_pairs span ~allow_markers
      ~with_abs_conts ctx abs0 abs1
  in
  [%ldebug
    "avalues after merging the loans from the left with the borrows from the \
     right:\n"
    ^ String.concat "\n" (List.map (tavalue_to_string ctx) avalues)];

  (* Phase 3: we now remove markers, by merging pairs of the same element with
     different markers into one element. To do so, we linearly traverse the list
     of avalues created through the first phase. *)
  let avalues =
    match merge_funs with
    | None -> avalues
    | Some merge_funs ->
        merge_abstractions_merge_markers span merge_funs ctx regions.owned
          avalues
  in
  [%ldebug
    "avalues after removing markers:\n"
    ^ String.concat "\n" (List.map (tavalue_to_string ctx) avalues)];

  (* Merge the expressions used for the pure translation. *)
  let abs1 =
    if MarkedNormSymbProjSet.is_empty discharged_shared_projs then abs1
    else
      let update =
        object
          inherit [_] map_eval_ctx_with_abs_levels
          method incr_level level = level + 1

          method! visit_ESymbolic level pm eproj =
            match eproj with
            | EProjBorrows { proj; loans = [] } when level = 0 ->
                let key : marked_norm_symb_proj =
                  {
                    pm = PNone;
                    sv_id = proj.sv_id;
                    norm_proj_ty =
                      normalize_proj_ty ctx.type_ctx.type_infos abs1.regions.owned proj.proj_ty;
                  }
                in
                let discharged branch =
                  MarkedNormSymbProjSet.mem key discharged_shared_projs
                  || MarkedNormSymbProjSet.mem { key with pm = branch }
                       discharged_shared_projs
                in
                (* Split ownership can discharge just one half of an
                   unmarked output. Keep the other half and the original
                   input computation; only an actually discharged shared
                   output becomes ignored. *)
                let left = pm <> PRight && not (discharged PLeft) in
                let right = pm <> PLeft && not (discharged PRight) in
                begin
                  match (left, right) with
                  | true, true -> ESymbolic (PNone, eproj)
                  | true, false -> ESymbolic (PLeft, eproj)
                  | false, true -> ESymbolic (PRight, eproj)
                  | false, false -> EIgnored
                end
            | _ -> ESymbolic (pm, eproj)
        end
      in
      let cont =
        Option.map
          (fun (cont : abs_cont) ->
            {
              cont with
              output = Option.map (update#visit_tevalue 0) cont.output;
            })
          abs1.cont
      in
      { abs1 with cont }
  in
  (*
```ocaml
  *)
  let parent_carriers = ref [] in
  let collect_parent_carriers (abs : abs) =
    let normalized ty =
      normalize_proj_ty ctx.type_ctx.type_infos abs.regions.owned ty
    in
    let capture pm parent mask producer =
      [%cassert] span (normalized producer.ty = mask)
        "A consumed parent carrier changes its projection mask";
      parent_carriers := (pm, parent, mask, abs.regions.owned, producer) :: !parent_carriers
    in
    let rec collect wrap (output : tevalue) (input : tevalue) =
      match input.value with
      | ECallEndpoints (witnesses, body) ->
          parent_carriers := witnesses.parent_carriers @ !parent_carriers;
          collect wrap output body
      | ELet (regions, pat, producer, next) ->
          collect
            (fun value ->
              match pat.pat, value.value with
              | PBound, EBVar var
                when var.scope = 0 && AbsBVarId.to_int var.bvar_id = 0 ->
                  wrap producer
              | _ ->
                  wrap { value = ELet (regions, pat, producer, value); ty = value.ty })
            output next
      | _ ->
          match output.value, input.value with
          | EAdt outputs, EAdt inputs ->
              [%cassert] span
                (List.length outputs.fields = List.length inputs.fields)
                "A parent carrier changes its product positions";
              List.iter2 (collect wrap) outputs.fields inputs.fields
          | ELoan (EIgnoredMutLoan (pm, Some parent, child)), _ ->
              capture pm parent (normalized child.ty) (wrap input)
          | EBorrow (EIgnoredMutBorrow (Some parent, child)), _ ->
              let carriers =
                List.filter_map
                  (fun (av : tavalue) ->
                    match av.value with
                    | ASymbolic (pm, APendingLoans bid) when bid = parent ->
                        [%cassert] span (normalized av.ty = normalized child.ty)
                          "A parent output changes its complete carrier mask";
                        Some { value = ESymbolic (pm, EPendingLoans bid); ty = av.ty }
                    | _ -> None)
                  abs.avalues
              in
              let rec collect_inputs (value : tevalue) =
                match value.value with
                | EJoinMarkers (left, right) ->
                    collect_inputs left;
                    collect_inputs right
                | ELoan (EIgnoredMutLoan (pm, Some bid, child)) ->
                    List.iter
                      (fun producer ->
                        match producer.value with
                        | ESymbolic (source_pm, EPendingLoans _)
                          when proj_markers_intersect pm source_pm ->
                            capture pm bid (normalized child.ty) producer
                        | _ -> ())
                      carriers
                | ECallEndpoints (witnesses, body) ->
                    parent_carriers := witnesses.parent_carriers @ !parent_carriers;
                    collect_inputs body
                | _ -> ()
              in
              collect_inputs input
          | _ -> ()
    in
    match abs.cont with
    | Some { output = Some output; input = Some input } ->
        collect Fun.id output input
    | _ -> ()
  in
  collect_parent_carriers abs0;
  collect_parent_carriers abs1;
  (*
```
  *)
  (* A matched parent dependency becomes an internal carrier.
     Preserve its child and the complete input computation. *)
  let resolve_parent_dependencies (abs : abs) =
    if resolved_parent_dependencies = [] then abs
    else
      let update =
        object
          inherit [_] map_tevalue as super

          method! visit_tevalue env value =
            let value = super#visit_tevalue env value in
            match value.value with
            | ELoan (EIgnoredMutLoan (pm, Some bid, child))
              when List.exists
                (fun (_, parent, _) -> parent = bid)
                resolved_parent_dependencies ->
                let mask =
                  normalize_proj_ty ctx.type_ctx.type_infos abs.regions.owned child.ty
                in
                let resolved branch =
                  List.exists
                    (fun (scope, parent, returned_mask) ->
                      parent = bid && returned_mask = mask
                      && proj_markers_intersect scope branch)
                    resolved_parent_dependencies
                in

                let internal =
                  { value with value = ELoan (EIgnoredMutLoan (PNone, None, child)) }
                in
                let remaining branch =
                  { value with value = ELoan (EIgnoredMutLoan (branch, Some bid, child)) }
                in
                let left = pm <> PRight && resolved PLeft in
                let right = pm <> PLeft && resolved PRight in

                begin match (pm, left, right) with
                | _, true, true | PLeft, true, false | PRight, false, true -> internal
                | PNone, true, false ->
                    { value with value = EJoinMarkers (internal, remaining PRight) }
                | PNone, false, true ->
                    { value with value = EJoinMarkers (remaining PLeft, internal) }
                | _ -> value
                end
            (*
```ocaml
            *)
            | ESymbolic (pm, EPendingLoans bid) ->
                let mask =
                  normalize_proj_ty ctx.type_ctx.type_infos abs.regions.owned value.ty
                in
                let resolved branch =
                  List.exists
                    (fun (scope, parent, returned_mask) ->
                      parent = bid && norm_proj_tys_equal span ctx returned_mask mask
                      && proj_markers_intersect scope branch)
                    resolved_parent_dependencies
                in
                let carrier branch =
                  let producers =
                    List.filter_map
                      (fun (scope, parent, returned_mask, regions, producer) ->
                        if parent = bid && norm_proj_tys_equal span ctx returned_mask mask
                           && proj_markers_intersect scope branch
                        then Some (regions, producer)
                        else None)
                      !parent_carriers
                    |> List.sort_uniq Stdlib.compare
                  in
                  match producers with
                  | [ (regions, producer) ] ->
                      let fid = fresh_abs_fvar_id () in
                      let var = { value = EFVar fid; ty = producer.ty } in
                      mk_let span regions (mk_epat_from_fvar var) producer var
                  | _ ->
                      [%craise] span
                        ("A consumed parent has no unique complete carrier producer: "
                        ^ tevalue_to_string ctx value
                        ^ "\n- source0:\n" ^ abs_to_string span ctx abs0
                        ^ "\n- source1:\n" ^ abs_to_string span ctx abs1
                        ^ "\n- producers:\n"
                        ^ String.concat "\n"
                            (List.map
                               (fun (pm, bid, mask, _, producer) ->
                                 show_proj_marker pm ^ " " ^ BorrowId.to_string bid
                                 ^ " " ^ ty_to_string ctx mask ^ " "
                                 ^ tevalue_to_string ctx producer)
                               !parent_carriers))
                in
                let remaining branch =
                  { value with value = ESymbolic (branch, EPendingLoans bid) }
                in
                let left = pm <> PRight && resolved PLeft in
                let right = pm <> PLeft && resolved PRight in
                begin match pm, left, right with
                | PLeft, true, _ -> carrier PLeft
                | PRight, _, true -> carrier PRight
                | PNone, true, true when not allow_markers -> carrier PNone
                | PNone, true, true ->
                    { value with value = EJoinMarkers (carrier PLeft, carrier PRight) }
                | PNone, true, false ->
                    { value with value = EJoinMarkers (carrier PLeft, remaining PRight) }
                | PNone, false, true ->
                    { value with value = EJoinMarkers (remaining PLeft, carrier PRight) }
                | _ -> value
                end
            (*
```
            *)
            | _ -> value
        end
      in

      let cont =
        Option.map
          (fun (cont : abs_cont) ->
            { cont with input = Option.map (update#visit_tevalue ()) cont.input })
          abs.cont
      in
      { abs with cont }
  in
  let abs0 = resolve_parent_dependencies abs0 in
  let abs1 = resolve_parent_dependencies abs1 in
  let cont = merge_abs_conts span ctx ~with_abs_conts abs0 abs1 in
  (*
```ocaml
  *)
  let cont =
    Option.map
      (fun (cont : abs_cont) ->
        let witnesses =
          { roots = []; expansions = []; projections = [];
(*
```ocaml
*)
(* ```ocaml *)
            carrier_origins = []; input_correspondences = []; carrier_conversions = [];
(* ``` *)
            physical_returns = []; return_routes = [];
(*
```
*)
            parent_carriers = List.sort_uniq Stdlib.compare !parent_carriers }
        in
        if witnesses.parent_carriers = [] then cont
        else
          { cont with input =
              Option.map
                (fun body -> { body with value = ECallEndpoints (witnesses, body) })
                cont.input })
      cont
  in
  (*
```
  *)
  (*
```ocaml
  *)
  let avalues =
    if resolved_parent_dependencies = [] then avalues
    else
      let key owned value =
        let visitor =
          object
            inherit [_] map_tavalue
            method! visit_proj_marker _ _ = PNone
            method! visit_ty _ ty =
              normalize_proj_ty ctx.type_ctx.type_infos owned ty
          end
        in
        visitor#visit_tavalue () value
      in
      let original =
        List.mapi
          (fun index (owned, value) -> (index, owned, value))
          (List.map (fun value -> (abs0.regions.owned, value)) abs0.avalues
          @ List.map (fun value -> (abs1.regions.owned, value)) abs1.avalues)
      in
      (*
```ocaml
      *)
      let current =
        List.map (fun value -> (key regions.owned value, value)) avalues
      in
      let transfers =
        List.filter_map
          (fun (_, (value : tavalue)) ->
            let positions =
              match value.value with
              | ASymbolic (_, APendingLoans carrier) ->
                  List.filter_map
                    (fun (branch, parent, mask, _, producer) ->
                      match producer.value with
                      | ESymbolic (_, EPendingLoans supplied) when supplied = carrier ->
                          List.find_map
                            (fun (index, owned, (av : tavalue)) ->
                              match av.value with
                              | ASymbolic (pm, APendingLoans bid)
                                when bid = parent && proj_markers_intersect branch pm
                                     && normalize_proj_ty ctx.type_ctx.type_infos owned av.ty = mask
                                     && List.exists
                                          (fun (scope, old, returned_mask) ->
                                            old = parent && returned_mask = mask
                                            && proj_markers_intersect scope branch)
                                          resolved_parent_dependencies ->
                                  Some index
                              | _ -> None)
                            original
                      | _ -> None)
                    !parent_carriers
              | _ -> []
            in
            match positions with
            | [] -> None
            | first :: rest -> Some (List.fold_left Stdlib.min first rest, value))
          current
        |> List.stable_sort (fun (left, _) (right, _) -> Int.compare left right)
      in
      let stationary =
        List.filter
          (fun (_, value) ->
            not (List.exists (fun (_, moved) -> moved == value) transfers))
          current
      in
      List.fold_left
        (fun values (position, moved) ->
          let anchor =
            List.find_map
              (fun (index, owned, previous) ->
                if index <= position then None
                else
                  let previous = key owned previous in
                  List.find_map
                    (fun (candidate, value) ->
                      if candidate = previous then Some value else None)
                    stationary)
              original
          in
          let rec insert = function
            | [] -> [ moved ]
            | value :: rest as values ->
                if Option.fold ~none:false ~some:(fun anchor -> anchor == value) anchor
                then moved :: values
                else value :: insert rest
          in
          insert values)
        (List.map snd stationary) transfers
      (*
```
      *)
  in
  (*
```
  *)
  (*
```ocaml
  *)
  let cont =
    let retained (branch, parent, mask, _, _) =
      let visitor =
        object
          inherit [_] iter_tavalue
          method! visit_tavalue _ (av : tavalue) =
            match av.value with
            | ALoan (AIgnoredMutLoan (pm, Some bid, child))
              when bid = parent && proj_markers_intersect pm branch
                   && normalize_proj_ty ctx.type_ctx.type_infos regions.owned child.ty = mask ->
                raise Utils.Found
            | _ -> ()
        end
      in
      try List.iter (visitor#visit_tavalue ()) avalues; false
      with Utils.Found -> true
    in
    let prune =
      object (self)
        inherit [_] map_tevalue as super
        method! visit_tevalue env value =
          match value.value with
          | ECallEndpoints (witnesses, body) ->
              let body = self#visit_tevalue env body in
              let parent_carriers = List.filter retained witnesses.parent_carriers in
              if parent_carriers = [] && witnesses.roots = []
                 && witnesses.expansions = [] && witnesses.projections = []
                 && witnesses.carrier_origins = [] && witnesses.input_correspondences = []
                 && witnesses.carrier_conversions = []
                 && witnesses.physical_returns = []
                 && witnesses.return_routes = []
              then body
              else
                { value with value = ECallEndpoints ({ witnesses with parent_carriers }, body) }
          | _ -> super#visit_tevalue env value
      end
    in
    Option.map (prune#visit_abs_cont ()) cont
  in
  (*
```
  *)
  (* ```ocaml *)
  let abs_kind, can_end =
    match cont with
    | Some { output = None; input = Some input } ->
        (match (call_protocol_body input).value with
        | EApp (EInputAbs rg_id, _) ->
            (SynthInput rg_id, abs0.can_end && abs1.can_end)
        | _ -> (abs_kind, can_end))
    | _ -> (abs_kind, can_end)
  in
  (* ``` *)

  (* *)
  [%cassert] span (AbsLevelSet.is_empty abs0.ended_subabs) "Unimplemented";
  [%cassert] span (AbsLevelSet.is_empty abs1.ended_subabs) "Unimplemented";
  let ended_subabs = AbsLevelSet.empty in

  (* Create the new abstraction *)
  let abs_id = ctx.fresh_abs_id () in
  let abs =
    {
      abs_id;
      kind = abs_kind;
      can_end;
      parents;
      ended_subabs;
      regions;
      avalues;
      cont;
(*
```ocaml
*)
      call_scopes =
(*
```
*)
        retain_call_scopes span avalues
          (abs0.call_scopes @ abs1.call_scopes);
    }
  in

  let abs = abs_simplify_duplicated_borrows span ctx abs in
  [%ltrace "resulting abs:\n" ^ abs_to_string span ctx abs];
  (* ```ocaml *)
  [%ltrace
    "Merge result origin contract:\n- id: " ^ AbsId.to_string abs.abs_id
    ^ "\n- kind: " ^ show_abs_kind abs.kind
    ^ "\n- continuation: " ^ string_of_bool (Option.is_some abs.cont)];
  (* ``` *)

  (* Sanity check *)
  [%sanity_check] span (abs_is_destructured span ctx abs);
  (* Return *)
  abs

(* Region substitution can make pending inputs share one declaration key.
   Bind the complete carrier once and preserve each branch computation. *)
let rebind_pending_input_aliases span ctx (abs : abs) =

  let has_pending = List.exists (fun (value : tavalue) ->
      match value.value with
      | ASymbolic (_, APendingSymbolicLoans _) -> true
      | _ -> false) abs.avalues in

  if not has_pending then abs
  else match abs.cont with
  | None -> abs
  | Some cont -> match cont.input with
    | None -> abs
    | Some input ->

      let views = ref SymbolicPendingSlotMap.empty in
      let aliases = ref false in
      let visitor =
        object
          inherit [_] iter_tevalue

          method! visit_ESymbolic _ pm projection =
            match projection with
            | EPendingSymbolicLoans slot ->
                let bit = match pm with PLeft -> 1 | PRight -> 2 | PNone -> 3 in
                let previous =
                  Option.value (SymbolicPendingSlotMap.find_opt slot !views)
                    ~default:0
                in

                let () =
                  if previous <> 0 && (previous lor bit) = 3
                     && (previous <> 3 || bit <> 3)
                  then aliases := true
                in
                views := SymbolicPendingSlotMap.add slot (previous lor bit) !views
            | _ -> ()
        end
      in
      let () = visitor#visit_tevalue () input in
      if not !aliases then abs
      else

        let bound = ref {
          borrows = BorrowId.Map.empty;
          symbolic = SymbolicValueId.Map.empty;
          all_bindings = [];
          input_loans = BorrowId.Map.empty;
          input_symbolic = NormSymbProjMap.empty;
          input_pending = BorrowId.Map.empty;
          input_pending_symbolic = SymbolicPendingSlotMap.empty;
          pending_symbolic_scopes =
            pending_symbolic_input_scopes span abs.call_scopes [Some input];
          all_input_bindings = [];
        } in

        let _, input =
          bind_outputs_from_output_input span ctx abs.regions.owned bound
            (mk_etuple ~borrow_proj:true []) input
        in
        let pat, carriers =
          merge_abs_conts_generate_input span ctx
            (List.rev !bound.all_input_bindings) !bound
        in
        let input = mk_let span abs.regions.owned pat carriers input in
        { abs with cont = Some { cont with input = Some input } }

(* ```ocaml *)
let transport_ignored_loan_cont_views span (ctx : eval_ctx) (owner : abs)
    ~metadata_policy ~metadata_rsubst rsubst : eval_ctx =

  let suppliers = ref [] in
  let collect =
    object
      inherit [_] iter_tavalue as super
      method! visit_tavalue env value =
        (match value.value with
        | ALoan (AIgnoredMutLoan (marker, Some loan, _)) ->
            suppliers :=
              (marker, loan, value.ty,
               normalize_proj_ty ctx.type_ctx.type_infos
                 owner.regions.owned value.ty) :: !suppliers
        | _ -> ());
        super#visit_tavalue env value
    end
  in
  List.iter (collect#visit_tavalue ()) owner.avalues;
  if !suppliers = [] then ctx
  else
    (* ```ocaml *)
    let type_substitution =
      Substitute.subst_ids_visitor ~metadata_policy

        ~metadata_rsubst

        { Substitute.empty_id_subst with r_subst = rsubst }
    in
    let types = TyCache.create 16 in
    (* ``` *)

    let view =
      object
        (* ```ocaml *)
        inherit [_] map_abs
        method! visit_ty _ ty =
          match TyCache.find_opt types ty with
          | Some mapped -> mapped
          | None ->
              let mapped = type_substitution#visit_ty () ty in
              let mapped = if TyCacheKey.equal ty mapped then ty else mapped in
              TyCache.add types ty mapped;
              mapped
        (* ``` *)
        method! visit_mvalue _ value = value
        method! visit_msymbolic_value _ value = value
        method! visit_mconsumed_symb _ value = value
        method! visit_mgiven_back_symb _ value = value
        method! visit_symbolic_pending_slot _ slot = slot
        method! visit_call_endpoint_witnesses _ witnesses = witnesses
      end
    in
    let visitor =
      object (self)
        inherit [_] map_abs as super
        method! visit_ty _ ty = ty
        method! visit_mconsumed_symb _ value = value
        method! visit_symbolic_pending_slot _ slot = slot
        method! visit_ECallEndpoints regions witnesses body =
          ECallEndpoints (witnesses, self#visit_tevalue regions body)
        method! visit_ELet regions local_regions pat producer next =
          ELet (local_regions, pat,
                self#visit_tevalue local_regions producer,
                self#visit_tevalue regions next)
        method! visit_tevalue regions value =
          match value.value with
          | ELoan (EIgnoredMutLoan (marker, Some loan, _)) ->
              let mask =
                normalize_proj_ty ctx.type_ctx.type_infos regions value.ty
              in
              let compatible =
                List.filter
                  (fun (source_marker, source_loan, _, source_mask) ->
                    source_loan = loan
                    && proj_markers_intersect marker source_marker
                    && source_mask = mask)
                  !suppliers
              in
              begin
                match compatible with
                | [] -> super#visit_tevalue regions value
                | [ (_, _, source_ty, _) ] ->
                    let value = view#visit_tevalue () value in
                    let source_ty = view#visit_ty () source_ty in
                    [%cassert] span
                      (normalize_proj_ty ctx.type_ctx.type_infos
                         (RegionId.Set.map rsubst regions) value.ty
                       = normalize_proj_ty ctx.type_ctx.type_infos
                           (RegionId.Set.map rsubst owner.regions.owned) source_ty)
                      "A live ignored loan changes its selected source positions";
                    value
                | _ ->
                    [%craise] span
                      "A live ignored loan has multiple complete suppliers"
              end
          | _ -> super#visit_tevalue regions value
      end
    in
    ctx_map_abs
      (fun abs ->
        let cont =
          Option.map
            (fun (cont : abs_cont) ->
              { cont with
                input = Option.map
                  (visitor#visit_tevalue abs.regions.owned) cont.input })
            abs.cont
        in
        { abs with cont })
      ctx
(* ``` *)

(* ```ocaml *)
let selected_owned_storage_keys (ctx : eval_ctx) (owner : abs) =
  let keys = ref RegionId.Set.empty in
  let storage =
    object (self)
      inherit [_] TypesAnalysis.iter_storage_ty ctx.type_ctx.type_infos as super
      method! visit_region metadata = function
        | RVar (Free key) when metadata && RegionId.Set.mem key owner.regions.owned ->
            keys := RegionId.Set.add key !keys
        | _ -> ()
      method! visit_TAdt metadata tref =
        if metadata then super#visit_TAdt true tref
        else
          match tref.id with
          | TAdtId id ->
              let info = TypeDeclId.Map.find id ctx.type_ctx.type_infos in
              RegionId.iteri
                (fun index region ->
                  if RegionId.Set.mem index info.stored_regions then
                    self#visit_region (RegionId.Set.mem index info.metadata_regions) region)
                tref.generics.regions;
              TypeVarId.iteri
                (fun index ty ->
                  if TypeVarId.Set.mem index info.stored_type_params then
                    self#visit_ty (TypeVarId.Set.mem index info.metadata_type_params) ty)
                tref.generics.types
          | TTuple | TBuiltin _ -> super#visit_TAdt false tref
    end
  in
  let active =
    object
      inherit [_] iter_tavalue as super
      method! visit_tavalue env value =
        (match value.value with
        (* ```ocaml *)
        | ASymbolic (_, AProjLoans { proj; _ })
        | ASymbolic (_, AProjBorrows { proj; _ }) ->
        (* ``` *)
            storage#visit_ty false proj.proj_ty
        | ALoan (AIgnoredMutLoan _) -> storage#visit_ty false value.ty
        | _ -> ());
        super#visit_tavalue env value
    end
  in
  List.iter (active#visit_tavalue ()) owner.avalues;
  !keys
(* ``` *)

(** Coalesce operational regions. Stored metadata keys stay distinct. *)
(* ```ocaml *)
let ctx_merge_regions span (ctx : eval_ctx) ~(surviving_owner : abs)
    (rid : RegionId.id) (rids : RegionId.Set.t) : eval_ctx =
(* ``` *)

  (*
```ocaml
  *)
  let metadata_keys = ref RegionId.Set.empty in
  (* ```ocaml *)
  let observable_sources = ref [] in
  let current_data = ref true in
  let observed_types = TyCache.create 16 in
  (*
```ocaml
  *)
  let selection_is_projector = ref false in
  let selected_regions = ref RegionId.Set.empty in
  (*
```
  *)
  let resolved_sources = ref RegionId.Map.empty in
  let resolve key =
    match RegionId.Map.find_opt key !resolved_sources with
    | Some source -> source
    | None ->
        let source = metadata_region ctx.metadata_bindings (RVar (Free key)) in
        resolved_sources := RegionId.Map.add key source !resolved_sources;
        source
  in
  (* ``` *)
  let collect =
    object (self)
      inherit [_] TypesAnalysis.iter_storage_ty ctx.type_ctx.type_infos as super
      (* ```ocaml *)
      method! visit_ty metadata ty =
        if not !current_data then super#visit_ty metadata ty
        else
          let context = if metadata then 2 else 1 in
          let seen = Option.value (TyCache.find_opt observed_types ty) ~default:0 in
          if seen land context = 0 then (
            TyCache.replace observed_types ty (seen lor context);
            super#visit_ty metadata ty)
      method! visit_region metadata region =
        if metadata then (
          (match region with
          | RVar (Free key) -> metadata_keys := RegionId.Set.add key !metadata_keys
          | _ -> ());
          (*
```ocaml
          *)
          if !current_data then (
            let selected =
              if not !selection_is_projector then true
              else
                match region with
                | RVar (Free key) -> RegionId.Set.mem key !selected_regions
                | RStatic | RVar (Bound _) | RBody _ | RErased -> false
            in
            if selected then (
              let source = match region with
                | RVar (Free key) -> resolve key
                | _ -> region in
              if not (List.mem source !observable_sources) then
                observable_sources := source :: !observable_sources)))
          (*
```
          *)
      (* ``` *)
      method! visit_TAdt metadata tref =
        if metadata then super#visit_TAdt true tref
        else
          match tref.id with
          | TAdtId id ->
              let info = TypeDeclId.Map.find id ctx.type_ctx.type_infos in
              RegionId.iteri
                (fun index region ->
                  if RegionId.Set.mem index info.stored_regions then
                    self#visit_region (RegionId.Set.mem index info.metadata_regions) region)
                tref.generics.regions;
              TypeVarId.iteri
                (fun index ty ->
                  if TypeVarId.Set.mem index info.stored_type_params then
                    self#visit_ty (TypeVarId.Set.mem index info.metadata_type_params) ty)
                tref.generics.types
          | TTuple | TBuiltin _ -> super#visit_TAdt false tref
    end
  in
  (*
```ocaml
  *)
  let observe_ty projected regions ty =
    let same_context =
      projected = !selection_is_projector
      && (not projected || RegionId.Set.equal regions !selected_regions)
    in
    if not same_context then (
      TyCache.clear observed_types;
      selection_is_projector := projected;
      selected_regions := regions);
    collect#visit_ty false ty
  in
  (*
```
  *)
  let operational =
    (* ```ocaml *)
    object (self)
      inherit [_] iter_tavalue as super
      (*
```ocaml
      *)
      method! visit_ty _ ty = observe_ty false RegionId.Set.empty ty
      method! visit_symbolic_proj owned proj =
        observe_ty true owned proj.proj_ty
      (*
```
      *)
      method! visit_mvalue _ _ = ()
      method! visit_msymbolic_value _ _ = ()
      method! visit_mconsumed_symb _ _ = ()
      method! visit_tvalue env value =
        match value.value with
        | VBottom | VLiteral _ -> ()
        | _ -> super#visit_tvalue env value
      (*
```ocaml
      *)
      method! visit_tavalue owned value =
        (match value.value with
        | ASymbolic (_, (AProjLoans _ | AProjBorrows _))
        | ABorrow (AProjSharedBorrow _) ->
            observe_ty true owned value.ty
        | AAdt _
        | ALoan (AMutLoan _ | ASharedLoan _ | AIgnoredMutLoan (_, Some _, _))
        | ABorrow (AMutBorrow _ | ASharedBorrow _ | AIgnoredMutBorrow (Some _, _))
        | ASymbolic (_, (APendingLoans _ | APendingSymbolicLoans _)) ->
            self#visit_ty owned value.ty
        | _ -> ());
        self#visit_avalue owned value.value
      (*
```
      *)
      method! visit_AEndedProjLoans _ _ = ()
      method! visit_AEndedProjBorrows _ _ = ()
      (*
```ocaml
      *)
      method! visit_ATransportedValue _ transport child =
        self#visit_tavalue transport.current_regions child
      method! visit_ATransportedProj _ transport child =
        self#visit_aproj transport.current_regions child
      (*
```
      *)
    end
    (* ``` *)
  in
  List.iter
    (function
      (*
```ocaml
      *)
      | EAbs abs ->
          List.iter (operational#visit_tavalue abs.regions.owned) abs.avalues;
          List.iter
            (function
              | PendingParameterScope scope ->
                  operational#visit_symbolic_pending_slot abs.regions.owned scope.slot
              | PhysicalInputScope scope ->
                  observe_ty true scope.physical_slot.proj_regions
                    scope.physical_slot.origin.transport_root.sv_ty)
            abs.call_scopes
      | EBinding (_, value) -> operational#visit_tvalue RegionId.Set.empty value
      (*
```
      *)
      | EFrame -> ())
    ctx.env;
  (* ```ocaml *)
  current_data := false;
  (* ``` *)
  (*
```ocaml
  *)
  let retained_source_keys = ref RegionId.Set.empty in
  let protect_origin (witnesses : call_endpoint_witnesses)
      (origin : carrier_origin) =
    (*
```ocaml
    *)
    match origin.source_role with
    | OrdinaryCallOutputOrigin declaration
      when declaration.output_owner = origin.source_owner
        && declaration.output_owner_kind =
             FunCall (declaration.output_call, origin.region_group)
        && declaration.instantiated_output = origin.original_root.sv_ty
        && origin.original_root.sv_id = origin.transport_root.sv_id ->

    (*
```
    *)
        let selected =
          RegionId.Set.inter declaration.output_owner_regions
            (ty_regions ctx.type_ctx.type_infos origin.original_root.sv_ty)
        in
        let root_count =
          List.fold_left
            (fun count (from_input, (root : tavalue), _) ->
              if not from_input && root.ty = origin.transport_root.sv_ty

                 && (match root.value with
                     | ASymbolic (_, AProjLoans { proj; _ }) ->
                         proj.sv_id = origin.transport_root.sv_id
                         && proj.proj_ty = origin.transport_root.sv_ty

                     | ASymbolic (_, AEndedProjLoans { proj; _ }) ->
                         proj = origin.transport_root.sv_id

                     | _ -> false)
              then count + 1 else count)
            0 witnesses.roots
        in
        (*
```ocaml
        *)
        if root_count = 1 && RegionId.Set.equal selected origin.original_mask then (

          (*
```ocaml
          *)
          let source_ty = origin.original_root.sv_ty in
          let execution_ty = origin.transport_root.sv_ty in
          let infos = ctx.type_ctx.type_infos in
          (*
```ocaml
          *)
          [%cassert] span
            (let complete_equal =
               complete_projection_types_compatible ctx source_ty execution_ty
             in
             let exact =
               complete_equal
               &&
               let execution_mask =
                 transport_projection_regions span infos
                   ~metadata_bindings:ctx.metadata_bindings source_ty execution_ty
                   origin.original_mask
               in
               norm_proj_tys_equal span ctx
                 (normalize_proj_ty infos origin.original_mask source_ty)
                 (normalize_proj_ty infos execution_mask execution_ty)

             in
             if not exact then begin
               let source_erased =
                 ty_erase_regions_with_metadata infos ctx.metadata_bindings source_ty
               in
               let execution_erased =
                 ty_erase_regions_with_metadata infos ctx.metadata_bindings execution_ty
               in
               let raw label text =
                 let shown = Stdlib.min 65536 (String.length text) in
                 Printf.eprintf "%s bytes=%d shown=%d:\n%s\n%!"
                   label (String.length text) shown (String.sub text 0 shown)
               in
               let report label show compute =
                 try
                   let value = compute () in
                   raw label (show value);
                   Some value
                 with error ->
                   raw (label ^ " unavailable") (Printexc.to_string error);
                   None
               in
               Printf.eprintf
                 "Retained typed correspondence failure: source-owner=%s call=%s group=%s canonical=%s transport=%s execution-roots=%d complete-type-equal=%b selected-transport-evaluated-by-guard=%b exact=%b\n%!"
                 (AbsId.to_string origin.source_owner)
                 (FunCallId.to_string declaration.output_call)
                 (RegionGroupId.to_string origin.region_group)
                 (SymbolicValueId.to_string origin.original_root.sv_id)
                 (SymbolicValueId.to_string origin.transport_root.sv_id)
                 root_count complete_equal complete_equal exact;
               Printf.eprintf
                 "Retained authority predicates: owner-equal=%b kind-equal=%b instantiated-source-equal=%b source-identity-equal=%b unique-execution-root=%b canonical-selection-equal=%b\n%!"
                 (declaration.output_owner = origin.source_owner)
                 (declaration.output_owner_kind =
                   FunCall (declaration.output_call, origin.region_group))
                 (declaration.instantiated_output = source_ty)
                 (origin.original_root.sv_id = origin.transport_root.sv_id)
                 (root_count = 1)
                 (RegionId.Set.equal selected origin.original_mask);
               raw "raw canonical root" (show_symbolic_value origin.original_root);
               raw "raw execution transport root"
                 (show_symbolic_value origin.transport_root);
               raw "raw origin role and creation facts"
                 (show_carrier_origin_role origin.source_role);
               raw "raw creation owner kind" (show_abs_kind declaration.output_owner_kind);
               raw "raw creation owner regions"
                 (RegionId.Set.show declaration.output_owner_regions);
               raw "raw creation declared output" (Types.show_ty declaration.declared_output);
               raw "raw creation instantiated output"
                 (Types.show_ty declaration.instantiated_output);
               raw "raw canonical selected mask" (RegionId.Set.show origin.original_mask);
               raw "raw creation selected mask" (RegionId.Set.show selected);
               raw "raw canonical erased type" (Types.show_ty source_erased);
               raw "raw execution erased type" (Types.show_ty execution_erased);
               let execution_mask =
                 report "raw transported comparison mask" RegionId.Set.show
                   (fun () ->
                     transport_projection_regions span infos
                       ~metadata_bindings:ctx.metadata_bindings source_ty execution_ty
                       origin.original_mask)
               in
               (*
```ocaml
               *)
               Printf.eprintf
                 "Retained selected-coordinate transport: succeeded=%b\n%!"
                 (Option.is_some execution_mask);
               (*
```
               *)

               let normalized_source =
                 report "raw canonical normalized selected positions" Types.show_ty
                   (fun () -> normalize_proj_ty infos origin.original_mask source_ty)
               in
               let normalized_execution =
                 match execution_mask with
                 | Some mask ->
                     report "raw execution normalized selected positions" Types.show_ty
                       (fun () -> normalize_proj_ty infos mask execution_ty)
                 | None ->
                     raw "execution normalized selected positions unavailable"
                       "The selected-coordinate transport did not return a mask.";
                     None
               in
               (match normalized_source, normalized_execution with
               | Some source, Some execution ->
                   (*
```ocaml
                   *)
                   Printf.eprintf
                     "Retained selected-position predicate: normalized-selected-raw-equal=%b\n%!"
                     (source = execution);
                   ignore
                     (report "normalized-selected-equal" string_of_bool
                       (fun () -> norm_proj_tys_equal span ctx source execution))
                   (*
```
                   *)

               | _ ->
                   Printf.eprintf
                     "Retained selected-position predicate: normalized-selected-equal=unavailable\n%!");
               let candidates = ref 0 in
               let emitted = ref 0 in
               List.iteri
                 (fun row (from_input, (root : tavalue), (actual : tavalue)) ->
                   let candidate =
                     match root.value with
                     | ASymbolic (_, AProjLoans { proj; _ })
                       when proj.sv_id = origin.transport_root.sv_id ->
                         Some ("live-loan", proj.proj_ty = execution_ty)
                     | ASymbolic (_, AEndedProjLoans { proj; _ })
                       when proj = origin.transport_root.sv_id ->
                         Some ("ended-loan", true)
                     | _ -> None
                   in
                   match candidate with
                   | None -> ()
                   | Some (kind, projector_equal) ->
                       incr candidates;
                       if !emitted < 8 then begin
                         incr emitted;
                         Printf.eprintf
                           "Retained execution-root candidate: row=%d kind=%s from-input=%b full-type-equal=%b projector-type-equal=%b eligible=%b\n%!"
                           row kind from_input (root.ty = execution_ty) projector_equal
                           (not from_input && root.ty = execution_ty && projector_equal);
                         raw "raw execution declaration root" (show_tavalue root);
                         raw "raw supplied actual endpoint" (show_tavalue actual)
                       end)
                 witnesses.roots;
               Printf.eprintf
                 "Retained execution-root candidate bounds: same-identity=%d emitted=%d total-roots=%d\n%!"
                 !candidates !emitted (List.length witnesses.roots)
             end;
             exact)
            "A retained declaration changes its exact source-to-execution correspondence";
          (*
```
          *)

          let selected =
            RegionId.Set.filter
              (fun key ->
                match metadata_region ctx.metadata_bindings (RVar (Free key)) with
                | RStatic | RVar (Bound _) | RBody _ -> true
                | RVar (Free _) | RErased -> false)
              selected
          in
          retained_source_keys := RegionId.Set.union selected !retained_source_keys)

        (*
```
        *)
    | _ -> ()
  in
  let retained_values = EvalueTbl.create 16 in
  let retained =
    object (self)
      inherit [_] iter_env as super
      method! visit_ty _ _ = ()

      method! visit_abs env abs =
        List.iter
          (fun scope -> self#visit_call_endpoint_witnesses env (ValuesUtils.call_scope_witnesses scope))
          abs.call_scopes;
        super#visit_abs env abs

      (*
```ocaml
      *)
      method! visit_call_endpoint_witnesses env witnesses =
        super#visit_call_endpoint_witnesses env witnesses;
        List.iter
          (fun (_, original, actual) ->
            self#visit_tavalue env original;
            self#visit_tavalue env actual)
          witnesses.roots;
        List.iter
          (fun (source, expansion) ->
            self#visit_symbolic_value env source;
            (*
```ocaml
            *)
            match expansion with
            | SeLiteral value -> self#visit_literal env value
            | SeAdt (_, fields) ->
                List.iter (self#visit_symbolic_value env) fields
            | SeMutRef (_, child) | SeSharedRef (_, child) ->
                self#visit_symbolic_value env child)
            (*
```
            *)
          witnesses.expansions;
        List.iter
          (fun (source, _, actual) ->
            self#visit_symbolic_proj env source;
            self#visit_tavalue env actual)
          witnesses.projections;
        List.iter (protect_origin witnesses) witnesses.carrier_origins;
        List.iter (self#visit_carrier_origin env) witnesses.carrier_origins;
        List.iter (self#visit_call_input_correspondence env)
          witnesses.input_correspondences;
        List.iter (self#visit_input_carrier_conversion env)
          witnesses.carrier_conversions;
        List.iter (self#visit_input_physical_return env) witnesses.physical_returns;
        List.iter (self#visit_input_return_route env) witnesses.return_routes;
        List.iter
          (fun (_, _, _, _, producer) -> self#visit_tevalue env producer)
          witnesses.parent_carriers

      method! visit_carrier_return_source env = function
        | SymbolicCarrierReturn route -> self#visit_input_return_route env route
        | PhysicalCarrierReturn receipts ->
            List.iter (self#visit_input_physical_return env) receipts

      method! visit_carrier_coordinate_transport env transport =
        super#visit_carrier_coordinate_transport env transport;
        self#visit_carrier_return_source env transport.return_source

      method! visit_mvalue env value = self#visit_tvalue env value
      method! visit_msymbolic_value env value = self#visit_symbolic_value env value
      (*
```
      *)

      method! visit_ECallEndpoints env witnesses body =
        self#visit_call_endpoint_witnesses env witnesses;
        self#visit_tevalue env body

      method! visit_tevalue env value =
        if not (EvalueTbl.mem retained_values value) then (
          EvalueTbl.add retained_values value ();
          super#visit_tevalue env value)
    end
  in
  retained#visit_env () ctx.env;
  (*
```
  *)
  (* ```ocaml *)
  [%ltrace
    "Operational region coalescence:\n- requested: "
    ^ RegionId.Set.to_string None (RegionId.Set.add rid rids)
    ^ "\n- protected keys: " ^ RegionId.Set.to_string None !metadata_keys
    ^ "\n- source bindings: "
    ^ carrier_metadata_bindings ctx.metadata_bindings
    ^ "\n- source state:\n"
    ^ eval_ctx_to_string ~span:(Some span) ~filter:false ctx];
  (* ``` *)
  (*
```
  *)
  (* Coalescence also reaches neighboring owners, not only the abstractions
     just merged. Their formerly unowned positions must remain unowned. *)
  let regions = RegionId.Set.add rid rids in
  (* The ownership merge already authorizes this operational region set.
     Select a stable stored declaration representative within that set.
     Metadata does not add another region to the operation. *)
  (* ```ocaml *)
  let selected_storage_keys = selected_owned_storage_keys ctx surviving_owner in
  let preferred =
    if RegionId.Set.is_empty selected_storage_keys then !metadata_keys
    (* ```ocaml *)
    else
      RegionId.Set.filter
        (fun candidate ->
          RegionId.Set.mem candidate selected_storage_keys
          ||
          let source = metadata_region ctx.metadata_bindings (RVar (Free candidate)) in
          match source with
          | RVar (Free _) | RErased -> false
          | RStatic | RVar (Bound _) | RBody _ ->
              RegionId.Set.exists
                (fun selected ->
                  metadata_region ctx.metadata_bindings (RVar (Free selected)) = source)
                selected_storage_keys)
        regions
    (* ``` *)
  in
  let rid =
    if RegionId.Set.mem rid preferred then rid
    else
      RegionId.Set.fold
        (fun candidate chosen ->
          if chosen = rid && RegionId.Set.mem candidate preferred then candidate
          else chosen)
        regions rid
  in
  (* ``` *)
  (* ```ocaml *)
  let metadata_bindings = ref ctx.metadata_bindings in
  (* ``` *)

  let ctx =
    ctx_map_abs
      (fun abs ->
        if RegionId.Set.disjoint regions abs.regions.owned then abs
        (* ```ocaml *)
        else
          let ctx = ctx_with_metadata_bindings ctx !metadata_bindings in
          preserve_projection_masks span ctx ~metadata_bindings regions abs)
        (* ``` *)

      ctx
  in
  (* ```ocaml *)
  let ctx = ctx_with_metadata_bindings ctx !metadata_bindings in
  (* ``` *)

  (* ```ocaml *)
  (* ```ocaml *)
  let stored_keys = RegionId.Set.union !metadata_keys !retained_source_keys in

  let stored_sources =
    RegionId.Set.fold
      (fun key sources ->
        let source = resolve key in

        match source with
        | RErased -> sources
        | RVar (Free _) when not (List.mem source !observable_sources) -> sources
        (* ```ocaml *)
        | RVar (Free _) | RStatic | RVar (Bound _) | RBody _
          when RegionId.Set.mem key stored_keys || List.mem source !observable_sources ->
            if List.mem_assoc source sources then sources
            else (source, key) :: sources
        | _ -> sources)
      regions []
        (* ``` *)

  in
  let representatives =
    RegionId.Set.fold
      (fun key sources ->
        let source = resolve key in

        List.map
          (fun (stored_source, chosen) ->
            if source = stored_source && RegionId.compare_id key chosen < 0 then
              (stored_source, key)
            else (stored_source, chosen))
          sources)
      regions stored_sources
  in
  let renaming =
    RegionId.Set.fold
      (fun key renaming ->
        let source = resolve key in

        let target =
          match List.assoc_opt source representatives with
          | Some target -> target
          | None -> if RegionId.Set.mem key stored_keys then key else rid

        in
        RegionId.Map.add key target renaming)
      regions RegionId.Map.empty
  in
  let storage_rsubst key =
    Option.value (RegionId.Map.find_opt key renaming) ~default:key
  in
  (* ```ocaml *)
  let runtime_renaming =
    RegionId.Map.mapi (fun key source ->
      if not (RegionId.Set.mem key regions) then key
      else if not (List.mem source !observable_sources) then rid
      else match source with
      | RErased -> key
      | RVar (Free _) | RStatic | RVar (Bound _) | RBody _ ->
          (match List.assoc_opt source representatives with
          | Some representative -> representative
          | None -> [%craise] span "An observable runtime class has no merge representative"))
      !resolved_sources
  in
  let rsubst key =
    if not (RegionId.Set.mem key regions) then key
    else Option.value (RegionId.Map.find_opt key runtime_renaming) ~default:rid
  in
  (* ``` *)

  let metadata_policy =
    (* ```ocaml *)
    ((fun id index original mapped ->
       let info = TypeDeclId.Map.find id ctx.type_ctx.type_infos in
       if not (RegionId.Set.mem index info.metadata_regions) then mapped
       else if not (RegionId.Set.mem index info.stored_regions) then original
       (* The visitor supplies its role-specific map. Declarations use
          storage_rsubst. Live values use rsubst. *)
       else mapped),
    (* ``` *)
     (fun id index ->
       let info = TypeDeclId.Map.find id ctx.type_ctx.type_infos in
       TypeVarId.Set.mem index info.metadata_type_params
       && not (TypeVarId.Set.mem index info.stored_type_params)))
  in

  (* ```ocaml *)
  let ctx =
    transport_ignored_loan_cont_views span ctx surviving_owner
      ~metadata_policy ~metadata_rsubst:storage_rsubst rsubst


  in
  (* ``` *)
  (* ```ocaml *)
  let runtime_owned abs =
    if RegionId.Set.disjoint regions abs.regions.owned then abs.regions.owned
    else
      (* ```ocaml *)
      let selected =
        RegionId.Set.map rsubst (selected_owned_storage_keys ctx abs)

      in
      (* ``` *)
      let owned = RegionId.Set.map rsubst abs.regions.owned in
      let () =
        if (!Config.print_error_diagnostics || !Config.print_error_emitters)
           && RegionId.Set.cardinal regions <= 128
           && RegionId.Set.cardinal abs.regions.owned <= 128
           && RegionId.Set.cardinal owned <= 128 then
          Printf.eprintf
            "Operational region map: survivor=%s owner=%s sources=%s target=%s owned-before=%s selected-storage=%s owned-after=%s\n%!"
            (AbsId.to_string surviving_owner.abs_id) (AbsId.to_string abs.abs_id)
            (RegionId.Set.to_string None regions) (RegionId.to_string rid)
            (RegionId.Set.to_string None abs.regions.owned)
            (RegionId.Set.to_string None selected)
            (RegionId.Set.to_string None owned)
      in
      owned
  in
  (* ```ocaml *)
  let before_projection_substitution = ctx in
  (* ``` *)
  let env =
    Substitute.env_subst_rids ~runtime_owned ~metadata_rsubst:storage_rsubst

      (transport_projection_regions span ctx.type_ctx.type_infos
         ~metadata_bindings:ctx.metadata_bindings)
      metadata_policy

      rsubst ctx.env
  in
  (* ``` *)

  let ctx = { ctx with env } in
  (* ```ocaml *)
  let () =
    if !Config.sanity_checks then begin
      let reports = ref 0 in
      let iter_rows emit (owner : abs) =
        let endpoint = ref 0 in
        let inspect regions witnesses =
          let scope = !endpoint in
          incr endpoint;
          List.iteri (emit scope regions) witnesses.projections
        in
        let visitor =
          object (self)
            inherit [_] iter_tevalue
            method! visit_ECallEndpoints regions witnesses body =
              inspect regions witnesses;
              self#visit_tevalue regions body
            method! visit_ETransportedProj _ transport child =
              self#visit_eproj transport.current_regions child
            method! visit_ETransportedValue _ transport child =
              self#visit_tevalue transport.current_regions child
          end
        in
        Option.iter
          (fun cont ->
            Option.iter (visitor#visit_tevalue owner.regions.owned) cont.output;
            Option.iter (visitor#visit_tevalue owner.regions.owned) cont.input)
          owner.cont;
        List.iter (fun scope -> inspect owner.regions.owned (ValuesUtils.call_scope_witnesses scope))
          owner.call_scopes
      in
      let raw label text =
        let shown = Stdlib.min 65536 (String.length text) in
        Printf.eprintf "%s bytes=%d shown=%d:\n%s\n%!"
          label (String.length text) shown (String.sub text 0 shown)
      in
      let describe phase owner endpoint owned row
          ((proj : symbolic_proj), mask, (actual : tavalue)) =
        let stored = ty_regions ctx.type_ctx.type_infos proj.proj_ty in
        Printf.eprintf
          "Projection substitution %s: survivor=%s owner=%s endpoint=%d row=%d source=%s sources=%s target=%s owned=%s recorded=%s stored=%s selected=%s type-equal=%b actual-is-rty=%b mask-equal=%b\n%!"
          phase (AbsId.to_string surviving_owner.abs_id) (AbsId.to_string owner)
          endpoint row (SymbolicValueId.to_string proj.sv_id)
          (RegionId.Set.show regions) (RegionId.to_string rid)
          (RegionId.Set.show owned) (RegionId.Set.show mask)
          (RegionId.Set.show stored)
          (RegionId.Set.show (RegionId.Set.inter owned stored))
          (proj.proj_ty = actual.ty)
          (ty_is_rty ctx.type_ctx.type_infos actual.ty)
          (RegionId.Set.equal mask (RegionId.Set.inter owned stored));
        raw "raw substitution projector" (show_symbolic_proj proj);
        raw "raw substitution actual type" (Types.show_ty actual.ty)
      in
      env_iter_abs
        (fun owner ->
          iter_rows
            (fun endpoint regions row ((proj, mask, actual) as record) ->
              if !reports < 8
                 && not (proj.proj_ty = actual.ty
                    && ty_is_rty ctx.type_ctx.type_infos actual.ty
                    && RegionId.Set.equal mask
                         (RegionId.Set.inter regions
                            (ty_regions ctx.type_ctx.type_infos proj.proj_ty)))
              then begin
                incr reports;
                describe "after" owner.abs_id endpoint regions row record;
                Option.iter
                  (fun (original : abs) ->
                    iter_rows
                      (fun old_endpoint old_regions old_row
                           ((old_proj, _, _) as old_record) ->
                        if old_endpoint = endpoint && old_row = row
                           && old_proj.sv_id = proj.sv_id then
                          describe "before" original.abs_id old_endpoint
                            old_regions old_row old_record)
                      original)
                  (ctx_lookup_abs_opt before_projection_substitution owner.abs_id)
              end)
            owner)
        ctx.env
    end
  in
  (* ``` *)
  (* ```ocaml *)
  [%ltrace
    "Operational region coalescence result:\n- representative: "
    ^ RegionId.to_string rid
    ^ "\n- result state:\n"
    ^ eval_ctx_to_string ~span:(Some span) ~filter:false ctx];
  (* ``` *)
  ctx_map_abs (rebind_pending_input_aliases span ctx) ctx

(* ```ocaml *)
let ctx_drop_carrierless_owned_regions protected (ctx : eval_ctx) =
  let carried = ref RegionId.Set.empty in
  let carry regions = carried := RegionId.Set.union regions !carried in
  let types = TyCache.create 16 in
  let storage_regions ty =
    match TyCache.find_opt types ty with
    | Some regions -> regions
    | None ->
        let regions = ref RegionId.Set.empty in
        let visitor =
          object
            inherit [_] TypesAnalysis.iter_storage_ty ctx.type_ctx.type_infos
            method! visit_region _ = function
              | RVar (Free id) -> regions := RegionId.Set.add id !regions
              | RStatic | RVar (Bound _) | RBody _ | RErased -> ()
          end
        in
        visitor#visit_ty () ty;
        TyCache.add types ty !regions;
        !regions
  in
  let selected owned ty = carry (RegionId.Set.inter owned (storage_regions ty)) in
  let reference owned ty =
    match ty with
    | TRef (RVar (Free id), _, _) when RegionId.Set.mem id owned ->
        carried := RegionId.Set.add id !carried
    | _ -> ()
  in
  let pending = ref SymbolicPendingSlotMap.empty in
  let register_pending slot =
    pending := SymbolicPendingSlotMap.add slot () !pending;
    carry slot.proj_regions
  in
  let current =
    object (self)
      inherit [_] iter_env as super
      method! visit_ty _ _ = ()
      method! visit_region_id_set _ _ = ()
      method! visit_abs_cont _ _ = ()
      method! visit_tvalue env value =
        (match value.value with
        | VBottom | VLiteral _ -> ()
        | _ -> carry (storage_regions value.ty));
        super#visit_tvalue env value
      method! visit_symbolic_value _ value = carry (storage_regions value.sv_ty)
      method! visit_symbolic_proj owned proj = selected owned proj.proj_ty
      method! visit_tavalue owned value =
        (match value.value with
        | ALoan (AMutLoan _ | ASharedLoan _)
        | ABorrow (AMutBorrow _ | ASharedBorrow _) -> reference owned value.ty
        | ABorrow (AProjSharedBorrow _) -> selected owned value.ty
        | ALoan (AIgnoredMutLoan (_, Some _, _))
        | ABorrow (AIgnoredMutBorrow (Some _, _))
        | ASymbolic (_, APendingLoans _) -> selected owned value.ty
        | _ -> ());
        super#visit_tavalue owned value
      method! visit_APendingSymbolicLoans _ slot = register_pending slot
      method! visit_abs _ abs =
        List.iter (self#visit_tavalue abs.regions.owned) abs.avalues;
        List.iter
          (function PendingParameterScope scope -> register_pending scope.slot | PhysicalInputScope _ -> ())
          abs.call_scopes
    end
  in
  current#visit_env RegionId.Set.empty ctx.env;
  (* ```ocaml *)
  let retained_parent_carrier (abs : abs) branch parent mask =
    let active =
      object
        inherit [_] iter_tavalue as super
        method! visit_ty _ _ = ()
        method! visit_tavalue env value =
          match value.value with
          | ALoan (AIgnoredMutLoan (marker, Some id, child))
            when id = parent && proj_markers_intersect marker branch
                 && normalize_proj_ty ctx.type_ctx.type_infos
                      abs.regions.owned child.ty = mask ->
              raise Utils.Found
          | _ -> super#visit_tavalue env value
      end
    in
    try List.iter (active#visit_tavalue ()) abs.avalues; false
    with Utils.Found -> true
  in
  (* ``` *)
  let latent (abs : abs) =
    let latent_values = EvalueTbl.create 16 in
    object (self)
      inherit [_] iter_tevalue as super
      method! visit_ty _ _ = ()
      method! visit_region_id_set _ _ = ()
      method! visit_EValue _ _ _ = ()
      method! visit_EPendingSymbolicLoans _ slot = register_pending slot
      (* ```ocaml *)
      method! visit_call_endpoint_witnesses _ witnesses =
        List.iter
          (fun (branch, parent, mask, _, producer) ->
            if retained_parent_carrier abs branch parent mask then
              self#visit_tevalue () producer)
          witnesses.parent_carriers
      method! visit_ECallEndpoints _ witnesses body =
        self#visit_call_endpoint_witnesses () witnesses;
        self#visit_tevalue () body
      (* ``` *)
      method! visit_tevalue env value =
        if not (EvalueTbl.mem latent_values value) then (
          EvalueTbl.add latent_values value ();
          super#visit_tevalue env value)
    end
  in
  List.iter
    (function
      (* ```ocaml *)
      | EAbs abs ->
          let visitor = latent abs in
          Option.iter
            (fun cont ->
              Option.iter (visitor#visit_tevalue ()) cont.input;
              Option.iter (visitor#visit_tevalue ()) cont.output)
            abs.cont;
          List.iter
            (fun scope -> visitor#visit_call_endpoint_witnesses () (ValuesUtils.call_scope_witnesses scope))
            abs.call_scopes
      | _ -> ())
      (* ``` *)
    ctx.env;
  let pending_origin origin =
    SymbolicPendingSlotMap.exists
      (fun slot () ->
        slot.root_sv_id = origin.original_root.sv_id
        || slot.root_sv_id = origin.transport_root.sv_id)
      !pending
  in
  let rec precedes route next =
    match next.route_previous with
    | None -> false
    | Some previous -> previous = route || precedes route previous
  in
  let dependencies (abs : abs) =
    let visited = EvalueTbl.create 16 in
    object (self)
      inherit [_] iter_tevalue as super
      method! visit_ty _ _ = ()
      method! visit_region_id_set _ _ = ()
      method! visit_EValue _ _ _ = ()
      method! visit_ELet owned local_owned _ producer next =
        self#visit_tevalue local_owned producer;
        self#visit_tevalue owned next
      method! visit_esymbolic_proj owned proj = selected owned proj.proj_ty
      method! visit_EPendingSymbolicLoans _ slot = carry slot.proj_regions
      method! visit_tevalue owned value =
        let previous =
          Option.value (EvalueTbl.find_opt visited value) ~default:RegionId.Set.empty
        in
        if not (EvalueTbl.mem visited value && RegionId.Set.subset owned previous) then (
          EvalueTbl.replace visited value (RegionId.Set.union owned previous);
          (match value.value with
          | ELoan (EMutLoan _) | EBorrow (EMutBorrow _) -> reference owned value.ty
          | ELoan (EIgnoredMutLoan (_, Some _, _))
          | EBorrow (EIgnoredMutBorrow (Some _, _))
          | ESymbolic (_, EPendingLoans _) -> selected owned value.ty
          | _ -> ());
          super#visit_tevalue owned value)
      method! visit_input_return_supplier owned = function
        | ConcreteInputReturn (_, producer) -> self#visit_tevalue owned producer
        | AbstractionInputReturn (_, _, root, regions, producer) ->
            selected regions root.sv_ty;
            Option.iter (self#visit_tevalue regions) producer
        | SymbolicInputReturn (_, _, proj, root, regions, producer) ->
            selected regions proj.proj_ty;
            selected regions root.sv_ty;
            Option.iter (self#visit_tevalue regions) producer
        | FieldInputReturn (route, _, _, _) ->
            self#visit_input_return_route owned route
        | DeclaredCallInputReturn (_, supplier) ->
            self#visit_input_return_supplier owned supplier
      method! visit_input_return_route owned route =
        self#visit_input_return_supplier owned route.route_supplier;
        List.iter (self#visit_input_return_route owned) route.route_physical_parents
      method! visit_input_physical_return owned returned =
        if (match returned.slot with
          | PendingParameterSlot slot -> SymbolicPendingSlotMap.mem slot !pending
          | PhysicalInputSlot _ -> true) then (
          carry (ValuesUtils.carrier_slot_regions returned.slot);
          current#visit_tvalue owned returned.current_payload;
          self#visit_input_return_supplier owned returned.supplier)
      method! visit_call_endpoint_witnesses owned witnesses =
        List.iter (self#visit_input_physical_return owned) witnesses.physical_returns;
        List.iter
          (fun route ->
            if pending_origin route.route_origin
               && not (List.exists (precedes route) witnesses.return_routes)
            then self#visit_input_return_route owned route)
          witnesses.return_routes;
        List.iter
          (fun (branch, parent, mask, regions, producer) ->
            if retained_parent_carrier abs branch parent mask then (
              selected regions producer.ty;
              self#visit_tevalue regions producer))
          witnesses.parent_carriers
      method! visit_ECallEndpoints owned witnesses body =
        self#visit_call_endpoint_witnesses owned witnesses;
        self#visit_tevalue owned body
      method! visit_eended_mut_loan owned loan =
        self#visit_tevalue owned loan.child;
        self#visit_tevalue owned loan.given_back;
        List.iter (self#visit_input_physical_return owned) loan.physical_returns
      method! visit_eended_ignored_mut_loan owned loan =
        self#visit_tevalue owned loan.child;
        self#visit_tevalue owned loan.given_back;
        List.iter (self#visit_input_physical_return owned) loan.physical_returns
    end
  in
  List.iter
    (function
      | EAbs ({ cont = Some cont; _ } as abs) ->
          let visitor = dependencies abs in
          Option.iter (visitor#visit_tevalue abs.regions.owned) cont.input;
          Option.iter (visitor#visit_tevalue abs.regions.owned) cont.output;
          List.iter
            (fun scope -> visitor#visit_call_endpoint_witnesses abs.regions.owned (ValuesUtils.call_scope_witnesses scope))
            abs.call_scopes
      | EAbs abs ->
          let visitor = dependencies abs in
          List.iter
            (fun scope -> visitor#visit_call_endpoint_witnesses abs.regions.owned (ValuesUtils.call_scope_witnesses scope))
            abs.call_scopes
      | _ -> ())
    ctx.env;
  ctx_map_abs
    (fun abs ->
      if not abs.can_end || AbsId.Set.mem abs.abs_id protected
         || RegionId.Set.cardinal abs.regions.owned < 2
      then abs
      else
        let owned = RegionId.Set.inter abs.regions.owned !carried in
        let owned =
          if RegionId.Set.is_empty owned then
            RegionId.Set.singleton (RegionId.Set.min_elt abs.regions.owned)
          else owned
        in
        if RegionId.Set.equal owned abs.regions.owned then abs
        else { abs with regions = { owned } })
    ctx
(* ``` *)

(** End the shared loans in a given abstraction which do not have corresponding
    shared borrows in the context *)
let end_endable_shared_loans_at_abs (span : Meta.span) (ctx : eval_ctx)
    (abs_id : AbsId.id) : eval_ctx =
  (* Compute the set of shared borrows appearing in the context *)
  let bids = (fst (compute_ctx_ids ctx)).borrow_ids in

  (* Update the shared borrows in the region abstraction - we assume the
     region abstraction has been destructured
  *)
  let abs = ctx_lookup_abs ctx abs_id in
  let end_value (av : tavalue) : tavalue option =
    match av.value with
    | ALoan (ASharedLoan (pm, bid, sv, child))
      when not (BorrowId.Set.mem bid bids) ->
        if
          tvalue_has_loans_or_borrows (Some span) ctx sv
          || not (is_aignored child.value)
        then Some { av with value = ALoan (AEndedSharedLoan (pm, sv, child)) }
        else None
    | _ -> Some av
  in

  let avalues = List.filter_map end_value abs.avalues in
  let abs = { abs with avalues } in
  fst (ctx_subst_abs span ctx abs_id abs)

let merge_into_first_abstraction (span : Meta.span) (abs_kind : abs_kind)
    ?diagnostic
    ~(can_end : bool) ~(with_abs_conts : bool)
    (merge_funs : merge_duplicates_funcs option) (ctx : eval_ctx)
    (abs_id0 : AbsId.id) (abs_id1 : AbsId.id) : eval_ctx * AbsId.id =
  let diagnostic_before = ctx in
  let diagnostic_isolation = Option.map (fun _ -> ref None) diagnostic in
  (* Lookup the abstractions *)
  let abs0 = ctx_lookup_abs ctx abs_id0 in
  let abs1 = ctx_lookup_abs ctx abs_id1 in

  [%ltrace
    "- abs0:\n"
    ^ abs_to_string span ctx abs0
    ^ "\n\n- abs1:\n"
    ^ abs_to_string span ctx abs1];

  (* Self-collapse reconciles complementary branch ownership, but must not
     execute or compose the abstraction's continuation a second time. *)
  (* ```ocaml *)
  let metadata_bindings = ref ctx.metadata_bindings in
  (* ``` *)

  let nabs =
    if abs_id0 = abs_id1 then (
      match merge_funs with
      | None -> abs0
      | Some _ when not (abs_has_markers abs0) -> abs0
      | Some merge_funs ->
          let avalues =
            merge_abstractions_merge_markers span merge_funs ctx
              abs0.regions.owned abs0.avalues
          in
          [%cassert] span (avalues <> abs0.avalues)
            ("Self-collapse did not reconcile complementary ownership:\n"
            ^ abs_to_string span ctx abs0);
          { abs0 with avalues })
    else
      (* ```ocaml *)
      merge_abstractions span abs_kind ?diagnostic_isolation ~can_end ~with_abs_conts ~metadata_bindings
        merge_funs ctx abs0 abs1
      (* ``` *)

  in
  (* ```ocaml *)
  let ctx = ctx_with_metadata_bindings ctx !metadata_bindings in
  (* ``` *)


  (* Update the environment: replace the abstraction 0 with the result of the merge,
     remove the abstraction 1 *)
  let ctx = fst (ctx_subst_abs span ctx abs_id0 nabs) in
  let ctx =
    if abs_id0 = abs_id1 then ctx
    else
      (* Substitution already retargeted children of abs0. Children of abs1
         must likewise depend on the merged owner; removing abs1 outright
         would silently erase their outlives dependency. *)
      let ctx =
        ctx_map_abs
          (fun abs ->
            if AbsId.Set.mem abs_id1 abs.parents then
              {
                abs with
                parents =
                  AbsId.Set.add nabs.abs_id
                    (AbsId.Set.remove abs_id1 abs.parents);
              }
            else abs)
          ctx
      in
      fst (ctx_remove_abs span ctx abs_id1)
  in
  (* Concrete payload matching can introduce loans in fresh abstractions.
     Install those owners before substituting merged regions throughout the
     environment, including their continuations. *)
  let ctx =
    match merge_funs with
    | None -> ctx
    | Some merge_funs ->
        let introduced, bindings = merge_funs.drain_new_abstractions () in
        let bindings =
          merge_metadata_bindings (Some span) ctx.metadata_bindings bindings
        in
        let ctx = ctx_with_metadata_bindings ctx bindings in
        { ctx with env = List.map (fun abs -> EAbs abs) introduced @ ctx.env }
  in
  Invariants.opt_type_check_abs span ctx nabs;
  (* ```ocaml *)
  let surviving_masks =
    object
      inherit [_] iter_tavalue as super
      method! visit_tavalue env av =
        (match av.value with
        | ASymbolic (_, AProjLoans { proj; _ }) ->
            [%ltrace
              "Surviving operational loan:\n- owner: "
              ^ AbsId.to_string nabs.abs_id
              ^ "\n- owned: " ^ RegionId.Set.to_string None nabs.regions.owned
              ^ "\n- root and selected source positions: " ^ tavalue_to_string ctx av
              ^ "\n- normalized mask: "
              ^ ty_to_string ctx
                  (normalize_proj_ty ctx.type_ctx.type_infos nabs.regions.owned proj.proj_ty)]
        | ALoan (AIgnoredMutLoan _) ->
            [%ltrace
              "Surviving operational ignored loan:\n- owner: "
              ^ AbsId.to_string nabs.abs_id
              ^ "\n- owned: " ^ RegionId.Set.to_string None nabs.regions.owned
              ^ "\n- root and selected source positions: " ^ tavalue_to_string ctx av
              ^ "\n- normalized mask: "
              ^ ty_to_string ctx
                  (normalize_proj_ty ctx.type_ctx.type_infos nabs.regions.owned av.ty)]
        | _ -> ());
        super#visit_tavalue env av
    end
  in
  List.iter (surviving_masks#visit_tavalue ()) nabs.avalues;
  (* ``` *)

  (* Merge all the regions from the abstraction into one (the first - i.e., the
     one with the smallest id). Note that we need to do this in the whole
     environment, as those regions may be referenced as ancestor regions by
     the other abstractions, and may be present in symbolic values, etc. (this
     is not the case if there are no nested borrows, but we anticipate).
  *)
  let ctx =
    let regions = nabs.regions.owned in
    (* Pick the first region id (this is the smallest) *)
    let rid = RegionId.Set.min_elt regions in
    (* If there is only one region, do nothing *)
    if RegionId.Set.cardinal regions = 1 then ctx
    else
      let rids = RegionId.Set.remove rid regions in
      (* ```ocaml *)
      ctx_merge_regions span ctx ~surviving_owner:nabs rid rids
      (* ``` *)

  in

  (* End the loans in the region abstraction which don't have corresponding borrows anymore *)
  let ctx = end_endable_shared_loans_at_abs span ctx nabs.abs_id in

  (match diagnostic with
  | None -> ()
  | Some diagnostic ->
      (try
         let isolated_left, isolated_right, left_coordinates, right_coordinates =
           match diagnostic_isolation with
           | Some cell -> (match !cell with
               | Some captured -> captured
               | None -> (abs0, abs1, RegionId.Map.empty, RegionId.Map.empty))
           | None -> (abs0, abs1, RegionId.Map.empty, RegionId.Map.empty)
         in
         let index = diagnostic.trace_count in
         diagnostic.trace_count <- index + 1;
         diagnostic.trace_records.(index mod 128) <- Some {
           merge_index = index; merge_phase = diagnostic.trace_phase;
           merge_step = diagnostic.trace_step; merge_fixed = diagnostic.trace_fixed;
           merge_preserved = diagnostic.trace_preserved;
           merge_before = diagnostic_before; merge_left = abs0; merge_right = abs1;
           merge_isolated_left = isolated_left; merge_isolated_right = isolated_right;
           merge_left_coordinates = left_coordinates;
           merge_right_coordinates = right_coordinates;
           merge_after = ctx; merge_result = nabs.abs_id;
           merge_normalization_callback = None;
           merge_selection = None;
         }
       with _ -> ()));
  (* Return *)
  (ctx, nabs.abs_id)

(* Function-call projections, structured ADTs and recursive symbolic trees keep
   positional input/output slots, including ignored and ended ones. Normalizing
   a flat ownership bag is not valid for these abstraction layouts. *)

(** Reorder the loans and borrows inside the fresh abstractions.

    See {!reorder_fresh_abs}.

    TODO: having to do this is a bit annoying. We should rather generalize the
    match/join operations to not be dependent on the order of the borrows/loans.
*)
let abs_has_fixed_avalue_layout (abs : abs) : bool =
  match abs.cont with
  | Some { output = _; input = Some input }
    when (match (call_protocol_body input).value with
         | EApp (EFunCall _, _) -> true
         | _ -> false) ->
      true
  | _ -> (
      let visitor =
        object
          inherit [_] iter_tavalue
          method! visit_AAdt _ _ = raise Utils.Found
          method! visit_ATransportedValue _ _ _ = raise Utils.Found
          method! visit_AIgnoredMutBorrow _ _ _ = raise Utils.Found
          method! visit_AEndedIgnoredMutBorrow _ _ = raise Utils.Found
          method! visit_AIgnoredMutLoan _ _ _ _ = raise Utils.Found
          method! visit_AEndedIgnoredMutLoan _ _ = raise Utils.Found
          method! visit_AEndedMutLoan _ _ = raise Utils.Found

          method! visit_aproj _ =
            function
            | APendingLoans _ | APendingSymbolicLoans _ -> raise Utils.Found
            | ATransportedProj _ -> raise Utils.Found
            | AProjLoans { consumed; borrows; _ }
            | AEndedProjLoans { consumed; borrows; _ }
              when consumed <> [] || borrows <> [] -> raise Utils.Found
            | (AProjBorrows { loans; _ } | AEndedProjBorrows { loans; _ })
              when loans <> [] -> raise Utils.Found
            | _ -> ()
        end
      in
      try
        (* A pending projection at the root is an element of a destructured
           ownership bag (see {!InterpBorrows.destructure_abs}), like the root
           projections: only nested ones fix a positional layout. *)
        List.iter
          (fun (av : tavalue) ->
            match av.value with
            | ASymbolic (_, (APendingLoans _ | APendingSymbolicLoans _)) -> ()
            | _ -> visitor#visit_tavalue () av)
          abs.avalues;
        false
      with Utils.Found -> true)

let reorder_loans_borrows_in_fresh_abs (span : Meta.span) (allow_markers : bool)
    (old_abs_ids : AbsId.Set.t) (ctx : eval_ctx) : eval_ctx =
  let type_infos = ctx.type_ctx.type_infos in
  let reorder_in_fresh_abs (abs : abs) : abs =
    [%ltrace "abs:\n" ^ abs_to_string span ctx abs];
    (* Filter the avalues *)
    let rec filter (v : tavalue) : bool =
      match v.value with
      | ATransportedValue (_, child) -> filter child
      | AAdt _ | ASymbolic _ -> true
      | ALoan lc -> (
          match lc with
          | AMutLoan _ | ASharedLoan _ -> true
          | AEndedMutLoan { child; given_back; given_back_meta = _ } ->
              [%cassert] span (is_aignored child.value) "Not supported yet";
              [%cassert] span (is_aignored given_back.value) "Not supported yet";
              false
          | AEndedSharedLoan (_, sv, child) ->
              [%cassert] span (is_aignored child.value) "Not supported yet";
              [%cassert] span
                (not
                   (ValuesUtils.value_has_loans_or_borrows (Some span)
                      type_infos sv.value))
                "Not implemented yet";
              false
          | AIgnoredMutLoan (_, _, child) ->
              [%cassert] span (is_aignored child.value) "Not supported yet";
              false
          | AEndedIgnoredMutLoan { child; given_back; _ } ->
              [%cassert] span (is_aignored child.value) "Not supported yet";
              [%cassert] span (is_aignored given_back.value) "Not supported yet";
              false
          | AIgnoredSharedLoan child ->
              [%cassert] span (is_aignored child.value) "Not supported yet";
              false)
      | ABorrow bc -> (
          match bc with
          | AMutBorrow _ | ASharedBorrow _ -> true
          | AIgnoredMutBorrow (_, child) ->
              [%cassert] span (is_aignored child.value) "Not supported yet";
              false
          | AEndedMutBorrow (_, child) ->
              [%cassert] span (is_aignored child.value) "Not supported yet";
              false
          | AEndedSharedBorrow -> false
          | AEndedIgnoredMutBorrow { child; given_back; given_back_meta = _ } ->
              [%cassert] span (is_aignored child.value) "Not supported yet";
              [%cassert] span (is_aignored given_back.value) "Not supported yet";
              false
          | AProjSharedBorrow _ -> [%craise] span "Not supported yet")
      | AIgnored _ -> false
    in
    let avalues = List.filter filter abs.avalues in
    (* Pending loans (nested borrows) are inputs, like the loans: they go
       between the loans and the loan projectors, sorted by parent borrow. *)
    let pendings, avalues =
      List.partition
        (fun (av : tavalue) ->
          match av.value with
          | ASymbolic (_, APendingLoans _) -> true
          | _ -> false)
        avalues
    in
    let pending_symbolic, avalues =
      List.partition
        (fun (av : tavalue) ->
          match av.value with
          | ASymbolic (_, APendingSymbolicLoans _) -> true
          | _ -> false)
        avalues
    in

    (* Split between the loans and borrows, and between the concrete
       and symbolic values. *)
    let is_borrow (av : tavalue) : bool =
      match av.value with
      | ABorrow _ | ASymbolic (_, AProjBorrows _) -> true
      | ALoan _ | ASymbolic (_, AProjLoans _) -> false
      | _ -> [%craise] span ("Unexpected avalue: " ^ tavalue_to_string ctx av)
    in
    let is_concrete (av : tavalue) : bool =
      match av.value with
      | ABorrow _ | ALoan _ -> true
      | ASymbolic (_, (AProjBorrows _ | AProjLoans _)) -> false
      | _ -> [%craise] span ("Unexpected avalue: " ^ tavalue_to_string ctx av)
    in
    let aborrows, aloans = List.partition is_borrow avalues in
    let aborrows, borrow_projs = List.partition is_concrete aborrows in
    let aloans, loan_projs = List.partition is_concrete aloans in

    (* Reoder the borrows, and the loans.

       After experimenting, it seems that a good way of reordering the loans
       and the borrows to find fixed points is simply to sort them by increasing
       order of id (taking the smallest id of a set of ids, in case of sets).

       This is actually not as arbitrary as it might seem, because the ids give
       us the order in which we introduced those borrows/loans.

       We do the same thing for the symbolic values: we use the symbolic ids.
       The final order is:
         borrows, borrow projectors, loans, loan projectors
       (all sorted by increasing id)
    *)
    let get_borrow_id (av : tavalue) : BorrowId.id =
      match av.value with
      | ABorrow (AMutBorrow (pm, bid, _) | ASharedBorrow (pm, bid, _)) ->
          [%sanity_check] span (allow_markers || pm = PNone);
          bid
      | _ -> [%craise] span ("Unexpected value: " ^ tavalue_to_string ctx av)
    in
    let get_loan_id (av : tavalue) : BorrowId.id =
      match av.value with
      | ALoan (AMutLoan (pm, lid, _)) ->
          [%sanity_check] span (allow_markers || pm = PNone);
          lid
      | ALoan (ASharedLoan (pm, lid, _, _)) ->
          [%sanity_check] span (allow_markers || pm = PNone);
          lid
      | _ -> [%craise] span ("Unexpected value: " ^ tavalue_to_string ctx av)
    in
    let get_symbolic_id (av : tavalue) : SymbolicValueId.id =
      match av.value with
      | ASymbolic (pm, aproj) -> begin
          [%sanity_check] span (allow_markers || pm = PNone);
          match aproj with
          | AProjLoans { proj; _ } | AProjBorrows { proj; _ } -> proj.sv_id
          | _ -> [%craise] span "Unexpected"
        end
      | _ -> [%craise] span ("Unexpected value: " ^ tavalue_to_string ctx av)
    in
    let marker_of (av : tavalue) =
      match av.value with
      | ABorrow (AMutBorrow (pm, _, _) | ASharedBorrow (pm, _, _))
      | ALoan (AMutLoan (pm, _, _) | ASharedLoan (pm, _, _, _))
      | ASymbolic (pm, _) -> pm
      | _ -> [%internal_error] span
    in
    let compare_same_id (v0 : tavalue) (v1 : tavalue) =
      (* Opposite markers are distinct alternatives. Disjoint projections of
         one symbolic value are distinct owners even under the same marker. *)
      let order = compare_proj_marker (marker_of v0) (marker_of v1) in
      if order <> 0 then order
      else
        match (v0.value, v1.value) with
        | ( ASymbolic
              (_, (AProjLoans { proj = p0; _ } | AProjBorrows { proj = p0; _ })),
            ASymbolic
              (_, (AProjLoans { proj = p1; _ } | AProjBorrows { proj = p1; _ }))
          ) ->
            compare_ty
              (normalize_proj_ty ctx.type_ctx.type_infos abs.regions.owned p0.proj_ty)
              (normalize_proj_ty ctx.type_ctx.type_infos abs.regions.owned p1.proj_ty)
        | _ -> 0
    in
    let compare_pair :
        'a. ('a -> 'a -> int) -> 'a * tavalue -> 'a * tavalue -> int =
     fun compare_id x y ->
      let fst = compare_id (fst x) (fst y) in
      let fst = if fst <> 0 then fst else compare_same_id (snd x) (snd y) in
      if fst = 0 then
        [%craise] span
          ("Unexpected: can't compare: '"
          ^ tavalue_to_string ctx (snd x)
          ^ "' with '"
          ^ tavalue_to_string ctx (snd y)
          ^ "'");
      fst
    in
    (* We use ordered maps to reorder the borrows and loans *)
    let reorder :
        'a. (tavalue -> 'a) -> ('a -> 'a -> int) -> tavalue list -> tavalue list
        =
     fun get_id compare_id values ->
      let values = List.map (fun v -> (get_id v, v)) values in
      List.map snd (List.stable_sort (compare_pair compare_id) values)
    in
    let aborrows = reorder get_borrow_id compare_borrow_id aborrows in
    let borrow_projs =
      reorder get_symbolic_id compare_symbolic_value_id borrow_projs
    in
    let aloans = reorder get_loan_id compare_borrow_id aloans in
    let loan_projs =
      reorder get_symbolic_id compare_symbolic_value_id loan_projs
    in
    let get_parent_borrow_id (av : tavalue) : BorrowId.id =
      match av.value with
      | ASymbolic (pm, APendingLoans bid) ->
          [%sanity_check] span (allow_markers || pm = PNone);
          bid
      | _ -> [%craise] span ("Unexpected value: " ^ tavalue_to_string ctx av)
    in
    let pendings = reorder get_parent_borrow_id compare_borrow_id pendings in
    let get_pending_symbolic_slot (av : tavalue) : symbolic_pending_slot =
      match av.value with
      | ASymbolic (pm, APendingSymbolicLoans slot) ->
          [%sanity_check] span (allow_markers || pm = PNone);
          slot
      | _ -> [%craise] span ("Unexpected value: " ^ tavalue_to_string ctx av)
    in
    let pending_symbolic =
      reorder get_pending_symbolic_slot compare_symbolic_pending_slot
        pending_symbolic
    in
    let avalues =
      List.concat
        [ aborrows; borrow_projs; aloans; pendings; pending_symbolic; loan_projs ]
    in
    { abs with avalues }
  in

  let reorder_in_abs (abs : abs) =
    (* We do not update the fixed region abstractions as well as the ones
       which were introduced exactly by function calls (we update those which
       were introduced when promoting anonymous values to region abstractions
       or by merging region abstractions). We also do not reorder the abstractions
       containing ADTs (those should actually have been introduced by function
       calls).

       TODO: remove the need to reorder the values by making the match/join operations
       more general.
     *)
    if
      AbsId.Set.mem abs.abs_id old_abs_ids
      || abs_has_fixed_avalue_layout abs
      || List.exists
           (fun (av : tavalue) ->
             match av.value with
             | ABorrow (AProjSharedBorrow _) | ALoan (AEndedSharedLoan _) ->
                 true
             | _ -> false)
           abs.avalues
    then abs
    else reorder_in_fresh_abs abs
  in

  let env = env_map_abs reorder_in_abs ctx.env in

  { ctx with env }

type tavalue_list = tavalue list [@@deriving ord, show]

module OrderedTypedAvalueList :
  Collections.OrderedType with type t = tavalue list = struct
  type t = tavalue_list

  let compare x y = compare_tavalue_list x y
  let to_string x = show_tavalue_list x
  let pp_t fmt x = Format.pp_print_string fmt (show_tavalue_list x)
  let show_t x = show_tavalue_list x
end

let reorder_fresh_abs_aux (span : Meta.span) (old_abs_ids : AbsId.Set.t)
    (ctx : eval_ctx) : eval_ctx =
  (* **WARNING:** remember that the environments store the bindings in *reverse*
     order (the fresh values/abstractions get pushed at the beginning of the list,
     and when printing the environments we reverse them first) *)
  (* Split between the fresh abstractions and the rest of the context *)
  let env, fresh_abs =
    List.partition
      (function
        | EAbs abs -> AbsId.Set.mem abs.abs_id old_abs_ids
        | _ -> true)
      ctx.env
  in

  (* Reorder the fresh abstractions.

     We use the content of the abstractions to reorder them.
     In practice, this allows us to reorder the abstractions by using the ids
     of the loans, borrows and symbolic values. This is far from perfect, but
     allows us to have a quite simple matching algorithm for now, to compute
     the joins as well as to check whether two environments are equivalent.
     We may want to make this algorithm more general in the future.
  *)
  let cmp abs0 abs1 =
    match (abs0, abs1) with
    | EAbs abs0, EAbs abs1 -> compare_tavalue_list abs0.avalues abs1.avalues
    | _ -> [%internal_error] span
  in
  let fresh_abs = List.sort cmp fresh_abs |> List.rev in

  (* Reconstruct the environment *)
  let env = fresh_abs @ env in

  { ctx with env }

let reorder_fresh_abs (span : Meta.span) (allow_markers : bool)
    (old_abs_ids : AbsId.Set.t) (ctx : eval_ctx) : eval_ctx =
  reorder_loans_borrows_in_fresh_abs span allow_markers old_abs_ids ctx
  |> reorder_fresh_abs_aux span old_abs_ids

type proj_ctx = {
  inside_output : bool;  (** Are we inside an abstraction output expression? *)
}

let project_context (span : Meta.span) (fixed_aids : AbsId.Set.t)
    (pm : proj_marker) (ctx : eval_ctx) : eval_ctx =
  [%cassert] span (pm = PLeft || pm = PRight) "Invalid input";
  let project_left = pm = PLeft in

  let preserve (pm' : proj_marker) =
    match (pm, pm') with
    | PLeft, (PNone | PLeft) -> true
    | PRight, (PNone | PRight) -> true
    | _ -> false
  in

  let visitor =
    object (self)
      inherit [_] map_eval_ctx as super

      (* By overriding this method to raise an exception we make sure we do not
         miss any projection marker *)
      method! visit_proj_marker _ _ = [%internal_error] span

      method! visit_ASymbolic env pm aproj =
        if preserve pm then
          let aproj = self#visit_aproj env aproj in
          ASymbolic (PNone, aproj)
        else
          (* The marker belongs to the whole symbolic projection tree. Unlike
             concrete child avalues, descendants carry no independent marker:
             none of this branch's owners belong to the selected context. *)
          AIgnored None

      method! visit_ALoan env lc =
        match lc with
        | AMutLoan (pm, lid, child) ->
            if preserve pm then
              let child = self#visit_tavalue env child in
              ALoan (AMutLoan (PNone, lid, child))
            else (
              [%cassert] span (is_aignored child.value) "Not implemented";
              AIgnored None)
        | ASharedLoan (pm, lid, shared, child) ->
            if preserve pm then
              let child = self#visit_tavalue env child in
              ALoan (ASharedLoan (PNone, lid, shared, child))
            else
              let child = self#visit_tavalue env child in
              if is_aignored child.value then AIgnored None
              else ALoan (AIgnoredSharedLoan child)
        | AEndedSharedLoan (pm, shared, child) ->
            (* Ending a shared loan does not erase its branch provenance. Its
               retained value still belongs to the selected branch, just like
               the value of a live shared loan. *)
            if preserve pm then
              let child = self#visit_tavalue env child in
              ALoan (AEndedSharedLoan (PNone, shared, child))
            else
              let child = self#visit_tavalue env child in
              if is_aignored child.value then AIgnored None
              else ALoan (AIgnoredSharedLoan child)
        | AIgnoredMutLoan (pm, bid, child) ->
            if preserve pm then
              let child = self#visit_tavalue env child in
              ALoan (AIgnoredMutLoan (PNone, bid, child))
            else AIgnored None
        | AEndedMutLoan _
        | AEndedIgnoredMutLoan _
        | AIgnoredSharedLoan _ ->
            (* Those do not have projection markers *)
            super#visit_ALoan env lc

      method! visit_ABorrow env bc =
        match bc with
        | AMutBorrow (pm, bid, child) ->
            if preserve pm then
              let child = self#visit_tavalue env child in
              ABorrow (AMutBorrow (PNone, bid, child))
            else (
              [%cassert] span (is_aignored child.value) "Not implemented";
              AIgnored None)
        | ASharedBorrow (pm, bid, sid) ->
            if preserve pm then ABorrow (ASharedBorrow (PNone, bid, sid))
            else AIgnored None
        | AProjSharedBorrow (pm, asb) ->
            if preserve pm then ABorrow (AProjSharedBorrow (PNone, asb))
            else AIgnored None
        | AIgnoredMutBorrow _
        | AEndedMutBorrow _
        | AEndedSharedBorrow
        | AEndedIgnoredMutBorrow _ ->
            (* Those do not have projection markers *)
            super#visit_ABorrow env bc

      (*
```ocaml
      *)
      method! visit_ECallEndpoints env witnesses body =
        let parent_carriers =
          List.filter_map
            (fun (branch, parent, mask, regions, producer) ->
              if preserve branch then
                Some (PNone, parent, mask, regions, self#visit_tevalue env producer)
              else None)
            witnesses.parent_carriers
        in
        ECallEndpoints ({ witnesses with parent_carriers }, self#visit_tevalue env body)
      (*
```
      *)
      method! visit_tevalue env v =
        (* We need to preserve the type when projecting joins (the type
           is not always constent because of loans) - TODO: remove those
           types. *)
        match v.value with
        | EJoinMarkers (left, right) ->
            let v = if project_left then left else right in
            self#visit_tevalue env v
        | _ -> super#visit_tevalue env v

      method! visit_ESymbolic env pm eproj =
        if preserve pm then
          let eproj = self#visit_eproj env eproj in
          ESymbolic (PNone, eproj)
        else
          let rec discard = function
            | ETransportedProj (_, child) -> discard child
            | EPendingLoans _ | EPendingSymbolicLoans _
            | EProjLoans _ | EEndedProjLoans _ -> EBottom
            | EProjBorrows _ | EEndedProjBorrows _ ->
                if env.inside_output then EIgnored else EBottom
            | EEmpty -> EIgnored
          in
          discard eproj

      method! visit_ELoan env lc =
        match lc with
        | EMutLoan (pm, lid, child) ->
            if preserve pm then
              let child = self#visit_tevalue env child in
              ELoan (EMutLoan (PNone, lid, child))
            else (
              [%cassert] span (is_eignored child.value) "Not implemented";
              EBottom)
        | EIgnoredMutLoan (pm, lid, child) ->
            if preserve pm then
              let child = self#visit_tevalue env child in
              ELoan (EIgnoredMutLoan (PNone, lid, child))
            else if env.inside_output then EIgnored else EBottom
        | EEndedMutLoan _ | EEndedIgnoredMutLoan _ ->
            (* Those do not have projection markers *)
            super#visit_ELoan env lc

      method! visit_EBorrow env lc =
        match lc with
        | EMutBorrow (pm, bid, child) ->
            if preserve pm then
              let child = self#visit_tevalue env child in
              EBorrow (EMutBorrow (PNone, bid, child))
            else (
              [%cassert] span (is_eignored child.value) "Not implemented";
              if env.inside_output then EIgnored else EBottom)
        | EIgnoredMutBorrow _ | EEndedMutBorrow _ | EEndedIgnoredMutBorrow _ ->
            (* Those do not have projection markers *)
            super#visit_EBorrow env lc

      method! visit_abs_cont env abs =
        let { output; input } = abs in
        let output =
          Option.map (self#visit_tevalue { inside_output = true }) output
        in
        let input = Option.map (self#visit_tevalue env) input in
        { output; input }
    end
  in
  (* Project *)
  let ctx = visitor#visit_eval_ctx { inside_output = false } ctx in

  (* Simplify the region abstractions, and filter the ones which have become
     empty because of the projection *)
  let removed_parents = ref AbsId.Map.empty in
  let update_binding (e : env_elem) : env_elem option =
    match e with
    | EAbs abs ->
        let keep_value (e : tavalue) : bool = not (is_aignored e.value) in
        if
          (not abs.can_end)
          || AbsId.Set.mem abs.abs_id fixed_aids
          (* A call keeps its field positions only while a selected value remains. *)
          || (abs_has_fixed_avalue_layout abs
             && List.exists keep_value abs.avalues)
        then Some e
        else
          let avalues = List.filter keep_value abs.avalues in
          if avalues = [] then (
            removed_parents :=
              AbsId.Map.add abs.abs_id abs.parents !removed_parents;
            None)
          else Some (EAbs { abs with avalues })
    | EBinding _ | EFrame -> Some e
  in
  let env = List.filter_map update_binding ctx.env in
  (* An absent branch may erase an intermediate abstraction without erasing
     its descendants or ancestors. Contract only those erased nodes: surviving
     children still depend on every surviving ancestor of their old parents. *)
  let env =
    if AbsId.Map.is_empty !removed_parents then env
    else
      let removed_parents = !removed_parents in
      let resolved = ref AbsId.Map.empty in
      let rec expand seen parents =
        AbsId.Set.fold
          (fun parent ancestors ->
            match AbsId.Map.find_opt parent removed_parents with
            | None -> AbsId.Set.add parent ancestors
            | Some grandparents ->
                let inherited =
                  match AbsId.Map.find_opt parent !resolved with
                  | Some inherited -> inherited
                  | None ->
                      [%cassert] span
                        (not (AbsId.Set.mem parent seen))
                        "Cycle among projected-away abstraction parents";
                      let inherited =
                        expand (AbsId.Set.add parent seen) grandparents
                      in
                      resolved := AbsId.Map.add parent inherited !resolved;
                      inherited
                in
                AbsId.Set.union ancestors inherited)
          parents AbsId.Set.empty
      in
      let is_removed parent = AbsId.Map.mem parent removed_parents in
      let rec update_parents env =
        match env with
        | [] -> []
        | binding :: tail ->
            let nbinding =
              match binding with
              | EAbs abs when AbsId.Set.exists is_removed abs.parents ->
                  let parents = expand AbsId.Set.empty abs.parents in
                  EAbs { abs with parents }
              | _ -> binding
            in
            let ntail = update_parents tail in
            if nbinding == binding && ntail == tail then env
            else nbinding :: ntail
      in
      update_parents env
  in
  { ctx with env }

let add_abs_cont_to_abs span (ctx : eval_ctx) (abs : abs) (abs_fun : abs_fun) :
    abs =
  [%ltrace "- abs:\n" ^ abs_to_string span ctx abs];
  match abs.cont with
  (* ```ocaml *)
  | Some { output = None; input = Some input }
    when (match (call_protocol_body input).value with
          | EApp (EInputAbs _, _) -> true
          | _ -> false) ->
  (* ``` *)
      (* Joining branch copies does not introduce a new synthesis-input owner.
         Its sentinel must continue to refer to the original function input,
         rather than being replaced by a freshly manufactured join/loop call. *)
      abs
  | _ ->
      (* We need to destructure the abs, otherwise when translating the abs as a
     continuation it is tricky to compute its type when some loans have been
     ended but not others (in particular, it is tricky if we have an ADT
     containing partially ended loans) *)
      let call_scopes =
        pending_symbolic_input_scopes span abs.call_scopes
          [ Option.bind abs.cont (fun cont -> cont.input) ]
      in
      let abs = destructure_abs span abs.kind ~can_end:abs.can_end ctx abs in
      [%ldebug "- abs after destructure:\n" ^ abs_to_string span ctx abs];
      (* Retrieve the *mutable* borrows/loans from the abstraction values *)
      let borrows : tevalue list ref = ref [] in
      let loans : tevalue list ref = ref [] in
      let evalue_of_avalue = project_avalue_to_evalue span ctx abs in
      let get_borrow_loan (x : tavalue) : unit =
        let projected = evalue_of_avalue x in
        let projected =
          match x.value with
          | ASymbolic (_, APendingSymbolicLoans slot) ->
              scope_pending_symbolic_input span call_scopes slot projected
          | _ -> projected
        in
        if not (is_eignored projected.value) then
          let rec is_borrow (value : tavalue) =
            let rec projection_is_borrow = function
              | ATransportedProj (_, child) -> projection_is_borrow child
              | AProjBorrows _ | AEndedProjBorrows _ -> true
              | APendingLoans _ | APendingSymbolicLoans _
              | AProjLoans _ | AEndedProjLoans _ -> false
              | AEmpty -> [%internal_error] span
            in
            match value.value with
            | ATransportedValue (_, child) -> is_borrow child
            | ABorrow _ -> true
            | ALoan _ -> false
            | ASymbolic (_, projection) -> projection_is_borrow projection
            | AAdt adt -> adt.borrow_proj
            | AIgnored _ -> [%internal_error] span
          in
          if is_borrow x then borrows := projected :: !borrows
          else loans := projected :: !loans
      in
      List.iter get_borrow_loan abs.avalues;

      (* Transform them into input/output expressions *)
      let output = mk_etuple ~borrow_proj:true (List.rev !borrows) in
      let input = EApp (abs_fun, [ List.rev !loans ]) in
      let input : tevalue = { value = input; ty = output.ty } in

      (* Put everything together *)
      let cont : abs_cont option =
        Some { output = Some output; input = Some input }
      in
      { abs with cont }
