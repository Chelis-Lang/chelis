open Types
open Values
open ValuesUtils
open TypesUtils
open Cps
open Contexts
open InterpUtils
open InterpBorrows
open InterpAbs
open InterpJoinCore
open InterpReduceCollapse
open InterpMatchCtxs

(** The local logger *)
let log = Logging.join_log

(** Auxiliary helper for [reborrow_ashared_loans_symbolic_mutable_borrows] *)
let reborrow_ashared_loans (span : Meta.span) (loop_id : LoopId.id option)
    ~(with_abs_conts : bool) : cm_fun =
 fun ctx0 ->
  let ctx = ctx0 in
  [%ldebug "ctx0:\n" ^ eval_ctx_to_string ctx];

  (* Gather abstractions to locate the protected shared payloads below. *)
  let absl =
    List.filter_map
      (function
        | EBinding _ | EFrame -> None
        | EAbs abs -> Some abs)
      ctx.env
  in

  (* Map from the fresh sids to the original symbolic values *)
  let sid_subst = ref [] in
  let fresh_absl = ref [] in
  let metadata_bindings = ref ctx.metadata_bindings in

  (* The abstraction owning the region [rid] of a copy: it holds shared
     reborrows of the original and the loans of the copy *)
  let push_copy_abs (rid : RegionId.id) (avalues : tavalue list) : unit =
    let cont =
      if with_abs_conts then
        Some
          {
            output = Some (mk_etuple ~borrow_proj:true []);
            input = Some (mk_etuple ~borrow_proj:false []);
          }
      else None
    in
    let abs =
      {
        abs_id = ctx.fresh_abs_id ();
        kind = CopySymbolicValue;
        can_end = true;
        parents = AbsId.Set.empty;
        ended_subabs = AbsLevelSet.empty;
        regions = { owned = RegionId.Set.singleton rid };
        avalues;
(*
```ocaml
*)
        call_scopes = [];
(*
```
*)
        cont;
      }
    in
    fresh_absl := abs :: !fresh_absl
  in

  (* Keep the original occurrence in the frozen loan. The copy has fresh
     regions backed by shared reborrow and loan projectors; its symbolic type
     must use those same regions so later expansion resolves its own loans.

     The copied value may contain mutable borrows (e.g., the payload
     [Option<&'1 mut T>] of [Option::as_ref]): the loan projectors of their
     regions are frozen, because the copy is only reachable through the shared
     loan of [push_abs_for_shared_value] (the only user of
     [mk_value_with_fresh_sids_no_shared_loans]). The values they consume are
     the unchanged values of the copy, and the abstraction gives nothing back
     to the original (its borrow is a shared reborrow): see
     [SymbolicToPureExpressions.translate_end_abs_identity]. *)
  let copy_symbolic_regions (sv : symbolic_value) nsid =
    let ctx = ctx_with_metadata_bindings ctx !metadata_bindings in
    if symbolic_value_has_borrows (Some span) ctx sv then (
      [%cassert] span
        (not (symbolic_value_has_ended_regions ctx.type_ctx.type_infos ctx.ended_regions sv))
        "Reborrowing a symbolic payload containing ended borrows";
      let regions, proj_ty, updated_bindings =
        InterpBorrowsCore.refresh_live_regions_in_ty span ctx sv.sv_ty
      in
      let () = metadata_bindings := updated_bindings in
      let shared_ty =
        TRef (RVar (Free (ctx.fresh_region_id ())), proj_ty, RShared)
      in
      List.iter
        (fun rid ->
          let borrow : tavalue =
            {
              value =
                ABorrow
                  (AProjSharedBorrow
                     (PNone, [ AsbProjReborrows { sv_id = sv.sv_id; proj_ty } ]));
              ty = shared_ty;
            }
          in
          let loan : tavalue =
            {
              value =
                ASymbolic
                  ( PNone,
                    AProjLoans
                      {
                        proj = { sv_id = nsid; proj_ty };
                        consumed = [];
                        borrows = [];
                      } );
              ty = proj_ty;
            }
          in
          push_copy_abs rid [ borrow; loan ])
        (RegionId.Map.values regions);
      proj_ty)
    else sv.sv_ty
  in

  (* Likewise for a concrete mutable borrow [MB bid v] of the payload (e.g.,
     the field [native : &'n mut T] of the payload [C<'n>] of an input
     [&C<'n>]), only read through the shared loan either. Its copy is a fresh
     borrow [MB nbid v'] of the copied value, whose loan is owned by a fresh
     region backed by a shared reborrow of the original borrow: the shape of
     the input abstractions of [&'a C<'n>], and of the expansion of a copied
     symbolic mutable borrow, which reading through the copy leaves
     unchanged. *)
  let copy_mut_borrow (v : tvalue) (bid : BorrowId.id) (child : tvalue) :
      tvalue =
    let nbid = ctx.fresh_borrow_id () in
    let rid = ctx.fresh_region_id () in
    let ctx = ctx_with_metadata_bindings ctx !metadata_bindings in
    let child_rty, bindings = retained_value_rty span ctx child in
    let () = metadata_bindings := bindings in
    let loan_ty = mk_ref_ty (RVar (Free rid)) child_rty RMut in
    let borrow : tavalue =
      {
        value =
          ABorrow
            (AProjSharedBorrow
               (PNone, [ AsbBorrow (bid, ctx.fresh_shared_borrow_id ()) ]));
        ty = mk_ref_ty (RVar (Free (ctx.fresh_region_id ()))) loan_ty RShared;
      }
    in
    let loan : tavalue =
      {
        value = ALoan (AMutLoan (PNone, nbid, mk_aignored span ctx.type_ctx.type_infos child_rty None));
        ty = loan_ty;
      }
    in
    push_copy_abs rid [ borrow; loan ];
    { v with value = VBorrow (VMutBorrow (nbid, child)) }
  in

  (* Return the same value but where:
     - the shared loans have been removed
     - the symbolic values have been replaced with fresh symbolic values
     - shared borrows get distinct borrower identities while retaining their
       original loan ids; copied symbols use their freshly projected regions
     - mutable borrows are copied as fresh borrows (see [copy_mut_borrow])
  *)
  let mk_value_with_fresh_sids_no_shared_loans (v : tvalue) : tvalue =
    (* Concrete shared references get new borrower identities. Symbols and
       mutable borrows get the shared projection ownership introduced above,
       never a blind copy. *)
    let check =
      object
        inherit [_] iter_tvalue

        method! visit_VReservedMutBorrow _ _ _ =
          [%craise] span
            "Reborrowing a shared payload containing a reserved borrow"
      end
    in
    check#visit_tvalue () v;
    (* Remove the shared loans *)
    let v = value_remove_shared_loans v in
    let copy =
      object (self)
        inherit [_] map_tvalue as super
        method! visit_shared_borrow_id _ _ = ctx.fresh_shared_borrow_id ()

        method! visit_tvalue env v =
          match v.value with
          | VBorrow (VMutBorrow (bid, child)) ->
              copy_mut_borrow v bid (self#visit_tvalue env child)
          | _ -> super#visit_tvalue env v

        method! visit_symbolic_value _ sv =
          let sv_id = ctx.fresh_symbolic_value_id () in
          let sv_ty = copy_symbolic_regions sv sv_id in
          sid_subst := (sv_id, sv) :: !sid_subst;
          { sv_id; sv_ty }
      end
    in
    copy#visit_tvalue () v
  in

  (* Auxiliary function to create a new abstraction for a shared value.

     Example:
     ========
     When exploring:
     {[
       abs'0 { SL l s0 }
       x0 -> SB l
       x1 -> SB l
     ]}

     we find the shared borrow [SB l] in x0 and x1, which maps to a loan in a region
     abstraction. We introduce reborrows the following way:
     {[
       abs'0 { SL l s0 }
       abs'2 { SB l, SL {l1} s1 }
       abs'3 { SB l, SL {l2} s2 }
       x0 -> SB l1
       x1 -> SB l2
     ]}
  *)
  let push_abs_for_shared_value (sv : tvalue) (lid : BorrowId.id)
      (sid : SharedBorrowId.id) : BorrowId.id * SharedBorrowId.id =
    (* Create fresh borrows (for the reborrow) *)
    let nlid = ctx.fresh_borrow_id () in
    let nsid = ctx.fresh_shared_borrow_id () in

    (* We need a fresh region for the new abstraction *)
    let nrid = ctx.fresh_region_id () in

    (* Prepare the shared value. The abstractions which own the nested
       regions of the copied symbolic values are the children of the
       abstraction owning the outer reborrow, as for the region groups of a
       function call: an inner region outlives the outer one. *)
    let num_fresh = List.length !fresh_absl in
    let nsv = mk_value_with_fresh_sids_no_shared_loans sv in
    let num_inner = List.length !fresh_absl - num_fresh in

    (* Introduce the new abstraction for the shared values *)
    let ctx = ctx_with_metadata_bindings ctx !metadata_bindings in
    let rty, bindings = retained_value_rty span ctx nsv in
    let () = metadata_bindings := bindings in

    (* Create the shared loan child *)
    let child_rty = rty in
    let child_av = mk_aignored span ctx.type_ctx.type_infos child_rty None in

    (* Create the shared loan *)
    let loan_rty = TRef (RVar (Free nrid), rty, RShared) in
    let loan_value = ALoan (ASharedLoan (PNone, nlid, nsv, child_av)) in
    let loan_value = mk_tavalue span ctx.type_ctx.type_infos loan_rty loan_value in

    (* Create the shared borrow *)
    let borrow_rty = loan_rty in
    let borrow_value = ABorrow (ASharedBorrow (PNone, lid, sid)) in
    let borrow_value = mk_tavalue span ctx.type_ctx.type_infos borrow_rty borrow_value in

    (* Create the abstraction *)
    let avalues = [ borrow_value; loan_value ] in
    let kind : abs_kind =
      match loop_id with
      | Some loop_id -> Loop loop_id
      | None -> Identity
    in
    let can_end = true in
    let regions : abs_regions = { owned = RegionId.Set.singleton nrid } in
    let cont : abs_cont option =
      if with_abs_conts then
        Some
          {
            output = Some (mk_etuple ~borrow_proj:true []);
            input = Some (mk_etuple ~borrow_proj:false []);
          }
      else None
    in
    let fresh_abs =
      {
        abs_id = ctx.fresh_abs_id ();
        kind;
        can_end;
        parents = AbsId.Set.empty;
        ended_subabs = AbsLevelSet.empty;
        regions;
        avalues;
(*
```ocaml
*)
        call_scopes = [];
(*
```
*)
        cont;
      }
    in
    fresh_absl :=
      List.mapi
        (fun i (abs : abs) ->
          if i < num_inner then
            { abs with parents = AbsId.Set.add fresh_abs.abs_id abs.parents }
          else abs)
        !fresh_absl;
    fresh_absl := fresh_abs :: !fresh_absl;
    (nlid, nsid)
  in

  (* Compute the map from borrow id to shared value appearing in a region abstraction -
     we only visit the region abstractions *)
  let loan_to_shared_value = ref BorrowId.Map.empty in
  let visitor =
    object
      inherit [_] iter_abs as super

      method! visit_VSharedLoan abs bid sv =
        loan_to_shared_value :=
          BorrowId.Map.add bid (abs, sv) !loan_to_shared_value;
        super#visit_VSharedLoan abs bid sv

      method! visit_ASharedLoan abs pm bid sv child =
        loan_to_shared_value :=
          BorrowId.Map.add bid (abs, sv) !loan_to_shared_value;
        super#visit_ASharedLoan abs pm bid sv child
    end
  in
  List.iter (fun abs -> visitor#visit_abs abs abs) absl;

  (* Explore the shared borrows in the environment, and introduce
     fresh abstractions with reborrows.

     We simply explore the context and call {!push_abs_for_shared_value}
     when necessary.
  *)
  let visitor =
    object
      inherit [_] map_eval_ctx_regular_order as super
      method! visit_ty _ ty = ty
      method! visit_abs _ abs = (* Do not explore region abstractions *) abs

      method! visit_VSharedBorrow env bid sid =
        (* Check if the corresponding loan is in a region abstraction *)
        match BorrowId.Map.find_opt bid !loan_to_shared_value with
        | None ->
            (* Do nothing *)
            super#visit_VSharedBorrow env bid sid
        | Some (abs, sv) ->
            (* Check if the region abstraction is frozen *)
            if not abs.can_end then
              let bid, sid = push_abs_for_shared_value sv bid sid in
              VSharedBorrow (bid, sid)
            else super#visit_VSharedBorrow env bid sid
    end
  in
  let ctx = visitor#visit_eval_ctx () ctx in
  let ctx = ctx_with_metadata_bindings ctx !metadata_bindings in

  (* Add the abstractions *)
  let fresh_absl = List.map (fun abs -> EAbs abs) !fresh_absl in
  let ctx = { ctx with env = List.append fresh_absl ctx.env } in

  (* Synthesize *)
  let cf =
    match !sid_subst with
    | [] -> Fun.id
    | bindings ->
        (* Resolve only the needed values now: reconstruction must not retain
           the symbolic-value index of the whole operational context. *)
        let _, ids = compute_ctx_ids ctx in
        let bindings =
          List.map
            (fun (sid, value) ->
              ( SymbolicValueId.Map.find sid ids.sids_to_values,
                mk_tvalue_from_symbolic_value ctx.type_ctx.type_infos ctx.metadata_bindings value ))
            bindings
        in
        let ctx = SynthesizeSymbolic.capture_context ctx in
        fun e ->
          List.fold_left
            (fun e (sv, value) ->
              SymbolicAst.IntroSymbolic (ctx, None, sv, VaSingleValue value, e))
            e bindings
  in
  Invariants.check_invariants span ctx;
  [%ldebug "resulting ctx:\n" ^ eval_ctx_to_string ctx];
  (ctx, cf)

(** Auxiliary helper for [reborrow_ashared_loans_symbolic_borrows] *)
let reborrow_symbolic_borrows (span : Meta.span) (loop_id : LoopId.id option)
    ~(with_abs_conts : bool) : cm_fun =
 fun ctx0 ->
  let ctx = ctx0 in
  [%ldebug "ctx0:\n" ^ eval_ctx_to_string ctx];

  (* Compute the set of symbolic loans which appear in the frozen abstractions
     (we call them the "frozen loans"), so that we can filter the borrows that
     we reborrow. *)
  let absl =
    List.filter_map
      (function
        | EBinding _ | EFrame -> None
        | EAbs abs when not abs.can_end -> Some abs
        | EAbs _ -> None)
      ctx.env
  in

  (* *)
  let frozen_loans = ref SymbolicValueId.Set.empty in
  let visitor =
    object
      inherit [_] iter_abs as super
      method! visit_tevalue _ _ = ()

      method! visit_AProjLoans abs proj =
        frozen_loans := SymbolicValueId.Set.add proj.proj.sv_id !frozen_loans;
        super#visit_AProjLoans abs proj
    end
  in
  List.iter (fun abs -> visitor#visit_abs abs abs) absl;

  (* Introduce the reborrows *)
  (* The fresh abstractions we introduce for the reborrows *)
  let fresh_absl = ref [] in
  (* The substitution from old symbolic values to fresh symbolic values *)
  let sid_subst = ref [] in
  let metadata_bindings = ref ctx.metadata_bindings in

  (* Auxiliary function to create new abstractions for a symbolic borrow *)
  let push_abs_for_symbolic_borrow (sv : symbolic_value) : value =
    (* Create a fresh symbolic value *)
    let nsid = ctx.fresh_symbolic_value_id () in

    (* Refresh the regions appearing in the symbolic value *)
    let region_is_live rid = not (RegionId.Set.mem rid ctx.ended_regions) in
    let region_is_live = Some region_is_live in
    let fresh_regions, ty, updated_bindings =
      ty_refresh_regions_with_metadata (Some span) ctx.type_ctx.type_infos
        ~region_is_live ctx.fresh_region_id !metadata_bindings sv.sv_ty
    in
    let () = metadata_bindings := updated_bindings in
    let ctx = { ctx with metadata_bindings = updated_bindings }
    in

    (* Introduce the fresh regions *)
    let push_abs (nrid : RegionId.id) =
      let rty = ty in

      (* Create the symbolic borrow *)
      let borrow : tavalue =
        let proj =
          AProjBorrows
            { proj = { sv_id = sv.sv_id; proj_ty = rty }; loans = [] }
        in
        let value = ASymbolic (PNone, proj) in
        { value; ty = rty }
      in

      (* Create the symbolic loan *)
      let loan : tavalue =
        let value =
          AProjLoans
            {
              proj = { sv_id = nsid; proj_ty = rty };
              consumed = [];
              borrows = [];
            }
        in
        { value = ASymbolic (PNone, value); ty = rty }
      in

      (* Create the abstraction *)
      let avalues = [ borrow; loan ] in
      let kind : abs_kind =
        match loop_id with
        | Some loop_id -> Loop loop_id
        | None -> WithCont
      in
      let can_end = true in
      let regions : abs_regions = { owned = RegionId.Set.singleton nrid } in
      let cont : abs_cont option =
        if with_abs_conts then
          (* Create the symbolic borrow. We introduce borrows/loans only if the
             region projects *mutable* borrows/loans. *)
          if
            ty_has_mut_borrow_for_region_in_set ctx.type_ctx.type_infos
              (RegionId.Set.singleton nrid)
              rty
          then
            let borrow : tevalue =
              let value =
                EProjBorrows
                  { proj = { sv_id = sv.sv_id; proj_ty = rty }; loans = [] }
              in
              { value = ESymbolic (PNone, value); ty = rty }
            in

            (* Create the symbolic loan *)
            let value =
              EProjLoans
                {
                  proj = { sv_id = nsid; proj_ty = rty };
                  consumed = [];
                  borrows = [];
                }
            in
            let loan : tevalue =
              { value = ESymbolic (PNone, value); ty = rty }
            in
            Some { output = Some borrow; input = Some loan }
          else
            Some
              {
                output = Some (mk_etuple ~borrow_proj:true []);
                input = Some (mk_etuple ~borrow_proj:false []);
              }
        else None
      in
      let fresh_abs =
        {
          abs_id = ctx.fresh_abs_id ();
          kind;
          can_end;
          parents = AbsId.Set.empty;
          ended_subabs = AbsLevelSet.empty;
          regions;
          avalues;
(*
```ocaml
*)
          call_scopes = [];
(*
```
*)
          cont;
        }
      in
      fresh_absl := fresh_abs :: !fresh_absl
    in

    List.iter push_abs fresh_regions;

    let nsv : symbolic_value = { sv_id = nsid; sv_ty = ty } in
    sid_subst := (sv, nsv) :: !sid_subst;
    VSymbolic nsv
  in

  (* Explore the mutable borrows in the environment, and introduce
     fresh abstractions with reborrows.

     We simply explore the context and call {!push_abs_for_symbolic_mut_borrow}
     when necessary.
  *)
  let visitor =
    object
      inherit [_] map_eval_ctx_regular_order as super
      method! visit_ty _ ty = ty
      method! visit_abs _ abs = (* Do not explore region abstractions *) abs

      method! visit_VSymbolic env sv =
        (* Check if the corresponding borrows appear in a frozen region abstraction *)
        if SymbolicValueId.Set.mem sv.sv_id !frozen_loans then
          (* Introduce a reborrow *)
          push_abs_for_symbolic_borrow sv
        else super#visit_VSymbolic env sv
    end
  in
  let ctx = visitor#visit_eval_ctx () ctx in
  let ctx = { ctx with metadata_bindings = !metadata_bindings } in

  (* Existing shared observations follow the replacement payload, just as for
     copying a symbolic value. Transfer them before installing the consuming
     projectors; leaving them on the old identity would violate exclusivity. *)
  let ctx =
    List.fold_left
      (fun ctx ((sv, nsv) : symbolic_value * symbolic_value) ->
        let source_regions =
          RegionId.Set.diff (ty_regions ctx.type_ctx.type_infos sv.sv_ty) ctx.ended_regions
        in
        let update_shared ~owned:_ ~outlive:_ _ (proj : symbolic_proj) =
          [ AsbProjReborrows { proj with sv_id = nsv.sv_id } ]
        in
        let update_mut ~owned:_ ~outlive:_ _ _ =
          [%craise] span
            "Cannot reborrow a symbolic value with a live consuming borrow \
             projector"
        in
        let update_emut ~owned:_ ~outlive:_ _ _ =
          [%craise] span
            "Cannot reborrow a symbolic value with a live consuming expression \
             projector"
        in
        InterpBorrowsCore.update_intersecting_aproj_borrows span
          ~fail_if_unchanged:false ~include_owned:true ~include_outlive:true
          ~update_shared:(Some update_shared) ~update_mut ~update_emut
          source_regions
          { sv_id = sv.sv_id; proj_ty = sv.sv_ty }
          ctx)
      ctx !sid_subst
  in

  (* Add the abstractions *)
  let fresh_absl = List.map (fun abs -> EAbs abs) !fresh_absl in
  let ctx = { ctx with env = List.append fresh_absl ctx.env } in

  (* Synthesize *)
  let cf =
    match !sid_subst with
    | [] -> Fun.id
    | bindings ->
        let bindings =
          List.map
            (fun (sv, nsv) -> (mk_tvalue_from_symbolic_value ctx.type_ctx.type_infos ctx.metadata_bindings sv, nsv))
            bindings
        in
        let ctx = SynthesizeSymbolic.capture_context ctx in
        fun e ->
          List.fold_left
            (fun e (value, nsv) ->
              SymbolicAst.IntroSymbolic (ctx, None, nsv, VaSingleValue value, e))
            e bindings
  in
  Invariants.check_invariants span ctx;
  [%ldebug "resulting ctx:\n" ^ eval_ctx_to_string ctx];
  (ctx, cf)

let reborrow_ashared_loans_symbolic_borrows (span : Meta.span)
    (loop_id : LoopId.id option) ~(with_abs_conts : bool) : cm_fun =
 fun ctx0 ->
  let ctx = ctx0 in
  [%ldebug "ctx0:\n" ^ eval_ctx_to_string ctx];
  let ctx, cc = reborrow_ashared_loans span loop_id ~with_abs_conts ctx in

  comp cc (reborrow_symbolic_borrows span loop_id ~with_abs_conts ctx)

let reborrow_ashared_loans_symbolic_borrows_no_synth (span : Meta.span)
    (loop_id : LoopId.id) ~(with_abs_conts : bool) (ctx : eval_ctx) : eval_ctx =
  fst
    (reborrow_ashared_loans_symbolic_borrows span (Some loop_id) ~with_abs_conts
       ctx)

(* TODO: this could be drastically simplified. *)
let compute_ctx_fresh_ordered_symbolic_values (span : Meta.span)
    ~(only_modified_svalues : bool) (ctx : eval_ctx) (fp_ctx : eval_ctx) :
    symbolic_value list =
  let old_ids, _ = compute_ctx_ids ctx in
  let fp_ids, fp_ids_maps = compute_ctx_ids fp_ctx in
  let fresh_sids = SymbolicValueId.Set.diff fp_ids.sids old_ids.sids in

  (* Compute the set of symbolic values which appear inside *frozen* abstractions.
     There are two kinds of values:
     - shared symbolic values (appearing in shared loans): because we introduce
       fresh abstractions and reborrows with {!prepare_ashared_loans}, those
       values are never accessed directly inside the loop iterations: we can
       ignore them (and should, because otherwise it leads to a very ugly
       translation with duplicated, unused values)
     - projections over symbolic values.
       TODO: actually it may happen that a projector inside a fixed abstraction
       gets expanded. We need to update the way we compute joins and check
       whether two contexts are equivalent to make it more general.
  *)
  let sids_in_fixed_abs =
    let fixed_absl =
      List.filter
        (fun (ee : env_elem) ->
          match ee with
          | EBinding _ | EFrame -> false
          | EAbs abs -> not abs.can_end)
        ctx.env
    in

    (* Rem.: as we greedily expand the symbolic values containing borrows, and
       in particular the (mutable/shared) borrows, we could simply list the
       symbolic values appearing in the abstractions: those are necessarily
       shared values. We prefer to be more general, in prevision of later
       changes.
    *)
    let sids = ref SymbolicValueId.Set.empty in
    let visitor =
      object (self)
        inherit [_] iter_env

        method! visit_ASharedLoan register _ _ sv child_av =
          self#visit_tvalue true sv;
          self#visit_tavalue register child_av

        method! visit_AProjLoans register proj =
          let { proj = { sv_id; proj_ty }; consumed; borrows } : aproj_loans =
            proj
          in
          self#visit_symbolic_value_id true sv_id;
          self#visit_ty register proj_ty;
          (* The projectors introduced because an ancestor region ended follow
             the same rules as the top-level ones (the consumed symbolic values
             are meta-values). *)
          List.iter (fun (_, p) -> self#visit_aproj register p) consumed;
          List.iter (fun (_, p) -> self#visit_aproj register p) borrows

        method! visit_symbolic_value_id register sid =
          if register then sids := SymbolicValueId.Set.add sid !sids
      end
    in
    visitor#visit_env false fixed_absl;
    !sids
  in

  (* Remove the shared symbolic values present in the fixed abstractions -
     see comments for [shared_sids_in_fixed_abs]. *)
  let sids_to_values = fp_ids_maps.sids_to_values in

  (* Also remove the symbolic values which appear inside of projectors in
     fixed abstractions - those are "fixed" and not modified between iterations
     of the loop *)
  [%ltrace
    "- sids_in_fixed_abs:"
    ^ SymbolicValueId.Set.show sids_in_fixed_abs
    ^ "\n- all_sids_to_values: "
    ^ SymbolicValueId.Map.show (symbolic_value_to_string ctx) sids_to_values];

  let sids_to_values =
    SymbolicValueId.Map.filter
      (fun sid _ -> not (SymbolicValueId.Set.mem sid sids_in_fixed_abs))
      sids_to_values
  in

  (* Remove the symbolic values which are not modified, if the option
     [only_modified_input_svalues] is [true] *)
  let sids_to_values =
    if only_modified_svalues then
      SymbolicValueId.Map.filter
        (fun sid _ -> SymbolicValueId.Set.mem sid fresh_sids)
        sids_to_values
    else sids_to_values
  in

  (* List the input symbolic values in proper order.

     We explore the environment, and order the symbolic values in the order
     in which they are found - this way, the symbolic values found in a
     variable [x] which appears before [y] are listed first, for instance.
  *)
  let input_svalues =
    let found_sids = ref SymbolicValueId.Set.empty in
    let ordered_sids = ref [] in

    let visitor =
      object (self)
        inherit [_] iter_env

        (** We lookup the shared values *)
        method! visit_VSharedBorrow env bid _ =
          let open InterpBorrowsCore in
          let v =
            match snd (ctx_lookup_loan span ek_all bid fp_ctx) with
            | Concrete (VSharedLoan (_, v)) -> v
            | Abstract (ASharedLoan (pm, _, v, _)) ->
                [%sanity_check] span (pm = PNone);
                v
            | _ -> [%craise] span "Unreachable"
          in
          self#visit_tvalue env v

        method! visit_symbolic_value_id _ id =
          if not (SymbolicValueId.Set.mem id !found_sids) then (
            found_sids := SymbolicValueId.Set.add id !found_sids;
            ordered_sids := id :: !ordered_sids)
      end
    in

    List.iter (visitor#visit_env_elem ()) (List.rev fp_ctx.env);

    List.filter_map
      (fun id -> SymbolicValueId.Map.find_opt id sids_to_values)
      (List.rev !ordered_sids)
  in

  [%ltrace
    "- src context:\n"
    ^ eval_ctx_to_string ~span:(Some span) ~filter:false ctx
    ^ "\n- fixed point:\n"
    ^ eval_ctx_to_string ~span:(Some span) ~filter:false fp_ctx
    ^ "\n- fresh_sids: "
    ^ SymbolicValueId.Set.show fresh_sids
    ^ "\n- input_svalues: "
    ^ Print.list_to_string (symbolic_value_to_string ctx) input_svalues
    ^ "\n"];

  input_svalues

let refresh_non_fixed_abs_ids (_span : Meta.span) (fixed_aids : AbsId.Set.t)
    (ctx : eval_ctx) : eval_ctx * abs_id AbsId.Map.t =
  (* Note that abstraction ids appear both inside of region abstractions
     but also inside of evalues (some evalues refer to region abstractions).
     We have to make sure that we keep things consistent: whenever we refresh
     an id, we remember it. *)
  let fresh_map = ref AbsId.Map.empty in

  let visitor =
    object
      inherit [_] map_eval_ctx

      method! visit_abs_id _ id =
        if AbsId.Set.mem id fixed_aids then id
        else
          match AbsId.Map.find_opt id !fresh_map with
          | Some id -> id
          | None ->
              let nid = ctx.fresh_abs_id () in
              fresh_map := AbsId.Map.add id nid !fresh_map;
              nid
    end
  in
  let ctx = visitor#visit_eval_ctx () ctx in
  (ctx, !fresh_map)

(** An anonymous value which is the same in two contexts under two distinct
    dummy ids is one value: every branch of a [match] can move the same
    borrow to a fresh anonymous value (e.g., the mutable reborrow given to a
    call before the [match], at its [StorageDead] in every arm). A value which
    holds borrows or loans denotes them by their ids, which are unique, so two
    equal such values are the same value. Give the dummy of [ctx1] the id of
    the equal dummy of [ctx0], so that the join keeps the value as it is.
    This preserves one operational owner and avoids duplicate transfers into
    region abstractions. *)
let unify_equal_dummy_ids (span : Meta.span) (ctx0 : eval_ctx)
    (ctx1 : eval_ctx) : eval_ctx =
  let dummies (ctx : eval_ctx) =
    List.filter_map
      (function
        | EBinding (BDummy id, v) -> Some (id, v)
        | EBinding (BVar _, _) | EAbs _ | EFrame -> None)
      ctx.env
  in
  let dummies0 = dummies ctx0 in
  let dummies1 = dummies ctx1 in
  let ids (dummies : (DummyVarId.id * tvalue) list) =
    DummyVarId.Set.of_list (List.map fst dummies)
  in
  let ids0 = ids dummies0 in
  let ids1 = ids dummies1 in
  let only0 =
    ref
      (List.filter
         (fun (id, (v : tvalue)) ->
           (not (DummyVarId.Set.mem id ids1))
           && value_has_loans_or_borrows (Some span) ctx0 v.value)
         dummies0)
  in
  let rename =
    List.fold_left
      (fun rename (id1, v1) ->
        if DummyVarId.Set.mem id1 ids0 then rename
        else
          match List.find_opt (fun (_, v0) -> v0 = v1) !only0 with
          | None -> rename
          | Some (id0, _) ->
              only0 := List.filter (fun (id, _) -> id <> id0) !only0;
              DummyVarId.Map.add id1 id0 rename)
      DummyVarId.Map.empty dummies1
  in
  if DummyVarId.Map.is_empty rename then ctx1
  else
    let env =
      List.map
        (function
          | EBinding (BDummy id, v) when DummyVarId.Map.mem id rename ->
              EBinding (BDummy (DummyVarId.Map.find id rename), v)
          | e -> e)
        ctx1.env
    in
    { ctx1 with env }

let join_ctxs (span : Meta.span) ?(loop : bool = false)
    ?diagnostic_source_ids
    (fresh_abs_kind : abs_kind) ~(recoverable : bool) ~(with_abs_conts : bool)
    (ctx0 : eval_ctx) (ctx1 : eval_ctx) : join_info_or_update =
  let loop_level_outputs = loop_level_outputs ~loop fresh_abs_kind in
  (* Debug *)
  [%ltrace
    "- ctx0:\n"
    ^ eval_ctx_to_string ~span:(Some span) ~filter:true ctx0
    ^ "\n\n- ctx1:\n"
    ^ eval_ctx_to_string ~span:(Some span) ~filter:true ctx1
    ^ "\n"];
  let ctx1 = unify_equal_dummy_ids span ctx0 ctx1 in

  (* Keep the lifetimes of the two branches distinct where their identity is
     not shared: this is alpha-renaming of one branch, including its
     continuations, not a change to either branch's ended regions. *)
  let refresh_regions conflicts (ctx : eval_ctx) =
    if RegionId.Set.is_empty conflicts then ctx
    else
      let subst = ref RegionId.Map.empty in
      let rsubst rid =
        if not (RegionId.Set.mem rid conflicts) then rid
        else
          match RegionId.Map.find_opt rid !subst with
          | Some rid -> rid
          | None ->
              let fresh = ctx.fresh_region_id () in
              subst := RegionId.Map.add rid fresh !subst;
              fresh
      in
      let metadata_policy =
        (* ```ocaml *)
        ((fun id index original mapped ->
           let info = TypeDeclId.Map.find id ctx.type_ctx.type_infos in
           if RegionId.Set.mem index info.metadata_regions
              && not (RegionId.Set.mem index info.stored_regions)
           then original else mapped),
        (* ``` *)
         (fun id index ->
           let info = TypeDeclId.Map.find id ctx.type_ctx.type_infos in
           TypeVarId.Set.mem index info.metadata_type_params
           && not (TypeVarId.Set.mem index info.stored_type_params)))
      in
      let env =
        Substitute.env_subst_rids
          (InterpBorrowsCore.transport_projection_regions span ctx.type_ctx.type_infos
             ~metadata_bindings:ctx.metadata_bindings)
          metadata_policy rsubst ctx.env
      in
      let bindings =
        RegionId.Map.fold
          (fun original fresh bindings ->
            let binding =
              match RegionId.Map.find_opt original ctx.metadata_bindings with
              | Some (MetadataSource _) ->
                  MetadataSource
                    (metadata_region ctx.metadata_bindings (RVar (Free original)))
              | None | Some MetadataFresh -> MetadataFresh
            in
            RegionId.Map.add fresh binding bindings)
          !subst ctx.metadata_bindings
      in
      ctx_with_metadata_bindings { ctx with env } bindings
  in
  (* A region can still be live in one branch after it ended in the other.
     Keep these lifetimes distinct before taking the union of ended regions:
     otherwise collapsing abstractions may choose the ended id as the
     representative of a fresh, live loan. The live branch is renamed. *)
  let refresh_conflicting_regions ended_regions (ctx : eval_ctx) =
    refresh_regions (RegionId.Set.diff ended_regions ctx.ended_regions) ctx
  in
  let ctx0 = refresh_conflicting_regions ctx1.ended_regions ctx0 in
  let ctx1 = refresh_conflicting_regions ctx0.ended_regions ctx1 in
  (* Distinct abstractions of the two branches can own the same region: a
     join in one branch merges the abstraction owning it into a join
     abstraction which keeps its region (e.g., the abstraction of [Vec::new]
     with the loans of a vector which one of the joined branches moved into
     the result), while the other branch still has the original abstraction.
     Both survive this join as distinct (marked) abstractions. If the collapse
     then ends one of them (e.g., the other branch drops the vector), the
     region is ended while the other one still owns it, and every value whose
     type mentions it reads as partially bottom. Such lifetimes are unrelated
     unless a symbolic value present in both branches mentions them in both
     branches (its projections are then reconciled by the join): the right
     branch is renamed for the unrelated ones only. A region which a common
     symbolic value mentions in one branch only is not reconciled through it:
     the value has distinct types in the two branches with or without the
     renaming (e.g., the loan of a reborrowed [&[(_, &'r T)]] whose inner
     region a join in the loop body renamed to the region of the abstraction
     of an earlier call it merged, which still owns that region at the loop
     entry), and the join introduces a fresh value for it either way (see
     [match_symbolic_values]). *)
  let ctx1 =
    let owned_by_own_abs (ctx : eval_ctx) (other : eval_ctx) =
      let other_ids = env_get_abs_ids other.env in
      List.fold_left
        (fun owned (e : env_elem) ->
          match e with
          | EAbs abs when not (AbsId.Set.mem abs.abs_id other_ids) ->
              RegionId.Set.union abs.regions.owned owned
          | _ -> owned)
        RegionId.Set.empty ctx.env
    in
    let conflicts =
      RegionId.Set.inter
        (owned_by_own_abs ctx0 ctx1)
        (owned_by_own_abs ctx1 ctx0)
    in
    if RegionId.Set.is_empty conflicts then ctx1
    else
      (* The regions mentioned by each symbolic value, in its type or in the
         types of its projections *)
      let symbolic_regions (ctx : eval_ctx) =
        let regions = ref SymbolicValueId.Map.empty in
        let add id ty =
          regions :=
            SymbolicValueId.Map.update id
              (fun rids ->
                Some
                  (RegionId.Set.union (ty_regions ctx.type_ctx.type_infos ty)
                     (Option.value rids ~default:RegionId.Set.empty)))
              !regions
        in
        let visited = EvalueTbl.create 16 in
        let visitor =
          object
            inherit [_] iter_env as super

            method! visit_tevalue env value =
              if not (EvalueTbl.mem visited value) then (
                EvalueTbl.add visited value ();
                super#visit_tevalue env value)

            method! visit_symbolic_value _ (sv : symbolic_value) =
              add sv.sv_id sv.sv_ty

            method! visit_symbolic_proj _ (proj : symbolic_proj) =
              add proj.sv_id proj.proj_ty

            method! visit_esymbolic_proj _ (proj : esymbolic_proj) =
              add proj.sv_id proj.proj_ty
          end
        in
        visitor#visit_env () ctx.env;
        !regions
      in
      let regions0 = symbolic_regions ctx0 in
      let regions1 = symbolic_regions ctx1 in
      let shared =
        SymbolicValueId.Map.fold
          (fun id rids0 shared ->
            match SymbolicValueId.Map.find_opt id regions1 with
            | Some rids1 ->
                RegionId.Set.union shared (RegionId.Set.inter rids0 rids1)
            | None -> shared)
          regions0 RegionId.Set.empty
      in
      refresh_regions (RegionId.Set.diff conflicts shared) ctx1
  in

  let nabs = ref [] in

  let symbolic_to_value = ref SymbolicValueId.Map.empty in
  (* Alpha-align a mutable loan and its borrower only when both concrete
     endpoints survive at corresponding binding paths. Joining them separately
     would manufacture an identity transfer abstraction between the endpoints.
     Rename the entire environment, including ignored/pending parent
     dependencies and continuations, rather than just replacing the endpoints.

     Likewise for a shared loan when it and every one of its borrows sit at
     corresponding binding paths in both branches, and nothing else borrows it
     (e.g., [x -> SL l0 v, y -> SB l0] and [x -> SL l1 v, y -> SB l1], two
     evaluations of [let y = &x]): the two loans are the same loan up to
     naming. Joining them separately would wrap them in a reborrow abstraction
     which neither branch has (e.g., a break context of a loop would no longer
     match the break target computed from the same shape). *)
  let subst0, subst1 =
    let locals1, dummies1 =
      List.fold_left
        (fun (locals, dummies) -> function
          | EBinding (BVar var, value) ->
              (Expressions.LocalId.Map.add var.index value locals, dummies)
          | EBinding (BDummy id, value) ->
              (locals, DummyVarId.Map.add id value dummies)
          | EAbs _ | EFrame -> (locals, dummies))
        (Expressions.LocalId.Map.empty, DummyVarId.Map.empty)
        ctx1.env
    in
    let loans = ref BorrowId.Map.empty in
    let borrows = ref BorrowId.Map.empty in
    let shared_loans = ref BorrowId.Map.empty in
    let shared_borrows = ref [] in
    let rec collect (v0 : tvalue) (v1 : tvalue) =
      if v0.ty = v1.ty then
        match (v0.value, v1.value) with
        | VAdt adt0, VAdt adt1 when adt0.variant_id = adt1.variant_id ->
            List.iter2 collect adt0.fields adt1.fields
        | VLoan (VMutLoan id0), VLoan (VMutLoan id1) ->
            loans := BorrowId.Map.add id0 id1 !loans
        | VBorrow (VMutBorrow (id0, child0)), VBorrow (VMutBorrow (id1, child1))
          ->
            borrows := BorrowId.Map.add id0 id1 !borrows;
            collect child0 child1
        | VLoan (VSharedLoan (id0, child0)), VLoan (VSharedLoan (id1, child1))
          ->
            shared_loans := BorrowId.Map.add id0 id1 !shared_loans;
            collect child0 child1
        | VBorrow (VSharedBorrow (id0, _)), VBorrow (VSharedBorrow (id1, _)) ->
            shared_borrows := (id0, id1) :: !shared_borrows
        | _ -> ()
    in
    List.iter
      (function
        | EBinding (binder, value0) ->
            let value1 =
              match binder with
              | BVar var -> Expressions.LocalId.Map.find_opt var.index locals1
              | BDummy id -> DummyVarId.Map.find_opt id dummies1
            in
            Option.iter (collect value0) value1
        | EAbs _ | EFrame -> ())
      ctx0.env;
    let mut_pairs =
      BorrowId.Map.filter
        (fun id0 id1 ->
          id0 <> id1 && BorrowId.Map.find_opt id0 !borrows = Some id1)
        !loans
    in
    let shared_pairs =
      if BorrowId.Map.is_empty !shared_loans then BorrowId.Map.empty
      else
        (* The number of occurrences of each borrow id, anywhere in a context
           (bindings, abstractions, continuations) *)
        let occurrences (ctx : eval_ctx) =
          let count = ref BorrowId.Map.empty in
          let visitor =
            object (self)
              inherit [_] iter_env

              method! visit_borrow_id () id =
                count :=
                  BorrowId.Map.update id
                    (function None -> Some 1 | Some n -> Some (n + 1))
                    !count

              method! visit_mvalue () value = self#visit_tvalue () value
            end
          in
          visitor#visit_env () ctx.env;
          !count
        in
        let occ0 = occurrences ctx0 in
        let occ1 = occurrences ctx1 in
        let count occ id =
          Option.value ~default:0 (BorrowId.Map.find_opt id occ)
        in
        BorrowId.Map.filter
          (fun id0 id1 ->
            let paired =
              List.filter
                (fun (b0, b1) -> b0 = id0 || b1 = id1)
                !shared_borrows
            in
            id0 <> id1 && paired <> []
            && List.for_all (fun (b0, b1) -> b0 = id0 && b1 = id1) paired
            && count occ0 id0 = List.length paired
            && count occ1 id1 = List.length paired)
          !shared_loans
    in
    if BorrowId.Map.is_empty mut_pairs && BorrowId.Map.is_empty shared_pairs
    then (BorrowId.Map.empty, BorrowId.Map.empty)
    else
      let frozen_ids = ref BorrowId.Set.empty in
      let frozen_visitor =
        object (self)
          inherit [_] iter_env

          method! visit_borrow_id () id =
            frozen_ids := BorrowId.Set.add id !frozen_ids

          method! visit_loan_id () id =
            frozen_ids := BorrowId.Set.add id !frozen_ids

          method! visit_mvalue () value = self#visit_tvalue () value
        end
      in
      let collect_frozen =
        List.iter (function
          | EAbs abs when not abs.can_end -> frozen_visitor#visit_abs () abs
          | _ -> ())
      in
      collect_frozen ctx0.env;
      collect_frozen ctx1.env;
      let add_pairs pairs substs =
        BorrowId.Map.fold
          (fun id0 id1 (subst0, subst1) ->
            if
              (not (BorrowId.Set.mem id0 !frozen_ids))
              && not (BorrowId.Set.mem id1 !frozen_ids)
            then
              let joined = ctx0.fresh_borrow_id () in
              ( BorrowId.Map.add id0 joined subst0,
                BorrowId.Map.add id1 joined subst1 )
            else (subst0, subst1))
          pairs substs
      in
      add_pairs shared_pairs
        (add_pairs mut_pairs (BorrowId.Map.empty, BorrowId.Map.empty))
  in
  let align subst ctx =
    if BorrowId.Map.is_empty subst then ctx
    else
      let bsubst id =
        match BorrowId.Map.find_opt id subst with
        | Some id -> id
        | None -> id
      in
      {
        ctx with
        env =
          Substitute.env_subst_ids
            { Substitute.empty_id_subst with bsubst }
            ctx.env;
      }
  in
  let ctx0 = align subst0 ctx0 in
  let ctx1 = align subst1 ctx1 in
  let metadata_bindings =
    ref (merge_metadata_bindings (Some span) ctx0.metadata_bindings ctx1.metadata_bindings)
  in
  let module S : MatchJoinState = struct
    let fresh_abs_kind = fresh_abs_kind
    let loop_level_outputs = loop_level_outputs
    let span = span
    let nabs = nabs
    let metadata_bindings = metadata_bindings
    let with_abs_conts = with_abs_conts
    let symbolic_to_value = symbolic_to_value
    let recover = recoverable

    let lookup_shared_value ~is_left ctx bid =
      match InterpBorrowsCore.lookup_shared_value_opt span ctx.env bid with
      | Some value -> value
      | None ->
          (* Reconciliation may move a nested lender out of a retained
             payload and into [nabs]. Its input borrowers still refer to the
             original branch value. Existing lenders must use their current
             payloads, so already-reconciled projections are not consumed
             again. *)
          let source = if is_left then ctx0 else ctx1 in
          InterpBorrowsCore.ctx_lookup_shared_value span source bid
  end in
  let module JM = MakeJoinMatcher (S) in
  let module M = MakeMatcher (JM) in
  (* An immutable shared payload may have been expanded in just one branch.
     An existing data-only symbol already abstracts that expansion. Reusing it
     keeps fixed owners stable; the branch instantiations are still recorded
     for replay, exactly as for freshly joined symbols. *)
  (* A shared loan identity supplies the source relation between these
     payloads. A type or a common nested referent alone cannot prove the
     identity of a symbolic expansion. Values with borrows need the
     ordinary join and its fresh projectors. Do not reuse their symbols
     without evidence for each projected region and its live ownership. *)
  let reuse_payload_symbol ctx0 ctx1 (sv : symbolic_value) right =
    if
      ty_has_borrows (Some span) ctx0.type_ctx.type_infos sv.sv_ty
      || tvalue_has_bottom ctx1 right
      || tvalue_has_loans right
    then None
    else
      let left = mk_tvalue_from_symbolic_value ctx0.type_ctx.type_infos ctx0.metadata_bindings sv in
      let values = (left, right) in
      match SymbolicValueId.Map.find_opt sv.sv_id !symbolic_to_value with
      | Some previous -> if previous = values then Some left else None
      | None ->
          symbolic_to_value :=
            SymbolicValueId.Map.add sv.sv_id values !symbolic_to_value;
          Some left
  in
  let module PayloadJM = struct
    include JM

    let match_symbolic_values match_rec ctx0 ctx1 sv0 sv1 =
      match
        reuse_payload_symbol ctx0 ctx1 sv0
          (mk_tvalue_from_symbolic_value ctx1.type_ctx.type_infos ctx1.metadata_bindings sv1)
      with
      | Some value -> value
      | None -> JM.match_symbolic_values match_rec ctx0 ctx1 sv0 sv1

    let match_symbolic_with_other match_rec ctx0 ctx1 ~symbolic_is_left sv value
        =
      let reused =
        if symbolic_is_left then reuse_payload_symbol ctx0 ctx1 sv value
        else None
      in
      match reused with
      | Some value -> value
      | None ->
          JM.match_symbolic_with_other match_rec ctx0 ctx1 ~symbolic_is_left sv
            value
  end in
  let module PayloadM = MakeMatcher (PayloadJM) in
  (* A shared reborrow of a place inside the payload retained by a frozen
     abstraction (e.g., the field [f] of [* *x] for an input [x : &&T]) puts a
     concrete shared loan in the payload, which stays once its borrows ended:
     frozen abstractions are never simplified. A branch where the place was not
     borrowed has no such loan, and joining the payloads would introduce a
     fresh loan, so that the frozen abstraction of the joined context differs
     from the one of the source context of a match (e.g., after
     [a || matches!(&binding.value.kind, ..)] in the body of a closure called
     on [&&T]). Such a loan has no counterpart: it is ended in a payload when
     no borrow of its context refers to it and the payloads of the other
     context do not hold it. A loan which both contexts hold is kept, like the
     rest of the fixed abstraction (e.g., at a loop entry where it is still
     borrowed, and in the continue context where it is not anymore). *)
  let end_unborrowed_frozen_payload_loans env0 env1 =
    let payload_loans env =
      let ids = ref BorrowId.Set.empty in
      let visitor =
        object
          inherit [_] iter_abs as super
          method! visit_ty _ _ = ()
          method! visit_abs_cont _ _ = ()

          method! visit_VSharedLoan env lid sv =
            ids := BorrowId.Set.add lid !ids;
            super#visit_VSharedLoan env lid sv
        end
      in
      List.iter
        (function
          | EAbs abs when not abs.can_end -> visitor#visit_abs () abs
          | _ -> ())
        env;
      !ids
    in
    let end_loans (ctx : eval_ctx) env other =
      let borrowed = InterpBorrowsCore.shared_reserved_loan_ids ctx in
      let kept = BorrowId.Set.union borrowed (payload_loans other) in
      let visitor =
        object
          inherit [_] map_abs as super
          method! visit_ty _ ty = ty
          method! visit_abs_cont _ cont = cont

          method! visit_VLoan () lc =
            match lc with
            | VSharedLoan (lid, sv) when not (BorrowId.Set.mem lid kept) ->
                super#visit_value () sv.value
            | _ -> super#visit_VLoan () lc
        end
      in
      List.map
        (function
          | EAbs abs when not abs.can_end -> EAbs (visitor#visit_abs () abs)
          | e -> e)
        env
    in
    ( end_loans { ctx0 with env = env0 } env0 env1,
      end_loans { ctx1 with env = env1 } env1 env0 )
  in
  (* Retained payloads belong to the join, not merely to marker collapse.
     Match them with the same state as ordinary values, so every new symbolic
     value and ownership abstraction is available when projecting and replaying
     the join for a particular branch. Abstract children and continuations
     remain branch-specific and are reconciled by the ordinary collapse. *)
  let join_retained_payloads env0 env1 =
    let env0, env1 = end_unborrowed_frozen_payload_loans env0 env1 in
    let collect env =
      let payloads = ref [] in
      let visitor =
        object (self)
          inherit [_] iter_tavalue as super

          method! visit_tavalue () av =
            match av.value with
            | ALoan (ASharedLoan (_, bid, sv, child)) ->
                payloads := (Some bid, av.ty, sv) :: !payloads;
                self#visit_tavalue () child
            | ALoan (AEndedSharedLoan (_, sv, child)) ->
                payloads := (None, av.ty, sv) :: !payloads;
                self#visit_tavalue () child
            | _ -> super#visit_tavalue () av
        end
      in
      List.iter
        (function
          | EAbs abs -> List.iter (visitor#visit_tavalue ()) abs.avalues
          | _ -> ())
        env;
      List.rev !payloads
    in
    let payloads0 = collect env0 in
    let payloads1 = collect env1 in
    let values payloads =
      Array.of_list (List.map (fun (_, _, sv) -> sv) payloads)
    in
    let values0 = values payloads0 in
    let values1 = values payloads1 in
    let remaining = ref (List.mapi (fun i payload -> (i, payload)) payloads1) in
    let changed = ref false in
    List.iteri
      (fun i (id0, ty0, sv0) ->
        let rec choose prefix = function
          | [] -> ()
          | ((j, (id1, ty1, sv1)) as candidate) :: rest ->
              let corresponding =
                match (id0, id1) with
                | Some bid0, Some bid1 -> bid0 = bid1
                | None, None ->
                    ty_erase_regions_with_metadata ctx0.type_ctx.type_infos ctx0.metadata_bindings ty0 = ty_erase_regions_with_metadata ctx1.type_ctx.type_infos ctx1.metadata_bindings ty1
                    && shared_payloads_correspond sv0 sv1
                | _ -> false
              in
              if corresponding then (
                remaining := List.rev_append prefix rest;
                if sv0 <> sv1 then (
                  let sv = PayloadM.match_tvalues ctx0 ctx1 sv0 sv1 in
                  values0.(i) <- sv;
                  values1.(j) <- sv;
                  changed := true))
              else choose (candidate :: prefix) rest
        in
        choose [] !remaining)
      payloads0;
    if not !changed then (env0, env1)
    else
      let update values env =
        let index = ref 0 in
        let next () =
          let sv = values.(!index) in
          incr index;
          sv
        in
        let visitor =
          object (self)
            inherit [_] map_tavalue as super

            method! visit_tavalue () av =
              match av.value with
              | ALoan (ASharedLoan (pm, bid, _, child)) ->
                  let sv = next () in
                  let child = self#visit_tavalue () child in
                  { av with value = ALoan (ASharedLoan (pm, bid, sv, child)) }
              | ALoan (AEndedSharedLoan (pm, _, child)) ->
                  let sv = next () in
                  let child = self#visit_tavalue () child in
                  { av with value = ALoan (AEndedSharedLoan (pm, sv, child)) }
              | _ -> super#visit_tavalue () av
          end
        in
        List.map
          (function
            | EAbs abs ->
                EAbs
                  {
                    abs with
                    avalues = List.map (visitor#visit_tavalue ()) abs.avalues;
                  }
            | e -> e)
          env
      in
      (update values0 env0, update values1 env1)
  in

  try
    (* Reconcile retained payloads before deciding which abstractions are
       common. Otherwise two branches of the same frozen input owner are
       needlessly renamed and marked as distinct owners. *)
    let env0, env1 = join_retained_payloads ctx0.env ctx1.env in
    let ctx0 = { ctx0 with env = env0 } in
    let ctx1 = { ctx1 with env = env1 } in
    (* Split the environments in two:
     - we preserve the dummy variables and abstractions which appear in both
       environments: we will match those pairwise. However, for the abstractions:
       we only preserve those which are the same in both abstractions.
     - for the others:
       - we mark the region abstractions with left/right markers
       - we lift the dummy values into region abstractions and mark them as well
  *)
    let dummy_ids0 = ctx_get_dummy_var_ids ctx0 in
    let dummy_ids1 = ctx_get_dummy_var_ids ctx1 in
    let dummy_ids = DummyVarId.Set.inter dummy_ids0 dummy_ids1 in
    let abs_ids = compute_fixed_abs_ids ctx0 ctx1 in

    (* Refresh the non fixed abstraction ids.

     We need to refresh the non-fixed abstraction ids (the ones which do appear,
     while being equal, in both environments) in one of the two contexts,
     because otherwise the join might have twice an abstraction with the same id,
     which is a problem.

     TODO: make the join more general.
  *)
    let ctx0, refreshed_aids = refresh_non_fixed_abs_ids span abs_ids ctx0 in
    (match diagnostic_source_ids with None -> () | Some ids -> ids := refreshed_aids);
    [%ltrace
      "After refreshing the non-fixed abstraction ids of ctx0:\n"
      ^ eval_ctx_to_string ~span:(Some span) ~filter:true ctx0];

    let partition (env : env) : env * env =
      List.partition
        (fun (e : env_elem) ->
          match e with
          | EBinding (BVar _, _) ->
              (* All the locals should appear on both sides *) true
          | EBinding (BDummy id, _) -> DummyVarId.Set.mem id dummy_ids
          | EAbs abs -> AbsId.Set.mem abs.abs_id abs_ids
          | EFrame -> true)
        env
    in
    let env0, env0_suffix = partition (List.rev ctx0.env) in
    let env1, env1_suffix = partition (List.rev ctx1.env) in
    [%ldebug
      "\n\n- env0:\n"
      ^ eval_ctx_to_string ~span:(Some span) ~filter:false
          { ctx0 with env = List.rev env0 }
      ^ "\n\n- env0_suffix:\n"
      ^ eval_ctx_to_string ~span:(Some span) ~filter:false
          { ctx0 with env = List.rev env0_suffix }
      ^ "\n\n- env1:\n"
      ^ eval_ctx_to_string ~span:(Some span) ~filter:false
          { ctx1 with env = List.rev env1 }
      ^ "\n\n- env1_suffix:\n"
      ^ eval_ctx_to_string ~span:(Some span) ~filter:false
          { ctx1 with env = List.rev env1_suffix }
      ^ "\n"];
    let pop_var = env_pop_var (fun _ -> [%internal_error] span) in
    let pop_dummy = env_pop_dummy (fun _ -> [%internal_error] span) in
    let pop_abs = env_pop_abs (fun _ -> [%internal_error] span) in

    (* Rem.: this function raises exceptions.

     We match on the first environment, then pop the corresponding binding
     from the second environment.
  *)
    let rec join_prefixes (env0 : env) (env1 : env) : env =
      match env0 with
      | (EBinding (BDummy b0, v0) as var0) :: env0' ->
          let v1, env1' = pop_dummy b0 env1 in
          let var1 = EBinding (BDummy b0, v1) in

          (* Debug *)
          [%ldebug
            "join_prefixes: BDummys:\n- value0:\n"
            ^ env_elem_to_string span ctx0 var0
            ^ "\n\n- value1:\n"
            ^ env_elem_to_string span ctx1 var1
            ^ "\n"];

          (* Match the values. A fixed dummy value which did not change (e.g.
             the shared loan of static data, see
             [push_value_to_dummy_shared_loan]) is kept as is: matching it would
             refresh the shared borrow ids it contains, so that it would never
             be equal to itself in the next iteration of a loop fixed point. *)
          let b = b0 in
          let v = if v0 = v1 then v0 else M.match_tvalues ctx0 ctx1 v0 v1 in
          let var = EBinding (BDummy b, v) in
          (* Continue *)
          var :: join_prefixes env0' env1'
      | (EBinding (BVar b0, v0) as var0) :: env0' ->
          let v1, env1' = pop_var b0 env1 in
          let var1 = EBinding (BVar b0, v1) in

          (* Debug *)
          [%ldebug
            "join_prefixes: BVars:\n- value0:\n"
            ^ env_elem_to_string span ctx0 var0
            ^ "\n\n- value1:\n"
            ^ env_elem_to_string span ctx1 var1
            ^ "\n"];

          (* Variable bindings *must* be in the prefix and consequently their
           ids must be the same *)
          (* Match the values *)
          let b = b0 in
          let v = M.match_tvalues ctx0 ctx1 v0 v1 in
          let var = EBinding (BVar b, v) in
          (* Continue *)
          var :: join_prefixes env0' env1'
      | (EAbs abs0 as abs) :: env0' ->
          let abs1, env1' = pop_abs abs0.abs_id env1 in

          (* Debug *)
          [%ldebug
            "join_prefixes:\n- abs0:\n"
            ^ abs_to_string span ctx0 abs0
            ^ "\n\n- abs1:\n"
            ^ abs_to_string span ctx1 abs1
            ^ "\n"];

          (* Fixed abstractions should be equal.

           Note that the presence of the field [abs.original_parents] used to make
           this test fail when some abstraction ids was refreshed by
           [refresh_non_fixed_abs_ids] (we since remove the field).

           Note that we ignore the continuation expressions: when computing fixed
           points we might remove/add continuations while the presence/absence
           shouldn't have an impact on the way we match/unify contexts.

             A fixed abstraction may have a parent which is not fixed (e.g., the
             abstraction of a region nested in the borrows of a joined value,
             unchanged while the abstraction of the outer region lost a
             projector in one branch): its parent id was refreshed in [ctx0].
             The joined context keeps the version of [ctx0], whose parent is
             the refreshed copy; the join then merges that copy with the one of
             [ctx1], which retargets the children (see
             {!InterpAbs.merge_into_first_abstraction}). *)
          let parents1 =
            AbsId.Set.map
              (fun id ->
                Option.value ~default:id (AbsId.Map.find_opt id refreshed_aids))
              abs1.parents
          in
          [%sanity_check] span
            ({ abs0 with cont = None }
            = { abs1 with cont = None; parents = parents1 });
          (* Continue *)
          abs :: join_prefixes env0' env1'
      | [] ->
          if env1 = [] then []
          else
            [%craise] span
              ("Internal error: please file an issue.\n\
                Could not match:\n\
                - env0:\n"
              ^ eval_ctx_to_string ~span:(Some span) ~filter:false
                  { ctx0 with env = List.rev env0 }
              ^ "\n\n- env1:\n"
              ^ eval_ctx_to_string ~span:(Some span) ~filter:false
                  { ctx1 with env = List.rev env1 })
      | _ -> [%internal_error] span
    in
    (* Remove the frame delimiter (the first element of an environment is a frame delimiter) *)
    let env0, env1 =
      match (env0, env1) with
      | EFrame :: env0, EFrame :: env1 -> (env0, env1)
      | _ -> [%craise] span "Unreachable"
    in

    (* Match the prefixes *)
    let prefix = join_prefixes env0 env1 in

    (* The join replaces a branch symbol which holds borrows by a fresh joined
       symbol, and consumes the branch symbol in the abstractions it
       introduces for the joined symbol, which hold its loans (see
       [match_symbolic_values]). Existing shared observations of the branch
       symbol in the branch abstractions follow the replacement, as for copies
       ([InterpExpressions.copy_value]) and reborrows
       ([reborrow_ashared_loans]). Otherwise, when the branch abstractions are
       collapsed, the consuming projection cancels the loans of the branch
       symbol, and the observations lose their lender. The shared projectors
       introduced by the join itself (in [nabs]) are not concerned. *)
    let observed_subst0, observed_subst1 =
      let add ctx (v : tvalue) nsv_id subst =
        match v.value with
        | VSymbolic sv
          when sv.sv_id <> nsv_id
               && ty_has_borrows (Some span) ctx.type_ctx.type_infos sv.sv_ty ->
            SymbolicValueId.Map.add sv.sv_id nsv_id subst
        | _ -> subst
      in
      SymbolicValueId.Map.fold
        (fun nsv_id ((left : tvalue), (right : tvalue)) (subst0, subst1) ->
          (add ctx0 left nsv_id subst0, add ctx1 right nsv_id subst1))
        !symbolic_to_value
        (SymbolicValueId.Map.empty, SymbolicValueId.Map.empty)
    in
    let transfer_observations subst (env : env) : env =
      if SymbolicValueId.Map.is_empty subst then env
      else
        let visitor =
          object (self)
            inherit [_] map_env as super

            method! visit_abs env abs =
              let call_scopes =
                List.map
                  (InterpBorrowsCore.map_call_scope self env)
                  abs.call_scopes
              in
(*
```ocaml
*)
              { (super#visit_abs env abs) with call_scopes }
(*
```
*)

            method! visit_ECallEndpoints env witnesses body =
              ECallEndpoints
                ( InterpBorrowsCore.map_call_endpoint_witnesses self env witnesses,
                  self#visit_tevalue env body )

            method! visit_abstract_shared_borrow _ asb =
              match asb with
              | AsbProjReborrows proj -> (
                  match SymbolicValueId.Map.find_opt proj.sv_id subst with
                  | Some nsv_id -> AsbProjReborrows { proj with sv_id = nsv_id }
                  | None -> asb)
              | AsbBorrow _ -> asb
          end
        in
        List.map
          (function
            | EAbs abs -> EAbs (visitor#visit_abs () abs)
            | ee -> ee)
          env
    in

    (* Apart from the retained payloads matched above, keep the suffixes
       branch-specific: lift dummy values and mark the abstractions. *)
    let suffix =
      let env0 = transfer_observations observed_subst0 env0_suffix in
      let env1 = transfer_observations observed_subst1 env1_suffix in
      (* Debug *)
      [%ldebug
        "join_suffixes:" ^ "\n\n- ctx0:\n"
        ^ eval_ctx_to_string ~span:(Some span) ~filter:false
            { ctx0 with env = List.rev env0 }
        ^ "\n\n- ctx1:\n"
        ^ eval_ctx_to_string ~span:(Some span) ~filter:false
            { ctx1 with env = List.rev env1 }
        ^ "\n"];

      (* Add projection marker to all abstractions in the left and right environments.
         Note that we destructure the fresh abstractions - TODO: make the merge more
         general *)
      let destructure_abs ctx =
        destructure_abs span fresh_abs_kind ~can_end:true ctx
      in
      let add_marker ctx (pm : proj_marker) (ee : env_elem) : env_elem list =
        match ee with
        | EAbs abs ->
            let abs = destructure_abs ctx abs in
            List.map
              (fun abs -> EAbs abs)
              (abs_add_marker span ~loop_level_outputs ctx pm abs)
        | EBinding (BDummy _, v) ->
            (* No variable refers to a dummy value: if it holds nested
               mutable borrows, which region abstractions cannot hold, end
               them in its branch first, then retry the join (see
               [join_ctxs_list]) *)
            Option.iter
              (fun id ->
                raise
                  (ValueMatchFailure
                     (if pm = PLeft then LoanInLeft id else LoanInRight id)))
              (value_nested_mut_borrows_owner span ~shared_payloads:true ctx v);
            (* Transform into a region abstraction and project *)
            let absl, bindings =
              convert_value_to_abstractions span fresh_abs_kind ~can_end:true
                ctx v
            in
            let bindings =
              merge_metadata_bindings (Some span) !metadata_bindings bindings
            in
            let () = metadata_bindings := bindings in
            let ctx = ctx_with_metadata_bindings ctx bindings in
            let absl = List.map (destructure_abs ctx) absl in
            let absl =
              List.concat_map
                (abs_add_marker span ~loop_level_outputs ctx pm)
                absl
            in
            List.map (fun abs -> EAbs abs) absl
        | EBinding (BVar _, _) | EFrame -> [%internal_error] span
      in

      let env0 = List.flatten (List.map (add_marker ctx0 PLeft) env0) in
      let env1 = List.flatten (List.map (add_marker ctx1 PRight) env1) in

      (* Concatenate the suffixes and append the abstractions introduced while
       joining the prefixes *)
      let absl = List.map (fun abs -> EAbs abs) (List.rev !nabs) in
      List.concat [ env0; env1; absl ]
    in

    let env = List.rev (EFrame :: (prefix @ suffix)) in

    (* Construct the joined context - of course, the type, fun, etc. contexts
     * should be the same in the two contexts *)
    let {
      type_ctx;
      crate;
      fun_ctx;
      region_groups;
      type_vars;
      const_generic_vars;
      const_generic_vars_map;
      env = _;
      ended_regions = ended_regions0;
      _;
    } =
      ctx0
    in
    let {
      type_ctx = _;
      crate = _;
      fun_ctx = _;
      region_groups = _;
      type_vars = _;
      const_generic_vars = _;
      const_generic_vars_map = _;
      env = _;
      ended_regions = ended_regions1;
      _;
    } =
      ctx1
    in
    let ended_regions = RegionId.Set.union ended_regions0 ended_regions1 in
    let ctx : eval_ctx =
      {
        ctx0 with
        crate;
        type_ctx;
        fun_ctx;
        region_groups;
        type_vars;
        const_generic_vars;
        const_generic_vars_map;
        env;
        ended_regions;
      }
    in
    let ctx = ctx_with_metadata_bindings ctx !metadata_bindings in
    let join_info : join_info =
      {
        joined_ctx = ctx;
        symbolic_to_value = !symbolic_to_value;
(*
```ocaml
*)
        symbolic_to_value_metadata = !metadata_bindings;
        fixed_abs_ids = abs_ids;
      }
    in

    (* Sanity check *)
    if !Config.sanity_checks then Invariants.check_unique_abs_ids span ctx;

    Ok join_info
  with ValueMatchFailure e -> Error e

(* A join retains the source slots when it replaces a symbolic value.
   The predecessor map and the complete masks identify the replacement.
   A unique complete layout preserves every carrier and continuation path. *)
(*
```ocaml
*)
let source_slot_lineage symbolic_to_value roots =
  let rec ancestors seen id =
    if SymbolicValueId.Set.mem id seen then seen
    else
      let seen = SymbolicValueId.Set.add id seen in
      match SymbolicValueId.Map.find_opt id symbolic_to_value with
      | None -> seen
      | Some (left, right) ->
          let left, _ = compute_tvalue_ids left in
          let right, _ = compute_tvalue_ids right in
          SymbolicValueId.Set.fold
            (fun id seen -> ancestors seen id)
            (SymbolicValueId.Set.union left.sids right.sids) seen
  in
  SymbolicValueId.Set.fold
    (fun id seen -> ancestors seen id) roots SymbolicValueId.Set.empty

let source_slot_layout_evidence ~all ctx roots lineage =
  let fixed = List.filter_map
    (function EAbs abs when abs_has_fixed_avalue_layout abs -> Some abs | _ -> None)
    ctx.env in
  let complete = ref true in
  let rows = List.mapi (fun index (abs : abs) ->
    let compute, get_ids, _ = compute_ids () in
    List.iter (compute#visit_tavalue ()) abs.avalues;
    let avalue_ids = (get_ids ()).sids in
    Option.iter (compute#visit_abs_cont ()) abs.cont;
    List.iter (compute#visit_call_scope ()) abs.call_scopes;
    let owner_ids = (get_ids ()).sids in
    let direct = SymbolicValueId.Set.inter roots owner_ids in
    let contributors = SymbolicValueId.Set.inter lineage owner_ids in
    if not all && SymbolicValueId.Set.is_empty contributors then None
    else if index >= 128 then (complete := false; None)
    else
      let count = List.length abs.avalues in
      let avalues = List.mapi (fun index value ->
        if index < 256 then Some
          ("avalue[" ^ string_of_int index ^ "]: " ^ Values.show_tavalue value)
        else (complete := false; None)) abs.avalues |> List.filter_map Fun.id in
      Some ("owner: " ^ AbsId.to_string abs.abs_id
        ^ "\nkind: " ^ show_abs_kind abs.kind
        ^ "\nowned mask: " ^ RegionId.Set.to_string None abs.regions.owned
        ^ "\nparents: " ^ AbsId.Set.to_string None abs.parents
        ^ "\nended sub-abstractions: " ^ AbsLevelSet.to_string None abs.ended_subabs
        ^ "\ncontinuation: " ^ (match abs.cont with
          | None -> "None" | Some cont -> Values.show_abs_cont cont)
        ^ "\npending scopes: "
        ^ String.concat "\n" (List.map Values.show_call_scope abs.call_scopes)
        ^ "\navalue count: " ^ string_of_int count
        ^ "\navalue symbolic IDs: " ^ SymbolicValueId.Set.to_string None avalue_ids
        ^ "\nowner symbolic IDs: " ^ SymbolicValueId.Set.to_string None owner_ids
        ^ "\ndirect roots: " ^ SymbolicValueId.Set.to_string None direct
        ^ "\nroots or recorded predecessors: "
        ^ SymbolicValueId.Set.to_string None contributors
        ^ "\n" ^ String.concat "\n" avalues)) fixed |> List.filter_map Fun.id in
  "\nfixed source-layout count: " ^ string_of_int (List.length fixed)
  ^ "\nlayout inventory complete: " ^ string_of_bool !complete
  ^ "\nlayout selection: " ^ (if all then "all fixed owners" else "recorded root contributors")
  ^ "\n" ^ String.concat "\n\n" rows

(* 
```ocaml
*)
let render_diagnostic_owner ~retain:_ (abs : abs) =
  (Values.show_abs abs,
   String.concat "\n" (List.map Values.show_call_scope abs.call_scopes))

let diagnose_source_slot_state ?(render_owner = render_diagnostic_owner)
    span phase symbolic_to_value source current =
  let log = Logging.carrier_events_log in
  if Logging.L.Debug >= log#effective_level then (
    let roots = SymbolicValueId.Map.fold
      (fun id _ roots -> SymbolicValueId.Set.add id roots)
      symbolic_to_value SymbolicValueId.Set.empty in
    let lineage = source_slot_lineage symbolic_to_value roots in
    [%ldebug "Source ABI state event:\nphase: " ^ phase
      ^ "\nspan: " ^ Errors.span_to_string span
      ^ "\ntracked roots: " ^ SymbolicValueId.Set.to_string None roots
      ^ "\nrecorded roots and predecessors: " ^ SymbolicValueId.Set.to_string None lineage
      ^ "\nsource layouts:" ^ source_slot_layout_evidence ~all:true source roots lineage
      ^ "\ncurrent layouts:" ^ source_slot_layout_evidence ~all:true current roots lineage
      ^ "\nsource bindings: "
      ^ carrier_metadata_bindings source.metadata_bindings
      ^ "\ncurrent bindings: "
      ^ carrier_metadata_bindings current.metadata_bindings];
    let count = ref 0 in
    let owner_count = ref 0 in
    List.iteri (fun index element ->
      match element with
      | EBinding (_, value) ->
          let ids, _ = compute_tvalue_ids value in
          if not (SymbolicValueId.Set.disjoint ids.sids lineage) then (
            incr count;
            if !count <= 256 then
              [%ldebug "Source ABI runtime binding event:\nphase: " ^ phase
                ^ "\nenvironment index: " ^ string_of_int index
                ^ "\nraw binding: " ^ Values.show_env_elem element
                ^ runtime_type_metadata_view current [value.ty]])
      | EAbs abs ->
          let () = incr owner_count in
          let ids, _ = compute_abs_ids abs in
          if not (SymbolicValueId.Set.disjoint ids.sids lineage) then (
            incr count;
            if !count <= 256 then
              [%ldebug
                let raw_owner, call_scopes =
                  render_owner ~retain:(!owner_count <= 128) abs
                in
                "Source ABI owner event:\nphase: " ^ phase
                ^ "\nenvironment index: " ^ string_of_int index
                ^ "\nraw owner: " ^ raw_owner
                ^ "\npending scopes: " ^ call_scopes])
(* 
```
*)
      | EFrame -> ()) current.env;
    [%ldebug "Source ABI state coverage:\nphase: " ^ phase
      ^ "\nmatching environment entries: " ^ string_of_int !count
      ^ "\nenvironment inventory complete: " ^ string_of_bool (!count <= 256)])
(*
```
*)

(* ```ocaml *)
let restore_source_slots (span : Meta.span)
    (symbolic_to_value : (tvalue * tvalue) SymbolicValueId.Map.t)
    (predecessor_metadata : region_metadata_bindings)
    (source : eval_ctx) (joined : eval_ctx) : eval_ctx =
  let source = ctx_with_metadata_bindings source predecessor_metadata in
  (* ```ocaml *)
  [%ltrace
    "Source ABI predecessor relation:\n"
    ^ String.concat "\n"
        (List.map
          (fun (id, (left, right)) ->
            SymbolicValueId.to_string id ^ " <- "
            ^ tvalue_to_string source left ^ " | " ^ tvalue_to_string source right)
          (SymbolicValueId.Map.bindings symbolic_to_value))
    ^ "\n- source bindings: "
    ^ carrier_metadata_bindings source.metadata_bindings
    ^ "\n- joined bindings: "
    ^ carrier_metadata_bindings joined.metadata_bindings];
  (* ``` *)
  (* ```ocaml *)
  let current_types = ref SymbolicValueId.Map.empty in
  let visitor = object
    inherit [_] iter_eval_ctx
    method! visit_ty _ _ = ()
    method! visit_symbolic_value _ sv =
      if SymbolicValueId.Map.mem sv.sv_id symbolic_to_value then
        match SymbolicValueId.Map.find_opt sv.sv_id !current_types with
        | None -> current_types := SymbolicValueId.Map.add sv.sv_id sv.sv_ty !current_types
        | Some previous ->
            [%cassert] span (previous = sv.sv_ty)
              "A joined symbolic source has distinct complete types"
  end in
  visitor#visit_eval_ctx () joined;
  (* ```ocaml *)
  let infos = source.type_ctx.type_infos in
  let metadata_policy =
    (* ```ocaml *)
    ((fun id index original mapped ->
       if RegionId.Set.mem index (TypeDeclId.Map.find id infos).metadata_regions
       then original else mapped),
    (* ``` *)
     (fun id index ->
       TypeVarId.Set.mem index (TypeDeclId.Map.find id infos).metadata_type_params))
  in
  let metadata_region_arg info index =
    match info with
    | None -> false
    | Some info -> RegionId.Set.mem (RegionId.of_int index) info.TypesAnalysis.metadata_regions
  in
  let metadata_type_arg info index =
    match info with
    | None -> false
    | Some info -> TypeVarId.Set.mem (TypeVarId.of_int index) info.TypesAnalysis.metadata_type_params
  in
  let metadata_correspondence = ref RegionId.Map.empty in
  let derive_correspondence original current =
    let execution = ref RegionId.Map.empty in
    let add metadata left right =
      match left, right with
      | RVar (Free id), (RVar (Free _) | RStatic) ->
          let correspondence = if metadata then metadata_correspondence else execution in
          (match RegionId.Map.find_opt id !correspondence with
          | None -> correspondence := RegionId.Map.add id right !correspondence
          | Some previous ->
              let equal =
                if metadata then
                  metadata_region joined.metadata_bindings previous
                  = metadata_region joined.metadata_bindings right
                else previous = right
              in
              [%cassert] span equal
                (if metadata then "A source slot has distinct metadata region transports"
                 else "A source slot has distinct execution region transports"))
      | _ -> ()
    in
    let iter_args stored visit left right =
      let rec iter index left right =
        match left, right with
        | [], [] -> ()
        | left :: lefts, right :: rights ->
            if stored index then visit index left right;
            iter (index + 1) lefts rights
        | _ -> [%craise] span "A joined source changes its complete nominal type"
      in
      iter 0 left right
    in
    let rec visit metadata left right =
      match left, right with
      | TAdt left, TAdt right ->
          [%cassert] span (left.id = right.id)
            "A joined source changes its complete nominal type";
          let info = InterpBorrowsCore.projection_adt_info infos left.id in
          iter_args (InterpBorrowsCore.projection_region_is_stored info)
            (fun index left right ->
              add (metadata || metadata_region_arg info index) left right)
            left.generics.regions right.generics.regions;
          iter_args (InterpBorrowsCore.projection_type_is_stored info)
            (fun index left right ->
              visit (metadata || metadata_type_arg info index) left right)
            left.generics.types right.generics.types
      | TRef (left_region, left, _), TRef (right_region, right, _) ->
          add metadata left_region right_region;
          visit metadata left right
      | TRawPtr (left, _), TRawPtr (right, _)
      | TArray (left, _), TArray (right, _)
      | TPtrMetadata left, TPtrMetadata right
      | TSlice left, TSlice right -> visit metadata left right
      | _ -> ()
    in
    visit false original current;
    !execution
  in
  let transport_ty ctx ~projection renaming =
    let execution =
      Substitute.subst_ids_visitor ~metadata_policy
        { Substitute.empty_id_subst with
          r_subst = (fun id ->
            match RegionId.Map.find_opt id renaming with
            | Some (RVar (Free actual)) -> actual
            | _ -> id) }
    in
    let visitor = object (self)
      inherit [_] map_ty as super
      method! visit_region_param _ param = param
      method! visit_region (stored, metadata) region =
        if stored then region
        else if metadata then metadata_region ctx.metadata_bindings region
        else
          match InterpBorrowsCore.rename_projection_metadata_region renaming region with
          | RStatic -> RStatic
          | _ -> execution#visit_region () region
      method! visit_TFnPtr _ signature = super#visit_TFnPtr (false, true) signature
      method! visit_TFnDef _ fn = super#visit_TFnDef (false, true) fn
      method! visit_trait_ref _ witness = super#visit_trait_ref (false, true) witness
      method! visit_TDynTrait _ witness = super#visit_TDynTrait (false, true) witness
      method! visit_TAdt (stored, metadata) tref =
        let info = InterpBorrowsCore.projection_adt_info infos tref.id in
        let generics = tref.generics in
        let regions = List.mapi
          (fun index region ->
            self#visit_region
              (stored && InterpBorrowsCore.projection_region_is_stored info index,
               metadata || metadata_region_arg info index) region)
          generics.regions in
        let types = List.mapi
          (fun index ty ->
            self#visit_ty
              (stored && InterpBorrowsCore.projection_type_is_stored info index,
               metadata || metadata_type_arg info index) ty)
          generics.types in
        let trait_refs = List.map (self#visit_trait_ref (false, true)) generics.trait_refs in
        TAdt { tref with generics = { generics with regions; types; trait_refs } }
    end in
    visitor#visit_ty (projection, false)
  in
  (* ``` *)
  let runtime_correspondence =
    SymbolicValueId.Map.fold
      (fun id (original, _) correspondence ->
        let original = value_strip_shared_loans original in
        match original.value, SymbolicValueId.Map.find_opt id !current_types with
        | VSymbolic original, Some current_ty ->
            (*
            ```ocaml
            *)
            let () =
              let log = Logging.carrier_events_log in
              if Logging.L.Debug >= log#effective_level then (
                let roots = SymbolicValueId.Set.singleton id in
                let lineage = source_slot_lineage symbolic_to_value roots in
                [%ldebug "Source ABI correspondence input:"
                  ^ "\njoined root: " ^ SymbolicValueId.to_string id
                  ^ "\nsource root: " ^ SymbolicValueId.to_string original.sv_id
                  ^ "\nraw source type: " ^ Types.show_ty original.sv_ty
                  ^ "\nraw joined type: " ^ Types.show_ty current_ty
                  ^ "\nsource evidence: "
                  ^ runtime_type_metadata_view source [original.sv_ty]
                  ^ "\njoined evidence: "
                  ^ runtime_type_metadata_view joined [current_ty]
                  ^ "\nsource layout contribution:"
                  ^ source_slot_layout_evidence ~all:false source roots lineage
                  ^ "\njoined layout contribution:"
                  ^ source_slot_layout_evidence ~all:false joined roots lineage])
            in
            (*
            ```
            *)
            let renaming = derive_correspondence original.sv_ty current_ty in
            (* ```ocaml *)
            [%ltrace
              "Source ABI typed predecessor: " ^ SymbolicValueId.to_string original.sv_id
              ^ " -> " ^ SymbolicValueId.to_string id
              ^ "\n- original full type: " ^ ty_to_string source original.sv_ty
              ^ "\n- actual full type: " ^ ty_to_string joined current_ty
              ^ "\n- operational correspondence: "
              ^ RegionId.Map.to_string None show_region renaming];
            (* ``` *)
            let source_view = transport_ty source ~projection:false renaming original.sv_ty in
            let joined_view = transport_ty joined ~projection:false RegionId.Map.empty current_ty in
            [%classert] span (source_view = joined_view)
              (lazy ("A joined source changes its complete nominal type"
              ^ "\n- joined root: " ^ SymbolicValueId.to_string id
              ^ "\n- predecessor root: " ^ SymbolicValueId.to_string original.sv_id
              ^ "\n- source full type: " ^ ty_to_string source original.sv_ty
              ^ "\n- joined full type: " ^ ty_to_string joined current_ty
              ^ "\n- resolved source type: " ^ ty_to_string source source_view
              ^ "\n- resolved joined type: " ^ ty_to_string joined joined_view
              ^ "\n- stored correspondence: "
              ^ RegionId.Map.to_string None show_region renaming));
            (* ```ocaml *)
            [%cassert] span
              (ty_erase_regions_with_metadata infos source.metadata_bindings original.sv_ty
               = ty_erase_regions_with_metadata infos joined.metadata_bindings current_ty)
              "A joined source changes its runtime type";
            (* ``` *)
            RegionId.Map.fold
              (fun region actual correspondence ->
                match RegionId.Map.find_opt region correspondence with
                | None -> RegionId.Map.add region actual correspondence
                | Some previous ->
                    [%cassert] span (previous = actual)
                      "A source slot has distinct runtime region transports";
                    correspondence)
              renaming correspondence
        | _ -> correspondence)
      symbolic_to_value RegionId.Map.empty
  in
  [%ltrace "Source ABI runtime correspondence: "
    ^ RegionId.Map.to_string None show_region runtime_correspondence];
  (* ``` *)
  (* ```ocaml *)
  let source_projection = transport_ty source ~projection:true runtime_correspondence in
  let joined_projection = transport_ty joined ~projection:true RegionId.Map.empty in
  (* ``` *)
  let key ctx regions predecessor (value : tavalue) =
    (* Normalize owned positions before transport. A target ID can also occur
       in an unused source position. *)
    (* ```ocaml *)
    let transport = if predecessor then joined_projection else source_projection in
    let normalize mask ty =
      transport (InterpBorrowsCore.normalize_proj_ty ctx.type_ctx.type_infos mask ty)
    (* ``` *)
    in
    let sid id =
      if not predecessor then id
      else
        match SymbolicValueId.Map.find_opt id symbolic_to_value with
        | Some (original, _) ->
            (match (value_strip_shared_loans original).value with
            | VSymbolic original -> original.sv_id
            | _ -> id)
        | None -> id
    in
    (* ```ocaml *)
    let visitor = object
      inherit [_] map_tavalue
      method! visit_ty _ ty = normalize regions ty
      method! visit_symbolic_value_id _ id = sid id
      method! visit_symbolic_pending_slot _ slot =
        let selected =
          if ty_has_regions_in_set infos slot.proj_regions slot.proj_ty then
            RegionId.Set.singleton RegionId.zero
          else RegionId.Set.empty
        in
        { slot with
          root_sv_id = sid slot.root_sv_id;
          proj_ty = normalize slot.proj_regions slot.proj_ty;
          proj_regions = selected }
    end in
    let value = visitor#visit_tavalue () value in
    (* ``` *)
    match value.value with
    | ASymbolic (marker, AProjLoans { proj; consumed = []; borrows = [] }) ->
        `Projection (true, marker, proj.sv_id, proj.proj_ty)
    | ASymbolic (marker, AProjBorrows { proj; loans = [] }) ->
        `Projection (false, marker, proj.sv_id, proj.proj_ty)
    | _ -> `Value (value.ty, value.value)
  in
  (* ```ocaml *)
  let show_slot_key = function
    | `Projection (loan, marker, root, ty) ->
        (if loan then "loan" else "borrow") ^ ":"
        ^ show_proj_marker marker ^ ":" ^ SymbolicValueId.to_string root
        ^ ":" ^ ty_to_string joined ty
    | `Value (ty, value) -> tavalue_to_string joined { ty; value }
  in
  (* ``` *)
  let originals =
    List.filter_map
      (function
        | EAbs abs when abs_has_fixed_avalue_layout abs ->
            Some
              (List.map
                 (key source abs.regions.owned false)
                 abs.avalues)
        | _ -> None)
      source.env
  in
  let restore (abs : abs) =
    if not (abs_has_fixed_avalue_layout abs) then abs
    else
      let available =
        List.map
          (fun value -> (key joined abs.regions.owned true value, value))
          abs.avalues
      in
      let rec align index remaining = function
        | [] ->
            (* Completed slots outside the source layout carry no value.
               Every source slot remains in its original order. *)
            if List.for_all
                 (fun (_, (value : tavalue)) ->
                   match value.value with AIgnored None -> true | _ -> false)
                 remaining
            then Some []
            else None
        | expected :: rest ->
            let selected, remaining =
              List.partition (fun (actual, _) -> actual = expected) remaining
            in
            match selected with
            (* ```ocaml *)
            | [ (actual, value) ] ->
                [%ltrace
                  "Source ABI slot alignment:\n- target owner: " ^ AbsId.to_string abs.abs_id
                  ^ "\n- original position: " ^ string_of_int index
                  ^ "\n- selected current position: "
                  ^ string_of_int
                      (fst (List.find (fun (_, current) -> current == value)
                        (List.mapi (fun index value -> (index, value)) abs.avalues)))
                  ^ "\n- source key: " ^ show_slot_key expected
                  ^ "\n- current key: " ^ show_slot_key actual
                  ^ "\n- physical payload: " ^ tavalue_to_string joined value];
                Option.map (fun rest -> value :: rest) (align (index + 1) remaining rest)
            | _ ->
                [%ltrace
                  "Source ABI slot alignment rejection:\n- target owner: "
                  ^ AbsId.to_string abs.abs_id
                  ^ "\n- original position: " ^ string_of_int index
                  ^ "\n- source key: " ^ show_slot_key expected
                  ^ "\n- current keys: "
                  ^ String.concat "\n" (List.map (fun (actual, _) -> show_slot_key actual) remaining)
                  ^ "\n- exact matches: " ^ string_of_int (List.length selected)];
                None
            (* ``` *)
      in
      let matches =
        List.filter_map
          (fun original -> align 0 available original)
          originals
      in
      match matches with
      | [ avalues ] ->
          if List.equal ( == ) avalues abs.avalues then abs
          else { abs with avalues }
      | _ -> abs
  in
  if originals = [] then joined else ctx_map_abs restore joined
(* ``` *)

let join_ctxs_list (config : config) (span : Meta.span) ?(loop : bool = false)
    (fresh_abs_kind : abs_kind) ?(preprocess_first_ctx : bool = true)
    ~(recoverable : bool) ~(with_abs_conts : bool) (ctxl : eval_ctx list) :
    eval_ctx list * eval_ctx =
  (* The list of contexts should be non empty *)
  let ctx0, ctxl =
    match ctxl with
    | [] -> [%internal_error] span
    | ctx0 :: ctxl -> (ctx0, ctxl)
  in

  (* Small helper - TODO: probably not necessary anymore as we now preprocess
     the contexts depending on the situation *)
  let preprocess_ctx (ctx : eval_ctx) : eval_ctx =
    (* Simplify the dummy values, by removing as many as we can -
       we ignore the synthesis continuation *)
    let ctx, _ = simplify_dummy_values_useless_abs config span ctx in
    [%ltrace
      "after simplify_dummy_values_useless_abs:\n"
      ^ eval_ctx_to_string ~span:(Some span) ctx];
    ctx
  in

  let ctx0 = if preprocess_first_ctx then preprocess_ctx ctx0 else ctx0 in

  (* # Join with the new contexts, one by one

     For every context, we repeteadly attempt to join it with the current
     result of the join: if we fail (because we need to end loans for instance),
     we update the context and retry.
  *)
  let joined_ctx = ref ctx0 in
  (* The abstractions kept unchanged by the last join *)
  let untouched = ref AbsId.Set.empty in
  let source_slots = ref None in
  let rec join_one_aux (ctx : eval_ctx) : eval_ctx =
    match
      join_ctxs span ~loop fresh_abs_kind ~recoverable ~with_abs_conts
        !joined_ctx ctx
    with
    (* ```ocaml *)
    | Ok { joined_ctx = nctx; fixed_abs_ids; symbolic_to_value;
           symbolic_to_value_metadata } ->
        source_slots :=
          (match fresh_abs_kind with
          | Loop _ when not with_abs_conts ->
              Some (!joined_ctx, symbolic_to_value, symbolic_to_value_metadata)
          | _ -> None);
        joined_ctx := nctx;
        untouched := fixed_abs_ids;
        ctx
    (* ``` *)
    | Error err ->
        (* End the loans, then simplify again: the values given back may have
           made region abstractions useless (see [preprocess_ctx]) *)
        let ctx =
          (* TODO: simplify *)
          match err with
          | LoanInRight bid ->
              preprocess_ctx (InterpBorrows.end_loan_no_synth config span bid ctx)
          | LoansInRight bids ->
              preprocess_ctx
                (InterpBorrows.end_loans_no_synth config span bids ctx)
          | LoanInLeft bid ->
              joined_ctx :=
                preprocess_ctx
                  (InterpBorrows.end_loan_no_synth config span bid !joined_ctx);
              ctx
          | LoansInLeft bids ->
              joined_ctx :=
                preprocess_ctx
                  (InterpBorrows.end_loans_no_synth config span bids !joined_ctx);
              ctx
          | AbsInRight _ | AbsInLeft _ -> [%craise] span "Unexpected"
        in
        join_one_aux ctx
  in
  let join_one (ctx : eval_ctx) : eval_ctx =
    [%ltrace
      "join_one: initial ctx:\n" ^ eval_ctx_to_string ~span:(Some span) ctx];

    (* Simplify the dummy values *)
    let ctx = preprocess_ctx ctx in

    (* Join the two contexts  *)
(*
```ocaml
*)
    let left_before_join = !joined_ctx in
    let right_before_join = ctx in
(*
```
*)
    let ctx1 = join_one_aux ctx in
(*
```ocaml
*)
    InterpBorrows.diagnose_symbolic_runtime_type_transition span
(*
```ocaml
*)
      "join_ctxs_list: retry-inclusive initial left to successful join"
      left_before_join !joined_ctx;
(*
```
*)
    InterpBorrows.diagnose_symbolic_runtime_type_transition span
(*
```ocaml
*)
      "join_ctxs_list: retry-inclusive initial right to successful join"
      right_before_join !joined_ctx;
(*
```
*)
(*
```
*)
    [%ltrace
      "join_one: after join:\n"
      ^ eval_ctx_to_string ~span:(Some span) !joined_ctx];

    (*
    ```ocaml
    *)
    (match !source_slots with
    | Some (source, symbolic_to_value, _) ->
        diagnose_source_slot_state span "before collapse" symbolic_to_value source !joined_ctx
    | None -> ());
    (*
    ```
    *)
    (* Collapse to eliminate the markers *)
    joined_ctx :=
      collapse_ctx config span ~untouched:!untouched ~loop fresh_abs_kind
        ~recoverable ~with_abs_conts !joined_ctx;
    (* ```ocaml *)
    (match !source_slots with
    | Some (source, symbolic_to_value, predecessor_metadata) ->
        diagnose_source_slot_state span "after collapse" symbolic_to_value source !joined_ctx;
        joined_ctx :=
          restore_source_slots span symbolic_to_value predecessor_metadata source !joined_ctx
(*
```
*)
    | None -> ());
    (* ``` *)
    [%ltrace
      "join_one: after join-collapse:\n"
      ^ eval_ctx_to_string ~span:(Some span) !joined_ctx];
    (* Sanity check *)
    if !Config.sanity_checks then Invariants.check_invariants span !joined_ctx;

    (* Return *)
    ctx1
  in

  let ctxl = List.map join_one ctxl in

  (* # Return *)
  (ctx0 :: ctxl, !joined_ctx)

(** Destructure all the new abstractions *)
let destructure_new_abs (span : Meta.span) (old_abs_ids : AbsId.Set.t)
    (ctx : eval_ctx) : eval_ctx =
  [%ltrace "ctx:\n\n" ^ eval_ctx_to_string ctx];
  let is_fresh_abs_id (id : AbsId.id) : bool =
    not (AbsId.Set.mem id old_abs_ids)
  in
  let env =
    env_map_abs
      (fun abs ->
        if is_fresh_abs_id abs.abs_id then
          let abs = destructure_abs span abs.kind ~can_end:true ctx abs in
          abs
        else abs)
      ctx.env
  in
  let ctx = { ctx with env } in
  [%ltrace "resulting ctx:\n\n" ^ eval_ctx_to_string ctx];
  Invariants.check_invariants span ctx;
  ctx

let loop_join_origin_with_continue_ctxs (config : config) (span : Meta.span)
    (loop_id : LoopId.id) (ctx0 : eval_ctx) (ctxl : eval_ctx list) :
    (eval_ctx * eval_ctx list) * eval_ctx =
  (* Simplify the contexts we want to join *)
  let simplify (ctx : eval_ctx) : eval_ctx =
    let fixed_aids = compute_fixed_abs_ids ctx0 ctx in
    let fixed_dids = ctx_get_dummy_var_ids ctx0 in
    [%ldebug "- fixed_aids: " ^ AbsId.Set.to_string None fixed_aids];

    (* Simplify the dummy values, by removing as many as we can -
       we ignore the synthesis continuation, as we are only computing a fixed point *)
    let ctx, _ = simplify_dummy_values_useless_abs config span ctx in
    [%ltrace
      "simplify: after simplify_dummy_values_useless_abs:\n"
      ^ eval_ctx_to_string ~span:(Some span) ctx];

    (* Destructure the abstractions introduced in the new context *)
    let ctx = destructure_new_abs span fixed_aids ctx in
    [%ltrace
      "simplify: after destructure:\n"
      ^ eval_ctx_to_string ~span:(Some span) ctx];

    (* Reduce the context we want to add to the join *)
    let ctx =
      reduce_ctx config span ~with_abs_conts:false (Loop loop_id) fixed_aids
        fixed_dids ctx
    in
    [%ltrace
      "simplify: after reduce:\n" ^ eval_ctx_to_string ~span:(Some span) ctx];
    (* Sanity check *)
    if !Config.sanity_checks then Invariants.check_invariants span ctx;

    ctx
  in

  let ctxl = List.map simplify ctxl in

  let ctxl', joined_ctx =
    join_ctxs_list config span (Loop loop_id) ~preprocess_first_ctx:false
      ~recoverable:false ~with_abs_conts:false (ctx0 :: ctxl)
  in
  [%sanity_check] span (List.length ctxl' = List.length ctxl + 1);
  ((List.hd ctxl', List.tl ctxl'), joined_ctx)

let loop_join_break_ctxs (config : config) (span : Meta.span)
    (loop_id : LoopId.id) (fixed_aids : AbsId.Set.t)
    (fixed_dids : DummyVarId.Set.t) (ctxl : eval_ctx list) : eval_ctx =
  (* Simplify the contexts *)
  let with_abs_conts = false in
  let fresh_abs_kind : abs_kind = Loop loop_id in
  let prepare_ctx (ctx : eval_ctx) : eval_ctx =
    [%ltrace
      "prepate_ctx: initial ctx:\n" ^ eval_ctx_to_string ~span:(Some span) ctx];

    (* Simplify the dummy values, by removing as many as we can -
       we ignore the synthesis continuation *)
    let ctx, _ = simplify_dummy_values_useless_abs config span ctx in
    [%ltrace
      "prepare_ctx: after simplify_dummy_values_useless_abs:\n"
      ^ eval_ctx_to_string ~span:(Some span) ctx];

    (* Destructure the abstractions introduced in the new context *)
    let ctx = destructure_new_abs span fixed_aids ctx in
    [%ltrace
      "prepare_ctx: after destructure:\n"
      ^ eval_ctx_to_string ~span:(Some span) ctx];

    (* Reduce the context we want to add to the join *)
    let ctx =
      reduce_ctx config span ~with_abs_conts:false (Loop loop_id) fixed_aids
        fixed_dids ctx
    in
    [%ltrace
      "prepare_ctx: after reduce:\n" ^ eval_ctx_to_string ~span:(Some span) ctx];
    (* Sanity check *)
    if !Config.sanity_checks then Invariants.check_invariants span ctx;

    ctx
  in
  let ctxl = List.map prepare_ctx ctxl in

  match ctxl with
  | [] -> [%internal_error] span
  | [ ctx ] ->
      (* Special case: simply remove the continuation expressions from the fresh abs *)
      let update (e : env_elem) : env_elem =
        match (e : env_elem) with
        | EAbs abs ->
            if AbsId.Set.mem abs.abs_id fixed_aids then e
            else EAbs { abs with cont = None; kind = Loop loop_id }
        | EBinding _ | EFrame -> e
      in
      { ctx with env = List.map update ctx.env }
  | ctx :: ctxl ->
      let joined_ctx = ref ctx in

      (* # Join the contexts, one by one.

          For every context, we repeteadly attempt to join it with the current
          result of the join: if we fail (because we need to end loans for instance),
          we update the context and retry.
       *)
      let untouched = ref AbsId.Set.empty in
      let rec join_one_aux (ctx : eval_ctx) =
        match
          join_ctxs span fresh_abs_kind ~recoverable:false ~with_abs_conts
            !joined_ctx ctx
        with
        | Ok { joined_ctx = nctx; fixed_abs_ids; _ } ->
            joined_ctx := nctx;
            untouched := fixed_abs_ids;
            ctx
        | Error err ->
            let ctx =
              (* TODO: simplify *)
              match err with
              | LoanInRight bid ->
                  InterpBorrows.end_loan_no_synth config span bid ctx
              | LoansInRight bids ->
                  InterpBorrows.end_loans_no_synth config span bids ctx
              | LoanInLeft bid ->
                  joined_ctx :=
                    InterpBorrows.end_loan_no_synth config span bid !joined_ctx;
                  ctx
              | LoansInLeft bids ->
                  joined_ctx :=
                    InterpBorrows.end_loans_no_synth config span bids
                      !joined_ctx;
                  ctx
              | AbsInRight _ | AbsInLeft _ -> [%craise] span "Unexpected"
            in
            join_one_aux ctx
      in
      let join_one (ctx : eval_ctx) =
        (* Join the two contexts  *)
        let ctx1 = join_one_aux ctx in
        [%ltrace
          "join_one: after join:\n" ^ eval_ctx_to_string ~span:(Some span) ctx1];

        (* Collapse to eliminate the markers *)
        joined_ctx :=
          collapse_ctx config span ~untouched:!untouched fresh_abs_kind
            ~recoverable:false ~with_abs_conts !joined_ctx;
        [%ltrace
          "join_one: after join-collapse:\n"
          ^ eval_ctx_to_string ~span:(Some span) !joined_ctx];
        (* Sanity check *)
        if !Config.sanity_checks then
          Invariants.check_invariants span !joined_ctx;

        (* Reduce (it helps matching afterwards) *)
        joined_ctx :=
          reduce_ctx config span ~with_abs_conts fresh_abs_kind fixed_aids
            fixed_dids !joined_ctx;
        [%ltrace
          "join_one: after last reduce:\n"
          ^ eval_ctx_to_string ~span:(Some span) !joined_ctx];

        (* Sanity check *)
        if !Config.sanity_checks then
          Invariants.check_invariants span !joined_ctx
      in
      List.iter join_one ctxl;

      (* Update the fresh region abstractions *)
      !joined_ctx

let match_ctx_with_target (config : config) (span : Meta.span)
    ?(loop : bool = false) (fresh_abs_kind : abs_kind) (fixed_aids : AbsId.Set.t)
    (fixed_dids : DummyVarId.Set.t) (input_abs : AbsId.id list)
    (input_svalues : SymbolicValueId.id list) ~(recoverable : bool)
    (src_ctx : eval_ctx) (tgt_ctx : eval_ctx) :
    (eval_ctx * eval_ctx * tvalue SymbolicValueId.Map.t * abs AbsId.Map.t)
    * (SymbolicAst.expr -> SymbolicAst.expr) =
  let diagnostic =
    let log = Logging.carrier_events_log in
    if not (!Config.print_error_diagnostics || !Config.print_error_emitters
            || Logging.L.Debug >= log#effective_level) then None
    else try
      let native = {
        trace_count = 0; trace_phase = "target-reduction"; trace_step = -1;
        trace_fixed = None; trace_preserved = AbsId.Set.empty;
        trace_callback_unavailable = 0; trace_records = Array.make 128 None;
      } in
      Some ({ replay_native = native; replay_count = 0;
              replay_records = Array.make 128 None }, ref AbsId.Map.empty, ref None)
    with _ -> None
  in
  let native_diagnostic = Option.map (fun (capture, _, _) -> capture.replay_native) diagnostic in
  let source_ids = Option.map (fun (_, ids, _) -> ids) diagnostic in
  let selected_pair = Option.map (fun (_, _, pair) -> pair) diagnostic in
  let src_ctx = normalize_private_shared_regions span src_ctx in
  (* Debug *)
  [%ltrace
    "- src_ctx: " ^ eval_ctx_to_string src_ctx ^ "\n- tgt_ctx: "
    ^ eval_ctx_to_string tgt_ctx];

  (* End all the unnecessary borrows/loans.

     Note that in theory it's better to call [prepare_loop_match_ctx_with_target]
     *before* because it unlocks simplification possibilities for
     [simplify_dummy_values_useless_abs], but in practice it is also good to
     call [simplify_dummy_values_useless_abs config span tgt_ctx] before so
     that it prevents [prepare_match_ctx_with_target] from doing matches that
     are not supported yet. For this reason, we call simplify twice: before
     and after the call to prepare.
  *)
  let tgt_ctx, cc = simplify_dummy_values_useless_abs config span tgt_ctx in
  [%ltrace
    "- tgt_ctx after simplify_dummy_values_useless_abs (i):\n"
    ^ eval_ctx_to_string tgt_ctx];

  (* We first reorganize [tgt_ctx] so that we can match [src_ctx] with it (by
     ending loans for instance - remember that the [src_ctx] is the fixed point
     context, which results from joins during which we ended the loans which
     were introduced during the loop iterations).

     This operation only ends loans/abstractions and moves some values to anonymous
     values.
  *)
  let tgt_ctx, cc =
    comp cc
      (prepare_match_ctx_with_target config span ~loop fresh_abs_kind
         ~recoverable src_ctx tgt_ctx)
  in
  [%ltrace
    "Finished preparing the match:" ^ "\n- src_ctx: "
    ^ eval_ctx_to_string src_ctx ^ "\n- tgt_ctx: " ^ eval_ctx_to_string tgt_ctx];

  (* End all the unnecessary borrows/loans (note that it's better to call
     [prepare_loop_match_ctx_with_target] *before* because it unlocks simplification
     possibilities for [simplify_dummy_values_useless_abs]. *)
  let tgt_ctx, cc =
    comp cc (simplify_dummy_values_useless_abs config span tgt_ctx)
  in
  [%ltrace
    "- tgt_ctx after simplify_dummy_values_useless_abs (ii):\n"
    ^ eval_ctx_to_string tgt_ctx];

  (* Reduce the context - TODO: generalize the join so that we don't need to do this *)
  let tgt_ctx =
    reduce_ctx config span ?diagnostic:native_diagnostic ~loop ~with_abs_conts:true fresh_abs_kind fixed_aids
      fixed_dids tgt_ctx
  in
  [%ltrace "- tgt_ctx after reduce_ctx:\n" ^ eval_ctx_to_string tgt_ctx];

  (* Join the source context with the target context *)
  let join_info =
    match
      join_ctxs span ~loop ?diagnostic_source_ids:source_ids fresh_abs_kind ~recoverable ~with_abs_conts:true
        src_ctx tgt_ctx
    with
    | Ok x -> x
    | Error _ -> [%craise] span "Could not join the contexts"
  in
  let joined_ctx = join_info.joined_ctx in
  [%ltrace
    "Result of the join:\n- joined_ctx:\n"
    ^ eval_ctx_to_string joined_ctx
    ^ "\n- join_info.symbolic_to_value: "
    ^ SymbolicValueId.Map.to_string (Some "  ")
        (Print.pair_to_string (tvalue_to_string src_ctx)
           (tvalue_to_string src_ctx))
        join_info.symbolic_to_value];

  (* We need to collapse the context.

     We have to collapse the context because otherwise some abstractions might not
     get merged, leading to an issue when matching the source context with the
     joined context afterwards. We also do not want to collapse the context then
     project it, because the collapsed context uses elements from both the right
     and left context in its abstraction expressions, which are a bit annoying
     to project. What we do for now is merge the joined context, to register the
     sequence of merges which have to be performed, then project the context
     *before* the collapse, and apply the same sequence to this one.

     TODO: we need to make the match more general so that we do not have to do this.
  *)
  (match native_diagnostic with None -> () | Some capture ->
      capture.trace_phase <- "unprojected";
      capture.trace_step <- -1);
  let diagnostic_original_joined = match diagnostic with None -> None | Some _ -> Some joined_ctx in
  let merge_seq = ref [] in
  let add_borrows_seq = ref [] in
  let joined_ctx_not_projected =
    collapse_ctx config span ?diagnostic:native_diagnostic ~loop ~sequence:(Some merge_seq)
      ~shared_borrows_seq:(Some add_borrows_seq)
      ~untouched:join_info.fixed_abs_ids ~recoverable ~with_abs_conts:true
      ~preserved_abs_ids:join_info.fixed_abs_ids
      fresh_abs_kind joined_ctx
  in
  let diagnostic_unprojected = match diagnostic with None -> None | Some _ -> Some joined_ctx_not_projected in
  let merge_seq = List.rev !merge_seq in
  (* Update the sequence of shared borrows to introduce: we only want to add
     borrows to the right *)
  let add_borrows_seq =
    List.filter_map
      (fun (abs_id, i, pm, bid, ty) ->
        if pm = PRight then Some (abs_id, i, PNone, bid, ty) else None)
      (List.rev !add_borrows_seq)
  in
  [%ltrace
    "After collapsing the (unprojected) context: joined_ctx_not_projected:\n"
    ^ eval_ctx_to_string joined_ctx_not_projected
    ^ "\n\n- merge_seq:\n"
    ^ String.concat "\n"
        (List.map
           (fun (a0, a1, a2) ->
             "(" ^ AbsId.to_string a0 ^ "," ^ AbsId.to_string a1 ^ ") -> "
             ^ AbsId.to_string a2)
           merge_seq)];

  (* Project the context to only preserve the right part, which corresponds to the
     target *)
  let joined_ctx = project_context span fixed_aids PRight joined_ctx in
  let joined_symbolic_to_tgt_value =
    SymbolicValueId.Map.map (fun (_, x) -> x) join_info.symbolic_to_value
  in
  [%ltrace
    "After projection: joined_ctx:\n"
    ^ eval_ctx_to_string joined_ctx
    ^ "\n- joined_symbolic_to_tgt_value: "
    ^ SymbolicValueId.Map.to_string (Some "  ") (tvalue_to_string src_ctx)
        joined_symbolic_to_tgt_value];

  (* Apply the sequence of merges to the projected context *)
  let diagnostic_projected = match diagnostic with None -> None | Some _ -> Some joined_ctx in
  let replay_diagnostic = Option.map (fun (capture, _, _) -> capture) diagnostic in
  let joined_ctx =
    collapse_ctx_no_markers_following_sequence span ?diagnostic:replay_diagnostic ~loop merge_seq
      add_borrows_seq ~with_abs_conts:true fresh_abs_kind joined_ctx
  in
  [%ltrace
    "After collapsing the context: joined_ctx:\n"
    ^ eval_ctx_to_string joined_ctx];

  let diagnostic_replay_result = match diagnostic with None -> None | Some _ -> Some joined_ctx in
  (* There may be empty abstractions in the projected context: end them.

     Remark: we forbid the introduction of (meta) snapshots, because they may
     refer to values which are introduced as, for instance, output of a loop
     and are not bound yet (this may lead to issues). *)
  let joined_ctx, cc =
    comp cc
      (simplify_dummy_values_useless_abs config span ~snapshots:false joined_ctx)
  in
  [%ltrace
    "After applying [simplify_dummy_values_useless_abs] to the joined context: \
     joined_ctx:\n"
    ^ eval_ctx_to_string joined_ctx];

  let joined_ctx = normalize_private_shared_regions span joined_ctx in
  (*
```ocaml
  *)
  let diagnose_boundary phase (current : eval_ctx) =
    let log = Logging.carrier_events_log in
    if Logging.L.Debug >= log#effective_level then
      try
        (* 
```ocaml
*)
        let rendered_owners = ref AbsId.Map.empty in
        let render_owner ~retain (abs : abs) =
          match AbsId.Map.find_opt abs.abs_id !rendered_owners with
          | Some (previous, rendered) when previous == abs -> rendered
          | _ ->
              let rendered = render_diagnostic_owner ~retain:false abs in
              let () = if retain then
                rendered_owners := AbsId.Map.add abs.abs_id (abs, rendered) !rendered_owners
              in
              rendered
        in
        let () =
          diagnose_source_slot_state ~render_owner span phase join_info.symbolic_to_value
            src_ctx current
        in
        let count = ref 0 in
        let () =
          List.iteri
            (fun index element ->
              match element with
              | EAbs abs ->
                  let () = incr count in
                  if !count <= 128 then
                    [%ldebug
                      let raw_owner, call_scopes = render_owner ~retain:false abs in
                      "Carrier owned-region boundary owner event:"
                      ^ "\nphase: " ^ phase
                      ^ "\nsource span: " ^ Errors.span_to_string span
                      ^ "\nenvironment index: " ^ string_of_int index
                      ^ "\nraw owner: " ^ raw_owner
                      ^ "\npending scopes: " ^ call_scopes]
(* 
```
*)
              | EBinding _ | EFrame -> ())
            current.env
        in
        [%ldebug
          "Carrier owned-region boundary coverage:"
          ^ "\nphase: " ^ phase
          ^ "\nowner count: " ^ string_of_int !count
          ^ "\nowner inventory complete: " ^ string_of_bool (!count <= 128)]
      with error ->
        (try
           [%ldebug
             "Carrier owned-region boundary analysis unavailable:"
             ^ "\nphase: " ^ phase
             ^ "\nanalysis exception: " ^ Printexc.to_string error]
         with _ -> ())
  in
  (*
```
  *)
  let () =
    diagnose_boundary "match_ctx_with_target: before owned-region reduction"
      joined_ctx
  in
  let joined_ctx =
    ctx_drop_carrierless_owned_regions fixed_aids joined_ctx
  in
  let () =
    diagnose_boundary "match_ctx_with_target: after owned-region reduction"
      joined_ctx
  in

  (* Reorder the region abstractions in the target context -
     TODO: generalize the match so that we don't have to do this *)
  let joined_ctx = reorder_fresh_abs span true fixed_aids joined_ctx in
  let joined_ctx =
    restore_source_slots span join_info.symbolic_to_value
      join_info.symbolic_to_value_metadata src_ctx joined_ctx
  in
  [%ltrace
    "After reorder_fresh_abs (fixed_aids: "
    ^ AbsId.Set.to_string None fixed_aids
    ^ "): joined_ctx:\n"
    ^ eval_ctx_to_string ~span:(Some span) joined_ctx];

  [%ltrace
    "About to match:" ^ "\n- src_ctx:\n" ^ eval_ctx_to_string src_ctx
    ^ "\n- joined_ctx:\n"
    ^ eval_ctx_to_string joined_ctx];

  (* Check that the source context (i.e., the fixed-point context) matches
     the resulting target context. *)
  let src_to_joined_maps =
    let open InterpBorrowsCore in
    let lookup_shared_loan lid ctx : tvalue =
      match snd (ctx_lookup_loan span ek_all lid ctx) with
      | Concrete (VSharedLoan (_, v)) -> v
      | Abstract (ASharedLoan (pm, _, v, _)) ->
          [%sanity_check] span (pm = PNone);
          v
      | _ -> [%craise] span "Unreachable"
    in
    let lookup_in_src id = lookup_shared_loan id src_ctx in
    let lookup_in_joined id = lookup_shared_loan id joined_ctx in
    (* Match *)
    let fixed_ids =
      { empty_ids_sets with aids = ctx_get_frozen_abs_set src_ctx }
    in

    match
      try_match_ctxs span ~check_equiv:false ~check_kind:false
        ~check_can_end:false ?selected_pair fixed_ids lookup_in_src lookup_in_joined src_ctx
        joined_ctx
    with
    | Some maps -> maps
    | None ->
        (match diagnostic with
        | None -> ()
        | Some (capture, source_ids, pair) ->
          (try
            let original_joined_ctx, unprojected_ctx, projected_input_ctx, replay_result_ctx =
              match diagnostic_original_joined, diagnostic_unprojected,
                    diagnostic_projected, diagnostic_replay_result with
              | Some original, Some collapsed, Some projected, Some replayed ->
                  (original, collapsed, projected, replayed)
              | _ -> raise Not_found
            in
            let exception Limit in
            let output = Buffer.create 4096 in
            let omitted = ref 0 in
            let critical_complete = ref false in
            let actual_pair_complete = ref false in
            let recorded_pair_complete = ref false in
            let emit text =
              if String.length text > 261888 - Buffer.length output then raise Limit;
              Buffer.add_string output text
            in
            let integer name value = emit (name ^ "=" ^ string_of_int value ^ "\n") in
            let owner_id name id = emit (name ^ "=" ^ AbsId.to_string id ^ "\n") in
            let text name value =
              integer (name ^ "-bytes") (String.length value);
              emit (name ^ "=" ^ value ^ "\n")
            in
            let regions name ids =
              integer (name ^ "-count") (RegionId.Set.cardinal ids);
              emit (name ^ "={"); RegionId.Set.iter
                (fun id -> emit (RegionId.to_string id ^ ",")) ids; emit "}\n"
            in
            let owners name ids =
              integer (name ^ "-count") (AbsId.Set.cardinal ids);
              emit (name ^ "={"); AbsId.Set.iter
                (fun id -> emit (AbsId.to_string id ^ ",")) ids; emit "}\n"
            in
            let formatted label printer value =
              emit (label ^ ":\n");
              let written = ref 0 in
              let write value start count =
                if count > 261888 - Buffer.length output then raise Limit;
                written := !written + count;
                Buffer.add_substring output value start count
              in
              let formatter = Format.make_formatter write (fun () -> ()) in
              printer formatter value;
              Format.pp_print_flush formatter ();
              emit "\n"
            in
            let raw_type label ty = formatted label Types.pp_ty ty in
            let witness_fields label (witnesses : call_endpoint_witnesses) =
              emit (label ^ "-endpoint-witnesses:\n");
              List.iter (fun (from_input, original, actual) ->
                text "endpoint-root-side" (if from_input then "input" else "return");
                formatted "endpoint-original-root" Values.pp_tavalue original;
                formatted "endpoint-actual-root" Values.pp_tavalue actual) witnesses.roots;
              List.iter (fun (symbol, expansion) ->
                formatted "endpoint-expansion-symbol" Values.pp_symbolic_value symbol;
                formatted "endpoint-expansion" Values.pp_symbolic_expansion expansion) witnesses.expansions;
              List.iter (fun (projector, mask, actual) ->
                formatted "endpoint-witness-projector" Values.pp_symbolic_proj projector;
                regions "endpoint-witness-mask" mask;
                formatted "endpoint-witness-actual" Values.pp_tavalue actual) witnesses.projections;
              List.iter (formatted "endpoint-carrier-origin" Values.pp_carrier_origin) witnesses.carrier_origins;
              List.iter (fun correspondence ->
                formatted "endpoint-input-correspondence" Values.pp_call_input_correspondence correspondence;
                List.iter (formatted "endpoint-input-source-path" Values.pp_value_path_step)
                  correspondence.input_source_path;
                List.iter (formatted "endpoint-input-path" Values.pp_value_path_step)
                  correspondence.input_path) witnesses.input_correspondences;
              List.iter (formatted "endpoint-carrier-conversion" Values.pp_input_carrier_conversion)
                witnesses.carrier_conversions;
              List.iter (formatted "endpoint-physical-return" Values.pp_input_physical_return)
                witnesses.physical_returns;
              List.iter (formatted "endpoint-return-route" Values.pp_input_return_route)
                witnesses.return_routes;
              List.iter (fun (marker, borrow, ty, mask, expression) ->
                formatted "endpoint-parent-marker" Values.pp_proj_marker marker;
                emit ("endpoint-parent-borrow=" ^ BorrowId.to_string borrow ^ "\n");
                raw_type "endpoint-parent-type" ty;
                regions "endpoint-parent-mask" mask;
                formatted "endpoint-parent-expression" Values.pp_tevalue expression) witnesses.parent_carriers
            in
            let raw_contents label (abs : abs) =
              text "owner-image" label;
              owner_id "owner" abs.abs_id;
              formatted "kind" Values.pp_abs_kind abs.kind;
              regions "owned" abs.regions.owned;
              owners "parents" abs.parents;
              text "can-end" (string_of_bool abs.can_end);
              formatted "ended-subabs" AbsLevelSet.pp abs.ended_subabs;
              integer "current-avalue-count" (List.length abs.avalues);
              List.iteri (fun index value ->
                integer "current-avalue-index" index;
                formatted "current-avalue" Values.pp_tavalue value) abs.avalues
            in
            let raw_continuation label (abs : abs) =
              text "continuation-owner-image" label;
              owner_id "continuation-owner" abs.abs_id;
              (match abs.cont with
              | None -> emit "complete-continuation=absent\n"
              | Some cont -> formatted "complete-continuation" Values.pp_abs_cont cont);
              integer "pending-scope-count" (List.length abs.call_scopes);
(*
```ocaml
*)
              List.iter (fun scope ->
                (match scope with
                | PendingParameterScope scope ->
                    formatted "pending-slot" Values.pp_symbolic_pending_slot scope.slot;
                    List.iter (fun (from_input, path) ->
                      text "pending-position-side" (if from_input then "input" else "return");
                      List.iter (fun position ->
                        text "pending-position" (string_of_bool position)) path)
                      scope.positions
                | PhysicalInputScope scope ->
                    formatted "physical-input-slot" Values.pp_physical_input_slot scope.physical_slot);
                witness_fields "scope" (ValuesUtils.call_scope_witnesses scope)) abs.call_scopes;
(*
```
*)
              let path = ref [] and next_child = ref 0 and projector_ordinal = ref 0 in
              let visitor = object (self)
                inherit [_] iter_tavalue as super
                method! visit_ty _ _ = ()
                method! visit_symbolic_proj owned projector =
                  integer "live-projector-ordinal" !projector_ordinal;
                  incr projector_ordinal;
                  emit ("live-projector-occurrence-path=" ^ String.concat "."
                    (List.map string_of_int (List.rev !path)) ^ "\n");
                  emit ("live-projector-symbol=" ^ SymbolicValueId.to_string projector.sv_id ^ "\n");
                  regions "live-effective-projector-scope" owned
                method! visit_esymbolic_proj owned projector =
                  integer "live-eprojector-ordinal" !projector_ordinal;
                  incr projector_ordinal;
                  emit ("live-eprojector-occurrence-path=" ^ String.concat "."
                    (List.map string_of_int (List.rev !path)) ^ "\n");
                  emit ("live-eprojector-symbol=" ^ SymbolicValueId.to_string projector.sv_id ^ "\n");
                  regions "live-effective-eprojector-scope" owned
                method! visit_proj_marker _ marker =
                  formatted "live-marker" Values.pp_proj_marker marker
                method! visit_carrier_coordinate_transport _ transport =
                  formatted "transport-receiver" Values.pp_symbolic_proj transport.receiver;
                  regions "transport-receiver-mask" transport.receiver_regions;
                  formatted "transport-current" Values.pp_symbolic_value transport.current;
                  regions "transport-current-mask" transport.current_regions;
                  (match transport.return_source with
                  | SymbolicCarrierReturn route -> formatted "transport-symbolic-return" Values.pp_input_return_route route
                  | PhysicalCarrierReturn returns -> List.iter
                      (formatted "transport-physical-return" Values.pp_input_physical_return) returns)
                method! visit_call_endpoint_witnesses _ witnesses =
                  witness_fields "continuation" witnesses
                method! visit_ATransportedProj _ transport child =
                  self#visit_carrier_coordinate_transport transport.current_regions transport;
                  self#visit_aproj transport.current_regions child
                method! visit_ATransportedValue _ transport child =
                  self#visit_carrier_coordinate_transport transport.current_regions transport;
                  self#visit_tavalue transport.current_regions child
                method! visit_ETransportedProj _ transport child =
                  self#visit_carrier_coordinate_transport transport.current_regions transport;
                  self#visit_eproj transport.current_regions child
                method! visit_ETransportedValue _ transport child =
                  self#visit_carrier_coordinate_transport transport.current_regions transport;
                  self#visit_tevalue transport.current_regions child
                method! visit_ELet owned local_regions pattern producer next =
                  self#visit_tepat local_regions pattern;
                  self#visit_tevalue local_regions producer;
                  self#visit_tevalue owned next
                method! visit_EValue _ _ _ = ()
                method! visit_tavalue owned value =
                  let parent = !path and sibling = !next_child in
                  path := sibling :: parent;
                  next_child := 0;
                  super#visit_tavalue owned value;
                  path := parent;
                  next_child := sibling + 1
                method! visit_tevalue owned value =
                  let parent = !path and sibling = !next_child in
                  path := sibling :: parent;
                  next_child := 0;
                  super#visit_tevalue owned value;
                  path := parent;
                  next_child := sibling + 1
              end in
              List.iter (visitor#visit_tavalue abs.regions.owned) abs.avalues;
              Option.iter (visitor#visit_abs_cont abs.regions.owned) abs.cont
            in
            let raw_owner label (abs : abs) =
              raw_contents label abs;
              raw_continuation label abs
            in
            let native = capture.replay_native in
            let merges = Array.fold_left (fun rows -> function
                | Some entry -> entry :: rows | None -> rows) [] native.trace_records
              |> List.sort (fun left right -> Int.compare right.merge_index left.merge_index)
            in
            let steps = Array.fold_left (fun rows -> function
                | Some entry -> entry :: rows | None -> rows) [] capture.replay_records
              |> List.sort (fun left right -> Int.compare right.replay_index left.replay_index)
            in
            (try
              emit "role=failed-target-owner-producer-lineage\n";
              text "source-span" (Errors.span_to_string span);
              emit "attribution=selected-rejected-trial-not-a-unique-terminal-cause\n";
              integer "native-merge-count" native.trace_count;
              integer "native-merge-retention-omitted" (Stdlib.max 0 (native.trace_count - 128));
              integer "replay-step-count" capture.replay_count;
              integer "replay-step-retention-omitted" (Stdlib.max 0 (capture.replay_count - 128));
              integer "normalization-callback-unavailable" native.trace_callback_unavailable;
              owners "projection-fixed" fixed_aids;
              owners "collapse-preserved" join_info.fixed_abs_ids;
              owners "collapse-untouched" join_info.fixed_abs_ids;
              owners "matcher-fixed" fixed_ids.aids;
              owners "projected-input-frozen" (ctx_get_frozen_abs_set projected_input_ctx);
              match !pair with
              | None -> emit "selected-owner-pair-unavailable\n"
              | Some (source, current) ->
                owner_id "selected-source-owner" source.abs_id;
                owner_id "selected-current-owner" current.abs_id;
                let actual_ids = ref (AbsId.Set.singleton current.abs_id) in
                List.iter (fun entry ->
                    if entry.merge_phase <> "unprojected"
                       && AbsId.Set.mem entry.merge_result !actual_ids then
                      actual_ids := AbsId.Set.add entry.merge_left.abs_id
                          (AbsId.Set.add entry.merge_right.abs_id !actual_ids)) merges;
                let recorded_ids = ref AbsId.Set.empty in
                (match ctx_lookup_abs_opt projected_input_ctx current.abs_id with
                | None -> () | Some _ -> recorded_ids := AbsId.Set.singleton current.abs_id);
                List.iter (fun entry ->
                    let left, right, recorded = entry.replay_recorded in
                    let actual_result_in_lineage = match entry.replay_result with
                      | None -> false
                      | Some result -> AbsId.Set.mem result !actual_ids in
                    if AbsId.Set.mem recorded !recorded_ids || actual_result_in_lineage then
                      recorded_ids := AbsId.Set.add_list [left; right; recorded] !recorded_ids) steps;
                List.iter (fun entry ->
                    if entry.merge_phase = "unprojected"
                       && AbsId.Set.mem entry.merge_result !recorded_ids then
                      recorded_ids := AbsId.Set.add entry.merge_left.abs_id
                          (AbsId.Set.add entry.merge_right.abs_id !recorded_ids)) merges;
                let relevant entry =
                  if entry.merge_phase = "unprojected" then
                    AbsId.Set.mem entry.merge_result !recorded_ids
                  else AbsId.Set.mem entry.merge_result !actual_ids
                in
                let coordinates label before after map =
                  text "isolation-side" label;
                  integer "native-isolation-coordinate-count" (RegionId.Map.cardinal map);
                  let count = ref 0 in
                  RegionId.Map.iter (fun original isolated ->
                      incr count;
                      if !count > 128 then incr omitted
                      else (
                        emit ("raw-original-region=" ^ RegionId.to_string original ^ "\n");
                        emit ("raw-isolated-region=" ^ RegionId.to_string isolated ^ "\n");
                        let binding label ctx key = match RegionId.Map.find_opt key ctx.metadata_bindings with
                          | None -> text label "absent"
                          | Some MetadataFresh -> text label "MetadataFresh"
                          | Some (MetadataSource source) -> formatted label Types.pp_region source in
                        binding "original-binding-before-isolation" before original;
                        binding "isolated-binding-after-isolation" after isolated)) map
                in
                let target = List.find_opt (fun entry ->
                    entry.merge_phase = "target-reduction" && relevant entry) merges in
                let replay_focus = List.fold_left (fun selected step ->
                    match step.replay_case, step.replay_result with
                    | "merge", Some result when AbsId.Set.mem result !actual_ids ->
                        let matches = List.filter (fun entry ->
                            entry.merge_phase = "replay-merge"
                            && entry.merge_step = step.replay_index
                            && entry.merge_left.abs_id = step.replay_normalized_left
                            && entry.merge_right.abs_id = step.replay_normalized_right
                            && entry.merge_result = result) merges in
                        (match matches with
                        | [entry] ->
                            (match selected with
                            | Some (prior, _) when prior.replay_index <= step.replay_index -> selected
                            | _ -> Some (step, entry))
                        | _ ->
                            integer "unassociated-actual-replay-step" step.replay_index;
                            text "actual-native-association"
                              (if matches = [] then "missing" else "ambiguous");
                            selected)
                    | _ -> selected) None steps in
                let recorded_focus = match replay_focus with
                  | None -> None
                  | Some (step, _) ->
                      let left, right, result = step.replay_recorded in
                      integer "primary-replay-step" step.replay_index;
                      owner_id "primary-recorded-left" left;
                      owner_id "primary-recorded-right" right;
                      owner_id "primary-recorded-result" result;
                      let matches = List.filter (fun entry ->
                          entry.merge_phase = "unprojected"
                          && entry.merge_left.abs_id = left
                          && entry.merge_right.abs_id = right
                          && entry.merge_result = result) merges in
                      (match matches with
                      | [entry] -> emit "recorded-native-association=unique\n"; Some entry
                      | _ ->
                          text "recorded-native-association"
                            (if matches = [] then "missing" else "ambiguous");
                          None)
                in
                let critical = match replay_focus with
                  | Some (_, entry) -> Some entry
                  | None -> target in
                let selection entry =
                  integer "native-merge-index" entry.merge_index;
                  text "native-merge-phase" entry.merge_phase;
                  integer "native-replay-step" entry.merge_step;
                  owner_id "native-left" entry.merge_left.abs_id;
                  owner_id "native-right" entry.merge_right.abs_id;
                  owner_id "native-result" entry.merge_result;
                  (match entry.merge_selection with
                  | None -> emit "reduction-selection=unavailable\n"
                  | Some (family, edge, guards) ->
                      text "reduction-policy-family" family;
                      formatted "selected-reduction-edge" (fun formatter edge -> edge formatter) edge;
                      List.iter (fun name ->
                        text ("actual-guard-" ^ name)
                          (match List.assoc_opt name guards with None -> "skipped"
                           | Some verdict -> string_of_bool verdict))
                        ["with-markers"; "distinct-owner"; "can-reduce-borrow";
                         "no-forward-payload-capture"; "marked-edge";
                         "no-backward-payload-capture"; "no-deferred-level-output";
                         "no-variable-borrow-end"; "capture-forward";
                         "capture-backward"; "deferred-level-output"; "variable-borrow-end"])
                in
                let header label entry =
                  text "focused-native-role" label;
                  selection entry;
                  (match entry.merge_fixed with None -> emit "native-fixed-set=not-a-replay-guard\n"
                  | Some ids -> owners "native-fixed" ids);
                  owners "native-preserved" entry.merge_preserved;
                  coordinates "left" entry.merge_before entry.merge_after entry.merge_left_coordinates;
                  coordinates "right" entry.merge_before entry.merge_after entry.merge_right_coordinates
                in
                (match replay_focus with
                | None -> emit "primary-actual-replay-pair=unavailable\n"
                | Some (step, _) ->
                    owner_id "primary-normalized-left" step.replay_normalized_left;
                    owner_id "primary-normalized-right" step.replay_normalized_right;
                    Option.iter (owner_id "primary-actual-result") step.replay_result;
                    integer "primary-normalization-native-begin" step.replay_normalization_begin;
                    integer "primary-normalization-native-end" step.replay_normalization_end);
                Option.iter (header (if Option.is_some replay_focus then "actual-replay" else "target-reduction-fallback")) critical;
                Option.iter (header "recorded-predecessor") recorded_focus;
                let immediate_contents label entry =
                  raw_contents (label ^ "-immediate-left") entry.merge_left;
                  raw_contents (label ^ "-immediate-right") entry.merge_right
                in
                let immediate_continuations label entry =
                  raw_continuation (label ^ "-immediate-left") entry.merge_left;
                  raw_continuation (label ^ "-immediate-right") entry.merge_right
                in
                let immediate label entry =
                  immediate_contents label entry;
                  immediate_continuations label entry
                in
                Option.iter (immediate_contents "critical") critical;
                Option.iter (immediate_contents "recorded-predecessor") recorded_focus;
                (match critical with
                | None -> emit "critical-target-reduction-pair=unavailable\n"
                | Some entry ->
                    immediate_continuations "critical" entry;
                    critical_complete := true;
                    if Option.is_some replay_focus then actual_pair_complete := true;
                    emit "critical-pair-immediate-complete=true\n");
                (match recorded_focus with
                | None -> ()
                | Some entry ->
                    immediate_continuations "recorded-predecessor" entry;
                    recorded_pair_complete := true);
                let remaining_images entry =
                  raw_owner "native-isolated-left" entry.merge_isolated_left;
                  raw_owner "native-isolated-right" entry.merge_isolated_right;
                  match ctx_lookup_abs_opt entry.merge_after entry.merge_result with
                  | None -> emit "native-result-image=absent\n"
                  | Some abs -> raw_owner "native-result" abs
                in
                Option.iter remaining_images critical;
                Option.iter remaining_images recorded_focus;
                let focused entry =
                  List.exists (Option.fold ~none:false
                      ~some:(fun focus -> focus.merge_index = entry.merge_index))
                    [critical; recorded_focus]
                in
                let source_owners = ref (AbsId.Set.singleton source.abs_id) in
                AbsId.Map.iter (fun original refreshed ->
                    if AbsId.Set.mem refreshed !recorded_ids then (
                      source_owners := AbsId.Set.add original !source_owners;
                      owner_id "source-owner" original;
                      owner_id "refreshed-source-owner" refreshed)) !source_ids;
                owners "actual-lineage" !actual_ids;
                owners "recorded-lineage" !recorded_ids;
                List.iteri (fun index (left, right, result) ->
                    if AbsId.Set.mem result !recorded_ids then (
                      integer "original-sequence-step" index;
                      owner_id "recorded-left" left; owner_id "recorded-right" right;
                      owner_id "recorded-result" result)) merge_seq;
                List.iter (fun entry ->
                    let _, _, recorded_result = entry.replay_recorded in
                    let actual_result_in_lineage = match entry.replay_result with
                      | None -> false
                      | Some result -> AbsId.Set.mem result !actual_ids in
                    if AbsId.Set.mem recorded_result !recorded_ids || actual_result_in_lineage then (
                        integer "replay-step" entry.replay_index;
                        let left, right, recorded = entry.replay_recorded in
                        owner_id "recorded-left" left; owner_id "recorded-right" right;
                        owner_id "recorded-result" recorded;
                        owner_id "get-id-left-before-normalization" entry.replay_resolved_left;
                        owner_id "get-id-right-before-normalization" entry.replay_resolved_right;
                        owner_id "normalization-output-left" entry.replay_normalized_left;
                        owner_id "normalization-output-right" entry.replay_normalized_right;
                        integer "normalization-native-begin" entry.replay_normalization_begin;
                        integer "normalization-native-end" entry.replay_normalization_end;
                        text "selected-replay-case" entry.replay_case;
                        owner_id "result-association-recorded" recorded;
                        (match entry.replay_result with
                        | None -> text "result-association-actual" "absent"
                        | Some result -> owner_id "result-association-actual" result);
                        let association label id map = match AbsId.Map.find_opt id map with
                          | None -> text label "absent"
                          | Some value -> owner_id label value in
                        association "left-association-before" left entry.replay_map_before;
                        association "right-association-before" right entry.replay_map_before;
                        association "result-association-after" recorded entry.replay_map_after
                    )) (List.rev steps);
                List.iter (fun entry ->
                    let relevant = if entry.merge_phase = "unprojected" then
                        AbsId.Set.mem entry.merge_result !recorded_ids
                      else AbsId.Set.mem entry.merge_result !actual_ids in
                    if relevant then (
                      integer "native-merge-index" entry.merge_index;
                      text "native-merge-phase" entry.merge_phase;
                      integer "native-replay-step" entry.merge_step;
                      owner_id "native-left" entry.merge_left.abs_id;
                      owner_id "native-right" entry.merge_right.abs_id;
                      owner_id "native-result" entry.merge_result;
                      (match entry.merge_fixed with None -> emit "native-fixed-set=not-a-replay-guard\n"
                      | Some ids -> owners "native-fixed" ids);
                      owners "native-preserved" entry.merge_preserved;
                      (match entry.merge_normalization_callback with
                      | None -> ()
                      | Some (holder, owner, result) ->
                          owner_id "normalization-callback-holder" holder;
                          owner_id "normalization-callback-transferred-owner" owner;
                          owner_id "normalization-callback-result" result);
                      coordinates "left" entry.merge_before entry.merge_after entry.merge_left_coordinates;
                      coordinates "right" entry.merge_before entry.merge_after entry.merge_right_coordinates;
                      ()) ) merges;
                List.iter (fun entry ->
                    if relevant entry && not (focused entry) then (
                      selection entry;
                      immediate "native" entry;
                      remaining_images entry))
                  (List.stable_sort (fun left right ->
                    Bool.compare (left.merge_phase <> "target-reduction")
                      (right.merge_phase <> "target-reduction")) (List.filter relevant merges));
                raw_owner "selected-source" source;
                raw_owner "selected-current" current;
                let image label ids ctx = AbsId.Set.iter (fun id ->
                    match ctx_lookup_abs_opt ctx id with
                    | None -> () | Some abs -> raw_owner label abs) ids in
                image "original-source" !source_owners src_ctx;
                image "original-pre-collapse-joined" !recorded_ids original_joined_ctx;
                image "collapsed-unprojected" !recorded_ids unprojected_ctx;
                image "projected-input" !actual_ids projected_input_ctx;
                image "replay-result" !actual_ids replay_result_ctx
             with Limit -> incr omitted
                | _ -> incr omitted; (try emit "optional-producer-analysis-unavailable\n" with _ -> ()));
            Buffer.add_string output ("report-budget-bytes=262144\ncritical-pair-complete="
                ^ string_of_bool !critical_complete
                ^ "\nactual-replay-pair-complete=" ^ string_of_bool !actual_pair_complete
                ^ "\nrecorded-predecessor-pair-complete=" ^ string_of_bool !recorded_pair_complete
                ^ "\nomitted-sections="
                ^ string_of_int !omitted ^ "\n");
            (try Printf.eprintf "Failed target owner producer lineage:\n%s%!" (Buffer.contents output) with _ -> ())
           with _ -> (try Printf.eprintf "Failed target owner producer lineage unavailable.\n%!" with _ -> ())));
        [%craise] span
          ("Could not match the contexts\nSource context:\n"
          ^ eval_ctx_to_string ~span:(Some span) ~filter:false src_ctx
          ^ "\nJoined context:\n"
          ^ eval_ctx_to_string ~span:(Some span) ~filter:false joined_ctx)
  in
  [%ltrace
    "The match was successful:" ^ "\n\n- src_ctx: "
    ^ eval_ctx_to_string ~span:(Some span) src_ctx
    ^ "\n\n- joined_ctx: "
    ^ eval_ctx_to_string ~span:(Some span) joined_ctx
    ^ "\n\n- src_to_joined_maps: "
    ^ ids_maps_to_string joined_ctx src_to_joined_maps];

  (* Sanity check *)
  if !Config.sanity_checks then
    Invariants.check_borrowed_values_invariant span joined_ctx;

  (* Compute the loop input values and abstractions *)
  [%ltrace
    "About to compute the input values and abstractions:"
    ^ "\n- fp_input_svalues: "
    ^ String.concat ", " (List.map SymbolicValueId.to_string input_svalues)
    ^ "\n- src_to_joined_maps:\n"
    ^ ids_maps_to_string joined_ctx src_to_joined_maps
    ^ "\n- joined_symbolic_to_tgt_value: "
    ^ SymbolicValueId.Map.to_string (Some "  ") (tvalue_to_string src_ctx)
        joined_symbolic_to_tgt_value
    ^ "\n- src_ctx:\n" ^ eval_ctx_to_string src_ctx ^ "\n- joined_ctx:\n"
    ^ eval_ctx_to_string joined_ctx];
  (* Retained payloads can be joined before their referring borrows. A later
     joined symbol may therefore instantiate to another symbol generated by
     this same join, rather than directly to a value in the target branch.
     Compose those instantiations before emitting the branch inputs: these
     intermediate symbols have ownership, but no branch-local let binding. *)
  let resolved_values = ref SymbolicValueId.Map.empty in
  let subst =
    object (self)
      inherit [_] map_tvalue

      method! visit_VSymbolic visiting sv =
        match SymbolicValueId.Map.find_opt sv.sv_id !resolved_values with
        | Some value -> value
        | None -> (
            match
              SymbolicValueId.Map.find_opt sv.sv_id joined_symbolic_to_tgt_value
            with
            | None -> VSymbolic sv
            | Some v ->
                let value =
                  match v.value with
                  | VSymbolic target when target.sv_id = sv.sv_id ->
                      VSymbolic target
                  | _ ->
                      [%cassert] span
                        (not (SymbolicValueId.Set.mem sv.sv_id visiting))
                        "Cyclic symbolic instantiation while emitting join \
                         inputs";
                      self#visit_value
                        (SymbolicValueId.Set.add sv.sv_id visiting)
                        v.value
                in
                resolved_values :=
                  SymbolicValueId.Map.add sv.sv_id value !resolved_values;
                value)
    end
  in
  let input_values =
    SymbolicValueId.Map.of_list
      (List.map
         (fun sid ->
           (* We retrieve the value in two steps:
              - source to joined
              - joined to target
              Note that joined to target is a partial map: it only maps
              symbolic values appearing in the joined context, and in
              particular appearing in the joined values (not in the region
              abstractions). For all the missing symbolic values, the
              substitution should be the identity.
           *)
           let v =
             match
               SymbolicValueId.Map.find_opt sid
                 src_to_joined_maps.sid_to_value_map
             with
             | Some v -> v
             | None ->
                 [%craise] span
                   ("Could not find symbolic value @"
                   ^ SymbolicValueId.to_string sid
                   ^ " in src_to_joined_map")
           in
           let v = subst#visit_tvalue SymbolicValueId.Set.empty v in
           (sid, v))
         input_svalues)
  in
  let input_abs =
    let aid_map =
      AbsId.Map.of_list (AbsId.InjSubst.bindings src_to_joined_maps.aid_map)
    in
    AbsId.Map.of_list
      (List.map
         (fun input_aid ->
           match AbsId.Map.find_opt input_aid aid_map with
           | None -> [%internal_error] span
           | Some joined_id -> (input_aid, ctx_lookup_abs joined_ctx joined_id))
         input_abs)
  in
  (*
```ocaml
  *)
  let producer_ids = ref SymbolicValueId.Set.empty in
  let collect =
    object
      inherit [_] iter_abs
      method! visit_symbolic_value_id _ id =
        if SymbolicValueId.Map.mem id joined_symbolic_to_tgt_value then
          producer_ids := SymbolicValueId.Set.add id !producer_ids
    end
  in
  AbsId.Map.iter (fun _ abs -> collect#visit_abs () abs) input_abs;
  let _, ids = compute_ctx_ids joined_ctx in
  let producers =
    List.map
      (fun id ->
        let symbolic = SymbolicValueId.Map.find id ids.sids_to_values in
        let value = SymbolicValueId.Map.find id joined_symbolic_to_tgt_value in
        (symbolic, subst#visit_tvalue SymbolicValueId.Set.empty value))
      (SymbolicValueId.Set.elements !producer_ids)
  in
  let input_values =
    SymbolicValueId.Map.mapi
      (fun id value ->
        match SymbolicValueId.Map.find_opt id src_to_joined_maps.sid_to_value_map with
        | Some { value = VSymbolic symbolic; _ }
          when SymbolicValueId.Set.mem symbolic.sv_id !producer_ids ->
            mk_tvalue_from_symbolic_value joined_ctx.type_ctx.type_infos
              joined_ctx.metadata_bindings symbolic
        | _ -> value)
      input_values
  in
  let cc =
    let producer_ctx = SynthesizeSymbolic.capture_context tgt_ctx in
    fun next ->
      cc (List.fold_right
        (fun (symbolic, value) next ->
          SymbolicAst.IntroSymbolic
            (producer_ctx, None, symbolic, VaSingleValue value, next))
        producers next)
  in
  (*
```
  *)

  [%ltrace
    "Input values:\n"
    ^ SymbolicValueId.Map.to_string (Some "  ")
        (tvalue_to_string ~span:(Some span) src_ctx)
        input_values
    ^ "\nInput abs:\n"
    ^ AbsId.Map.to_string (Some "  ") (abs_to_string span src_ctx) input_abs];

  (* *)
  Invariants.check_invariants span joined_ctx;

  (* We continue with the *fixed-point* context *)
  ((src_ctx, tgt_ctx, input_values, input_abs), cc)

let loop_match_break_ctx_with_target (config : config) (span : Meta.span)
    (_loop_id : LoopId.id) (fixed_aids : AbsId.Set.t)
    (fixed_dids : DummyVarId.Set.t) (fp_input_abs : abs_id list)
    (fp_input_svalues : SymbolicValueId.id list) (src_ctx : eval_ctx)
    (tgt_ctx : eval_ctx) :
    (eval_ctx * eval_ctx * tvalue SymbolicValueId.Map.t * abs AbsId.Map.t)
    * (SymbolicAst.expr -> SymbolicAst.expr) =
  (* Debug *)
  [%ltrace
    "- src_ctx:\n" ^ eval_ctx_to_string src_ctx ^ "\n- tgt_ctx:\n"
    ^ eval_ctx_to_string tgt_ctx];

  match_ctx_with_target config span ~loop:true WithCont fixed_aids fixed_dids
    fp_input_abs fp_input_svalues ~recoverable:false src_ctx tgt_ctx
