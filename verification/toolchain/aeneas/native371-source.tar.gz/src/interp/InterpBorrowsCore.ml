(** This file defines the basic blocks to implement the semantics of borrows.
    Note that those functions are not only used in InterpBorrows, but also in
    Invariants or InterpProjectors *)

open Types
open Values
open Contexts
open Utils
open TypesUtils
open InterpUtils

(** The local logger *)
let log = Logging.borrows_log
(* ```ocaml *)
let check_function_input_interface span ctx
    (witnesses : call_endpoint_witnesses) (origin : carrier_origin)
    (canonical : abs) =
  match origin.source_role with
  | OrdinaryCallOutputOrigin _ -> [%internal_error] span
  | FunctionInputOrigin input_index ->
      [%cassert] span
        (canonical.abs_id = origin.source_owner
         && canonical.kind = SynthInput origin.region_group
         && RegionId.Set.equal origin.original_mask
              (RegionId.Set.inter canonical.regions.owned
                 (ty_regions ctx.type_ctx.type_infos origin.original_root.sv_ty)))
        "A function input changes its canonical declaration owner";
      let declared =
        Option.fold ~none:false
          ~some:(fun (value : tavalue) ->
            value.ty = origin.original_root.sv_ty
            && match value.value with
               | ASymbolic (PNone, AProjLoans { proj; _ }) ->
                   proj.sv_id = origin.original_root.sv_id
                   && proj.proj_ty = origin.original_root.sv_ty
               | ASymbolic (PNone, AEndedProjLoans { proj; _ }) ->
                   proj = origin.original_root.sv_id
               | _ -> false)
          (List.nth_opt canonical.avalues input_index) in
      [%cassert] span declared
        "A function input changes its declared input position";
      let body_ty = origin.transport_root.sv_ty in
      let roots_match from_input root =
        (* Count declaration identities, not their different actual histories.
           The exactly-one check only needs zero, one, or multiple declarations. *)
        let rec scan found declared = function
          | [] -> if found then 1 else 0
          | (side, (original : tavalue), _) :: rest ->
              if side = from_input && original.ty = body_ty
                 && (match from_input, original.value with
                     | true, ASymbolic (_, AProjBorrows { proj; _ })
                     | false, ASymbolic (_, AProjLoans { proj; _ }) ->
                         proj.sv_id = root && proj.proj_ty = body_ty
                     | _ -> false)
              then
                if found && original <> declared then 2
                else scan true original rest
              else scan found declared rest in
        match witnesses.roots with
        | [] -> 0
        | (_, declared, _) :: _ -> scan false declared witnesses.roots in
      [%cassert] span
        (roots_match true origin.original_root.sv_id = 1
         && roots_match false origin.transport_root.sv_id = 1)
        "A function input lacks its unique declared body interface"
(* ``` *)

(** TODO: cleanup this a bit, once we have a better understanding about what we
    need. TODO: I'm not sure in which file this should be moved... *)
type exploration_kind = {
  enter_shared_loans : bool;
  enter_mut_borrows : bool;
  enter_abs : bool;
      (** Note that if we allow to enter abs, we don't check whether we enter
          mutable/shared loans or borrows: there are no use cases requiring a
          finer control. *)
}
(** This record controls how some generic helper lookup/update functions behave,
    by restraining the kind of therms they can enter. *)

let ek_all : exploration_kind =
  { enter_shared_loans = true; enter_mut_borrows = true; enter_abs = true }

type borrow_id_or_proj_symbolic_value =
  | BorrowId of borrow_id
  | SymbolicValue of symbolic_proj
[@@deriving show]

type unique_borrow_id_or_proj_symbolic_value =
  | BorrowId of unique_borrow_id
  | SymbolicValue of symbolic_proj
[@@deriving show]

exception FoundBorrowId of BorrowId.id
exception FoundLoanId of BorrowId.id
exception FoundUniqueBorrowId of unique_borrow_id

type priority_borrow_or_abs =
  | OuterMutBorrow of borrow_id
  | OuterSharedLoan of borrow_id
  | OuterAbs of AbsId.id * int
  | InnerLoan of loan_id
[@@deriving show]

let update_if_none opt x =
  match opt with
  | None -> Some x
  | _ -> opt

(** Utility exception *)
exception FoundPriority of priority_borrow_or_abs

(** Utility exception *)
exception FoundSharedBorrowId of borrow_id * shared_borrow_id

type loan_or_borrow_content =
  | LoanContent of loan_content
  | BorrowContent of borrow_content
[@@deriving show]

type borrow_loan_abs_id =
  | BorrowId of unique_borrow_id
  | LoanId of loan_id
  | AbsId of AbsId.id * int
      (** The integer represents the level (or sub-abstraction) that we end. *)

type borrow_loan_abs_ids = borrow_loan_abs_id list

let borrow_loan_abs_id_to_string (id : borrow_loan_abs_id) : string =
  match id with
  | AbsId (id, level) ->
      "abs@" ^ AbsId.to_string id ^ "(level:" ^ string_of_int level ^ ")"
  | BorrowId id -> (
      match id with
      | UMut id -> "MB@" ^ BorrowId.to_string id
      | UShared (id, sid) ->
          "SB@" ^ BorrowId.to_string id ^ "^" ^ SharedBorrowId.to_string sid)
  | LoanId id -> "loan@" ^ BorrowId.to_string id

let borrow_loan_abs_ids_chain_to_string (ids : borrow_loan_abs_ids) : string =
  let ids = List.rev ids in
  let ids = List.map borrow_loan_abs_id_to_string ids in
  String.concat " -> " ids

(** Add a borrow or abs id to a chain of ids, while checking that we don't loop
*)
let add_borrow_loan_abs_id_to_chain (span : Meta.span) (msg : string)
    (id : borrow_loan_abs_id) (ids : borrow_loan_abs_ids) : borrow_loan_abs_ids
    =
  if List.mem id ids then
    [%craise] span
      (msg ^ "detected a loop in the chain of ids: "
      ^ borrow_loan_abs_ids_chain_to_string (id :: ids))
  else id :: ids

(** We use this visitor to visit region abstractions.

    The visitor factors out once and for all the logic to increment the
    sub-abstraction indices/levels when diving into nested borrows. *)
class virtual ['self] iter_eval_ctx_with_abs_levels =
  object (self : 'self)
    inherit [_] iter_eval_ctx as super
    method virtual incr_level : 'a -> 'a

    method! visit_aborrow_content state bc =
      match bc with
      | AMutBorrow (pm, bid, av) -> self#visit_AMutBorrow state pm bid av
      | ASharedBorrow (pm, bid, sid) ->
          self#visit_ASharedBorrow state pm bid sid
      | AIgnoredMutBorrow (bid, child) ->
          self#visit_AIgnoredMutBorrow state bid child
      | AEndedSharedBorrow -> self#visit_AEndedSharedBorrow state
      | AEndedMutBorrow (m, child) -> self#visit_AEndedMutBorrow state m child
      | AEndedIgnoredMutBorrow bc -> self#visit_AEndedIgnoredMutBorrow state bc
      | AProjSharedBorrow (pm, asbl) ->
          self#visit_AProjSharedBorrow state pm asbl

    method! visit_AMutBorrow state pm bid child =
      super#visit_AMutBorrow state pm bid child

    method! visit_ASharedBorrow state pm bid sid =
      super#visit_ASharedBorrow state pm bid sid

    method! visit_AIgnoredMutBorrow state bid child =
      super#visit_AIgnoredMutBorrow state bid child

    method! visit_AEndedSharedBorrow state =
      super#visit_AEndedSharedBorrow state

    method! visit_AEndedMutBorrow state meta child =
      super#visit_AEndedMutBorrow state meta child

    method! visit_aended_ignored_mut_borrow state
        { child; given_back; given_back_meta } =
      self#visit_tavalue state child;
      self#visit_tavalue (self#incr_level state) given_back;
      self#visit_msymbolic_value state given_back_meta

    method! visit_abstract_shared_borrows state asbl =
      (* TODO: properly track the states inside the abstract shared borrows *)
      List.iter (self#visit_abstract_shared_borrow state) asbl

    (** We may need to visit borrow contents because of shared values *)
    method! visit_borrow_content state bc =
      match bc with
      | VSharedBorrow (bid, sid) -> self#visit_VSharedBorrow state bid sid
      | VReservedMutBorrow (bid, sid) ->
          self#visit_VReservedMutBorrow state bid sid
      | VMutBorrow (bid, v) -> self#visit_VMutBorrow state bid v

    method! visit_VSharedBorrow state bid sid =
      super#visit_VSharedBorrow state bid sid

    method! visit_VReservedMutBorrow state bid sid =
      super#visit_VReservedMutBorrow state bid sid

    method! visit_VMutBorrow state bid v = super#visit_VMutBorrow state bid v

    method! visit_aloan_content state lc =
      (* **WARNING**: we explicitly list all the cases here to make sure
         we catch any modification performed to the definitions: we have to
         be careful about not missing the overloading of any variant (method
         [visit_AMutLoan], [visit_ASharedLoan], etc.). *)
      match lc with
      | AMutLoan (pm, lid, child) -> self#visit_AMutLoan state pm lid child
      | ASharedLoan (pm, lid, sv, child) ->
          self#visit_ASharedLoan state pm lid sv child
      | AEndedSharedLoan (pm, sv, child) ->
          self#visit_AEndedSharedLoan state pm sv child
      | AIgnoredMutLoan (pm, lid, child) ->
          self#visit_AIgnoredMutLoan state pm lid child
      | AEndedMutLoan lc -> self#visit_AEndedMutLoan state lc
      | AEndedIgnoredMutLoan lc -> self#visit_AEndedIgnoredMutLoan state lc
      | AIgnoredSharedLoan child -> self#visit_AIgnoredSharedLoan state child

    method! visit_AMutLoan state pm lid child =
      super#visit_AMutLoan state pm lid child

    method! visit_ASharedLoan state lc = super#visit_ASharedLoan state lc

    method! visit_AEndedSharedLoan state pm sv child =
      super#visit_AEndedSharedLoan state pm sv child

    method! visit_AIgnoredMutLoan state pm lid child =
      super#visit_AIgnoredMutLoan state pm lid child

    method! visit_aended_mut_loan state { given_back; child; given_back_meta } =
      self#visit_mvalue state given_back_meta;
      (* We need to increase the state when diving into the loan *)
      self#visit_tavalue (self#incr_level state) given_back;
      self#visit_tavalue state child

    method! visit_aended_ignored_mut_loan state
        { given_back; child; given_back_meta; _ } =
      self#visit_mvalue state given_back_meta;
      (* We need to increase the state when diving into the loan *)
      self#visit_tavalue (self#incr_level state) given_back;
      self#visit_tavalue state child

    method! visit_AIgnoredSharedLoan state child =
      super#visit_AIgnoredSharedLoan state child

    (** We may need to visit loan contents because of shared values *)
    method! visit_loan_content state lc =
      match lc with
      | VMutLoan lid -> self#visit_VMutLoan state lid
      | VSharedLoan (bid, sid) -> self#visit_VSharedLoan state bid sid

    method! visit_VMutLoan state lid = super#visit_VMutLoan state lid

    method! visit_VSharedLoan state bid sid =
      super#visit_VSharedLoan state bid sid

    method! visit_aproj state proj =
      match proj with
      | ATransportedProj (transport, child) ->
          self#visit_ATransportedProj state transport child
      | AProjBorrows proj -> self#visit_AProjBorrows state proj
      | AEndedProjBorrows proj -> self#visit_AEndedProjBorrows state proj
      | AProjLoans proj -> self#visit_AProjLoans state proj
      | AEndedProjLoans proj -> self#visit_AEndedProjLoans state proj
      | APendingLoans bid -> self#visit_APendingLoans state bid
      | APendingSymbolicLoans slot -> self#visit_APendingSymbolicLoans state slot
      | AEmpty -> self#visit_AEmpty state

    method! visit_aproj_borrows state { proj; loans } =
      (* TODO: properly track the state for symbolic values *)
      self#visit_symbolic_proj state proj;
      List.iter
        (fun (m, p) ->
          self#visit_mconsumed_symb state m;
          self#visit_aproj (self#incr_level state) p)
        loans

    method! visit_aended_proj_borrows state { mvalues; loans } =
      (* TODO: properly track the state for symbolic values *)
      self#visit_ended_proj_borrow_meta state mvalues;
      List.iter
        (fun (m, p) ->
          self#visit_mconsumed_symb state m;
          self#visit_aproj (self#incr_level state) p)
        loans

    method! visit_aproj_loans state { proj; consumed; borrows } =
      (* TODO: properly track the state for symbolic values *)
      self#visit_symbolic_proj state proj;
      List.iter
        (fun (m, p) ->
          self#visit_mconsumed_symb state m;
          self#visit_aproj (self#incr_level state) p)
        consumed;
      List.iter
        (fun (m, p) ->
          self#visit_mconsumed_symb state m;
          self#visit_aproj (self#incr_level state) p)
        borrows

    method! visit_aended_proj_loans state { proj; consumed; borrows } =
      (* TODO: properly track the state for symbolic values *)
      self#visit_msymbolic_value_id state proj;
      List.iter
        (fun (m, p) ->
          self#visit_mconsumed_symb state m;
          self#visit_aproj (self#incr_level state) p)
        consumed;
      List.iter
        (fun (m, p) ->
          self#visit_mconsumed_symb state m;
          self#visit_aproj (self#incr_level state) p)
        borrows

    method! visit_AEmpty state = super#visit_AEmpty state

    method! visit_eborrow_content state bc =
      match bc with
      | EMutBorrow (pm, sid, child) -> self#visit_EMutBorrow state pm sid child
      | EIgnoredMutBorrow (bid, child) ->
          self#visit_EIgnoredMutBorrow state bid child
      | EEndedMutBorrow (meta, child) ->
          self#visit_EEndedMutBorrow state meta child
      | EEndedIgnoredMutBorrow bc -> self#visit_EEndedIgnoredMutBorrow state bc

    method! visit_EMutBorrow state pm sid child =
      super#visit_EMutBorrow state pm sid child

    method! visit_EIgnoredMutBorrow state bid child =
      super#visit_EIgnoredMutBorrow state bid child

    method! visit_EEndedMutBorrow state meta child =
      super#visit_EEndedMutBorrow state meta child

    method! visit_eended_ignored_mut_borrow state
        { child; given_back; given_back_meta } =
      self#visit_tevalue state child;
      self#visit_tevalue (self#incr_level state) given_back;
      self#visit_msymbolic_value state given_back_meta

    method! visit_eloan_content state lc =
      match lc with
      | EMutLoan (pm, lid, child) -> self#visit_EMutLoan state pm lid child
      | EEndedMutLoan lc -> self#visit_EEndedMutLoan state lc
      | EIgnoredMutLoan (pm, lid, child) ->
          self#visit_EIgnoredMutLoan state pm lid child
      | EEndedIgnoredMutLoan lc -> self#visit_EEndedIgnoredMutLoan state lc

    method! visit_EMutLoan state pm lid child =
      super#visit_EMutLoan state pm lid child

    method! visit_eended_mut_loan state { child; given_back; given_back_meta } =
      self#visit_tevalue state child;
      self#visit_tevalue (self#incr_level state) given_back;
      self#visit_mvalue state given_back_meta

    method! visit_EIgnoredMutLoan state pm lid child =
      super#visit_EIgnoredMutLoan state pm lid child

    method! visit_eended_ignored_mut_loan state
        { child; given_back; given_back_meta; _ } =
      self#visit_tevalue state child;
      self#visit_tevalue (self#incr_level state) given_back;
      self#visit_mvalue state given_back_meta

    method! visit_eproj state proj =
      match proj with
      | ETransportedProj (transport, child) ->
          self#visit_ETransportedProj state transport child
      | EProjLoans proj -> self#visit_EProjLoans state proj
      | EProjBorrows proj -> self#visit_EProjBorrows state proj
      | EEndedProjLoans proj -> self#visit_EEndedProjLoans state proj
      | EEndedProjBorrows proj -> self#visit_EEndedProjBorrows state proj
      | EPendingLoans bid -> self#visit_EPendingLoans state bid
      | EPendingSymbolicLoans slot -> self#visit_EPendingSymbolicLoans state slot
      | EEmpty -> self#visit_EEmpty state

    method! visit_eproj_loans state { proj; consumed; borrows } =
      self#visit_esymbolic_proj state proj;
      List.iter
        (fun (m, p) ->
          self#visit_mconsumed_symb state m;
          self#visit_eproj (self#incr_level state) p)
        consumed;
      List.iter
        (fun (m, p) ->
          self#visit_mconsumed_symb state m;
          self#visit_eproj (self#incr_level state) p)
        borrows

    method! visit_eproj_borrows state { proj; loans } =
      self#visit_esymbolic_proj state proj;
      List.iter
        (fun (m, p) ->
          self#visit_mconsumed_symb state m;
          self#visit_eproj (self#incr_level state) p)
        loans

    method! visit_eended_proj_loans state { proj; consumed; borrows } =
      self#visit_msymbolic_value_id state proj;
      List.iter
        (fun (m, p) ->
          self#visit_mconsumed_symb state m;
          self#visit_eproj (self#incr_level state) p)
        consumed;
      List.iter
        (fun (m, p) ->
          self#visit_mconsumed_symb state m;
          self#visit_eproj (self#incr_level state) p)
        borrows

    method! visit_eended_proj_borrows state { mvalues; loans } =
      self#visit_ended_proj_borrow_meta state mvalues;
      List.iter
        (fun (m, p) ->
          self#visit_mconsumed_symb state m;
          self#visit_eproj (self#incr_level state) p)
        loans

    method! visit_EEmpty _ = ()

    method! visit_EMutBorrowInput state av =
      super#visit_EMutBorrowInput state av
  end

class virtual ['self] iter_abs_with_levels =
  object (_ : 'self)
    inherit [_] iter_eval_ctx_with_abs_levels
  end

class virtual ['self] iter_tavalue_with_levels =
  object (_ : 'self)
    inherit [_] iter_eval_ctx_with_abs_levels
  end

(** Map live operational and continuation projections at their sub-abstraction
    levels. Historical metadata stays at the level of its enclosing projector.
*)
class virtual ['self] map_eval_ctx_with_abs_levels =
  object (self : 'self)
    inherit [_] map_eval_ctx
    method virtual incr_level : 'a -> 'a

    method! visit_aended_mut_loan state (lc : aended_mut_loan) =
      {
        lc with
        child = self#visit_tavalue state lc.child;
        given_back = self#visit_tavalue (self#incr_level state) lc.given_back;
      }

    method! visit_aended_ignored_mut_loan state (lc : aended_ignored_mut_loan) =
      {
        lc with
        child = self#visit_tavalue state lc.child;
        given_back = self#visit_tavalue (self#incr_level state) lc.given_back;
      }

    method! visit_aended_ignored_mut_borrow state
        (bc : aended_ignored_mut_borrow) =
      {
        bc with
        child = self#visit_tavalue state bc.child;
        given_back = self#visit_tavalue (self#incr_level state) bc.given_back;
      }

    method! visit_eended_mut_loan state (lc : eended_mut_loan) =
      {
        lc with
        child = self#visit_tevalue state lc.child;
        given_back = self#visit_tevalue (self#incr_level state) lc.given_back;
      }

    method! visit_eended_ignored_mut_loan state (lc : eended_ignored_mut_loan) =
      {
        lc with
        child = self#visit_tevalue state lc.child;
        given_back = self#visit_tevalue (self#incr_level state) lc.given_back;
      }

    method! visit_eended_ignored_mut_borrow state
        (bc : eended_ignored_mut_borrow) =
      {
        bc with
        child = self#visit_tevalue state bc.child;
        given_back = self#visit_tevalue (self#incr_level state) bc.given_back;
      }

    method private visit_aproj_children state children =
      List.map
        (fun (meta, proj) ->
          ( self#visit_mconsumed_symb state meta,
            self#visit_aproj (self#incr_level state) proj ))
        children

    method private visit_eproj_children state children =
      List.map
        (fun (meta, proj) ->
          ( self#visit_mconsumed_symb state meta,
            self#visit_eproj (self#incr_level state) proj ))
        children

    method! visit_aproj_borrows state (proj : aproj_borrows) : aproj_borrows =
      {
        proj = self#visit_symbolic_proj state proj.proj;
        loans = self#visit_aproj_children state proj.loans;
      }

    method! visit_aended_proj_borrows state (proj : aended_proj_borrows) :
        aended_proj_borrows =
      {
        mvalues = self#visit_ended_proj_borrow_meta state proj.mvalues;
        loans = self#visit_aproj_children state proj.loans;
      }

    method! visit_aproj_loans state (proj : aproj_loans) : aproj_loans =
      {
        proj = self#visit_symbolic_proj state proj.proj;
        consumed = self#visit_aproj_children state proj.consumed;
        borrows = self#visit_aproj_children state proj.borrows;
      }

    method! visit_aended_proj_loans state (proj : aended_proj_loans) :
        aended_proj_loans =
      {
        proj = self#visit_msymbolic_value_id state proj.proj;
        consumed = self#visit_aproj_children state proj.consumed;
        borrows = self#visit_aproj_children state proj.borrows;
      }

    method! visit_eproj_borrows state (proj : eproj_borrows) : eproj_borrows =
      {
        proj = self#visit_esymbolic_proj state proj.proj;
        loans = self#visit_eproj_children state proj.loans;
      }

    method! visit_eended_proj_borrows state (proj : eended_proj_borrows) :
        eended_proj_borrows =
      {
        mvalues = self#visit_ended_proj_borrow_meta state proj.mvalues;
        loans = self#visit_eproj_children state proj.loans;
      }

    method! visit_eproj_loans state (proj : eproj_loans) : eproj_loans =
      {
        proj = self#visit_esymbolic_proj state proj.proj;
        consumed = self#visit_eproj_children state proj.consumed;
        borrows = self#visit_eproj_children state proj.borrows;
      }

    method! visit_eended_proj_loans state (proj : eended_proj_loans) :
        eended_proj_loans =
      {
        proj = self#visit_msymbolic_value_id state proj.proj;
        consumed = self#visit_eproj_children state proj.consumed;
        borrows = self#visit_eproj_children state proj.borrows;
      }
  end

(** Map operational abstract values with their sub-abstraction levels.
    Continuations and symbolic-projector metadata do not contain operational
    [tavalue] children and are left unchanged. *)
class virtual ['self] map_abs_with_levels =
  object (self : 'self)
    inherit [_] map_eval_ctx_with_abs_levels

    method! visit_abs state abs =
      { abs with avalues = List.map (self#visit_tavalue state) abs.avalues }
  end

(** Remap declaration witnesses, authentic edges, and physical return suppliers
    through a pure semantic visitor. Source keys follow that visitor's guarded
    substitutions. Supplier levels, declaration ordinals, and field routes
    retain their identity.

    Runtime-owner searches and mutations must not use this helper. *)
let map_call_endpoint_witnesses visitor env
    (witnesses : call_endpoint_witnesses) : call_endpoint_witnesses =
  let map_expansion = function
    | SeLiteral value -> SeLiteral (visitor#visit_literal env value)
    | SeAdt (variant, fields) ->
        SeAdt (variant, List.map (visitor#visit_symbolic_value env) fields)
    | SeMutRef (bid, child) ->
        SeMutRef
          (visitor#visit_borrow_id env bid, visitor#visit_symbolic_value env child)
    | SeSharedRef (bid, child) ->
        SeSharedRef
          (visitor#visit_borrow_id env bid, visitor#visit_symbolic_value env child)
  in
  {
    roots =
      List.map
        (fun (from_input, original, actual) ->
          ( from_input,
            visitor#visit_tavalue env original,
            visitor#visit_tavalue env actual ))
        witnesses.roots;
    expansions =
      List.map
        (fun (source, expansion) ->
          (visitor#visit_symbolic_value env source, map_expansion expansion))
        witnesses.expansions;
    projections =
      List.map
        (fun (source, regions, projected) ->
          ( visitor#visit_symbolic_proj env source,
            visitor#visit_region_id_set env regions,
            visitor#visit_tavalue env projected ))
        witnesses.projections;
    (*
```ocaml
    *)
    carrier_origins =
      List.map (visitor#visit_carrier_origin env) witnesses.carrier_origins;
    input_correspondences =
      List.map (visitor#visit_call_input_correspondence env) witnesses.input_correspondences;
(* ```ocaml *)
    carrier_conversions =
      List.map (visitor#visit_input_carrier_conversion env) witnesses.carrier_conversions;
(* ``` *)
    (*
```
    *)
    physical_returns =
      List.map
        (visitor#visit_input_physical_return env)
        witnesses.physical_returns;
(*
```ocaml
*)
    return_routes =
      List.map (visitor#visit_input_return_route env) witnesses.return_routes;
(*
```
*)
    (*
```ocaml
    *)
    parent_carriers =
      List.map
        (fun (branch, parent, mask, regions, producer) ->
          (branch, visitor#visit_borrow_id env parent, mask,
           visitor#visit_region_id_set env regions,
           visitor#visit_tevalue env producer))
        witnesses.parent_carriers;
    (*
```
    *)
  }

(** Remap a pending dependency and its witnesses without changing declaration
    positions or structural paths. Only pure semantic visitors may use this. *)
let map_call_pending_scope visitor env (scope : call_pending_scope) :
    call_pending_scope =
  {
    scope with
    slot = visitor#visit_symbolic_pending_slot env scope.slot;
    witnesses = map_call_endpoint_witnesses visitor env scope.witnesses;
  }

(*
```ocaml
*)
let map_call_scope visitor env = function
  | PendingParameterScope scope ->
      PendingParameterScope (map_call_pending_scope visitor env scope)
  | PhysicalInputScope scope ->
      PhysicalInputScope {
        physical_slot = visitor#visit_physical_input_slot env scope.physical_slot;
        ancestry = visitor#visit_physical_input_ancestry env scope.ancestry;
        witnesses = map_call_endpoint_witnesses visitor env scope.witnesses;
      }
(*
```
*)

(** Reconcile a complete concrete shared group against opposite-marker plain
    borrowers in this same-level value list.

    Matching uses real lender IDs and one distinct plain entry per member.
    Partial inventories and symbolic members remain marked. Both forms retain
    their allocated shared IDs, loan IDs, types, order, and multiplicity. *)
let reconcile_shared_borrow_groups (avalues : tavalue list) : tavalue list =
  let eligible (av : tavalue) =
    match av.value with
    | ABorrow (AProjSharedBorrow ((PLeft | PRight), (_ :: _ as members))) ->
        List.for_all
          (function AsbBorrow _ -> true | AsbProjReborrows _ -> false)
          members
    | _ -> false
  in
  if not (List.exists eligible avalues) then avalues
  else
    let entries = Array.of_list avalues in
    let changed = ref false in
    Array.iteri
      (fun index (group : tavalue) ->
        match group.value with
        | ABorrow (AProjSharedBorrow (((PLeft | PRight) as pm), members)) ->
            let opposite = if pm = PLeft then PRight else PLeft in
            let rec cover chosen = function
              | [] -> Some chosen
              | AsbProjReborrows _ :: _ -> None
              | AsbBorrow (bid, _) :: rest ->
                  let rec find i =
                    if i = Array.length entries then None
                    else if List.mem i chosen then find (i + 1)
                    else
                      match entries.(i).value with
                      | ABorrow (ASharedBorrow (marker, actual, _))
                        when marker = opposite && actual = bid ->
                          cover (i :: chosen) rest
                      | _ -> find (i + 1)
                  in
                  find 0
            in
            (match cover [] members with
            | Some (_ :: _ as chosen) ->
                List.iter
                  (fun i ->
                    let actual = entries.(i) in
                    match actual.value with
                    | ABorrow (ASharedBorrow (_, bid, sid)) ->
                        entries.(i) <-
                          { actual with
                            value = ABorrow (ASharedBorrow (PNone, bid, sid)) }
                    | _ -> assert false)
                  chosen;
                entries.(index) <-
                  { group with
                    value = ABorrow (AProjSharedBorrow (PNone, members)) };
                changed := true
            | Some [] | None -> ())
        | _ -> ())
      entries;
    if !changed then Array.to_list entries else avalues

let projection_adt_info (infos : TypesAnalysis.type_infos) = function
  | TAdtId id -> Some (TypeDeclId.Map.find id infos)
  | TTuple | TBuiltin _ -> None

let projection_region_is_stored info index =
  match info with
  | None -> true
  | Some info ->
      RegionId.Set.mem (RegionId.of_int index) info.TypesAnalysis.stored_regions

let projection_type_is_stored info index =
  match info with
  | None -> true
  | Some info ->
      TypeVarId.Set.mem (TypeVarId.of_int index) info.TypesAnalysis.stored_type_params

(** Derive metadata aliases only from corresponding stored positions.
    Context matching may supply its recoverable mismatch exception. Other callers
    retain the existing internal consistency checks. *)
(*
```ocaml
*)
let projection_metadata_stored_paths infos ty1 ty2 source previous current =
  let rows = ref [] in
  let stopped = ref false in
  let add path r1 r2 =
    if not !stopped && r1 = source then (
      rows := (path ^ " -> " ^ show_region r2) :: !rows;
      if r2 = current && r2 <> previous then stopped := true)
  in
  let rec iter_args index stored visit path args1 args2 =
    match args1, args2 with
    | arg1 :: args1, arg2 :: args2 when not !stopped ->
        if stored index then visit (path ^ "[" ^ string_of_int index ^ "]") arg1 arg2;
        iter_args (index + 1) stored visit path args1 args2
    | _ -> ()
  in
  let rec visit path ty1 ty2 =
    if not !stopped then match ty1, ty2 with
    | TAdt tref1, TAdt tref2 ->
        let info = projection_adt_info infos tref1.id in
        let path = path ^ "/TAdt(" ^ show_type_id tref1.id ^ ")" in
        iter_args 0 (projection_region_is_stored info) add
          (path ^ "/regions") tref1.generics.regions tref2.generics.regions;
        iter_args 0 (projection_type_is_stored info) visit
          (path ^ "/types") tref1.generics.types tref2.generics.types
    | TRef (r1, ty1, _), TRef (r2, ty2, _) ->
        add (path ^ "/TRef.region") r1 r2;
        visit (path ^ "/TRef.type") ty1 ty2
    | TRawPtr (ty1, _), TRawPtr (ty2, _) -> visit (path ^ "/TRawPtr.type") ty1 ty2
    | TArray (ty1, _), TArray (ty2, _) -> visit (path ^ "/TArray.type") ty1 ty2
    | TPtrMetadata ty1, TPtrMetadata ty2 -> visit (path ^ "/TPtrMetadata.type") ty1 ty2
    | TSlice ty1, TSlice ty2 -> visit (path ^ "/TSlice.type") ty1 ty2
    | _ -> ()
  in
  visit "root" ty1 ty2;
  String.concat "\n" (List.rev !rows)

let projection_metadata_renaming ?mismatch ?selected_regions ?metadata_bindings span infos ty1 ty2 =
  let renaming = ref RegionId.Map.empty in
  let log = Logging.carrier_events_log in
  let add_region r1 r2 =
    match (r1, r2) with
    | RVar (Free rid), (RVar (Free _) | RStatic)
      when (match selected_regions with
            | None -> true
            | Some selected -> RegionId.Set.mem rid selected) ->
        (match RegionId.Map.find_opt rid !renaming with
        | None -> renaming := RegionId.Map.add rid r2 !renaming
        | Some previous ->
            if previous <> r2 then begin
              (* ```ocaml *)
              (match selected_regions with
              | None -> ()
              | Some _ when not !Config.sanity_checks -> ()
              | Some selected ->
                  let raw label text =
                    let shown = Stdlib.min 65536 (String.length text) in
                    Printf.eprintf "%s bytes=%d shown=%d:\n%s\n%!"
                      label (String.length text) shown (String.sub text 0 shown)
                  in
                  Printf.eprintf
                    "Stored selection correspondence conflict: source=%s previous=%s destination=%s selected-source=%b\n%!"
                    (RegionId.to_string rid) (show_region previous)
                    (show_region r2) (RegionId.Set.mem rid selected);
                  raw "raw selected storage mask" (RegionId.Set.show selected);
                  raw "raw original stored-coordinate type" (Types.show_ty ty1);
                  raw "raw mapped stored-coordinate type" (Types.show_ty ty2);
                  raw "raw conflicting stored paths"
                    (projection_metadata_stored_paths infos ty1 ty2 r1 previous r2);
                  Option.iter
                    (fun bindings ->
                      let binding role region =
                        Printf.eprintf
                          "Stored selection input binding: role=%s coordinate=%s source=%s\n%!"
                          role (show_region region)
                          (show_region (metadata_region bindings region))
                      in
                      binding "conflict" r1;
                      binding "previous" previous;
                      binding "destination" r2)
                    metadata_bindings);
              (* ``` *)
              [%ldebug
                "Source ABI forward correspondence conflict:"
                ^ "\n- source region: " ^ show_region r1
                ^ "\n- previous target: " ^ show_region previous
                ^ "\n- new target: " ^ show_region r2
                ^ "\n- derived stored paths: "
                ^ projection_metadata_stored_paths infos ty1 ty2 r1 previous r2
                ^ "\n- partial forward map: "
                ^ RegionId.Map.to_string None show_region !renaming
                ^ "\n- raw source type: " ^ Types.show_ty ty1
                ^ "\n- raw joined type: " ^ Types.show_ty ty2];
              match mismatch with
              | Some error -> raise error
              | None -> [%sanity_check] span (previous = r2)
            end)
    | _ -> ()
  in
  let iter_args is_stored visit args1 args2 =
    let rec iter index args1 args2 =
      match (args1, args2) with
      | [], [] -> ()
      | arg1 :: args1, arg2 :: args2 ->
          if is_stored index then visit arg1 arg2;
          iter (index + 1) args1 args2
      | _ ->
          (match mismatch with
          | Some error -> raise error
          | None -> [%internal_error] span)
    in
    iter 0 args1 args2
  in
  let rec visit ty1 ty2 =
    match (ty1, ty2) with
    | TAdt tref1, TAdt tref2 ->
        let info = projection_adt_info infos tref1.id in
        iter_args (projection_region_is_stored info) add_region
          tref1.generics.regions tref2.generics.regions;
        iter_args (projection_type_is_stored info) visit
          tref1.generics.types tref2.generics.types
    | TRef (r1, ty1, _), TRef (r2, ty2, _) ->
        add_region r1 r2;
        visit ty1 ty2
    | TRawPtr (ty1, _), TRawPtr (ty2, _)
    | TArray (ty1, _), TArray (ty2, _)
    | TPtrMetadata ty1, TPtrMetadata ty2
    | TSlice ty1, TSlice ty2 -> visit ty1 ty2
    | TLiteral _, TLiteral _
    | TVar _, TVar _
    | TNever, TNever
    | TFnPtr _, TFnPtr _
    | TFnDef _, TFnDef _
    | TTraitType _, TTraitType _
    | TDynTrait _, TDynTrait _ -> ()
    | _ ->
        (match mismatch with
        | Some error -> raise error
        | None -> [%internal_error] span)
  in
  visit ty1 ty2;
  !renaming
(*
```
*)

(* ```ocaml *)
let transport_projection_regions span infos ~metadata_bindings original mapped selected =
  if original == mapped || RegionId.Set.is_empty selected then selected
  else
    let renaming =
      projection_metadata_renaming ~selected_regions:selected ~metadata_bindings
        span infos original mapped
    in
    RegionId.Set.fold
      (fun source transported ->
        match RegionId.Map.find_opt source renaming with
        | Some (RVar (Free destination)) ->
            RegionId.Set.add destination transported
        | None -> RegionId.Set.add source transported
        | _ ->
            [%craise] span "A stored projection coordinate is not a physical region")
      selected RegionId.Set.empty
(* ``` *)

let rename_projection_metadata_region renaming r =
  match r with
  | RVar (Free rid) ->
      (match RegionId.Map.find_opt rid renaming with
      | Some renamed -> renamed
      | None -> r)
  | _ -> r

(** Rename free aliases uniformly without opening binders or changing parameters. *)
let map_free_region_aliases rename_region ty =
  let visitor =
    object
      inherit [_] map_ty
      method! visit_region_param _ param = param
      method! visit_region _ r =
        match r with
        | RVar (Free _) -> rename_region r
        | _ -> r
    end
  in
  visitor#visit_ty () ty

let projection_metadata_regions_equal (ctx : eval_ctx) renaming r1 r2 =
  rename_projection_metadata_region renaming
    (metadata_region ctx.metadata_bindings r1)
  = metadata_region ctx.metadata_bindings r2

(** Source aliases describe call metadata, not physical ownership positions. *)
let resolve_projection_metadata_ty (ctx : eval_ctx) ty =
  if RegionId.Map.is_empty ctx.metadata_bindings then ty
  else map_free_region_aliases (metadata_region ctx.metadata_bindings) ty

let projection_metadata_types_equal (ctx : eval_ctx) renaming ty1 ty2 =
  let ty1 = resolve_projection_metadata_ty ctx ty1 in
  let ty2 = resolve_projection_metadata_ty ctx ty2 in
  if RegionId.Map.is_empty renaming then ty1 = ty2
  else
    map_free_region_aliases (rename_projection_metadata_region renaming) ty1 = ty2

(** Compare complete types after positional transport of stored regions.
    Nonstored arguments and declaration metadata retain their original values.
    Selected-subset functionality remains a separate transport check. *)
(* ```ocaml *)
let complete_projection_types_compatible (ctx : eval_ctx) source current =
  if source = current then true
  else
    let map_stored is_stored map left right =
      let rec visit index left right =
        match left, right with
        | (original :: tail as originals), actual :: right ->
            let value = if is_stored index then map original actual else original in
            let mapped_tail = visit (index + 1) tail right in
            if value == original && mapped_tail == tail then originals
            else value :: mapped_tail
        | remaining, _ -> remaining
      in
      visit 0 left right
    in
    let region original actual =
      if original = actual then original
      else
      match original, actual with
      | RVar (Free _), (RVar (Free _) | RStatic) -> actual
      | _ -> original
    in
    let types = TyCache.create 16 in
    let rec align source current =
      if source = current then source
      else
        match TyCache.find_opt types source with
        | Some (previous, result) when previous = current -> result
        | _ ->
            let result =
              match source, current with
              | TAdt original, TAdt actual when original.id = actual.id ->
                  let info = projection_adt_info ctx.type_ctx.type_infos original.id in
                  let generics = original.generics in
                  let regions =
                    map_stored (projection_region_is_stored info) region
                      generics.regions actual.generics.regions
                  in
                  let types =
                    map_stored (projection_type_is_stored info) align
                      generics.types actual.generics.types
                  in
                  if regions == generics.regions && types == generics.types then source
                  else TAdt { original with generics = { generics with regions; types } }
              | TRef (original, child, kind), TRef (actual, current, _) ->
                  let mapped_region = region original actual in
                  let mapped_child = align child current in
                  if mapped_region == original && mapped_child == child then source
                  else TRef (mapped_region, mapped_child, kind)
              | TRawPtr (child, kind), TRawPtr (current, _) ->
                  let mapped_child = align child current in
                  if mapped_child == child then source
                  else TRawPtr (mapped_child, kind)
              | TArray (child, length), TArray (current, _) ->
                  let mapped_child = align child current in
                  if mapped_child == child then source
                  else TArray (mapped_child, length)
              | TSlice child, TSlice current ->
                  let mapped_child = align child current in
                  if mapped_child == child then source else TSlice mapped_child
              | TPtrMetadata child, TPtrMetadata current ->
                  let mapped_child = align child current in
                  if mapped_child == child then source else TPtrMetadata mapped_child
              | _ -> source
            in
            TyCache.add types source (current, result);
            result
    in
    let comparison = align source current in
    projection_metadata_types_equal ctx RegionId.Map.empty comparison current
(* ``` *)

(** Compare stored region positions of two regionful types.
    Ownership uses the original physical regions.

    Metadata compatibility uses source-resolved aliases and correspondence
    from stored positions. Metadata never reaches [compare_regions]. *)
let rec compare_ty_regions (span : Meta.span) (ctx : eval_ctx) metadata_renaming
    (default : bool) (combine : bool -> bool -> bool)
    (compare_regions : region -> region -> bool) (ty1 : ty) (ty2 : ty) : bool =
  let compare =
    compare_ty_regions span ctx metadata_renaming default combine compare_regions
  in
  (* Normalize the associated types *)
  match (ty1, ty2) with
  | TLiteral lit1, TLiteral lit2 ->
      [%sanity_check] span (lit1 = lit2);
      default
  | TAdt tref1, TAdt tref2 ->
      let generics1 = tref1.generics in
      let generics2 = tref2.generics in
      [%sanity_check] span (tref1.id = tref2.id);
      (* There are no regions in the const generics, so we ignore them,
         but we still check they are the same, for sanity *)
      [%sanity_check] span (generics1.const_generics = generics2.const_generics);

      let info = projection_adt_info ctx.type_ctx.type_infos tref1.id in
      let compare_args is_stored compare compare_metadata args1 args2 =
        let rec fold index result args1 args2 =
          match (args1, args2) with
          | [], [] -> result
          | arg1 :: args1, arg2 :: args2 ->
              let compared =
                if is_stored index then compare arg1 arg2
                else (
                  [%cassert] span (compare_metadata arg1 arg2)
                    ("Incompatible projection metadata:\n"
                    ^ ty_to_string ctx ty1 ^ "\n" ^ ty_to_string ctx ty2);
                  default)
              in
              fold (index + 1) (combine result compared) args1 args2
          | _ -> [%internal_error] span
        in
        fold 0 default args1 args2
      in
      let params_b =
        compare_args (projection_region_is_stored info) compare_regions
          (projection_metadata_regions_equal ctx (Lazy.force metadata_renaming))
          generics1.regions generics2.regions
      in
      let tys_b =
        compare_args (projection_type_is_stored info) compare
          (fun ty1 ty2 ->
            projection_metadata_types_equal ctx (Lazy.force metadata_renaming) ty1 ty2)
          generics1.types generics2.types
      in
      combine params_b tys_b
  | TArray (ty1, len1), TArray (ty2, len2) ->
      (* There are no regions in the const generics, so we ignore them,
         but we still check they are the same, for sanity *)
      [%sanity_check] span (len1 = len2);
      compare ty1 ty2
  | TSlice ty1, TSlice ty2 -> compare ty1 ty2
  | TRef (r1, ty1, kind1), TRef (r2, ty2, kind2) ->
      (* Sanity check *)
      [%sanity_check] span (kind1 = kind2);
      (* Explanation for the case where we check if projections intersect:
       * the projections intersect if the borrows intersect or their contents
       * intersect. *)
      let regions_b = compare_regions r1 r2 in
      let tys_b = compare ty1 ty2 in
      combine regions_b tys_b
  | TVar id1, TVar id2 ->
      [%sanity_check] span (id1 = id2);
      default
  | TTraitType _, TTraitType _ ->
      (* The types should have been normalized. If after normalization we
         get trait types, we can consider them as variables *)
      [%sanity_check] span (projection_metadata_types_equal ctx (Lazy.force metadata_renaming) ty1 ty2);
      default
  | TFnDef _, TFnDef _
  | TFnPtr _, TFnPtr _ ->
      (* Call signatures contribute compatibility, never ownership overlap. *)
      [%sanity_check] span (projection_metadata_types_equal ctx (Lazy.force metadata_renaming) ty1 ty2);
      default
  | TDynTrait _, TDynTrait _ ->
      (* TODO: this is wrong, we need to compare the regions inside TDyn *)
      [%cassert] span (not Config.use_dyn_regions) "Unimplemented";
      default
  | _ ->
      [%craise] span
        ("Internal error, please report an issue.\n\nUnexpected inputs:"
       ^ "\n- ty1: " ^ ty_to_string ctx ty1 ^ "\n- ty2: " ^ ty_to_string ctx ty2
        )

(** Compare regionful projection types, never erased types or projection masks.
*)
let compare_rtys (span : Meta.span) (ctx : eval_ctx) (default : bool)
    (combine : bool -> bool -> bool)
    (compare_regions : region -> region -> bool) (ty1 : rty) (ty2 : rty) : bool
    =
  [%sanity_check] span (ty_is_rty ctx.type_ctx.type_infos ty1 && ty_is_rty ctx.type_ctx.type_infos ty2);
  let metadata_renaming =
    lazy
      (if ty1 = ty2 then RegionId.Map.empty
       else
         projection_metadata_renaming span ctx.type_ctx.type_infos
           (resolve_projection_metadata_ty ctx ty1)
           (resolve_projection_metadata_ty ctx ty2))
  in
  compare_ty_regions span ctx metadata_renaming default combine compare_regions ty1 ty2

(** Check if two different projections intersect.

    This is necessary when giving a symbolic value to an abstraction: we need to
    check that the regions which are already ended inside the abstraction don't
    intersect the regions over which we project in the new abstraction. Note
    that the two abstractions have different views (in terms of regions) of the
    symbolic value (hence the two region types). *)
let projections_intersect (span : Meta.span) (ctx : eval_ctx)
    (rset1 : RegionId.Set.t) (ty1 : rty) (rset2 : RegionId.Set.t) (ty2 : rty) :
    bool =
  let default = false in
  let combine b1 b2 = b1 || b2 in
  let compare_regions r1 r2 =
    region_in_set r1 rset1 && region_in_set r2 rset2
  in
  compare_rtys span ctx default combine compare_regions ty1 ty2

(** Check if the first projection contains the second projection. We use this
    function when checking invariants.

    The regions in the types shouldn't be erased (this function will raise an
    exception otherwise). *)
let projection_contains (span : Meta.span) (ctx : eval_ctx)
    (rset1 : RegionId.Set.t) (ty1 : rty) (rset2 : RegionId.Set.t) (ty2 : rty) :
    bool =
  let default = true in
  let combine b1 b2 = b1 && b2 in
  let compare_regions r1 r2 =
    region_in_set r1 rset1 || not (region_in_set r2 rset2)
  in
  compare_rtys span ctx default combine compare_regions ty1 ty2

(** Equality of selected region positions, not of their unowned witnesses. *)
let projection_masks_equal (span : Meta.span) (ctx : eval_ctx)
    (owned : RegionId.Set.t) (ty0 : rty) (ty1 : rty) : bool =
  compare_rtys span ctx true ( && )
    (fun r0 r1 -> region_in_set r0 owned = region_in_set r1 owned)
    ty0 ty1

(** Lookup a loan content.

    The loan is referred to by a borrow id.

    Rem.: if the {!InterpUtils.g_loan_content} is
    {!constructor:Aeneas.InterpUtils.concrete_or_abs.Concrete}, the
    {!InterpUtils.abs_or_var_id} is not necessarily
    {!constructor:Aeneas.InterpUtils.abs_or_var_id.LocalId} or
    {!constructor:Aeneas.InterpUtils.abs_or_var_id.DummyVarId}: there can be
    concrete loans in abstractions (in the shared values). *)
let lookup_loan_opt (span : Meta.span) (ek : exploration_kind) (l : BorrowId.id)
    (env : env) : (abs_or_var_id * g_loan_content) option =
  (* We store here whether we are inside an abstraction or a value - note that we
   * could also track that with the environment, it would probably be more idiomatic
   * and cleaner *)
  let abs_or_var : abs_or_var_id option ref = ref None in

  let obj =
    object (self)
      inherit [_] iter_eval_ctx as super
      method! visit_ty _ _ = ()

      method! visit_env_elem env ee =
        match ee with
        | EBinding (_, { value = VBottom | VLiteral _ | VSymbolic _; _ }) -> ()
        | _ -> super#visit_env_elem env ee

      method! visit_borrow_content env bc =
        match bc with
        | VSharedBorrow (bid, sid) ->
            (* Nothing specific to do *)
            super#visit_VSharedBorrow env bid sid
        | VReservedMutBorrow (bid, sid) ->
            (* Nothing specific to do *)
            super#visit_VReservedMutBorrow env bid sid
        | VMutBorrow (bid, mv) ->
            (* Control the dive *)
            if ek.enter_mut_borrows then super#visit_VMutBorrow env bid mv
            else ()

      (** We reimplement {!visit_Loan} (rather than the more precise functions
          {!visit_SharedLoan}, etc.) on purpose: as we have an exhaustive match
          below, we are more resilient to definition updates (the compiler is
          our friend). *)
      method! visit_loan_content env lc =
        match lc with
        | VSharedLoan (lid, sv) ->
            (* Check if this is the loan we are looking for, and control the dive *)
            if l = lid then raise_notrace (FoundGLoanContent (Concrete lc))
            else if ek.enter_shared_loans then
              super#visit_VSharedLoan env lid sv
            else ()
        | VMutLoan bid ->
            (* Check if this is the loan we are looking for *)
            if bid = l then raise_notrace (FoundGLoanContent (Concrete lc))
            else super#visit_VMutLoan env bid

      (** Note that we don't control diving inside the abstractions: if we allow
          to dive inside abstractions, we allow to go anywhere (because there
          are no use cases requiring finer control) *)
      method! visit_aloan_content env lc =
        match lc with
        | AMutLoan (pm, bid, av) ->
            (* Sanity check: projection markers can only appear when we're doing a join *)
            [%sanity_check] span (pm = PNone);
            if bid = l then raise_notrace (FoundGLoanContent (Abstract lc))
            else super#visit_AMutLoan env pm bid av
        | ASharedLoan (pm, lid, v, av) ->
            (* Sanity check: projection markers can only appear when we're doing a join *)
            [%sanity_check] span (pm = PNone);
            if l = lid then raise_notrace (FoundGLoanContent (Abstract lc))
            else super#visit_ASharedLoan env pm lid v av
        | AEndedMutLoan { given_back = _; child = _; given_back_meta = _ }
        | AEndedSharedLoan (_, _, _)
        | AIgnoredMutLoan (_, _, _)
        | AEndedIgnoredMutLoan { given_back = _; child = _; _ }
        | AIgnoredSharedLoan _ -> super#visit_aloan_content env lc

      method! visit_EBinding env bv v =
        [%sanity_check] span (Option.is_none !abs_or_var);
        abs_or_var :=
          Some
            (match bv with
            | BVar b -> LocalId b.index
            | BDummy id -> DummyVarId id);
        super#visit_EBinding env bv v;
        abs_or_var := None

      method! visit_EAbs env abs =
        [%sanity_check] span (Option.is_none !abs_or_var);
        if ek.enter_abs then (
          abs_or_var := Some (AbsId abs.abs_id);
          (* Continuation meta-values are not live ownership values. *)
          List.iter (self#visit_tavalue env) abs.avalues;
          abs_or_var := None)
        else ()
    end
  in
  (* We use exceptions *)
  try
    obj#visit_env () env;
    None
  with FoundGLoanContent lc -> (
    match !abs_or_var with
    | Some abs_or_var -> Some (abs_or_var, lc)
    | None -> [%craise] span "Inconsistent state")

(** Lookup a loan content.

    The loan is referred to by a borrow id. Raises an exception if no loan was
    found. *)
let lookup_loan (span : Meta.span) (ek : exploration_kind) (l : BorrowId.id)
    (env : env) : abs_or_var_id * g_loan_content =
  match lookup_loan_opt span ek l env with
  | None -> [%craise] span "Unreachable"
  | Some res -> res

let ctx_lookup_loan_opt span ek l ctx = lookup_loan_opt span ek l ctx.env
let ctx_lookup_loan span ek l ctx = lookup_loan span ek l ctx.env

(** Update a loan content.

    The loan is referred to by a borrow id.

    This is a helper function: it might break invariants. *)
let update_loan (span : Meta.span) (ek : exploration_kind) (l : BorrowId.id)
    (nlc : loan_content) (ctx : eval_ctx) : eval_ctx =
  (* We use a reference to check that we update exactly one loan: when updating
   * inside values, we check we don't update more than one loan. Then, upon
   * returning we check that we updated at least once. *)
  let r = ref false in
  let update () : loan_content =
    [%sanity_check] span (not !r);
    r := true;
    nlc
  in

  let obj =
    object
      inherit [_] map_eval_ctx as super
      method! visit_ty _ ty = ty
      method! visit_abs_cont _ cont = cont

      method! visit_borrow_content env bc =
        match bc with
        | VSharedBorrow _ | VReservedMutBorrow _ ->
            (* Nothing specific to do *)
            super#visit_borrow_content env bc
        | VMutBorrow (bid, mv) ->
            (* Control the dive into mutable borrows *)
            if ek.enter_mut_borrows then super#visit_VMutBorrow env bid mv
            else VMutBorrow (bid, mv)

      (** We reimplement {!visit_loan_content} (rather than one of the sub-
          functions) on purpose: exhaustive matches are good for maintenance *)
      method! visit_loan_content env lc =
        match lc with
        | VSharedLoan (lid, sv) ->
            (* Shared loan: check if this is the loan we are looking for, and
               control the dive. *)
            if l = lid then update ()
            else if ek.enter_shared_loans then
              super#visit_VSharedLoan env lid sv
            else VSharedLoan (lid, sv)
        | VMutLoan bid ->
            (* Mut loan: checks if this is the loan we are looking for *)
            if bid = l then update () else super#visit_VMutLoan env bid

      (** Note that once inside the abstractions, we don't control diving (there
          are no use cases requiring finer control). Also, as we give back a
          {!loan_content} (and not an {!aloan_content}) we don't need to do
          reimplement the visit functions for the values inside the abstractions
          (rk.: there may be "concrete" values inside abstractions, so there is
          a utility in diving inside). *)
      method! visit_abs env abs =
        if ek.enter_abs then super#visit_abs env abs else abs
    end
  in

  let ctx = obj#visit_eval_ctx () ctx in
  (* Check that we updated at least one loan *)
  [%sanity_check] span !r;
  ctx

(** Update a abstraction loan content.

    The loan is referred to by a borrow id.

    This is a helper function: it might break invariants. *)
let update_aloan (span : Meta.span) (ek : exploration_kind) (l : BorrowId.id)
    (nlc : aloan_content) (ctx : eval_ctx) : eval_ctx =
  (* We use a reference to check that we update exactly one loan: when updating
   * inside values, we check we don't update more than one loan. Then, upon
   * returning we check that we updated at least once. *)
  let r = ref false in
  let update () : aloan_content =
    [%sanity_check] span (not !r);
    r := true;
    nlc
  in

  let obj =
    object
      inherit [_] map_eval_ctx as super
      method! visit_ty _ ty = ty
      method! visit_abs_cont _ cont = cont

      method! visit_aloan_content env lc =
        match lc with
        | AMutLoan (pm, bid, av) ->
            (* Sanity check: projection markers can only appear when we're doing a join *)
            [%sanity_check] span (pm = PNone);
            if bid = l then update () else super#visit_AMutLoan env pm bid av
        | ASharedLoan (pm, lid, v, av) ->
            (* Sanity check: projection markers can only appear when we're doing a join *)
            [%sanity_check] span (pm = PNone);
            if l = lid then update ()
            else super#visit_ASharedLoan env pm lid v av
        | AEndedMutLoan { given_back = _; child = _; given_back_meta = _ }
        | AEndedSharedLoan (_, _, _)
        | AIgnoredMutLoan (_, _, _)
        | AEndedIgnoredMutLoan { given_back = _; child = _; _ }
        | AIgnoredSharedLoan _ -> super#visit_aloan_content env lc

      (** Note that once inside the abstractions, we don't control diving (there
          are no use cases requiring finer control). *)
      method! visit_abs env abs =
        if ek.enter_abs then super#visit_abs env abs else abs
    end
  in

  let ctx = obj#visit_eval_ctx () ctx in
  (* Check that we updated at least one loan *)
  [%sanity_check] span !r;
  ctx

(** Lookup a borrow content from a borrow id. *)
let lookup_borrow_opt (span : Meta.span) (ek : exploration_kind)
    (l : unique_borrow_id) (ctx : eval_ctx) : g_borrow_content option =
  let obj =
    object
      inherit [_] iter_eval_ctx as super
      method! visit_ty _ _ = ()
      method! visit_abs_cont _ _ = ()

      method! visit_borrow_content env bc =
        match bc with
        | VMutBorrow (bid, mv) ->
            (* Check the borrow id and control the dive *)
            if UMut bid = l then raise (FoundGBorrowContent (Concrete bc))
            else if ek.enter_mut_borrows then super#visit_VMutBorrow env bid mv
            else ()
        | VSharedBorrow (bid, uid) ->
            (* Check the borrow id *)
            if UShared (bid, uid) = l then
              raise (FoundGBorrowContent (Concrete bc))
            else ()
        | VReservedMutBorrow (bid, uid) ->
            (* Check the borrow id *)
            if UShared (bid, uid) = l then
              raise (FoundGBorrowContent (Concrete bc))
            else ()

      method! visit_loan_content env lc =
        match lc with
        | VMutLoan bid ->
            (* Nothing special to do *) super#visit_VMutLoan env bid
        | VSharedLoan (bids, sv) ->
            (* Control the dive *)
            if ek.enter_shared_loans then super#visit_VSharedLoan env bids sv
            else ()

      method! visit_aborrow_content env bc =
        match bc with
        | AMutBorrow (pm, bid, av) ->
            (* Sanity check: projection markers can only appear when we're doing a join *)
            [%sanity_check] span (pm = PNone);
            if UMut bid = l then raise (FoundGBorrowContent (Abstract bc))
            else super#visit_AMutBorrow env pm bid av
        | ASharedBorrow (pm, bid, uid) ->
            (* Sanity check: projection markers can only appear when we're doing a join *)
            [%sanity_check] span (pm = PNone);
            if UShared (bid, uid) = l then
              raise (FoundGBorrowContent (Abstract bc))
            else super#visit_ASharedBorrow env pm bid uid
        | AIgnoredMutBorrow (_, _)
        | AEndedMutBorrow _
        | AEndedIgnoredMutBorrow
            { given_back = _; child = _; given_back_meta = _ }
        | AEndedSharedBorrow -> super#visit_aborrow_content env bc
        | AProjSharedBorrow (_, asb) -> (
            match l with
            | UShared (_, l) ->
                if borrow_in_asb l asb then
                  raise (FoundGBorrowContent (Abstract bc))
                else ()
            | UMut _ -> ())

      method! visit_abs env abs =
        if ek.enter_abs then super#visit_abs env abs else ()
    end
  in
  (* We use exceptions *)
  try
    obj#visit_eval_ctx () ctx;
    None
  with FoundGBorrowContent lc -> Some lc

(** Lookup a borrow content from a borrow id.

    Raise an borrow if no loan was found *)
let lookup_borrow (span : Meta.span) (ek : exploration_kind)
    (l : unique_borrow_id) (ctx : eval_ctx) : g_borrow_content =
  match lookup_borrow_opt span ek l ctx with
  | None -> [%craise] span "Unreachable"
  | Some lc -> lc

(** Lookup a borrow content appearing in an abstraction expression.

    Note that abstraction expressions only track *mutable* borrows, which is why
    we identify the borrow with a [borrow_id] and not a [unique_borrow_id]. *)
let lookup_eborrow_opt (span : Meta.span) (ek : exploration_kind)
    (l : borrow_id) (ctx : eval_ctx) : eborrow_content option =
  let obj =
    object
      inherit [_] iter_eval_ctx as super
      method! visit_ty _ _ = ()

      method! visit_eborrow_content env bc =
        match bc with
        | EMutBorrow (pm, bid, av) ->
            (* Sanity check: projection markers can only appear when we're doing a join *)
            [%sanity_check] span (pm = PNone);
            if bid = l then raise (FoundEBorrowContent bc)
            else super#visit_EMutBorrow env pm bid av
        | EIgnoredMutBorrow (_, _)
        | EEndedMutBorrow _ | EEndedIgnoredMutBorrow _ ->
            super#visit_eborrow_content env bc

      method! visit_abs env abs =
        if ek.enter_abs then super#visit_abs env abs else ()
    end
  in
  (* We use exceptions *)
  try
    obj#visit_eval_ctx () ctx;
    None
  with FoundEBorrowContent bc -> Some bc

(** Lookup a borrow content appearing in an abstraction expression.

    Raise an exception if no borrow was found *)
let lookup_eborrow (span : Meta.span) (ek : exploration_kind) (l : borrow_id)
    (ctx : eval_ctx) : eborrow_content =
  match lookup_eborrow_opt span ek l ctx with
  | None -> [%craise] span "Unreachable"
  | Some lc -> lc

(** Visit direct shared and reserved borrowers, excluding continuation metadata.
*)
let iter_shared_reserved_borrows (f : loan_id -> shared_borrow_id -> unit)
    (ctx : eval_ctx) : unit =
  let obj =
    object
      inherit [_] iter_eval_ctx as super
      method! visit_ty _ _ = ()
      method! visit_abs_cont _ _ = ()

      method! visit_tvalue env value =
        match value.value with
        | VBottom | VLiteral _ | VSymbolic _ -> ()
        | _ -> super#visit_tvalue env value

      method! visit_VSharedBorrow _ l uid = f l uid
      method! visit_VReservedMutBorrow _ l uid = f l uid
      method! visit_ASharedBorrow _ _ l uid = f l uid
    end
  in
  obj#visit_eval_ctx () ctx

(** Lookup all the shared and reserved borrows associated with a given loan id.
*)
let lookup_shared_reserved_borrows (l : loan_id) (ctx : eval_ctx) :
    shared_borrow_id list =
  let borrows = ref [] in
  iter_shared_reserved_borrows
    (fun l' uid -> if l' = l then borrows := uid :: !borrows)
    ctx;
  List.rev !borrows

let shared_reserved_loan_ids (ctx : eval_ctx) : BorrowId.Set.t =
  let ids = ref BorrowId.Set.empty in
  iter_shared_reserved_borrows (fun l _ -> ids := BorrowId.Set.add l !ids) ctx;
  !ids

(** Update a borrow content.

    The borrow is referred to by a borrow id.

    This is a helper function: it might break invariants. *)
let update_borrow (span : Meta.span) (ek : exploration_kind)
    (l : unique_borrow_id) (nbc : borrow_content) (ctx : eval_ctx) : eval_ctx =
  (* We use a reference to check that we update exactly one borrow: when updating
     inside values, we check we don't update more than one borrow. Then, upon
     returning we check that we updated at least once. *)
  let r = ref false in
  let update () : borrow_content =
    [%sanity_check] span (not !r);
    r := true;
    nbc
  in

  let obj =
    object
      inherit [_] map_eval_ctx as super
      method! visit_ty _ ty = ty
      method! visit_abs_cont _ cont = cont

      method! visit_borrow_content env bc =
        match bc with
        | VMutBorrow (bid, mv) ->
            (* Check the id and control dive *)
            if UMut bid = l then update ()
            else if ek.enter_mut_borrows then super#visit_VMutBorrow env bid mv
            else VMutBorrow (bid, mv)
        | VSharedBorrow (bid, sid) ->
            (* Check the id *)
            if UShared (bid, sid) = l then update ()
            else super#visit_VSharedBorrow env bid sid
        | VReservedMutBorrow (bid, sid) ->
            (* Check the id *)
            if UShared (bid, sid) = l then update ()
            else super#visit_VReservedMutBorrow env bid sid

      method! visit_loan_content env lc =
        match lc with
        | VSharedLoan (bids, sv) ->
            (* Control the dive *)
            if ek.enter_shared_loans then super#visit_VSharedLoan env bids sv
            else VSharedLoan (bids, sv)
        | VMutLoan bid ->
            (* Nothing specific to do *)
            super#visit_VMutLoan env bid

      method! visit_abs env abs =
        if ek.enter_abs then super#visit_abs env abs else abs
    end
  in

  let ctx = obj#visit_eval_ctx () ctx in
  (* Check that we updated at least one borrow *)
  [%sanity_check] span !r;
  ctx

(** Update an abstraction borrow content.

    The borrow is referred to by a borrow id.

    This is a helper function: **it might break invariants**. *)
let update_aborrow (span : Meta.span) (ek : exploration_kind)
    (l : unique_borrow_id) (nv : avalue) (nev : evalue option) (ctx : eval_ctx)
    : eval_ctx =
  (* We use a reference to check that we update exactly one borrow: when updating
     inside values, we check we don't update more than one borrow. Then, upon
     returning we check that we updated at least once. *)
  let r = ref false in
  let update () : avalue =
    [%sanity_check] span (not !r);
    r := true;
    nv
  in

  let r_evalue = ref false in
  let update_evalue () : evalue =
    [%sanity_check] span (not !r_evalue);
    r_evalue := true;
    match nev with
    | None -> [%internal_error] span
    | Some nv -> nv
  in

  let obj =
    object
      inherit [_] map_eval_ctx as super
      method! visit_ty _ ty = ty

      method! visit_ABorrow env bc =
        match bc with
        | AMutBorrow (pm, bid, av) ->
            (* Sanity check: projection markers can only appear when we're doing a join *)
            [%sanity_check] span (pm = PNone);
            if UMut bid = l then update ()
            else ABorrow (super#visit_AMutBorrow env pm bid av)
        | ASharedBorrow (pm, bid, sid) ->
            (* Sanity check: projection markers can only appear when we're doing a join *)
            [%sanity_check] span (pm = PNone);
            if UShared (bid, sid) = l then update ()
            else ABorrow (super#visit_ASharedBorrow env pm bid sid)
        | AIgnoredMutBorrow _
        | AEndedMutBorrow _
        | AEndedSharedBorrow
        | AEndedIgnoredMutBorrow _ -> super#visit_ABorrow env bc
        | AProjSharedBorrow (pm, asb) -> (
            match l with
            | UShared (_, l) ->
                if borrow_in_asb l asb then update ()
                else ABorrow (super#visit_AProjSharedBorrow env pm asb)
            | UMut _ -> super#visit_ABorrow env bc)

      method! visit_EBorrow env bc =
        match bc with
        | EMutBorrow (pm, bid, av) ->
            (* Sanity check: projection markers can only appear when we're doing a join *)
            [%sanity_check] span (pm = PNone);
            if UMut bid = l then update_evalue ()
            else EBorrow (super#visit_EMutBorrow env pm bid av)
        | EIgnoredMutBorrow _ | EEndedMutBorrow _ | EEndedIgnoredMutBorrow _ ->
            super#visit_EBorrow env bc

      method! visit_abs env abs =
        if ek.enter_abs then super#visit_abs env abs else abs
    end
  in

  let ctx = obj#visit_eval_ctx () ctx in
  (* Check that we updated at least one borrow *)
  [%cassert] span !r "No borrow was updated";
  ctx

type mut_borrow_or_shared_loan_id =
  | MutBorrow of borrow_id  (** Mutable borrow *)
  | SharedLoan of loan_id  (** Shared loan *)

type outer = {
  abs_id : AbsId.id option;
  level : int;
  borrow_loan : mut_borrow_or_shared_loan_id option;
}

(** Auxiliary function: see its usage in [end_borrow_get_borrow_in_value] *)
let update_outer_borrow (outer : outer) (x : mut_borrow_or_shared_loan_id) :
    outer =
  { outer with borrow_loan = update_if_none outer.borrow_loan x }

(** Return the first loan we find in a value *)
let get_first_loan_in_value (v : tvalue) : loan_content option =
  let obj =
    object
      inherit [_] iter_tvalue
      method! visit_loan_content _ lc = raise (FoundLoanContent lc)
    end
  in
  (* We use exceptions *)
  try
    obj#visit_tvalue () v;
    None
  with FoundLoanContent lc -> Some lc

(** Return the first loan we find in a list of values *)
let get_first_loan_in_values (vs : tvalue list) : loan_content option =
  let obj =
    object
      inherit [_] iter_tvalue
      method! visit_loan_content _ lc = raise (FoundLoanContent lc)
    end
  in
  (* We use exceptions *)
  try
    List.iter (obj#visit_tvalue ()) vs;
    None
  with FoundLoanContent lc -> Some lc

(** Return the first borrow we find in a value *)
let get_first_borrow_in_value (v : tvalue) : borrow_content option =
  let obj =
    object
      inherit [_] iter_tvalue
      method! visit_borrow_content _ bc = raise (FoundBorrowContent bc)
    end
  in
  (* We use exceptions *)
  try
    obj#visit_tvalue () v;
    None
  with FoundBorrowContent bc -> Some bc

(** Return the first loan or borrow content we find in a value (starting with
    the outer ones).

    [with_borrows]:
    - if [true]: return the first loan or borrow we find
    - if [false]: return the first loan we find, do not dive into borrowed
      values *)
let get_first_outer_loan_or_borrow_in_value (with_borrows : bool) (v : tvalue) :
    loan_or_borrow_content option =
  let obj =
    object
      inherit [_] iter_tvalue

      method! visit_borrow_content _ bc =
        if with_borrows then raise (FoundBorrowContent bc) else ()

      method! visit_loan_content _ lc = raise (FoundLoanContent lc)
    end
  in
  (* We use exceptions *)
  try
    obj#visit_tvalue () v;
    None
  with
  | FoundLoanContent lc -> Some (LoanContent lc)
  | FoundBorrowContent bc -> Some (BorrowContent bc)

let proj_borrows_intersects_proj_loans (span : Meta.span) (ctx : eval_ctx)
    (proj_borrows : RegionId.Set.t * symbolic_value_id * rty)
    (proj_loans : RegionId.Set.t * symbolic_value_id * rty) : bool =
  let b_regions, b_sv_id, b_ty = proj_borrows in
  let l_regions, l_sv_id, l_ty = proj_loans in
  if b_sv_id = l_sv_id then
    projections_intersect span ctx l_regions l_ty b_regions b_ty
  else false

(** Result of looking up aproj_borrows which intersect a given aproj_loans in
    the context.

    A loan projection can cover several disjoint borrow projections: for
    example, a container of [(&'a T, &'a U)] can be consumed by a call with
    separate region groups for its two fields. Non-shared borrow projections
    must be pairwise disjoint, not unique for the whole symbolic value. A
    shared projector may overlap a non-shared projector whose projected
    regions only hold shared borrows: both only hold copies of shared
    references (see [Invariants.check_symbolic_values]).

    Return one non-shared projector when present. Ending it may give back new
    loans, so the caller must retry the lookup afterwards. Otherwise return all
    shared projectors, which may overlap.

    The result contains the ids of the abstractions in which the projectors were
    found, as well as the projection types used in those abstractions. *)
type looked_up_aproj_borrows =
  | NonSharedProj of AbsId.id * rty * abs_level
  | SharedProjs of (AbsId.id * rty * abs_level) list

(** Lookup the aproj_borrows (including aproj_shared_borrows) over a symbolic
    value which intersect a given set of regions.

    [lookup_shared]: if [true] also explore projectors over shared values,
    otherwise ignore.

    This is a helper function. *)
let lookup_intersecting_aproj_borrows_opt (span : Meta.span)
    (lookup_shared : bool) (regions : RegionId.Set.t) (proj : symbolic_proj)
    (ctx : eval_ctx) : looked_up_aproj_borrows option =
  let found : looked_up_aproj_borrows option ref = ref None in
  (* Retain the actual owned regions and projection types when checking
     uniqueness. Comparing each borrower only with the queried loan cannot
     distinguish disjoint owners of different positions in the same value. *)
  let seen = ref [] in
  (* A consuming projector is linear if it moves mutable borrows *)
  let copyable (shared : bool) (owned : RegionId.Set.t) (ty : rty) : bool =
    shared
    || not (ty_has_mut_borrow_for_region_in_set ctx.type_ctx.type_infos owned ty)
  in
  let check_add_proj_borrows (is_shared : bool) (abs : abs) (level : abs_level)
      (proj' : symbolic_proj) =
    if
      proj_borrows_intersects_proj_loans span ctx
        (abs.regions.owned, proj'.sv_id, proj'.proj_ty)
        (regions, proj.sv_id, proj.proj_ty)
    then (
      List.iter
        (fun (shared, owned, ty) ->
          [%cassert] span
            ((is_shared || shared)
             && copyable is_shared abs.regions.owned proj'.proj_ty
             && copyable shared owned ty
            || not
                 (projections_intersect span ctx abs.regions.owned proj'.proj_ty
                    owned ty))
            "Overlapping non-shared borrow projections")
        !seen;
      seen := (is_shared, abs.regions.owned, proj'.proj_ty) :: !seen;
      let x = (abs.abs_id, proj'.proj_ty, level) in
      match (!found, is_shared) with
      | None, true -> found := Some (SharedProjs [ x ])
      | Some (SharedProjs projs), true ->
          found := Some (SharedProjs (x :: projs))
      | (None | Some (SharedProjs _)), false ->
          found := Some (NonSharedProj (abs.abs_id, proj'.proj_ty, level))
      | Some (NonSharedProj _), _ -> ())
  in
  let visitor =
(*
```ocaml
*)
    object (self)
(*
```
*)
      inherit [_] iter_eval_ctx_with_abs_levels as super

      method incr_level al =
        match al with
        | Some (abs, level) -> Some (abs, level + 1)
        | None -> [%internal_error] span

      method! visit_abs _ abs = super#visit_abs (Some (abs, 0)) abs

(*
```ocaml
*)
      method! visit_ATransportedProj state transport child =
        let state = Option.map
          (fun (abs, level) -> (carrier_coordinate_abs transport abs, level))
          state in
        self#visit_aproj state child

      method! visit_ATransportedValue state transport child =
        let state = Option.map
          (fun (abs, level) -> (carrier_coordinate_abs transport abs, level))
          state in
        self#visit_tavalue state child
(*
```
*)

      method! visit_abstract_shared_borrow abs asb =
        (* Explore *)
        if lookup_shared then
          let abs, lvl = Option.get abs in
          match asb with
          | AsbBorrow _ -> ()
          | AsbProjReborrows proj' ->
              let is_shared = true in
              check_add_proj_borrows is_shared abs lvl proj'
        else ()

      method! visit_aproj abs sproj =
        (let abs, lvl = Option.get abs in
         match sproj with
         | APendingLoans _ | APendingSymbolicLoans _
         | AProjLoans _
         | AEndedProjLoans _
         | AEndedProjBorrows _
(*
```ocaml
*)
         | ATransportedProj _ | AEmpty -> ()
(*
```
*)
         | AProjBorrows { proj = proj'; _ } ->
             let is_shared = false in
             check_add_proj_borrows is_shared abs lvl proj');
        super#visit_aproj abs sproj
    end
  in
  (* Visit *)
  visitor#visit_eval_ctx None ctx;
  (* Return *)
  !found

(** Lookup the aproj_borrows (not aproj_borrows_shared!) over a symbolic value
    which intersects a given set of regions.

    If several disjoint projectors intersect the queried loan, return the first.
    The caller must repeat the lookup after ending that projector.

    Returns the id of the owning abstraction, and the projection type used in
    this abstraction. *)
let lookup_intersecting_aproj_borrows_not_shared_opt (span : Meta.span)
    (regions : RegionId.Set.t) (proj : symbolic_proj) (ctx : eval_ctx) :
    (AbsId.id * rty * abs_level) option =
  let lookup_shared = false in
  match
    lookup_intersecting_aproj_borrows_opt span lookup_shared regions proj ctx
  with
  | None -> None
  | Some (NonSharedProj (abs_id, rty, level)) -> Some (abs_id, rty, level)
  | _ -> [%craise] span "Unexpected"

(** Classify projections affected by giving back a value. Besides owning a
    projected position or an outliving position, a projection of the same
    symbolic value may own an unrelated position. In particular, absence of an
    owned intersection does not imply an outlive intersection. *)
let projection_intersections span ctx proj_regions proj_ty =
  let outlive_regions =
    lazy
      (TypesAnalysis.compute_outlive_proj_ty (Some span) ctx.type_ctx.type_decls
         ctx.type_ctx.type_infos proj_regions proj_ty)
  in
  fun regions ty ->
    let owned =
      projections_intersect span ctx proj_regions proj_ty regions ty
    in
    let outlive =
      projections_intersect span ctx
        (Lazy.force outlive_regions)
        proj_ty regions ty
    in
    [%sanity_check] span ((not owned) || not outlive);
    (owned, outlive)

(** Similar to {!lookup_intersecting_aproj_borrows_opt}, but updates the values.

    This is a helper function: **it might break invariants**.

    [include_ancestors]: when exploring an abstraction and computing projection
    intersections, use the ancestor regions. [include_owned]: when exploring an
    abstraction and computing projection intersections, use the owned regions.

    Note that we take care of also updating abstraction regions (we only require
    a function to update mutable borrows in expressions and no function to
    update shared borrows because abstraction expressions do not track shared
    borrows/loans). *)
let update_intersecting_aproj_borrows (span : Meta.span)
    ~(fail_if_unchanged : bool) ~(include_owned : bool)
    ~(include_outlive : bool)
    ~(update_shared :
       (owned:bool ->
       outlive:bool ->
       abs ->
       symbolic_proj ->
       abstract_shared_borrows)
       option)
    ~(update_mut : owned:bool -> outlive:bool -> abs -> aproj_borrows -> aproj)
    ~(update_emut : owned:bool -> outlive:bool -> abs -> eproj_borrows -> eproj)
    (proj_regions : RegionId.Set.t) (proj : symbolic_proj) (ctx : eval_ctx) :
    eval_ctx =
  (* Small helpers for sanity checks *)
  let shared = ref None in
  let add_shared () =
    match !shared with
    | None -> shared := Some true
    | Some b -> [%sanity_check] span b
  in
  let set_non_shared () =
    match !shared with
    | None -> shared := Some false
    | Some _ -> [%craise] span "Found unexpected intersecting proj_borrows"
  in
  let intersections =
    projection_intersections span ctx proj_regions proj.proj_ty
  in
  (* Return: [(intersects_owned, intersects_outlive)] *)
  let check_proj_borrows_core is_shared abs (proj'_sv_id : symbolic_value_id)
      (proj'_ty : ty) : bool * bool =
    if proj.sv_id = proj'_sv_id then (
      let intersects_owned, intersects_outlive =
        intersections abs.regions.owned proj'_ty
      in
      (* Only affected positions receive the given-back value. Disjoint sibling
         projections keep their existing loans and region identities. *)
      let intersects_outlive = include_outlive && intersects_outlive in
      let intersects_owned = include_owned && intersects_owned in
      let intersects = intersects_owned || intersects_outlive in
      if intersects then if is_shared then add_shared () else set_non_shared ();
      (intersects_owned, intersects_outlive))
    else (false, false)
  in

  let check_proj_borrows is_shared abs (proj' : symbolic_proj) : bool * bool =
    check_proj_borrows_core is_shared abs proj'.sv_id proj'.proj_ty
  in
  let check_eproj_borrows is_shared abs (proj' : esymbolic_proj) : bool * bool =
    check_proj_borrows_core is_shared abs proj'.sv_id proj'.proj_ty
  in
  (* The visitor *)
  let obj =
    object
(*
```ocaml
*)
      inherit [_] map_eval_ctx_carrier_coordinates as super
(*
```
*)
      method! visit_abs _ abs = super#visit_abs (Some abs) abs

      method! visit_abstract_shared_borrows abs asb =
        (* Sanity check *)
        (match !shared with
        | Some b -> [%sanity_check] span b
        | _ -> ());
        (* Explore *)
        match update_shared with
        | Some update_shared ->
            let abs = Option.get abs in
            let update (asb : abstract_shared_borrow) : abstract_shared_borrows
                =
              match asb with
              | AsbBorrow _ -> [ asb ]
              | AsbProjReborrows proj' ->
                  let is_shared = true in
                  let owned, outlive = check_proj_borrows is_shared abs proj' in
                  if owned || outlive then
                    update_shared ~owned ~outlive abs proj'
                  else [ asb ]
            in
            List.concat (List.map update asb)
        | _ -> asb

      method! visit_aproj abs sproj =
        match sproj with
(*
```ocaml
*)
        | ATransportedProj _ | APendingLoans _ | APendingSymbolicLoans _
(*
```
*)
        | AProjLoans _
        | AEndedProjLoans _
        | AEndedProjBorrows _
        | AEmpty -> super#visit_aproj abs sproj
        | AProjBorrows proj' ->
            let abs = Option.get abs in
            let is_shared = true in
            let owned, outlive = check_proj_borrows is_shared abs proj'.proj in
            if owned || outlive then update_mut ~owned ~outlive abs proj'
            else super#visit_aproj (Some abs) sproj

      method! visit_eproj abs sproj =
        match sproj with
(*
```ocaml
*)
        | ETransportedProj _ | EPendingLoans _ | EPendingSymbolicLoans _
(*
```
*)
        | EProjLoans _
        | EEndedProjLoans _
        | EEndedProjBorrows _
        | EEmpty -> super#visit_eproj abs sproj
        | EProjBorrows proj' ->
            let abs = Option.get abs in
            let is_shared = true in
            let owned, outlive = check_eproj_borrows is_shared abs proj'.proj in
            if owned || outlive then update_emut ~owned ~outlive abs proj'
            else super#visit_eproj (Some abs) sproj
    end
  in
  (* Apply *)
  let ctx = obj#visit_eval_ctx None ctx in
  (* Check that we updated the context at least once *)
  if fail_if_unchanged && Option.is_none !shared then
    [%craise] span
      ("Context was not updated for projection "
      ^ symbolic_proj_to_string ctx proj
      ^ "\n- selected regions: "
      ^ RegionId.Set.to_string None proj_regions
      ^ "\n- include owned/outlive: "
      ^ string_of_bool include_owned
      ^ "/"
      ^ string_of_bool include_outlive
      ^ "\n- context:\n" ^ eval_ctx_to_string ctx);
  (* Return *)
  ctx

(** Simply calls {!update_intersecting_aproj_borrows} to remove the proj_borrows
    over shared values.

    This is a helper function: it might break invariants. *)
let remove_intersecting_aproj_borrows_shared (span : Meta.span)
    ~(include_owned : bool) ~(include_outlive : bool) (regions : RegionId.Set.t)
    (proj : symbolic_proj) (ctx : eval_ctx) : eval_ctx =
  [%ltrace
    "- regions: "
    ^ RegionId.Set.to_string None regions
    ^ "\n- proj: "
    ^ symbolic_proj_to_string ctx proj
    ^ "\n- ctx:\n" ^ eval_ctx_to_string ctx];
  (* Small helpers *)
  let update_shared = Some (fun ~owned:_ ~outlive:_ _ _ -> []) in
  let update_mut ~owned:_ ~outlive:_ _ = [%craise] span "Unexpected" in
  let update_emut ~owned:_ ~outlive:_ _ = [%craise] span "Unexpected" in
  (* Update

     We set [fail_if_unchanged] to false because if the borrow projectors we're
     looking for may be in the concrete environment, in which case we will leave
     it unchanged.
  *)
  update_intersecting_aproj_borrows span ~fail_if_unchanged:false ~include_owned
    ~include_outlive ~update_shared ~update_mut ~update_emut regions proj ctx

(** Updates the proj_loans intersecting some projection.

    This is a helper function: it might break invariants.

    Note that we can update more than one projector of loans! Consider the
    following example:
    {[
      fn f<'a, 'b>(...) -> (&'a mut u32, &'b mut u32));
      fn g<'c>(&'c mut u32, &'c mut u32);

      let p = f(...);
      g(move p);

      // Symbolic context after the call to g:
      // abs'a {'a} { [s@0 <: (&'a mut u32, &'b mut u32)] }
      // abs'b {'b} { [s@0 <: (&'a mut u32, &'b mut u32)] }
      //
      // abs'c {'c} { (s@0 <: (&'c mut u32, &'c mut u32)) }
    ]}

    Note that for sanity, this function checks that we update *at least* one
    projector of loans.

    [proj_ty]: shouldn't contain erased regions.

    [subst]: takes as parameters the abstraction in which we perform the
    substitution and the list of given back values at the projector of loans
    where we perform the substitution (see the fields in {!Values.AProjLoans}).
    Note that the symbolic value at this place is necessarily equal to [sv],
    which is why we don't give it as parameters.

    [include_ancestors]: when exploring an abstraction and computing projection
    intersections, use the ancestor regions. [include_owned]: when exploring an
    abstraction and computing projection intersections, use the owned regions.
*)
let update_intersecting_aproj_loans (span : Meta.span)
    ~(fail_if_unchanged : bool) ~(include_owned : bool)
    ~(include_outlive : bool) (proj_regions : RegionId.Set.t)
    (proj : symbolic_proj)
    (subst : owned:bool -> outlive:bool -> abs -> aproj_loans -> aproj)
    (esubst : owned:bool -> outlive:bool -> abs -> eproj_loans -> eproj)
    (ctx : eval_ctx) : eval_ctx =
  (* *)
  [%sanity_check] span (ty_is_rty ctx.type_ctx.type_infos proj.proj_ty);
  (* Small helpers for sanity checks *)
  let updated = ref false in
  let update ~owned ~outlive abs aproj_loans : aproj =
    (* Note that we can update more than once! *)
    updated := true;
    subst ~owned ~outlive abs aproj_loans
  in
  let updated_evalue = ref false in
  let update_evalue ~owned ~outlive abs aproj_loans : eproj =
    (* Note that we can update more than once! *)
    updated_evalue := true;
    esubst ~owned ~outlive abs aproj_loans
  in
  let intersections =
    projection_intersections span ctx proj_regions proj.proj_ty
  in

  (* The visitor *)
  let obj =
    object
(*
```ocaml
*)
      inherit [_] map_eval_ctx_carrier_coordinates as super
(*
```
*)
      method! visit_abs _ abs = super#visit_abs (Some abs) abs

      method! visit_aproj abs sproj =
        match sproj with
(*
```ocaml
*)
        | ATransportedProj _ | APendingLoans _ | APendingSymbolicLoans _
(*
```
*)
        | AProjBorrows _
        | AEndedProjLoans _
        | AEndedProjBorrows _
        | AEmpty -> super#visit_aproj abs sproj
        | AProjLoans aproj_loans ->
            let abs = Option.get abs in
            if proj.sv_id = aproj_loans.proj.sv_id then
              let owned, outlive =
                intersections abs.regions.owned aproj_loans.proj.proj_ty
              in
              let outlive = include_outlive && outlive in
              let owned = include_owned && owned in
              if owned || outlive then update ~owned ~outlive abs aproj_loans
              else super#visit_aproj (Some abs) sproj
            else super#visit_aproj (Some abs) sproj

      method! visit_eproj abs sproj =
        match sproj with
(*
```ocaml
*)
        | ETransportedProj _ | EPendingLoans _ | EPendingSymbolicLoans _
(*
```
*)
        | EProjBorrows _
        | EEndedProjLoans _
        | EEndedProjBorrows _
        | EEmpty -> super#visit_eproj abs sproj
        | EProjLoans aproj_loans ->
            let abs = Option.get abs in
            if proj.sv_id = aproj_loans.proj.sv_id then
              let owned, outlive =
                intersections abs.regions.owned aproj_loans.proj.proj_ty
              in
              let outlive = include_outlive && outlive in
              let owned = include_owned && owned in
              if owned || outlive then
                update_evalue ~owned ~outlive abs aproj_loans
              else super#visit_eproj (Some abs) sproj
            else super#visit_eproj (Some abs) sproj
    end
  in
  (* Apply *)
  let ctx = obj#visit_eval_ctx None ctx in
  (* Check that we updated the context at least once *)
  [%sanity_check] span ((not fail_if_unchanged) || !updated);
  (* Return *)
  ctx

(** Helper function: lookup an {!constructor:Values.aproj.AProjLoans} by using
    an abstraction id, sub-abstraction level and symbolic projection.

    We return the information from the looked up projector of loans. See the
    fields in {!constructor:Values.aproj.AProjLoans} (we don't return the
    symbolic value, because it is equal to [proj.sv_id]).

    Sanity check: the complete owner key (abstraction, level, symbolic value,
    selected region positions) identifies at most one projector. *)
let lookup_aproj_loans_opt (span : Meta.span) (abs_id : AbsId.id) (level : int)
    (proj : symbolic_proj) (ctx : eval_ctx) :
    (aproj_loans * eproj_loans option) option =
  (* Small helpers for sanity checks *)
  let found = ref None in
  let set_found x =
    (* There is at most one projector which corresponds to the description *)
    [%sanity_check] span (Option.is_none !found);
    found := Some x
  in
  let found_eproj = ref None in
  let set_found_eproj x =
    (* There is at most one projector which corresponds to the description *)
    [%sanity_check] span (Option.is_none !found_eproj);
    found_eproj := Some x
  in
  let matches (owned, current_level) sv_id proj_ty =
    current_level = level && sv_id = proj.sv_id
    && projection_masks_equal span ctx owned proj.proj_ty proj_ty
  in
  (* The visitor *)
  let obj =
    object (self)
      inherit [_] iter_eval_ctx_with_abs_levels as super
      method incr_level (owned, level) = (owned, level + 1)
(*
```ocaml
*)
      method! visit_ATransportedProj (_, level) transport child =
        self#visit_aproj (transport.current_regions, level) child

      method! visit_ETransportedProj (_, level) transport child =
        self#visit_eproj (transport.current_regions, level) child

      method! visit_ATransportedValue (_, level) transport child =
        self#visit_tavalue (transport.current_regions, level) child

      method! visit_ETransportedValue (_, level) transport child =
        self#visit_tevalue (transport.current_regions, level) child
(*
```
*)

      method! visit_abs _ abs =
        if abs.abs_id = abs_id then super#visit_abs (abs.regions.owned, 0) abs
        else ()

      method! visit_aproj state sproj =
        (match sproj with
        | ATransportedProj _ | APendingLoans _ | APendingSymbolicLoans _
        | AProjBorrows _
        | AEndedProjLoans _
        | AEndedProjBorrows _
        | AEmpty -> ()
        | AProjLoans aproj_loan ->
            if matches state aproj_loan.proj.sv_id aproj_loan.proj.proj_ty then
              set_found aproj_loan
            else ());
        super#visit_aproj state sproj

      method! visit_eproj state sproj =
        (match sproj with
        | ETransportedProj _ | EPendingLoans _ | EPendingSymbolicLoans _
        | EProjBorrows _
        | EEndedProjLoans _
        | EEndedProjBorrows _
        | EEmpty -> ()
        | EProjLoans aproj_loan ->
            if matches state aproj_loan.proj.sv_id aproj_loan.proj.proj_ty then
              set_found_eproj aproj_loan
            else ());
        super#visit_eproj state sproj
    end
  in
  (* Apply *)
  obj#visit_eval_ctx (RegionId.Set.empty, 0) ctx;
  (* Return *)
  [%sanity_check] span (!found_eproj = None || Option.is_some !found);
  match !found with
  | None -> None
  | Some aproj -> Some (aproj, !found_eproj)

let lookup_aproj_loans (span : Meta.span) (abs_id : AbsId.id) (level : int)
    (proj : symbolic_proj) (ctx : eval_ctx) : aproj_loans * eproj_loans option =
  Option.get (lookup_aproj_loans_opt span abs_id level proj ctx)

(** Helper function: might break invariants.

    Update a projector identified by its abstraction, sub-abstraction level,
    symbolic value and selected region positions.

    Sanity check: the complete owner key identifies exactly one projector.

    This function updates abstraction values *and* abstraction expressions. *)
let update_aproj_loans (span : Meta.span) (abs_id : AbsId.id) (level : int)
    (proj : symbolic_proj) (nproj : aproj) (neproj : eproj option)
    (ctx : eval_ctx) : eval_ctx =
  (* Small helpers for sanity checks *)
  let found = ref false in
  let update () =
    (* We update at most once *)
    [%sanity_check] span (not !found);
    found := true;
    nproj
  in
  let found_eproj = ref false in
  let update_eproj () =
    (* We update at most once *)
    [%sanity_check] span (not !found_eproj);
    found_eproj := true;
    match neproj with
    | None -> [%internal_error] span
    | Some proj -> proj
  in
  let matches (owned, current_level) sv_id proj_ty =
    current_level = level && sv_id = proj.sv_id
    && projection_masks_equal span ctx owned proj.proj_ty proj_ty
  in
  (* The visitor *)
  let obj =
    object (self)
      inherit [_] map_eval_ctx_with_abs_levels as super
      method incr_level (owned, level) = (owned, level + 1)
(*
```ocaml
*)
      method! visit_ATransportedProj (_, level) transport child =
        ATransportedProj
          (transport, self#visit_aproj (transport.current_regions, level) child)

      method! visit_ETransportedProj (_, level) transport child =
        ETransportedProj
          (transport, self#visit_eproj (transport.current_regions, level) child)

      method! visit_ATransportedValue (_, level) transport child =
        ATransportedValue
          (transport, self#visit_tavalue (transport.current_regions, level) child)

      method! visit_ETransportedValue (_, level) transport child =
        ETransportedValue
          (transport, self#visit_tevalue (transport.current_regions, level) child)
(*
```
*)

      method! visit_abs _ abs =
        if abs.abs_id = abs_id then super#visit_abs (abs.regions.owned, 0) abs
        else abs

      method! visit_aproj state sproj =
        match sproj with
        | ATransportedProj _ | APendingLoans _ | APendingSymbolicLoans _
        | AProjBorrows _
        | AEndedProjLoans _
        | AEndedProjBorrows _
        | AEmpty -> super#visit_aproj state sproj
        | AProjLoans { proj = abs_proj; _ } ->
            if matches state abs_proj.sv_id abs_proj.proj_ty then update ()
            else super#visit_aproj state sproj

      method! visit_eproj state sproj =
        match sproj with
        | ETransportedProj _ | EPendingLoans _ | EPendingSymbolicLoans _
        | EProjBorrows _
        | EEndedProjLoans _
        | EEndedProjBorrows _
        | EEmpty -> super#visit_eproj state sproj
        | EProjLoans { proj = abs_proj; _ } ->
            if matches state abs_proj.sv_id abs_proj.proj_ty then
              update_eproj ()
            else super#visit_eproj state sproj
    end
  in
  (* Apply *)
  let ctx = obj#visit_eval_ctx (RegionId.Set.empty, 0) ctx in
  (* Sanity check *)
  [%sanity_check] span !found;
  (* Return *)
  ctx

(** Helper function: might break invariants.

    Update a projector over borrows. The projector is identified by a symbolic
    value and an abstraction id.

    Sanity check: we check that there is exactly one projector which corresponds
    to the couple (abstraction id, symbolic value).

    TODO: factorize with {!update_aproj_loans}? *)
let update_aproj_borrows (span : Meta.span) (abs_id : AbsId.id)
    (sv : symbolic_value) (nproj : aproj) (neproj : eproj) (ctx : eval_ctx) :
    eval_ctx =
  (* Small helpers for sanity checks *)
  let found = ref false in
  let update () =
    (* We update at most once *)
    [%sanity_check] span (not !found);
    found := true;
    nproj
  in
  let found_eproj = ref false in
  let update_eproj () =
    (* We update at most once *)
    [%sanity_check] span (not !found_eproj);
    found_eproj := true;
    neproj
  in
  (* The visitor *)
  let obj =
    object
      inherit [_] map_eval_ctx_carrier_coordinates as super

      method! visit_abs _ abs =
        if abs.abs_id = abs_id then super#visit_abs (Some abs) abs else abs

      method! visit_aproj (abs : abs option) sproj =
        match sproj with
        | ATransportedProj _ | APendingLoans _ | APendingSymbolicLoans _
        | AProjLoans _
        | AEndedProjLoans _
        | AEndedProjBorrows _
        | AEmpty -> super#visit_aproj abs sproj
        | AProjBorrows { proj = abs_proj; _ } ->
            let abs = Option.get abs in
            [%sanity_check] span (abs.abs_id = abs_id);
            if abs_proj.sv_id = sv.sv_id then update ()
            else super#visit_aproj (Some abs) sproj

      method! visit_eproj (abs : abs option) sproj =
        match sproj with
        | ETransportedProj _ | EPendingLoans _ | EPendingSymbolicLoans _
        | EProjLoans _
        | EEndedProjLoans _
        | EEndedProjBorrows _
        | EEmpty -> super#visit_eproj abs sproj
        | EProjBorrows { proj = abs_proj; _ } ->
            let abs = Option.get abs in
            [%sanity_check] span (abs.abs_id = abs_id);
            if abs_proj.sv_id = sv.sv_id then update_eproj ()
            else super#visit_eproj (Some abs) sproj
    end
  in
  (* Apply *)
  let ctx = obj#visit_eval_ctx None ctx in
  (* Sanity check *)
  [%sanity_check] span !found;
  (* Return *)
  ctx

(** Helper function: might break invariants.

    Converts an {!Values.aproj.AProjLoans} to an
    {!Values.aproj.AEndedProjLoans}. The projector is identified by its
    abstraction, sub-abstraction level, symbolic value and owned region mask.

    **Remark:** the loan projector is allowed not to exist in the context
    anymore, in which case this function does nothing. *)
let update_aproj_loans_to_ended (span : Meta.span) (abs_id : AbsId.id)
    (level : int) (proj : symbolic_proj) (ctx : eval_ctx) : eval_ctx =
  let sv_id = proj.sv_id in
  (* Lookup the projector of loans *)
  match lookup_aproj_loans_opt span abs_id level proj ctx with
  | Some ({ proj = _; consumed; borrows }, eproj) ->
      (* Create the new value for the projector *)
      let nproj = AEndedProjLoans { proj = sv_id; consumed; borrows } in
      let neproj =
        match eproj with
        | Some { proj = _; consumed; borrows } ->
            Some (EEndedProjLoans { proj = sv_id; consumed; borrows })
        | None -> None
      in
      (* Insert it *)
      let ctx = update_aproj_loans span abs_id level proj nproj neproj ctx in
      (* Return *)
      ctx
  | _ ->
      (* The loan projector doesn't exist anymore: we have nothing to do *)
      ctx

let no_aproj_over_symbolic_in_context (span : Meta.span)
    (sv_id : symbolic_value_id) (ctx : eval_ctx) : unit =
  (* The visitor *)
  let obj =
    object
      inherit [_] iter_eval_ctx as super

      method! visit_aproj env sproj =
        (match sproj with
        | ATransportedProj _ | APendingLoans _ | APendingSymbolicLoans _
        | AEndedProjLoans _ | AEndedProjBorrows _ | AEmpty ->
            ()
        | AProjLoans { proj = abs_proj; _ }
        | AProjBorrows { proj = abs_proj; _ } ->
            if abs_proj.sv_id = sv_id then raise Found else ());
        super#visit_aproj env sproj

      method! visit_eproj env sproj =
        (match sproj with
        | ETransportedProj _ | EPendingLoans _ | EPendingSymbolicLoans _
        | EEndedProjLoans _ | EEndedProjBorrows _ | EEmpty ->
            ()
        | EProjLoans { proj = abs_proj; _ }
        | EProjBorrows { proj = abs_proj; _ } ->
            if abs_proj.sv_id = sv_id then raise Found else ());
        super#visit_eproj env sproj
    end
  in
  (* Apply *)
  try obj#visit_eval_ctx () ctx
  with Found ->
    [%ltrace
      "update_aproj_loan_to_ended failed:\n- sv_id: "
      ^ SymbolicValueId.to_string sv_id
      ^ "\n- ctx:\n" ^ eval_ctx_to_string ctx];
    [%craise] span "update_aproj_loans_to_ended: failed"

let abs_has_non_ended_eborrows_or_eloans ~(borrows : bool) (ctx : eval_ctx)
    (abs : abs) (min_level : int) : bool =
  let opt_raise ~(is_borrow : bool) (level : int) =
    if level >= min_level && is_borrow = borrows then raise Found
  in
  let has_mut_projection_ty =
    ty_has_mut_borrow_for_region_in_set ctx.type_ctx.type_infos
      abs.regions.owned
  in
  let visited = ValuesUtils.ScopedEvalueTbl.create 16 in
  let visitor =
    object
      inherit [_] iter_abs_with_levels as super
      method incr_level level = level + 1
      method! visit_ty _ _ = ()

      method! visit_tevalue level value =
        (* The same node may be below the threshold at one ownership level
           and above it at another. Never deduplicate by node alone. *)
        let key = (level, value) in
        if not (ValuesUtils.ScopedEvalueTbl.mem visited key) then (
          ValuesUtils.ScopedEvalueTbl.add visited key ();
          super#visit_tevalue level value)

      method! visit_EMutBorrow level pm bid child =
        opt_raise ~is_borrow:true level;
        super#visit_EMutBorrow level pm bid child

      method! visit_EMutLoan level pm bid child =
        opt_raise ~is_borrow:false level;
        super#visit_EMutLoan level pm bid child

      method! visit_EProjBorrows level (proj : eproj_borrows) =
        if has_mut_projection_ty proj.proj.proj_ty then
          opt_raise ~is_borrow:true level;
        super#visit_EProjBorrows level proj

      method! visit_EProjLoans level (proj : eproj_loans) =
        if has_mut_projection_ty proj.proj.proj_ty then
          opt_raise ~is_borrow:false level;
        super#visit_EProjLoans level proj
    end
  in
  try
    visitor#visit_abs 0 abs;
    false
  with Found -> true

let abs_has_non_ended_eborrows (ctx : eval_ctx) (abs : abs) (min_level : int) :
    bool =
  abs_has_non_ended_eborrows_or_eloans ~borrows:true ctx abs min_level

let abs_has_non_ended_eloans (ctx : eval_ctx) (abs : abs) (min_level : int) :
    bool =
  abs_has_non_ended_eborrows_or_eloans ~borrows:false ctx abs min_level

(** Helper function

    Return the loan (aloan, loan, proj_loans over a symbolic value) we find in
    an abstraction **for a given level**, if there is.

    **Remark:** we don't take the *ignored* mut/shared loans into account. *)
let get_first_non_ignored_aloan_in_abs (span : Meta.span) (abs : abs)
    (min_level : int) (max_level : int) :
    (borrow_id_or_proj_symbolic_value * RegionId.Set.t) option =
  let level_ref = ref None in
  let projected_regions = ref abs.regions.owned in
  let check_if_report (level : int) : bool =
    let report = level >= min_level && (max_level < 0 || level <= max_level) in
    if report then level_ref := Some level;
    report
  in
  (* Explore to find a loan *)
  let visitor =
    object (self)
      inherit [_] iter_abs_with_levels as super
      method! visit_ty _ _ = ()
      method! visit_abs_cont _ _ = ()
      method incr_level level = level + 1
(*
```ocaml
*)
      method! visit_ATransportedProj level transport child =
        let previous = !projected_regions in
        projected_regions := transport.current_regions;
        self#visit_aproj level child;
        projected_regions := previous

      method! visit_ATransportedValue level transport child =
        let previous = !projected_regions in
        projected_regions := transport.current_regions;
        self#visit_tavalue level child;
        projected_regions := previous
(*
```
*)

      method! visit_AEndedSharedLoan level _pm _sv child =
        (* The concrete payload is released by the outer loan, not owned by
           its region. Only the child loan projectors belong to this abs. *)
        self#visit_tavalue level child

      method! visit_aloan_content level lc =
        match lc with
        | AMutLoan (pm, bid, child) ->
            (* Sanity check: projection markers can only appear when we're doing a join *)
            [%sanity_check] span (pm = PNone);
            if check_if_report level then raise (FoundBorrowId bid)
            else self#visit_AMutLoan level pm bid child
        | ASharedLoan (pm, bid, sv, child) ->
            (* Sanity check: projection markers can only appear when we're doing a join *)
            [%sanity_check] span (pm = PNone);
            if check_if_report level then raise (FoundBorrowId bid)
            else self#visit_ASharedLoan level pm bid sv child
        | AEndedMutLoan { given_back = _; child = _; given_back_meta = _ }
        | AEndedSharedLoan (_, _, _)
        | AIgnoredMutLoan (_, _, _)
        | AEndedIgnoredMutLoan { given_back = _; child = _; _ }
        | AIgnoredSharedLoan _ ->
            (* Dive into the sub-values *)
            super#visit_aloan_content level lc

      (** We may need to visit loan contents because of shared values *)
      method! visit_loan_content level lc =
        match lc with
        | VMutLoan _ ->
            (* The mut loan linked to the mutable borrow present in a shared
             * value in an abstraction should be in an AProjBorrows *)
            [%craise] span "Unreachable"
        | VSharedLoan (bid, sv) ->
            if check_if_report level then raise (FoundBorrowId bid)
            else self#visit_VSharedLoan level bid sv

      method! visit_aproj level sproj =
        (match sproj with
        | ATransportedProj _ | APendingLoans _ | APendingSymbolicLoans _
        | AProjBorrows _
        | AEndedProjLoans _
        | AEndedProjBorrows _
        | AEmpty -> ()
        | AProjLoans proj ->
            if check_if_report level then raise (FoundAProjLoans proj));
        super#visit_aproj level sproj
    end
  in
  try
    (* Check if there are loans *)
    visitor#visit_abs 0 abs;
    (* No loans *)
    None
  with
  (* There are loans *)
  | FoundBorrowId bid -> Some (BorrowId bid, !projected_regions)
  | FoundAProjLoans { proj; _ } ->
      (* There are loan projections over symbolic values *)
      Some (SymbolicValue proj, !projected_regions)

let get_max_sub_abs_visitor ?(with_ended = false) ?(with_evalues = false)
    ?(pending_borrow_ty = fun (_ : RegionId.Set.t) (_ : ty) -> false)
    ?(pending_regions = RegionId.Set.empty)
    ?(excluded_levels = AbsLevelSet.empty) (max_level : int ref) =
  let save_level level =
    if level > !max_level && not (AbsLevelSet.mem level excluded_levels) then
      max_level := level
  in
  object (self)
    inherit [_] iter_abs_with_levels as super
    (*
```ocaml
    *)
    val mutable active_pending_regions = pending_regions

    method! visit_ATransportedProj level transport child =
      let previous = active_pending_regions in
      active_pending_regions <- transport.current_regions;
      self#visit_aproj level child;
      active_pending_regions <- previous

    method! visit_ETransportedProj level transport child =
      let previous = active_pending_regions in
      active_pending_regions <- transport.current_regions;
      self#visit_eproj level child;
      active_pending_regions <- previous

    method! visit_ATransportedValue level transport child =
      let previous = active_pending_regions in
      active_pending_regions <- transport.current_regions;
      self#visit_tavalue level child;
      active_pending_regions <- previous

    method! visit_ETransportedValue level transport child =
      let previous = active_pending_regions in
      active_pending_regions <- transport.current_regions;
      self#visit_tevalue level child;
      active_pending_regions <- previous
    (*
```
    *)
    method! visit_ty _ _ = ()
    method incr_level level = level + 1

    method! visit_aloan_content level lc =
      (match lc with
      | AMutLoan _ | ASharedLoan _ -> save_level level
      | AEndedMutLoan _
      | AEndedSharedLoan _
      | AIgnoredMutLoan _
      | AEndedIgnoredMutLoan _
      | AIgnoredSharedLoan _ -> if with_ended then save_level level);
      super#visit_aloan_content level lc

    method! visit_aborrow_content level bc =
      (match bc with
      | AMutBorrow _ | ASharedBorrow _ -> save_level level
      | AIgnoredMutBorrow _
      | AEndedMutBorrow _
      | AEndedSharedBorrow
      | AEndedIgnoredMutBorrow _
      | AProjSharedBorrow (_, _ :: _) -> save_level level
      | AProjSharedBorrow (_, []) -> if with_ended then save_level level);
      super#visit_aborrow_content level bc

    method! visit_aproj level proj =
      (match proj with
      | ATransportedProj _ -> ()
      | APendingLoans _ | APendingSymbolicLoans _
      | AProjLoans _ | AProjBorrows _ -> save_level level
      | AEndedProjLoans _ | AEndedProjBorrows _ | AEmpty ->
          (* TODO: ignore AEmpty? *)
          if with_ended then save_level level);
      super#visit_aproj level proj

    method! visit_loan_content level lc =
      (match lc with
      | VSharedLoan _ | VMutLoan _ -> save_level level);
      super#visit_loan_content level lc

    method! visit_borrow_content level bc =
      (match bc with
      | VSharedBorrow _ | VMutBorrow _ | VReservedMutBorrow _ ->
          save_level level);
      super#visit_borrow_content level bc

    method! visit_adt_avalue level a =
      (* When analyzing the ended borrows, make sure we don't forget the ADTs
         containing borrows which expanded to a variant which did not contain
         any borrow. *)
      if with_ended then save_level level;
      super#visit_adt_avalue level a

    method! visit_tevalue level e =
      if with_evalues then super#visit_tevalue level e else ()

    method! visit_eloan_content level lc =
      (match lc with
      | EMutLoan _ -> save_level level
      | EEndedMutLoan _ | EIgnoredMutLoan _ | EEndedIgnoredMutLoan _ ->
          if with_ended then save_level level);
      super#visit_eloan_content level lc

    method! visit_eborrow_content level bc =
      (match bc with
      | EMutBorrow _ -> save_level level
      | EIgnoredMutBorrow (Some _, child)
        when pending_borrow_ty active_pending_regions child.ty ->
          save_level (level + 1)
      | EIgnoredMutBorrow _ | EEndedMutBorrow _ | EEndedIgnoredMutBorrow _ ->
          if with_ended then save_level level);
      super#visit_eborrow_content level bc

    method! visit_eproj level proj =
      (match proj with
      | ETransportedProj _ -> ()
      | EPendingLoans _ | EPendingSymbolicLoans _
      | EProjLoans _ | EProjBorrows _ -> save_level level
      | EEndedProjLoans _ | EEndedProjBorrows _ | EEmpty ->
          (* TODO: ignore EEmpty? *)
          if with_ended then save_level level);
      super#visit_eproj level proj
  end

(** Get the non-ended sub-abstraction with the highest level.

    Outputs -1 if no valid borrow/loan was found *)
let get_max_sub_abs ?(with_ended = false) ?(with_evalues = false) (abs : abs) :
    int =
  let max_level = ref (-1) in
  (* Ended carriers remain in the abstraction for its continuation. They must
     not hide a lower, still-live level when selecting the teardown frontier. *)
  let excluded_levels =
    if with_ended then AbsLevelSet.empty else abs.ended_subabs
  in
  let visitor =
    get_max_sub_abs_visitor ~with_ended ~with_evalues ~excluded_levels max_level
  in
  visitor#visit_abs 0 abs;
  !max_level

let lookup_shared_value_opt (span : Meta.span) (env : env) (bid : BorrowId.id) :
    tvalue option =
  match lookup_loan_opt span ek_all bid env with
  | None -> None
  | Some (_, lc) -> (
      match lc with
      | Concrete (VSharedLoan (_, sv)) | Abstract (ASharedLoan (_, _, sv, _)) ->
          Some sv
      | _ -> None)

let lookup_shared_value (span : Meta.span) (env : env) (bid : BorrowId.id) :
    tvalue =
  Option.get (lookup_shared_value_opt span env bid)

let ctx_lookup_shared_value span ctx = lookup_shared_value span ctx.env

(** A marked borrow id *)
type marked_borrow_id = proj_marker * borrow_id [@@deriving show, ord]

module MarkedBorrowIdOrd = struct
  type t = marked_borrow_id

  let compare = compare_marked_borrow_id
  let to_string = show_marked_borrow_id
  let pp_t = pp_marked_borrow_id
  let show_t = show_marked_borrow_id
end

module MarkedBorrowIdSet = Collections.MakeSet (MarkedBorrowIdOrd)
module MarkedBorrowIdMap = Collections.MakeMap (MarkedBorrowIdOrd)

module MarkedBorrowId : sig
  type t

  val to_string : t -> string

  module Set : Collections.Set with type elt = t
  module Map : Collections.Map with type key = t
end
with type t = marked_borrow_id = struct
  type t = marked_borrow_id

  let to_string = show_marked_borrow_id

  module Set = MarkedBorrowIdSet
  module Map = MarkedBorrowIdMap
end

(** A marked borrow id *)
type marked_unique_borrow_id = proj_marker * borrow_id * shared_borrow_id option
[@@deriving show, ord]

module MarkedUniqueBorrowIdOrd = struct
  type t = marked_unique_borrow_id

  let compare = compare_marked_unique_borrow_id
  let to_string = show_marked_unique_borrow_id
  let pp_t = pp_marked_unique_borrow_id
  let show_t = show_marked_unique_borrow_id
end

module MarkedUniqueBorrowIdSet = Collections.MakeSet (MarkedUniqueBorrowIdOrd)
module MarkedUniqueBorrowIdMap = Collections.MakeMap (MarkedUniqueBorrowIdOrd)

module MarkedUniqueBorrowId : sig
  type t

  val to_string : t -> string

  module Set : Collections.Set with type elt = t
  module Map : Collections.Map with type key = t
end
with type t = marked_unique_borrow_id = struct
  type t = marked_unique_borrow_id

  let to_string = show_marked_unique_borrow_id

  module Set = MarkedUniqueBorrowIdSet
  module Map = MarkedUniqueBorrowIdMap
end

(** A marked loan id *)
type marked_loan_id = proj_marker * loan_id [@@deriving show, ord]

module MarkedLoanIdOrd = MarkedBorrowIdOrd
module MarkedLoanIdSet = MarkedBorrowIdSet
module MarkedLoanIdMap = MarkedBorrowIdMap
module MarkedLoanId = MarkedBorrowId

let marked_unique_borrow_to_loan_id (x : marked_unique_borrow_id) :
    marked_loan_id =
  let pm, bid, _ = x in
  (pm, bid)

(** A marked and normalized symbolic value (loan/borrow) projection.

    A normalized symbolic value projection is a projection of a symoblic value
    for which the projection type has been normalized in the following way: the
    projected regions have the identifier 0, and the non-projected regions are
    erased.

    For instance, if we consider the region abstractions below:
    {[
      abs0 {'a} { s <: S<'a, 'b> }
      abs1 {'b} { s <: S<'a, 'b> }
    ]}

    Then normalizing (the type of) the symbolic value [s] for ['a] gives
    [S<'0, '_>], while normalizing it for ['b] gives [S<'_, '0>].

    We use normalized types to compare loan/borrow projections of symbolic
    values, and for lookups (normalized types can easily be used as keys in
    maps). *)
type marked_norm_symb_proj = {
  pm : proj_marker;
  sv_id : symbolic_value_id;
  norm_proj_ty : ty;
}
[@@deriving show, ord]

let marked_norm_symb_proj_to_string (ctx : eval_ctx) (p : marked_norm_symb_proj)
    : string =
  let { pm; sv_id; norm_proj_ty } = p in
  Print.Values.symbolic_value_id_to_pretty_string sv_id
  ^ " <: "
  ^ ty_to_string ctx norm_proj_ty
  |> Print.Values.add_proj_marker pm

module MarkedNormSymbProjOrd = struct
  type t = marked_norm_symb_proj

  let compare = compare_marked_norm_symb_proj
  let to_string = show_marked_norm_symb_proj
  let pp_t = pp_marked_norm_symb_proj
  let show_t = show_marked_norm_symb_proj
end

module MarkedNormSymbProjSet = Collections.MakeSet (MarkedNormSymbProjOrd)
module MarkedNormSymbProjMap = Collections.MakeMap (MarkedNormSymbProjOrd)

module MarkedNormSymbProj : sig
  type t

  val to_string : t -> string

  module Set : Collections.Set with type elt = t
  module Map : Collections.Map with type key = t
end
with type t = marked_norm_symb_proj = struct
  type t = marked_norm_symb_proj

  let to_string = show_marked_norm_symb_proj

  module Set = MarkedNormSymbProjSet
  module Map = MarkedNormSymbProjMap
end

type norm_symb_proj = { sv_id : symbolic_value_id; norm_proj_ty : ty }
[@@deriving show, ord]

let norm_symb_proj_to_string (ctx : eval_ctx) (proj : norm_symb_proj) : string =
  let sv_id = symbolic_value_id_to_pretty_string proj.sv_id in
  let ty = ty_to_string ctx proj.norm_proj_ty in
  "(" ^ sv_id ^ " : " ^ ty ^ ")"

module NormSymbProjOrd = struct
  type t = norm_symb_proj

  let compare = compare_norm_symb_proj
  let to_string = show_norm_symb_proj
  let pp_t = pp_norm_symb_proj
  let show_t = show_norm_symb_proj
end

module NormSymbProjSet : sig
  include Collections.Set with type elt = norm_symb_proj

  val with_ctx_to_string : string option -> eval_ctx -> t -> string
end = struct
  include Collections.MakeSet (NormSymbProjOrd)

  let with_ctx_to_string indent_opt ctx (s : t) =
    let indent, break =
      match indent_opt with
      | Some indent -> (indent, "\n")
      | None -> ("", " ")
    in
    let sep = "," ^ break in
    let ls =
      fold (fun v ls -> (indent ^ norm_symb_proj_to_string ctx v) :: ls) s []
    in
    match ls with
    | [] -> "{}"
    | _ -> "{" ^ break ^ String.concat sep (List.rev ls) ^ " }"
end

module NormSymbProjMap : sig
  include Collections.Map with type key = norm_symb_proj

  val with_ctx_to_string :
    string option -> ('a -> string) -> eval_ctx -> 'a t -> string
end = struct
  include Collections.MakeMap (NormSymbProjOrd)

  let with_ctx_to_string indent_opt a_to_string ctx m =
    let indent, break =
      match indent_opt with
      | Some indent -> (indent, "\n")
      | None -> ("", " ")
    in
    let sep = "," ^ break in
    let ls =
      fold
        (fun key v ls ->
          (indent ^ norm_symb_proj_to_string ctx key ^ " -> " ^ a_to_string v)
          :: ls)
        m []
    in
    match ls with
    | [] -> "{}"
    | _ -> "{" ^ break ^ String.concat sep (List.rev ls) ^ " }"
end

module NormSymbProj : sig
  type t

  val to_string : t -> string
  val with_ctx_to_string : eval_ctx -> t -> string

  module Set : sig
    include Collections.Set

    val with_ctx_to_string : string option -> eval_ctx -> t -> string
  end
  with type elt = t

  module Map : sig
    include Collections.Map with type key = t

    val with_ctx_to_string :
      string option -> ('a -> string) -> eval_ctx -> 'a t -> string
  end
end
with type t = norm_symb_proj = struct
  type t = norm_symb_proj

  let to_string = show_norm_symb_proj
  let with_ctx_to_string = norm_symb_proj_to_string

  module Set = struct
    include NormSymbProjSet
  end

  module Map = struct
    include NormSymbProjMap
  end
end

let marked_norm_symb_proj_to_unmarked (m : marked_norm_symb_proj) :
    norm_symb_proj =
  { sv_id = m.sv_id; norm_proj_ty = m.norm_proj_ty }

let map2_projection_args span is_stored merge equal_metadata args1 args2 =
  let rec map index args1 args2 =
    match (args1, args2) with
    | [], [] -> []
    | arg1 :: args1, arg2 :: args2 ->
        let arg =
          if is_stored index then merge arg1 arg2
          else (
            [%sanity_check] span (equal_metadata arg1 arg2);
            arg1)
        in
        arg :: map (index + 1) args1 args2
    | _ -> [%internal_error] span
  in
  map 0 args1 args2

(** Normalize a projection type by replacing the projected regions with ['0] and
    the non-projected ones with ['_].

    For example, normalize the projection type [S<'a, 'b>] for region ['a].
    Callable metadata and trait witnesses contribute no stored borrow positions.
    Pointer signatures retain their region identities.

    Nominal stored arguments encode ownership even when their parameters also
    occur in signature metadata. These masks never instantiate runtime fields.
    The original projection type retains those metadata identities.

    Dyn trait regions contribute no positions when [Config.type_analysis_ignore_dyn]
    applies. The projections of [&'a (dyn Trait + 'b)] over ['a] and ['b] have
    the same shape. *)
let normalize_proj_ty (infos : TypesAnalysis.type_infos)
    (regions : RegionId.Set.t) (ty : rty) : rty =
  let visitor =
    object (self)
      inherit [_] map_ty as super
      method! visit_trait_ref _ tr = tr

      method! visit_TAdt stored tref =
        if not stored then TAdt tref
        else
          let info = projection_adt_info infos tref.id in
          let generics = tref.generics in
          let regions =
            List.mapi
              (fun index r ->
                self#visit_region (projection_region_is_stored info index) r)
              generics.regions
          in
          let types =
            List.mapi
              (fun index ty ->
                self#visit_ty (projection_type_is_stored info index) ty)
              generics.types
          in
          TAdt { tref with generics = { generics with regions; types } }

      method! visit_ty stored ty =
        if not stored then ty
        else
          match ty with
          | TFnPtr _ | TFnDef _ -> ty
          | TDynTrait _ when Config.type_analysis_ignore_dyn -> ty_erase_regions infos ty
          | _ -> super#visit_ty stored ty

      method! visit_region stored r =
        if not stored then r
        else
          match r with
          | RVar (Free r) ->
              if RegionId.Set.mem r regions then RVar (Free RegionId.zero)
              else RErased
          | RVar (Bound _) | RStatic | RErased -> r
          | RBody _ -> [%craise_opt_span] None "unsupported: Body region"
    end
  in
  visitor#visit_ty true ty

(** Compute the disjoint union of two normalized projection masks over the same
    type. Only free ['0] positions represent ownership.

    Callable metadata must agree after source alias resolution. The result
    retains the original metadata witnesses, not the resolved comparison view.
    Static and bound regions must agree unchanged. *)
let rec norm_proj_tys_union (span : Meta.span) (ctx : eval_ctx) (ty1 : rty)
    (ty2 : rty) : rty =
  match (ty1, ty2) with
  | TAdt tref1, TAdt tref2 ->
      [%sanity_check] span (tref1.id = tref2.id);
      let info = projection_adt_info ctx.type_ctx.type_infos tref1.id in
      TAdt
        {
          id = tref1.id;
          generics =
            norm_proj_generic_args_union span ctx info tref1.generics tref2.generics;
        }
  | TVar id1, TVar id2 ->
      [%sanity_check] span (id1 = id2);
      TVar id1
  | TLiteral lit1, TLiteral lit2 ->
      [%sanity_check] span (lit1 = lit2);
      TLiteral lit1
  | TNever, TNever -> TNever
  | TRef (r1, ty1, rk1), TRef (r2, ty2, rk2) ->
      [%sanity_check] span (rk1 = rk2);
      (match (r1, r2) with
      | RVar (Free _), RVar (Free _) ->
          [%craise] span
            ("Overlapping normalized reference projections:\n- left:\n"
            ^ ty_to_string ctx (TRef (r1, ty1, rk1))
            ^ "\n- right:\n"
            ^ ty_to_string ctx (TRef (r2, ty2, rk2))
            ^ "\n- context:\n" ^ eval_ctx_to_string ctx)
      | _ -> ());
      TRef
        ( norm_proj_regions_union span r1 r2,
          norm_proj_tys_union span ctx ty1 ty2,
          rk1 )
  | TRawPtr (ty1, rk1), TRawPtr (ty2, rk2) ->
      [%sanity_check] span (rk1 = rk2);
      TRawPtr (norm_proj_tys_union span ctx ty1 ty2, rk1)
  | TTraitType (tr1, item1), TTraitType (tr2, item2) ->
      [%sanity_check] span (item1 = item2);
      TTraitType (norm_proj_trait_refs_union span ctx tr1 tr2, item1)
  | TFnPtr _, TFnPtr _
  | TFnDef _, TFnDef _ ->
      (* Callable metadata contributes no owned positions to either mask. *)
      [%sanity_check] span
        (projection_metadata_types_equal ctx RegionId.Map.empty ty1 ty2);
      ty1
  | TArray (ty0, len0), TArray (ty1, len1) ->
      [%sanity_check] span (len0 = len1);
      TArray (norm_proj_tys_union span ctx ty0 ty1, len0)
  | TSlice ty0, TSlice ty1 -> TSlice (norm_proj_tys_union span ctx ty0 ty1)
  | TDynTrait _, TDynTrait _ ->
      (* Its regions are erased by [normalize_proj_ty] and contribute no owned
         positions to either mask. *)
      [%cassert] span (not Config.use_dyn_regions) "Unimplemented";
      [%sanity_check] span (ty1 = ty2);
      ty1
  | _ ->
      [%ltrace
        "- ty1: " ^ ty_to_string ctx ty1 ^ "\n- ty2: " ^ ty_to_string ctx ty2];
      [%internal_error] span

and norm_proj_generic_args_union span (ctx : eval_ctx) info
    (generics1 : generic_args) (generics2 : generic_args) : generic_args =
  let {
    regions = regions1;
    types = types1;
    const_generics = const_generics1;
    trait_refs = trait_refs1;
  } =
    generics1
  in
  let {
    regions = regions2;
    types = types2;
    const_generics = const_generics2;
    trait_refs = trait_refs2;
  } =
    generics2
  in
  {
    regions =
      map2_projection_args span (projection_region_is_stored info)
        (norm_proj_regions_union span)
        (projection_metadata_regions_equal ctx RegionId.Map.empty)
        regions1 regions2;
    types =
      map2_projection_args span (projection_type_is_stored info)
        (norm_proj_tys_union span ctx)
        (projection_metadata_types_equal ctx RegionId.Map.empty)
        types1 types2;
    const_generics =
      List.map2
        (norm_proj_const_generics_union span)
        const_generics1 const_generics2;
    trait_refs =
      List.map2 (norm_proj_trait_refs_union span ctx) trait_refs1 trait_refs2;
  }

and norm_proj_regions_union (span : Meta.span) (r1 : region) (r2 : region) :
    region =
  match (r1, r2) with
  | RVar (Free _), RVar (Free _) ->
      (* There is an intersection: the regions should be disjoint *)
      [%internal_error] span
  | RVar (Free rid), RErased | RErased, RVar (Free rid) ->
      [%sanity_check] span (rid = RegionId.zero);
      RVar (Free rid)
  | RErased, RErased -> RErased
  | RStatic, RStatic -> RStatic
  | RVar (Bound (db1, var1)), RVar (Bound (db2, var2)) ->
      [%sanity_check] span (db1 = db2 && var1 = var2);
      r1
  | _ -> [%internal_error] span

and norm_proj_trait_refs_union (span : Meta.span) (_ctx : eval_ctx)
    (tr1 : trait_ref) (tr2 : trait_ref) : trait_ref =
  [%sanity_check] span (tr1 = tr2);
  tr1

and norm_proj_const_generics_union (span : Meta.span) (cg1 : constant_expr)
    (cg2 : constant_expr) : constant_expr =
  [%sanity_check] span (cg1 = cg2);
  cg1

(** In a normalized projection, ['0] is a selected position and ['_] is an
    unselected position, not a missing region identity. These masks must not be
    passed to the comparisons of regionful types. *)
let compare_norm_proj_tys span ctx default combine compare_selected
    (ty1 : norm_proj_ty) (ty2 : norm_proj_ty) : bool =
  let selected = function
    | RVar (Free rid) ->
        [%sanity_check] span (rid = RegionId.zero);
        true
    | RErased -> false
    | RStatic | RVar (Bound _) | RBody _ -> [%internal_error] span
  in
  (* Traverse both masks together, including dictionaries. A static or bound
     region is not an owned position, but its identity is part of the shape. *)
  let compare_regions r1 r2 =
    match (r1, r2) with
    | (RVar (Free _) | RErased), (RVar (Free _) | RErased) ->
        compare_selected (selected r1) (selected r2)
    | RStatic, RStatic -> compare_selected false false
    | RVar (Bound (db1, var1)), RVar (Bound (db2, var2)) ->
        [%sanity_check] span (db1 = db2 && var1 = var2);
        compare_selected false false
    | _ -> [%internal_error] span
  in
  let compare_list is_stored compare equal_metadata xs ys =
    let rec fold index acc xs ys =
      match (xs, ys) with
      | [], [] -> acc
      | x :: xs, y :: ys ->
          let result =
            if is_stored index then compare x y
            else (
(* ```ocaml *)
              [%cassert] span (equal_metadata x y)
                ("Incompatible normalized projector metadata:\n"
                ^ ty_to_string ctx ty1 ^ "\n" ^ ty_to_string ctx ty2
                ^ "\nSource aliases:\n"
                ^ String.concat "\n"
                    (List.map
                      (fun (id, binding) ->
                        RegionId.to_string id ^ ": "
                        ^ Types.show_region_metadata_binding binding)
                      (RegionId.Map.bindings ctx.metadata_bindings)));
(* ``` *)
              default)
          in
          fold (index + 1) (combine acc result) xs ys
      | _ -> [%internal_error] span
    in
    fold 0 default xs ys
  in
  let rec compare_ty ty1 ty2 =
    match (ty1, ty2) with
    | TAdt tref1, TAdt tref2 ->
        [%sanity_check] span (tref1.id = tref2.id);
        let info = projection_adt_info ctx.type_ctx.type_infos tref1.id in
        compare_generics info tref1.generics tref2.generics
    | TVar id1, TVar id2 ->
        [%sanity_check] span (id1 = id2);
        default
    | TLiteral lit1, TLiteral lit2 ->
        [%sanity_check] span (lit1 = lit2);
        default
    | TNever, TNever -> default
    | TRef (r1, ty1, rk1), TRef (r2, ty2, rk2) ->
        [%sanity_check] span (rk1 = rk2);
        let regions = compare_regions r1 r2 in
        let types = compare_ty ty1 ty2 in
        combine regions types
    | TRawPtr (ty1, rk1), TRawPtr (ty2, rk2) ->
        [%sanity_check] span (rk1 = rk2);
        compare_ty ty1 ty2
    | TTraitType (tr1, item1), TTraitType (tr2, item2) ->
        [%sanity_check] span (item1 = item2);
        compare_trait_refs tr1 tr2
    | TArray (ty1, len1), TArray (ty2, len2) ->
        [%sanity_check] span (len1 = len2);
        compare_ty ty1 ty2
    | TSlice ty1, TSlice ty2 -> compare_ty ty1 ty2
    | TFnPtr _, TFnPtr _
    | TFnDef _, TFnDef _ ->
        (* Callable metadata contributes no owned positions. *)
(* ```ocaml *)
        [%cassert] span
          (projection_metadata_types_equal ctx RegionId.Map.empty ty1 ty2)
          "Incompatible normalized callable metadata";
(* ``` *)
        default
    | TDynTrait _, TDynTrait _ ->
        [%cassert] span (not Config.use_dyn_regions) "Unimplemented";
        [%sanity_check] span (ty1 = ty2);
        default
    | _ ->
        [%ltrace
          "- ty1: " ^ ty_to_string ctx ty1 ^ "\n- ty2: " ^ ty_to_string ctx ty2];
        [%internal_error] span
  and compare_generics info (g1 : generic_args) (g2 : generic_args) =
    [%sanity_check] span
      (g1.const_generics = g2.const_generics && g1.trait_refs = g2.trait_refs);
    let regions =
      compare_list (projection_region_is_stored info) compare_regions
        (projection_metadata_regions_equal ctx RegionId.Map.empty)
        g1.regions g2.regions
    in
    let types =
      compare_list (projection_type_is_stored info) compare_ty
        (projection_metadata_types_equal ctx RegionId.Map.empty)
        g1.types g2.types
    in
    combine regions types
  and compare_trait_refs (tr1 : trait_ref) (tr2 : trait_ref) =
    [%sanity_check] span (tr1 = tr2);
    default
  in
  compare_ty ty1 ty2

let norm_proj_ty_contains span ctx (ty1 : norm_proj_ty) (ty2 : norm_proj_ty) :
    bool =
  compare_norm_proj_tys span ctx true ( && )
    (fun selected1 selected2 -> selected1 || not selected2)
    ty1 ty2

let norm_proj_tys_intersect span ctx (ty1 : norm_proj_ty) (ty2 : norm_proj_ty) :
    bool =
  compare_norm_proj_tys span ctx false ( || ) ( && ) ty1 ty2

(* ```ocaml *)
let norm_proj_tys_equal span ctx (ty1 : norm_proj_ty) (ty2 : norm_proj_ty) :
    bool =
  ty1 = ty2 || compare_norm_proj_tys span ctx true ( && ) ( = ) ty1 ty2
(* ``` *)

(** Refresh the live region ids in stored positions.
    The returned map contains only stored positions that need ownership abstractions.

    Metadata uses the same rename map as storage. Metadata-only free regions
    retain their identities. Bound signature regions remain bound. *)
let refresh_live_regions_in_ty (span : Meta.span) (ctx : eval_ctx) (ty : rty) :
    RegionId.id RegionId.Map.t * rty * region_metadata_bindings =
  [%sanity_check] span (ty_is_rty ctx.type_ctx.type_infos ty);
  let stored_regions = ty_regions ctx.type_ctx.type_infos ty in
  let regions =
    RegionId.Set.fold
      (fun rid regions ->
        if RegionId.Set.mem rid ctx.ended_regions then regions
        else RegionId.Map.add rid (ctx.fresh_region_id ()) regions)
      stored_regions RegionId.Map.empty
  in
  if RegionId.Map.is_empty regions then (regions, ty, ctx.metadata_bindings)
  else
    let rename_region = function
      | RVar (Free rid) as r ->
          (match RegionId.Map.find_opt rid regions with
          | Some fresh -> RVar (Free fresh)
          | None -> r)
      | r -> r
    in
    let metadata_bindings =
      if not (ty_has_stored_metadata ctx.type_ctx.type_infos ty) then
        ctx.metadata_bindings
      else
        RegionId.Map.fold
          (fun original execution bindings ->
            let source = metadata_region ctx.metadata_bindings
              (RVar (Free original)) in
            RegionId.Map.add execution (MetadataSource source) bindings)
          regions ctx.metadata_bindings
    in
    (regions, map_free_region_aliases rename_region ty, metadata_bindings)

(** Set a list of abstractions as (non-)endable *)
let update_endable (ctx : eval_ctx) (abs_ids : abs_id list) ~(can_end : bool) :
    eval_ctx =
  let abs_ids = AbsId.Set.of_list abs_ids in
  let update (e : env_elem) : env_elem =
    match e with
    | EAbs abs ->
        if AbsId.Set.mem abs.abs_id abs_ids then EAbs { abs with can_end }
        else EAbs abs
    | _ -> e
  in
  { ctx with env = List.map update ctx.env }

let normalize_symbolic_proj (infos : TypesAnalysis.type_infos)
    (regions : RegionId.Set.t) (proj : symbolic_proj) : norm_symb_proj =
  let { sv_id; proj_ty } : symbolic_proj = proj in
  let norm_proj_ty = normalize_proj_ty infos regions proj_ty in
  { sv_id; norm_proj_ty }
