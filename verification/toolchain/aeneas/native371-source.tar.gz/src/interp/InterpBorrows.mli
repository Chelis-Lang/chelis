open Values
open Contexts
open Cps
open InterpUtils

(*
```ocaml
*)
val diagnose_symbolic_runtime_type_transition :
  Meta.span -> string -> eval_ctx -> eval_ctx -> unit

val runtime_type_metadata_view : eval_ctx -> Types.ty list -> string

val input_return_route_ty :
  eval_ctx -> Types.ty -> value_path_step list -> Types.ty option

val input_return_declared_source :
  ?final_borrow:borrow_id ->
  Meta.span ->
  (symbolic_value * symbolic_expansion) list ->
  symbolic_value -> value_path_step list -> symbolic_value option

val call_input_value_at_path : tvalue -> value_path_step list -> tvalue option

val call_input_actual_path :
  call_input_correspondence -> value_path_step list -> value_path_step list option

val call_input_borrow_reference :
  Meta.span ->
  eval_ctx ->
  call_input_correspondence ->
  borrow_id ->
  (Types.ty * Types.ty) option


val register_call_input_correspondences :
  Meta.span ->
  eval_ctx ->
  fun_call_id ->
  [ `Regular of Types.fn_ptr_kind | `Dynamic of tvalue ] ->
  Types.fun_sig ->
  LlbcAst.inst_fun_sig ->
  tvalue list ->
  eval_ctx
(*
```
*)

(** End a borrow identified by its id, while preserving the invariants.

    If the borrow is inside another borrow/an abstraction or contains loans,
    [end_borrow] will end those borrows/abstractions/loans first. *)
val end_borrow :
  config -> Meta.span -> ?snapshots:bool -> unique_borrow_id -> cm_fun

(** End a set of borrows identified by their ids, while preserving the
    invariants. *)
val end_borrows :
  config -> Meta.span -> ?snapshots:bool -> unique_borrow_id_set -> cm_fun

(** End a loan identified by its id, while preserving the invariants *)
val end_loan : config -> Meta.span -> ?snapshots:bool -> loan_id -> cm_fun

(** End a set of loans identified by their ids, while preserving the invariants
*)
val end_loans : config -> Meta.span -> ?snapshots:bool -> loan_id_set -> cm_fun

(** End an abstraction while preserving the invariants. *)
val end_abs :
  config -> Meta.span -> ?snapshots:bool -> AbsId.id -> int -> cm_fun

(** End a set of abstractions while preserving the invariants. *)
val end_abs_set :
  config -> Meta.span -> ?snapshots:bool -> AbsIdWithLevelSet.t -> cm_fun

(** End a borrow and return the resulting environment, ignoring synthesis *)
val end_borrow_no_synth :
  config ->
  Meta.span ->
  ?snapshots:bool ->
  unique_borrow_id ->
  eval_ctx ->
  eval_ctx

(** End a set of borrows and return the resulting environment, ignoring
    synthesis *)
val end_borrows_no_synth :
  config ->
  Meta.span ->
  ?snapshots:bool ->
  unique_borrow_id_set ->
  eval_ctx ->
  eval_ctx

(** End a loan and return the resulting environment, ignoring synthesis *)
val end_loan_no_synth :
  config -> Meta.span -> ?snapshots:bool -> loan_id -> eval_ctx -> eval_ctx

(** End a set of loans and return the resulting environment, ignoring synthesis
*)
val end_loans_no_synth :
  config -> Meta.span -> ?snapshots:bool -> loan_id_set -> eval_ctx -> eval_ctx

(** End a set of loans and return the resulting environment, ignoring synthesis.

    Contrary to [end_loans_no_synth], the function doesn't fail if one of the
    loan ids actually doesn't exist in the context. *)
val try_end_loans_no_synth :
  config -> Meta.span -> ?snapshots:bool -> loan_id_set -> eval_ctx -> eval_ctx

(** End an abstraction and return the resulting environment, ignoring synthesis
*)
val end_abs_no_synth :
  config ->
  Meta.span ->
  ?snapshots:bool ->
  AbsId.id ->
  abs_level ->
  eval_ctx ->
  eval_ctx

(** End a set of abstractions and return the resulting environment, ignoring
    synthesis *)
val end_abs_set_no_synth :
  config ->
  Meta.span ->
  ?snapshots:bool ->
  AbsIdWithLevelSet.t ->
  eval_ctx ->
  eval_ctx

(** End the abstractions which observe, through a shared reborrow projector,
    mutable borrows owned by a symbolic value of the given value: a call which
    took a shared borrow of the value leaves such an observation, which moving
    the value or borrowing it mutably ends. Observations of shared borrows only
    stay. Returns [None] if there is no such observation. *)
val end_mut_borrow_observations_in_value_opt :
  config ->
  Meta.span ->
  tvalue ->
  eval_ctx ->
  (eval_ctx * (SymbolicAst.expr -> SymbolicAst.expr)) option

(** Promote a reserved mut borrow to a mut borrow, while preserving the
    invariants.

    Reserved borrows are special mutable borrows which are created as shared
    borrows then promoted to mutable borrows upon their first use.

    This function replaces the reserved borrow with a mutable borrow, then
    replaces the corresponding shared loan with a mutable loan (after having
    ended the other shared borrows which point to this loan). *)
val promote_reserved_mut_borrow :
  config -> Meta.span -> loan_id -> shared_borrow_id -> cm_fun

(** Whether a symbolic projection tree contains a live borrow, loan or pending
    give-back obligation at any level. Ended roots still own live descendants.
*)
val proj_has_ownership : aproj -> bool

(** Whether a value contains live ownership or an ignored mutable dependency
    whose parent can still install give-back ownership. Metadata is not live. *)
val tavalue_has_ownership : Meta.span -> eval_ctx -> tavalue -> bool

(** Transform an abstraction to an abstraction where the values are not
    structured.

    For instance:
    {[
      abs {
        (mut_borrow l0, mut_borrow l1, _)
      }

          ~~>

      abs {
        mut_borrow l0
        mut_borrow l1
      }
    ]}

    This simplifies merging abstractions. Concrete shared-loan payloads remain
    intact: their nested loans and borrowers have one operational owner, and
    their child region witnesses are not rebound to the outer region.

    Active ignored mutable dependencies become [APendingLoans] carrying the real
    parent borrow identity and an isolated payload region mask. Their paired
    continuation normalization creates corresponding [EPendingLoans] inputs;
    ending the parent resolves both from the actual returned value. Ended
    ignored mutable borrow wrappers are flattened together with the
    continuation's lifted give-back inputs. Join callers must normalize both
    sides with [InterpAbs.normalize_abs_for_join] before assigning markers.

    Symbolic projection trees remain intact: their children own distinct
    sub-abstraction levels, and their give-back metadata corresponds to the
    existing continuation. Ended roots are removed only when no descendant still
    owns a borrow or loan.

    Existing synthesis-input abstractions retain their kind and [can_end]
    status: destructuring their branch copies does not introduce new join or
    loop continuations.

    Paramters:
    - [abs_kind]
    - [can_end]
    - [ctx]
    - [abs] *)
val destructure_abs :
  Meta.span -> abs_kind -> can_end:bool -> eval_ctx -> abs -> abs

(** Return [true] if the values in an abstraction are destructured.

    We simply destructure it and check that it gives the identity. *)
val abs_is_destructured : Meta.span -> eval_ctx -> abs -> bool

(** Check that neither the symbolic value nor an intersecting borrow projector
    remains. Include shared reborrow projectors when [lookup_shared] is set. *)
val loan_proj_is_endable :
  Meta.span ->
  eval_ctx ->
  lookup_shared:bool ->
  Types.RegionId.Set.t ->
  symbolic_proj ->
  bool

(** Discharge shared borrow edges supplied by lenders in the same abstraction,
    branch and level. Preserve projection masks, descendants and continuation.
*)
val eliminate_internal_shared_borrows : Meta.span -> eval_ctx -> abs -> abs

(** A value which contains no loans and no mutable borrows, including inside
    its symbolic values: discarding it gives nothing back and only releases
    shared loans. *)
val value_has_only_shared_borrows : eval_ctx -> tvalue -> bool

(** Attempts to eliminate useless ended shared loans.

    TODO: will not be necessary once we destructure the avalues. *)
val eliminate_ended_shared_loans : Meta.span -> eval_ctx -> eval_ctx

(** Simplify the dummy values in a context by removing as many as possible and
    ending as many borrows as possible.

    We remove all the dummy values which:
    - contain no loans/borrows.
    - contain symbolic values (including those containing borrows: it is
      tantamount to ending preemptively the outer borrows)

    We also:
    - end the borrows which are inside dummy and don't themselves contain loans
    - end the region abstractions which can be ended because they contain no
      loans
    - end the loan projectors which can be ended because the corresponding
      symbolic value doesn't appear anywhere else in the context We ignore the
      abstractions which are specified by the set of abstraction ids (we do not
      end them, nor their loans).
    - eliminate the ended shared loans (see [eliminate_ended_shared_loans])

    until none of these steps changes the context: simplifying the result
    again changes nothing. *)
val simplify_dummy_values_useless_abs :
  config -> ?snapshots:bool -> Meta.span -> cm_fun
