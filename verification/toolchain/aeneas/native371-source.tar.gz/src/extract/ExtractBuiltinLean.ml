(** THIS FILE WAS AUTOMATICALLY GENERATED FROM LEAN: DO NOT MODIFY DIRECTLY *)
open ExtractBuiltinCore

let lean_builtin_types = [
  (* file: "Aeneas/Std/Alloc.lean", line: 16 *)
  mk_type "alloc::alloc::Global" "_root_.Aeneas.Std.Global" ~kind:(KEnum [("Mk", Some "mk")]);
  (* file: "Aeneas/Std/Core/Borrow.lean", line: 81 *)
  mk_type "alloc::borrow::Cow" "_root_.Aeneas.Std.alloc.borrow.Cow" ~kind:(KEnum [("Borrowed", Some "Borrowed"); ("Owned", Some "Owned")]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 16 *)
  mk_type "alloc::collections::btree::map::BTreeMap" "_root_.Aeneas.Std.alloc.collections.btree.map.BTreeMap" ~keep_params:(Some [true; true; false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 46 *)
  mk_type "alloc::collections::btree::map::IntoIter" "_root_.Aeneas.Std.alloc.collections.btree.map.IntoIter" ~keep_params:(Some [true; true; false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 52 *)
  mk_type "alloc::collections::btree::map::IntoValues" "_root_.Aeneas.Std.alloc.collections.btree.map.IntoValues" ~keep_params:(Some [true; true; false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 21 *)
  mk_type "alloc::collections::btree::map::Iter" "_root_.Aeneas.Std.alloc.collections.btree.map.Iter";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 27 *)
  mk_type "alloc::collections::btree::map::Keys" "_root_.Aeneas.Std.alloc.collections.btree.map.Keys";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 32 *)
  mk_type "alloc::collections::btree::map::Values" "_root_.Aeneas.Std.alloc.collections.btree.map.Values";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 41 *)
  mk_type "alloc::collections::btree::map::ValuesMut" "_root_.Aeneas.Std.alloc.collections.btree.map.ValuesMut" ~mut_regions:([0]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 78 *)
  mk_type "alloc::collections::btree::map::entry::Entry" "_root_.Aeneas.Std.alloc.collections.btree.map.entry.Entry" ~keep_params:(Some [true; true; false]) ~mut_regions:([0]) ~kind:(KEnum [("Vacant", Some "Vacant"); ("Occupied", Some "Occupied")]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 59 *)
  mk_type "alloc::collections::btree::map::entry::OccupiedEntry" "_root_.Aeneas.Std.alloc.collections.btree.map.entry.OccupiedEntry" ~keep_params:(Some [true; true; false]) ~mut_regions:([0]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 70 *)
  mk_type "alloc::collections::btree::map::entry::VacantEntry" "_root_.Aeneas.Std.alloc.collections.btree.map.entry.VacantEntry" ~keep_params:(Some [true; true; false]) ~mut_regions:([0]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 11 *)
  mk_type "alloc::collections::btree::set::BTreeSet" "_root_.Aeneas.Std.alloc.collections.btree.set.BTreeSet" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 17 *)
  mk_type "alloc::collections::btree::set::IntoIter" "_root_.Aeneas.Std.alloc.collections.btree.set.IntoIter" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 23 *)
  mk_type "alloc::collections::btree::set::Iter" "_root_.Aeneas.Std.alloc.collections.btree.set.Iter";
  (* file: "Aeneas/Std/VecDeque.lean", line: 15 *)
  mk_type "alloc::collections::vec_deque::VecDeque" "_root_.Aeneas.Std.alloc.collections.vec_deque.VecDeque" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Sync.lean", line: 32 *)
  mk_type "alloc::rc::Rc" "_root_.Aeneas.Std.alloc.rc.Rc";
  (* file: "Aeneas/Std/Alloc.lean", line: 11 *)
  mk_type "alloc::string::String" "_root_.String";
  (* file: "Aeneas/Std/Sync.lean", line: 29 *)
  mk_type "alloc::sync::Arc" "_root_.Aeneas.Std.alloc.sync.Arc";
  (* file: "Aeneas/Std/Vec.lean", line: 20 *)
  mk_type "alloc::vec::Vec" "_root_.Aeneas.Std.alloc.vec.Vec";
  (* file: "Aeneas/Std/VecDrain.lean", line: 14 *)
  mk_type "alloc::vec::drain::Drain" "_root_.Aeneas.Std.alloc.vec.drain.Drain" ~keep_params:(Some [true; false]) ~mut_regions:([0]);
  (* file: "Aeneas/Std/VecIter.lean", line: 10 *)
  mk_type "alloc::vec::into_iter::IntoIter" "_root_.Aeneas.Std.alloc.vec.into_iter.IntoIter" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/ChelisNative.lean", line: 29 *)
  mk_type "chelis_ir::capacity_key::CapacityScopeSupply" "_root_.Aeneas.Std.chelis_ir.capacity_key.CapacityScopeSupply";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 159 *)
  mk_type "chelis_ir::lowering_runtime::LoweringRuntime" "_root_.Aeneas.Std.chelis_ir.lowering_runtime.LoweringRuntime";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 55 *)
  mk_type "chelis_types::native::NativeServices" "_root_.Aeneas.Std.chelis_types.native.NativeServices";
  (* file: "Aeneas/Std/Core/Ptr.lean", line: 78 *)
  mk_type "core::alloc::layout::Layout" "_root_.Aeneas.Std.core.alloc.layout.Layout" ~kind:(KStruct [("size", Some "size"); ("align", Some "align")]);
  (* file: "Aeneas/Std/Core/Any.lean", line: 11 *)
  mk_type "core::any::TypeId" "_root_.Aeneas.Std.core.any.TypeId";
  (* file: "Aeneas/Std/Array/ArraySlice.lean", line: 115 *)
  mk_type "core::array::TryFromSliceError" "_root_.Aeneas.Std.core.array.TryFromSliceError";
  (* file: "Aeneas/Std/ArrayIter.lean", line: 8 *)
  mk_type "core::array::iter::IntoIter" "_root_.Aeneas.Std.core.array.iter.IntoIter";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 32 *)
  mk_type "core::cmp::Ordering" "_root_.Ordering" ~kind:(KEnum [("Less", Some "lt"); ("Equal", Some "eq"); ("Greater", Some "gt")]);
  (* file: "Aeneas/Std/Core/Reverse.lean", line: 12 *)
  mk_type "core::cmp::Reverse" "_root_.Aeneas.Std.core.cmp.Reverse";
  (* file: "Aeneas/Std/Core/Core.lean", line: 46 *)
  mk_type "core::convert::Infallible" "_root_.Aeneas.Std.core.convert.Infallible" ~kind:(KEnum []);
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 137 *)
  mk_type "core::fmt::Arguments" "_root_.Aeneas.Std.core.fmt.Arguments" ~kind:(KEnum [("Literal", Some "literal"); ("Template", Some "template")]);
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 8 *)
  mk_type "core::fmt::Error" "_root_.Aeneas.Std.core.fmt.Error";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 32 *)
  mk_type "core::fmt::Formatter" "_root_.Aeneas.Std.core.fmt.Formatter" ~kind:(KStruct [("output", Some "output"); ("options", Some "options"); ("write", Some "write"); ("indent", Some "indent"); ("lineStart", Some "lineStart")]);
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 397 *)
  mk_type "core::fmt::builders::DebugStruct" "_root_.Aeneas.Std.core.fmt.DebugStruct" ~mut_regions:([0]);
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 132 *)
  mk_type "core::fmt::rt::Argument" "_root_.Aeneas.Std.core.fmt.rt.Argument" ~kind:(KEnum [("Placeholder", Some "placeholder"); ("Count", Some "count")]);
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 22 *)
  mk_type "core::iter::adapters::chain::Chain" "_root_.Aeneas.Std.core.iter.adapters.chain.Chain" ~state_merge:(Some ("Aeneas.Std.core.iter.adapters.chain.Chain.recombine", [0; 1]));
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 803 *)
  mk_type "core::iter::adapters::cloned::Cloned" "_root_.Aeneas.Std.core.iter.adapters.cloned.Cloned" ~kind:(KStruct [("it", Some "it")]);
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 799 *)
  mk_type "core::iter::adapters::copied::Copied" "_root_.Aeneas.Std.core.iter.adapters.copied.Copied" ~kind:(KStruct [("it", Some "it")]);
  (* file: "Aeneas/Std/Core/Iter.lean", line: 85 *)
  mk_type "core::iter::adapters::enumerate::Enumerate" "_root_.Aeneas.Std.core.iter.adapters.enumerate.Enumerate" ~kind:(KStruct [("iter", Some "iter"); ("count", Some "count")]);
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 1032 *)
  mk_type "core::iter::adapters::filter::Filter" "_root_.Aeneas.Std.core.iter.adapters.filter.Filter" ~kind:(KStruct [("iter", Some "iter"); ("predicate", Some "predicate")]);
  (* file: "Aeneas/Std/Core/Iter.lean", line: 95 *)
  mk_type "core::iter::adapters::filter_map::FilterMap" "_root_.Aeneas.Std.core.iter.adapters.filter_map.FilterMap" ~kind:(KStruct [("iter", Some "iter"); ("f", Some "f")]);
  (* file: "Aeneas/Std/FlatMap.lean", line: 48 *)
  mk_type "core::iter::adapters::flatten::FlatMap" "_root_.Aeneas.Std.core.iter.adapters.flatten.FlatMap" ~keep_params:(Some [true; false; true; false; true]) ~state_merge:(Some ("Aeneas.Std.core.iter.adapters.flatten.FlatMap.recombine", [0; 2]));
  (* file: "Aeneas/Std/FlatMap.lean", line: 712 *)
  mk_type "core::iter::adapters::flatten::Flatten" "_root_.Aeneas.Std.core.iter.adapters.flatten.Flatten" ~keep_params:(Some [true; false; false; true]) ~state_merge:(Some ("Aeneas.Std.core.iter.adapters.flatten.Flatten.recombine", [0]));
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1918 *)
  mk_type "core::iter::adapters::map::Map" "_root_.Aeneas.Std.core.iter.adapters.map.Map" ~kind:(KStruct [("iter", Some "iter"); ("f", Some "f")]);
  (* file: "Aeneas/Std/Core/Iter.lean", line: 100 *)
  mk_type "core::iter::adapters::rev::Rev" "_root_.Aeneas.Std.core.iter.adapters.rev.Rev" ~kind:(KStruct [("iter", Some "iter")]);
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 51 *)
  mk_type "core::iter::adapters::skip::Skip" "_root_.Aeneas.Std.core.iter.adapters.skip.Skip" ~state_merge:(Some ("Aeneas.Std.core.iter.adapters.skip.Skip.recombine", [0]));
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 1217 *)
  mk_type "core::iter::adapters::skip_while::SkipWhile" "_root_.Aeneas.Std.core.iter.adapters.skip_while.SkipWhile" ~kind:(KStruct [("iter", Some "iter"); ("flag", Some "flag"); ("predicate", Some "predicate")]);
  (* file: "Aeneas/Std/Core/Iter.lean", line: 81 *)
  mk_type "core::iter::adapters::step_by::StepBy" "_root_.Aeneas.Std.core.iter.adapters.step_by.StepBy" ~state_merge:(Some ("Aeneas.Std.core.iter.adapters.step_by.StepBy.recombine", [0]));
  (* file: "Aeneas/Std/Core/Iter.lean", line: 90 *)
  mk_type "core::iter::adapters::take::Take" "_root_.Aeneas.Std.core.iter.adapters.take.Take" ~kind:(KStruct [("iter", Some "iter"); ("n", Some "n")]);
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 38 *)
  mk_type "core::iter::adapters::zip::Zip" "_root_.Aeneas.Std.core.iter.adapters.zip.Zip" ~state_merge:(Some ("Aeneas.Std.core.iter.adapters.zip.Zip.recombine", [0; 1]));
  (* file: "Aeneas/Std/IteratorSources.lean", line: 447 *)
  mk_type "core::iter::sources::empty::Empty" "_root_.Aeneas.Std.core.iter.sources.empty.Empty";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 280 *)
  mk_type "core::iter::sources::once::Once" "_root_.Aeneas.Std.core.iter.sources.once.Once";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 390 *)
  mk_type "core::iter::sources::repeat_with::RepeatWith" "_root_.Aeneas.Std.core.iter.sources.repeat_with.RepeatWith" ~state_merge:(Some ("Aeneas.Std.core.iter.sources.repeat_with.RepeatWith.recombine", [0]));
  (* file: "Aeneas/Std/Core/Discriminant.lean", line: 90 *)
  mk_type "core::mem::Discriminant" "_root_.Aeneas.Std.core.mem.Discriminant" ~kind:(KStruct [("value", Some "value"); ("bits", Some "bits")]);
  (* file: "Aeneas/Std/Parse.lean", line: 183 *)
  mk_type "core::num::dec2flt::FloatErrorKind" "_root_.Aeneas.Std.core.num.dec2flt.FloatErrorKind" ~kind:(KEnum [("Empty", Some "Empty"); ("Invalid", Some "Invalid")]);
  (* file: "Aeneas/Std/Parse.lean", line: 189 *)
  mk_type "core::num::dec2flt::ParseFloatError" "_root_.Aeneas.Std.core.num.dec2flt.ParseFloatError" ~kind:(KStruct [("kind", Some "kind")]);
  (* file: "Aeneas/Std/Parse.lean", line: 30 *)
  mk_type "core::num::error::IntErrorKind" "_root_.Aeneas.Std.core.num.error.IntErrorKind" ~kind:(KEnum [("Empty", Some "Empty"); ("InvalidDigit", Some "InvalidDigit"); ("PosOverflow", Some "PosOverflow"); ("NegOverflow", Some "NegOverflow"); ("Zero", Some "Zero")]);
  (* file: "Aeneas/Std/Parse.lean", line: 36 *)
  mk_type "core::num::error::ParseIntError" "_root_.Aeneas.Std.core.num.error.ParseIntError" ~kind:(KStruct [("kind", Some "kind")]);
  (* file: "Aeneas/Std/Core/Convert.lean", line: 8 *)
  mk_type "core::num::error::TryFromIntError" "_root_.Aeneas.Std.core.num.error.TryFromIntError";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 63 *)
  mk_type "core::num::niche_types::NonZeroCharInner" "_root_.Aeneas.Std.core.num.niche_types.NonZeroCharInner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 57 *)
  mk_type "core::num::niche_types::NonZeroI128Inner" "_root_.Aeneas.Std.core.num.niche_types.NonZeroI128Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 48 *)
  mk_type "core::num::niche_types::NonZeroI16Inner" "_root_.Aeneas.Std.core.num.niche_types.NonZeroI16Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 51 *)
  mk_type "core::num::niche_types::NonZeroI32Inner" "_root_.Aeneas.Std.core.num.niche_types.NonZeroI32Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 54 *)
  mk_type "core::num::niche_types::NonZeroI64Inner" "_root_.Aeneas.Std.core.num.niche_types.NonZeroI64Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 45 *)
  mk_type "core::num::niche_types::NonZeroI8Inner" "_root_.Aeneas.Std.core.num.niche_types.NonZeroI8Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 60 *)
  mk_type "core::num::niche_types::NonZeroIsizeInner" "_root_.Aeneas.Std.core.num.niche_types.NonZeroIsizeInner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 39 *)
  mk_type "core::num::niche_types::NonZeroU128Inner" "_root_.Aeneas.Std.core.num.niche_types.NonZeroU128Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 30 *)
  mk_type "core::num::niche_types::NonZeroU16Inner" "_root_.Aeneas.Std.core.num.niche_types.NonZeroU16Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 33 *)
  mk_type "core::num::niche_types::NonZeroU32Inner" "_root_.Aeneas.Std.core.num.niche_types.NonZeroU32Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 36 *)
  mk_type "core::num::niche_types::NonZeroU64Inner" "_root_.Aeneas.Std.core.num.niche_types.NonZeroU64Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 27 *)
  mk_type "core::num::niche_types::NonZeroU8Inner" "_root_.Aeneas.Std.core.num.niche_types.NonZeroU8Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 42 *)
  mk_type "core::num::niche_types::NonZeroUsizeInner" "_root_.Aeneas.Std.core.num.niche_types.NonZeroUsizeInner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 14 *)
  mk_type "core::num::nonzero::NonZero" "_root_.Aeneas.Std.core.num.nonzero.NonZero" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Core/Ops.lean", line: 233 *)
  mk_type "core::ops::control_flow::ControlFlow" "_root_.Aeneas.Std.core.ops.control_flow.ControlFlow" ~kind:(KEnum [("Continue", Some "Continue"); ("Break", Some "Break")]);
  (* file: "Aeneas/Std/RangeBounds.lean", line: 10 *)
  mk_type "core::ops::range::Bound" "_root_.Aeneas.Std.core.ops.range.Bound" ~kind:(KEnum [("Included", Some "Included"); ("Excluded", Some "Excluded"); ("Unbounded", Some "Unbounded")]);
  (* file: "Aeneas/Std/Range.lean", line: 14 *)
  mk_type "core::ops::range::Range" "_root_.Aeneas.Std.core.ops.range.Range" ~kind:(KStruct [("start", Some "start"); ("end", Some "«end»")]);
  (* file: "Aeneas/Std/Core/Core.lean", line: 215 *)
  mk_type "core::ops::range::RangeFrom" "_root_.Aeneas.Std.core.ops.range.RangeFrom" ~kind:(KStruct [("start", Some "start")]);
  (* file: "Aeneas/Std/Range.lean", line: 27 *)
  mk_type "core::ops::range::RangeFull" "_root_.Aeneas.Std.core.ops.range.RangeFull";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 21 *)
  mk_type "core::ops::range::RangeInclusive" "_root_.Aeneas.Std.core.ops.range.RangeInclusive";
  (* file: "Aeneas/Std/Range.lean", line: 20 *)
  mk_type "core::ops::range::RangeTo" "_root_.Aeneas.Std.core.ops.range.RangeTo" ~kind:(KStruct [("end", Some "«end»")]);
  (* file: "Aeneas/Std/IteratorSources.lean", line: 540 *)
  mk_type "core::option::IntoIter" "_root_.Aeneas.Std.core.option.IntoIter";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 485 *)
  mk_type "core::option::Iter" "_root_.Aeneas.Std.core.option.Iter";
  (* file: "Aeneas/Std/Core/Core.lean", line: 12 *)
  mk_type "core::option::Option" "_root_.Option" ~prefix_variant_names:false ~kind:(KEnum [("None", Some "none"); ("Some", Some "some")]);
  (* file: "Aeneas/Std/Core/Panic.lean", line: 6 *)
  mk_type "core::panic::panic_info::PanicInfo" "_root_.Aeneas.Std.core.panic.panic_info.PanicInfo";
  (* file: "Aeneas/Std/Core/UnwindSafe.lean", line: 14 *)
  mk_type "core::panic::unwind_safe::AssertUnwindSafe" "_root_.Aeneas.Std.core.panic.unwind_safe.AssertUnwindSafe";
  (* file: "Aeneas/Std/Core/Core.lean", line: 219 *)
  mk_type "core::panicking::AssertKind" "_root_.Aeneas.Std.core.panicking.AssertKind" ~kind:(KEnum [("Eq", Some "Eq"); ("Ne", Some "Ne"); ("Match", Some "Match")]);
  (* file: "Aeneas/Std/Core/Pin.lean", line: 6 *)
  mk_type "core::pin::Pin" "_root_.Aeneas.Std.core.pin.Pin";
  (* file: "Aeneas/Std/Core/Pin.lean", line: 10 *)
  mk_type "core::pin::helper::PinHelper" "_root_.Aeneas.Std.core.pin.helper.PinHelper";
  (* file: "Aeneas/Std/Core/Ptr.lean", line: 74 *)
  mk_type "core::ptr::alignment::Alignment" "_root_.Aeneas.Std.core.ptr.alignment.Alignment";
  (* file: "Aeneas/Std/Core/Ptr.lean", line: 7 *)
  mk_type "core::ptr::alignment::AlignmentEnum" "_root_.Aeneas.Std.core.ptr.alignment.AlignmentEnum" ~kind:(KEnum [("_Align1Shl0", Some "_Align1Shl0"); ("_Align1Shl1", Some "_Align1Shl1"); ("_Align1Shl2", Some "_Align1Shl2"); ("_Align1Shl3", Some "_Align1Shl3"); ("_Align1Shl4", Some "_Align1Shl4"); ("_Align1Shl5", Some "_Align1Shl5"); ("_Align1Shl6", Some "_Align1Shl6"); ("_Align1Shl7", Some "_Align1Shl7"); ("_Align1Shl8", Some "_Align1Shl8"); ("_Align1Shl9", Some "_Align1Shl9"); ("_Align1Shl10", Some "_Align1Shl10"); ("_Align1Shl11", Some "_Align1Shl11"); ("_Align1Shl12", Some "_Align1Shl12"); ("_Align1Shl13", Some "_Align1Shl13"); ("_Align1Shl14", Some "_Align1Shl14"); ("_Align1Shl15", Some "_Align1Shl15"); ("_Align1Shl16", Some "_Align1Shl16"); ("_Align1Shl17", Some "_Align1Shl17"); ("_Align1Shl18", Some "_Align1Shl18"); ("_Align1Shl19", Some "_Align1Shl19"); ("_Align1Shl20", Some "_Align1Shl20"); ("_Align1Shl21", Some "_Align1Shl21"); ("_Align1Shl22", Some "_Align1Shl22"); ("_Align1Shl23", Some "_Align1Shl23"); ("_Align1Shl24", Some "_Align1Shl24"); ("_Align1Shl25", Some "_Align1Shl25"); ("_Align1Shl26", Some "_Align1Shl26"); ("_Align1Shl27", Some "_Align1Shl27"); ("_Align1Shl28", Some "_Align1Shl28"); ("_Align1Shl29", Some "_Align1Shl29"); ("_Align1Shl30", Some "_Align1Shl30"); ("_Align1Shl31", Some "_Align1Shl31"); ("_Align1Shl32", Some "_Align1Shl32"); ("_Align1Shl33", Some "_Align1Shl33"); ("_Align1Shl34", Some "_Align1Shl34"); ("_Align1Shl35", Some "_Align1Shl35"); ("_Align1Shl36", Some "_Align1Shl36"); ("_Align1Shl37", Some "_Align1Shl37"); ("_Align1Shl38", Some "_Align1Shl38"); ("_Align1Shl39", Some "_Align1Shl39"); ("_Align1Shl40", Some "_Align1Shl40"); ("_Align1Shl41", Some "_Align1Shl41"); ("_Align1Shl42", Some "_Align1Shl42"); ("_Align1Shl43", Some "_Align1Shl43"); ("_Align1Shl44", Some "_Align1Shl44"); ("_Align1Shl45", Some "_Align1Shl45"); ("_Align1Shl46", Some "_Align1Shl46"); ("_Align1Shl47", Some "_Align1Shl47"); ("_Align1Shl48", Some "_Align1Shl48"); ("_Align1Shl49", Some "_Align1Shl49"); ("_Align1Shl50", Some "_Align1Shl50"); ("_Align1Shl51", Some "_Align1Shl51"); ("_Align1Shl52", Some "_Align1Shl52"); ("_Align1Shl53", Some "_Align1Shl53"); ("_Align1Shl54", Some "_Align1Shl54"); ("_Align1Shl55", Some "_Align1Shl55"); ("_Align1Shl56", Some "_Align1Shl56"); ("_Align1Shl57", Some "_Align1Shl57"); ("_Align1Shl58", Some "_Align1Shl58"); ("_Align1Shl59", Some "_Align1Shl59"); ("_Align1Shl60", Some "_Align1Shl60"); ("_Align1Shl61", Some "_Align1Shl61"); ("_Align1Shl62", Some "_Align1Shl62"); ("_Align1Shl63", Some "_Align1Shl63")]);
  (* file: "Aeneas/Std/Core/Result.lean", line: 7 *)
  mk_type "core::result::Result" "_root_.Aeneas.Std.core.result.Result" ~kind:(KEnum [("Ok", Some "Ok"); ("Err", Some "Err")]);
  (* file: "Aeneas/Std/SliceIter.lean", line: 548 *)
  mk_type "core::slice::iter::Chunks" "_root_.Aeneas.Std.core.slice.iter.Chunks";
  (* file: "Aeneas/Std/SliceIter.lean", line: 668 *)
  mk_type "core::slice::iter::ChunksExact" "_root_.Aeneas.Std.core.slice.iter.ChunksExact";
  (* file: "Aeneas/Std/SliceIter.lean", line: 14 *)
  mk_type "core::slice::iter::Iter" "_root_.Aeneas.Std.core.slice.iter.Iter" ~kind:(KStruct [("slice", Some "slice"); ("i", Some "i"); ("back", Some "back")]);
  (* file: "Aeneas/Std/SliceIter.lean", line: 22 *)
  mk_type "core::slice::iter::IterMut" "_root_.Aeneas.Std.core.slice.iter.IterMut" ~mut_regions:([0]);
  (* file: "Aeneas/Std/SliceIter.lean", line: 438 *)
  mk_type "core::slice::iter::Windows" "_root_.Aeneas.Std.core.slice.iter.Windows";
  (* file: "Aeneas/Std/StringIter.lean", line: 689 *)
  mk_type "core::str::iter::Bytes" "_root_.Aeneas.Std.core.str.iter.Bytes";
  (* file: "Aeneas/Std/StringIter.lean", line: 72 *)
  mk_type "core::str::iter::Chars" "_root_.Aeneas.Std.core.str.iter.Chars";
  (* file: "Aeneas/Std/StringIter.lean", line: 172 *)
  mk_type "core::str::iter::Lines" "_root_.Aeneas.Std.core.str.iter.Lines";
  (* file: "Aeneas/Std/StringIter.lean", line: 830 *)
  mk_type "core::str::iter::RSplit" "_root_.Aeneas.Std.core.str.iter.RSplit";
  (* file: "Aeneas/Std/StringIter.lean", line: 252 *)
  mk_type "core::str::iter::Split" "_root_.Aeneas.Std.core.str.iter.Split";
  (* file: "Aeneas/Std/StringIter.lean", line: 648 *)
  mk_type "core::str::iter::SplitN" "_root_.Aeneas.Std.core.str.iter.SplitN";
  (* file: "Aeneas/Std/StringIter.lean", line: 10 *)
  mk_type "core::str::pattern::CharArraySearcher" "_root_.Aeneas.Std.core.str.pattern.CharArraySearcher";
  (* file: "Aeneas/Std/String.lean", line: 304 *)
  mk_type "core::str::pattern::CharSearcher" "_root_.Aeneas.Std.core.str.pattern.CharSearcher";
  (* file: "Aeneas/Std/String.lean", line: 246 *)
  mk_type "core::str::pattern::StrSearcher" "_root_.Aeneas.Std.core.str.pattern.StrSearcher";
  (* file: "Aeneas/Std/Core/Atomic.lean", line: 6 *)
  mk_type "core::sync::atomic::AtomicBool" "_root_.Aeneas.Std.core.sync.atomic.AtomicBool";
  (* file: "Aeneas/Std/Core/Atomic.lean", line: 10 *)
  mk_type "core::sync::atomic::AtomicU32" "_root_.Aeneas.Std.core.sync.atomic.AtomicU32";
  (* file: "Aeneas/Std/Float.lean", line: 37 *)
  mk_type "half::bfloat::bf16" "_root_.Aeneas.Std.BF16";
  (* file: "Aeneas/Std/Float.lean", line: 35 *)
  mk_type "half::binary16::f16" "_root_.Aeneas.Std.F16";
  (* file: "Aeneas/Std/BigUint.lean", line: 24 *)
  mk_type "num_bigint::TryFromBigIntError" "_root_.Aeneas.Std.num_bigint.TryFromBigIntError" ~kind:(KStruct [("original", Some "original")]);
  (* file: "Aeneas/Std/BigUint.lean", line: 20 *)
  mk_type "num_bigint::biguint::BigUint" "_root_.Aeneas.Std.num_bigint.BigUint";
  (* file: "Aeneas/Std/Serde/Content.lean", line: 409 *)
  mk_type "serde::private::de::content::ContentDeserializer" "_root_.Aeneas.Std.serde.private.de.content.ContentDeserializer";
  (* file: "Aeneas/Std/Serde/Content.lean", line: 41 *)
  mk_type "serde::private::de::content::ContentVisitor" "_root_.Aeneas.Std.serde.private.de.content.ContentVisitor";
  (* file: "Aeneas/Std/Serde/Content.lean", line: 306 *)
  mk_type "serde::private::de::content::TaggedContentVisitor" "_root_.Aeneas.Std.serde.private.de.content.TaggedContentVisitor";
  (* file: "Aeneas/Std/Serde/De.lean", line: 68 *)
  mk_type "serde_core::de::Unexpected" "_root_.Aeneas.Std.serde_core.de.Unexpected" ~kind:(KEnum [("Bool", Some "Bool"); ("Unsigned", Some "Unsigned"); ("Signed", Some "Signed"); ("Float", Some "Float"); ("Char", Some "Char"); ("Str", Some "Str"); ("Bytes", Some "Bytes"); ("Unit", Some "Unit"); ("Option", Some "Option"); ("NewtypeStruct", Some "NewtypeStruct"); ("Seq", Some "Seq"); ("Map", Some "Map"); ("Enum", Some "Enum"); ("UnitVariant", Some "UnitVariant"); ("NewtypeVariant", Some "NewtypeVariant"); ("TupleVariant", Some "TupleVariant"); ("StructVariant", Some "StructVariant"); ("Other", Some "Other")]);
  (* file: "Aeneas/Std/Serde/Content.lean", line: 186 *)
  mk_type "serde_core::de::value::SeqAccessDeserializer" "_root_.Aeneas.Std.serde_core.de.value.SeqAccessDeserializer";
  (* file: "Aeneas/Std/Serde/De.lean", line: 93 *)
  mk_type "serde_core::private::content::Content" "_root_.Aeneas.Std.serde_core.private.content.Content" ~kind:(KEnum [("Bool", Some "Bool"); ("U8", Some "U8"); ("U16", Some "U16"); ("U32", Some "U32"); ("U64", Some "U64"); ("I8", Some "I8"); ("I16", Some "I16"); ("I32", Some "I32"); ("I64", Some "I64"); ("F32", Some "F32"); ("F64", Some "F64"); ("Char", Some "Char"); ("String", Some "String"); ("Str", Some "Str"); ("ByteBuf", Some "ByteBuf"); ("Bytes", Some "Bytes"); ("None", Some "None"); ("Some", Some "Some"); ("Unit", Some "Unit"); ("Newtype", Some "Newtype"); ("Seq", Some "Seq"); ("Map", Some "Map")]);
]

let lean_builtin_consts = [
  (* file: "Aeneas/Std/Float.lean", line: 464 *)
  mk_global "core::f64::{f64}::INFINITY" "_root_.Aeneas.Std.F64.INFINITY" ~can_fail:false;
  (* file: "Aeneas/Std/Float.lean", line: 467 *)
  mk_global "core::f64::{f64}::NEG_INFINITY" "_root_.Aeneas.Std.F64.NEG_INFINITY" ~can_fail:false;
  (* file: "Aeneas/Std/Half.lean", line: 370 *)
  mk_global "half::bfloat::{half::bfloat::bf16}::INFINITY" "_root_.Aeneas.Std.BF16.INFINITY" ~can_fail:false;
  (* file: "Aeneas/Std/Half.lean", line: 374 *)
  mk_global "half::bfloat::{half::bfloat::bf16}::MAX" "_root_.Aeneas.Std.BF16.MAX" ~can_fail:false;
  (* file: "Aeneas/Std/Half.lean", line: 372 *)
  mk_global "half::bfloat::{half::bfloat::bf16}::NAN" "_root_.Aeneas.Std.BF16.NAN" ~can_fail:false;
  (* file: "Aeneas/Std/Half.lean", line: 366 *)
  mk_global "half::bfloat::{half::bfloat::bf16}::NEG_ZERO" "_root_.Aeneas.Std.BF16.NEG_ZERO" ~can_fail:false;
  (* file: "Aeneas/Std/Half.lean", line: 368 *)
  mk_global "half::bfloat::{half::bfloat::bf16}::ONE" "_root_.Aeneas.Std.BF16.ONE" ~can_fail:false;
  (* file: "Aeneas/Std/Half.lean", line: 364 *)
  mk_global "half::bfloat::{half::bfloat::bf16}::ZERO" "_root_.Aeneas.Std.BF16.ZERO" ~can_fail:false;
  (* file: "Aeneas/Std/Half.lean", line: 297 *)
  mk_global "half::binary16::{half::binary16::f16}::INFINITY" "_root_.Aeneas.Std.F16.INFINITY" ~can_fail:false;
  (* file: "Aeneas/Std/Half.lean", line: 301 *)
  mk_global "half::binary16::{half::binary16::f16}::MAX" "_root_.Aeneas.Std.F16.MAX" ~can_fail:false;
  (* file: "Aeneas/Std/Half.lean", line: 299 *)
  mk_global "half::binary16::{half::binary16::f16}::NAN" "_root_.Aeneas.Std.F16.NAN" ~can_fail:false;
  (* file: "Aeneas/Std/Half.lean", line: 293 *)
  mk_global "half::binary16::{half::binary16::f16}::NEG_ZERO" "_root_.Aeneas.Std.F16.NEG_ZERO" ~can_fail:false;
  (* file: "Aeneas/Std/Half.lean", line: 295 *)
  mk_global "half::binary16::{half::binary16::f16}::ONE" "_root_.Aeneas.Std.F16.ONE" ~can_fail:false;
  (* file: "Aeneas/Std/Half.lean", line: 291 *)
  mk_global "half::binary16::{half::binary16::f16}::ZERO" "_root_.Aeneas.Std.F16.ZERO" ~can_fail:false;
]

let lean_builtin_funs = [
  (* file: "Aeneas/Std/Alloc.lean", line: 25 *)
  mk_fun "alloc::alloc::{core::clone::Clone<alloc::alloc::Global>}::clone" "_root_.Aeneas.Std.alloc.alloc.CloneGlobal.clone";
  (* file: "Aeneas/Std/Core/Borrow.lean", line: 58 *)
  mk_fun "alloc::borrow::{alloc::borrow::ToOwned<@T, @T>}::clone_into" "_root_.Aeneas.Std.alloc.borrow.ToOwnedClone.clone_into";
  (* file: "Aeneas/Std/Core/Borrow.lean", line: 52 *)
  mk_fun "alloc::borrow::{alloc::borrow::ToOwned<@T, @T>}::to_owned" "_root_.Aeneas.Std.alloc.borrow.ToOwnedClone.to_owned";
  (* file: "Aeneas/Std/Core/Borrow.lean", line: 102 *)
  mk_fun "alloc::borrow::{core::convert::AsRef<alloc::borrow::Cow<'0, @T, @O>, @T>}::as_ref" "_root_.Aeneas.Std.alloc.borrow.AsRefCow.as_ref";
  (* file: "Aeneas/Std/Core/Borrow.lean", line: 88 *)
  mk_fun "alloc::borrow::{core::ops::deref::Deref<alloc::borrow::Cow<'0, @B, @O>, @B>}::deref" "_root_.Aeneas.Std.alloc.borrow.DerefCow.deref";
  (* file: "Aeneas/Std/Core/Core.lean", line: 61 *)
  mk_fun "alloc::boxed::convert::{core::convert::From<Box<@T>, @T>}::from" "_root_.Aeneas.Std.core.convert.FromBox.from_" ~can_fail:false;
  (* file: "Aeneas/Std/String.lean", line: 614 *)
  mk_fun "alloc::boxed::convert::{core::convert::From<Box<str>, &'0 str>}::from" "_root_.Aeneas.Std.alloc.boxed.convert.FromSharedStrBoxStr.from_";
  (* file: "Aeneas/Std/VecIter.lean", line: 182 *)
  mk_fun "alloc::boxed::iter::{core::iter::traits::collect::IntoIterator<Box<[@I]>, @I, alloc::vec::into_iter::IntoIter<@I, @A>>}::into_iter" "_root_.Aeneas.Std.alloc.boxed.IntoIteratorBoxSlice.into_iter" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Core/Core.lean", line: 126 *)
  mk_fun "alloc::boxed::{core::clone::Clone<Box<@T>>}::clone" "_root_.Aeneas.Std.core.alloc.boxed.CloneBox.clone" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 753 *)
  mk_fun "alloc::boxed::{core::clone::Clone<Box<[@T]>>}::clone" "_root_.Aeneas.Std.alloc.boxed.CloneBoxSlice.clone" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/String.lean", line: 214 *)
  mk_fun "alloc::boxed::{core::clone::Clone<Box<str>>}::clone" "_root_.Aeneas.Std.alloc.boxed.CloneBoxStr.clone";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 371 *)
  mk_fun "alloc::boxed::{core::cmp::Ord<Box<@T>>}::cmp" "_root_.Aeneas.Std.alloc.boxed.OrdBox.cmp" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 311 *)
  mk_fun "alloc::boxed::{core::cmp::PartialEq<Box<@T>, Box<@T>>}::eq" "_root_.Aeneas.Std.alloc.boxed.PartialEqBox.eq" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 316 *)
  mk_fun "alloc::boxed::{core::cmp::PartialEq<Box<@T>, Box<@T>>}::ne" "_root_.Aeneas.Std.alloc.boxed.PartialEqBox.ne" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 355 *)
  mk_fun "alloc::boxed::{core::cmp::PartialOrd<Box<@T>, Box<@T>>}::ge" "_root_.Aeneas.Std.alloc.boxed.PartialOrdBox.ge" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 350 *)
  mk_fun "alloc::boxed::{core::cmp::PartialOrd<Box<@T>, Box<@T>>}::gt" "_root_.Aeneas.Std.alloc.boxed.PartialOrdBox.gt" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 345 *)
  mk_fun "alloc::boxed::{core::cmp::PartialOrd<Box<@T>, Box<@T>>}::le" "_root_.Aeneas.Std.alloc.boxed.PartialOrdBox.le" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 340 *)
  mk_fun "alloc::boxed::{core::cmp::PartialOrd<Box<@T>, Box<@T>>}::lt" "_root_.Aeneas.Std.alloc.boxed.PartialOrdBox.lt" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 335 *)
  mk_fun "alloc::boxed::{core::cmp::PartialOrd<Box<@T>, Box<@T>>}::partial_cmp" "_root_.Aeneas.Std.alloc.boxed.PartialOrdBox.partial_cmp" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Core/Core.lean", line: 14 *)
  mk_fun "alloc::boxed::{core::convert::AsMut<Box<@T>, @T>}::as_mut" "_root_.Aeneas.Std.alloc.boxed.AsMutBox.as_mut" ~keep_params:(Some [true; false]) ~can_fail:false;
  (* file: "Aeneas/Std/Core/Core.lean", line: 19 *)
  mk_fun "alloc::boxed::{core::convert::AsRef<Box<@T>, @T>}::as_ref" "_root_.Aeneas.Std.alloc.boxed.AsRefBox.as_ref" ~keep_params:(Some [true; false]) ~can_fail:false;
  (* file: "Aeneas/Std/Core/Default.lean", line: 23 *)
  mk_fun "alloc::boxed::{core::default::Default<Box<@T>>}::default" "_root_.Aeneas.Std.alloc.boxed.DefaultBox.default";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 88 *)
  mk_fun "alloc::boxed::{core::fmt::Debug<alloc::boxed::Box<@T>>}::fmt" "_root_.Aeneas.Std.core.fmt.DebugBox.fmt" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 93 *)
  mk_fun "alloc::boxed::{core::fmt::Display<alloc::boxed::Box<@T>>}::fmt" "_root_.Aeneas.Std.core.fmt.DisplayBox.fmt" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Core/Hash.lean", line: 137 *)
  mk_fun "alloc::boxed::{core::hash::Hash<Box<@T>>}::hash" "_root_.Aeneas.Std.alloc.boxed.HashBox.hash" ~keep_params:(Some [true; false; true]);
  (* file: "Aeneas/Std/Alloc.lean", line: 19 *)
  mk_fun "alloc::boxed::{core::ops::deref::Deref<Box<@T>, @T>}::deref" "_root_.Aeneas.Std.alloc.boxed.Box.deref" ~keep_params:(Some [true; false]) ~can_fail:false;
  (* file: "Aeneas/Std/Alloc.lean", line: 22 *)
  mk_fun "alloc::boxed::{core::ops::deref::DerefMut<Box<@T>, @T>}::deref_mut" "_root_.Aeneas.Std.alloc.boxed.Box.deref_mut" ~keep_params:(Some [true; false]) ~can_fail:false;
  (* file: "Aeneas/Std/BTreeMap.lean", line: 376 *)
  mk_fun "alloc::collections::btree::map::entry::{alloc::collections::btree::map::entry::Entry<'a, @K, @V, @A>}::key" "_root_.Aeneas.Std.alloc.collections.btree.map.entry.Entry.key" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 415 *)
  mk_fun "alloc::collections::btree::map::entry::{alloc::collections::btree::map::entry::OccupiedEntry<'a, @K, @V, @A>}::get" "_root_.Aeneas.Std.alloc.collections.btree.map.entry.OccupiedEntry.get" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 423 *)
  mk_fun "alloc::collections::btree::map::entry::{alloc::collections::btree::map::entry::OccupiedEntry<'a, @K, @V, @A>}::get_mut" "_root_.Aeneas.Std.alloc.collections.btree.map.entry.OccupiedEntry.get_mut" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 431 *)
  mk_fun "alloc::collections::btree::map::entry::{alloc::collections::btree::map::entry::OccupiedEntry<'a, @K, @V, @A>}::insert" "_root_.Aeneas.Std.alloc.collections.btree.map.entry.OccupiedEntry.insert" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 356 *)
  mk_fun "alloc::collections::btree::map::entry::{alloc::collections::btree::map::entry::OccupiedEntry<'a, @K, @V, @A>}::into_mut" "_root_.Aeneas.Std.alloc.collections.btree.map.entry.OccupiedEntry.into_mut" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 409 *)
  mk_fun "alloc::collections::btree::map::entry::{alloc::collections::btree::map::entry::OccupiedEntry<'a, @K, @V, @A>}::key" "_root_.Aeneas.Std.alloc.collections.btree.map.entry.OccupiedEntry.key_" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 439 *)
  mk_fun "alloc::collections::btree::map::entry::{alloc::collections::btree::map::entry::OccupiedEntry<'a, @K, @V, @A>}::remove" "_root_.Aeneas.Std.alloc.collections.btree.map.entry.OccupiedEntry.remove" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 446 *)
  mk_fun "alloc::collections::btree::map::entry::{alloc::collections::btree::map::entry::OccupiedEntry<'a, @K, @V, @A>}::remove_entry" "_root_.Aeneas.Std.alloc.collections.btree.map.entry.OccupiedEntry.remove_entry" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 362 *)
  mk_fun "alloc::collections::btree::map::entry::{alloc::collections::btree::map::entry::VacantEntry<'a, @K, @V, @A>}::insert" "_root_.Aeneas.Std.alloc.collections.btree.map.entry.VacantEntry.insert" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 386 *)
  mk_fun "alloc::collections::btree::map::entry::{alloc::collections::btree::map::entry::VacantEntry<'a, @K, @V, @A>}::insert_entry" "_root_.Aeneas.Std.alloc.collections.btree.map.entry.VacantEntry.insert_entry" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 402 *)
  mk_fun "alloc::collections::btree::map::entry::{alloc::collections::btree::map::entry::VacantEntry<'a, @K, @V, @A>}::into_key" "_root_.Aeneas.Std.alloc.collections.btree.map.entry.VacantEntry.into_key" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 395 *)
  mk_fun "alloc::collections::btree::map::entry::{alloc::collections::btree::map::entry::VacantEntry<'a, @K, @V, @A>}::key" "_root_.Aeneas.Std.alloc.collections.btree.map.entry.VacantEntry.key_" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 175 *)
  mk_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::clear" "_root_.Aeneas.Std.alloc.collections.btree.map.BTreeMap.clear" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 207 *)
  mk_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::contains_key" "_root_.Aeneas.Std.alloc.collections.btree.map.BTreeMap.contains_key" ~keep_params:(Some [true; true; false; true]) ~keep_trait_clauses:(Some [false; true; true; true]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 349 *)
  mk_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::entry" "_root_.Aeneas.Std.alloc.collections.btree.map.BTreeMap.entry" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [false; true]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 151 *)
  mk_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::get" "_root_.Aeneas.Std.alloc.collections.btree.map.BTreeMap.get" ~keep_params:(Some [true; true; false; true]) ~keep_trait_clauses:(Some [false; true; true; true]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 168 *)
  mk_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::get_key_value" "_root_.Aeneas.Std.alloc.collections.btree.map.BTreeMap.get_key_value" ~keep_params:(Some [true; true; false; true]) ~keep_trait_clauses:(Some [false; true; true; true]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 195 *)
  mk_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::get_mut" "_root_.Aeneas.Std.alloc.collections.btree.map.BTreeMap.get_mut" ~keep_params:(Some [true; true; false; true]) ~keep_trait_clauses:(Some [false; true; true; true]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 114 *)
  mk_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::insert" "_root_.Aeneas.Std.alloc.collections.btree.map.BTreeMap.insert" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [false; true]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 500 *)
  mk_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::into_values" "_root_.Aeneas.Std.alloc.collections.btree.map.BTreeMap.into_values" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 251 *)
  mk_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::is_empty" "_root_.Aeneas.Std.alloc.collections.btree.map.BTreeMap.is_empty" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 256 *)
  mk_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::iter" "_root_.Aeneas.Std.alloc.collections.btree.map.BTreeMap.iter" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 262 *)
  mk_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::keys" "_root_.Aeneas.Std.alloc.collections.btree.map.BTreeMap.keys" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 124 *)
  mk_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::len" "_root_.Aeneas.Std.alloc.collections.btree.map.BTreeMap.len" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 225 *)
  mk_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::remove" "_root_.Aeneas.Std.alloc.collections.btree.map.BTreeMap.remove" ~keep_params:(Some [true; true; false; true]) ~keep_trait_clauses:(Some [false; true; true; true]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 268 *)
  mk_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::values" "_root_.Aeneas.Std.alloc.collections.btree.map.BTreeMap.values" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 275 *)
  mk_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::values_mut" "_root_.Aeneas.Std.alloc.collections.btree.map.BTreeMap.values_mut" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 91 *)
  mk_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, alloc::alloc::Global>}::new" "_root_.Aeneas.Std.alloc.collections.btree.map.BTreeMap.new";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 133 *)
  mk_fun "alloc::collections::btree::map::{core::clone::Clone<alloc::collections::btree::map::BTreeMap<@K, @V, @A>>}::clone" "_root_.Aeneas.Std.alloc.collections.btree.map.BTreeMap.clone" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [true; true; false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 295 *)
  mk_fun "alloc::collections::btree::map::{core::cmp::PartialEq<alloc::collections::btree::map::BTreeMap<@K, @V, @A>, alloc::collections::btree::map::BTreeMap<@K, @V, @A>>}::eq" "_root_.Aeneas.Std.alloc.collections.btree.map.PartialEqBTreeMap.eq" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [true; true; false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 304 *)
  mk_fun "alloc::collections::btree::map::{core::cmp::PartialEq<alloc::collections::btree::map::BTreeMap<@K, @V, @A>, alloc::collections::btree::map::BTreeMap<@K, @V, @A>>}::ne" "_root_.Aeneas.Std.alloc.collections.btree.map.PartialEqBTreeMap.ne" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [true; true; false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 729 *)
  mk_fun "alloc::collections::btree::map::{core::convert::From<alloc::collections::btree::map::BTreeMap<@K, @V, alloc::alloc::Global>, [(@K, @V); @N]>}::from" "_root_.Aeneas.Std.alloc.collections.btree.map.FromBTreeMapArray.from_";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 95 *)
  mk_fun "alloc::collections::btree::map::{core::default::Default<alloc::collections::btree::map::BTreeMap<@K, @V, alloc::alloc::Global>>}::default" "_root_.Aeneas.Std.alloc.collections.btree.map.DefaultBTreeMap.default";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 322 *)
  mk_fun "alloc::collections::btree::map::{core::fmt::Debug<alloc::collections::btree::map::BTreeMap<@K, @V, @A>>}::fmt" "_root_.Aeneas.Std.alloc.collections.btree.map.DebugBTreeMap.fmt" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [true; true; false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 237 *)
  mk_fun "alloc::collections::btree::map::{core::iter::traits::collect::Extend<alloc::collections::btree::map::BTreeMap<@K, @V, @A>, (@K, @V)>}::extend" "_root_.Aeneas.Std.alloc.collections.btree.map.ExtendBTreeMap.extend" ~keep_params:(Some [true; true; false; true; true]) ~keep_trait_clauses:(Some [true; false; true]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 712 *)
  mk_fun "alloc::collections::btree::map::{core::iter::traits::collect::FromIterator<alloc::collections::btree::map::BTreeMap<@K, @V, alloc::alloc::Global>, (@K, @V)>}::from_iter" "_root_.Aeneas.Std.alloc.collections.btree.map.FromIteratorBTreeMap.from_iter";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 676 *)
  mk_fun "alloc::collections::btree::map::{core::iter::traits::collect::IntoIterator<&'a alloc::collections::btree::map::BTreeMap<@K, @V, @A>, (&'a @K, &'a @V), alloc::collections::btree::map::Iter<'a, @K, @V>>}::into_iter" "_root_.Aeneas.Std.alloc.collections.btree.map.IntoIteratorSharedBTreeMap.into_iter" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 668 *)
  mk_fun "alloc::collections::btree::map::{core::iter::traits::collect::IntoIterator<alloc::collections::btree::map::BTreeMap<@K, @V, @A>, (@K, @V), alloc::collections::btree::map::IntoIter<@K, @V, @A>>}::into_iter" "_root_.Aeneas.Std.alloc.collections.btree.map.IntoIteratorBTreeMap.into_iter" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 658 *)
  mk_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::IntoIter<@K, @V, @A>, (@K, @V)>}::collect" "_root_.Aeneas.Std.alloc.collections.btree.map.IteratorIntoIter.collect" ~keep_params:(Some [true; true; false; true]) ~keep_trait_clauses:(Some [false; true]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 577 *)
  mk_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::IntoIter<@K, @V, @A>, (@K, @V)>}::enumerate" "_root_.Aeneas.Std.alloc.collections.btree.map.IteratorIntoIter.enumerate" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 477 *)
  mk_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::IntoIter<@K, @V, @A>, (@K, @V)>}::next" "_root_.Aeneas.Std.alloc.collections.btree.map.IteratorIntoIter.next" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 491 *)
  mk_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::IntoIter<@K, @V, @A>, (@K, @V)>}::size_hint" "_root_.Aeneas.Std.alloc.collections.btree.map.IteratorIntoIter.size_hint" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 571 *)
  mk_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::IntoIter<@K, @V, @A>, (@K, @V)>}::step_by" "_root_.Aeneas.Std.alloc.collections.btree.map.IteratorIntoIter.step_by" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 582 *)
  mk_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::IntoIter<@K, @V, @A>, (@K, @V)>}::take" "_root_.Aeneas.Std.alloc.collections.btree.map.IteratorIntoIter.take" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 506 *)
  mk_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::IntoValues<@K, @V, @A>, @V>}::next" "_root_.Aeneas.Std.alloc.collections.btree.map.IteratorIntoValues.next" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 514 *)
  mk_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::IntoValues<@K, @V, @A>, @V>}::size_hint" "_root_.Aeneas.Std.alloc.collections.btree.map.IteratorIntoValues.size_hint" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 652 *)
  mk_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Iter<'a, @K, @V>, (&'a @K, &'a @V)>}::collect" "_root_.Aeneas.Std.alloc.collections.btree.map.IteratorIter.collect";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 563 *)
  mk_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Iter<'a, @K, @V>, (&'a @K, &'a @V)>}::enumerate" "_root_.Aeneas.Std.alloc.collections.btree.map.IteratorIter.enumerate";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 471 *)
  mk_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Iter<'a, @K, @V>, (&'a @K, &'a @V)>}::next" "_root_.Aeneas.Std.alloc.collections.btree.map.IteratorIter.next";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 485 *)
  mk_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Iter<'a, @K, @V>, (&'a @K, &'a @V)>}::size_hint" "_root_.Aeneas.Std.alloc.collections.btree.map.IteratorIter.size_hint";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 558 *)
  mk_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Iter<'a, @K, @V>, (&'a @K, &'a @V)>}::step_by" "_root_.Aeneas.Std.alloc.collections.btree.map.IteratorIter.step_by";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 567 *)
  mk_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Iter<'a, @K, @V>, (&'a @K, &'a @V)>}::take" "_root_.Aeneas.Std.alloc.collections.btree.map.IteratorIter.take";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 521 *)
  mk_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Keys<'a, @K, @V>, &'a @K>}::next" "_root_.Aeneas.Std.alloc.collections.btree.map.IteratorKeys.next";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 527 *)
  mk_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Keys<'a, @K, @V>, &'a @K>}::size_hint" "_root_.Aeneas.Std.alloc.collections.btree.map.IteratorKeys.size_hint";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 532 *)
  mk_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Values<'a, @K, @V>, &'a @V>}::next" "_root_.Aeneas.Std.alloc.collections.btree.map.IteratorValues.next";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 554 *)
  mk_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Values<'a, @K, @V>, &'a @V>}::size_hint" "_root_.Aeneas.Std.alloc.collections.btree.map.IteratorValues.size_hint";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 540 *)
  mk_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::ValuesMut<'a, @K, @V>, &'a mut @V>}::next" "_root_.Aeneas.Std.alloc.collections.btree.map.IteratorValuesMut.next";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 778 *)
  mk_fun "alloc::collections::btree::map::{core::ops::index::Index<alloc::collections::btree::map::BTreeMap<@K, @V, @A>, &'0 @Q, @V>}::index" "_root_.Aeneas.Std.alloc.collections.btree.map.IndexBTreeMap.index" ~keep_params:(Some [true; true; true; false]) ~keep_trait_clauses:(Some [false; true; true; true]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 53 *)
  mk_fun "alloc::collections::btree::set::{alloc::collections::btree::set::BTreeSet<@T, @A>}::clear" "_root_.Aeneas.Std.alloc.collections.btree.set.BTreeSet.clear" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false; false]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 32 *)
  mk_fun "alloc::collections::btree::set::{alloc::collections::btree::set::BTreeSet<@T, @A>}::contains" "_root_.Aeneas.Std.alloc.collections.btree.set.BTreeSet.contains" ~keep_params:(Some [true; false; true]) ~keep_trait_clauses:(Some [false; true; true; true]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 127 *)
  mk_fun "alloc::collections::btree::set::{alloc::collections::btree::set::BTreeSet<@T, @A>}::first" "_root_.Aeneas.Std.alloc.collections.btree.set.BTreeSet.first" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false; false]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 162 *)
  mk_fun "alloc::collections::btree::set::{alloc::collections::btree::set::BTreeSet<@T, @A>}::insert" "_root_.Aeneas.Std.alloc.collections.btree.set.BTreeSet.insert" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false; true]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 40 *)
  mk_fun "alloc::collections::btree::set::{alloc::collections::btree::set::BTreeSet<@T, @A>}::is_empty" "_root_.Aeneas.Std.alloc.collections.btree.set.BTreeSet.is_empty" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 196 *)
  mk_fun "alloc::collections::btree::set::{alloc::collections::btree::set::BTreeSet<@T, @A>}::iter" "_root_.Aeneas.Std.alloc.collections.btree.set.BTreeSet.iter" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 46 *)
  mk_fun "alloc::collections::btree::set::{alloc::collections::btree::set::BTreeSet<@T, @A>}::len" "_root_.Aeneas.Std.alloc.collections.btree.set.BTreeSet.len" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 170 *)
  mk_fun "alloc::collections::btree::set::{alloc::collections::btree::set::BTreeSet<@T, @A>}::remove" "_root_.Aeneas.Std.alloc.collections.btree.set.BTreeSet.remove" ~keep_params:(Some [true; false; true]) ~keep_trait_clauses:(Some [false; true; true; true]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 154 *)
  mk_fun "alloc::collections::btree::set::{alloc::collections::btree::set::BTreeSet<@T, @A>}::retain" "_root_.Aeneas.Std.alloc.collections.btree.set.BTreeSet.retain" ~keep_params:(Some [true; false; true]) ~keep_trait_clauses:(Some [false; true; true]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 111 *)
  mk_fun "alloc::collections::btree::set::{alloc::collections::btree::set::BTreeSet<@T, alloc::alloc::Global>}::new" "_root_.Aeneas.Std.alloc.collections.btree.set.BTreeSet.new";
  (* file: "Aeneas/Std/BTreeSet.lean", line: 60 *)
  mk_fun "alloc::collections::btree::set::{core::clone::Clone<alloc::collections::btree::set::BTreeSet<@T, @A>>}::clone" "_root_.Aeneas.Std.alloc.collections.btree.set.CloneBTreeSet.clone" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 69 *)
  mk_fun "alloc::collections::btree::set::{core::cmp::PartialEq<alloc::collections::btree::set::BTreeSet<@T, @A>, alloc::collections::btree::set::BTreeSet<@T, @A>>}::eq" "_root_.Aeneas.Std.alloc.collections.btree.set.PartialEqBTreeSet.eq" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 83 *)
  mk_fun "alloc::collections::btree::set::{core::cmp::PartialEq<alloc::collections::btree::set::BTreeSet<@T, @A>, alloc::collections::btree::set::BTreeSet<@T, @A>>}::ne" "_root_.Aeneas.Std.alloc.collections.btree.set.PartialEqBTreeSet.ne" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 261 *)
  mk_fun "alloc::collections::btree::set::{core::convert::From<alloc::collections::btree::set::BTreeSet<@T, alloc::alloc::Global>, [@T; @N]>}::from" "_root_.Aeneas.Std.alloc.collections.btree.set.FromArrayBTreeSet.from_";
  (* file: "Aeneas/Std/BTreeSet.lean", line: 116 *)
  mk_fun "alloc::collections::btree::set::{core::default::Default<alloc::collections::btree::set::BTreeSet<@T, alloc::alloc::Global>>}::default" "_root_.Aeneas.Std.alloc.collections.btree.set.DefaultBTreeSet.default";
  (* file: "Aeneas/Std/BTreeSet.lean", line: 99 *)
  mk_fun "alloc::collections::btree::set::{core::fmt::Debug<alloc::collections::btree::set::BTreeSet<@T, @A>>}::fmt" "_root_.Aeneas.Std.alloc.collections.btree.set.DebugBTreeSet.fmt" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 181 *)
  mk_fun "alloc::collections::btree::set::{core::iter::traits::collect::Extend<alloc::collections::btree::set::BTreeSet<@T, @A>, @T>}::extend" "_root_.Aeneas.Std.alloc.collections.btree.set.ExtendBTreeSet.extend" ~keep_params:(Some [true; false; true; true]) ~keep_trait_clauses:(Some [true; false; true]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 241 *)
  mk_fun "alloc::collections::btree::set::{core::iter::traits::collect::FromIterator<alloc::collections::btree::set::BTreeSet<@T, alloc::alloc::Global>, @T>}::from_iter" "_root_.Aeneas.Std.alloc.collections.btree.set.FromIteratorBTreeSet.from_iter";
  (* file: "Aeneas/Std/BTreeSet.lean", line: 322 *)
  mk_fun "alloc::collections::btree::set::{core::iter::traits::collect::IntoIterator<&'a alloc::collections::btree::set::BTreeSet<@T, @A>, &'a @T, alloc::collections::btree::set::Iter<'a, @T>>}::into_iter" "_root_.Aeneas.Std.alloc.collections.btree.set.IntoIteratorSharedBTreeSet.into_iter" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 229 *)
  mk_fun "alloc::collections::btree::set::{core::iter::traits::collect::IntoIterator<alloc::collections::btree::set::BTreeSet<@T, @A>, @T, alloc::collections::btree::set::IntoIter<@T, @A>>}::into_iter" "_root_.Aeneas.Std.alloc.collections.btree.set.IntoIteratorBTreeSet.into_iter" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 214 *)
  mk_fun "alloc::collections::btree::set::{core::iter::traits::iterator::Iterator<alloc::collections::btree::set::IntoIter<@T, @A>, @T>}::next" "_root_.Aeneas.Std.alloc.collections.btree.set.IteratorIntoIter.next" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 222 *)
  mk_fun "alloc::collections::btree::set::{core::iter::traits::iterator::Iterator<alloc::collections::btree::set::IntoIter<@T, @A>, @T>}::size_hint" "_root_.Aeneas.Std.alloc.collections.btree.set.IteratorIntoIter.size_hint" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 202 *)
  mk_fun "alloc::collections::btree::set::{core::iter::traits::iterator::Iterator<alloc::collections::btree::set::Iter<'a, @T>, &'a @T>}::next" "_root_.Aeneas.Std.alloc.collections.btree.set.IteratorIter.next";
  (* file: "Aeneas/Std/BTreeSet.lean", line: 208 *)
  mk_fun "alloc::collections::btree::set::{core::iter::traits::iterator::Iterator<alloc::collections::btree::set::Iter<'a, @T>, &'a @T>}::size_hint" "_root_.Aeneas.Std.alloc.collections.btree.set.IteratorIter.size_hint";
  (* file: "Aeneas/Std/VecDeque.lean", line: 136 *)
  mk_fun "alloc::collections::vec_deque::{alloc::collections::vec_deque::VecDeque<@T, @A>}::back" "_root_.Aeneas.Std.alloc.collections.vec_deque.VecDeque.back" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/VecDeque.lean", line: 88 *)
  mk_fun "alloc::collections::vec_deque::{alloc::collections::vec_deque::VecDeque<@T, @A>}::clear" "_root_.Aeneas.Std.alloc.collections.vec_deque.VecDeque.clear" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/VecDeque.lean", line: 130 *)
  mk_fun "alloc::collections::vec_deque::{alloc::collections::vec_deque::VecDeque<@T, @A>}::front" "_root_.Aeneas.Std.alloc.collections.vec_deque.VecDeque.front" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/VecDeque.lean", line: 81 *)
  mk_fun "alloc::collections::vec_deque::{alloc::collections::vec_deque::VecDeque<@T, @A>}::is_empty" "_root_.Aeneas.Std.alloc.collections.vec_deque.VecDeque.is_empty" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/VecDeque.lean", line: 73 *)
  mk_fun "alloc::collections::vec_deque::{alloc::collections::vec_deque::VecDeque<@T, @A>}::len" "_root_.Aeneas.Std.alloc.collections.vec_deque.VecDeque.len" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/VecDeque.lean", line: 121 *)
  mk_fun "alloc::collections::vec_deque::{alloc::collections::vec_deque::VecDeque<@T, @A>}::pop_back" "_root_.Aeneas.Std.alloc.collections.vec_deque.VecDeque.pop_back" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/VecDeque.lean", line: 112 *)
  mk_fun "alloc::collections::vec_deque::{alloc::collections::vec_deque::VecDeque<@T, @A>}::pop_front" "_root_.Aeneas.Std.alloc.collections.vec_deque.VecDeque.pop_front" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/VecDeque.lean", line: 96 *)
  mk_fun "alloc::collections::vec_deque::{alloc::collections::vec_deque::VecDeque<@T, @A>}::push_back" "_root_.Aeneas.Std.alloc.collections.vec_deque.VecDeque.push_back" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/VecDeque.lean", line: 104 *)
  mk_fun "alloc::collections::vec_deque::{alloc::collections::vec_deque::VecDeque<@T, @A>}::push_front" "_root_.Aeneas.Std.alloc.collections.vec_deque.VecDeque.push_front" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/VecDeque.lean", line: 23 *)
  mk_fun "alloc::collections::vec_deque::{alloc::collections::vec_deque::VecDeque<@T, alloc::alloc::Global>}::new" "_root_.Aeneas.Std.alloc.collections.vec_deque.VecDeque.new";
  (* file: "Aeneas/Std/VecDeque.lean", line: 40 *)
  mk_fun "alloc::collections::vec_deque::{core::convert::From<alloc::collections::vec_deque::VecDeque<@T, alloc::alloc::Global>, [@T; @N]>}::from" "_root_.Aeneas.Std.alloc.collections.vec_deque.FromVecDequeArray.from";
  (* file: "Aeneas/Std/VecDeque.lean", line: 28 *)
  mk_fun "alloc::collections::vec_deque::{core::default::Default<alloc::collections::vec_deque::VecDeque<@T, alloc::alloc::Global>>}::default" "_root_.Aeneas.Std.alloc.collections.vec_deque.DefaultVecDeque.default";
  (* file: "Aeneas/Std/VecDeque.lean", line: 61 *)
  mk_fun "alloc::collections::vec_deque::{core::iter::traits::collect::FromIterator<alloc::collections::vec_deque::VecDeque<@T, alloc::alloc::Global>, @T>}::from_iter" "_root_.Aeneas.Std.alloc.collections.vec_deque.FromIteratorVecDeque.from_iter";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 199 *)
  mk_fun "alloc::fmt::format" "_root_.Aeneas.Std.alloc.fmt.format";
  (* file: "Aeneas/Std/Sync.lean", line: 38 *)
  mk_fun "alloc::rc::{alloc::rc::Rc<@T>}::new" "_root_.Aeneas.Std.alloc.rc.Rc.new" ~can_fail:false;
  (* file: "Aeneas/Std/Sync.lean", line: 52 *)
  mk_fun "alloc::rc::{core::clone::Clone<alloc::rc::Rc<@T>>}::clone" "_root_.Aeneas.Std.alloc.rc.CloneRc.clone" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/Sync.lean", line: 111 *)
  mk_fun "alloc::rc::{core::default::Default<alloc::rc::Rc<@T>>}::default" "_root_.Aeneas.Std.alloc.rc.DefaultRc.default" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Sync.lean", line: 73 *)
  mk_fun "alloc::rc::{core::ops::deref::Deref<alloc::rc::Rc<@T>, @T>}::deref" "_root_.Aeneas.Std.alloc.rc.DerefRc.deref" ~keep_params:(Some [true; false]) ~can_fail:false;
  (* file: "Aeneas/Std/Vec.lean", line: 509 *)
  mk_fun "alloc::slice::{[@T]}::into_vec" "_root_.Aeneas.Std.alloc.slice.Slice.into_vec" ~keep_params:(Some [true; false]) ~can_fail:false ~lift:false;
  (* file: "Aeneas/Std/StringJoin.lean", line: 9 *)
  mk_fun "alloc::slice::{[@T]}::join" "_root_.Aeneas.Std.alloc.slice.Slice.join";
  (* file: "Aeneas/Std/Sort.lean", line: 65 *)
  mk_fun "alloc::slice::{[@T]}::sort" "_root_.Aeneas.Std.alloc.slice.Slice.sort";
  (* file: "Aeneas/Std/Sort.lean", line: 90 *)
  mk_fun "alloc::slice::{[@T]}::sort_by" "_root_.Aeneas.Std.alloc.slice.Slice.sort_by";
  (* file: "Aeneas/Std/Sort.lean", line: 73 *)
  mk_fun "alloc::slice::{[@T]}::sort_by_key" "_root_.Aeneas.Std.alloc.slice.Slice.sort_by_key";
  (* file: "Aeneas/Std/Vec.lean", line: 497 *)
  mk_fun "alloc::slice::{[@T]}::to_vec" "_root_.Aeneas.Std.alloc.slice.Slice.to_vec";
  (* file: "Aeneas/Std/SliceOwned.lean", line: 34 *)
  mk_fun "alloc::slice::{alloc::borrow::ToOwned<[@T], alloc::vec::Vec<@T>>}::clone_into" "_root_.Aeneas.Std.alloc.slice.ToOwnedSlice.clone_into";
  (* file: "Aeneas/Std/SliceOwned.lean", line: 24 *)
  mk_fun "alloc::slice::{alloc::borrow::ToOwned<[@T], alloc::vec::Vec<@T>>}::to_owned" "_root_.Aeneas.Std.alloc.slice.ToOwnedSlice.to_owned";
  (* file: "Aeneas/Std/SliceOwned.lean", line: 11 *)
  mk_fun "alloc::slice::{core::borrow::Borrow<alloc::vec::Vec<@T>, [@T]>}::borrow" "_root_.Aeneas.Std.alloc.slice.BorrowVecSlice.borrow" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/String.lean", line: 593 *)
  mk_fun "alloc::str::{alloc::borrow::ToOwned<str, alloc::string::String>}::to_owned" "_root_.Aeneas.Std.alloc.str.ToOwnedStr.to_owned";
  (* file: "Aeneas/Std/StringJoin.lean", line: 34 *)
  mk_fun "alloc::str::{alloc::slice::Join<[@S], &'a str, alloc::string::String>}::join" "_root_.Aeneas.Std.alloc.str.JoinStr.join";
  (* file: "Aeneas/Std/Core/Borrow.lean", line: 31 *)
  mk_fun "alloc::str::{core::borrow::Borrow<alloc::string::String, str>}::borrow" "_root_.Aeneas.Std.alloc.str.BorrowString.borrow";
  (* file: "Aeneas/Std/String.lean", line: 576 *)
  mk_fun "alloc::str::{str}::repeat" "_root_.Aeneas.Std.alloc.str.Str.repeat";
  (* file: "Aeneas/Std/StringIter.lean", line: 455 *)
  mk_fun "alloc::str::{str}::replace" "_root_.Aeneas.Std.alloc.str.Str.replace";
  (* file: "Aeneas/Std/String.lean", line: 124 *)
  mk_fun "alloc::str::{str}::to_ascii_lowercase" "_root_.Aeneas.Std.alloc.str.Str.to_ascii_lowercase";
  (* file: "Aeneas/Std/String.lean", line: 229 *)
  mk_fun "alloc::string::{alloc::string::String}::as_bytes" "_root_.Aeneas.Std.alloc.string.String.as_bytes";
  (* file: "Aeneas/Std/String.lean", line: 225 *)
  mk_fun "alloc::string::{alloc::string::String}::as_str" "_root_.Aeneas.Std.alloc.string.String.as_str";
  (* file: "Aeneas/Std/Core/Borrow.lean", line: 161 *)
  mk_fun "alloc::string::{alloc::string::String}::from_utf8_lossy" "_root_.Aeneas.Std.alloc.string.String.from_utf8_lossy";
  (* file: "Aeneas/Std/String.lean", line: 232 *)
  mk_fun "alloc::string::{alloc::string::String}::is_empty" "_root_.Aeneas.Std.alloc.string.String.is_empty";
  (* file: "Aeneas/Std/String.lean", line: 457 *)
  mk_fun "alloc::string::{alloc::string::String}::len" "_root_.Aeneas.Std.alloc.string.String.len";
  (* file: "Aeneas/Std/String.lean", line: 462 *)
  mk_fun "alloc::string::{alloc::string::String}::new" "_root_.Aeneas.Std.alloc.string.String.new";
  (* file: "Aeneas/Std/String.lean", line: 477 *)
  mk_fun "alloc::string::{alloc::string::String}::pop" "_root_.Aeneas.Std.alloc.string.String.pop";
  (* file: "Aeneas/Std/String.lean", line: 561 *)
  mk_fun "alloc::string::{alloc::string::String}::push" "_root_.Aeneas.Std.alloc.string.String.push";
  (* file: "Aeneas/Std/String.lean", line: 567 *)
  mk_fun "alloc::string::{alloc::string::String}::push_str" "_root_.Aeneas.Std.alloc.string.String.push_str";
  (* file: "Aeneas/Std/String.lean", line: 554 *)
  mk_fun "alloc::string::{alloc::string::String}::with_capacity" "_root_.Aeneas.Std.alloc.string.String.with_capacity";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 235 *)
  mk_fun "alloc::string::{alloc::string::ToString<@T>}::to_string" "_root_.Aeneas.Std.alloc.string.ToStringBlanket.to_string";
  (* file: "Aeneas/Std/String.lean", line: 204 *)
  mk_fun "alloc::string::{core::clone::Clone<alloc::string::String>}::clone" "_root_.Aeneas.Std.alloc.string.CloneString.clone";
  (* file: "Aeneas/Std/String.lean", line: 144 *)
  mk_fun "alloc::string::{core::cmp::Eq<alloc::string::String>}::assert_receiver_is_total_eq" "_root_.Aeneas.Std.alloc.string.EqString.assert_receiver_is_total_eq";
  (* file: "Aeneas/Std/String.lean", line: 162 *)
  mk_fun "alloc::string::{core::cmp::Ord<alloc::string::String>}::cmp" "_root_.Aeneas.Std.alloc.string.OrdString.cmp";
  (* file: "Aeneas/Std/String.lean", line: 107 *)
  mk_fun "alloc::string::{core::cmp::PartialEq<&'a str, alloc::string::String>}::eq" "_root_.Aeneas.Std.alloc.string.PartialEqSharedStrString.eq";
  (* file: "Aeneas/Std/String.lean", line: 111 *)
  mk_fun "alloc::string::{core::cmp::PartialEq<&'a str, alloc::string::String>}::ne" "_root_.Aeneas.Std.alloc.string.PartialEqSharedStrString.ne";
  (* file: "Aeneas/Std/String.lean", line: 91 *)
  mk_fun "alloc::string::{core::cmp::PartialEq<alloc::string::String, &'a str>}::eq" "_root_.Aeneas.Std.alloc.string.PartialEqStringSharedStr.eq";
  (* file: "Aeneas/Std/String.lean", line: 95 *)
  mk_fun "alloc::string::{core::cmp::PartialEq<alloc::string::String, &'a str>}::ne" "_root_.Aeneas.Std.alloc.string.PartialEqStringSharedStr.ne";
  (* file: "Aeneas/Std/String.lean", line: 61 *)
  mk_fun "alloc::string::{core::cmp::PartialEq<alloc::string::String, alloc::string::String>}::eq" "_root_.Aeneas.Std.alloc.string.PartialEqString.eq";
  (* file: "Aeneas/Std/String.lean", line: 65 *)
  mk_fun "alloc::string::{core::cmp::PartialEq<alloc::string::String, alloc::string::String>}::ne" "_root_.Aeneas.Std.alloc.string.PartialEqString.ne";
  (* file: "Aeneas/Std/String.lean", line: 75 *)
  mk_fun "alloc::string::{core::cmp::PartialEq<alloc::string::String, str>}::eq" "_root_.Aeneas.Std.alloc.string.PartialEqStringStr.eq";
  (* file: "Aeneas/Std/String.lean", line: 79 *)
  mk_fun "alloc::string::{core::cmp::PartialEq<alloc::string::String, str>}::ne" "_root_.Aeneas.Std.alloc.string.PartialEqStringStr.ne";
  (* file: "Aeneas/Std/String.lean", line: 166 *)
  mk_fun "alloc::string::{core::cmp::PartialOrd<alloc::string::String, alloc::string::String>}::partial_cmp" "_root_.Aeneas.Std.alloc.string.PartialOrdString.partial_cmp";
  (* file: "Aeneas/Std/String.lean", line: 596 *)
  mk_fun "alloc::string::{core::convert::From<Box<str>, alloc::string::String>}::from" "_root_.Aeneas.Std.alloc.string.FromStringBoxStr.from_";
  (* file: "Aeneas/Std/String.lean", line: 605 *)
  mk_fun "alloc::string::{core::convert::From<alloc::string::String, &'0 alloc::string::String>}::from" "_root_.Aeneas.Std.alloc.string.FromSharedStringString.from_";
  (* file: "Aeneas/Std/String.lean", line: 585 *)
  mk_fun "alloc::string::{core::convert::From<alloc::string::String, &'a str>}::from" "_root_.Aeneas.Std.alloc.string.FromStrString.from_";
  (* file: "Aeneas/Std/String.lean", line: 466 *)
  mk_fun "alloc::string::{core::default::Default<alloc::string::String>}::default" "_root_.Aeneas.Std.alloc.string.DefaultString.default";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 73 *)
  mk_fun "alloc::string::{core::fmt::Debug<alloc::string::String>}::fmt" "_root_.Aeneas.Std.core.fmt.DebugString.fmt";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 78 *)
  mk_fun "alloc::string::{core::fmt::Display<alloc::string::String>}::fmt" "_root_.Aeneas.Std.core.fmt.DisplayString.fmt";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 214 *)
  mk_fun "alloc::string::{core::fmt::Write<alloc::string::String>}::write_char" "_root_.Aeneas.Std.alloc.string.WriteString.write_char";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 225 *)
  mk_fun "alloc::string::{core::fmt::Write<alloc::string::String>}::write_fmt" "_root_.Aeneas.Std.alloc.string.WriteString.write_fmt";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 209 *)
  mk_fun "alloc::string::{core::fmt::Write<alloc::string::String>}::write_str" "_root_.Aeneas.Std.alloc.string.WriteString.write_str";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 329 *)
  mk_fun "alloc::string::{core::hash::Hash<alloc::string::String>}::hash" "_root_.Aeneas.Std.alloc.string.HashString.hash";
  (* file: "Aeneas/Std/VecIter.lean", line: 267 *)
  mk_fun "alloc::string::{core::iter::traits::collect::FromIterator<alloc::string::String, char>}::from_iter" "_root_.Aeneas.Std.alloc.string.FromIteratorStringChar.from_iter";
  (* file: "Aeneas/Std/String.lean", line: 222 *)
  mk_fun "alloc::string::{core::ops::deref::Deref<alloc::string::String, str>}::deref" "_root_.Aeneas.Std.alloc.string.DerefString.deref";
  (* file: "Aeneas/Std/Sync.lean", line: 35 *)
  mk_fun "alloc::sync::{alloc::sync::Arc<@T>}::new" "_root_.Aeneas.Std.alloc.sync.Arc.new" ~can_fail:false;
  (* file: "Aeneas/Std/Sync.lean", line: 41 *)
  mk_fun "alloc::sync::{core::clone::Clone<alloc::sync::Arc<@T>>}::clone" "_root_.Aeneas.Std.alloc.sync.CloneArc.clone" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/Sync.lean", line: 95 *)
  mk_fun "alloc::sync::{core::convert::AsRef<alloc::sync::Arc<@T>, @T>}::as_ref" "_root_.Aeneas.Std.alloc.sync.AsRefArc.as_ref" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Sync.lean", line: 101 *)
  mk_fun "alloc::sync::{core::default::Default<alloc::sync::Arc<@T>>}::default" "_root_.Aeneas.Std.alloc.sync.DefaultArc.default";
  (* file: "Aeneas/Std/Sync.lean", line: 83 *)
  mk_fun "alloc::sync::{core::fmt::Debug<alloc::sync::Arc<@T>>}::fmt" "_root_.Aeneas.Std.alloc.sync.DebugArc.fmt" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Sync.lean", line: 63 *)
  mk_fun "alloc::sync::{core::ops::deref::Deref<alloc::sync::Arc<@T>, @T>}::deref" "_root_.Aeneas.Std.alloc.sync.DerefArc.deref" ~keep_params:(Some [true; false]) ~can_fail:false;
  (* file: "Aeneas/Std/VecDrain.lean", line: 55 *)
  mk_fun "alloc::vec::drain::{core::iter::traits::double_ended::DoubleEndedIterator<alloc::vec::drain::Drain<'a, @T, @A>, @T>}::next_back" "_root_.Aeneas.Std.alloc.vec.drain.DoubleEndedIteratorDrain.next_back" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/VecDrain.lean", line: 37 *)
  mk_fun "alloc::vec::drain::{core::iter::traits::iterator::Iterator<alloc::vec::drain::Drain<'a, @T, @A>, @T>}::next" "_root_.Aeneas.Std.alloc.vec.drain.IteratorDrain.next" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/VecDrain.lean", line: 47 *)
  mk_fun "alloc::vec::drain::{core::iter::traits::iterator::Iterator<alloc::vec::drain::Drain<'a, @T, @A>, @T>}::size_hint" "_root_.Aeneas.Std.alloc.vec.drain.IteratorDrain.size_hint" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 513 *)
  mk_fun "alloc::vec::from_elem" "_root_.Aeneas.Std.alloc.vec.from_elem";
  (* file: "Aeneas/Std/VecIter.lean", line: 132 *)
  mk_fun "alloc::vec::into_iter::{core::iter::traits::double_ended::DoubleEndedIterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::advance_back_by" "_root_.Aeneas.Std.alloc.vec.into_iter.DoubleEndedIteratorIntoIter.advance_back_by" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/VecIter.lean", line: 118 *)
  mk_fun "alloc::vec::into_iter::{core::iter::traits::double_ended::DoubleEndedIterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::next_back" "_root_.Aeneas.Std.alloc.vec.into_iter.DoubleEndedIteratorIntoIter.next_back" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/VecIter.lean", line: 60 *)
  mk_fun "alloc::vec::into_iter::{core::iter::traits::iterator::Iterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::advance_by" "_root_.Aeneas.Std.alloc.vec.into_iter.IteratorIntoIter.advance_by" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/VecIter.lean", line: 53 *)
  mk_fun "alloc::vec::into_iter::{core::iter::traits::iterator::Iterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::count" "_root_.Aeneas.Std.alloc.vec.into_iter.IteratorIntoIter.count" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/VecIter.lean", line: 30 *)
  mk_fun "alloc::vec::into_iter::{core::iter::traits::iterator::Iterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::enumerate" "_root_.Aeneas.Std.alloc.vec.into_iter.IteratorIntoIter.enumerate" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/VecIter.lean", line: 76 *)
  mk_fun "alloc::vec::into_iter::{core::iter::traits::iterator::Iterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::fold" "_root_.Aeneas.Std.alloc.vec.into_iter.IteratorIntoIter.fold" ~keep_params:(Some [true; false; true; true]);
  (* file: "Aeneas/Std/VecIter.lean", line: 285 *)
  mk_fun "alloc::vec::into_iter::{core::iter::traits::iterator::Iterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::map" "_root_.Aeneas.Std.alloc.vec.into_iter.IntoIter.Insts.CoreIterTraitsIteratorIterator.map";
  (* file: "Aeneas/Std/VecIter.lean", line: 13 *)
  mk_fun "alloc::vec::into_iter::{core::iter::traits::iterator::Iterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::next" "_root_.Aeneas.Std.alloc.vec.into_iter.IteratorIntoIter.next" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/VecIter.lean", line: 45 *)
  mk_fun "alloc::vec::into_iter::{core::iter::traits::iterator::Iterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::size_hint" "_root_.Aeneas.Std.alloc.vec.into_iter.IteratorIntoIter.size_hint" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/VecIter.lean", line: 22 *)
  mk_fun "alloc::vec::into_iter::{core::iter::traits::iterator::Iterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::step_by" "_root_.Aeneas.Std.alloc.vec.into_iter.IteratorIntoIter.step_by" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/VecIter.lean", line: 37 *)
  mk_fun "alloc::vec::into_iter::{core::iter::traits::iterator::Iterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::take" "_root_.Aeneas.Std.alloc.vec.into_iter.IteratorIntoIter.take" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/VecIter.lean", line: 87 *)
  mk_fun "alloc::vec::into_iter::{core::iter::traits::iterator::Iterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::try_fold" "_root_.Aeneas.Std.alloc.vec.into_iter.IteratorIntoIter.try_fold" ~keep_params:(Some [true; false; true; true; true; true]);
  (* file: "Aeneas/Std/VecIter.lean", line: 327 *)
  mk_fun "alloc::vec::into_iter::{core::iter::traits::iterator::Iterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::unzip" "_root_.Aeneas.Std.alloc.vec.into_iter.IteratorIntoIter.unzip" ~keep_params:(Some [true; false; true; true; true; true]);
  (* file: "Aeneas/Std/SliceCmp.lean", line: 157 *)
  mk_fun "alloc::vec::partial_eq::{core::cmp::PartialEq<alloc::vec::Vec<@T>, [@U; @N]>}::eq" "_root_.Aeneas.Std.alloc.vec.partial_eq.PartialEqVecArray.eq" ~keep_params:(Some [true; true; false]);
  (* file: "Aeneas/Std/SliceCmp.lean", line: 164 *)
  mk_fun "alloc::vec::partial_eq::{core::cmp::PartialEq<alloc::vec::Vec<@T>, [@U; @N]>}::ne" "_root_.Aeneas.Std.alloc.vec.partial_eq.PartialEqVecArray.ne" ~keep_params:(Some [true; true; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 766 *)
  mk_fun "alloc::vec::partial_eq::{core::cmp::PartialEq<alloc::vec::Vec<@T>, alloc::vec::Vec<@U>>}::eq" "_root_.Aeneas.Std.alloc.vec.partial_eq.PartialEqVec.eq" ~keep_params:(Some [true; true; false; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 776 *)
  mk_fun "alloc::vec::partial_eq::{core::cmp::PartialEq<alloc::vec::Vec<@T>, alloc::vec::Vec<@U>>}::ne" "_root_.Aeneas.Std.alloc.vec.partial_eq.PartialEqVec.ne" ~keep_params:(Some [true; true; false; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 547 *)
  mk_fun "alloc::vec::{alloc::vec::Vec<@T>}::append" "_root_.Aeneas.Std.alloc.vec.Vec.append" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 638 *)
  mk_fun "alloc::vec::{alloc::vec::Vec<@T>}::as_mut_slice" "_root_.Aeneas.Std.alloc.vec.Vec.as_mut_slice" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 613 *)
  mk_fun "alloc::vec::{alloc::vec::Vec<@T>}::as_slice" "_root_.Aeneas.Std.alloc.vec.Vec.as_slice" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 52 *)
  mk_fun "alloc::vec::{alloc::vec::Vec<@T>}::clear" "_root_.Aeneas.Std.alloc.vec.Vec.clear" ~keep_params:(Some [true; false]) ~can_fail:false;
  (* file: "Aeneas/Std/Vec.lean", line: 256 *)
  mk_fun "alloc::vec::{alloc::vec::Vec<@T>}::dedup" "_root_.Aeneas.Std.alloc.vec.Vec.dedup" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 306 *)
  mk_fun "alloc::vec::{alloc::vec::Vec<@T>}::dedup_by_key" "_root_.Aeneas.Std.alloc.vec.Vec.dedup_by_key" ~keep_params:(Some [true; false; true; true]);
  (* file: "Aeneas/Std/VecDrain.lean", line: 23 *)
  mk_fun "alloc::vec::{alloc::vec::Vec<@T>}::drain" "_root_.Aeneas.Std.alloc.vec.Vec.drain" ~keep_params:(Some [true; false; true]);
  (* file: "Aeneas/Std/Vec.lean", line: 533 *)
  mk_fun "alloc::vec::{alloc::vec::Vec<@T>}::extend_from_slice" "_root_.Aeneas.Std.alloc.vec.Vec.extend_from_slice" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 316 *)
  mk_fun "alloc::vec::{alloc::vec::Vec<@T>}::insert" "_root_.Aeneas.Std.alloc.vec.Vec.insert" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 216 *)
  mk_fun "alloc::vec::{alloc::vec::Vec<@T>}::into_boxed_slice" "_root_.Aeneas.Std.alloc.vec.Vec.into_boxed_slice" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 48 *)
  mk_fun "alloc::vec::{alloc::vec::Vec<@T>}::is_empty" "_root_.Aeneas.Std.alloc.vec.Vec.is_empty" ~keep_params:(Some [true; false]) ~can_fail:false ~lift:false;
  (* file: "Aeneas/Std/Vec.lean", line: 129 *)
  mk_fun "alloc::vec::{alloc::vec::Vec<@T>}::len" "_root_.Aeneas.Std.alloc.vec.Vec.len" ~keep_params:(Some [true; false]) ~can_fail:false ~lift:false;
  (* file: "Aeneas/Std/Vec.lean", line: 45 *)
  mk_fun "alloc::vec::{alloc::vec::Vec<@T>}::new" "_root_.Aeneas.Std.alloc.vec.Vec.new" ~can_fail:false ~lift:false;
  (* file: "Aeneas/Std/Vec.lean", line: 198 *)
  mk_fun "alloc::vec::{alloc::vec::Vec<@T>}::pop" "_root_.Aeneas.Std.alloc.vec.Vec.pop" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 182 *)
  mk_fun "alloc::vec::{alloc::vec::Vec<@T>}::push" "_root_.Aeneas.Std.alloc.vec.Vec.push" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 56 *)
  mk_fun "alloc::vec::{alloc::vec::Vec<@T>}::remove" "_root_.Aeneas.Std.alloc.vec.Vec.remove" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 643 *)
  mk_fun "alloc::vec::{alloc::vec::Vec<@T>}::resize" "_root_.Aeneas.Std.alloc.vec.Vec.resize" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 603 *)
  mk_fun "alloc::vec::{alloc::vec::Vec<@T>}::retain" "_root_.Aeneas.Std.alloc.vec.Vec.retain" ~keep_params:(Some [true; false; true]);
  (* file: "Aeneas/Std/Vec.lean", line: 579 *)
  mk_fun "alloc::vec::{alloc::vec::Vec<@T>}::retain_mut" "_root_.Aeneas.Std.alloc.vec.Vec.retain_mut" ~keep_params:(Some [true; false; true]);
  (* file: "Aeneas/Std/Vec.lean", line: 206 *)
  mk_fun "alloc::vec::{alloc::vec::Vec<@T>}::split_off" "_root_.Aeneas.Std.alloc.vec.Vec.split_off" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/Vec.lean", line: 530 *)
  mk_fun "alloc::vec::{alloc::vec::Vec<@T>}::with_capacity" "_root_.Aeneas.Std.alloc.vec.Vec.with_capacity" ~can_fail:false ~lift:false;
  (* file: "Aeneas/Std/Vec.lean", line: 738 *)
  mk_fun "alloc::vec::{core::clone::Clone<alloc::vec::Vec<@T>>}::clone" "_root_.Aeneas.Std.alloc.vec.CloneVec.clone" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 701 *)
  mk_fun "alloc::vec::{core::convert::From<Box<[@T]>, alloc::vec::Vec<@T>>}::from" "_root_.Aeneas.Std.alloc.vec.FromBoxSliceVec.from" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 669 *)
  mk_fun "alloc::vec::{core::convert::From<alloc::vec::Vec<@T>, [@T; @N]>}::from" "_root_.Aeneas.Std.alloc.vec.FromVecArray.from";
  (* file: "Aeneas/Std/Vec.lean", line: 685 *)
  mk_fun "alloc::vec::{core::convert::TryFrom<[@T; @N], alloc::vec::Vec<@T>, alloc::vec::Vec<@T>>}::try_from" "_root_.Aeneas.Std.alloc.vec.TryFromArrayVec.try_from" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 67 *)
  mk_fun "alloc::vec::{core::default::Default<alloc::vec::Vec<@T>>}::default" "_root_.Aeneas.Std.alloc.vec.DefaultVec.default";
  (* file: "Aeneas/Std/Vec.lean", line: 797 *)
  mk_fun "alloc::vec::{core::fmt::Debug<alloc::vec::Vec<@T>>}::fmt" "_root_.Aeneas.Std.alloc.vec.DebugVec.fmt" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 110 *)
  mk_fun "alloc::vec::{core::iter::traits::collect::Extend<alloc::vec::Vec<@T>, &'a @T>}::extend" "_root_.Aeneas.Std.alloc.vec.ExtendVecShared.extend" ~keep_params:(Some [true; false; true; true]) ~keep_trait_clauses:(Some [false; true]);
  (* file: "Aeneas/Std/Vec.lean", line: 89 *)
  mk_fun "alloc::vec::{core::iter::traits::collect::Extend<alloc::vec::Vec<@T>, @T>}::extend" "_root_.Aeneas.Std.alloc.vec.ExtendVec.extend" ~keep_params:(Some [true; false; true; true]);
  (* file: "Aeneas/Std/VecIter.lean", line: 240 *)
  mk_fun "alloc::vec::{core::iter::traits::collect::FromIterator<alloc::vec::Vec<@T>, @T>}::from_iter" "_root_.Aeneas.Std.alloc.vec.FromIteratorVec.from_iter";
  (* file: "Aeneas/Std/VecIter.lean", line: 200 *)
  mk_fun "alloc::vec::{core::iter::traits::collect::IntoIterator<&'a alloc::vec::Vec<@T>, &'a @T, core::slice::iter::Iter<'a, @T>>}::into_iter" "_root_.Aeneas.Std.alloc.vec.IntoIteratorSharedVec.into_iter" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/VecIter.lean", line: 218 *)
  mk_fun "alloc::vec::{core::iter::traits::collect::IntoIterator<&'a mut alloc::vec::Vec<@T>, &'a mut @T, core::slice::iter::IterMut<'a, @T>>}::into_iter" "_root_.Aeneas.Std.alloc.vec.IntoIteratorMutVec.into_iter" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/VecIter.lean", line: 163 *)
  mk_fun "alloc::vec::{core::iter::traits::collect::IntoIterator<alloc::vec::Vec<@T>, @T, alloc::vec::into_iter::IntoIter<@T, @A>>}::into_iter" "_root_.Aeneas.Std.alloc.vec.IntoIteratorVec.into_iter" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 608 *)
  mk_fun "alloc::vec::{core::ops::deref::Deref<alloc::vec::Vec<@T>, [@T]>}::deref" "_root_.Aeneas.Std.alloc.vec.Vec.deref" ~keep_params:(Some [true; false]) ~can_fail:false ~lift:false;
  (* file: "Aeneas/Std/Vec.lean", line: 622 *)
  mk_fun "alloc::vec::{core::ops::deref::DerefMut<alloc::vec::Vec<@T>, [@T]>}::deref_mut" "_root_.Aeneas.Std.alloc.vec.Vec.deref_mut" ~keep_params:(Some [true; false]) ~can_fail:false;
  (* file: "Aeneas/Std/Vec.lean", line: 376 *)
  mk_fun "alloc::vec::{core::ops::index::Index<alloc::vec::Vec<@T>, @I, @O>}::index" "_root_.Aeneas.Std.alloc.vec.Vec.index" ~keep_params:(Some [true; true; false; true]);
  (* file: "Aeneas/Std/Vec.lean", line: 382 *)
  mk_fun "alloc::vec::{core::ops::index::IndexMut<alloc::vec::Vec<@T>, @I, @O>}::index_mut" "_root_.Aeneas.Std.alloc.vec.Vec.index_mut" ~keep_params:(Some [true; true; false; true]);
  (* file: "Aeneas/Std/ChelisNative.lean", line: 36 *)
  mk_fun "chelis_ir::capacity_key::{chelis_ir::capacity_key::CapacityScopeSupply}::fresh_id" "_root_.Aeneas.Std.chelis_ir.capacity_key.CapacityScopeSupply.fresh_id";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 199 *)
  mk_fun "chelis_ir::lowering_runtime::grow_stack_if_needed" "_root_.Aeneas.Std.chelis_ir.lowering_runtime.grow_stack_if_needed";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 177 *)
  mk_fun "chelis_ir::lowering_runtime::resume_native_unwind" "_root_.Aeneas.Std.chelis_ir.lowering_runtime.resume_native_unwind";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 185 *)
  mk_fun "chelis_ir::lowering_runtime::scoped" "_root_.Aeneas.Std.chelis_ir.lowering_runtime.scoped";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 240 *)
  mk_fun "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::catch_native_unwind" "_root_.Aeneas.Std.chelis_ir.lowering_runtime.LoweringRuntime.catch_native_unwind";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 320 *)
  mk_fun "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::detail_profile_declaration" "_root_.Aeneas.Std.chelis_ir.lowering_runtime.LoweringRuntime.detail_profile_declaration";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 311 *)
  mk_fun "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::detail_profile_declaration_start" "_root_.Aeneas.Std.chelis_ir.lowering_runtime.LoweringRuntime.detail_profile_declaration_start";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 303 *)
  mk_fun "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::detail_profile_phase" "_root_.Aeneas.Std.chelis_ir.lowering_runtime.LoweringRuntime.detail_profile_phase";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 294 *)
  mk_fun "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::detail_profile_start" "_root_.Aeneas.Std.chelis_ir.lowering_runtime.LoweringRuntime.detail_profile_start";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 253 *)
  mk_fun "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::fresh_host_inference_var" "_root_.Aeneas.Std.chelis_ir.lowering_runtime.LoweringRuntime.fresh_host_inference_var";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 278 *)
  mk_fun "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::fresh_preflight_frame" "_root_.Aeneas.Std.chelis_ir.lowering_runtime.LoweringRuntime.fresh_preflight_frame";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 227 *)
  mk_fun "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::observe_raise" "_root_.Aeneas.Std.chelis_ir.lowering_runtime.LoweringRuntime.observe_raise";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 259 *)
  mk_fun "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::record_summary_probe_build" "_root_.Aeneas.Std.chelis_ir.lowering_runtime.LoweringRuntime.record_summary_probe_build";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 328 *)
  mk_fun "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::report_internal" "_root_.Aeneas.Std.chelis_ir.lowering_runtime.LoweringRuntime.report_internal";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 271 *)
  mk_fun "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::reset_summary_probe_builds" "_root_.Aeneas.Std.chelis_ir.lowering_runtime.LoweringRuntime.reset_summary_probe_builds";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 220 *)
  mk_fun "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::set_output_suppressed" "_root_.Aeneas.Std.chelis_ir.lowering_runtime.LoweringRuntime.set_output_suppressed";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 213 *)
  mk_fun "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::set_unrepresentable_panic_suppressed" "_root_.Aeneas.Std.chelis_ir.lowering_runtime.LoweringRuntime.set_unrepresentable_panic_suppressed";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 265 *)
  mk_fun "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::summary_probe_builds" "_root_.Aeneas.Std.chelis_ir.lowering_runtime.LoweringRuntime.summary_probe_builds";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 207 *)
  mk_fun "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::unrepresentable_panic_suppressed" "_root_.Aeneas.Std.chelis_ir.lowering_runtime.LoweringRuntime.unrepresentable_panic_suppressed";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 119 *)
  mk_fun "chelis_types::native::sha256_concat" "_root_.Aeneas.Std.chelis_types.native.sha256_concat";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 68 *)
  mk_fun "chelis_types::native::{chelis_types::native::NativeServices}::cancellation_observed" "_root_.Aeneas.Std.chelis_types.native.NativeServices.cancellation_observed";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 78 *)
  mk_fun "chelis_types::native::{chelis_types::native::NativeServices}::enter_frame" "_root_.Aeneas.Std.chelis_types.native.NativeServices.enter_frame";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 84 *)
  mk_fun "chelis_types::native::{chelis_types::native::NativeServices}::exit_frame" "_root_.Aeneas.Std.chelis_types.native.NativeServices.exit_frame";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 99 *)
  mk_fun "chelis_types::native::{chelis_types::native::NativeServices}::profile_phase" "_root_.Aeneas.Std.chelis_types.native.NativeServices.profile_phase";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 94 *)
  mk_fun "chelis_types::native::{chelis_types::native::NativeServices}::profile_start" "_root_.Aeneas.Std.chelis_types.native.NativeServices.profile_start";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 89 *)
  mk_fun "chelis_types::native::{chelis_types::native::NativeServices}::reset_frames" "_root_.Aeneas.Std.chelis_types.native.NativeServices.reset_frames";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 73 *)
  mk_fun "chelis_types::native::{chelis_types::native::NativeServices}::stack_exhausted" "_root_.Aeneas.Std.chelis_types.native.NativeServices.stack_exhausted";
  (* file: "Aeneas/Std/ChelisNative.lean", line: 109 *)
  mk_fun "chelis_types::native::{chelis_types::native::NativeServices}::with_grown_stack" "_root_.Aeneas.Std.chelis_types.native.NativeServices.with_grown_stack";
  (* file: "Aeneas/Std/Array/ArraySlice.lean", line: 164 *)
  mk_fun "core::array::equality::{core::cmp::PartialEq<&'0 [@T], [@U; @N]>}::eq" "_root_.Aeneas.Std.core.array.equality.PartialEqSharedSliceArray.eq";
  (* file: "Aeneas/Std/Array/ArraySlice.lean", line: 171 *)
  mk_fun "core::array::equality::{core::cmp::PartialEq<&'0 [@T], [@U; @N]>}::ne" "_root_.Aeneas.Std.core.array.equality.PartialEqSharedSliceArray.ne";
  (* file: "Aeneas/Std/Array/ArraySlice.lean", line: 130 *)
  mk_fun "core::array::equality::{core::cmp::PartialEq<[@T; @N], [@U; @N]>}::eq" "_root_.Aeneas.Std.core.array.equality.PartialEqArray.eq";
  (* file: "Aeneas/Std/Array/ArraySlice.lean", line: 138 *)
  mk_fun "core::array::equality::{core::cmp::PartialEq<[@T; @N], [@U; @N]>}::ne" "_root_.Aeneas.Std.core.array.equality.PartialEqArray.ne";
  (* file: "Aeneas/Std/Array/ArraySlice.lean", line: 146 *)
  mk_fun "core::array::equality::{core::cmp::PartialEq<[@T], [@U; @N]>}::eq" "_root_.Aeneas.Std.core.array.equality.PartialEqSliceArray.eq";
  (* file: "Aeneas/Std/Array/ArraySlice.lean", line: 154 *)
  mk_fun "core::array::equality::{core::cmp::PartialEq<[@T], [@U; @N]>}::ne" "_root_.Aeneas.Std.core.array.equality.PartialEqSliceArray.ne";
  (* file: "Aeneas/Std/ArrayIter.lean", line: 97 *)
  mk_fun "core::array::iter::{core::iter::traits::collect::IntoIterator<[@T; @N], @T, core::array::iter::IntoIter<@T, @N>>}::into_iter" "_root_.Aeneas.Std.core.array.iter.IntoIteratorArray.into_iter";
  (* file: "Aeneas/Std/ArrayIter.lean", line: 33 *)
  mk_fun "core::array::iter::{core::iter::traits::iterator::Iterator<core::array::iter::IntoIter<@T, @N>, @T>}::advance_by" "_root_.Aeneas.Std.core.array.iter.IteratorIntoIter.advance_by";
  (* file: "Aeneas/Std/ArrayIter.lean", line: 73 *)
  mk_fun "core::array::iter::{core::iter::traits::iterator::Iterator<core::array::iter::IntoIter<@T, @N>, @T>}::any" "_root_.Aeneas.Std.core.array.iter.IteratorIntoIter.any";
  (* file: "Aeneas/Std/ArrayIter.lean", line: 66 *)
  mk_fun "core::array::iter::{core::iter::traits::iterator::Iterator<core::array::iter::IntoIter<@T, @N>, @T>}::count" "_root_.Aeneas.Std.core.array.iter.IteratorIntoIter.count";
  (* file: "Aeneas/Std/ArrayIter.lean", line: 46 *)
  mk_fun "core::array::iter::{core::iter::traits::iterator::Iterator<core::array::iter::IntoIter<@T, @N>, @T>}::fold" "_root_.Aeneas.Std.core.array.iter.IteratorIntoIter.fold";
  (* file: "Aeneas/Std/ArrayIter.lean", line: 16 *)
  mk_fun "core::array::iter::{core::iter::traits::iterator::Iterator<core::array::iter::IntoIter<@T, @N>, @T>}::next" "_root_.Aeneas.Std.core.array.iter.IteratorIntoIter.next";
  (* file: "Aeneas/Std/ArrayIter.lean", line: 26 *)
  mk_fun "core::array::iter::{core::iter::traits::iterator::Iterator<core::array::iter::IntoIter<@T, @N>, @T>}::size_hint" "_root_.Aeneas.Std.core.array.iter.IteratorIntoIter.size_hint";
  (* file: "Aeneas/Std/ArrayIter.lean", line: 56 *)
  mk_fun "core::array::iter::{core::iter::traits::iterator::Iterator<core::array::iter::IntoIter<@T, @N>, @T>}::try_fold" "_root_.Aeneas.Std.core.array.iter.IteratorIntoIter.try_fold";
  (* file: "Aeneas/Std/Array/ArraySlice.lean", line: 245 *)
  mk_fun "core::array::{[@T; @N]}::as_mut_slice" "_root_.Aeneas.Std.core.array.Array.as_mut_slice";
  (* file: "Aeneas/Std/Array/ArraySlice.lean", line: 241 *)
  mk_fun "core::array::{[@T; @N]}::as_slice" "_root_.Aeneas.Std.core.array.Array.as_slice";
  (* file: "Aeneas/Std/Array/Array.lean", line: 228 *)
  mk_fun "core::array::{core::clone::Clone<[@T; @N]>}::clone" "_root_.Aeneas.Std.core.array.CloneArray.clone";
  (* file: "Aeneas/Std/Array/Array.lean", line: 241 *)
  mk_fun "core::array::{core::clone::Clone<[@T; @N]>}::clone_from" "_root_.Aeneas.Std.core.array.CloneArray.clone_from";
  (* file: "Aeneas/Std/Array/ArraySlice.lean", line: 203 *)
  mk_fun "core::array::{core::convert::TryFrom<&'a [@T; @N], &'a [@T], core::array::TryFromSliceError>}::try_from" "_root_.Aeneas.Std.core.array.TryFromSharedArraySlice.try_from";
  (* file: "Aeneas/Std/Array/ArraySlice.lean", line: 218 *)
  mk_fun "core::array::{core::convert::TryFrom<&'a mut [@T; @N], &'a mut [@T], core::array::TryFromSliceError>}::try_from" "_root_.Aeneas.Std.core.array.TryFromMutArraySlice.try_from";
  (* file: "Aeneas/Std/Array/ArraySlice.lean", line: 191 *)
  mk_fun "core::array::{core::convert::TryFrom<[@T; @N], &'0 [@T], core::array::TryFromSliceError>}::try_from" "_root_.Aeneas.Std.core.array.TryFromArrayCopySlice.try_from";
  (* file: "Aeneas/Std/Array/Array.lean", line: 301 *)
  mk_fun "core::array::{core::default::Default<[@T; 0]>}::default" "_root_.Aeneas.Std.core.default.DefaultArrayEmpty.default";
  (* file: "Aeneas/Std/Array/Array.lean", line: 285 *)
  mk_fun "core::array::{core::default::Default<[@T; @N]>}::default" "_root_.Aeneas.Std.core.default.DefaultArray.default";
  (* file: "Aeneas/Std/Array/ArraySlice.lean", line: 234 *)
  mk_fun "core::array::{core::fmt::Debug<[@T; @N]>}::fmt" "_root_.Aeneas.Std.core.array.DebugArray.fmt";
  (* file: "Aeneas/Std/Array/ArraySlice.lean", line: 177 *)
  mk_fun "core::array::{core::fmt::Debug<core::array::TryFromSliceError>}::fmt" "_root_.Aeneas.Std.core.array.DebugTryFromSliceError.fmt";
  (* file: "Aeneas/Std/SliceIter.lean", line: 420 *)
  mk_fun "core::array::{core::iter::traits::collect::IntoIterator<&'a [@T; @N], &'a @T, core::slice::iter::Iter<'a, @T>>}::into_iter" "_root_.Aeneas.Std.core.array.IntoIteratorSharedArray.into_iter";
  (* file: "Aeneas/Std/Array/ArraySlice.lean", line: 86 *)
  mk_fun "core::array::{core::ops::index::Index<[@T; @N], @I, @O>}::index" "_root_.Aeneas.Std.core.array.Array.index";
  (* file: "Aeneas/Std/Array/ArraySlice.lean", line: 92 *)
  mk_fun "core::array::{core::ops::index::IndexMut<[@T; @N], @I, @O>}::index_mut" "_root_.Aeneas.Std.core.array.Array.index_mut";
  (* file: "Aeneas/Std/Core/Ops.lean", line: 254 *)
  mk_fun "core::bool::{bool}::then" "_root_.Aeneas.Std.core.bool.Bool.then";
  (* file: "Aeneas/Std/Core/Core.lean", line: 95 *)
  mk_fun "core::bool::{bool}::then_some" "_root_.Aeneas.Std.core.bool.then_some" ~can_fail:false;
  (* file: "Aeneas/Std/Core/Borrow.lean", line: 21 *)
  mk_fun "core::borrow::{core::borrow::Borrow<&'a @T, @T>}::borrow" "_root_.Aeneas.Std.core.borrow.BorrowShared.borrow";
  (* file: "Aeneas/Std/Core/Borrow.lean", line: 12 *)
  mk_fun "core::borrow::{core::borrow::Borrow<@T, @T>}::borrow" "_root_.Aeneas.Std.core.borrow.BorrowSelf.borrow";
  (* file: "Aeneas/Std/String.lean", line: 497 *)
  mk_fun "core::char::methods::{char}::is_ascii_alphanumeric" "_root_.Aeneas.Std.core.char.methods.Char.is_ascii_alphanumeric";
  (* file: "Aeneas/Std/String.lean", line: 491 *)
  mk_fun "core::char::methods::{char}::is_ascii_digit" "_root_.Aeneas.Std.core.char.methods.Char.is_ascii_digit";
  (* file: "Aeneas/Std/String.lean", line: 507 *)
  mk_fun "core::char::methods::{char}::is_ascii_lowercase" "_root_.Aeneas.Std.core.char.methods.Char.is_ascii_lowercase";
  (* file: "Aeneas/Std/String.lean", line: 502 *)
  mk_fun "core::char::methods::{char}::is_ascii_uppercase" "_root_.Aeneas.Std.core.char.methods.Char.is_ascii_uppercase";
  (* file: "Aeneas/Std/Core/CharCase.lean", line: 268 *)
  mk_fun "core::char::methods::{char}::is_lowercase" "_root_.Aeneas.Std.core.char.methods.Char.is_lowercase";
  (* file: "Aeneas/Std/Core/CharCase.lean", line: 262 *)
  mk_fun "core::char::methods::{char}::is_uppercase" "_root_.Aeneas.Std.core.char.methods.Char.is_uppercase";
  (* file: "Aeneas/Std/StringIter.lean", line: 425 *)
  mk_fun "core::char::methods::{char}::is_whitespace" "_root_.Aeneas.Std.core.char.methods.Char.is_whitespace";
  (* file: "Aeneas/Std/String.lean", line: 485 *)
  mk_fun "core::char::methods::{char}::len_utf8" "_root_.Aeneas.Std.core.char.methods.Char.len_utf8";
  (* file: "Aeneas/Std/String.lean", line: 513 *)
  mk_fun "core::char::methods::{char}::to_ascii_lowercase" "_root_.Aeneas.Std.core.char.methods.Char.to_ascii_lowercase";
  (* file: "Aeneas/Std/String.lean", line: 519 *)
  mk_fun "core::char::methods::{char}::to_ascii_uppercase" "_root_.Aeneas.Std.core.char.methods.Char.to_ascii_uppercase";
  (* file: "Aeneas/Std/Core/Core.lean", line: 225 *)
  mk_fun "core::clone::impls::{core::clone::Clone<&'0 @T>}::clone" "_root_.Aeneas.Std.core.clone.impls.CloneShared.clone";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 89 *)
  mk_fun "core::clone::impls::{core::clone::Clone<char>}::clone" "_root_.Aeneas.Std.core.clone.CloneChar.clone";
  (* file: "Aeneas/Std/Float.lean", line: 449 *)
  mk_fun "core::clone::impls::{core::clone::Clone<f32>}::clone" "_root_.Aeneas.Std.F32.clone";
  (* file: "Aeneas/Std/Float.lean", line: 589 *)
  mk_fun "core::clone::impls::{core::clone::Clone<f64>}::clone" "_root_.Aeneas.Std.F64.clone";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 203 *)
  mk_fun "core::cmp::impls::{core::cmp::Ord<()>}::cmp" "_root_.Aeneas.Std.core.cmp.impls.OrdUnit.cmp";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 267 *)
  mk_fun "core::cmp::impls::{core::cmp::Ord<char>}::clamp" "_root_.Aeneas.Std.core.cmp.impls.OrdChar.clamp";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 244 *)
  mk_fun "core::cmp::impls::{core::cmp::Ord<char>}::cmp" "_root_.Aeneas.Std.core.cmp.impls.OrdChar.cmp" ~can_fail:false;
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 294 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialEq<&'a @A, &'b @B>}::eq" "_root_.Aeneas.Std.core.cmp.impls.PartialEqShared.eq";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 299 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialEq<&'a @A, &'b @B>}::ne" "_root_.Aeneas.Std.core.cmp.impls.PartialEqShared.ne";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 187 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialEq<(), ()>}::eq" "_root_.Aeneas.Std.core.cmp.impls.PartialEqUnit.eq";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 190 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialEq<(), ()>}::ne" "_root_.Aeneas.Std.core.cmp.impls.PartialEqUnit.ne";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 207 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialEq<bool, bool>}::eq" "_root_.Aeneas.Std.core.cmp.impls.PartialEqBool.eq";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 225 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialEq<char, char>}::eq" "_root_.Aeneas.Std.core.cmp.impls.PartialEqChar.eq" ~can_fail:false;
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 229 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialEq<char, char>}::ne" "_root_.Aeneas.Std.core.cmp.impls.PartialEqChar.ne" ~can_fail:false;
  (* file: "Aeneas/Std/Float.lean", line: 420 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialEq<f32, f32>}::eq" "_root_.Aeneas.Std.core.cmp.impls.PartialEqF32.eq";
  (* file: "Aeneas/Std/Float.lean", line: 422 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialEq<f32, f32>}::ne" "_root_.Aeneas.Std.core.cmp.impls.PartialEqF32.ne";
  (* file: "Aeneas/Std/Float.lean", line: 560 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialEq<f64, f64>}::eq" "_root_.Aeneas.Std.core.cmp.impls.PartialEqF64.eq";
  (* file: "Aeneas/Std/Float.lean", line: 562 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialEq<f64, f64>}::ne" "_root_.Aeneas.Std.core.cmp.impls.PartialEqF64.ne";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 199 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialOrd<(), ()>}::partial_cmp" "_root_.Aeneas.Std.core.cmp.impls.PartialOrdUnit.partial_cmp";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 262 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialOrd<char, char>}::ge" "_root_.Aeneas.Std.core.cmp.impls.PartialOrdChar.ge" ~can_fail:false;
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 259 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialOrd<char, char>}::gt" "_root_.Aeneas.Std.core.cmp.impls.PartialOrdChar.gt" ~can_fail:false;
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 256 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialOrd<char, char>}::le" "_root_.Aeneas.Std.core.cmp.impls.PartialOrdChar.le" ~can_fail:false;
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 253 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialOrd<char, char>}::lt" "_root_.Aeneas.Std.core.cmp.impls.PartialOrdChar.lt" ~can_fail:false;
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 248 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialOrd<char, char>}::partial_cmp" "_root_.Aeneas.Std.core.cmp.impls.PartialOrdChar.partial_cmp" ~can_fail:false;
  (* file: "Aeneas/Std/Float.lean", line: 438 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialOrd<f32, f32>}::ge" "_root_.Aeneas.Std.core.cmp.impls.PartialOrdF32.ge";
  (* file: "Aeneas/Std/Float.lean", line: 436 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialOrd<f32, f32>}::gt" "_root_.Aeneas.Std.core.cmp.impls.PartialOrdF32.gt";
  (* file: "Aeneas/Std/Float.lean", line: 434 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialOrd<f32, f32>}::le" "_root_.Aeneas.Std.core.cmp.impls.PartialOrdF32.le";
  (* file: "Aeneas/Std/Float.lean", line: 432 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialOrd<f32, f32>}::lt" "_root_.Aeneas.Std.core.cmp.impls.PartialOrdF32.lt";
  (* file: "Aeneas/Std/Float.lean", line: 429 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialOrd<f32, f32>}::partial_cmp" "_root_.Aeneas.Std.core.cmp.impls.PartialOrdF32.partial_cmp";
  (* file: "Aeneas/Std/Float.lean", line: 578 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialOrd<f64, f64>}::ge" "_root_.Aeneas.Std.core.cmp.impls.PartialOrdF64.ge";
  (* file: "Aeneas/Std/Float.lean", line: 576 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialOrd<f64, f64>}::gt" "_root_.Aeneas.Std.core.cmp.impls.PartialOrdF64.gt";
  (* file: "Aeneas/Std/Float.lean", line: 574 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialOrd<f64, f64>}::le" "_root_.Aeneas.Std.core.cmp.impls.PartialOrdF64.le";
  (* file: "Aeneas/Std/Float.lean", line: 572 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialOrd<f64, f64>}::lt" "_root_.Aeneas.Std.core.cmp.impls.PartialOrdF64.lt";
  (* file: "Aeneas/Std/Float.lean", line: 569 *)
  mk_fun "core::cmp::impls::{core::cmp::PartialOrd<f64, f64>}::partial_cmp" "_root_.Aeneas.Std.core.cmp.impls.PartialOrdF64.partial_cmp";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 182 *)
  mk_fun "core::cmp::max" "_root_.Aeneas.Std.core.cmp.max";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 177 *)
  mk_fun "core::cmp::min" "_root_.Aeneas.Std.core.cmp.min";
  (* file: "Aeneas/Std/Core/Reverse.lean", line: 35 *)
  mk_fun "core::cmp::{core::cmp::Eq<core::cmp::Reverse<@T>>}::assert_receiver_is_total_eq" "_root_.Aeneas.Std.core.cmp.EqReverse.assert_receiver_is_total_eq";
  (* file: "Aeneas/Std/Core/Reverse.lean", line: 141 *)
  mk_fun "core::cmp::{core::cmp::Ord<core::cmp::Reverse<@T>>}::clamp" "_root_.Aeneas.Std.core.cmp.OrdReverse.clamp";
  (* file: "Aeneas/Std/Core/Reverse.lean", line: 123 *)
  mk_fun "core::cmp::{core::cmp::Ord<core::cmp::Reverse<@T>>}::cmp" "_root_.Aeneas.Std.core.cmp.OrdReverse.cmp";
  (* file: "Aeneas/Std/Core/Reverse.lean", line: 131 *)
  mk_fun "core::cmp::{core::cmp::Ord<core::cmp::Reverse<@T>>}::max" "_root_.Aeneas.Std.core.cmp.OrdReverse.max";
  (* file: "Aeneas/Std/Core/Reverse.lean", line: 136 *)
  mk_fun "core::cmp::{core::cmp::Ord<core::cmp::Reverse<@T>>}::min" "_root_.Aeneas.Std.core.cmp.OrdReverse.min";
  (* file: "Aeneas/Std/Core/Reverse.lean", line: 16 *)
  mk_fun "core::cmp::{core::cmp::PartialEq<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>}::eq" "_root_.Aeneas.Std.core.cmp.PartialEqReverse.eq";
  (* file: "Aeneas/Std/Core/Reverse.lean", line: 22 *)
  mk_fun "core::cmp::{core::cmp::PartialEq<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>}::ne" "_root_.Aeneas.Std.core.cmp.PartialEqReverse.ne";
  (* file: "Aeneas/Std/Core/Reverse.lean", line: 99 *)
  mk_fun "core::cmp::{core::cmp::PartialOrd<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>}::__chaining_ge" "_root_.Aeneas.Std.core.cmp.PartialOrdReverse.__chaining_ge";
  (* file: "Aeneas/Std/Core/Reverse.lean", line: 92 *)
  mk_fun "core::cmp::{core::cmp::PartialOrd<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>}::__chaining_gt" "_root_.Aeneas.Std.core.cmp.PartialOrdReverse.__chaining_gt";
  (* file: "Aeneas/Std/Core/Reverse.lean", line: 85 *)
  mk_fun "core::cmp::{core::cmp::PartialOrd<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>}::__chaining_le" "_root_.Aeneas.Std.core.cmp.PartialOrdReverse.__chaining_le";
  (* file: "Aeneas/Std/Core/Reverse.lean", line: 78 *)
  mk_fun "core::cmp::{core::cmp::PartialOrd<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>}::__chaining_lt" "_root_.Aeneas.Std.core.cmp.PartialOrdReverse.__chaining_lt";
  (* file: "Aeneas/Std/Core/Reverse.lean", line: 70 *)
  mk_fun "core::cmp::{core::cmp::PartialOrd<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>}::ge" "_root_.Aeneas.Std.core.cmp.PartialOrdReverse.ge";
  (* file: "Aeneas/Std/Core/Reverse.lean", line: 65 *)
  mk_fun "core::cmp::{core::cmp::PartialOrd<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>}::gt" "_root_.Aeneas.Std.core.cmp.PartialOrdReverse.gt";
  (* file: "Aeneas/Std/Core/Reverse.lean", line: 60 *)
  mk_fun "core::cmp::{core::cmp::PartialOrd<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>}::le" "_root_.Aeneas.Std.core.cmp.PartialOrdReverse.le";
  (* file: "Aeneas/Std/Core/Reverse.lean", line: 55 *)
  mk_fun "core::cmp::{core::cmp::PartialOrd<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>}::lt" "_root_.Aeneas.Std.core.cmp.PartialOrdReverse.lt";
  (* file: "Aeneas/Std/Core/Reverse.lean", line: 47 *)
  mk_fun "core::cmp::{core::cmp::PartialOrd<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>}::partial_cmp" "_root_.Aeneas.Std.core.cmp.PartialOrdReverse.partial_cmp";
  (* file: "Aeneas/Std/Scalar/CoreConvertNum.lean", line: 25 *)
  mk_fun "core::convert::num::ptr_try_from_impls::{core::convert::TryFrom<i32, usize, core::num::error::TryFromIntError>}::try_from" "_root_.Aeneas.Std.core.convert.num.TryFromI32Usize.try_from";
  (* file: "Aeneas/Std/Scalar/CoreConvertNum.lean", line: 47 *)
  mk_fun "core::convert::num::ptr_try_from_impls::{core::convert::TryFrom<i64, usize, core::num::error::TryFromIntError>}::try_from" "_root_.Aeneas.Std.core.convert.num.TryFromI64Usize.try_from";
  (* file: "Aeneas/Std/Scalar/CoreConvertNum.lean", line: 74 *)
  mk_fun "core::convert::num::ptr_try_from_impls::{core::convert::TryFrom<u32, usize, core::num::error::TryFromIntError>}::try_from" "_root_.Aeneas.Std.core.convert.num.TryFromU32Usize.try_from";
  (* file: "Aeneas/Std/Scalar/CoreConvertNum.lean", line: 60 *)
  mk_fun "core::convert::num::ptr_try_from_impls::{core::convert::TryFrom<u64, usize, core::num::error::TryFromIntError>}::try_from" "_root_.Aeneas.Std.core.convert.num.TryFromU64Usize.try_from";
  (* file: "Aeneas/Std/Scalar/CoreConvertNum.lean", line: 36 *)
  mk_fun "core::convert::num::ptr_try_from_impls::{core::convert::TryFrom<usize, i32, core::num::error::TryFromIntError>}::try_from" "_root_.Aeneas.Std.core.convert.num.TryFromUsizeI32.try_from";
  (* file: "Aeneas/Std/Scalar/CoreConvertNum.lean", line: 101 *)
  mk_fun "core::convert::num::ptr_try_from_impls::{core::convert::TryFrom<usize, i64, core::num::error::TryFromIntError>}::try_from" "_root_.Aeneas.Std.core.convert.num.TryFromUsizeI64.try_from";
  (* file: "Aeneas/Std/Float.lean", line: 599 *)
  mk_fun "core::convert::num::{core::convert::From<f64, f32>}::from" "_root_.Aeneas.Std.core.convert.num.FromF64F32.from_";
  (* file: "Aeneas/Std/Scalar/CoreConvertNum.lean", line: 127 *)
  mk_fun "core::convert::num::{core::convert::TryFrom<i16, i64, core::num::error::TryFromIntError>}::try_from" "_root_.Aeneas.Std.core.convert.num.TryFromI16I64.try_from";
  (* file: "Aeneas/Std/Scalar/CoreConvertNum.lean", line: 139 *)
  mk_fun "core::convert::num::{core::convert::TryFrom<i32, i64, core::num::error::TryFromIntError>}::try_from" "_root_.Aeneas.Std.core.convert.num.TryFromI32I64.try_from";
  (* file: "Aeneas/Std/Scalar/CoreConvertNum.lean", line: 115 *)
  mk_fun "core::convert::num::{core::convert::TryFrom<i8, i64, core::num::error::TryFromIntError>}::try_from" "_root_.Aeneas.Std.core.convert.num.TryFromI8I64.try_from";
  (* file: "Aeneas/Std/Scalar/CoreConvertNum.lean", line: 87 *)
  mk_fun "core::convert::num::{core::convert::TryFrom<u64, i64, core::num::error::TryFromIntError>}::try_from" "_root_.Aeneas.Std.core.convert.num.TryFromU64I64.try_from";
  (* file: "Aeneas/Std/Core/Core.lean", line: 53 *)
  mk_fun "core::convert::{core::convert::From<@T, @T>}::from" "_root_.Aeneas.Std.core.convert.FromSame.from_" ~can_fail:false;
  (* file: "Aeneas/Std/Core/Convert.lean", line: 20 *)
  mk_fun "core::convert::{core::convert::Into<@T, @U>}::into" "_root_.Aeneas.Std.core.convert.IntoFrom.into";
  (* file: "Aeneas/Std/Core/Convert.lean", line: 37 *)
  mk_fun "core::convert::{core::convert::TryFrom<@T, @U, core::convert::Infallible>}::try_from" "_root_.Aeneas.Std.core.convert.TryFromTUInfallible.Blanket.try_from";
  (* file: "Aeneas/Std/Core/Convert.lean", line: 50 *)
  mk_fun "core::convert::{core::convert::TryInto<@T, @U, @Error>}::try_into" "_root_.Aeneas.Std.core.convert.TryInto.Blanket.try_into";
  (* file: "Aeneas/Std/Core/Default.lean", line: 9 *)
  mk_fun "core::default::{core::default::Default<bool>}::default" "_root_.Aeneas.Std.core.default.DefaultBool.default";
  (* file: "Aeneas/Std/Core/Error.lean", line: 12 *)
  mk_fun "core::error::Error::source" "_root_.Aeneas.Std.core.error.Error.source.default";
  (* file: "Aeneas/Std/Float.lean", line: 359 *)
  mk_fun "core::f32::{f32}::abs" "_root_.Aeneas.Std.F32.abs";
  (* file: "Aeneas/Std/Float.lean", line: 330 *)
  mk_fun "core::f32::{f32}::from_bits" "_root_.Aeneas.Std.F32.from_bits";
  (* file: "Aeneas/Std/Float.lean", line: 355 *)
  mk_fun "core::f32::{f32}::is_finite" "_root_.Aeneas.Std.F32.is_finite";
  (* file: "Aeneas/Std/Float.lean", line: 353 *)
  mk_fun "core::f32::{f32}::is_infinite" "_root_.Aeneas.Std.F32.is_infinite";
  (* file: "Aeneas/Std/Float.lean", line: 351 *)
  mk_fun "core::f32::{f32}::is_nan" "_root_.Aeneas.Std.F32.is_nan";
  (* file: "Aeneas/Std/Float.lean", line: 357 *)
  mk_fun "core::f32::{f32}::is_sign_negative" "_root_.Aeneas.Std.F32.is_sign_negative";
  (* file: "Aeneas/Std/Float.lean", line: 383 *)
  mk_fun "core::f32::{f32}::max" "_root_.Aeneas.Std.F32.max";
  (* file: "Aeneas/Std/Float.lean", line: 386 *)
  mk_fun "core::f32::{f32}::min" "_root_.Aeneas.Std.F32.min";
  (* file: "Aeneas/Std/Float.lean", line: 370 *)
  mk_fun "core::f32::{f32}::recip" "_root_.Aeneas.Std.F32.recip";
  (* file: "Aeneas/Std/Float.lean", line: 332 *)
  mk_fun "core::f32::{f32}::to_bits" "_root_.Aeneas.Std.F32.to_bits";
  (* file: "Aeneas/Std/Float.lean", line: 494 *)
  mk_fun "core::f64::{f64}::abs" "_root_.Aeneas.Std.F64.abs";
  (* file: "Aeneas/Std/Float.lean", line: 459 *)
  mk_fun "core::f64::{f64}::from_bits" "_root_.Aeneas.Std.F64.from_bits";
  (* file: "Aeneas/Std/Float.lean", line: 490 *)
  mk_fun "core::f64::{f64}::is_finite" "_root_.Aeneas.Std.F64.is_finite";
  (* file: "Aeneas/Std/Float.lean", line: 488 *)
  mk_fun "core::f64::{f64}::is_infinite" "_root_.Aeneas.Std.F64.is_infinite";
  (* file: "Aeneas/Std/Float.lean", line: 486 *)
  mk_fun "core::f64::{f64}::is_nan" "_root_.Aeneas.Std.F64.is_nan";
  (* file: "Aeneas/Std/Float.lean", line: 492 *)
  mk_fun "core::f64::{f64}::is_sign_negative" "_root_.Aeneas.Std.F64.is_sign_negative";
  (* file: "Aeneas/Std/Float.lean", line: 518 *)
  mk_fun "core::f64::{f64}::max" "_root_.Aeneas.Std.F64.max";
  (* file: "Aeneas/Std/Float.lean", line: 521 *)
  mk_fun "core::f64::{f64}::min" "_root_.Aeneas.Std.F64.min";
  (* file: "Aeneas/Std/Float.lean", line: 505 *)
  mk_fun "core::f64::{f64}::recip" "_root_.Aeneas.Std.F64.recip";
  (* file: "Aeneas/Std/Float.lean", line: 461 *)
  mk_fun "core::f64::{f64}::to_bits" "_root_.Aeneas.Std.F64.to_bits";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 421 *)
  mk_fun "core::fmt::builders::{core::fmt::builders::DebugStruct<'a, 'b>}::field" "_root_.Aeneas.Std.core.fmt.DebugStruct.field";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 443 *)
  mk_fun "core::fmt::builders::{core::fmt::builders::DebugStruct<'a, 'b>}::finish" "_root_.Aeneas.Std.core.fmt.DebugStruct.finish";
  (* file: "Aeneas/Std/FloatFmt.lean", line: 159 *)
  mk_fun "core::fmt::float::{core::fmt::Debug<f32>}::fmt" "_root_.Aeneas.Std.core.fmt.DebugF32.fmt";
  (* file: "Aeneas/Std/FloatFmt.lean", line: 168 *)
  mk_fun "core::fmt::float::{core::fmt::Debug<f64>}::fmt" "_root_.Aeneas.Std.core.fmt.DebugF64.fmt";
  (* file: "Aeneas/Std/FloatFmt.lean", line: 163 *)
  mk_fun "core::fmt::float::{core::fmt::Display<f32>}::fmt" "_root_.Aeneas.Std.core.fmt.DisplayF32.fmt";
  (* file: "Aeneas/Std/FloatFmt.lean", line: 172 *)
  mk_fun "core::fmt::float::{core::fmt::Display<f64>}::fmt" "_root_.Aeneas.Std.core.fmt.DisplayF64.fmt";
  (* file: "Aeneas/Std/FloatFmt.lean", line: 207 *)
  mk_fun "core::fmt::float::{core::fmt::LowerExp<f64>}::fmt" "_root_.Aeneas.Std.core.fmt.LowerExpF64.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 152 *)
  mk_fun "core::fmt::num::imp::{core::fmt::Display<i128>}::fmt" "_root_.Aeneas.Std.core.fmt.num.DisplayI128.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 116 *)
  mk_fun "core::fmt::num::imp::{core::fmt::Display<i16>}::fmt" "_root_.Aeneas.Std.core.fmt.num.DisplayI16.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 128 *)
  mk_fun "core::fmt::num::imp::{core::fmt::Display<i32>}::fmt" "_root_.Aeneas.Std.core.fmt.num.DisplayI32.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 140 *)
  mk_fun "core::fmt::num::imp::{core::fmt::Display<i64>}::fmt" "_root_.Aeneas.Std.core.fmt.num.DisplayI64.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 104 *)
  mk_fun "core::fmt::num::imp::{core::fmt::Display<i8>}::fmt" "_root_.Aeneas.Std.core.fmt.num.DisplayI8.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 164 *)
  mk_fun "core::fmt::num::imp::{core::fmt::Display<isize>}::fmt" "_root_.Aeneas.Std.core.fmt.num.DisplayIsize.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 80 *)
  mk_fun "core::fmt::num::imp::{core::fmt::Display<u128>}::fmt" "_root_.Aeneas.Std.core.fmt.num.DisplayU128.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 44 *)
  mk_fun "core::fmt::num::imp::{core::fmt::Display<u16>}::fmt" "_root_.Aeneas.Std.core.fmt.num.DisplayU16.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 56 *)
  mk_fun "core::fmt::num::imp::{core::fmt::Display<u32>}::fmt" "_root_.Aeneas.Std.core.fmt.num.DisplayU32.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 68 *)
  mk_fun "core::fmt::num::imp::{core::fmt::Display<u64>}::fmt" "_root_.Aeneas.Std.core.fmt.num.DisplayU64.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 32 *)
  mk_fun "core::fmt::num::imp::{core::fmt::Display<u8>}::fmt" "_root_.Aeneas.Std.core.fmt.num.DisplayU8.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 92 *)
  mk_fun "core::fmt::num::imp::{core::fmt::Display<usize>}::fmt" "_root_.Aeneas.Std.core.fmt.num.DisplayUsize.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 146 *)
  mk_fun "core::fmt::num::{core::fmt::Debug<i128>}::fmt" "_root_.Aeneas.Std.core.fmt.num.DebugI128.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 110 *)
  mk_fun "core::fmt::num::{core::fmt::Debug<i16>}::fmt" "_root_.Aeneas.Std.core.fmt.num.DebugI16.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 122 *)
  mk_fun "core::fmt::num::{core::fmt::Debug<i32>}::fmt" "_root_.Aeneas.Std.core.fmt.num.DebugI32.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 134 *)
  mk_fun "core::fmt::num::{core::fmt::Debug<i64>}::fmt" "_root_.Aeneas.Std.core.fmt.num.DebugI64.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 98 *)
  mk_fun "core::fmt::num::{core::fmt::Debug<i8>}::fmt" "_root_.Aeneas.Std.core.fmt.num.DebugI8.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 158 *)
  mk_fun "core::fmt::num::{core::fmt::Debug<isize>}::fmt" "_root_.Aeneas.Std.core.fmt.num.DebugIsize.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 74 *)
  mk_fun "core::fmt::num::{core::fmt::Debug<u128>}::fmt" "_root_.Aeneas.Std.core.fmt.num.DebugU128.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 38 *)
  mk_fun "core::fmt::num::{core::fmt::Debug<u16>}::fmt" "_root_.Aeneas.Std.core.fmt.num.DebugU16.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 50 *)
  mk_fun "core::fmt::num::{core::fmt::Debug<u32>}::fmt" "_root_.Aeneas.Std.core.fmt.num.DebugU32.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 62 *)
  mk_fun "core::fmt::num::{core::fmt::Debug<u64>}::fmt" "_root_.Aeneas.Std.core.fmt.num.DebugU64.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 26 *)
  mk_fun "core::fmt::num::{core::fmt::Debug<u8>}::fmt" "_root_.Aeneas.Std.core.fmt.num.DebugU8.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 86 *)
  mk_fun "core::fmt::num::{core::fmt::Debug<usize>}::fmt" "_root_.Aeneas.Std.core.fmt.num.DebugUsize.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 178 *)
  mk_fun "core::fmt::num::{core::fmt::LowerHex<u16>}::fmt" "_root_.Aeneas.Std.core.fmt.num.LowerHexU16.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 184 *)
  mk_fun "core::fmt::num::{core::fmt::LowerHex<u32>}::fmt" "_root_.Aeneas.Std.core.fmt.num.LowerHexU32.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 190 *)
  mk_fun "core::fmt::num::{core::fmt::LowerHex<u64>}::fmt" "_root_.Aeneas.Std.core.fmt.num.LowerHexU64.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 172 *)
  mk_fun "core::fmt::num::{core::fmt::LowerHex<u8>}::fmt" "_root_.Aeneas.Std.core.fmt.num.LowerHexU8.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 204 *)
  mk_fun "core::fmt::num::{core::fmt::UpperHex<u32>}::fmt" "_root_.Aeneas.Std.core.fmt.num.UpperHexU32.fmt";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 198 *)
  mk_fun "core::fmt::num::{core::fmt::UpperHex<u8>}::fmt" "_root_.Aeneas.Std.core.fmt.num.UpperHexU8.fmt";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 178 *)
  mk_fun "core::fmt::rt::{core::fmt::rt::Argument<'0>}::from_usize" "_root_.Aeneas.Std.core.fmt.rt.Argument.from_usize";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 154 *)
  mk_fun "core::fmt::rt::{core::fmt::rt::Argument<'0>}::new_debug" "_root_.Aeneas.Std.core.fmt.rt.Argument.new_debug";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 174 *)
  mk_fun "core::fmt::rt::{core::fmt::rt::Argument<'0>}::new_debug_noop" "_root_.Aeneas.Std.core.fmt.rt.Argument.new_debug_noop";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 158 *)
  mk_fun "core::fmt::rt::{core::fmt::rt::Argument<'0>}::new_display" "_root_.Aeneas.Std.core.fmt.rt.Argument.new_display";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 170 *)
  mk_fun "core::fmt::rt::{core::fmt::rt::Argument<'0>}::new_lower_exp" "_root_.Aeneas.Std.core.fmt.rt.Argument.new_lower_exp";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 162 *)
  mk_fun "core::fmt::rt::{core::fmt::rt::Argument<'0>}::new_lower_hex" "_root_.Aeneas.Std.core.fmt.rt.Argument.new_lower_hex";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 166 *)
  mk_fun "core::fmt::rt::{core::fmt::rt::Argument<'0>}::new_upper_hex" "_root_.Aeneas.Std.core.fmt.rt.Argument.new_upper_hex";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 142 *)
  mk_fun "core::fmt::{core::fmt::Arguments<'a>}::from_str" "_root_.Aeneas.Std.core.fmt.Arguments.from_str";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 146 *)
  mk_fun "core::fmt::{core::fmt::Arguments<'a>}::from_str_nonconst" "_root_.Aeneas.Std.core.fmt.Arguments.from_str_nonconst";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 149 *)
  mk_fun "core::fmt::{core::fmt::Arguments<'a>}::new" "_root_.Aeneas.Std.core.fmt.Arguments.new";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 314 *)
  mk_fun "core::fmt::{core::fmt::Debug<&'0 @T>}::fmt" "_root_.Aeneas.Std.core.fmt.DebugShared.fmt";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 344 *)
  mk_fun "core::fmt::{core::fmt::Debug<()>}::fmt" "_root_.Aeneas.Std.core.fmt.DebugUnit.fmt";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 175 *)
  mk_fun "core::fmt::{core::fmt::Debug<(@A, @B)>}::fmt" "_root_.Aeneas.Std.core.fmt.DebugPair.fmt";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 183 *)
  mk_fun "core::fmt::{core::fmt::Debug<(@V, @U, @T)>}::fmt" "_root_.Aeneas.Std.core.fmt.DebugTriple.fmt";
  (* file: "Aeneas/Std/Vec.lean", line: 807 *)
  mk_fun "core::fmt::{core::fmt::Debug<[@T]>}::fmt" "_root_.Aeneas.Std.core.fmt.DebugSlice.fmt";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 333 *)
  mk_fun "core::fmt::{core::fmt::Debug<bool>}::fmt" "_root_.Aeneas.Std.core.fmt.DebugBool.fmt";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 48 *)
  mk_fun "core::fmt::{core::fmt::Debug<char>}::fmt" "_root_.Aeneas.Std.core.fmt.DebugChar.fmt";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 63 *)
  mk_fun "core::fmt::{core::fmt::Debug<str>}::fmt" "_root_.Aeneas.Std.core.fmt.DebugStr.fmt";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 83 *)
  mk_fun "core::fmt::{core::fmt::Display<&'0 @T>}::fmt" "_root_.Aeneas.Std.core.fmt.DisplayShared.fmt";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 339 *)
  mk_fun "core::fmt::{core::fmt::Display<bool>}::fmt" "_root_.Aeneas.Std.core.fmt.DisplayBool.fmt";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 57 *)
  mk_fun "core::fmt::{core::fmt::Display<char>}::fmt" "_root_.Aeneas.Std.core.fmt.DisplayChar.fmt";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 68 *)
  mk_fun "core::fmt::{core::fmt::Display<str>}::fmt" "_root_.Aeneas.Std.core.fmt.DisplayStr.fmt";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 405 *)
  mk_fun "core::fmt::{core::fmt::Formatter<'a>}::debug_struct" "_root_.Aeneas.Std.core.fmt.Formatter.debug_struct";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 349 *)
  mk_fun "core::fmt::{core::fmt::Formatter<'a>}::debug_struct_field1_finish" "_root_.Aeneas.Std.core.fmt.Formatter.debug_struct_field1_finish";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 354 *)
  mk_fun "core::fmt::{core::fmt::Formatter<'a>}::debug_struct_field2_finish" "_root_.Aeneas.Std.core.fmt.Formatter.debug_struct_field2_finish";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 359 *)
  mk_fun "core::fmt::{core::fmt::Formatter<'a>}::debug_struct_field3_finish" "_root_.Aeneas.Std.core.fmt.Formatter.debug_struct_field3_finish";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 365 *)
  mk_fun "core::fmt::{core::fmt::Formatter<'a>}::debug_struct_field4_finish" "_root_.Aeneas.Std.core.fmt.Formatter.debug_struct_field4_finish";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 372 *)
  mk_fun "core::fmt::{core::fmt::Formatter<'a>}::debug_struct_field5_finish" "_root_.Aeneas.Std.core.fmt.Formatter.debug_struct_field5_finish";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 12 *)
  mk_fun "core::fmt::{core::fmt::Formatter<'a>}::debug_struct_fields_finish" "_root_.Aeneas.Std.core.fmt.Formatter.debug_struct_fields_finish";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 380 *)
  mk_fun "core::fmt::{core::fmt::Formatter<'a>}::debug_tuple_field1_finish" "_root_.Aeneas.Std.core.fmt.Formatter.debug_tuple_field1_finish";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 384 *)
  mk_fun "core::fmt::{core::fmt::Formatter<'a>}::debug_tuple_field2_finish" "_root_.Aeneas.Std.core.fmt.Formatter.debug_tuple_field2_finish";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 389 *)
  mk_fun "core::fmt::{core::fmt::Formatter<'a>}::debug_tuple_field3_finish" "_root_.Aeneas.Std.core.fmt.Formatter.debug_tuple_field3_finish";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 236 *)
  mk_fun "core::fmt::{core::fmt::Formatter<'a>}::write_fmt" "_root_.Aeneas.Std.core.fmt.Formatter.write_fmt";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 232 *)
  mk_fun "core::fmt::{core::fmt::Formatter<'a>}::write_str" "_root_.Aeneas.Std.core.fmt.Formatter.write_str";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 327 *)
  mk_fun "core::fmt::{core::fmt::LowerHex<&'0 @T>}::fmt" "_root_.Aeneas.Std.core.fmt.LowerHexShared.fmt";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 320 *)
  mk_fun "core::fmt::{core::fmt::UpperHex<&'0 @T>}::fmt" "_root_.Aeneas.Std.core.fmt.UpperHexShared.fmt";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 265 *)
  mk_fun "core::hash::impls::{core::hash::Hash<&'0 @T>}::hash" "_root_.Aeneas.Std.core.hash.impls.HashShared.hash";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 318 *)
  mk_fun "core::hash::impls::{core::hash::Hash<[@T]>}::hash" "_root_.Aeneas.Std.core.hash.impls.HashSlice.hash";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 253 *)
  mk_fun "core::hash::impls::{core::hash::Hash<bool>}::hash" "_root_.Aeneas.Std.core.hash.impls.HashBool.hash";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 257 *)
  mk_fun "core::hash::impls::{core::hash::Hash<char>}::hash" "_root_.Aeneas.Std.core.hash.impls.HashChar.hash";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 197 *)
  mk_fun "core::hash::impls::{core::hash::Hash<i128>}::hash" "_root_.Aeneas.Std.core.hash.impls.HashI128.hash";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 244 *)
  mk_fun "core::hash::impls::{core::hash::Hash<i128>}::hash_slice" "_root_.Aeneas.Std.core.hash.impls.HashI128.hash_slice";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 188 *)
  mk_fun "core::hash::impls::{core::hash::Hash<i16>}::hash" "_root_.Aeneas.Std.core.hash.impls.HashI16.hash";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 232 *)
  mk_fun "core::hash::impls::{core::hash::Hash<i16>}::hash_slice" "_root_.Aeneas.Std.core.hash.impls.HashI16.hash_slice";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 191 *)
  mk_fun "core::hash::impls::{core::hash::Hash<i32>}::hash" "_root_.Aeneas.Std.core.hash.impls.HashI32.hash";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 236 *)
  mk_fun "core::hash::impls::{core::hash::Hash<i32>}::hash_slice" "_root_.Aeneas.Std.core.hash.impls.HashI32.hash_slice";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 194 *)
  mk_fun "core::hash::impls::{core::hash::Hash<i64>}::hash" "_root_.Aeneas.Std.core.hash.impls.HashI64.hash";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 240 *)
  mk_fun "core::hash::impls::{core::hash::Hash<i64>}::hash_slice" "_root_.Aeneas.Std.core.hash.impls.HashI64.hash_slice";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 185 *)
  mk_fun "core::hash::impls::{core::hash::Hash<i8>}::hash" "_root_.Aeneas.Std.core.hash.impls.HashI8.hash";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 228 *)
  mk_fun "core::hash::impls::{core::hash::Hash<i8>}::hash_slice" "_root_.Aeneas.Std.core.hash.impls.HashI8.hash_slice";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 200 *)
  mk_fun "core::hash::impls::{core::hash::Hash<isize>}::hash" "_root_.Aeneas.Std.core.hash.impls.HashIsize.hash";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 248 *)
  mk_fun "core::hash::impls::{core::hash::Hash<isize>}::hash_slice" "_root_.Aeneas.Std.core.hash.impls.HashIsize.hash_slice";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 261 *)
  mk_fun "core::hash::impls::{core::hash::Hash<str>}::hash" "_root_.Aeneas.Std.core.hash.impls.HashStr.hash";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 179 *)
  mk_fun "core::hash::impls::{core::hash::Hash<u128>}::hash" "_root_.Aeneas.Std.core.hash.impls.HashU128.hash";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 220 *)
  mk_fun "core::hash::impls::{core::hash::Hash<u128>}::hash_slice" "_root_.Aeneas.Std.core.hash.impls.HashU128.hash_slice";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 170 *)
  mk_fun "core::hash::impls::{core::hash::Hash<u16>}::hash" "_root_.Aeneas.Std.core.hash.impls.HashU16.hash";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 208 *)
  mk_fun "core::hash::impls::{core::hash::Hash<u16>}::hash_slice" "_root_.Aeneas.Std.core.hash.impls.HashU16.hash_slice";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 173 *)
  mk_fun "core::hash::impls::{core::hash::Hash<u32>}::hash" "_root_.Aeneas.Std.core.hash.impls.HashU32.hash";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 212 *)
  mk_fun "core::hash::impls::{core::hash::Hash<u32>}::hash_slice" "_root_.Aeneas.Std.core.hash.impls.HashU32.hash_slice";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 176 *)
  mk_fun "core::hash::impls::{core::hash::Hash<u64>}::hash" "_root_.Aeneas.Std.core.hash.impls.HashU64.hash";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 216 *)
  mk_fun "core::hash::impls::{core::hash::Hash<u64>}::hash_slice" "_root_.Aeneas.Std.core.hash.impls.HashU64.hash_slice";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 167 *)
  mk_fun "core::hash::impls::{core::hash::Hash<u8>}::hash" "_root_.Aeneas.Std.core.hash.impls.HashU8.hash";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 204 *)
  mk_fun "core::hash::impls::{core::hash::Hash<u8>}::hash_slice" "_root_.Aeneas.Std.core.hash.impls.HashU8.hash_slice";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 182 *)
  mk_fun "core::hash::impls::{core::hash::Hash<usize>}::hash" "_root_.Aeneas.Std.core.hash.impls.HashUsize.hash";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 224 *)
  mk_fun "core::hash::impls::{core::hash::Hash<usize>}::hash_slice" "_root_.Aeneas.Std.core.hash.impls.HashUsize.hash_slice";
  (* file: "Aeneas/Std/Core/Core.lean", line: 69 *)
  mk_fun "core::hint::must_use" "_root_.Aeneas.Std.core.hint.must_use" ~can_fail:false;
  (* file: "Aeneas/Std/Core/Core.lean", line: 92 *)
  mk_fun "core::hint::unreachable_unchecked::precondition_check" "_root_.Aeneas.Std.core.hint.unreachable_unchecked.precondition_check";
  (* file: "Aeneas/Std/Core/Discriminant.lean", line: 74 *)
  mk_fun "core::intrinsics::discriminant_value" "_root_.Aeneas.Std.core.intrinsics.discriminant_value";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 140 *)
  mk_fun "core::iter::adapters::chain::{core::iter::traits::iterator::Iterator<core::iter::adapters::chain::Chain<@A, @B>, @Clause0_Item>}::advance_by" "_root_.Aeneas.Std.core.iter.adapters.chain.IteratorChain.advance_by";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 232 *)
  mk_fun "core::iter::adapters::chain::{core::iter::traits::iterator::Iterator<core::iter::adapters::chain::Chain<@A, @B>, @Clause0_Item>}::any" "_root_.Aeneas.Std.core.iter.adapters.chain.IteratorChain.any";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 219 *)
  mk_fun "core::iter::adapters::chain::{core::iter::traits::iterator::Iterator<core::iter::adapters::chain::Chain<@A, @B>, @Clause0_Item>}::count" "_root_.Aeneas.Std.core.iter.adapters.chain.IteratorChain.count";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 264 *)
  mk_fun "core::iter::adapters::chain::{core::iter::traits::iterator::Iterator<core::iter::adapters::chain::Chain<@A, @B>, @Clause0_Item>}::enumerate" "_root_.Aeneas.Std.core.iter.adapters.chain.IteratorChain.enumerate";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 244 *)
  mk_fun "core::iter::adapters::chain::{core::iter::traits::iterator::Iterator<core::iter::adapters::chain::Chain<@A, @B>, @Clause0_Item>}::find" "_root_.Aeneas.Std.core.iter.adapters.chain.IteratorChain.find";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 160 *)
  mk_fun "core::iter::adapters::chain::{core::iter::traits::iterator::Iterator<core::iter::adapters::chain::Chain<@A, @B>, @Clause0_Item>}::fold" "_root_.Aeneas.Std.core.iter.adapters.chain.IteratorChain.fold";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 96 *)
  mk_fun "core::iter::adapters::chain::{core::iter::traits::iterator::Iterator<core::iter::adapters::chain::Chain<@A, @B>, @Clause0_Item>}::next" "_root_.Aeneas.Std.core.iter.adapters.chain.IteratorChain.next";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 115 *)
  mk_fun "core::iter::adapters::chain::{core::iter::traits::iterator::Iterator<core::iter::adapters::chain::Chain<@A, @B>, @Clause0_Item>}::nth" "_root_.Aeneas.Std.core.iter.adapters.chain.IteratorChain.nth";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 202 *)
  mk_fun "core::iter::adapters::chain::{core::iter::traits::iterator::Iterator<core::iter::adapters::chain::Chain<@A, @B>, @Clause0_Item>}::size_hint" "_root_.Aeneas.Std.core.iter.adapters.chain.IteratorChain.size_hint";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 174 *)
  mk_fun "core::iter::adapters::chain::{core::iter::traits::iterator::Iterator<core::iter::adapters::chain::Chain<@A, @B>, @Clause0_Item>}::try_fold" "_root_.Aeneas.Std.core.iter.adapters.chain.IteratorChain.try_fold";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 913 *)
  mk_fun "core::iter::adapters::cloned::{core::iter::traits::iterator::Iterator<core::iter::adapters::cloned::Cloned<@I>, @T>}::fold" "_root_.Aeneas.Std.core.iter.adapters.cloned.IteratorCloned.fold";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 848 *)
  mk_fun "core::iter::adapters::cloned::{core::iter::traits::iterator::Iterator<core::iter::adapters::cloned::Cloned<@I>, @T>}::next" "_root_.Aeneas.Std.core.iter.adapters.cloned.IteratorCloned.next";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 942 *)
  mk_fun "core::iter::adapters::cloned::{core::iter::traits::iterator::Iterator<core::iter::adapters::cloned::Cloned<@I>, @T>}::size_hint" "_root_.Aeneas.Std.core.iter.adapters.cloned.IteratorCloned.size_hint";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 927 *)
  mk_fun "core::iter::adapters::cloned::{core::iter::traits::iterator::Iterator<core::iter::adapters::cloned::Cloned<@I>, @T>}::try_fold" "_root_.Aeneas.Std.core.iter.adapters.cloned.IteratorCloned.try_fold";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 903 *)
  mk_fun "core::iter::adapters::copied::{core::iter::traits::iterator::Iterator<core::iter::adapters::copied::Copied<@I>, @T>}::advance_by" "_root_.Aeneas.Std.core.iter.adapters.copied.IteratorCopied.advance_by";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 839 *)
  mk_fun "core::iter::adapters::copied::{core::iter::traits::iterator::Iterator<core::iter::adapters::copied::Copied<@I>, @T>}::count" "_root_.Aeneas.Std.core.iter.adapters.copied.IteratorCopied.count";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 996 *)
  mk_fun "core::iter::adapters::copied::{core::iter::traits::iterator::Iterator<core::iter::adapters::copied::Copied<@I>, @T>}::eq" "_root_.Aeneas.Std.core.iter.adapters.copied.IteratorCopied.eq";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 862 *)
  mk_fun "core::iter::adapters::copied::{core::iter::traits::iterator::Iterator<core::iter::adapters::copied::Copied<@I>, @T>}::fold" "_root_.Aeneas.Std.core.iter.adapters.copied.IteratorCopied.fold";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 985 *)
  mk_fun "core::iter::adapters::copied::{core::iter::traits::iterator::Iterator<core::iter::adapters::copied::Copied<@I>, @T>}::min_by_key" "_root_.Aeneas.Std.core.iter.adapters.copied.IteratorCopied.min_by_key";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 827 *)
  mk_fun "core::iter::adapters::copied::{core::iter::traits::iterator::Iterator<core::iter::adapters::copied::Copied<@I>, @T>}::next" "_root_.Aeneas.Std.core.iter.adapters.copied.IteratorCopied.next";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 893 *)
  mk_fun "core::iter::adapters::copied::{core::iter::traits::iterator::Iterator<core::iter::adapters::copied::Copied<@I>, @T>}::nth" "_root_.Aeneas.Std.core.iter.adapters.copied.IteratorCopied.nth";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 975 *)
  mk_fun "core::iter::adapters::copied::{core::iter::traits::iterator::Iterator<core::iter::adapters::copied::Copied<@I>, @T>}::product" "_root_.Aeneas.Std.core.iter.adapters.copied.IteratorCopied.product";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 885 *)
  mk_fun "core::iter::adapters::copied::{core::iter::traits::iterator::Iterator<core::iter::adapters::copied::Copied<@I>, @T>}::size_hint" "_root_.Aeneas.Std.core.iter.adapters.copied.IteratorCopied.size_hint";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 1233 *)
  mk_fun "core::iter::adapters::copied::{core::iter::traits::iterator::Iterator<core::iter::adapters::copied::Copied<@I>, @T>}::skip_while" "_root_.Aeneas.Std.core.iter.adapters.copied.IteratorCopied.skip_while";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 873 *)
  mk_fun "core::iter::adapters::copied::{core::iter::traits::iterator::Iterator<core::iter::adapters::copied::Copied<@I>, @T>}::try_fold" "_root_.Aeneas.Std.core.iter.adapters.copied.IteratorCopied.try_fold";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 385 *)
  mk_fun "core::iter::adapters::enumerate::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Clause0_Item)>}::advance_back_by" "_root_.Aeneas.Std.core.iter.adapters.enumerate.DoubleEndedIteratorEnumerate.advance_back_by";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 314 *)
  mk_fun "core::iter::adapters::enumerate::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Clause0_Item)>}::next_back" "_root_.Aeneas.Std.core.iter.adapters.enumerate.DoubleEndedIteratorEnumerate.next_back";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 328 *)
  mk_fun "core::iter::adapters::enumerate::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Clause0_Item)>}::nth_back" "_root_.Aeneas.Std.core.iter.adapters.enumerate.DoubleEndedIteratorEnumerate.nth_back";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 369 *)
  mk_fun "core::iter::adapters::enumerate::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Clause0_Item)>}::rfold" "_root_.Aeneas.Std.core.iter.adapters.enumerate.DoubleEndedIteratorEnumerate.rfold";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 352 *)
  mk_fun "core::iter::adapters::enumerate::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Clause0_Item)>}::try_rfold" "_root_.Aeneas.Std.core.iter.adapters.enumerate.DoubleEndedIteratorEnumerate.try_rfold";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 413 *)
  mk_fun "core::iter::adapters::enumerate::{core::iter::traits::exact_size::ExactSizeIterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Clause0_Item)>}::len" "_root_.Aeneas.Std.core.iter.adapters.enumerate.ExactSizeIteratorEnumerate.len";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 268 *)
  mk_fun "core::iter::adapters::enumerate::{core::iter::traits::iterator::Iterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Item)>}::advance_by" "_root_.Aeneas.Std.core.iter.adapters.enumerate.IteratorEnumerate.advance_by";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 208 *)
  mk_fun "core::iter::adapters::enumerate::{core::iter::traits::iterator::Iterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Item)>}::count" "_root_.Aeneas.Std.core.iter.adapters.enumerate.IteratorEnumerate.count";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 232 *)
  mk_fun "core::iter::adapters::enumerate::{core::iter::traits::iterator::Iterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Item)>}::fold" "_root_.Aeneas.Std.core.iter.adapters.enumerate.IteratorEnumerate.fold";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 193 *)
  mk_fun "core::iter::adapters::enumerate::{core::iter::traits::iterator::Iterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Item)>}::next" "_root_.Aeneas.Std.core.iter.adapters.enumerate.IteratorEnumerate.next";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 218 *)
  mk_fun "core::iter::adapters::enumerate::{core::iter::traits::iterator::Iterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Item)>}::nth" "_root_.Aeneas.Std.core.iter.adapters.enumerate.IteratorEnumerate.nth";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 261 *)
  mk_fun "core::iter::adapters::enumerate::{core::iter::traits::iterator::Iterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Item)>}::size_hint" "_root_.Aeneas.Std.core.iter.adapters.enumerate.IteratorEnumerate.size_hint";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 246 *)
  mk_fun "core::iter::adapters::enumerate::{core::iter::traits::iterator::Iterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Item)>}::try_fold" "_root_.Aeneas.Std.core.iter.adapters.enumerate.IteratorEnumerate.try_fold";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 1148 *)
  mk_fun "core::iter::adapters::filter::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::filter::Filter<@I, @P>, @Clause0_Clause0_Item>}::next_back" "_root_.Aeneas.Std.core.iter.adapters.filter.DoubleEndedIteratorFilter.next_back";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 1158 *)
  mk_fun "core::iter::adapters::filter::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::filter::Filter<@I, @P>, @Clause0_Clause0_Item>}::rfold" "_root_.Aeneas.Std.core.iter.adapters.filter.DoubleEndedIteratorFilter.rfold";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 1175 *)
  mk_fun "core::iter::adapters::filter::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::filter::Filter<@I, @P>, @Clause0_Clause0_Item>}::try_rfold" "_root_.Aeneas.Std.core.iter.adapters.filter.DoubleEndedIteratorFilter.try_rfold";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 1103 *)
  mk_fun "core::iter::adapters::filter::{core::iter::traits::iterator::Iterator<core::iter::adapters::filter::Filter<@I, @P>, @Clause0_Item>}::count" "_root_.Aeneas.Std.core.iter.adapters.filter.IteratorFilter.count";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 1057 *)
  mk_fun "core::iter::adapters::filter::{core::iter::traits::iterator::Iterator<core::iter::adapters::filter::Filter<@I, @P>, @Clause0_Item>}::fold" "_root_.Aeneas.Std.core.iter.adapters.filter.IteratorFilter.fold";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 1130 *)
  mk_fun "core::iter::adapters::filter::{core::iter::traits::iterator::Iterator<core::iter::adapters::filter::Filter<@I, @P>, @Clause0_Item>}::min_by_key" "_root_.Aeneas.Std.core.iter.adapters.filter.IteratorFilter.min_by_key";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 1046 *)
  mk_fun "core::iter::adapters::filter::{core::iter::traits::iterator::Iterator<core::iter::adapters::filter::Filter<@I, @P>, @Clause0_Item>}::next" "_root_.Aeneas.Std.core.iter.adapters.filter.IteratorFilter.next";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 1094 *)
  mk_fun "core::iter::adapters::filter::{core::iter::traits::iterator::Iterator<core::iter::adapters::filter::Filter<@I, @P>, @Clause0_Item>}::size_hint" "_root_.Aeneas.Std.core.iter.adapters.filter.IteratorFilter.size_hint";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 1074 *)
  mk_fun "core::iter::adapters::filter::{core::iter::traits::iterator::Iterator<core::iter::adapters::filter::Filter<@I, @P>, @Clause0_Item>}::try_fold" "_root_.Aeneas.Std.core.iter.adapters.filter.IteratorFilter.try_fold";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 715 *)
  mk_fun "core::iter::adapters::filter_map::{core::iter::traits::iterator::Iterator<core::iter::adapters::filter_map::FilterMap<@I, @F>, @B>}::fold" "_root_.Aeneas.Std.core.iter.adapters.filter_map.IteratorFilterMap.fold";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 777 *)
  mk_fun "core::iter::adapters::filter_map::{core::iter::traits::iterator::Iterator<core::iter::adapters::filter_map::FilterMap<@I, @F>, @B>}::max" "_root_.Aeneas.Std.core.iter.adapters.filter_map.IteratorFilterMap.max";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 788 *)
  mk_fun "core::iter::adapters::filter_map::{core::iter::traits::iterator::Iterator<core::iter::adapters::filter_map::FilterMap<@I, @F>, @B>}::min" "_root_.Aeneas.Std.core.iter.adapters.filter_map.IteratorFilterMap.min";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 704 *)
  mk_fun "core::iter::adapters::filter_map::{core::iter::traits::iterator::Iterator<core::iter::adapters::filter_map::FilterMap<@I, @F>, @B>}::next" "_root_.Aeneas.Std.core.iter.adapters.filter_map.IteratorFilterMap.next";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 754 *)
  mk_fun "core::iter::adapters::filter_map::{core::iter::traits::iterator::Iterator<core::iter::adapters::filter_map::FilterMap<@I, @F>, @B>}::size_hint" "_root_.Aeneas.Std.core.iter.adapters.filter_map.IteratorFilterMap.size_hint";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 733 *)
  mk_fun "core::iter::adapters::filter_map::{core::iter::traits::iterator::Iterator<core::iter::adapters::filter_map::FilterMap<@I, @F>, @B>}::try_fold" "_root_.Aeneas.Std.core.iter.adapters.filter_map.IteratorFilterMap.try_fold";
  (* file: "Aeneas/Std/FlatMap.lean", line: 642 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause2_Item, @Clause2_IntoIter>, @Clause2_Item>}::advance_back_by" "_root_.Aeneas.Std.core.iter.adapters.flatten.DoubleEndedIteratorFlatMap.advance_back_by";
  (* file: "Aeneas/Std/FlatMap.lean", line: 597 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause2_Item, @Clause2_IntoIter>, @Clause2_Item>}::next_back" "_root_.Aeneas.Std.core.iter.adapters.flatten.DoubleEndedIteratorFlatMap.next_back";
  (* file: "Aeneas/Std/FlatMap.lean", line: 611 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause2_Item, @Clause2_IntoIter>, @Clause2_Item>}::rfold" "_root_.Aeneas.Std.core.iter.adapters.flatten.DoubleEndedIteratorFlatMap.rfold";
  (* file: "Aeneas/Std/FlatMap.lean", line: 626 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause2_Item, @Clause2_IntoIter>, @Clause2_Item>}::try_rfold" "_root_.Aeneas.Std.core.iter.adapters.flatten.DoubleEndedIteratorFlatMap.try_rfold";
  (* file: "Aeneas/Std/FlatMap.lean", line: 929 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Clause0_Item, @Clause2_Clause0_Item, @U>, @Clause2_Clause0_Item>}::advance_back_by" "_root_.Aeneas.Std.core.iter.adapters.flatten.DoubleEndedIteratorFlatten.advance_back_by";
  (* file: "Aeneas/Std/FlatMap.lean", line: 885 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Clause0_Item, @Clause2_Clause0_Item, @U>, @Clause2_Clause0_Item>}::next_back" "_root_.Aeneas.Std.core.iter.adapters.flatten.DoubleEndedIteratorFlatten.next_back";
  (* file: "Aeneas/Std/FlatMap.lean", line: 898 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Clause0_Item, @Clause2_Clause0_Item, @U>, @Clause2_Clause0_Item>}::rfold" "_root_.Aeneas.Std.core.iter.adapters.flatten.DoubleEndedIteratorFlatten.rfold";
  (* file: "Aeneas/Std/FlatMap.lean", line: 913 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Clause0_Item, @Clause2_Clause0_Item, @U>, @Clause2_Clause0_Item>}::try_rfold" "_root_.Aeneas.Std.core.iter.adapters.flatten.DoubleEndedIteratorFlatten.try_rfold";
  (* file: "Aeneas/Std/FlatMap.lean", line: 475 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause1_Item, @Clause1_IntoIter>, @Clause1_Item>}::advance_by" "_root_.Aeneas.Std.core.iter.adapters.flatten.IteratorFlatMap.advance_by";
  (* file: "Aeneas/Std/FlatMap.lean", line: 460 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause1_Item, @Clause1_IntoIter>, @Clause1_Item>}::any" "_root_.Aeneas.Std.core.iter.adapters.flatten.IteratorFlatMap.any";
  (* file: "Aeneas/Std/FlatMap.lean", line: 440 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause1_Item, @Clause1_IntoIter>, @Clause1_Item>}::count" "_root_.Aeneas.Std.core.iter.adapters.flatten.IteratorFlatMap.count";
  (* file: "Aeneas/Std/FlatMap.lean", line: 413 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause1_Item, @Clause1_IntoIter>, @Clause1_Item>}::fold" "_root_.Aeneas.Std.core.iter.adapters.flatten.IteratorFlatMap.fold";
  (* file: "Aeneas/Std/FlatMap.lean", line: 577 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause1_Item, @Clause1_IntoIter>, @Clause1_Item>}::max" "_root_.Aeneas.Std.core.iter.adapters.flatten.IteratorFlatMap.max";
  (* file: "Aeneas/Std/FlatMap.lean", line: 181 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause1_Item, @Clause1_IntoIter>, @Clause1_Item>}::next" "_root_.Aeneas.Std.core.iter.adapters.flatten.IteratorFlatMap.next";
  (* file: "Aeneas/Std/FlatMap.lean", line: 488 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause1_Item, @Clause1_IntoIter>, @Clause1_Item>}::nth" "_root_.Aeneas.Std.core.iter.adapters.flatten.IteratorFlatMap.nth";
  (* file: "Aeneas/Std/FlatMap.lean", line: 510 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause1_Item, @Clause1_IntoIter>, @Clause1_Item>}::size_hint" "_root_.Aeneas.Std.core.iter.adapters.flatten.IteratorFlatMap.size_hint";
  (* file: "Aeneas/Std/FlatMap.lean", line: 426 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause1_Item, @Clause1_IntoIter>, @Clause1_Item>}::try_fold" "_root_.Aeneas.Std.core.iter.adapters.flatten.IteratorFlatMap.try_fold";
  (* file: "Aeneas/Std/FlatMap.lean", line: 815 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Item, @Clause2_Item, @U>, @Clause2_Item>}::advance_by" "_root_.Aeneas.Std.core.iter.adapters.flatten.IteratorFlatten.advance_by";
  (* file: "Aeneas/Std/FlatMap.lean", line: 844 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Item, @Clause2_Item, @U>, @Clause2_Item>}::any" "_root_.Aeneas.Std.core.iter.adapters.flatten.IteratorFlatten.any";
  (* file: "Aeneas/Std/FlatMap.lean", line: 802 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Item, @Clause2_Item, @U>, @Clause2_Item>}::count" "_root_.Aeneas.Std.core.iter.adapters.flatten.IteratorFlatten.count";
  (* file: "Aeneas/Std/FlatMap.lean", line: 772 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Item, @Clause2_Item, @U>, @Clause2_Item>}::fold" "_root_.Aeneas.Std.core.iter.adapters.flatten.IteratorFlatten.fold";
  (* file: "Aeneas/Std/FlatMap.lean", line: 747 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Item, @Clause2_Item, @U>, @Clause2_Item>}::next" "_root_.Aeneas.Std.core.iter.adapters.flatten.IteratorFlatten.next";
  (* file: "Aeneas/Std/FlatMap.lean", line: 829 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Item, @Clause2_Item, @U>, @Clause2_Item>}::nth" "_root_.Aeneas.Std.core.iter.adapters.flatten.IteratorFlatten.nth";
  (* file: "Aeneas/Std/FlatMap.lean", line: 760 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Item, @Clause2_Item, @U>, @Clause2_Item>}::size_hint" "_root_.Aeneas.Std.core.iter.adapters.flatten.IteratorFlatten.size_hint";
  (* file: "Aeneas/Std/FlatMap.lean", line: 786 *)
  mk_fun "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Item, @Clause2_Item, @U>, @Clause2_Item>}::try_fold" "_root_.Aeneas.Std.core.iter.adapters.flatten.IteratorFlatten.try_fold";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 645 *)
  mk_fun "core::iter::adapters::map::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::map::Map<@I, @F>, @B>}::next_back" "_root_.Aeneas.Std.core.iter.adapters.map.DoubleEndedIteratorMap.next_back";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 659 *)
  mk_fun "core::iter::adapters::map::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::map::Map<@I, @F>, @B>}::rfold" "_root_.Aeneas.Std.core.iter.adapters.map.DoubleEndedIteratorMap.rfold";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 675 *)
  mk_fun "core::iter::adapters::map::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::map::Map<@I, @F>, @B>}::try_rfold" "_root_.Aeneas.Std.core.iter.adapters.map.DoubleEndedIteratorMap.try_rfold";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 534 *)
  mk_fun "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::any" "_root_.Aeneas.Std.core.iter.adapters.map.IteratorMap.any";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 522 *)
  mk_fun "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::count" "_root_.Aeneas.Std.core.iter.adapters.map.IteratorMap.count";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 461 *)
  mk_fun "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::enumerate" "_root_.Aeneas.Std.core.iter.adapters.map.IteratorMap.enumerate";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 628 *)
  mk_fun "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::eq" "_root_.Aeneas.Std.core.iter.adapters.map.IteratorMap.eq";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 480 *)
  mk_fun "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::fold" "_root_.Aeneas.Std.core.iter.adapters.map.IteratorMap.fold";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 606 *)
  mk_fun "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::min" "_root_.Aeneas.Std.core.iter.adapters.map.IteratorMap.min";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 616 *)
  mk_fun "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::ne" "_root_.Aeneas.Std.core.iter.adapters.map.IteratorMap.ne";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 438 *)
  mk_fun "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::next" "_root_.Aeneas.Std.core.iter.adapters.map.IteratorMap.next";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 596 *)
  mk_fun "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::product" "_root_.Aeneas.Std.core.iter.adapters.map.IteratorMap.product";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 574 *)
  mk_fun "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::reduce" "_root_.Aeneas.Std.core.iter.adapters.map.IteratorMap.reduce";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 513 *)
  mk_fun "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::size_hint" "_root_.Aeneas.Std.core.iter.adapters.map.IteratorMap.size_hint";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 452 *)
  mk_fun "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::step_by" "_root_.Aeneas.Std.core.iter.adapters.map.IteratorMap.step_by";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 586 *)
  mk_fun "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::sum" "_root_.Aeneas.Std.core.iter.adapters.map.IteratorMap.sum";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 470 *)
  mk_fun "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::take" "_root_.Aeneas.Std.core.iter.adapters.map.IteratorMap.take";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 496 *)
  mk_fun "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::try_fold" "_root_.Aeneas.Std.core.iter.adapters.map.IteratorMap.try_fold";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 134 *)
  mk_fun "core::iter::adapters::rev::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::advance_back_by" "_root_.Aeneas.Std.core.iter.adapters.rev.DoubleEndedIteratorRev.advance_back_by";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 113 *)
  mk_fun "core::iter::adapters::rev::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::next_back" "_root_.Aeneas.Std.core.iter.adapters.rev.DoubleEndedIteratorRev.next_back";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 124 *)
  mk_fun "core::iter::adapters::rev::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::nth_back" "_root_.Aeneas.Std.core.iter.adapters.rev.DoubleEndedIteratorRev.nth_back";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 167 *)
  mk_fun "core::iter::adapters::rev::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::rfind" "_root_.Aeneas.Std.core.iter.adapters.rev.DoubleEndedIteratorRev.rfind";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 144 *)
  mk_fun "core::iter::adapters::rev::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::rfold" "_root_.Aeneas.Std.core.iter.adapters.rev.DoubleEndedIteratorRev.rfold";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 155 *)
  mk_fun "core::iter::adapters::rev::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::try_rfold" "_root_.Aeneas.Std.core.iter.adapters.rev.DoubleEndedIteratorRev.try_rfold";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 44 *)
  mk_fun "core::iter::adapters::rev::{core::iter::traits::iterator::Iterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::advance_by" "_root_.Aeneas.Std.core.iter.adapters.rev.IteratorRev.advance_by";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 85 *)
  mk_fun "core::iter::adapters::rev::{core::iter::traits::iterator::Iterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::find" "_root_.Aeneas.Std.core.iter.adapters.rev.IteratorRev.find";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 54 *)
  mk_fun "core::iter::adapters::rev::{core::iter::traits::iterator::Iterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::fold" "_root_.Aeneas.Std.core.iter.adapters.rev.IteratorRev.fold";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 24 *)
  mk_fun "core::iter::adapters::rev::{core::iter::traits::iterator::Iterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::next" "_root_.Aeneas.Std.core.iter.adapters.rev.IteratorRev.next";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 34 *)
  mk_fun "core::iter::adapters::rev::{core::iter::traits::iterator::Iterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::nth" "_root_.Aeneas.Std.core.iter.adapters.rev.IteratorRev.nth";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 77 *)
  mk_fun "core::iter::adapters::rev::{core::iter::traits::iterator::Iterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::size_hint" "_root_.Aeneas.Std.core.iter.adapters.rev.IteratorRev.size_hint";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 65 *)
  mk_fun "core::iter::adapters::rev::{core::iter::traits::iterator::Iterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::try_fold" "_root_.Aeneas.Std.core.iter.adapters.rev.IteratorRev.try_fold";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 942 *)
  mk_fun "core::iter::adapters::skip::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Clause0_Item>}::advance_back_by" "_root_.Aeneas.Std.core.iter.adapters.skip.DoubleEndedIteratorSkip.advance_back_by";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 849 *)
  mk_fun "core::iter::adapters::skip::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Clause0_Item>}::next_back" "_root_.Aeneas.Std.core.iter.adapters.skip.DoubleEndedIteratorSkip.next_back";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 864 *)
  mk_fun "core::iter::adapters::skip::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Clause0_Item>}::nth_back" "_root_.Aeneas.Std.core.iter.adapters.skip.DoubleEndedIteratorSkip.nth_back";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 918 *)
  mk_fun "core::iter::adapters::skip::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Clause0_Item>}::rfold" "_root_.Aeneas.Std.core.iter.adapters.skip.DoubleEndedIteratorSkip.rfold";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 883 *)
  mk_fun "core::iter::adapters::skip::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Clause0_Item>}::try_rfold" "_root_.Aeneas.Std.core.iter.adapters.skip.DoubleEndedIteratorSkip.try_rfold";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 683 *)
  mk_fun "core::iter::adapters::skip::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Item>}::advance_by" "_root_.Aeneas.Std.core.iter.adapters.skip.IteratorSkip.advance_by";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 774 *)
  mk_fun "core::iter::adapters::skip::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Item>}::any" "_root_.Aeneas.Std.core.iter.adapters.skip.IteratorSkip.any";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 754 *)
  mk_fun "core::iter::adapters::skip::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Item>}::count" "_root_.Aeneas.Std.core.iter.adapters.skip.IteratorSkip.count";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 784 *)
  mk_fun "core::iter::adapters::skip::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Item>}::enumerate" "_root_.Aeneas.Std.core.iter.adapters.skip.IteratorSkip.enumerate";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 704 *)
  mk_fun "core::iter::adapters::skip::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Item>}::fold" "_root_.Aeneas.Std.core.iter.adapters.skip.IteratorSkip.fold";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 673 *)
  mk_fun "core::iter::adapters::skip::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Item>}::next" "_root_.Aeneas.Std.core.iter.adapters.skip.IteratorSkip.next";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 650 *)
  mk_fun "core::iter::adapters::skip::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Item>}::nth" "_root_.Aeneas.Std.core.iter.adapters.skip.IteratorSkip.nth";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 746 *)
  mk_fun "core::iter::adapters::skip::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Item>}::size_hint" "_root_.Aeneas.Std.core.iter.adapters.skip.IteratorSkip.size_hint";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 723 *)
  mk_fun "core::iter::adapters::skip::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Item>}::try_fold" "_root_.Aeneas.Std.core.iter.adapters.skip.IteratorSkip.try_fold";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 1266 *)
  mk_fun "core::iter::adapters::skip_while::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip_while::SkipWhile<@I, @P>, @Clause0_Item>}::fold" "_root_.Aeneas.Std.core.iter.adapters.skip_while.IteratorSkipWhile.fold";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 1242 *)
  mk_fun "core::iter::adapters::skip_while::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip_while::SkipWhile<@I, @P>, @Clause0_Item>}::next" "_root_.Aeneas.Std.core.iter.adapters.skip_while.IteratorSkipWhile.next";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 1257 *)
  mk_fun "core::iter::adapters::skip_while::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip_while::SkipWhile<@I, @P>, @Clause0_Item>}::size_hint" "_root_.Aeneas.Std.core.iter.adapters.skip_while.IteratorSkipWhile.size_hint";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 1286 *)
  mk_fun "core::iter::adapters::skip_while::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip_while::SkipWhile<@I, @P>, @Clause0_Item>}::try_fold" "_root_.Aeneas.Std.core.iter.adapters.skip_while.IteratorSkipWhile.try_fold";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1816 *)
  mk_fun "core::iter::adapters::step_by::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Clause0_Item>}::next_back" "_root_.Aeneas.Std.core.iter.adapters.step_by.DoubleEndedIteratorStepBy.next_back";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1830 *)
  mk_fun "core::iter::adapters::step_by::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Clause0_Item>}::nth_back" "_root_.Aeneas.Std.core.iter.adapters.step_by.DoubleEndedIteratorStepBy.nth_back";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1865 *)
  mk_fun "core::iter::adapters::step_by::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Clause0_Item>}::rfold" "_root_.Aeneas.Std.core.iter.adapters.step_by.DoubleEndedIteratorStepBy.rfold";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1877 *)
  mk_fun "core::iter::adapters::step_by::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Clause0_Item>}::try_rfold" "_root_.Aeneas.Std.core.iter.adapters.step_by.DoubleEndedIteratorStepBy.try_rfold";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 599 *)
  mk_fun "core::iter::adapters::step_by::{core::iter::traits::iterator::Iterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Item>}::enumerate" "_root_.Aeneas.Std.core.iter.adapters.step_by.IteratorStepBy.enumerate";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 701 *)
  mk_fun "core::iter::adapters::step_by::{core::iter::traits::iterator::Iterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Item>}::fold" "_root_.Aeneas.Std.core.iter.adapters.step_by.IteratorStepBy.fold";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 573 *)
  mk_fun "core::iter::adapters::step_by::{core::iter::traits::iterator::Iterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Item>}::next" "_root_.Aeneas.Std.core.iter.adapters.step_by.IteratorStepBy.next";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 637 *)
  mk_fun "core::iter::adapters::step_by::{core::iter::traits::iterator::Iterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Item>}::nth" "_root_.Aeneas.Std.core.iter.adapters.step_by.IteratorStepBy.nth";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 666 *)
  mk_fun "core::iter::adapters::step_by::{core::iter::traits::iterator::Iterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Item>}::size_hint" "_root_.Aeneas.Std.core.iter.adapters.step_by.IteratorStepBy.size_hint";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 588 *)
  mk_fun "core::iter::adapters::step_by::{core::iter::traits::iterator::Iterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Item>}::step_by" "_root_.Aeneas.Std.core.iter.adapters.step_by.IteratorStepBy.step_by";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 608 *)
  mk_fun "core::iter::adapters::step_by::{core::iter::traits::iterator::Iterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Item>}::take" "_root_.Aeneas.Std.core.iter.adapters.step_by.IteratorStepBy.take";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 714 *)
  mk_fun "core::iter::adapters::step_by::{core::iter::traits::iterator::Iterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Item>}::try_fold" "_root_.Aeneas.Std.core.iter.adapters.step_by.IteratorStepBy.try_fold";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1766 *)
  mk_fun "core::iter::adapters::take::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::take::Take<@I>, @Clause0_Clause0_Item>}::advance_back_by" "_root_.Aeneas.Std.core.iter.adapters.take.DoubleEndedIteratorTake.advance_back_by";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1693 *)
  mk_fun "core::iter::adapters::take::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::take::Take<@I>, @Clause0_Clause0_Item>}::next_back" "_root_.Aeneas.Std.core.iter.adapters.take.DoubleEndedIteratorTake.next_back";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1707 *)
  mk_fun "core::iter::adapters::take::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::take::Take<@I>, @Clause0_Clause0_Item>}::nth_back" "_root_.Aeneas.Std.core.iter.adapters.take.DoubleEndedIteratorTake.nth_back";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1753 *)
  mk_fun "core::iter::adapters::take::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::take::Take<@I>, @Clause0_Clause0_Item>}::rfold" "_root_.Aeneas.Std.core.iter.adapters.take.DoubleEndedIteratorTake.rfold";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1739 *)
  mk_fun "core::iter::adapters::take::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::take::Take<@I>, @Clause0_Clause0_Item>}::try_rfold" "_root_.Aeneas.Std.core.iter.adapters.take.DoubleEndedIteratorTake.try_rfold";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1586 *)
  mk_fun "core::iter::adapters::take::{core::iter::traits::iterator::Iterator<core::iter::adapters::take::Take<@I>, @Clause0_Item>}::advance_by" "_root_.Aeneas.Std.core.iter.adapters.take.IteratorTake.advance_by";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1657 *)
  mk_fun "core::iter::adapters::take::{core::iter::traits::iterator::Iterator<core::iter::adapters::take::Take<@I>, @Clause0_Item>}::fold" "_root_.Aeneas.Std.core.iter.adapters.take.IteratorTake.fold";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1560 *)
  mk_fun "core::iter::adapters::take::{core::iter::traits::iterator::Iterator<core::iter::adapters::take::Take<@I>, @Clause0_Item>}::next" "_root_.Aeneas.Std.core.iter.adapters.take.IteratorTake.next";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1571 *)
  mk_fun "core::iter::adapters::take::{core::iter::traits::iterator::Iterator<core::iter::adapters::take::Take<@I>, @Clause0_Item>}::nth" "_root_.Aeneas.Std.core.iter.adapters.take.IteratorTake.nth";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1601 *)
  mk_fun "core::iter::adapters::take::{core::iter::traits::iterator::Iterator<core::iter::adapters::take::Take<@I>, @Clause0_Item>}::size_hint" "_root_.Aeneas.Std.core.iter.adapters.take.IteratorTake.size_hint";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1614 *)
  mk_fun "core::iter::adapters::take::{core::iter::traits::iterator::Iterator<core::iter::adapters::take::Take<@I>, @Clause0_Item>}::try_fold" "_root_.Aeneas.Std.core.iter.adapters.take.IteratorTake.try_fold";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 593 *)
  mk_fun "core::iter::adapters::zip::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::zip::Zip<@A, @B>, (@Clause0_Clause0_Item, @Clause2_Clause0_Item)>}::next_back" "_root_.Aeneas.Std.core.iter.adapters.zip.DoubleEndedIteratorZip.next_back";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 500 *)
  mk_fun "core::iter::adapters::zip::{core::iter::traits::iterator::Iterator<core::iter::adapters::zip::Zip<@A, @B>, (@Clause0_Item, @Clause1_Item)>}::any" "_root_.Aeneas.Std.core.iter.adapters.zip.IteratorZip.any";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 489 *)
  mk_fun "core::iter::adapters::zip::{core::iter::traits::iterator::Iterator<core::iter::adapters::zip::Zip<@A, @B>, (@Clause0_Item, @Clause1_Item)>}::count" "_root_.Aeneas.Std.core.iter.adapters.zip.IteratorZip.count";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 512 *)
  mk_fun "core::iter::adapters::zip::{core::iter::traits::iterator::Iterator<core::iter::adapters::zip::Zip<@A, @B>, (@Clause0_Item, @Clause1_Item)>}::enumerate" "_root_.Aeneas.Std.core.iter.adapters.zip.IteratorZip.enumerate";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 455 *)
  mk_fun "core::iter::adapters::zip::{core::iter::traits::iterator::Iterator<core::iter::adapters::zip::Zip<@A, @B>, (@Clause0_Item, @Clause1_Item)>}::fold" "_root_.Aeneas.Std.core.iter.adapters.zip.IteratorZip.fold";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 321 *)
  mk_fun "core::iter::adapters::zip::{core::iter::traits::iterator::Iterator<core::iter::adapters::zip::Zip<@A, @B>, (@Clause0_Item, @Clause1_Item)>}::next" "_root_.Aeneas.Std.core.iter.adapters.zip.IteratorZip.next";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 362 *)
  mk_fun "core::iter::adapters::zip::{core::iter::traits::iterator::Iterator<core::iter::adapters::zip::Zip<@A, @B>, (@Clause0_Item, @Clause1_Item)>}::nth" "_root_.Aeneas.Std.core.iter.adapters.zip.IteratorZip.nth";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 384 *)
  mk_fun "core::iter::adapters::zip::{core::iter::traits::iterator::Iterator<core::iter::adapters::zip::Zip<@A, @B>, (@Clause0_Item, @Clause1_Item)>}::size_hint" "_root_.Aeneas.Std.core.iter.adapters.zip.IteratorZip.size_hint";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 475 *)
  mk_fun "core::iter::adapters::zip::{core::iter::traits::iterator::Iterator<core::iter::adapters::zip::Zip<@A, @B>, (@Clause0_Item, @Clause1_Item)>}::try_fold" "_root_.Aeneas.Std.core.iter.adapters.zip.IteratorZip.try_fold";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1216 *)
  mk_fun "core::iter::range::{core::iter::range::Step<i32>}::backward_checked" "_root_.Aeneas.Std.core.iter.range.StepI32.backward_checked";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1208 *)
  mk_fun "core::iter::range::{core::iter::range::Step<i32>}::forward_checked" "_root_.Aeneas.Std.core.iter.range.StepI32.forward_checked";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1199 *)
  mk_fun "core::iter::range::{core::iter::range::Step<i32>}::steps_between" "_root_.Aeneas.Std.core.iter.range.StepI32.steps_between";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1281 *)
  mk_fun "core::iter::range::{core::iter::range::Step<u32>}::backward_checked" "_root_.Aeneas.Std.core.iter.range.StepU32.backward_checked";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1273 *)
  mk_fun "core::iter::range::{core::iter::range::Step<u32>}::forward_checked" "_root_.Aeneas.Std.core.iter.range.StepU32.forward_checked";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1262 *)
  mk_fun "core::iter::range::{core::iter::range::Step<u32>}::steps_between" "_root_.Aeneas.Std.core.iter.range.StepU32.steps_between";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1254 *)
  mk_fun "core::iter::range::{core::iter::range::Step<usize>}::backward_checked" "_root_.Aeneas.Std.core.iter.range.StepUsize.backward_checked";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1248 *)
  mk_fun "core::iter::range::{core::iter::range::Step<usize>}::forward_checked" "_root_.Aeneas.Std.core.iter.range.StepUsize.forward_checked";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1239 *)
  mk_fun "core::iter::range::{core::iter::range::Step<usize>}::steps_between" "_root_.Aeneas.Std.core.iter.range.StepUsize.steps_between";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1457 *)
  mk_fun "core::iter::range::{core::iter::traits::double_ended::DoubleEndedIterator<core::ops::range::Range<@A>, @A>}::advance_back_by" "_root_.Aeneas.Std.core.iter.range.DoubleEndedIteratorRange.advance_back_by";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1429 *)
  mk_fun "core::iter::range::{core::iter::traits::double_ended::DoubleEndedIterator<core::ops::range::Range<@A>, @A>}::next_back" "_root_.Aeneas.Std.core.iter.range.DoubleEndedIteratorRange.next_back";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1442 *)
  mk_fun "core::iter::range::{core::iter::traits::double_ended::DoubleEndedIterator<core::ops::range::Range<@A>, @A>}::nth_back" "_root_.Aeneas.Std.core.iter.range.DoubleEndedIteratorRange.nth_back";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1414 *)
  mk_fun "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::Range<@A>, @A>}::advance_by" "_root_.Aeneas.Std.core.iter.range.IteratorRange.advance_by";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1388 *)
  mk_fun "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::Range<@A>, @A>}::count" "_root_.Aeneas.Std.core.iter.range.IteratorRange.count";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1366 *)
  mk_fun "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::Range<@A>, @A>}::enumerate" "_root_.Aeneas.Std.core.iter.range.IteratorRange.enumerate";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1338 *)
  mk_fun "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::Range<@A>, @A>}::next" "_root_.Aeneas.Std.core.iter.range.IteratorRange.next";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1397 *)
  mk_fun "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::Range<@A>, @A>}::nth" "_root_.Aeneas.Std.core.iter.range.IteratorRange.nth";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1380 *)
  mk_fun "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::Range<@A>, @A>}::size_hint" "_root_.Aeneas.Std.core.iter.range.IteratorRange.size_hint";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1353 *)
  mk_fun "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::Range<@A>, @A>}::step_by" "_root_.Aeneas.Std.core.iter.range.IteratorRange.step_by";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1373 *)
  mk_fun "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::Range<@A>, @A>}::take" "_root_.Aeneas.Std.core.iter.range.IteratorRange.take";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1493 *)
  mk_fun "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeFrom<@A>, @A>}::next" "_root_.Aeneas.Std.core.iter.range.IteratorRangeFrom.next";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1510 *)
  mk_fun "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeFrom<@A>, @A>}::nth" "_root_.Aeneas.Std.core.iter.range.IteratorRangeFrom.nth";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1502 *)
  mk_fun "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeFrom<@A>, @A>}::size_hint" "_root_.Aeneas.Std.core.iter.range.IteratorRangeFrom.size_hint";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1536 *)
  mk_fun "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeFrom<@A>, @A>}::try_for_each" "_root_.Aeneas.Std.core.iter.range.IteratorRangeFrom.try_for_each";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 270 *)
  mk_fun "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeInclusive<@A>, @A>}::advance_by" "_root_.Aeneas.Std.core.iter.range.IteratorRangeInclusive.advance_by";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 140 *)
  mk_fun "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeInclusive<@A>, @A>}::any" "_root_.Aeneas.Std.core.iter.range.IteratorRangeInclusive.any";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 75 *)
  mk_fun "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeInclusive<@A>, @A>}::count" "_root_.Aeneas.Std.core.iter.range.IteratorRangeInclusive.count";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 150 *)
  mk_fun "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeInclusive<@A>, @A>}::enumerate" "_root_.Aeneas.Std.core.iter.range.IteratorRangeInclusive.enumerate";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 193 *)
  mk_fun "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeInclusive<@A>, @A>}::fold" "_root_.Aeneas.Std.core.iter.range.IteratorRangeInclusive.fold";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 55 *)
  mk_fun "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeInclusive<@A>, @A>}::next" "_root_.Aeneas.Std.core.iter.range.IteratorRangeInclusive.next";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 91 *)
  mk_fun "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeInclusive<@A>, @A>}::nth" "_root_.Aeneas.Std.core.iter.range.IteratorRangeInclusive.nth";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 158 *)
  mk_fun "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeInclusive<@A>, @A>}::size_hint" "_root_.Aeneas.Std.core.iter.range.IteratorRangeInclusive.size_hint";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 240 *)
  mk_fun "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeInclusive<@A>, @A>}::try_fold" "_root_.Aeneas.Std.core.iter.range.IteratorRangeInclusive.try_fold";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 451 *)
  mk_fun "core::iter::sources::empty::empty" "_root_.Aeneas.Std.core.iter.sources.empty.empty";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 457 *)
  mk_fun "core::iter::sources::empty::{core::iter::traits::iterator::Iterator<core::iter::sources::empty::Empty<@T>, @T>}::next" "_root_.Aeneas.Std.core.iter.sources.empty.IteratorEmpty.next";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 463 *)
  mk_fun "core::iter::sources::empty::{core::iter::traits::iterator::Iterator<core::iter::sources::empty::Empty<@T>, @T>}::size_hint" "_root_.Aeneas.Std.core.iter.sources.empty.IteratorEmpty.size_hint";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 284 *)
  mk_fun "core::iter::sources::once::once" "_root_.Aeneas.Std.core.iter.sources.once.once";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 371 *)
  mk_fun "core::iter::sources::once::{core::iter::traits::iterator::Iterator<core::iter::sources::once::Once<@T>, @T>}::advance_by" "_root_.Aeneas.Std.core.iter.sources.once.IteratorOnce.advance_by";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 310 *)
  mk_fun "core::iter::sources::once::{core::iter::traits::iterator::Iterator<core::iter::sources::once::Once<@T>, @T>}::any" "_root_.Aeneas.Std.core.iter.sources.once.IteratorOnce.any";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 296 *)
  mk_fun "core::iter::sources::once::{core::iter::traits::iterator::Iterator<core::iter::sources::once::Once<@T>, @T>}::count" "_root_.Aeneas.Std.core.iter.sources.once.IteratorOnce.count";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 322 *)
  mk_fun "core::iter::sources::once::{core::iter::traits::iterator::Iterator<core::iter::sources::once::Once<@T>, @T>}::enumerate" "_root_.Aeneas.Std.core.iter.sources.once.IteratorOnce.enumerate";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 336 *)
  mk_fun "core::iter::sources::once::{core::iter::traits::iterator::Iterator<core::iter::sources::once::Once<@T>, @T>}::fold" "_root_.Aeneas.Std.core.iter.sources.once.IteratorOnce.fold";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 289 *)
  mk_fun "core::iter::sources::once::{core::iter::traits::iterator::Iterator<core::iter::sources::once::Once<@T>, @T>}::next" "_root_.Aeneas.Std.core.iter.sources.once.IteratorOnce.next";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 303 *)
  mk_fun "core::iter::sources::once::{core::iter::traits::iterator::Iterator<core::iter::sources::once::Once<@T>, @T>}::nth" "_root_.Aeneas.Std.core.iter.sources.once.IteratorOnce.nth";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 329 *)
  mk_fun "core::iter::sources::once::{core::iter::traits::iterator::Iterator<core::iter::sources::once::Once<@T>, @T>}::size_hint" "_root_.Aeneas.Std.core.iter.sources.once.IteratorOnce.size_hint";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 344 *)
  mk_fun "core::iter::sources::once::{core::iter::traits::iterator::Iterator<core::iter::sources::once::Once<@T>, @T>}::try_fold" "_root_.Aeneas.Std.core.iter.sources.once.IteratorOnce.try_fold";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 396 *)
  mk_fun "core::iter::sources::repeat_with::repeat_with" "_root_.Aeneas.Std.core.iter.sources.repeat_with.repeat_with";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 407 *)
  mk_fun "core::iter::sources::repeat_with::{core::iter::traits::iterator::Iterator<core::iter::sources::repeat_with::RepeatWith<@F>, @A>}::next" "_root_.Aeneas.Std.core.iter.sources.repeat_with.IteratorRepeatWith.next";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 416 *)
  mk_fun "core::iter::sources::repeat_with::{core::iter::traits::iterator::Iterator<core::iter::sources::repeat_with::RepeatWith<@F>, @A>}::size_hint" "_root_.Aeneas.Std.core.iter.sources.repeat_with.IteratorRepeatWith.size_hint";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 423 *)
  mk_fun "core::iter::sources::repeat_with::{core::iter::traits::iterator::Iterator<core::iter::sources::repeat_with::RepeatWith<@F>, @A>}::try_fold" "_root_.Aeneas.Std.core.iter.sources.repeat_with.IteratorRepeatWith.try_fold";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 888 *)
  mk_fun "core::iter::traits::accum::{core::iter::traits::accum::Product<usize, &'a usize>}::product" "_root_.Aeneas.Std.core.iter.traits.accum.ProductUsizeSharedUsize.product";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 907 *)
  mk_fun "core::iter::traits::accum::{core::iter::traits::accum::Product<usize, usize>}::product" "_root_.Aeneas.Std.core.iter.traits.accum.ProductUsizeUsize.product";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 955 *)
  mk_fun "core::iter::traits::accum::{core::iter::traits::accum::Sum<usize, &'a usize>}::sum" "_root_.Aeneas.Std.core.iter.traits.accum.SumUsizeSharedUsize.sum";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 936 *)
  mk_fun "core::iter::traits::accum::{core::iter::traits::accum::Sum<usize, usize>}::sum" "_root_.Aeneas.Std.core.iter.traits.accum.SumUsizeUsize.sum";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 987 *)
  mk_fun "core::iter::traits::collect::{core::iter::traits::collect::IntoIterator<@I, @Item, @I>}::into_iter" "_root_.Aeneas.Std.core.iter.traits.collect.IntoIterator.Blanket.into_iter";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 57 *)
  mk_fun "core::iter::traits::iterator::Iterator::chain" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator.chain.default";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 818 *)
  mk_fun "core::iter::traits::iterator::Iterator::cloned" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator.cloned.default";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1008 *)
  mk_fun "core::iter::traits::iterator::Iterator::collect" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator.collect.default";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 809 *)
  mk_fun "core::iter::traits::iterator::Iterator::copied" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator.copied.default";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1054 *)
  mk_fun "core::iter::traits::iterator::Iterator::eq" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator.eq.default";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 1037 *)
  mk_fun "core::iter::traits::iterator::Iterator::filter" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator.filter.default";
  (* file: "Aeneas/Std/FlatMap.lean", line: 169 *)
  mk_fun "core::iter::traits::iterator::Iterator::flat_map" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator.flat_map.default";
  (* file: "Aeneas/Std/FlatMap.lean", line: 737 *)
  mk_fun "core::iter::traits::iterator::Iterator::flatten" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator.flatten.default";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 804 *)
  mk_fun "core::iter::traits::iterator::Iterator::for_each" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator.for_each.default";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 430 *)
  mk_fun "core::iter::traits::iterator::Iterator::map" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator.map.default";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 767 *)
  mk_fun "core::iter::traits::iterator::Iterator::max" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator.max.default";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 866 *)
  mk_fun "core::iter::traits::iterator::Iterator::min" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator.min.default";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 841 *)
  mk_fun "core::iter::traits::iterator::Iterator::min_by_key" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator.min_by_key.default";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1074 *)
  mk_fun "core::iter::traits::iterator::Iterator::ne" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator.ne.default";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 756 *)
  mk_fun "core::iter::traits::iterator::Iterator::product" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator.product.default";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 788 *)
  mk_fun "core::iter::traits::iterator::Iterator::reduce" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator.reduce.default";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 16 *)
  mk_fun "core::iter::traits::iterator::Iterator::rev" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator.rev.default";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1175 *)
  mk_fun "core::iter::traits::iterator::Iterator::rposition" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator.rposition.default" ~keep_params:(Some [true; true; true; false; false]);
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 87 *)
  mk_fun "core::iter::traits::iterator::Iterator::skip" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator.skip.default";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 1223 *)
  mk_fun "core::iter::traits::iterator::Iterator::skip_while" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator.skip_while.default";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 926 *)
  mk_fun "core::iter::traits::iterator::Iterator::sum" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator.sum.default";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 818 *)
  mk_fun "core::iter::traits::iterator::Iterator::try_for_each" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator.try_for_each.default";
  (* file: "Aeneas/Std/VecIter.lean", line: 304 *)
  mk_fun "core::iter::traits::iterator::Iterator::unzip" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator.unzip.default";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 69 *)
  mk_fun "core::iter::traits::iterator::Iterator::zip" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator.zip.default";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 417 *)
  mk_fun "core::iter::traits::iterator::{core::iter::traits::iterator::Iterator<&'a mut @I, @Item>}::advance_by" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorMut.advance_by";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 434 *)
  mk_fun "core::iter::traits::iterator::{core::iter::traits::iterator::Iterator<&'a mut @I, @Item>}::fold" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorMut.fold";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 403 *)
  mk_fun "core::iter::traits::iterator::{core::iter::traits::iterator::Iterator<&'a mut @I, @Item>}::next" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorMut.next";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 425 *)
  mk_fun "core::iter::traits::iterator::{core::iter::traits::iterator::Iterator<&'a mut @I, @Item>}::nth" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorMut.nth";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 410 *)
  mk_fun "core::iter::traits::iterator::{core::iter::traits::iterator::Iterator<&'a mut @I, @Item>}::size_hint" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorMut.size_hint";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 455 *)
  mk_fun "core::iter::traits::iterator::{core::iter::traits::iterator::Iterator<&'a mut @I, @Item>}::try_fold" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorMut.try_fold";
  (* file: "Aeneas/Std/Core/Discriminant.lean", line: 100 *)
  mk_fun "core::mem::discriminant" "_root_.Aeneas.Std.core.mem.discriminant";
  (* file: "Aeneas/Std/Core/Core.lean", line: 162 *)
  mk_fun "core::mem::replace" "_root_.Aeneas.Std.core.mem.replace" ~can_fail:false ~lift:false;
  (* file: "Aeneas/Std/Core/Core.lean", line: 166 *)
  mk_fun "core::mem::swap" "_root_.Aeneas.Std.core.mem.swap" ~can_fail:false ~lift:false;
  (* file: "Aeneas/Std/Core/Default.lean", line: 34 *)
  mk_fun "core::mem::take" "_root_.Aeneas.Std.core.mem.take";
  (* file: "Aeneas/Std/Core/Discriminant.lean", line: 107 *)
  mk_fun "core::mem::{core::cmp::PartialEq<core::mem::Discriminant<@T>, core::mem::Discriminant<@T>>}::eq" "_root_.Aeneas.Std.core.mem.PartialEqDiscriminant.eq";
  (* file: "Aeneas/Std/Core/Discriminant.lean", line: 119 *)
  mk_fun "core::mem::{core::fmt::Debug<core::mem::Discriminant<@T>>}::fmt" "_root_.Aeneas.Std.core.mem.DebugDiscriminant.fmt";
  (* file: "Aeneas/Std/Parse.lean", line: 324 *)
  mk_fun "core::num::dec2flt::{core::fmt::Debug<core::num::dec2flt::ParseFloatError>}::fmt" "_root_.Aeneas.Std.core.num.dec2flt.DebugParseFloatError.fmt";
  (* file: "Aeneas/Std/Parse.lean", line: 306 *)
  mk_fun "core::num::dec2flt::{core::fmt::Display<core::num::dec2flt::ParseFloatError>}::fmt" "_root_.Aeneas.Std.core.num.dec2flt.DisplayParseFloatError.fmt";
  (* file: "Aeneas/Std/Parse.lean", line: 294 *)
  mk_fun "core::num::dec2flt::{core::str::traits::FromStr<f32, core::num::dec2flt::ParseFloatError>}::from_str" "_root_.Aeneas.Std.core.num.dec2flt.FromStrF32.from_str";
  (* file: "Aeneas/Std/Parse.lean", line: 283 *)
  mk_fun "core::num::dec2flt::{core::str::traits::FromStr<f64, core::num::dec2flt::ParseFloatError>}::from_str" "_root_.Aeneas.Std.core.num.dec2flt.FromStrF64.from_str";
  (* file: "Aeneas/Std/Core/Convert.lean", line: 12 *)
  mk_fun "core::num::error::{core::cmp::PartialEq<core::num::error::TryFromIntError, core::num::error::TryFromIntError>}::eq" "_root_.Aeneas.Std.core.num.error.PartialEqTryFromIntError.eq";
  (* file: "Aeneas/Std/Parse.lean", line: 158 *)
  mk_fun "core::num::error::{core::fmt::Debug<core::num::error::IntErrorKind>}::fmt" "_root_.Aeneas.Std.core.num.error.DebugIntErrorKind.fmt";
  (* file: "Aeneas/Std/Parse.lean", line: 171 *)
  mk_fun "core::num::error::{core::fmt::Debug<core::num::error::ParseIntError>}::fmt" "_root_.Aeneas.Std.core.num.error.DebugParseIntError.fmt";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 191 *)
  mk_fun "core::num::error::{core::fmt::Debug<core::num::error::TryFromIntError>}::fmt" "_root_.Aeneas.Std.core.fmt.DebugTryFromIntError.fmt";
  (* file: "Aeneas/Std/Parse.lean", line: 335 *)
  mk_fun "core::num::error::{core::fmt::Display<core::num::error::ParseIntError>}::fmt" "_root_.Aeneas.Std.core.num.error.DisplayParseIntError.fmt";
  (* file: "Aeneas/Std/Parse.lean", line: 152 *)
  mk_fun "core::num::error::{core::num::error::ParseIntError}::kind" "_root_.Aeneas.Std.core.num.error.ParseIntError.kind'";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 436 *)
  mk_fun "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroCharInner>}::clone" "_root_.Aeneas.Std.core.clone.CloneNonZeroCharInner.clone";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 380 *)
  mk_fun "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroI128Inner>}::clone" "_root_.Aeneas.Std.core.clone.CloneNonZeroI128Inner.clone";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 296 *)
  mk_fun "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroI16Inner>}::clone" "_root_.Aeneas.Std.core.clone.CloneNonZeroI16Inner.clone";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 324 *)
  mk_fun "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroI32Inner>}::clone" "_root_.Aeneas.Std.core.clone.CloneNonZeroI32Inner.clone";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 352 *)
  mk_fun "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroI64Inner>}::clone" "_root_.Aeneas.Std.core.clone.CloneNonZeroI64Inner.clone";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 268 *)
  mk_fun "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroI8Inner>}::clone" "_root_.Aeneas.Std.core.clone.CloneNonZeroI8Inner.clone";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 408 *)
  mk_fun "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroIsizeInner>}::clone" "_root_.Aeneas.Std.core.clone.CloneNonZeroIsizeInner.clone";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 212 *)
  mk_fun "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroU128Inner>}::clone" "_root_.Aeneas.Std.core.clone.CloneNonZeroU128Inner.clone";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 128 *)
  mk_fun "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroU16Inner>}::clone" "_root_.Aeneas.Std.core.clone.CloneNonZeroU16Inner.clone";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 156 *)
  mk_fun "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroU32Inner>}::clone" "_root_.Aeneas.Std.core.clone.CloneNonZeroU32Inner.clone";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 184 *)
  mk_fun "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroU64Inner>}::clone" "_root_.Aeneas.Std.core.clone.CloneNonZeroU64Inner.clone";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 100 *)
  mk_fun "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroU8Inner>}::clone" "_root_.Aeneas.Std.core.clone.CloneNonZeroU8Inner.clone";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 240 *)
  mk_fun "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroUsizeInner>}::clone" "_root_.Aeneas.Std.core.clone.CloneNonZeroUsizeInner.clone";
  (* file: "Aeneas/Std/Core/NonZeroTraits.lean", line: 14 *)
  mk_fun "core::num::nonzero::{core::cmp::PartialEq<core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>, core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>>}::eq" "_root_.Aeneas.Std.core.num.nonzero.PartialEqNonZero.eq" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false; true]);
  (* file: "Aeneas/Std/Core/NonZeroTraits.lean", line: 21 *)
  mk_fun "core::num::nonzero::{core::cmp::PartialEq<core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>, core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>>}::ne" "_root_.Aeneas.Std.core.num.nonzero.PartialEqNonZero.ne" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false; true]);
  (* file: "Aeneas/Std/Core/NonZeroTraits.lean", line: 56 *)
  mk_fun "core::num::nonzero::{core::fmt::Debug<core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>>}::fmt" "_root_.Aeneas.Std.core.num.nonzero.DebugNonZero.fmt" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false; true]);
  (* file: "Aeneas/Std/Core/NonZeroTraits.lean", line: 38 *)
  mk_fun "core::num::nonzero::{core::hash::Hash<core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>>}::hash" "_root_.Aeneas.Std.core.num.nonzero.HashNonZero.hash" ~keep_params:(Some [true; false; true]) ~keep_trait_clauses:(Some [false; true; true]);
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 497 *)
  mk_fun "core::num::nonzero::{core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>}::get" "_root_.Aeneas.Std.core.num.nonzero.NonZero.getGeneric" ~keep_params:(Some [true; true]) ~keep_trait_clauses:(Some [true]);
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 477 *)
  mk_fun "core::num::nonzero::{core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>}::new" "_root_.Aeneas.Std.core.num.nonzero.NonZero.newGeneric" ~keep_params:(Some [true; true]) ~keep_trait_clauses:(Some [true]);
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 487 *)
  mk_fun "core::num::nonzero::{core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>}::new_unchecked" "_root_.Aeneas.Std.core.num.nonzero.NonZero.newUncheckedGeneric" ~keep_params:(Some [true; true]) ~keep_trait_clauses:(Some [true]);
  (* file: "Aeneas/Std/Parse.lean", line: 119 *)
  mk_fun "core::num::{core::str::traits::FromStr<i32, core::num::error::ParseIntError>}::from_str" "_root_.Aeneas.Std.core.num.FromStrI32.from_str";
  (* file: "Aeneas/Std/Parse.lean", line: 130 *)
  mk_fun "core::num::{core::str::traits::FromStr<i64, core::num::error::ParseIntError>}::from_str" "_root_.Aeneas.Std.core.num.FromStrI64.from_str";
  (* file: "Aeneas/Std/Parse.lean", line: 108 *)
  mk_fun "core::num::{core::str::traits::FromStr<u64, core::num::error::ParseIntError>}::from_str" "_root_.Aeneas.Std.core.num.FromStrU64.from_str";
  (* file: "Aeneas/Std/Parse.lean", line: 97 *)
  mk_fun "core::num::{core::str::traits::FromStr<usize, core::num::error::ParseIntError>}::from_str" "_root_.Aeneas.Std.core.num.FromStrUsize.from_str";
  (* file: "Aeneas/Std/Scalar/CheckedOps/Neg.lean", line: 34 *)
  mk_fun "core::num::{i16}::checked_abs" "_root_.Aeneas.Std.core.num.I16.checked_abs" ~can_fail:false;
  (* file: "Aeneas/Std/Scalar/CheckedOps/Neg.lean", line: 25 *)
  mk_fun "core::num::{i16}::checked_neg" "_root_.Aeneas.Std.core.num.I16.checked_neg" ~can_fail:false;
  (* file: "Aeneas/Std/Scalar/CheckedOps/Neg.lean", line: 36 *)
  mk_fun "core::num::{i32}::checked_abs" "_root_.Aeneas.Std.core.num.I32.checked_abs" ~can_fail:false;
  (* file: "Aeneas/Std/Scalar/CheckedOps/Neg.lean", line: 27 *)
  mk_fun "core::num::{i32}::checked_neg" "_root_.Aeneas.Std.core.num.I32.checked_neg" ~can_fail:false;
  (* file: "Aeneas/Std/Scalar/CheckedOps/Neg.lean", line: 38 *)
  mk_fun "core::num::{i64}::checked_abs" "_root_.Aeneas.Std.core.num.I64.checked_abs" ~can_fail:false;
  (* file: "Aeneas/Std/Scalar/CheckedOps/Neg.lean", line: 29 *)
  mk_fun "core::num::{i64}::checked_neg" "_root_.Aeneas.Std.core.num.I64.checked_neg" ~can_fail:false;
  (* file: "Aeneas/Std/Parse.lean", line: 142 *)
  mk_fun "core::num::{i64}::from_str_radix" "_root_.Aeneas.Std.core.num.I64.from_str_radix";
  (* file: "Aeneas/Std/Scalar/Misc.lean", line: 15 *)
  mk_fun "core::num::{i64}::is_negative" "_root_.Aeneas.Std.core.num.I64.is_negative" ~can_fail:false;
  (* file: "Aeneas/Std/Scalar/Misc.lean", line: 19 *)
  mk_fun "core::num::{i64}::unsigned_abs" "_root_.Aeneas.Std.core.num.I64.unsigned_abs" ~can_fail:false;
  (* file: "Aeneas/Std/Scalar/CheckedOps/Neg.lean", line: 32 *)
  mk_fun "core::num::{i8}::checked_abs" "_root_.Aeneas.Std.core.num.I8.checked_abs" ~can_fail:false;
  (* file: "Aeneas/Std/Scalar/CheckedOps/Neg.lean", line: 23 *)
  mk_fun "core::num::{i8}::checked_neg" "_root_.Aeneas.Std.core.num.I8.checked_neg" ~can_fail:false;
  (* file: "Aeneas/Std/Scalar/Pow.lean", line: 35 *)
  mk_fun "core::num::{u128}::pow" "_root_.Aeneas.Std.core.num.U128.pow";
  (* file: "Aeneas/Std/Scalar/Pow.lean", line: 29 *)
  mk_fun "core::num::{u16}::pow" "_root_.Aeneas.Std.core.num.U16.pow";
  (* file: "Aeneas/Std/Scalar/Misc.lean", line: 28 *)
  mk_fun "core::num::{u32}::abs_diff" "_root_.Aeneas.Std.core.num.U32.abs_diff" ~can_fail:false;
  (* file: "Aeneas/Std/Scalar/Pow.lean", line: 31 *)
  mk_fun "core::num::{u32}::pow" "_root_.Aeneas.Std.core.num.U32.pow";
  (* file: "Aeneas/Std/Scalar/Misc.lean", line: 31 *)
  mk_fun "core::num::{u64}::abs_diff" "_root_.Aeneas.Std.core.num.U64.abs_diff" ~can_fail:false;
  (* file: "Aeneas/Std/Scalar/Pow.lean", line: 33 *)
  mk_fun "core::num::{u64}::pow" "_root_.Aeneas.Std.core.num.U64.pow";
  (* file: "Aeneas/Std/String.lean", line: 540 *)
  mk_fun "core::num::{u8}::is_ascii_alphabetic" "_root_.Aeneas.Std.core.num.U8.is_ascii_alphabetic";
  (* file: "Aeneas/Std/String.lean", line: 546 *)
  mk_fun "core::num::{u8}::is_ascii_alphanumeric" "_root_.Aeneas.Std.core.num.U8.is_ascii_alphanumeric";
  (* file: "Aeneas/Std/String.lean", line: 524 *)
  mk_fun "core::num::{u8}::is_ascii_digit" "_root_.Aeneas.Std.core.num.U8.is_ascii_digit";
  (* file: "Aeneas/Std/String.lean", line: 529 *)
  mk_fun "core::num::{u8}::is_ascii_hexdigit" "_root_.Aeneas.Std.core.num.U8.is_ascii_hexdigit";
  (* file: "Aeneas/Std/String.lean", line: 535 *)
  mk_fun "core::num::{u8}::is_ascii_whitespace" "_root_.Aeneas.Std.core.num.U8.is_ascii_whitespace";
  (* file: "Aeneas/Std/Scalar/Pow.lean", line: 27 *)
  mk_fun "core::num::{u8}::pow" "_root_.Aeneas.Std.core.num.U8.pow";
  (* file: "Aeneas/Std/Scalar/Misc.lean", line: 34 *)
  mk_fun "core::num::{usize}::abs_diff" "_root_.Aeneas.Std.core.num.Usize.abs_diff" ~can_fail:false;
  (* file: "Aeneas/Std/Scalar/Ops/Div.lean", line: 25 *)
  mk_fun "core::num::{usize}::div_ceil" "_root_.Aeneas.Std.core.num.Usize.div_ceil";
  (* file: "Aeneas/Std/Scalar/Misc.lean", line: 11 *)
  mk_fun "core::num::{usize}::is_multiple_of" "_root_.Aeneas.Std.core.num.Usize.is_multiple_of" ~can_fail:false;
  (* file: "Aeneas/Std/Scalar/Pow.lean", line: 7 *)
  mk_fun "core::num::{usize}::is_power_of_two" "_root_.Aeneas.Std.core.num.Usize.is_power_of_two";
  (* file: "Aeneas/Std/Scalar/Pow.lean", line: 37 *)
  mk_fun "core::num::{usize}::pow" "_root_.Aeneas.Std.core.num.Usize.pow";
  (* file: "Aeneas/Std/Float.lean", line: 557 *)
  mk_fun "core::ops::arith::{core::ops::arith::AddAssign<f64, &'a f64>}::add_assign" "_root_.Aeneas.Std.core.ops.arith.AddAssignF64SharedF64.add_assign";
  (* file: "Aeneas/Std/Scalar/Ops/Add.lean", line: 144 *)
  mk_fun "core::ops::arith::{core::ops::arith::AddAssign<usize, &'0 usize>}::add_assign" "_root_.Aeneas.Std.core.ops.arith.AddAssignUsizeSharedUsize.add_assign";
  (* file: "Aeneas/Std/Scalar/Ops/Mul.lean", line: 34 *)
  mk_fun "core::ops::arith::{core::ops::arith::Mul<&'a usize, usize, usize>}::mul" "_root_.Aeneas.Std.core.ops.arith.MulSharedUsizeUsize.mul";
  (* file: "Aeneas/Std/Scalar/Ops/Mul.lean", line: 23 *)
  mk_fun "core::ops::arith::{core::ops::arith::MulAssign<usize, &'a usize>}::mul_assign" "_root_.Aeneas.Std.core.ops.arith.MulAssignUsizeShared.mul_assign";
  (* file: "Aeneas/Std/Scalar/Ops/Rem.lean", line: 130 *)
  mk_fun "core::ops::arith::{core::ops::arith::Rem<&'0 u64, u64, u64>}::rem" "_root_.Aeneas.Std.core.ops.arith.RemSharedU64U64.rem";
  (* file: "Aeneas/Std/Scalar/Ops/Sub.lean", line: 171 *)
  mk_fun "core::ops::arith::{core::ops::arith::Sub<&'1 i64, &'0 i64, i64>}::sub" "_root_.Aeneas.Std.core.ops.arith.SubSharedI64SharedI64.sub";
  (* file: "Aeneas/Std/Scalar/Ops/Sub.lean", line: 21 *)
  mk_fun "core::ops::arith::{core::ops::arith::Sub<usize, &'a usize, usize>}::sub" "_root_.Aeneas.Std.core.ops.arith.SubUsizeSharedUsize.sub";
  (* file: "Aeneas/Std/Scalar/Bitwise.lean", line: 289 *)
  mk_fun "core::ops::bit::{core::ops::bit::BitAnd<&'0 u128, u128, u128>}::bitand" "_root_.Aeneas.Std.core.ops.bit.BitAndSharedU128U128.bitand";
  (* file: "Aeneas/Std/Scalar/Bitwise.lean", line: 294 *)
  mk_fun "core::ops::bit::{core::ops::bit::BitAnd<&'1 u128, &'0 u128, u128>}::bitand" "_root_.Aeneas.Std.core.ops.bit.BitAndSharedU128SharedU128.bitand";
  (* file: "Aeneas/Std/Scalar/Bitwise.lean", line: 299 *)
  mk_fun "core::ops::bit::{core::ops::bit::Not<&'0 bool, bool>}::not" "_root_.Aeneas.Std.core.ops.bit.NotSharedBool.not";
  (* file: "Aeneas/Std/Core/Ops.lean", line: 217 *)
  mk_fun "core::ops::function::impls::{core::ops::function::FnMut<&'0 mut @F, @A, @Clause0_Clause0_Output>}::call_mut" "_root_.Aeneas.Std.core.ops.function.FnMutMutRef.call_mut";
  (* file: "Aeneas/Std/Core/Ops.lean", line: 205 *)
  mk_fun "core::ops::function::impls::{core::ops::function::FnOnce<&'0 mut @F, @A, @Clause0_Clause0_Output>}::call_once" "_root_.Aeneas.Std.core.ops.function.FnOnceMutRef.call_once";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 13 *)
  mk_fun "core::ops::range::{core::ops::range::Range<@Idx>}::contains" "_root_.Aeneas.Std.core.ops.range.Range.contains";
  (* file: "Aeneas/Std/RangeBounds.lean", line: 78 *)
  mk_fun "core::ops::range::{core::ops::range::RangeBounds<core::ops::range::Range<@T>, @T>}::end_bound" "_root_.Aeneas.Std.core.ops.range.RangeBoundsRange.end_bound";
  (* file: "Aeneas/Std/RangeBounds.lean", line: 73 *)
  mk_fun "core::ops::range::{core::ops::range::RangeBounds<core::ops::range::Range<@T>, @T>}::start_bound" "_root_.Aeneas.Std.core.ops.range.RangeBoundsRange.start_bound";
  (* file: "Aeneas/Std/RangeBounds.lean", line: 44 *)
  mk_fun "core::ops::range::{core::ops::range::RangeBounds<core::ops::range::RangeFrom<@T>, @T>}::end_bound" "_root_.Aeneas.Std.core.ops.range.RangeBoundsRangeFrom.end_bound";
  (* file: "Aeneas/Std/RangeBounds.lean", line: 39 *)
  mk_fun "core::ops::range::{core::ops::range::RangeBounds<core::ops::range::RangeFrom<@T>, @T>}::start_bound" "_root_.Aeneas.Std.core.ops.range.RangeBoundsRangeFrom.start_bound";
  (* file: "Aeneas/Std/RangeBounds.lean", line: 28 *)
  mk_fun "core::ops::range::{core::ops::range::RangeBounds<core::ops::range::RangeFull, @T>}::end_bound" "_root_.Aeneas.Std.core.ops.range.RangeBoundsRangeFull.end_bound";
  (* file: "Aeneas/Std/RangeBounds.lean", line: 23 *)
  mk_fun "core::ops::range::{core::ops::range::RangeBounds<core::ops::range::RangeFull, @T>}::start_bound" "_root_.Aeneas.Std.core.ops.range.RangeBoundsRangeFull.start_bound";
  (* file: "Aeneas/Std/RangeBounds.lean", line: 96 *)
  mk_fun "core::ops::range::{core::ops::range::RangeBounds<core::ops::range::RangeInclusive<@T>, @T>}::end_bound" "_root_.Aeneas.Std.core.ops.range.RangeBoundsRangeInclusive.end_bound";
  (* file: "Aeneas/Std/RangeBounds.lean", line: 90 *)
  mk_fun "core::ops::range::{core::ops::range::RangeBounds<core::ops::range::RangeInclusive<@T>, @T>}::start_bound" "_root_.Aeneas.Std.core.ops.range.RangeBoundsRangeInclusive.start_bound";
  (* file: "Aeneas/Std/RangeBounds.lean", line: 61 *)
  mk_fun "core::ops::range::{core::ops::range::RangeBounds<core::ops::range::RangeTo<@T>, @T>}::end_bound" "_root_.Aeneas.Std.core.ops.range.RangeBoundsRangeTo.end_bound";
  (* file: "Aeneas/Std/RangeBounds.lean", line: 56 *)
  mk_fun "core::ops::range::{core::ops::range::RangeBounds<core::ops::range::RangeTo<@T>, @T>}::start_bound" "_root_.Aeneas.Std.core.ops.range.RangeBoundsRangeTo.start_bound";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 39 *)
  mk_fun "core::ops::range::{core::ops::range::RangeInclusive<@Idx>}::contains" "_root_.Aeneas.Std.core.ops.range.RangeInclusive.contains";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 27 *)
  mk_fun "core::ops::range::{core::ops::range::RangeInclusive<@Idx>}::new" "_root_.Aeneas.Std.core.ops.range.RangeInclusive.new";
  (* file: "Aeneas/Std/Core/Core.lean", line: 181 *)
  mk_fun "core::option::Option::Some" "_root_.Aeneas.Std.core.option.Option.Some";
  (* file: "Aeneas/Std/Core/CoreOption.lean", line: 12 *)
  mk_fun "core::option::expect_failed" "_root_.Aeneas.Std.core.option.expect_failed";
  (* file: "Aeneas/Std/Core/CoreOption.lean", line: 7 *)
  mk_fun "core::option::unwrap_failed" "_root_.Aeneas.Std.core.option.unwrap_failed";
  (* file: "Aeneas/Std/Core/CoreOption.lean", line: 15 *)
  mk_fun "core::option::{core::clone::Clone<core::option::Option<@T>>}::clone" "_root_.Aeneas.Std.core.option.Option.Clone.clone";
  (* file: "Aeneas/Std/Core/CoreOption.lean", line: 24 *)
  mk_fun "core::option::{core::clone::Clone<core::option::Option<@T>>}::clone_from" "_root_.Aeneas.Std.core.option.Option.Clone.clone_from";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 217 *)
  mk_fun "core::option::{core::cmp::Eq<core::option::Option<@T>>}::assert_receiver_is_total_eq" "_root_.Aeneas.Std.core.option.EqOption.assert_receiver_is_total_eq";
  (* file: "Aeneas/Std/Core/CoreOption.lean", line: 59 *)
  mk_fun "core::option::{core::cmp::PartialEq<core::option::Option<@T>, core::option::Option<@T>>}::eq" "_root_.Aeneas.Std.core.option.Option.Insts.CoreCmpPartialEqOption.eq";
  (* file: "Aeneas/Std/Core/Default.lean", line: 13 *)
  mk_fun "core::option::{core::default::Default<core::option::Option<@T>>}::default" "_root_.Aeneas.Std.core.option.DefaultOption.default";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 167 *)
  mk_fun "core::option::{core::fmt::Debug<core::option::Option<@T>>}::fmt" "_root_.Aeneas.Std.core.fmt.DebugOption.fmt";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 339 *)
  mk_fun "core::option::{core::hash::Hash<core::option::Option<@T>>}::hash" "_root_.Aeneas.Std.core.option.HashOption.hash";
  (* file: "Aeneas/Std/ResultIter.lean", line: 167 *)
  mk_fun "core::option::{core::iter::traits::collect::FromIterator<core::option::Option<@V>, core::option::Option<@A>>}::from_iter" "_root_.Aeneas.Std.core.option.FromIteratorOption.from_iter";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 519 *)
  mk_fun "core::option::{core::iter::traits::collect::IntoIterator<&'a core::option::Option<@T>, &'a @T, core::option::Iter<'a, @T>>}::into_iter" "_root_.Aeneas.Std.core.option.IntoIteratorSharedOption.into_iter";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 546 *)
  mk_fun "core::option::{core::iter::traits::collect::IntoIterator<core::option::Option<@T>, @T, core::option::IntoIter<@T>>}::into_iter" "_root_.Aeneas.Std.core.option.IntoIteratorOption.into_iter";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 560 *)
  mk_fun "core::option::{core::iter::traits::double_ended::DoubleEndedIterator<core::option::IntoIter<@A>, @A>}::next_back" "_root_.Aeneas.Std.core.option.DoubleEndedIteratorIntoIter.next_back";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 552 *)
  mk_fun "core::option::{core::iter::traits::iterator::Iterator<core::option::IntoIter<@A>, @A>}::next" "_root_.Aeneas.Std.core.option.IteratorIntoIter.next";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 566 *)
  mk_fun "core::option::{core::iter::traits::iterator::Iterator<core::option::IntoIter<@A>, @A>}::size_hint" "_root_.Aeneas.Std.core.option.IteratorIntoIter.size_hint";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 494 *)
  mk_fun "core::option::{core::iter::traits::iterator::Iterator<core::option::Iter<'a, @A>, &'a @A>}::next" "_root_.Aeneas.Std.core.option.IteratorIter.next";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 500 *)
  mk_fun "core::option::{core::iter::traits::iterator::Iterator<core::option::Iter<'a, @A>, &'a @A>}::size_hint" "_root_.Aeneas.Std.core.option.IteratorIter.size_hint";
  (* file: "Aeneas/Std/Core/CoreOption.lean", line: 40 *)
  mk_fun "core::option::{core::option::Option<@T>}::expect" "_root_.Aeneas.Std.core.option.Option.expect";
  (* file: "Aeneas/Std/Core/CoreOption.lean", line: 54 *)
  mk_fun "core::option::{core::option::Option<@T>}::get_or_insert" "_root_.Aeneas.Std.core.option.Option.get_or_insert";
  (* file: "Aeneas/Std/Core/Core.lean", line: 208 *)
  mk_fun "core::option::{core::option::Option<@T>}::is_none" "_root_.Aeneas.Std.core.option.Option.is_none" ~can_fail:false ~lift:false;
  (* file: "Aeneas/Std/Core/Core.lean", line: 212 *)
  mk_fun "core::option::{core::option::Option<@T>}::is_some" "_root_.Aeneas.Std.core.option.Option.is_some" ~can_fail:false ~lift:false;
  (* file: "Aeneas/Std/IteratorSources.lean", line: 490 *)
  mk_fun "core::option::{core::option::Option<@T>}::iter" "_root_.Aeneas.Std.core.option.Option.iter";
  (* file: "Aeneas/Std/Core/CoreOption.lean", line: 44 *)
  mk_fun "core::option::{core::option::Option<@T>}::ok_or" "_root_.Aeneas.Std.core.option.Option.ok_or";
  (* file: "Aeneas/Std/Core/Core.lean", line: 205 *)
  mk_fun "core::option::{core::option::Option<@T>}::take" "_root_.Aeneas.Std.core.option.Option.take" ~can_fail:false ~lift:false;
  (* file: "Aeneas/Std/Core/Core.lean", line: 184 *)
  mk_fun "core::option::{core::option::Option<@T>}::unwrap" "_root_.Aeneas.Std.core.option.Option.unwrap";
  (* file: "Aeneas/Std/Core/Core.lean", line: 193 *)
  mk_fun "core::option::{core::option::Option<@T>}::unwrap_or" "_root_.Aeneas.Std.core.option.Option.unwrap_or" ~can_fail:false;
  (* file: "Aeneas/Std/Core/UnwindSafe.lean", line: 18 *)
  mk_fun "core::panic::unwind_safe::{core::ops::deref::Deref<core::panic::unwind_safe::AssertUnwindSafe<@T>, @T>}::deref" "_root_.Aeneas.Std.core.panic.unwind_safe.DerefAssertUnwindSafe.deref";
  (* file: "Aeneas/Std/Core/UnwindSafe.lean", line: 33 *)
  mk_fun "core::panic::unwind_safe::{core::ops::deref::DerefMut<core::panic::unwind_safe::AssertUnwindSafe<@T>, @T>}::deref_mut" "_root_.Aeneas.Std.core.panic.unwind_safe.DerefMutAssertUnwindSafe.deref_mut";
  (* file: "Aeneas/Std/Core/UnwindSafe.lean", line: 50 *)
  mk_fun "core::panic::unwind_safe::{core::ops::function::FnOnce<core::panic::unwind_safe::AssertUnwindSafe<@F>, (), @R>}::call_once" "_root_.Aeneas.Std.core.panic.unwind_safe.FnOnceAssertUnwindSafe.call_once";
  (* file: "Aeneas/Std/Core/Result.lean", line: 59 *)
  mk_fun "core::result::{core::cmp::PartialEq<core::result::Result<@T, @E>, core::result::Result<@T, @E>>}::eq" "_root_.Aeneas.Std.core.result.PartialEqResult.eq";
  (* file: "Aeneas/Std/ResultIter.lean", line: 135 *)
  mk_fun "core::result::{core::iter::traits::collect::FromIterator<core::result::Result<@V, @E>, core::result::Result<@A, @E>>}::from_iter" "_root_.Aeneas.Std.core.result.FromIteratorResult.from_iter";
  (* file: "Aeneas/Std/Core/Result.lean", line: 13 *)
  mk_fun "core::result::{core::ops::try_trait::FromResidual<core::result::Result<@T, @F>, core::result::Result<core::convert::Infallible, @E>>}::from_residual" "_root_.Aeneas.Std.core.result.FromResidualResult.from_residual";
  (* file: "Aeneas/Std/Core/Result.lean", line: 38 *)
  mk_fun "core::result::{core::ops::try_trait::Try<core::result::Result<@T, @E>, @T, core::result::Result<core::convert::Infallible, @E>>}::branch" "_root_.Aeneas.Std.core.result.TryResult.branch";
  (* file: "Aeneas/Std/Core/Result.lean", line: 32 *)
  mk_fun "core::result::{core::ops::try_trait::Try<core::result::Result<@T, @E>, @T, core::result::Result<core::convert::Infallible, @E>>}::from_output" "_root_.Aeneas.Std.core.result.TryResult.from_output";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 644 *)
  mk_fun "core::result::{core::result::Result<@T, @E>}::expect" "_root_.Aeneas.Std.core.result.Result.expect";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 631 *)
  mk_fun "core::result::{core::result::Result<@T, @E>}::unwrap" "_root_.Aeneas.Std.core.result.Result.unwrap";
  (* file: "Aeneas/Std/SliceCmp.lean", line: 137 *)
  mk_fun "core::slice::cmp::{core::cmp::Ord<[@T]>}::cmp" "_root_.Aeneas.Std.core.slice.cmp.OrdSlice.cmp";
  (* file: "Aeneas/Std/SliceCmp.lean", line: 55 *)
  mk_fun "core::slice::cmp::{core::cmp::PartialEq<[@T], [@U]>}::eq" "_root_.Aeneas.Std.core.slice.cmp.PartialEqSlice.eq";
  (* file: "Aeneas/Std/SliceCmp.lean", line: 60 *)
  mk_fun "core::slice::cmp::{core::cmp::PartialEq<[@T], [@U]>}::ne" "_root_.Aeneas.Std.core.slice.cmp.PartialEqSlice.ne";
  (* file: "Aeneas/Std/SliceCmp.lean", line: 100 *)
  mk_fun "core::slice::cmp::{core::cmp::PartialOrd<[@T], [@T]>}::__chaining_ge" "_root_.Aeneas.Std.core.slice.cmp.PartialOrdSlice.chaining_ge";
  (* file: "Aeneas/Std/SliceCmp.lean", line: 96 *)
  mk_fun "core::slice::cmp::{core::cmp::PartialOrd<[@T], [@T]>}::__chaining_gt" "_root_.Aeneas.Std.core.slice.cmp.PartialOrdSlice.chaining_gt";
  (* file: "Aeneas/Std/SliceCmp.lean", line: 92 *)
  mk_fun "core::slice::cmp::{core::cmp::PartialOrd<[@T], [@T]>}::__chaining_le" "_root_.Aeneas.Std.core.slice.cmp.PartialOrdSlice.chaining_le";
  (* file: "Aeneas/Std/SliceCmp.lean", line: 88 *)
  mk_fun "core::slice::cmp::{core::cmp::PartialOrd<[@T], [@T]>}::__chaining_lt" "_root_.Aeneas.Std.core.slice.cmp.PartialOrdSlice.chaining_lt";
  (* file: "Aeneas/Std/SliceCmp.lean", line: 117 *)
  mk_fun "core::slice::cmp::{core::cmp::PartialOrd<[@T], [@T]>}::ge" "_root_.Aeneas.Std.core.slice.cmp.PartialOrdSlice.ge";
  (* file: "Aeneas/Std/SliceCmp.lean", line: 113 *)
  mk_fun "core::slice::cmp::{core::cmp::PartialOrd<[@T], [@T]>}::gt" "_root_.Aeneas.Std.core.slice.cmp.PartialOrdSlice.gt";
  (* file: "Aeneas/Std/SliceCmp.lean", line: 109 *)
  mk_fun "core::slice::cmp::{core::cmp::PartialOrd<[@T], [@T]>}::le" "_root_.Aeneas.Std.core.slice.cmp.PartialOrdSlice.le";
  (* file: "Aeneas/Std/SliceCmp.lean", line: 105 *)
  mk_fun "core::slice::cmp::{core::cmp::PartialOrd<[@T], [@T]>}::lt" "_root_.Aeneas.Std.core.slice.cmp.PartialOrdSlice.lt";
  (* file: "Aeneas/Std/SliceCmp.lean", line: 77 *)
  mk_fun "core::slice::cmp::{core::cmp::PartialOrd<[@T], [@T]>}::partial_cmp" "_root_.Aeneas.Std.core.slice.cmp.PartialOrdSlice.partial_cmp";
  (* file: "Aeneas/Std/Slice.lean", line: 347 *)
  mk_fun "core::slice::index::{core::ops::index::Index<[@T], @I, @O>}::index" "_root_.Aeneas.Std.core.slice.index.Slice.index";
  (* file: "Aeneas/Std/Slice.lean", line: 425 *)
  mk_fun "core::slice::index::{core::ops::index::IndexMut<[@T], @I, @O>}::index_mut" "_root_.Aeneas.Std.core.slice.index.Slice.index_mut";
  (* file: "Aeneas/Std/Slice.lean", line: 373 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<core::ops::range::Range<usize>, [@T], [@T]>}::get" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeUsizeSlice.get";
  (* file: "Aeneas/Std/Slice.lean", line: 380 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<core::ops::range::Range<usize>, [@T], [@T]>}::get_mut" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeUsizeSlice.get_mut";
  (* file: "Aeneas/Std/Slice.lean", line: 394 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<core::ops::range::Range<usize>, [@T], [@T]>}::get_unchecked" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeUsizeSlice.get_unchecked";
  (* file: "Aeneas/Std/Slice.lean", line: 400 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<core::ops::range::Range<usize>, [@T], [@T]>}::get_unchecked_mut" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeUsizeSlice.get_unchecked_mut";
  (* file: "Aeneas/Std/Slice.lean", line: 406 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<core::ops::range::Range<usize>, [@T], [@T]>}::index" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeUsizeSlice.index";
  (* file: "Aeneas/Std/Slice.lean", line: 412 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<core::ops::range::Range<usize>, [@T], [@T]>}::index_mut" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeUsizeSlice.index_mut";
  (* file: "Aeneas/Std/Slice.lean", line: 649 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<core::ops::range::RangeFrom<usize>, [@T], [@T]>}::get" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeFromUsizeSlice.get";
  (* file: "Aeneas/Std/Slice.lean", line: 655 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<core::ops::range::RangeFrom<usize>, [@T], [@T]>}::get_mut" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeFromUsizeSlice.get_mut";
  (* file: "Aeneas/Std/Slice.lean", line: 669 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<core::ops::range::RangeFrom<usize>, [@T], [@T]>}::get_unchecked" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeFromUsizeSlice.get_unchecked";
  (* file: "Aeneas/Std/Slice.lean", line: 675 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<core::ops::range::RangeFrom<usize>, [@T], [@T]>}::get_unchecked_mut" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeFromUsizeSlice.get_unchecked_mut";
  (* file: "Aeneas/Std/Slice.lean", line: 681 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<core::ops::range::RangeFrom<usize>, [@T], [@T]>}::index" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeFromUsizeSlice.index";
  (* file: "Aeneas/Std/Slice.lean", line: 688 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<core::ops::range::RangeFrom<usize>, [@T], [@T]>}::index_mut" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeFromUsizeSlice.index_mut";
  (* file: "Aeneas/Std/Slice.lean", line: 528 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<core::ops::range::RangeFull, [@T], [@T]>}::get" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeFullSlice.get";
  (* file: "Aeneas/Std/Slice.lean", line: 533 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<core::ops::range::RangeFull, [@T], [@T]>}::get_mut" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeFullSlice.get_mut";
  (* file: "Aeneas/Std/Slice.lean", line: 539 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<core::ops::range::RangeFull, [@T], [@T]>}::get_unchecked" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeFullSlice.get_unchecked";
  (* file: "Aeneas/Std/Slice.lean", line: 545 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<core::ops::range::RangeFull, [@T], [@T]>}::get_unchecked_mut" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeFullSlice.get_unchecked_mut";
  (* file: "Aeneas/Std/Slice.lean", line: 551 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<core::ops::range::RangeFull, [@T], [@T]>}::index" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeFullSlice.index";
  (* file: "Aeneas/Std/Slice.lean", line: 556 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<core::ops::range::RangeFull, [@T], [@T]>}::index_mut" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeFullSlice.index_mut";
  (* file: "Aeneas/Std/Slice.lean", line: 452 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<core::ops::range::RangeTo<usize>, [@T], [@T]>}::get" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeToUsizeSlice.get";
  (* file: "Aeneas/Std/Slice.lean", line: 459 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<core::ops::range::RangeTo<usize>, [@T], [@T]>}::get_mut" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeToUsizeSlice.get_mut";
  (* file: "Aeneas/Std/Slice.lean", line: 474 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<core::ops::range::RangeTo<usize>, [@T], [@T]>}::get_unchecked" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeToUsizeSlice.get_unchecked";
  (* file: "Aeneas/Std/Slice.lean", line: 480 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<core::ops::range::RangeTo<usize>, [@T], [@T]>}::get_unchecked_mut" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeToUsizeSlice.get_unchecked_mut";
  (* file: "Aeneas/Std/Slice.lean", line: 487 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<core::ops::range::RangeTo<usize>, [@T], [@T]>}::index" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeToUsizeSlice.index";
  (* file: "Aeneas/Std/Slice.lean", line: 494 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<core::ops::range::RangeTo<usize>, [@T], [@T]>}::index_mut" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeToUsizeSlice.index_mut";
  (* file: "Aeneas/Std/Slice.lean", line: 589 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<usize, [@T], @T>}::get" "_root_.Aeneas.Std.core.slice.index.Usize.get";
  (* file: "Aeneas/Std/Slice.lean", line: 594 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<usize, [@T], @T>}::get_mut" "_root_.Aeneas.Std.core.slice.index.Usize.get_mut";
  (* file: "Aeneas/Std/Slice.lean", line: 599 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<usize, [@T], @T>}::get_unchecked" "_root_.Aeneas.Std.core.slice.index.Usize.get_unchecked";
  (* file: "Aeneas/Std/Slice.lean", line: 605 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<usize, [@T], @T>}::get_unchecked_mut" "_root_.Aeneas.Std.core.slice.index.Usize.get_unchecked_mut";
  (* file: "Aeneas/Std/Slice.lean", line: 611 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<usize, [@T], @T>}::index" "_root_.Aeneas.Std.core.slice.index.Usize.index";
  (* file: "Aeneas/Std/Slice.lean", line: 615 *)
  mk_fun "core::slice::index::{core::slice::index::SliceIndex<usize, [@T], @T>}::index_mut" "_root_.Aeneas.Std.core.slice.index.Usize.index_mut";
  (* file: "Aeneas/Std/SliceIter.lean", line: 404 *)
  mk_fun "core::slice::iter::{core::iter::traits::collect::IntoIterator<&'a [@T], &'a @T, core::slice::iter::Iter<'a, @T>>}::into_iter" "_root_.Aeneas.Std.core.slice.iter.IntoIteratorSharedSlice.into_iter";
  (* file: "Aeneas/Std/SliceIter.lean", line: 80 *)
  mk_fun "core::slice::iter::{core::iter::traits::collect::IntoIterator<&'a mut [@T], &'a mut @T, core::slice::iter::IterMut<'a, @T>>}::into_iter" "_root_.Aeneas.Std.core.slice.iter.IntoIteratorMutSlice.into_iter";
  (* file: "Aeneas/Std/SliceIter.lean", line: 354 *)
  mk_fun "core::slice::iter::{core::iter::traits::double_ended::DoubleEndedIterator<core::slice::iter::Iter<'a, @T>, &'_ @T>}::advance_back_by" "_root_.Aeneas.Std.core.slice.iter.DoubleEndedIteratorSliceIter.advance_back_by";
  (* file: "Aeneas/Std/SliceIter.lean", line: 99 *)
  mk_fun "core::slice::iter::{core::iter::traits::double_ended::DoubleEndedIterator<core::slice::iter::Iter<'a, @T>, &'_ @T>}::next_back" "_root_.Aeneas.Std.core.slice.iter.DoubleEndedIteratorSliceIter.next_back";
  (* file: "Aeneas/Std/SliceIter.lean", line: 367 *)
  mk_fun "core::slice::iter::{core::iter::traits::double_ended::DoubleEndedIterator<core::slice::iter::Iter<'a, @T>, &'_ @T>}::nth_back" "_root_.Aeneas.Std.core.slice.iter.DoubleEndedIteratorSliceIter.nth_back";
  (* file: "Aeneas/Std/SliceIter.lean", line: 389 *)
  mk_fun "core::slice::iter::{core::iter::traits::exact_size::ExactSizeIterator<core::slice::iter::Iter<'a, @T>, &'_ @T>}::len" "_root_.Aeneas.Std.core.slice.iter.ExactSizeIteratorSliceIter.len";
  (* file: "Aeneas/Std/SliceIter.lean", line: 605 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Chunks<'a, @T>, &'a [@T]>}::any" "_root_.Aeneas.Std.core.slice.iter.IteratorChunks.any";
  (* file: "Aeneas/Std/SliceIter.lean", line: 593 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Chunks<'a, @T>, &'a [@T]>}::count" "_root_.Aeneas.Std.core.slice.iter.IteratorChunks.count";
  (* file: "Aeneas/Std/SliceIter.lean", line: 579 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Chunks<'a, @T>, &'a [@T]>}::enumerate" "_root_.Aeneas.Std.core.slice.iter.IteratorChunks.enumerate";
  (* file: "Aeneas/Std/SliceIter.lean", line: 560 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Chunks<'a, @T>, &'a [@T]>}::next" "_root_.Aeneas.Std.core.slice.iter.IteratorChunks.next";
  (* file: "Aeneas/Std/SliceIter.lean", line: 622 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Chunks<'a, @T>, &'a [@T]>}::nth" "_root_.Aeneas.Std.core.slice.iter.IteratorChunks.nth";
  (* file: "Aeneas/Std/SliceIter.lean", line: 615 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Chunks<'a, @T>, &'a [@T]>}::size_hint" "_root_.Aeneas.Std.core.slice.iter.IteratorChunks.size_hint";
  (* file: "Aeneas/Std/SliceIter.lean", line: 572 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Chunks<'a, @T>, &'a [@T]>}::step_by" "_root_.Aeneas.Std.core.slice.iter.IteratorChunks.step_by";
  (* file: "Aeneas/Std/SliceIter.lean", line: 586 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Chunks<'a, @T>, &'a [@T]>}::take" "_root_.Aeneas.Std.core.slice.iter.IteratorChunks.take";
  (* file: "Aeneas/Std/SliceIter.lean", line: 719 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::ChunksExact<'a, @T>, &'a [@T]>}::count" "_root_.Aeneas.Std.core.slice.iter.IteratorChunksExact.count";
  (* file: "Aeneas/Std/SliceIter.lean", line: 695 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::ChunksExact<'a, @T>, &'a [@T]>}::enumerate" "_root_.Aeneas.Std.core.slice.iter.IteratorChunksExact.enumerate";
  (* file: "Aeneas/Std/SliceIter.lean", line: 675 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::ChunksExact<'a, @T>, &'a [@T]>}::next" "_root_.Aeneas.Std.core.slice.iter.IteratorChunksExact.next";
  (* file: "Aeneas/Std/SliceIter.lean", line: 726 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::ChunksExact<'a, @T>, &'a [@T]>}::nth" "_root_.Aeneas.Std.core.slice.iter.IteratorChunksExact.nth";
  (* file: "Aeneas/Std/SliceIter.lean", line: 708 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::ChunksExact<'a, @T>, &'a [@T]>}::size_hint" "_root_.Aeneas.Std.core.slice.iter.IteratorChunksExact.size_hint";
  (* file: "Aeneas/Std/SliceIter.lean", line: 687 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::ChunksExact<'a, @T>, &'a [@T]>}::step_by" "_root_.Aeneas.Std.core.slice.iter.IteratorChunksExact.step_by";
  (* file: "Aeneas/Std/SliceIter.lean", line: 701 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::ChunksExact<'a, @T>, &'a [@T]>}::take" "_root_.Aeneas.Std.core.slice.iter.IteratorChunksExact.take";
  (* file: "Aeneas/Std/SliceIter.lean", line: 140 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::advance_by" "_root_.Aeneas.Std.core.slice.iter.IteratorSliceIter.advance_by";
  (* file: "Aeneas/Std/SliceIter.lean", line: 207 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::all" "_root_.Aeneas.Std.core.slice.iter.IteratorSliceIter.all";
  (* file: "Aeneas/Std/SliceIter.lean", line: 200 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::any" "_root_.Aeneas.Std.core.slice.iter.IteratorSliceIter.any";
  (* file: "Aeneas/Std/SliceIter.lean", line: 185 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::count" "_root_.Aeneas.Std.core.slice.iter.IteratorSliceIter.count";
  (* file: "Aeneas/Std/SliceIter.lean", line: 117 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::enumerate" "_root_.Aeneas.Std.core.slice.iter.IteratorSliceIter.enumerate";
  (* file: "Aeneas/Std/SliceIter.lean", line: 215 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::find" "_root_.Aeneas.Std.core.slice.iter.IteratorSliceIter.find";
  (* file: "Aeneas/Std/SliceIter.lean", line: 223 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::find_map" "_root_.Aeneas.Std.core.slice.iter.IteratorSliceIter.find_map";
  (* file: "Aeneas/Std/SliceIter.lean", line: 163 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::fold" "_root_.Aeneas.Std.core.slice.iter.IteratorSliceIter.fold";
  (* file: "Aeneas/Std/SliceIter.lean", line: 305 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::for_each" "_root_.Aeneas.Std.core.slice.iter.IteratorSliceIter.for_each";
  (* file: "Aeneas/Std/SliceIter.lean", line: 346 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::min" "_root_.Aeneas.Std.core.slice.iter.IteratorSliceIter.min";
  (* file: "Aeneas/Std/SliceIter.lean", line: 87 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::next" "_root_.Aeneas.Std.core.slice.iter.IteratorSliceIter.next";
  (* file: "Aeneas/Std/SliceIter.lean", line: 153 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::nth" "_root_.Aeneas.Std.core.slice.iter.IteratorSliceIter.nth";
  (* file: "Aeneas/Std/SliceIter.lean", line: 231 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::position" "_root_.Aeneas.Std.core.slice.iter.IteratorSliceIter.position";
  (* file: "Aeneas/Std/SliceIter.lean", line: 328 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::product" "_root_.Aeneas.Std.core.slice.iter.IteratorSliceIter.product";
  (* file: "Aeneas/Std/SliceIter.lean", line: 260 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::rposition" "_root_.Aeneas.Std.core.slice.iter.IteratorSliceIter.rposition" ~keep_trait_clauses:(Some [true; false; false]);
  (* file: "Aeneas/Std/SliceIter.lean", line: 130 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::size_hint" "_root_.Aeneas.Std.core.slice.iter.IteratorSliceIter.size_hint";
  (* file: "Aeneas/Std/SliceIter.lean", line: 110 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::step_by" "_root_.Aeneas.Std.core.slice.iter.IteratorSliceIter.step_by";
  (* file: "Aeneas/Std/SliceIter.lean", line: 337 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::sum" "_root_.Aeneas.Std.core.slice.iter.IteratorSliceIter.sum";
  (* file: "Aeneas/Std/SliceIter.lean", line: 123 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::take" "_root_.Aeneas.Std.core.slice.iter.IteratorSliceIter.take";
  (* file: "Aeneas/Std/SliceIter.lean", line: 175 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::try_fold" "_root_.Aeneas.Std.core.slice.iter.IteratorSliceIter.try_fold";
  (* file: "Aeneas/Std/SliceIter.lean", line: 313 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::try_for_each" "_root_.Aeneas.Std.core.slice.iter.IteratorSliceIter.try_for_each";
  (* file: "Aeneas/Std/SliceIter.lean", line: 59 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::IterMut<'a, @T>, &'a mut @T>}::find" "_root_.Aeneas.Std.core.slice.iter.IteratorIterMut.find";
  (* file: "Aeneas/Std/SliceIter.lean", line: 38 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::IterMut<'a, @T>, &'a mut @T>}::next" "_root_.Aeneas.Std.core.slice.iter.IteratorIterMut.next";
  (* file: "Aeneas/Std/SliceIter.lean", line: 495 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Windows<'a, @T>, &'a [@T]>}::any" "_root_.Aeneas.Std.core.slice.iter.IteratorWindows.any";
  (* file: "Aeneas/Std/SliceIter.lean", line: 483 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Windows<'a, @T>, &'a [@T]>}::count" "_root_.Aeneas.Std.core.slice.iter.IteratorWindows.count";
  (* file: "Aeneas/Std/SliceIter.lean", line: 469 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Windows<'a, @T>, &'a [@T]>}::enumerate" "_root_.Aeneas.Std.core.slice.iter.IteratorWindows.enumerate";
  (* file: "Aeneas/Std/SliceIter.lean", line: 450 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Windows<'a, @T>, &'a [@T]>}::next" "_root_.Aeneas.Std.core.slice.iter.IteratorWindows.next";
  (* file: "Aeneas/Std/SliceIter.lean", line: 512 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Windows<'a, @T>, &'a [@T]>}::nth" "_root_.Aeneas.Std.core.slice.iter.IteratorWindows.nth";
  (* file: "Aeneas/Std/SliceIter.lean", line: 505 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Windows<'a, @T>, &'a [@T]>}::size_hint" "_root_.Aeneas.Std.core.slice.iter.IteratorWindows.size_hint";
  (* file: "Aeneas/Std/SliceIter.lean", line: 462 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Windows<'a, @T>, &'a [@T]>}::step_by" "_root_.Aeneas.Std.core.slice.iter.IteratorWindows.step_by";
  (* file: "Aeneas/Std/SliceIter.lean", line: 476 *)
  mk_fun "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Windows<'a, @T>, &'a [@T]>}::take" "_root_.Aeneas.Std.core.slice.iter.IteratorWindows.take";
  (* file: "Aeneas/Std/Slice.lean", line: 776 *)
  mk_fun "core::slice::raw::from_ref" "_root_.Aeneas.Std.core.slice.raw.from_ref";
  (* file: "Aeneas/Std/SliceSearch.lean", line: 37 *)
  mk_fun "core::slice::{[@T]}::as_chunks" "_root_.Aeneas.Std.core.slice.Slice.as_chunks";
  (* file: "Aeneas/Std/SliceSearch.lean", line: 89 *)
  mk_fun "core::slice::{[@T]}::binary_search" "_root_.Aeneas.Std.core.slice.Slice.binary_search";
  (* file: "Aeneas/Std/SliceIter.lean", line: 554 *)
  mk_fun "core::slice::{[@T]}::chunks" "_root_.Aeneas.Std.core.slice.Slice.chunks";
  (* file: "Aeneas/Std/SliceIter.lean", line: 772 *)
  mk_fun "core::slice::{[@T]}::chunks_exact" "_root_.Aeneas.Std.core.slice.Slice.chunks_exact";
  (* file: "Aeneas/Std/SliceIter.lean", line: 33 *)
  mk_fun "core::slice::{[@T]}::contains" "_root_.Aeneas.Std.core.slice.Slice.contains";
  (* file: "Aeneas/Std/Slice.lean", line: 643 *)
  mk_fun "core::slice::{[@T]}::copy_from_slice" "_root_.Aeneas.Std.core.slice.Slice.copy_from_slice";
  (* file: "Aeneas/Std/SliceSearch.lean", line: 123 *)
  mk_fun "core::slice::{[@T]}::fill" "_root_.Aeneas.Std.core.slice.Slice.fill";
  (* file: "Aeneas/Std/Slice.lean", line: 121 *)
  mk_fun "core::slice::{[@T]}::first" "_root_.Aeneas.Std.core.slice.Slice.first";
  (* file: "Aeneas/Std/Slice.lean", line: 132 *)
  mk_fun "core::slice::{[@T]}::first_mut" "_root_.Aeneas.Std.core.slice.Slice.first_mut";
  (* file: "Aeneas/Std/Slice.lean", line: 353 *)
  mk_fun "core::slice::{[@T]}::get" "_root_.Aeneas.Std.core.slice.Slice.get";
  (* file: "Aeneas/Std/Slice.lean", line: 367 *)
  mk_fun "core::slice::{[@T]}::get_mut" "_root_.Aeneas.Std.core.slice.Slice.get_mut";
  (* file: "Aeneas/Std/Slice.lean", line: 359 *)
  mk_fun "core::slice::{[@T]}::get_unchecked" "_root_.Aeneas.Std.core.slice.Slice.get_unchecked";
  (* file: "Aeneas/Std/Slice.lean", line: 112 *)
  mk_fun "core::slice::{[@T]}::is_empty" "_root_.Aeneas.Std.core.slice.Slice.is_empty";
  (* file: "Aeneas/Std/SliceIter.lean", line: 29 *)
  mk_fun "core::slice::{[@T]}::iter" "_root_.Aeneas.Std.core.slice.Slice.iter";
  (* file: "Aeneas/Std/SliceIter.lean", line: 75 *)
  mk_fun "core::slice::{[@T]}::iter_mut" "_root_.Aeneas.Std.core.slice.Slice.iter_mut";
  (* file: "Aeneas/Std/Slice.lean", line: 125 *)
  mk_fun "core::slice::{[@T]}::last" "_root_.Aeneas.Std.core.slice.Slice.last";
  (* file: "Aeneas/Std/Slice.lean", line: 142 *)
  mk_fun "core::slice::{[@T]}::last_mut" "_root_.Aeneas.Std.core.slice.Slice.last_mut";
  (* file: "Aeneas/Std/Slice.lean", line: 45 *)
  mk_fun "core::slice::{[@T]}::len" "_root_.Aeneas.Std.Slice.len" ~can_fail:false ~lift:false;
  (* file: "Aeneas/Std/SliceSearch.lean", line: 113 *)
  mk_fun "core::slice::{[@T]}::partition_point" "_root_.Aeneas.Std.core.slice.Slice.partition_point";
  (* file: "Aeneas/Std/Slice.lean", line: 330 *)
  mk_fun "core::slice::{[@T]}::reverse" "_root_.Aeneas.Std.core.slice.Slice.reverse" ~can_fail:false;
  (* file: "Aeneas/Std/Sort.lean", line: 107 *)
  mk_fun "core::slice::{[@T]}::sort_unstable" "_root_.Aeneas.Std.core.slice.Slice.sort_unstable";
  (* file: "Aeneas/Std/Sort.lean", line: 120 *)
  mk_fun "core::slice::{[@T]}::sort_unstable_by" "_root_.Aeneas.Std.core.slice.Slice.sort_unstable_by";
  (* file: "Aeneas/Std/Slice.lean", line: 780 *)
  mk_fun "core::slice::{[@T]}::split_at" "_root_.Aeneas.Std.core.slice.Slice.split_at";
  (* file: "Aeneas/Std/Slice.lean", line: 791 *)
  mk_fun "core::slice::{[@T]}::split_at_mut" "_root_.Aeneas.Std.core.slice.Slice.split_at_mut";
  (* file: "Aeneas/Std/Slice.lean", line: 754 *)
  mk_fun "core::slice::{[@T]}::split_first" "_root_.Aeneas.Std.core.slice.Slice.split_first";
  (* file: "Aeneas/Std/Slice.lean", line: 763 *)
  mk_fun "core::slice::{[@T]}::split_last" "_root_.Aeneas.Std.core.slice.Slice.split_last";
  (* file: "Aeneas/Std/Slice.lean", line: 851 *)
  mk_fun "core::slice::{[@T]}::swap" "_root_.Aeneas.Std.core.slice.Slice.swap";
  (* file: "Aeneas/Std/SliceIter.lean", line: 444 *)
  mk_fun "core::slice::{[@T]}::windows" "_root_.Aeneas.Std.core.slice.Slice.windows";
  (* file: "Aeneas/Std/Slice.lean", line: 770 *)
  mk_fun "core::slice::{core::default::Default<&'0 [@T]>}::default" "_root_.Aeneas.Std.core.slice.DefaultSharedSlice.default";
  (* file: "Aeneas/Std/StringIter.lean", line: 727 *)
  mk_fun "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Bytes<'a>, u8>}::all" "_root_.Aeneas.Std.core.str.iter.IteratorBytes.all";
  (* file: "Aeneas/Std/StringIter.lean", line: 719 *)
  mk_fun "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Bytes<'a>, u8>}::any" "_root_.Aeneas.Std.core.str.iter.IteratorBytes.any";
  (* file: "Aeneas/Std/StringIter.lean", line: 712 *)
  mk_fun "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Bytes<'a>, u8>}::count" "_root_.Aeneas.Std.core.str.iter.IteratorBytes.count";
  (* file: "Aeneas/Std/StringIter.lean", line: 736 *)
  mk_fun "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Bytes<'a>, u8>}::find" "_root_.Aeneas.Std.core.str.iter.IteratorBytes.find";
  (* file: "Aeneas/Std/StringIter.lean", line: 698 *)
  mk_fun "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Bytes<'a>, u8>}::next" "_root_.Aeneas.Std.core.str.iter.IteratorBytes.next";
  (* file: "Aeneas/Std/StringIter.lean", line: 705 *)
  mk_fun "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Bytes<'a>, u8>}::size_hint" "_root_.Aeneas.Std.core.str.iter.IteratorBytes.size_hint";
  (* file: "Aeneas/Std/StringIter.lean", line: 138 *)
  mk_fun "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Chars<'a>, char>}::advance_by" "_root_.Aeneas.Std.core.str.iter.IteratorChars.advance_by";
  (* file: "Aeneas/Std/StringIter.lean", line: 155 *)
  mk_fun "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Chars<'a>, char>}::collect" "_root_.Aeneas.Std.core.str.iter.IteratorChars.collect";
  (* file: "Aeneas/Std/StringIter.lean", line: 130 *)
  mk_fun "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Chars<'a>, char>}::count" "_root_.Aeneas.Std.core.str.iter.IteratorChars.count";
  (* file: "Aeneas/Std/StringIter.lean", line: 102 *)
  mk_fun "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Chars<'a>, char>}::next" "_root_.Aeneas.Std.core.str.iter.IteratorChars.next";
  (* file: "Aeneas/Std/StringIter.lean", line: 122 *)
  mk_fun "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Chars<'a>, char>}::size_hint" "_root_.Aeneas.Std.core.str.iter.IteratorChars.size_hint";
  (* file: "Aeneas/Std/StringIter.lean", line: 206 *)
  mk_fun "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Lines<'a>, &'a str>}::next" "_root_.Aeneas.Std.core.str.iter.IteratorLines.next";
  (* file: "Aeneas/Std/StringIter.lean", line: 228 *)
  mk_fun "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Lines<'a>, &'a str>}::size_hint" "_root_.Aeneas.Std.core.str.iter.IteratorLines.size_hint";
  (* file: "Aeneas/Std/StringIter.lean", line: 853 *)
  mk_fun "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::RSplit<'a, @P>, &'a str>}::next" "_root_.Aeneas.Std.core.str.iter.IteratorRSplit.next" ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/StringIter.lean", line: 611 *)
  mk_fun "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Split<'a, @P>, &'a str>}::next" "_root_.Aeneas.Std.core.str.iter.IteratorSplit.next";
  (* file: "Aeneas/Std/StringIter.lean", line: 663 *)
  mk_fun "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::SplitN<'a, @P>, &'a str>}::next" "_root_.Aeneas.Std.core.str.iter.IteratorSplitN.next";
  (* file: "Aeneas/Std/String.lean", line: 399 *)
  mk_fun "core::str::pattern::{core::str::pattern::Pattern<&'b str>}::is_prefix_of" "_root_.Aeneas.Std.core.str.pattern.PatternSharedStr.is_prefix_of";
  (* file: "Aeneas/Std/StringIter.lean", line: 55 *)
  mk_fun "core::str::pattern::{core::str::pattern::Pattern<[char; @N]>}::is_prefix_of" "_root_.Aeneas.Std.core.str.pattern.PatternCharArray.is_prefix_of";
  (* file: "Aeneas/Std/String.lean", line: 415 *)
  mk_fun "core::str::pattern::{core::str::pattern::Pattern<char>}::is_prefix_of" "_root_.Aeneas.Std.core.str.pattern.PatternChar.is_prefix_of";
  (* file: "Aeneas/Std/StringIter.lean", line: 30 *)
  mk_fun "core::str::pattern::{core::str::pattern::Searcher<'a, core::str::pattern::CharArraySearcher<'a, @N>>}::haystack" "_root_.Aeneas.Std.core.str.pattern.SearcherCharArraySearcher.haystack";
  (* file: "Aeneas/Std/String.lean", line: 378 *)
  mk_fun "core::str::pattern::{core::str::pattern::Searcher<'a, core::str::pattern::CharSearcher<'a>>}::haystack" "_root_.Aeneas.Std.core.str.pattern.SearcherCharSearcher.haystack";
  (* file: "Aeneas/Std/String.lean", line: 358 *)
  mk_fun "core::str::pattern::{core::str::pattern::Searcher<'a, core::str::pattern::StrSearcher<'a, 'b>>}::haystack" "_root_.Aeneas.Std.core.str.pattern.SearcherStrSearcher.haystack";
  (* file: "Aeneas/Std/String.lean", line: 153 *)
  mk_fun "core::str::traits::{core::cmp::Eq<str>}::assert_receiver_is_total_eq" "_root_.Aeneas.Std.core.str.traits.EqStr.assert_receiver_is_total_eq";
  (* file: "Aeneas/Std/String.lean", line: 183 *)
  mk_fun "core::str::traits::{core::cmp::Ord<str>}::cmp" "_root_.Aeneas.Std.core.str.traits.OrdStr.cmp";
  (* file: "Aeneas/Std/String.lean", line: 130 *)
  mk_fun "core::str::traits::{core::cmp::PartialEq<str, str>}::eq" "_root_.Aeneas.Std.core.str.traits.PartialEqStr.eq";
  (* file: "Aeneas/Std/String.lean", line: 134 *)
  mk_fun "core::str::traits::{core::cmp::PartialEq<str, str>}::ne" "_root_.Aeneas.Std.core.str.traits.PartialEqStr.ne";
  (* file: "Aeneas/Std/String.lean", line: 187 *)
  mk_fun "core::str::traits::{core::cmp::PartialOrd<str, str>}::partial_cmp" "_root_.Aeneas.Std.core.str.traits.PartialOrdStr.partial_cmp";
  (* file: "Aeneas/Std/StringIter.lean", line: 487 *)
  mk_fun "core::str::traits::{core::ops::index::Index<str, @I, @O>}::index" "_root_.Aeneas.Std.core.str.traits.IndexStr.index";
  (* file: "Aeneas/Std/StringIter.lean", line: 493 *)
  mk_fun "core::str::traits::{core::ops::index::IndexMut<str, @I, @O>}::index_mut" "_root_.Aeneas.Std.core.str.traits.IndexMutStr.index_mut";
  (* file: "Aeneas/Std/StringIter.lean", line: 773 *)
  mk_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::Range<usize>, str, str>}::get" "_root_.Aeneas.Std.core.str.traits.SliceIndexRangeUsizeStr.get";
  (* file: "Aeneas/Std/StringIter.lean", line: 779 *)
  mk_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::Range<usize>, str, str>}::get_mut" "_root_.Aeneas.Std.core.str.traits.SliceIndexRangeUsizeStr.get_mut";
  (* file: "Aeneas/Std/StringIter.lean", line: 788 *)
  mk_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::Range<usize>, str, str>}::get_unchecked" "_root_.Aeneas.Std.core.str.traits.SliceIndexRangeUsizeStr.get_unchecked";
  (* file: "Aeneas/Std/StringIter.lean", line: 793 *)
  mk_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::Range<usize>, str, str>}::get_unchecked_mut" "_root_.Aeneas.Std.core.str.traits.SliceIndexRangeUsizeStr.get_unchecked_mut";
  (* file: "Aeneas/Std/StringIter.lean", line: 798 *)
  mk_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::Range<usize>, str, str>}::index" "_root_.Aeneas.Std.core.str.traits.SliceIndexRangeUsizeStr.index";
  (* file: "Aeneas/Std/StringIter.lean", line: 805 *)
  mk_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::Range<usize>, str, str>}::index_mut" "_root_.Aeneas.Std.core.str.traits.SliceIndexRangeUsizeStr.index_mut";
  (* file: "Aeneas/Std/StringIter.lean", line: 503 *)
  mk_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::RangeFrom<usize>, str, str>}::get" "_root_.Aeneas.Std.core.str.traits.SliceIndexRangeFromUsizeStr.get";
  (* file: "Aeneas/Std/StringIter.lean", line: 509 *)
  mk_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::RangeFrom<usize>, str, str>}::get_mut" "_root_.Aeneas.Std.core.str.traits.SliceIndexRangeFromUsizeStr.get_mut";
  (* file: "Aeneas/Std/StringIter.lean", line: 518 *)
  mk_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::RangeFrom<usize>, str, str>}::get_unchecked" "_root_.Aeneas.Std.core.str.traits.SliceIndexRangeFromUsizeStr.get_unchecked";
  (* file: "Aeneas/Std/StringIter.lean", line: 523 *)
  mk_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::RangeFrom<usize>, str, str>}::get_unchecked_mut" "_root_.Aeneas.Std.core.str.traits.SliceIndexRangeFromUsizeStr.get_unchecked_mut";
  (* file: "Aeneas/Std/StringIter.lean", line: 528 *)
  mk_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::RangeFrom<usize>, str, str>}::index" "_root_.Aeneas.Std.core.str.traits.SliceIndexRangeFromUsizeStr.index";
  (* file: "Aeneas/Std/StringIter.lean", line: 535 *)
  mk_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::RangeFrom<usize>, str, str>}::index_mut" "_root_.Aeneas.Std.core.str.traits.SliceIndexRangeFromUsizeStr.index_mut";
  (* file: "Aeneas/Std/StringIter.lean", line: 557 *)
  mk_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::RangeTo<usize>, str, str>}::get" "_root_.Aeneas.Std.core.str.traits.SliceIndexRangeToUsizeStr.get";
  (* file: "Aeneas/Std/StringIter.lean", line: 563 *)
  mk_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::RangeTo<usize>, str, str>}::get_mut" "_root_.Aeneas.Std.core.str.traits.SliceIndexRangeToUsizeStr.get_mut";
  (* file: "Aeneas/Std/StringIter.lean", line: 572 *)
  mk_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::RangeTo<usize>, str, str>}::get_unchecked" "_root_.Aeneas.Std.core.str.traits.SliceIndexRangeToUsizeStr.get_unchecked";
  (* file: "Aeneas/Std/StringIter.lean", line: 577 *)
  mk_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::RangeTo<usize>, str, str>}::get_unchecked_mut" "_root_.Aeneas.Std.core.str.traits.SliceIndexRangeToUsizeStr.get_unchecked_mut";
  (* file: "Aeneas/Std/StringIter.lean", line: 582 *)
  mk_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::RangeTo<usize>, str, str>}::index" "_root_.Aeneas.Std.core.str.traits.SliceIndexRangeToUsizeStr.index";
  (* file: "Aeneas/Std/StringIter.lean", line: 588 *)
  mk_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::RangeTo<usize>, str, str>}::index_mut" "_root_.Aeneas.Std.core.str.traits.SliceIndexRangeToUsizeStr.index_mut";
  (* file: "Aeneas/Std/StringIter.lean", line: 880 *)
  mk_fun "core::str::{core::default::Default<&'0 str>}::default" "_root_.Aeneas.Std.core.str.DefaultSharedStr.default";
  (* file: "Aeneas/Std/StringIter.lean", line: 297 *)
  mk_fun "core::str::{str}::as_bytes" "_root_.Aeneas.Std.core.str.Str.as_bytes";
  (* file: "Aeneas/Std/StringIter.lean", line: 694 *)
  mk_fun "core::str::{str}::bytes" "_root_.Aeneas.Std.core.str.Str.bytes";
  (* file: "Aeneas/Std/StringIter.lean", line: 164 *)
  mk_fun "core::str::{str}::chars" "_root_.Aeneas.Std.core.str.Str.chars";
  (* file: "Aeneas/Std/String.lean", line: 449 *)
  mk_fun "core::str::{str}::contains" "_root_.Aeneas.Std.core.str.Str.contains";
  (* file: "Aeneas/Std/StringIter.lean", line: 351 *)
  mk_fun "core::str::{str}::ends_with" "_root_.Aeneas.Std.core.str.Str.ends_with" ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/StringIter.lean", line: 759 *)
  mk_fun "core::str::{str}::get" "_root_.Aeneas.Std.core.str.Str.get";
  (* file: "Aeneas/Std/StringIter.lean", line: 474 *)
  mk_fun "core::str::{str}::is_char_boundary" "_root_.Aeneas.Std.core.str.Str.is_char_boundary";
  (* file: "Aeneas/Std/String.lean", line: 235 *)
  mk_fun "core::str::{str}::is_empty" "_root_.Aeneas.Std.core.str.Str.is_empty";
  (* file: "Aeneas/Std/String.lean", line: 240 *)
  mk_fun "core::str::{str}::len" "_root_.Aeneas.Std.core.str.Str.len";
  (* file: "Aeneas/Std/StringIter.lean", line: 178 *)
  mk_fun "core::str::{str}::lines" "_root_.Aeneas.Std.core.str.Str.lines";
  (* file: "Aeneas/Std/Parse.lean", line: 24 *)
  mk_fun "core::str::{str}::parse" "_root_.Aeneas.Std.core.str.Str.parse";
  (* file: "Aeneas/Std/StringIter.lean", line: 364 *)
  mk_fun "core::str::{str}::rfind" "_root_.Aeneas.Std.core.str.Str.rfind" ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/StringIter.lean", line: 841 *)
  mk_fun "core::str::{str}::rsplit" "_root_.Aeneas.Std.core.str.Str.rsplit" ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/StringIter.lean", line: 283 *)
  mk_fun "core::str::{str}::rsplit_once" "_root_.Aeneas.Std.core.str.Str.rsplit_once" ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/StringIter.lean", line: 268 *)
  mk_fun "core::str::{str}::split" "_root_.Aeneas.Std.core.str.Str.split";
  (* file: "Aeneas/Std/StringIter.lean", line: 303 *)
  mk_fun "core::str::{str}::split_once" "_root_.Aeneas.Std.core.str.Str.split_once";
  (* file: "Aeneas/Std/StringIter.lean", line: 655 *)
  mk_fun "core::str::{str}::splitn" "_root_.Aeneas.Std.core.str.Str.splitn";
  (* file: "Aeneas/Std/String.lean", line: 430 *)
  mk_fun "core::str::{str}::starts_with" "_root_.Aeneas.Std.core.str.Str.starts_with";
  (* file: "Aeneas/Std/StringIter.lean", line: 321 *)
  mk_fun "core::str::{str}::strip_prefix" "_root_.Aeneas.Std.core.str.Str.strip_prefix";
  (* file: "Aeneas/Std/StringIter.lean", line: 334 *)
  mk_fun "core::str::{str}::strip_suffix" "_root_.Aeneas.Std.core.str.Str.strip_suffix" ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/StringIter.lean", line: 433 *)
  mk_fun "core::str::{str}::trim" "_root_.Aeneas.Std.core.str.Str.trim";
  (* file: "Aeneas/Std/StringIter.lean", line: 405 *)
  mk_fun "core::str::{str}::trim_end_matches" "_root_.Aeneas.Std.core.str.Str.trim_end_matches" ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/StringIter.lean", line: 393 *)
  mk_fun "core::str::{str}::trim_start_matches" "_root_.Aeneas.Std.core.str.Str.trim_start_matches";
  (* file: "Aeneas/Std/Tuple.lean", line: 111 *)
  mk_fun "core::tuple::{core::cmp::Ord<(@U, @T)>}::cmp" "_root_.Aeneas.Std.core.tuple.OrdPair.cmp";
  (* file: "Aeneas/Std/Tuple.lean", line: 7 *)
  mk_fun "core::tuple::{core::cmp::PartialEq<(@U, @T), (@U, @T)>}::eq" "_root_.Aeneas.Std.core.tuple.PartialEqPair.eq";
  (* file: "Aeneas/Std/Tuple.lean", line: 14 *)
  mk_fun "core::tuple::{core::cmp::PartialEq<(@U, @T), (@U, @T)>}::ne" "_root_.Aeneas.Std.core.tuple.PartialEqPair.ne";
  (* file: "Aeneas/Std/Tuple.lean", line: 22 *)
  mk_fun "core::tuple::{core::cmp::PartialEq<(@V, @U, @T), (@V, @U, @T)>}::eq" "_root_.Aeneas.Std.core.tuple.PartialEqTriple.eq";
  (* file: "Aeneas/Std/Tuple.lean", line: 32 *)
  mk_fun "core::tuple::{core::cmp::PartialEq<(@W, @V, @U, @T), (@W, @V, @U, @T)>}::eq" "_root_.Aeneas.Std.core.tuple.PartialEqQuad.eq";
  (* file: "Aeneas/Std/Tuple.lean", line: 91 *)
  mk_fun "core::tuple::{core::cmp::PartialOrd<(@U, @T), (@U, @T)>}::ge" "_root_.Aeneas.Std.core.tuple.PartialOrdPair.ge";
  (* file: "Aeneas/Std/Tuple.lean", line: 83 *)
  mk_fun "core::tuple::{core::cmp::PartialOrd<(@U, @T), (@U, @T)>}::gt" "_root_.Aeneas.Std.core.tuple.PartialOrdPair.gt";
  (* file: "Aeneas/Std/Tuple.lean", line: 75 *)
  mk_fun "core::tuple::{core::cmp::PartialOrd<(@U, @T), (@U, @T)>}::le" "_root_.Aeneas.Std.core.tuple.PartialOrdPair.le";
  (* file: "Aeneas/Std/Tuple.lean", line: 67 *)
  mk_fun "core::tuple::{core::cmp::PartialOrd<(@U, @T), (@U, @T)>}::lt" "_root_.Aeneas.Std.core.tuple.PartialOrdPair.lt";
  (* file: "Aeneas/Std/Tuple.lean", line: 57 *)
  mk_fun "core::tuple::{core::cmp::PartialOrd<(@U, @T), (@U, @T)>}::partial_cmp" "_root_.Aeneas.Std.core.tuple.PartialOrdPair.partial_cmp";
  (* file: "Aeneas/Std/Float.lean", line: 630 *)
  mk_fun "half::bfloat::{core::clone::Clone<half::bfloat::bf16>}::clone" "_root_.Aeneas.Std.BF16.clone";
  (* file: "Aeneas/Std/Half.lean", line: 384 *)
  mk_fun "half::bfloat::{core::cmp::PartialEq<half::bfloat::bf16, half::bfloat::bf16>}::eq" "_root_.Aeneas.Std.half.bfloat.PartialEqBF16.eq";
  (* file: "Aeneas/Std/Half.lean", line: 403 *)
  mk_fun "half::bfloat::{core::cmp::PartialOrd<half::bfloat::bf16, half::bfloat::bf16>}::ge" "_root_.Aeneas.Std.half.bfloat.PartialOrdBF16.ge";
  (* file: "Aeneas/Std/Half.lean", line: 400 *)
  mk_fun "half::bfloat::{core::cmp::PartialOrd<half::bfloat::bf16, half::bfloat::bf16>}::gt" "_root_.Aeneas.Std.half.bfloat.PartialOrdBF16.gt";
  (* file: "Aeneas/Std/Half.lean", line: 397 *)
  mk_fun "half::bfloat::{core::cmp::PartialOrd<half::bfloat::bf16, half::bfloat::bf16>}::le" "_root_.Aeneas.Std.half.bfloat.PartialOrdBF16.le";
  (* file: "Aeneas/Std/Half.lean", line: 394 *)
  mk_fun "half::bfloat::{core::cmp::PartialOrd<half::bfloat::bf16, half::bfloat::bf16>}::lt" "_root_.Aeneas.Std.half.bfloat.PartialOrdBF16.lt";
  (* file: "Aeneas/Std/Half.lean", line: 391 *)
  mk_fun "half::bfloat::{core::cmp::PartialOrd<half::bfloat::bf16, half::bfloat::bf16>}::partial_cmp" "_root_.Aeneas.Std.half.bfloat.PartialOrdBF16.partial_cmp";
  (* file: "Aeneas/Std/Half.lean", line: 379 *)
  mk_fun "half::bfloat::{core::convert::From<f64, half::bfloat::bf16>}::from" "_root_.Aeneas.Std.half.bfloat.FromF64BF16.from_";
  (* file: "Aeneas/Std/FloatFmt.lean", line: 221 *)
  mk_fun "half::bfloat::{core::fmt::Debug<half::bfloat::bf16>}::fmt" "_root_.Aeneas.Std.core.fmt.DebugBF16.fmt";
  (* file: "Aeneas/Std/FloatFmt.lean", line: 225 *)
  mk_fun "half::bfloat::{core::fmt::Display<half::bfloat::bf16>}::fmt" "_root_.Aeneas.Std.core.fmt.DisplayBF16.fmt";
  (* file: "Aeneas/Std/Float.lean", line: 626 *)
  mk_fun "half::bfloat::{half::bfloat::bf16}::from_bits" "_root_.Aeneas.Std.BF16.from_bits";
  (* file: "Aeneas/Std/Half.lean", line: 350 *)
  mk_fun "half::bfloat::{half::bfloat::bf16}::from_f32" "_root_.Aeneas.Std.BF16.from_f32";
  (* file: "Aeneas/Std/Half.lean", line: 352 *)
  mk_fun "half::bfloat::{half::bfloat::bf16}::from_f64" "_root_.Aeneas.Std.BF16.from_f64";
  (* file: "Aeneas/Std/Half.lean", line: 361 *)
  mk_fun "half::bfloat::{half::bfloat::bf16}::is_finite" "_root_.Aeneas.Std.BF16.is_finite";
  (* file: "Aeneas/Std/Half.lean", line: 358 *)
  mk_fun "half::bfloat::{half::bfloat::bf16}::is_nan" "_root_.Aeneas.Std.BF16.is_nan";
  (* file: "Aeneas/Std/Float.lean", line: 628 *)
  mk_fun "half::bfloat::{half::bfloat::bf16}::to_bits" "_root_.Aeneas.Std.BF16.to_bits";
  (* file: "Aeneas/Std/Half.lean", line: 354 *)
  mk_fun "half::bfloat::{half::bfloat::bf16}::to_f32" "_root_.Aeneas.Std.BF16.to_f32";
  (* file: "Aeneas/Std/Half.lean", line: 356 *)
  mk_fun "half::bfloat::{half::bfloat::bf16}::to_f64" "_root_.Aeneas.Std.BF16.to_f64";
  (* file: "Aeneas/Std/Float.lean", line: 613 *)
  mk_fun "half::binary16::{core::clone::Clone<half::binary16::f16>}::clone" "_root_.Aeneas.Std.F16.clone";
  (* file: "Aeneas/Std/Half.lean", line: 311 *)
  mk_fun "half::binary16::{core::cmp::PartialEq<half::binary16::f16, half::binary16::f16>}::eq" "_root_.Aeneas.Std.half.binary16.PartialEqF16.eq";
  (* file: "Aeneas/Std/Half.lean", line: 330 *)
  mk_fun "half::binary16::{core::cmp::PartialOrd<half::binary16::f16, half::binary16::f16>}::ge" "_root_.Aeneas.Std.half.binary16.PartialOrdF16.ge";
  (* file: "Aeneas/Std/Half.lean", line: 327 *)
  mk_fun "half::binary16::{core::cmp::PartialOrd<half::binary16::f16, half::binary16::f16>}::gt" "_root_.Aeneas.Std.half.binary16.PartialOrdF16.gt";
  (* file: "Aeneas/Std/Half.lean", line: 324 *)
  mk_fun "half::binary16::{core::cmp::PartialOrd<half::binary16::f16, half::binary16::f16>}::le" "_root_.Aeneas.Std.half.binary16.PartialOrdF16.le";
  (* file: "Aeneas/Std/Half.lean", line: 321 *)
  mk_fun "half::binary16::{core::cmp::PartialOrd<half::binary16::f16, half::binary16::f16>}::lt" "_root_.Aeneas.Std.half.binary16.PartialOrdF16.lt";
  (* file: "Aeneas/Std/Half.lean", line: 318 *)
  mk_fun "half::binary16::{core::cmp::PartialOrd<half::binary16::f16, half::binary16::f16>}::partial_cmp" "_root_.Aeneas.Std.half.binary16.PartialOrdF16.partial_cmp";
  (* file: "Aeneas/Std/Half.lean", line: 306 *)
  mk_fun "half::binary16::{core::convert::From<f64, half::binary16::f16>}::from" "_root_.Aeneas.Std.half.binary16.FromF64F16.from_";
  (* file: "Aeneas/Std/FloatFmt.lean", line: 212 *)
  mk_fun "half::binary16::{core::fmt::Debug<half::binary16::f16>}::fmt" "_root_.Aeneas.Std.core.fmt.DebugF16.fmt";
  (* file: "Aeneas/Std/FloatFmt.lean", line: 216 *)
  mk_fun "half::binary16::{core::fmt::Display<half::binary16::f16>}::fmt" "_root_.Aeneas.Std.core.fmt.DisplayF16.fmt";
  (* file: "Aeneas/Std/Float.lean", line: 609 *)
  mk_fun "half::binary16::{half::binary16::f16}::from_bits" "_root_.Aeneas.Std.F16.from_bits";
  (* file: "Aeneas/Std/Half.lean", line: 258 *)
  mk_fun "half::binary16::{half::binary16::f16}::from_f32" "_root_.Aeneas.Std.F16.from_f32";
  (* file: "Aeneas/Std/Half.lean", line: 270 *)
  mk_fun "half::binary16::{half::binary16::f16}::from_f64" "_root_.Aeneas.Std.F16.from_f64";
  (* file: "Aeneas/Std/Half.lean", line: 288 *)
  mk_fun "half::binary16::{half::binary16::f16}::is_finite" "_root_.Aeneas.Std.F16.is_finite";
  (* file: "Aeneas/Std/Half.lean", line: 285 *)
  mk_fun "half::binary16::{half::binary16::f16}::is_nan" "_root_.Aeneas.Std.F16.is_nan";
  (* file: "Aeneas/Std/Float.lean", line: 611 *)
  mk_fun "half::binary16::{half::binary16::f16}::to_bits" "_root_.Aeneas.Std.F16.to_bits";
  (* file: "Aeneas/Std/Half.lean", line: 281 *)
  mk_fun "half::binary16::{half::binary16::f16}::to_f32" "_root_.Aeneas.Std.F16.to_f32";
  (* file: "Aeneas/Std/Half.lean", line: 283 *)
  mk_fun "half::binary16::{half::binary16::f16}::to_f64" "_root_.Aeneas.Std.F16.to_f64";
  (* file: "Aeneas/Std/BigUint.lean", line: 40 *)
  mk_fun "num_bigint::biguint::convert::{core::convert::From<num_bigint::biguint::BigUint, u128>}::from" "_root_.Aeneas.Std.num_bigint.BigUint.FromU128.from_";
  (* file: "Aeneas/Std/BigUint.lean", line: 32 *)
  mk_fun "num_bigint::biguint::convert::{core::convert::From<num_bigint::biguint::BigUint, u16>}::from" "_root_.Aeneas.Std.num_bigint.BigUint.FromU16.from_";
  (* file: "Aeneas/Std/BigUint.lean", line: 34 *)
  mk_fun "num_bigint::biguint::convert::{core::convert::From<num_bigint::biguint::BigUint, u32>}::from" "_root_.Aeneas.Std.num_bigint.BigUint.FromU32.from_";
  (* file: "Aeneas/Std/BigUint.lean", line: 36 *)
  mk_fun "num_bigint::biguint::convert::{core::convert::From<num_bigint::biguint::BigUint, u64>}::from" "_root_.Aeneas.Std.num_bigint.BigUint.FromU64.from_";
  (* file: "Aeneas/Std/BigUint.lean", line: 30 *)
  mk_fun "num_bigint::biguint::convert::{core::convert::From<num_bigint::biguint::BigUint, u8>}::from" "_root_.Aeneas.Std.num_bigint.BigUint.FromU8.from_";
  (* file: "Aeneas/Std/BigUint.lean", line: 38 *)
  mk_fun "num_bigint::biguint::convert::{core::convert::From<num_bigint::biguint::BigUint, usize>}::from" "_root_.Aeneas.Std.num_bigint.BigUint.FromUsize.from_";
  (* file: "Aeneas/Std/BigUint.lean", line: 45 *)
  mk_fun "num_bigint::biguint::convert::{core::convert::TryFrom<u64, num_bigint::biguint::BigUint, num_bigint::TryFromBigIntError<num_bigint::biguint::BigUint>>}::try_from" "_root_.Aeneas.Std.num_bigint.BigUint.TryFromU64.try_from";
  (* file: "Aeneas/Std/BigUint.lean", line: 51 *)
  mk_fun "num_bigint::biguint::convert::{core::convert::TryFrom<usize, num_bigint::biguint::BigUint, num_bigint::TryFromBigIntError<num_bigint::biguint::BigUint>>}::try_from" "_root_.Aeneas.Std.num_bigint.BigUint.TryFromUsize.try_from";
  (* file: "Aeneas/Std/BigUint.lean", line: 62 *)
  mk_fun "num_bigint::biguint::division::{core::ops::arith::Div<&'a num_bigint::biguint::BigUint, &'b num_bigint::biguint::BigUint, num_bigint::biguint::BigUint>}::div" "_root_.Aeneas.Std.num_bigint.BigUint.DivShared.div";
  (* file: "Aeneas/Std/BigUint.lean", line: 65 *)
  mk_fun "num_bigint::biguint::division::{core::ops::arith::Div<num_bigint::biguint::BigUint, num_bigint::biguint::BigUint, num_bigint::biguint::BigUint>}::div" "_root_.Aeneas.Std.num_bigint.BigUint.DivBigUint.div";
  (* file: "Aeneas/Std/BigUint.lean", line: 71 *)
  mk_fun "num_bigint::biguint::division::{core::ops::arith::Rem<&'a num_bigint::biguint::BigUint, &'b num_bigint::biguint::BigUint, num_bigint::biguint::BigUint>}::rem" "_root_.Aeneas.Std.num_bigint.BigUint.RemShared.rem";
  (* file: "Aeneas/Std/BigUint.lean", line: 74 *)
  mk_fun "num_bigint::biguint::division::{core::ops::arith::Rem<num_bigint::biguint::BigUint, num_bigint::biguint::BigUint, num_bigint::biguint::BigUint>}::rem" "_root_.Aeneas.Std.num_bigint.BigUint.RemBigUint.rem";
  (* file: "Aeneas/Std/BigUint.lean", line: 58 *)
  mk_fun "num_bigint::biguint::multiplication::{core::ops::arith::Mul<&'a num_bigint::biguint::BigUint, &'b num_bigint::biguint::BigUint, num_bigint::biguint::BigUint>}::mul" "_root_.Aeneas.Std.num_bigint.BigUint.MulShared.mul";
  (* file: "Aeneas/Std/BigUint.lean", line: 56 *)
  mk_fun "num_bigint::biguint::multiplication::{core::ops::arith::Mul<num_bigint::biguint::BigUint, num_bigint::biguint::BigUint, num_bigint::biguint::BigUint>}::mul" "_root_.Aeneas.Std.num_bigint.BigUint.MulBigUint.mul";
  (* file: "Aeneas/Std/BigUint.lean", line: 78 *)
  mk_fun "num_bigint::biguint::{core::clone::Clone<num_bigint::biguint::BigUint>}::clone" "_root_.Aeneas.Std.num_bigint.BigUint.CloneBigUint.clone";
  (* file: "Aeneas/Std/BigUint.lean", line: 87 *)
  mk_fun "num_bigint::biguint::{core::cmp::Ord<num_bigint::biguint::BigUint>}::cmp" "_root_.Aeneas.Std.num_bigint.BigUint.OrdBigUint.cmp";
  (* file: "Aeneas/Std/BigUint.lean", line: 82 *)
  mk_fun "num_bigint::biguint::{core::cmp::PartialEq<num_bigint::biguint::BigUint, num_bigint::biguint::BigUint>}::eq" "_root_.Aeneas.Std.num_bigint.BigUint.PartialEqBigUint.eq";
  (* file: "Aeneas/Std/BigUint.lean", line: 91 *)
  mk_fun "num_bigint::biguint::{core::cmp::PartialOrd<num_bigint::biguint::BigUint, num_bigint::biguint::BigUint>}::partial_cmp" "_root_.Aeneas.Std.num_bigint.BigUint.PartialOrdBigUint.partial_cmp";
  (* file: "Aeneas/Std/BigUint.lean", line: 175 *)
  mk_fun "num_bigint::biguint::{core::fmt::Debug<num_bigint::biguint::BigUint>}::fmt" "_root_.Aeneas.Std.num_bigint.BigUint.DebugBigUint.fmt";
  (* file: "Aeneas/Std/BigUint.lean", line: 168 *)
  mk_fun "num_bigint::biguint::{core::fmt::Display<num_bigint::biguint::BigUint>}::fmt" "_root_.Aeneas.Std.num_bigint.BigUint.DisplayBigUint.fmt";
  (* file: "Aeneas/Std/BigUint.lean", line: 104 *)
  mk_fun "num_bigint::biguint::{core::hash::Hash<num_bigint::biguint::BigUint>}::hash" "_root_.Aeneas.Std.num_bigint.BigUint.HashBigUint.hash";
  (* file: "Aeneas/Std/Serde/Content.lean", line: 414 *)
  mk_fun "serde::private::de::content::{serde::private::de::content::ContentDeserializer<'de, @E>}::new" "_root_.Aeneas.Std.serde.private.de.content.ContentDeserializer.new";
  (* file: "Aeneas/Std/Serde/Content.lean", line: 45 *)
  mk_fun "serde::private::de::content::{serde::private::de::content::ContentVisitor<'de>}::new" "_root_.Aeneas.Std.serde.private.de.content.ContentVisitor.new";
  (* file: "Aeneas/Std/Serde/Content.lean", line: 312 *)
  mk_fun "serde::private::de::content::{serde::private::de::content::TaggedContentVisitor<@T>}::new" "_root_.Aeneas.Std.serde.private.de.content.TaggedContentVisitor.new";
  (* file: "Aeneas/Std/Serde/Content.lean", line: 160 *)
  mk_fun "serde::private::de::content::{serde_core::de::DeserializeSeed<'de, serde::private::de::content::ContentVisitor<'de>, serde_core::private::content::Content<'de>>}::deserialize" "_root_.Aeneas.Std.serde.private.de.content.DeserializeSeedContentVisitor.deserialize";
  (* file: "Aeneas/Std/Serde/Content.lean", line: 907 *)
  mk_fun "serde::private::de::content::{serde_core::de::Deserializer<'de, serde::private::de::content::ContentDeserializer<'de, @E>, @E>}::deserialize_any" "_root_.Aeneas.Std.serde.private.de.content.DeserializerContentDeserializer.deserialize_any";
  (* file: "Aeneas/Std/Serde/Content.lean", line: 383 *)
  mk_fun "serde::private::de::content::{serde_core::de::Visitor<'de, serde::private::de::content::TaggedContentVisitor<@T>, (@T, serde_core::private::content::Content<'de>)>}::expecting" "_root_.Aeneas.Std.serde.private.de.content.VisitorTaggedContentVisitor.expecting";
  (* file: "Aeneas/Std/Serde/Content.lean", line: 348 *)
  mk_fun "serde::private::de::content::{serde_core::de::Visitor<'de, serde::private::de::content::TaggedContentVisitor<@T>, (@T, serde_core::private::content::Content<'de>)>}::visit_map" "_root_.Aeneas.Std.serde.private.de.content.VisitorTaggedContentVisitor.visit_map";
  (* file: "Aeneas/Std/Serde/Content.lean", line: 365 *)
  mk_fun "serde::private::de::content::{serde_core::de::Visitor<'de, serde::private::de::content::TaggedContentVisitor<@T>, (@T, serde_core::private::content::Content<'de>)>}::visit_seq" "_root_.Aeneas.Std.serde.private.de.content.VisitorTaggedContentVisitor.visit_seq";
  (* file: "Aeneas/Std/Serde/Private.lean", line: 86 *)
  mk_fun "serde::private::de::missing_field" "_root_.Aeneas.Std.serde.private.de.missing_field";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 920 *)
  mk_fun "serde_core::de::ignored_any::{serde_core::de::Deserialize<'de, serde_core::de::ignored_any::IgnoredAny>}::deserialize" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeIgnoredAny.deserialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 648 *)
  mk_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, ()>}::deserialize" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeUnit.deserialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 367 *)
  mk_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, (@T0, @T1)>}::deserialize" "_root_.Aeneas.Std.serde_core.de.impls.DeserializePair.deserialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 772 *)
  mk_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, Box<@T>>}::deserialize" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeBox.deserialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 836 *)
  mk_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, [@T; 32]>}::deserialize" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeArray32.deserialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 754 *)
  mk_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, alloc::collections::btree::map::BTreeMap<@K, @V, alloc::alloc::Global>>}::deserialize" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeBTreeMap.deserialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 723 *)
  mk_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, alloc::collections::btree::set::BTreeSet<@T, alloc::alloc::Global>>}::deserialize" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeBTreeSet.deserialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 437 *)
  mk_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, alloc::string::String>}::deserialize" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeString.deserialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 784 *)
  mk_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, alloc::sync::Arc<@T>>}::deserialize" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeArc.deserialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 697 *)
  mk_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, alloc::vec::Vec<@T>>}::deserialize" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeVec.deserialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 633 *)
  mk_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, bool>}::deserialize" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeBool.deserialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 462 *)
  mk_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, core::option::Option<@T>>}::deserialize" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeOption.deserialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 618 *)
  mk_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, f64>}::deserialize" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeF64.deserialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 534 *)
  mk_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, i16>}::deserialize" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeI16.deserialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 544 *)
  mk_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, i32>}::deserialize" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeI32.deserialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 554 *)
  mk_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, i64>}::deserialize" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeI64.deserialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 524 *)
  mk_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, i8>}::deserialize" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeI8.deserialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 409 *)
  mk_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, u32>}::deserialize" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeU32.deserialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 574 *)
  mk_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, u64>}::deserialize" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeU64.deserialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 564 *)
  mk_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, u8>}::deserialize" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeU8.deserialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 584 *)
  mk_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, usize>}::deserialize" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeUsize.deserialize";
  (* file: "Aeneas/Std/Serde/Content.lean", line: 191 *)
  mk_fun "serde_core::de::value::{serde_core::de::value::SeqAccessDeserializer<@A>}::new" "_root_.Aeneas.Std.serde_core.de.value.SeqAccessDeserializer.new";
  (* file: "Aeneas/Std/Serde/De.lean", line: 133 *)
  mk_fun "serde_core::de::{serde_core::de::Expected<&'0 str>}::fmt" "_root_.Aeneas.Std.serde_core.de.ExpectedSharedStr.fmt";
  (* file: "Aeneas/Std/Serde/Private.lean", line: 93 *)
  mk_fun "serde_core::private::string::from_utf8_lossy" "_root_.Aeneas.Std.serde_core.private.string.from_utf8_lossy";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 47 *)
  mk_fun "serde_core::ser::impls::{serde_core::ser::Serialize<&'a @T>}::serialize" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeShared.serialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 239 *)
  mk_fun "serde_core::ser::impls::{serde_core::ser::Serialize<()>}::serialize" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeUnit.serialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 24 *)
  mk_fun "serde_core::ser::impls::{serde_core::ser::Serialize<(@T0, @T1)>}::serialize" "_root_.Aeneas.Std.serde_core.ser.impls.SerializePair.serialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 268 *)
  mk_fun "serde_core::ser::impls::{serde_core::ser::Serialize<Box<@T>>}::serialize" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeBox.serialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 326 *)
  mk_fun "serde_core::ser::impls::{serde_core::ser::Serialize<[@T; 32]>}::serialize" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeArray32.serialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 117 *)
  mk_fun "serde_core::ser::impls::{serde_core::ser::Serialize<alloc::collections::btree::map::BTreeMap<@K, @V, alloc::alloc::Global>>}::serialize" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeBTreeMap.serialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 99 *)
  mk_fun "serde_core::ser::impls::{serde_core::ser::Serialize<alloc::collections::btree::set::BTreeSet<@T, alloc::alloc::Global>>}::serialize" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeBTreeSet.serialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 70 *)
  mk_fun "serde_core::ser::impls::{serde_core::ser::Serialize<alloc::string::String>}::serialize" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeString.serialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 281 *)
  mk_fun "serde_core::ser::impls::{serde_core::ser::Serialize<alloc::sync::Arc<@T>>}::serialize" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeArc.serialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 84 *)
  mk_fun "serde_core::ser::impls::{serde_core::ser::Serialize<alloc::vec::Vec<@T>>}::serialize" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeVec.serialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 136 *)
  mk_fun "serde_core::ser::impls::{serde_core::ser::Serialize<bool>}::serialize" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeBool.serialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 253 *)
  mk_fun "serde_core::ser::impls::{serde_core::ser::Serialize<core::option::Option<@T>>}::serialize" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeOption.serialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 206 *)
  mk_fun "serde_core::ser::impls::{serde_core::ser::Serialize<f64>}::serialize" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeF64.serialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 156 *)
  mk_fun "serde_core::ser::impls::{serde_core::ser::Serialize<i16>}::serialize" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeI16.serialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 166 *)
  mk_fun "serde_core::ser::impls::{serde_core::ser::Serialize<i32>}::serialize" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeI32.serialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 176 *)
  mk_fun "serde_core::ser::impls::{serde_core::ser::Serialize<i64>}::serialize" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeI64.serialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 146 *)
  mk_fun "serde_core::ser::impls::{serde_core::ser::Serialize<i8>}::serialize" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeI8.serialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 228 *)
  mk_fun "serde_core::ser::impls::{serde_core::ser::Serialize<str>}::serialize" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeStr.serialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 59 *)
  mk_fun "serde_core::ser::impls::{serde_core::ser::Serialize<u32>}::serialize" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeU32.serialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 196 *)
  mk_fun "serde_core::ser::impls::{serde_core::ser::Serialize<u64>}::serialize" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeU64.serialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 186 *)
  mk_fun "serde_core::ser::impls::{serde_core::ser::Serialize<u8>}::serialize" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeU8.serialize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 217 *)
  mk_fun "serde_core::ser::impls::{serde_core::ser::Serialize<usize>}::serialize" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeUsize.serialize";
  (* file: "Aeneas/Std/Float.lean", line: 408 *)
  mk_fun "std::f32::{f32}::atan" "_root_.Aeneas.Std.F32.atan";
  (* file: "Aeneas/Std/Float.lean", line: 373 *)
  mk_fun "std::f32::{f32}::ceil" "_root_.Aeneas.Std.F32.ceil";
  (* file: "Aeneas/Std/Float.lean", line: 400 *)
  mk_fun "std::f32::{f32}::cos" "_root_.Aeneas.Std.F32.cos";
  (* file: "Aeneas/Std/Float.lean", line: 412 *)
  mk_fun "std::f32::{f32}::exp" "_root_.Aeneas.Std.F32.exp";
  (* file: "Aeneas/Std/Float.lean", line: 365 *)
  mk_fun "std::f32::{f32}::floor" "_root_.Aeneas.Std.F32.floor";
  (* file: "Aeneas/Std/Float.lean", line: 363 *)
  mk_fun "std::f32::{f32}::fract" "_root_.Aeneas.Std.F32.fract";
  (* file: "Aeneas/Std/Float.lean", line: 416 *)
  mk_fun "std::f32::{f32}::ln" "_root_.Aeneas.Std.F32.ln";
  (* file: "Aeneas/Std/Float.lean", line: 380 *)
  mk_fun "std::f32::{f32}::mul_add" "_root_.Aeneas.Std.F32.mul_add";
  (* file: "Aeneas/Std/Float.lean", line: 367 *)
  mk_fun "std::f32::{f32}::powi" "_root_.Aeneas.Std.F32.powi";
  (* file: "Aeneas/Std/Float.lean", line: 375 *)
  mk_fun "std::f32::{f32}::round_ties_even" "_root_.Aeneas.Std.F32.round_ties_even";
  (* file: "Aeneas/Std/Float.lean", line: 396 *)
  mk_fun "std::f32::{f32}::sin" "_root_.Aeneas.Std.F32.sin";
  (* file: "Aeneas/Std/Float.lean", line: 377 *)
  mk_fun "std::f32::{f32}::sqrt" "_root_.Aeneas.Std.F32.sqrt";
  (* file: "Aeneas/Std/Float.lean", line: 404 *)
  mk_fun "std::f32::{f32}::tan" "_root_.Aeneas.Std.F32.tan";
  (* file: "Aeneas/Std/Float.lean", line: 361 *)
  mk_fun "std::f32::{f32}::trunc" "_root_.Aeneas.Std.F32.trunc";
  (* file: "Aeneas/Std/Float.lean", line: 543 *)
  mk_fun "std::f64::{f64}::atan" "_root_.Aeneas.Std.F64.atan";
  (* file: "Aeneas/Std/Float.lean", line: 508 *)
  mk_fun "std::f64::{f64}::ceil" "_root_.Aeneas.Std.F64.ceil";
  (* file: "Aeneas/Std/Float.lean", line: 535 *)
  mk_fun "std::f64::{f64}::cos" "_root_.Aeneas.Std.F64.cos";
  (* file: "Aeneas/Std/Float.lean", line: 547 *)
  mk_fun "std::f64::{f64}::exp" "_root_.Aeneas.Std.F64.exp";
  (* file: "Aeneas/Std/Float.lean", line: 500 *)
  mk_fun "std::f64::{f64}::floor" "_root_.Aeneas.Std.F64.floor";
  (* file: "Aeneas/Std/Float.lean", line: 498 *)
  mk_fun "std::f64::{f64}::fract" "_root_.Aeneas.Std.F64.fract";
  (* file: "Aeneas/Std/Float.lean", line: 551 *)
  mk_fun "std::f64::{f64}::ln" "_root_.Aeneas.Std.F64.ln";
  (* file: "Aeneas/Std/Float.lean", line: 515 *)
  mk_fun "std::f64::{f64}::mul_add" "_root_.Aeneas.Std.F64.mul_add";
  (* file: "Aeneas/Std/Float.lean", line: 502 *)
  mk_fun "std::f64::{f64}::powi" "_root_.Aeneas.Std.F64.powi";
  (* file: "Aeneas/Std/Float.lean", line: 510 *)
  mk_fun "std::f64::{f64}::round_ties_even" "_root_.Aeneas.Std.F64.round_ties_even";
  (* file: "Aeneas/Std/Float.lean", line: 531 *)
  mk_fun "std::f64::{f64}::sin" "_root_.Aeneas.Std.F64.sin";
  (* file: "Aeneas/Std/Float.lean", line: 512 *)
  mk_fun "std::f64::{f64}::sqrt" "_root_.Aeneas.Std.F64.sqrt";
  (* file: "Aeneas/Std/Float.lean", line: 539 *)
  mk_fun "std::f64::{f64}::tan" "_root_.Aeneas.Std.F64.tan";
  (* file: "Aeneas/Std/Float.lean", line: 496 *)
  mk_fun "std::f64::{f64}::trunc" "_root_.Aeneas.Std.F64.trunc";
  (* file: "Aeneas/Std/Std/Io.lean", line: 5 *)
  mk_fun "std::io::stdio::_print" "_root_.Aeneas.Std.std.io.stdio._print";
  (* file: "Aeneas/Std/Thiserror.lean", line: 27 *)
  mk_fun "thiserror::aserror::{thiserror::aserror::AsDynError<'a, @T>}::as_dyn_error" "_root_.Aeneas.Std.thiserror.aserror.AsDynError.as_dyn_error";
  (* file: "Aeneas/Std/Thiserror.lean", line: 19 *)
  mk_fun "thiserror::display::{thiserror::display::AsDisplay<'a, &'0 @T, &'a @T>}::as_display" "_root_.Aeneas.Std.thiserror.display.AsDisplayShared.as_display";
]

let lean_builtin_trait_decls = [
  (* file: "Aeneas/Std/Core/Borrow.lean", line: 42 *)
  mk_trait_decl "alloc::borrow::ToOwned" "_root_.Aeneas.Std.alloc.borrow.ToOwned" ~parent_clauses:["coreborrowBorrowInst"] ~methods:[("to_owned", "to_owned"); ("clone_into", "clone_into")] ~default_methods:["clone_into"];
  (* file: "Aeneas/Std/StringJoin.lean", line: 5 *)
  mk_trait_decl "alloc::slice::Join" "_root_.Aeneas.Std.alloc.slice.Join" ~methods:[("join", "join")];
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 231 *)
  mk_trait_decl "alloc::string::ToString" "_root_.Aeneas.Std.alloc.string.ToString" ~methods:[("to_string", "to_string")];
  (* file: "Aeneas/Std/Core/Ptr.lean", line: 83 *)
  mk_trait_decl "core::alloc::global::GlobalAlloc" "_root_.Aeneas.Std.core.alloc.global.GlobalAlloc" ~methods:[("alloc", "alloc"); ("dealloc", "dealloc")];
  (* file: "Aeneas/Std/Core/Core.lean", line: 150 *)
  mk_trait_decl "core::any::Any" "_root_.Aeneas.Std.core.any.Any";
  (* file: "Aeneas/Std/Core/Borrow.lean", line: 8 *)
  mk_trait_decl "core::borrow::Borrow" "_root_.Aeneas.Std.core.borrow.Borrow" ~methods:[("borrow", "borrow")];
  (* file: "Aeneas/Std/Core/Core.lean", line: 102 *)
  mk_trait_decl "core::clone::Clone" "_root_.Aeneas.Std.core.clone.Clone" ~methods:[("clone", "clone"); ("clone_from", "clone_from")] ~default_methods:["clone_from"];
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 14 *)
  mk_trait_decl "core::cmp::Eq" "_root_.Aeneas.Std.core.cmp.Eq" ~parent_clauses:["partialEqInst"] ~methods:[("assert_receiver_is_total_eq", "assert_receiver_is_total_eq")] ~default_methods:["assert_receiver_is_total_eq"];
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 149 *)
  mk_trait_decl "core::cmp::Ord" "_root_.Aeneas.Std.core.cmp.Ord" ~parent_clauses:["eqInst"; "partialOrdInst"] ~methods:[("cmp", "cmp"); ("max", "max"); ("min", "min"); ("clamp", "clamp")] ~default_methods:["max"; "min"; "clamp"];
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 9 *)
  mk_trait_decl "core::cmp::PartialEq" "_root_.Aeneas.Std.core.cmp.PartialEq" ~methods:[("eq", "eq"); ("ne", "ne")] ~default_methods:["ne"];
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 70 *)
  mk_trait_decl "core::cmp::PartialOrd" "_root_.Aeneas.Std.core.cmp.PartialOrd" ~parent_clauses:["partialEqInst"] ~methods:[("partial_cmp", "partial_cmp"); ("lt", "lt"); ("le", "le"); ("gt", "gt"); ("ge", "ge"); ("__chaining_lt", "__chaining_lt"); ("__chaining_le", "__chaining_le"); ("__chaining_gt", "__chaining_gt"); ("__chaining_ge", "__chaining_ge")] ~default_methods:["lt"; "le"; "gt"; "ge"; "__chaining_lt"; "__chaining_le"; "__chaining_gt"; "__chaining_ge"];
  (* file: "Aeneas/Std/Core/Convert.lean", line: 78 *)
  mk_trait_decl "core::convert::AsMut" "_root_.Aeneas.Std.core.convert.AsMut" ~methods:[("as_mut", "as_mut")];
  (* file: "Aeneas/Std/Core/Core.lean", line: 49 *)
  mk_trait_decl "core::convert::From" "_root_.Aeneas.Std.core.convert.From" ~methods:[("from", "from_")];
  (* file: "Aeneas/Std/Core/Convert.lean", line: 16 *)
  mk_trait_decl "core::convert::Into" "_root_.Aeneas.Std.core.convert.Into" ~methods:[("into", "into")];
  (* file: "Aeneas/Std/Core/Convert.lean", line: 31 *)
  mk_trait_decl "core::convert::TryFrom" "_root_.Aeneas.Std.core.convert.TryFrom" ~methods:[("try_from", "try_from")];
  (* file: "Aeneas/Std/Core/Convert.lean", line: 56 *)
  mk_trait_decl "core::convert::TryInto" "_root_.Aeneas.Std.core.convert.TryInto" ~methods:[("try_into", "try_into")];
  (* file: "Aeneas/Std/Core/Default.lean", line: 5 *)
  mk_trait_decl "core::default::Default" "_root_.Aeneas.Std.core.default.Default" ~methods:[("default", "default")];
  (* file: "Aeneas/Std/Core/Error.lean", line: 5 *)
  mk_trait_decl "core::error::Error" "_root_.Aeneas.Std.core.error.Error" ~parent_clauses:["fmtDebugInst"; "fmtDisplayInst"];
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 112 *)
  mk_trait_decl "core::fmt::Debug" "_root_.Aeneas.Std.core.fmt.Debug" ~methods:[("fmt", "fmt")];
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 116 *)
  mk_trait_decl "core::fmt::Display" "_root_.Aeneas.Std.core.fmt.Display" ~methods:[("fmt", "fmt")];
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 128 *)
  mk_trait_decl "core::fmt::LowerExp" "_root_.Aeneas.Std.core.fmt.LowerExp" ~methods:[("fmt", "fmt")];
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 120 *)
  mk_trait_decl "core::fmt::LowerHex" "_root_.Aeneas.Std.core.fmt.LowerHex" ~methods:[("fmt", "fmt")];
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 124 *)
  mk_trait_decl "core::fmt::UpperHex" "_root_.Aeneas.Std.core.fmt.UpperHex" ~methods:[("fmt", "fmt")];
  (* file: "Aeneas/Std/Core/Hash.lean", line: 124 *)
  mk_trait_decl "core::hash::Hash" "_root_.Aeneas.Std.core.hash.Hash" ~methods:[("hash", "hash"); ("hash_slice", "hash_slice")] ~default_methods:["hash_slice"];
  (* file: "Aeneas/Std/Core/Hash.lean", line: 33 *)
  mk_trait_decl "core::hash::Hasher" "_root_.Aeneas.Std.core.hash.Hasher" ~methods:[("finish", "finish"); ("write", "write"); ("write_u8", "write_u8"); ("write_u16", "write_u16"); ("write_u32", "write_u32"); ("write_u64", "write_u64"); ("write_u128", "write_u128"); ("write_usize", "write_usize"); ("write_i8", "write_i8"); ("write_i16", "write_i16"); ("write_i32", "write_i32"); ("write_i64", "write_i64"); ("write_i128", "write_i128"); ("write_isize", "write_isize"); ("write_length_prefix", "write_length_prefix"); ("write_str", "write_str")] ~default_methods:["write_u8"; "write_u16"; "write_u32"; "write_u64"; "write_u128"; "write_usize"; "write_i8"; "write_i16"; "write_i32"; "write_i64"; "write_i128"; "write_isize"; "write_length_prefix"; "write_str"];
  (* file: "Aeneas/Std/Core/Iter.lean", line: 64 *)
  mk_trait_decl "core::iter::adapters::zip::TrustedRandomAccessNoCoerce" "_root_.Aeneas.Std.core.iter.adapters.zip.TrustedRandomAccessNoCoerce" ~consts:[("MAY_HAVE_SIDE_EFFECT", "MAY_HAVE_SIDE_EFFECT")];
  (* file: "Aeneas/Std/Core/Iter.lean", line: 33 *)
  mk_trait_decl "core::iter::range::Step" "_root_.Aeneas.Std.core.iter.range.Step" ~parent_clauses:["cloneInst"; "partialOrdInst"] ~methods:[("steps_between", "steps_between"); ("forward_checked", "forward_checked"); ("backward_checked", "backward_checked"); ("forward", "forward")] ~default_methods:["forward"];
  (* file: "Aeneas/Std/Core/Iter.lean", line: 750 *)
  mk_trait_decl "core::iter::traits::accum::Product" "_root_.Aeneas.Std.core.iter.traits.accum.Product" ~methods:[("product", "product")];
  (* file: "Aeneas/Std/Core/Iter.lean", line: 745 *)
  mk_trait_decl "core::iter::traits::accum::Sum" "_root_.Aeneas.Std.core.iter.traits.accum.Sum" ~methods:[("sum", "sum")];
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1084 *)
  mk_trait_decl "core::iter::traits::collect::Extend" "_root_.Aeneas.Std.core.iter.traits.collect.Extend" ~methods:[("extend", "extend")];
  (* file: "Aeneas/Std/Core/Iter.lean", line: 981 *)
  mk_trait_decl "core::iter::traits::collect::FromIterator" "_root_.Aeneas.Std.core.iter.traits.collect.FromIterator" ~methods:[("from_iter", "from_iter")];
  (* file: "Aeneas/Std/Core/Iter.lean", line: 971 *)
  mk_trait_decl "core::iter::traits::collect::IntoIterator" "_root_.Aeneas.Std.core.iter.traits.collect.IntoIterator" ~parent_clauses:["iteratorInst"] ~methods:[("into_iter", "into_iter")];
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1089 *)
  mk_trait_decl "core::iter::traits::double_ended::DoubleEndedIterator" "_root_.Aeneas.Std.core.iter.traits.double_ended.DoubleEndedIterator" ~parent_clauses:["iteratorInst"] ~methods:[("next_back", "next_back"); ("advance_back_by", "advance_back_by"); ("nth_back", "nth_back"); ("rfold", "rfold"); ("try_rfold", "try_rfold"); ("rfind", "rfind")] ~default_methods:["advance_back_by"; "nth_back"; "rfold"; "try_rfold"; "rfind"];
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1149 *)
  mk_trait_decl "core::iter::traits::exact_size::ExactSizeIterator" "_root_.Aeneas.Std.core.iter.traits.exact_size.ExactSizeIterator" ~parent_clauses:["iteratorInst"] ~methods:[("len", "len")] ~default_methods:["len"];
  (* file: "Aeneas/Std/Core/Iter.lean", line: 334 *)
  mk_trait_decl "core::iter::traits::iterator::Iterator" "_root_.Aeneas.Std.core.iter.traits.iterator.Iterator" ~methods:[("next", "next"); ("fold", "fold"); ("try_fold", "try_fold"); ("advance_by", "advance_by"); ("nth", "nth"); ("size_hint", "size_hint"); ("step_by", "step_by"); ("enumerate", "enumerate"); ("take", "take"); ("filter_map", "filter_map"); ("count", "count"); ("any", "any"); ("all", "all"); ("find", "find"); ("find_map", "find_map"); ("position", "position")] ~default_methods:["step_by"; "enumerate"; "take"; "filter_map"; "count"; "any"; "all"; "find"; "find_map"; "position"; "advance_by"; "nth"; "fold"; "try_fold"; "size_hint"] ~default_only_methods:["collect"; "unzip"];
  (* file: "Aeneas/Std/Core/Core.lean", line: 137 *)
  mk_trait_decl "core::marker::Copy" "_root_.Aeneas.Std.core.marker.Copy" ~parent_clauses:["cloneInst"];
  (* file: "Aeneas/Std/Core/Discriminant.lean", line: 56 *)
  mk_trait_decl "core::marker::DiscriminantKind" "_root_.Aeneas.Std.DiscriminantKind" ~parent_clauses:["cloneInst"; "copyInst"; "debugInst"; "partialEqInst"; "eqInst"; "hashInst"] ~types:[("Discriminant", "Discriminant")];
  (* file: "Aeneas/Std/Core/Marker.lean", line: 8 *)
  mk_trait_decl "core::marker::Freeze" "_root_.Aeneas.Std.core.marker.Freeze";
  (* file: "Aeneas/Std/Core/Marker.lean", line: 5 *)
  mk_trait_decl "core::marker::StructuralPartialEq" "_root_.Aeneas.Std.core.marker.StructuralPartialEq";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 78 *)
  mk_trait_decl "core::num::nonzero::ZeroablePrimitive" "_root_.Aeneas.Std.core.num.nonzero.ZeroablePrimitive" ~parent_clauses:["copyInst"; "sealedInst"; "innerCopyInst"];
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 75 *)
  mk_trait_decl "core::num::nonzero::private::Sealed" "_root_.Aeneas.Std.core.num.nonzero.private.Sealed";
  (* file: "Aeneas/Std/Core/Ops.lean", line: 47 *)
  mk_trait_decl "core::ops::arith::MulAssign" "_root_.Aeneas.Std.core.ops.arith.MulAssign" ~methods:[("mul_assign", "mul_assign")];
  (* file: "Aeneas/Std/Core/Ops.lean", line: 43 *)
  mk_trait_decl "core::ops::bit::BitAnd" "_root_.Aeneas.Std.core.ops.bit.BitAnd" ~methods:[("bitand", "bitand")];
  (* file: "Aeneas/Std/Core/Ops.lean", line: 19 *)
  mk_trait_decl "core::ops::deref::Deref" "_root_.Aeneas.Std.core.ops.deref.Deref" ~methods:[("deref", "deref")];
  (* file: "Aeneas/Std/Core/Ops.lean", line: 23 *)
  mk_trait_decl "core::ops::deref::DerefMut" "_root_.Aeneas.Std.core.ops.deref.DerefMut" ~parent_clauses:["derefInst"] ~methods:[("deref_mut", "deref_mut")];
  (* file: "Aeneas/Std/Core/Ops.lean", line: 175 *)
  mk_trait_decl "core::ops::function::Fn" "_root_.Aeneas.Std.core.ops.function.Fn" ~parent_clauses:["FnMutInst"] ~methods:[("call", "call")];
  (* file: "Aeneas/Std/Core/Ops.lean", line: 170 *)
  mk_trait_decl "core::ops::function::FnMut" "_root_.Aeneas.Std.core.ops.function.FnMut" ~parent_clauses:["FnOnceInst"] ~methods:[("call_mut", "call_mut")];
  (* file: "Aeneas/Std/Core/Ops.lean", line: 92 *)
  mk_trait_decl "core::ops::function::FnMut<@Self, (&'a &'b mut @T), @Output>" "_root_.Aeneas.Std.core.ops.function.FnMutSharedMutArg" ~parent_clauses:["FnOnceInst"] ~methods:[("call_mut", "call_mut")];
  (* file: "Aeneas/Std/Core/Ops.lean", line: 107 *)
  mk_trait_decl "core::ops::function::FnMut<@Self, (&'a mut @T), @Output>" "_root_.Aeneas.Std.core.ops.function.FnMutMutArg" ~parent_clauses:["FnOnceInst"] ~methods:[("call_mut", "call_mut")];
  (* file: "Aeneas/Std/Core/Ops.lean", line: 51 *)
  mk_trait_decl "core::ops::function::FnOnce" "_root_.Aeneas.Std.core.ops.function.FnOnce" ~methods:[("call_once", "call_once")];
  (* file: "Aeneas/Std/Core/Ops.lean", line: 85 *)
  mk_trait_decl "core::ops::function::FnOnce<@Self, (&'a &'b mut @T), @Output>" "_root_.Aeneas.Std.core.ops.function.FnOnceSharedMutArg" ~methods:[("call_once", "call_once")];
  (* file: "Aeneas/Std/Core/Ops.lean", line: 60 *)
  mk_trait_decl "core::ops::function::FnOnce<@Self, (&'a mut @T), @Output>" "_root_.Aeneas.Std.core.ops.function.FnOnceMutArg" ~methods:[("call_once", "call_once")];
  (* file: "Aeneas/Std/Core/Ops.lean", line: 77 *)
  mk_trait_decl "core::ops::function::FnOnce<@Self, (&'a mut @T, &'b mut @U), @Output>" "_root_.Aeneas.Std.core.ops.function.FnOnceMutArgMutArg" ~methods:[("call_once", "call_once")];
  (* file: "Aeneas/Std/Core/Ops.lean", line: 68 *)
  mk_trait_decl "core::ops::function::FnOnce<@Self, (&'a mut @T, @U), @Output>" "_root_.Aeneas.Std.core.ops.function.FnOnceMutArgPair" ~methods:[("call_once", "call_once")];
  (* file: "Aeneas/Std/Core/Ops.lean", line: 10 *)
  mk_trait_decl "core::ops::index::Index" "_root_.Aeneas.Std.core.ops.index.Index" ~methods:[("index", "index")];
  (* file: "Aeneas/Std/Core/Ops.lean", line: 14 *)
  mk_trait_decl "core::ops::index::IndexMut" "_root_.Aeneas.Std.core.ops.index.IndexMut" ~parent_clauses:["indexInst"] ~methods:[("index_mut", "index_mut")];
  (* file: "Aeneas/Std/RangeBounds.lean", line: 17 *)
  mk_trait_decl "core::ops::range::RangeBounds" "_root_.Aeneas.Std.core.ops.range.RangeBounds" ~methods:[("start_bound", "start_bound"); ("end_bound", "end_bound")];
  (* file: "Aeneas/Std/Core/Ops.lean", line: 229 *)
  mk_trait_decl "core::ops::try_trait::FromResidual" "_root_.Aeneas.Std.core.ops.try_trait.FromResidual" ~methods:[("from_residual", "from_residual")];
  (* file: "Aeneas/Std/Core/Ops.lean", line: 244 *)
  mk_trait_decl "core::ops::try_trait::Residual" "_root_.Aeneas.Std.core.ops.try_trait.Residual" ~parent_clauses:["TryInst"];
  (* file: "Aeneas/Std/Core/Ops.lean", line: 238 *)
  mk_trait_decl "core::ops::try_trait::Try" "_root_.Aeneas.Std.core.ops.try_trait.Try" ~parent_clauses:["FromResidualInst"] ~methods:[("from_output", "from_output"); ("branch", "branch")];
  (* file: "Aeneas/Std/Slice.lean", line: 337 *)
  mk_trait_decl "core::slice::index::SliceIndex" "_root_.Aeneas.Std.core.slice.index.SliceIndex" ~parent_clauses:["sealedInst"] ~methods:[("get", "get"); ("get_mut", "get_mut"); ("get_unchecked", "get_unchecked"); ("get_unchecked_mut", "get_unchecked_mut"); ("index", "index"); ("index_mut", "index_mut")];
  (* file: "Aeneas/Std/Slice.lean", line: 334 *)
  mk_trait_decl "core::slice::index::private_slice_index::Sealed" "_root_.Aeneas.Std.core.slice.index.private_slice_index.Sealed";
  (* file: "Aeneas/Std/String.lean", line: 326 *)
  mk_trait_decl "core::str::pattern::Pattern" "_root_.Aeneas.Std.core.str.pattern.Pattern" ~methods:[("is_prefix_of", "is_prefix_of")];
  (* file: "Aeneas/Std/String.lean", line: 353 *)
  mk_trait_decl "core::str::pattern::ReverseSearcher" "_root_.Aeneas.Std.core.str.pattern.ReverseSearcher" ~parent_clauses:["searcherInst"];
  (* file: "Aeneas/Std/String.lean", line: 346 *)
  mk_trait_decl "core::str::pattern::Searcher" "_root_.Aeneas.Std.core.str.pattern.Searcher" ~methods:[("haystack", "haystack")];
  (* file: "Aeneas/Std/Parse.lean", line: 19 *)
  mk_trait_decl "core::str::traits::FromStr" "_root_.Aeneas.Std.core.str.traits.FromStr" ~methods:[("from_str", "from_str")];
  (* file: "Aeneas/Std/Serde/De.lean", line: 689 *)
  mk_trait_decl "serde_core::de::Deserialize" "_root_.Aeneas.Std.serde_core.de.Deserialize" ~methods:[("deserialize", "deserialize")] ~knot:"_root_.Aeneas.Std.serde_core.de.Deserialize.wrap";
  (* file: "Aeneas/Std/Serde/De.lean", line: 693 *)
  mk_trait_decl "serde_core::de::DeserializeSeed" "_root_.Aeneas.Std.serde_core.de.DeserializeSeed" ~methods:[("deserialize", "deserialize")] ~knot:"_root_.Aeneas.Std.serde_core.de.DeserializeSeed.wrap";
  (* file: "Aeneas/Std/Serde/De.lean", line: 652 *)
  mk_trait_decl "serde_core::de::Deserializer" "_root_.Aeneas.Std.serde_core.de.Deserializer" ~parent_clauses:["serde_coredeErrorInst"] ~methods:[("deserialize_any", "deserialize_any"); ("deserialize_bool", "deserialize_bool"); ("deserialize_i8", "deserialize_i8"); ("deserialize_i16", "deserialize_i16"); ("deserialize_i32", "deserialize_i32"); ("deserialize_i64", "deserialize_i64"); ("deserialize_i128", "deserialize_i128"); ("deserialize_u8", "deserialize_u8"); ("deserialize_u16", "deserialize_u16"); ("deserialize_u32", "deserialize_u32"); ("deserialize_u64", "deserialize_u64"); ("deserialize_u128", "deserialize_u128"); ("deserialize_f32", "deserialize_f32"); ("deserialize_f64", "deserialize_f64"); ("deserialize_char", "deserialize_char"); ("deserialize_str", "deserialize_str"); ("deserialize_string", "deserialize_string"); ("deserialize_bytes", "deserialize_bytes"); ("deserialize_byte_buf", "deserialize_byte_buf"); ("deserialize_option", "deserialize_option"); ("deserialize_unit", "deserialize_unit"); ("deserialize_unit_struct", "deserialize_unit_struct"); ("deserialize_newtype_struct", "deserialize_newtype_struct"); ("deserialize_seq", "deserialize_seq"); ("deserialize_tuple", "deserialize_tuple"); ("deserialize_tuple_struct", "deserialize_tuple_struct"); ("deserialize_map", "deserialize_map"); ("deserialize_struct", "deserialize_struct"); ("deserialize_enum", "deserialize_enum"); ("deserialize_identifier", "deserialize_identifier"); ("deserialize_ignored_any", "deserialize_ignored_any"); ("is_human_readable", "is_human_readable"); ("__deserialize_content_v1", "__deserialize_content_v1")] ~default_methods:["deserialize_i128"; "deserialize_u128"; "is_human_readable"; "__deserialize_content_v1"];
  (* file: "Aeneas/Std/Serde/De.lean", line: 684 *)
  mk_trait_decl "serde_core::de::EnumAccess" "_root_.Aeneas.Std.serde_core.de.EnumAccess" ~parent_clauses:["serde_coredeErrorInst"; "VariantAccessInst"] ~methods:[("variant_seed", "variant_seed"); ("variant", "variant")] ~default_methods:["variant"];
  (* file: "Aeneas/Std/Serde/De.lean", line: 194 *)
  mk_trait_decl "serde_core::de::Error" "_root_.Aeneas.Std.serde_core.de.Error" ~parent_clauses:["coreerrorErrorInst"] ~methods:[("custom", "custom"); ("invalid_type", "invalid_type"); ("invalid_value", "invalid_value"); ("invalid_length", "invalid_length"); ("unknown_variant", "unknown_variant"); ("unknown_field", "unknown_field"); ("missing_field", "missing_field"); ("duplicate_field", "duplicate_field")] ~default_methods:["invalid_type"; "invalid_value"; "invalid_length"; "unknown_variant"; "unknown_field"; "missing_field"; "duplicate_field"];
  (* file: "Aeneas/Std/Serde/De.lean", line: 120 *)
  mk_trait_decl "serde_core::de::Expected" "_root_.Aeneas.Std.serde_core.de.Expected" ~methods:[("fmt", "fmt")];
  (* file: "Aeneas/Std/Serde/De.lean", line: 671 *)
  mk_trait_decl "serde_core::de::MapAccess" "_root_.Aeneas.Std.serde_core.de.MapAccess" ~parent_clauses:["serde_coredeErrorInst"] ~methods:[("next_key_seed", "next_key_seed"); ("next_value_seed", "next_value_seed"); ("next_entry_seed", "next_entry_seed"); ("next_key", "next_key"); ("next_value", "next_value"); ("next_entry", "next_entry"); ("size_hint", "size_hint")] ~default_methods:["next_entry_seed"; "next_key"; "next_value"; "next_entry"; "size_hint"];
  (* file: "Aeneas/Std/Serde/De.lean", line: 666 *)
  mk_trait_decl "serde_core::de::SeqAccess" "_root_.Aeneas.Std.serde_core.de.SeqAccess" ~parent_clauses:["serde_coredeErrorInst"] ~methods:[("next_element_seed", "next_element_seed"); ("next_element", "next_element"); ("size_hint", "size_hint")] ~default_methods:["next_element"; "size_hint"];
  (* file: "Aeneas/Std/Serde/De.lean", line: 677 *)
  mk_trait_decl "serde_core::de::VariantAccess" "_root_.Aeneas.Std.serde_core.de.VariantAccess" ~parent_clauses:["serde_coredeErrorInst"] ~methods:[("unit_variant", "unit_variant"); ("newtype_variant_seed", "newtype_variant_seed"); ("newtype_variant", "newtype_variant"); ("tuple_variant", "tuple_variant"); ("struct_variant", "struct_variant")] ~default_methods:["newtype_variant"];
  (* file: "Aeneas/Std/Serde/De.lean", line: 697 *)
  mk_trait_decl "serde_core::de::Visitor" "_root_.Aeneas.Std.serde_core.de.Visitor" ~methods:[("expecting", "expecting"); ("visit_bool", "visit_bool"); ("visit_i8", "visit_i8"); ("visit_i16", "visit_i16"); ("visit_i32", "visit_i32"); ("visit_i64", "visit_i64"); ("visit_i128", "visit_i128"); ("visit_u8", "visit_u8"); ("visit_u16", "visit_u16"); ("visit_u32", "visit_u32"); ("visit_u64", "visit_u64"); ("visit_u128", "visit_u128"); ("visit_f32", "visit_f32"); ("visit_f64", "visit_f64"); ("visit_char", "visit_char"); ("visit_str", "visit_str"); ("visit_borrowed_str", "visit_borrowed_str"); ("visit_string", "visit_string"); ("visit_bytes", "visit_bytes"); ("visit_borrowed_bytes", "visit_borrowed_bytes"); ("visit_byte_buf", "visit_byte_buf"); ("visit_none", "visit_none"); ("visit_some", "visit_some"); ("visit_unit", "visit_unit"); ("visit_newtype_struct", "visit_newtype_struct"); ("visit_seq", "visit_seq"); ("visit_map", "visit_map"); ("visit_enum", "visit_enum")] ~default_methods:["visit_bool"; "visit_i8"; "visit_i16"; "visit_i32"; "visit_i64"; "visit_i128"; "visit_u8"; "visit_u16"; "visit_u32"; "visit_u64"; "visit_u128"; "visit_f32"; "visit_f64"; "visit_char"; "visit_str"; "visit_borrowed_str"; "visit_string"; "visit_bytes"; "visit_borrowed_bytes"; "visit_byte_buf"; "visit_none"; "visit_some"; "visit_unit"; "visit_newtype_struct"; "visit_seq"; "visit_map"; "visit_enum"] ~knot:"_root_.Aeneas.Std.serde_core.de.Visitor.wrap";
  (* file: "Aeneas/Std/Serde/Ser.lean", line: 52 *)
  mk_trait_decl "serde_core::ser::Error" "_root_.Aeneas.Std.serde_core.ser.Error" ~parent_clauses:["coreerrorErrorInst"] ~methods:[("custom", "custom")];
  (* file: "Aeneas/Std/Serde/Ser.lean", line: 422 *)
  mk_trait_decl "serde_core::ser::Serialize" "_root_.Aeneas.Std.serde_core.ser.Serialize" ~methods:[("serialize", "serialize")] ~knot:"_root_.Aeneas.Std.serde_core.ser.Serialize.wrap";
  (* file: "Aeneas/Std/Serde/Ser.lean", line: 389 *)
  mk_trait_decl "serde_core::ser::SerializeMap" "_root_.Aeneas.Std.serde_core.ser.SerializeMap" ~parent_clauses:["serde_coreserErrorInst"] ~methods:[("serialize_key", "serialize_key"); ("serialize_value", "serialize_value"); ("serialize_entry", "serialize_entry"); ("end", "end")] ~default_methods:["serialize_entry"];
  (* file: "Aeneas/Std/Serde/Ser.lean", line: 371 *)
  mk_trait_decl "serde_core::ser::SerializeSeq" "_root_.Aeneas.Std.serde_core.ser.SerializeSeq" ~parent_clauses:["serde_coreserErrorInst"] ~methods:[("serialize_element", "serialize_element"); ("end", "end")];
  (* file: "Aeneas/Std/Serde/Ser.lean", line: 395 *)
  mk_trait_decl "serde_core::ser::SerializeStruct" "_root_.Aeneas.Std.serde_core.ser.SerializeStruct" ~parent_clauses:["serde_coreserErrorInst"] ~methods:[("serialize_field", "serialize_field"); ("skip_field", "skip_field"); ("end", "end")] ~default_methods:["skip_field"];
  (* file: "Aeneas/Std/Serde/Ser.lean", line: 400 *)
  mk_trait_decl "serde_core::ser::SerializeStructVariant" "_root_.Aeneas.Std.serde_core.ser.SerializeStructVariant" ~parent_clauses:["serde_coreserErrorInst"] ~methods:[("serialize_field", "serialize_field"); ("skip_field", "skip_field"); ("end", "end")] ~default_methods:["skip_field"];
  (* file: "Aeneas/Std/Serde/Ser.lean", line: 375 *)
  mk_trait_decl "serde_core::ser::SerializeTuple" "_root_.Aeneas.Std.serde_core.ser.SerializeTuple" ~parent_clauses:["serde_coreserErrorInst"] ~methods:[("serialize_element", "serialize_element"); ("end", "end")];
  (* file: "Aeneas/Std/Serde/Ser.lean", line: 379 *)
  mk_trait_decl "serde_core::ser::SerializeTupleStruct" "_root_.Aeneas.Std.serde_core.ser.SerializeTupleStruct" ~parent_clauses:["serde_coreserErrorInst"] ~methods:[("serialize_field", "serialize_field"); ("end", "end")];
  (* file: "Aeneas/Std/Serde/Ser.lean", line: 384 *)
  mk_trait_decl "serde_core::ser::SerializeTupleVariant" "_root_.Aeneas.Std.serde_core.ser.SerializeTupleVariant" ~parent_clauses:["serde_coreserErrorInst"] ~methods:[("serialize_field", "serialize_field"); ("end", "end")];
  (* file: "Aeneas/Std/Serde/Ser.lean", line: 406 *)
  mk_trait_decl "serde_core::ser::Serializer" "_root_.Aeneas.Std.serde_core.ser.Serializer" ~parent_clauses:["serde_coreserErrorInst"; "SerializeSeqInst"; "SerializeTupleInst"; "SerializeTupleStructInst"; "SerializeTupleVariantInst"; "SerializeMapInst"; "SerializeStructInst"; "SerializeStructVariantInst"] ~methods:[("serialize_bool", "serialize_bool"); ("serialize_i8", "serialize_i8"); ("serialize_i16", "serialize_i16"); ("serialize_i32", "serialize_i32"); ("serialize_i64", "serialize_i64"); ("serialize_i128", "serialize_i128"); ("serialize_u8", "serialize_u8"); ("serialize_u16", "serialize_u16"); ("serialize_u32", "serialize_u32"); ("serialize_u64", "serialize_u64"); ("serialize_u128", "serialize_u128"); ("serialize_f32", "serialize_f32"); ("serialize_f64", "serialize_f64"); ("serialize_char", "serialize_char"); ("serialize_str", "serialize_str"); ("serialize_bytes", "serialize_bytes"); ("serialize_none", "serialize_none"); ("serialize_some", "serialize_some"); ("serialize_unit", "serialize_unit"); ("serialize_unit_struct", "serialize_unit_struct"); ("serialize_unit_variant", "serialize_unit_variant"); ("serialize_newtype_struct", "serialize_newtype_struct"); ("serialize_newtype_variant", "serialize_newtype_variant"); ("serialize_seq", "serialize_seq"); ("serialize_tuple", "serialize_tuple"); ("serialize_tuple_struct", "serialize_tuple_struct"); ("serialize_tuple_variant", "serialize_tuple_variant"); ("serialize_map", "serialize_map"); ("serialize_struct", "serialize_struct"); ("serialize_struct_variant", "serialize_struct_variant"); ("is_human_readable", "is_human_readable"); ("collect_seq", "collect_seq"); ("collect_map", "collect_map")] ~default_methods:["serialize_i128"; "serialize_u128"; "is_human_readable"; "collect_seq"; "collect_map"];
]

let lean_builtin_trait_impls = [
  (* file: "Aeneas/Std/Core/Borrow.lean", line: 63 *)
  mk_trait_impl "alloc::borrow::ToOwned<@T, @T>" "_root_.Aeneas.Std.alloc.borrow.ToOwnedClone";
  (* file: "Aeneas/Std/SliceOwned.lean", line: 43 *)
  mk_trait_impl "alloc::borrow::ToOwned<[@T], alloc::vec::Vec<@T>>" "_root_.Aeneas.Std.alloc.borrow.ToOwnedSlice";
  (* file: "Aeneas/Std/Core/Borrow.lean", line: 73 *)
  mk_trait_impl "alloc::borrow::ToOwned<str, alloc::string::String>" "_root_.Aeneas.Std.alloc.borrow.ToOwnedStr";
  (* file: "Aeneas/Std/StringJoin.lean", line: 52 *)
  mk_trait_impl "alloc::slice::Join<[@S], &'a str, alloc::string::String>" "_root_.Aeneas.Std.alloc.slice.JoinStr";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 242 *)
  mk_trait_impl "alloc::string::ToString<@T>" "_root_.Aeneas.Std.alloc.string.ToStringBlanket";
  (* file: "Aeneas/Std/Core/Core.lean", line: 154 *)
  mk_trait_impl "core::any::Any<@T>" "_root_.Aeneas.Std.core.any.AnyBlanket";
  (* file: "Aeneas/Std/Core/Borrow.lean", line: 24 *)
  mk_trait_impl "core::borrow::Borrow<&'a @T, @T>" "_root_.Aeneas.Std.core.borrow.BorrowShared";
  (* file: "Aeneas/Std/Core/Borrow.lean", line: 15 *)
  mk_trait_impl "core::borrow::Borrow<@T, @T>" "_root_.Aeneas.Std.core.borrow.BorrowSelf";
  (* file: "Aeneas/Std/Core/Borrow.lean", line: 35 *)
  mk_trait_impl "core::borrow::Borrow<alloc::string::String, str>" "_root_.Aeneas.Std.core.borrow.BorrowString";
  (* file: "Aeneas/Std/SliceOwned.lean", line: 16 *)
  mk_trait_impl "core::borrow::Borrow<alloc::vec::Vec<@T>, [@T]>" "_root_.Aeneas.Std.core.borrow.BorrowVecSlice" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Core/Core.lean", line: 131 *)
  mk_trait_impl "core::clone::Clone<Box<@T>>" "_root_.Aeneas.Std.core.core.clone.CloneBox" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 759 *)
  mk_trait_impl "core::clone::Clone<Box<[@T]>>" "_root_.Aeneas.Std.core.clone.CloneBoxSlice" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/String.lean", line: 217 *)
  mk_trait_impl "core::clone::Clone<Box<str>>" "_root_.Aeneas.Std.core.clone.CloneBoxStr";
  (* file: "Aeneas/Std/Array/Array.lean", line: 254 *)
  mk_trait_impl "core::clone::Clone<[@T; @N]>" "_root_.Aeneas.Std.core.clone.CloneArray";
  (* file: "Aeneas/Std/Core/Core.lean", line: 111 *)
  mk_trait_impl "core::clone::Clone<alloc::alloc::Global>" "_root_.Aeneas.Std.core.core.clone.CloneGlobal";
  (* file: "Aeneas/Std/BTreeSet.lean", line: 76 *)
  mk_trait_impl "core::clone::Clone<alloc::collections::btree::set::BTreeSet<@T, @A>>" "_root_.Aeneas.Std.alloc.collections.btree.set.CloneBTreeSet" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/Sync.lean", line: 57 *)
  mk_trait_impl "core::clone::Clone<alloc::rc::Rc<@T>>" "_root_.Aeneas.Std.core.clone.CloneRc" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/String.lean", line: 207 *)
  mk_trait_impl "core::clone::Clone<alloc::string::String>" "_root_.Aeneas.Std.core.clone.CloneString";
  (* file: "Aeneas/Std/Sync.lean", line: 46 *)
  mk_trait_impl "core::clone::Clone<alloc::sync::Arc<@T>>" "_root_.Aeneas.Std.core.clone.CloneArc" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/Vec.lean", line: 744 *)
  mk_trait_impl "core::clone::Clone<alloc::vec::Vec<@T>>" "_root_.Aeneas.Std.core.clone.CloneallocvecVec" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/Core/Core.lean", line: 120 *)
  mk_trait_impl "core::clone::Clone<bool>" "_root_.Aeneas.Std.core.clone.CloneBool";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 92 *)
  mk_trait_impl "core::clone::Clone<char>" "_root_.Aeneas.Std.core.clone.CloneChar";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 441 *)
  mk_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroCharInner>" "_root_.Aeneas.Std.core.clone.CloneNonZeroCharInner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 385 *)
  mk_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroI128Inner>" "_root_.Aeneas.Std.core.clone.CloneNonZeroI128Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 301 *)
  mk_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroI16Inner>" "_root_.Aeneas.Std.core.clone.CloneNonZeroI16Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 329 *)
  mk_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroI32Inner>" "_root_.Aeneas.Std.core.clone.CloneNonZeroI32Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 357 *)
  mk_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroI64Inner>" "_root_.Aeneas.Std.core.clone.CloneNonZeroI64Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 273 *)
  mk_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroI8Inner>" "_root_.Aeneas.Std.core.clone.CloneNonZeroI8Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 413 *)
  mk_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroIsizeInner>" "_root_.Aeneas.Std.core.clone.CloneNonZeroIsizeInner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 217 *)
  mk_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroU128Inner>" "_root_.Aeneas.Std.core.clone.CloneNonZeroU128Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 133 *)
  mk_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroU16Inner>" "_root_.Aeneas.Std.core.clone.CloneNonZeroU16Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 161 *)
  mk_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroU32Inner>" "_root_.Aeneas.Std.core.clone.CloneNonZeroU32Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 189 *)
  mk_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroU64Inner>" "_root_.Aeneas.Std.core.clone.CloneNonZeroU64Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 105 *)
  mk_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroU8Inner>" "_root_.Aeneas.Std.core.clone.CloneNonZeroU8Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 245 *)
  mk_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroUsizeInner>" "_root_.Aeneas.Std.core.clone.CloneNonZeroUsizeInner";
  (* file: "Aeneas/Std/Core/CoreOption.lean", line: 31 *)
  mk_trait_impl "core::clone::Clone<core::option::Option<@T>>" "_root_.Aeneas.Std.core.clone.CloneOption";
  (* file: "Aeneas/Std/Float.lean", line: 451 *)
  mk_trait_impl "core::clone::Clone<f32>" "_root_.Aeneas.Std.core.clone.CloneF32";
  (* file: "Aeneas/Std/Float.lean", line: 591 *)
  mk_trait_impl "core::clone::Clone<f64>" "_root_.Aeneas.Std.core.clone.CloneF64";
  (* file: "Aeneas/Std/Float.lean", line: 635 *)
  mk_trait_impl "core::clone::Clone<half::bfloat::bf16>" "_root_.Aeneas.Std.core.clone.CloneBF16";
  (* file: "Aeneas/Std/Float.lean", line: 618 *)
  mk_trait_impl "core::clone::Clone<half::binary16::f16>" "_root_.Aeneas.Std.core.clone.CloneF16";
  (* file: "Aeneas/Std/BigUint.lean", line: 120 *)
  mk_trait_impl "core::clone::Clone<num_bigint::biguint::BigUint>" "_root_.Aeneas.Std.num_bigint.CloneBigUint";
  (* file: "Aeneas/Std/Tuple.lean", line: 51 *)
  mk_trait_impl "core::cmp::Eq<(@U, @T)>" "_root_.Aeneas.Std.core.cmp.EqPair";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 328 *)
  mk_trait_impl "core::cmp::Eq<Box<@T>>" "_root_.Aeneas.Std.core.cmp.EqBox" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/SliceCmp.lean", line: 72 *)
  mk_trait_impl "core::cmp::Eq<[@T]>" "_root_.Aeneas.Std.core.slice.cmp.EqSliceInst";
  (* file: "Aeneas/Std/String.lean", line: 147 *)
  mk_trait_impl "core::cmp::Eq<alloc::string::String>" "_root_.Aeneas.Std.core.cmp.EqString";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 238 *)
  mk_trait_impl "core::cmp::Eq<char>" "_root_.Aeneas.Std.core.cmp.EqChar";
  (* file: "Aeneas/Std/Core/Reverse.lean", line: 40 *)
  mk_trait_impl "core::cmp::Eq<core::cmp::Reverse<@T>>" "_root_.Aeneas.Std.core.cmp.EqReverse";
  (* file: "Aeneas/Std/BigUint.lean", line: 130 *)
  mk_trait_impl "core::cmp::Eq<num_bigint::biguint::BigUint>" "_root_.Aeneas.Std.num_bigint.EqBigUint";
  (* file: "Aeneas/Std/String.lean", line: 156 *)
  mk_trait_impl "core::cmp::Eq<str>" "_root_.Aeneas.Std.core.cmp.EqStr";
  (* file: "Aeneas/Std/Tuple.lean", line: 119 *)
  mk_trait_impl "core::cmp::Ord<(@U, @T)>" "_root_.Aeneas.Std.core.cmp.OrdPair";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 375 *)
  mk_trait_impl "core::cmp::Ord<Box<@T>>" "_root_.Aeneas.Std.core.cmp.OrdBox" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/SliceCmp.lean", line: 148 *)
  mk_trait_impl "core::cmp::Ord<[@T]>" "_root_.Aeneas.Std.core.slice.cmp.OrdSliceInst";
  (* file: "Aeneas/Std/String.lean", line: 176 *)
  mk_trait_impl "core::cmp::Ord<alloc::string::String>" "_root_.Aeneas.Std.core.cmp.OrdString";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 286 *)
  mk_trait_impl "core::cmp::Ord<char>" "_root_.Aeneas.Std.core.cmp.OrdChar";
  (* file: "Aeneas/Std/Core/Reverse.lean", line: 148 *)
  mk_trait_impl "core::cmp::Ord<core::cmp::Reverse<@T>>" "_root_.Aeneas.Std.core.cmp.OrdReverse";
  (* file: "Aeneas/Std/BigUint.lean", line: 141 *)
  mk_trait_impl "core::cmp::Ord<num_bigint::biguint::BigUint>" "_root_.Aeneas.Std.num_bigint.OrdBigUint";
  (* file: "Aeneas/Std/String.lean", line: 197 *)
  mk_trait_impl "core::cmp::Ord<str>" "_root_.Aeneas.Std.core.cmp.OrdStr";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 304 *)
  mk_trait_impl "core::cmp::PartialEq<&'a @A, &'b @B>" "_root_.Aeneas.Std.core.cmp.PartialEqShared";
  (* file: "Aeneas/Std/String.lean", line: 115 *)
  mk_trait_impl "core::cmp::PartialEq<&'a str, alloc::string::String>" "_root_.Aeneas.Std.core.cmp.PartialEqSharedStrString";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 193 *)
  mk_trait_impl "core::cmp::PartialEq<(), ()>" "_root_.Aeneas.Std.core.cmp.PartialEqUnit";
  (* file: "Aeneas/Std/Tuple.lean", line: 43 *)
  mk_trait_impl "core::cmp::PartialEq<(@U, @T), (@U, @T)>" "_root_.Aeneas.Std.core.cmp.PartialEqPair";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 321 *)
  mk_trait_impl "core::cmp::PartialEq<Box<@T>, Box<@T>>" "_root_.Aeneas.Std.core.cmp.PartialEqBox" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/SliceCmp.lean", line: 65 *)
  mk_trait_impl "core::cmp::PartialEq<[@T], [@U]>" "_root_.Aeneas.Std.core.slice.cmp.PartialEqSliceInst";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 311 *)
  mk_trait_impl "core::cmp::PartialEq<alloc::collections::btree::map::BTreeMap<@K, @V, @A>, alloc::collections::btree::map::BTreeMap<@K, @V, @A>>" "_root_.Aeneas.Std.alloc.collections.btree.map.PartialEqBTreeMap" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [true; true; false]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 89 *)
  mk_trait_impl "core::cmp::PartialEq<alloc::collections::btree::set::BTreeSet<@T, @A>, alloc::collections::btree::set::BTreeSet<@T, @A>>" "_root_.Aeneas.Std.alloc.collections.btree.set.PartialEqBTreeSet" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/String.lean", line: 99 *)
  mk_trait_impl "core::cmp::PartialEq<alloc::string::String, &'a str>" "_root_.Aeneas.Std.core.cmp.PartialEqStringSharedStr";
  (* file: "Aeneas/Std/String.lean", line: 69 *)
  mk_trait_impl "core::cmp::PartialEq<alloc::string::String, alloc::string::String>" "_root_.Aeneas.Std.core.cmp.PartialEqString";
  (* file: "Aeneas/Std/String.lean", line: 83 *)
  mk_trait_impl "core::cmp::PartialEq<alloc::string::String, str>" "_root_.Aeneas.Std.core.cmp.PartialEqStringStr";
  (* file: "Aeneas/Std/Vec.lean", line: 787 *)
  mk_trait_impl "core::cmp::PartialEq<alloc::vec::Vec<@T>, alloc::vec::Vec<@U>>" "_root_.Aeneas.Std.core.cmp.PartialEqVec" ~keep_params:(Some [true; true; false; false]);
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 210 *)
  mk_trait_impl "core::cmp::PartialEq<bool, bool>" "_root_.Aeneas.Std.core.cmp.PartialEqBool";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 232 *)
  mk_trait_impl "core::cmp::PartialEq<char, char>" "_root_.Aeneas.Std.core.cmp.PartialEqChar";
  (* file: "Aeneas/Std/Core/Reverse.lean", line: 27 *)
  mk_trait_impl "core::cmp::PartialEq<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>" "_root_.Aeneas.Std.core.cmp.PartialEqReverse";
  (* file: "Aeneas/Std/Core/Discriminant.lean", line: 111 *)
  mk_trait_impl "core::cmp::PartialEq<core::mem::Discriminant<@T>, core::mem::Discriminant<@T>>" "_root_.Aeneas.Std.core.mem.PartialEqDiscriminant";
  (* file: "Aeneas/Std/Core/NonZeroTraits.lean", line: 28 *)
  mk_trait_impl "core::cmp::PartialEq<core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>, core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>>" "_root_.Aeneas.Std.core.cmp.PartialEqNonZero" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false; true]);
  (* file: "Aeneas/Std/Float.lean", line: 424 *)
  mk_trait_impl "core::cmp::PartialEq<f32, f32>" "_root_.Aeneas.Std.core.cmp.PartialEqF32";
  (* file: "Aeneas/Std/Float.lean", line: 564 *)
  mk_trait_impl "core::cmp::PartialEq<f64, f64>" "_root_.Aeneas.Std.core.cmp.PartialEqF64";
  (* file: "Aeneas/Std/Half.lean", line: 387 *)
  mk_trait_impl "core::cmp::PartialEq<half::bfloat::bf16, half::bfloat::bf16>" "_root_.Aeneas.Std.half.bfloat.PartialEqBF16";
  (* file: "Aeneas/Std/Half.lean", line: 314 *)
  mk_trait_impl "core::cmp::PartialEq<half::binary16::f16, half::binary16::f16>" "_root_.Aeneas.Std.half.binary16.PartialEqF16";
  (* file: "Aeneas/Std/BigUint.lean", line: 124 *)
  mk_trait_impl "core::cmp::PartialEq<num_bigint::biguint::BigUint, num_bigint::biguint::BigUint>" "_root_.Aeneas.Std.num_bigint.PartialEqBigUint";
  (* file: "Aeneas/Std/String.lean", line: 138 *)
  mk_trait_impl "core::cmp::PartialEq<str, str>" "_root_.Aeneas.Std.core.cmp.PartialEqStr";
  (* file: "Aeneas/Std/Tuple.lean", line: 99 *)
  mk_trait_impl "core::cmp::PartialOrd<(@U, @T), (@U, @T)>" "_root_.Aeneas.Std.core.cmp.PartialOrdPair";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 360 *)
  mk_trait_impl "core::cmp::PartialOrd<Box<@T>, Box<@T>>" "_root_.Aeneas.Std.core.cmp.PartialOrdBox" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/SliceCmp.lean", line: 122 *)
  mk_trait_impl "core::cmp::PartialOrd<[@T], [@T]>" "_root_.Aeneas.Std.core.slice.cmp.PartialOrdSliceInst";
  (* file: "Aeneas/Std/String.lean", line: 170 *)
  mk_trait_impl "core::cmp::PartialOrd<alloc::string::String, alloc::string::String>" "_root_.Aeneas.Std.core.cmp.PartialOrdString";
  (* file: "Aeneas/Std/Core/Cmp.lean", line: 274 *)
  mk_trait_impl "core::cmp::PartialOrd<char, char>" "_root_.Aeneas.Std.core.cmp.PartialOrdChar";
  (* file: "Aeneas/Std/Core/Reverse.lean", line: 106 *)
  mk_trait_impl "core::cmp::PartialOrd<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>" "_root_.Aeneas.Std.core.cmp.PartialOrdReverse";
  (* file: "Aeneas/Std/Float.lean", line: 440 *)
  mk_trait_impl "core::cmp::PartialOrd<f32, f32>" "_root_.Aeneas.Std.core.cmp.PartialOrdF32";
  (* file: "Aeneas/Std/Float.lean", line: 580 *)
  mk_trait_impl "core::cmp::PartialOrd<f64, f64>" "_root_.Aeneas.Std.core.cmp.PartialOrdF64";
  (* file: "Aeneas/Std/Half.lean", line: 406 *)
  mk_trait_impl "core::cmp::PartialOrd<half::bfloat::bf16, half::bfloat::bf16>" "_root_.Aeneas.Std.half.bfloat.PartialOrdBF16";
  (* file: "Aeneas/Std/Half.lean", line: 333 *)
  mk_trait_impl "core::cmp::PartialOrd<half::binary16::f16, half::binary16::f16>" "_root_.Aeneas.Std.half.binary16.PartialOrdF16";
  (* file: "Aeneas/Std/BigUint.lean", line: 134 *)
  mk_trait_impl "core::cmp::PartialOrd<num_bigint::biguint::BigUint, num_bigint::biguint::BigUint>" "_root_.Aeneas.Std.num_bigint.PartialOrdBigUint";
  (* file: "Aeneas/Std/String.lean", line: 191 *)
  mk_trait_impl "core::cmp::PartialOrd<str, str>" "_root_.Aeneas.Std.core.cmp.PartialOrdStr";
  (* file: "Aeneas/Std/Core/Convert.lean", line: 82 *)
  mk_trait_impl "core::convert::AsMut<Box<@T>, @T>" "_root_.Aeneas.Std.core.convert.AsMutBox";
  (* file: "Aeneas/Std/Core/Core.lean", line: 56 *)
  mk_trait_impl "core::convert::From<@Self, @Self>" "_root_.Aeneas.Std.core.convert.FromSame";
  (* file: "Aeneas/Std/Core/Core.lean", line: 64 *)
  mk_trait_impl "core::convert::From<Box<@T>, @T>" "_root_.Aeneas.Std.core.convert.FromBox";
  (* file: "Aeneas/Std/Vec.lean", line: 709 *)
  mk_trait_impl "core::convert::From<Box<[@T]>, alloc::vec::Vec<@T>>" "_root_.Aeneas.Std.core.convert.FromBoxSliceVec" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/String.lean", line: 617 *)
  mk_trait_impl "core::convert::From<Box<str>, &'0 str>" "_root_.Aeneas.Std.core.convert.FromSharedStrBoxStr";
  (* file: "Aeneas/Std/String.lean", line: 599 *)
  mk_trait_impl "core::convert::From<Box<str>, alloc::string::String>" "_root_.Aeneas.Std.core.convert.FromStringBoxStr";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 739 *)
  mk_trait_impl "core::convert::From<alloc::collections::btree::map::BTreeMap<@K, @V, alloc::alloc::Global>, [(@K, @V); @N]>" "_root_.Aeneas.Std.core.convert.FromBTreeMapArray";
  (* file: "Aeneas/Std/VecDeque.lean", line: 45 *)
  mk_trait_impl "core::convert::From<alloc::collections::vec_deque::VecDeque<@T, alloc::alloc::Global>, [@T; @N]>" "_root_.Aeneas.Std.alloc.collections.vec_deque.FromVecDequeArray";
  (* file: "Aeneas/Std/String.lean", line: 608 *)
  mk_trait_impl "core::convert::From<alloc::string::String, &'0 alloc::string::String>" "_root_.Aeneas.Std.core.convert.FromSharedStringString";
  (* file: "Aeneas/Std/String.lean", line: 588 *)
  mk_trait_impl "core::convert::From<alloc::string::String, &'a str>" "_root_.Aeneas.Std.core.convert.FromStrString";
  (* file: "Aeneas/Std/Vec.lean", line: 675 *)
  mk_trait_impl "core::convert::From<alloc::vec::Vec<@T>, [@T; @N]>" "_root_.Aeneas.Std.core.convert.FromVecArray";
  (* file: "Aeneas/Std/Float.lean", line: 601 *)
  mk_trait_impl "core::convert::From<f64, f32>" "_root_.Aeneas.Std.core.convert.num.FromF64F32";
  (* file: "Aeneas/Std/Half.lean", line: 381 *)
  mk_trait_impl "core::convert::From<f64, half::bfloat::bf16>" "_root_.Aeneas.Std.half.bfloat.FromF64BF16";
  (* file: "Aeneas/Std/Half.lean", line: 308 *)
  mk_trait_impl "core::convert::From<f64, half::binary16::f16>" "_root_.Aeneas.Std.half.binary16.FromF64F16";
  (* file: "Aeneas/Std/BigUint.lean", line: 152 *)
  mk_trait_impl "core::convert::From<num_bigint::biguint::BigUint, u64>" "_root_.Aeneas.Std.num_bigint.FromBigUintU64";
  (* file: "Aeneas/Std/BigUint.lean", line: 149 *)
  mk_trait_impl "core::convert::From<num_bigint::biguint::BigUint, u8>" "_root_.Aeneas.Std.num_bigint.FromBigUintU8";
  (* file: "Aeneas/Std/BigUint.lean", line: 155 *)
  mk_trait_impl "core::convert::From<num_bigint::biguint::BigUint, usize>" "_root_.Aeneas.Std.num_bigint.FromBigUintUsize";
  (* file: "Aeneas/Std/Core/Convert.lean", line: 25 *)
  mk_trait_impl "core::convert::Into<@Self, @T>" "_root_.Aeneas.Std.core.convert.IntoFrom";
  (* file: "Aeneas/Std/Array/ArraySlice.lean", line: 210 *)
  mk_trait_impl "core::convert::TryFrom<&'a [@T; @N], &'a [@T], core::array::TryFromSliceError>" "_root_.Aeneas.Std.core.convert.TryFromSharedArraySliceTryFromSliceError";
  (* file: "Aeneas/Std/Core/Convert.lean", line: 44 *)
  mk_trait_impl "core::convert::TryFrom<@T, @U, core::convert::Infallible>" "_root_.Aeneas.Std.core.convert.TryFromTUInfallible.Blanket";
  (* file: "Aeneas/Std/Vec.lean", line: 692 *)
  mk_trait_impl "core::convert::TryFrom<[@T; @N], alloc::vec::Vec<@T>, alloc::vec::Vec<@T>>" "_root_.Aeneas.Std.core.convert.TryFromArrayVec" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Scalar/CoreConvertNum.lean", line: 133 *)
  mk_trait_impl "core::convert::TryFrom<i16, i64, core::num::error::TryFromIntError>" "_root_.Aeneas.Std.core.convert.num.TryFromI16I64";
  (* file: "Aeneas/Std/Scalar/CoreConvertNum.lean", line: 145 *)
  mk_trait_impl "core::convert::TryFrom<i32, i64, core::num::error::TryFromIntError>" "_root_.Aeneas.Std.core.convert.num.TryFromI32I64";
  (* file: "Aeneas/Std/Scalar/CoreConvertNum.lean", line: 31 *)
  mk_trait_impl "core::convert::TryFrom<i32, usize, core::num::error::TryFromIntError>" "_root_.Aeneas.Std.core.convert.num.TryFromI32Usize";
  (* file: "Aeneas/Std/Scalar/CoreConvertNum.lean", line: 53 *)
  mk_trait_impl "core::convert::TryFrom<i64, usize, core::num::error::TryFromIntError>" "_root_.Aeneas.Std.core.convert.num.TryFromI64Usize";
  (* file: "Aeneas/Std/Scalar/CoreConvertNum.lean", line: 121 *)
  mk_trait_impl "core::convert::TryFrom<i8, i64, core::num::error::TryFromIntError>" "_root_.Aeneas.Std.core.convert.num.TryFromI8I64";
  (* file: "Aeneas/Std/Scalar/CoreConvertNum.lean", line: 80 *)
  mk_trait_impl "core::convert::TryFrom<u32, usize, core::num::error::TryFromIntError>" "_root_.Aeneas.Std.core.convert.num.TryFromU32Usize";
  (* file: "Aeneas/Std/Scalar/CoreConvertNum.lean", line: 93 *)
  mk_trait_impl "core::convert::TryFrom<u64, i64, core::num::error::TryFromIntError>" "_root_.Aeneas.Std.core.convert.num.TryFromU64I64";
  (* file: "Aeneas/Std/BigUint.lean", line: 160 *)
  mk_trait_impl "core::convert::TryFrom<u64, num_bigint::biguint::BigUint, num_bigint::TryFromBigIntError<num_bigint::biguint::BigUint>>" "_root_.Aeneas.Std.num_bigint.TryFromU64BigUint";
  (* file: "Aeneas/Std/Scalar/CoreConvertNum.lean", line: 66 *)
  mk_trait_impl "core::convert::TryFrom<u64, usize, core::num::error::TryFromIntError>" "_root_.Aeneas.Std.core.convert.num.TryFromU64Usize";
  (* file: "Aeneas/Std/Scalar/CoreConvertNum.lean", line: 42 *)
  mk_trait_impl "core::convert::TryFrom<usize, i32, core::num::error::TryFromIntError>" "_root_.Aeneas.Std.core.convert.num.TryFromUsizeI32";
  (* file: "Aeneas/Std/Scalar/CoreConvertNum.lean", line: 107 *)
  mk_trait_impl "core::convert::TryFrom<usize, i64, core::num::error::TryFromIntError>" "_root_.Aeneas.Std.core.convert.num.TryFromUsizeI64";
  (* file: "Aeneas/Std/Core/Convert.lean", line: 71 *)
  mk_trait_impl "core::convert::TryInto<@T, @U, @E>" "_root_.Aeneas.Std.core.convert.TryInto.Blanket";
  (* file: "Aeneas/Std/Core/Convert.lean", line: 65 *)
  mk_trait_impl "core::convert::{core::convert::TryInto<@T, @U>}" "_root_.Aeneas.Std.core.convert.TryIntoFrom";
  (* file: "Aeneas/Std/Core/Default.lean", line: 27 *)
  mk_trait_impl "core::default::Default<Box<@T>>" "_root_.Aeneas.Std.alloc.boxed.DefaultBox";
  (* file: "Aeneas/Std/Array/Array.lean", line: 306 *)
  mk_trait_impl "core::default::Default<[@T; 0]>" "_root_.Aeneas.Std.core.default.DefaultArrayEmpty";
  (* file: "Aeneas/Std/Array/Array.lean", line: 295 *)
  mk_trait_impl "core::default::Default<[@T; @N]>" "_root_.Aeneas.Std.core.default.DefaultArray";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 98 *)
  mk_trait_impl "core::default::Default<alloc::collections::btree::map::BTreeMap<@K, @V, alloc::alloc::Global>>" "_root_.Aeneas.Std.alloc.collections.btree.map.DefaultBTreeMap";
  (* file: "Aeneas/Std/BTreeSet.lean", line: 120 *)
  mk_trait_impl "core::default::Default<alloc::collections::btree::set::BTreeSet<@T, alloc::alloc::Global>>" "_root_.Aeneas.Std.alloc.collections.btree.set.DefaultBTreeSet";
  (* file: "Aeneas/Std/VecDeque.lean", line: 32 *)
  mk_trait_impl "core::default::Default<alloc::collections::vec_deque::VecDeque<@T, alloc::alloc::Global>>" "_root_.Aeneas.Std.alloc.collections.vec_deque.DefaultVecDeque";
  (* file: "Aeneas/Std/Sync.lean", line: 117 *)
  mk_trait_impl "core::default::Default<alloc::rc::Rc<@T>>" "_root_.Aeneas.Std.core.default.DefaultRc" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/String.lean", line: 469 *)
  mk_trait_impl "core::default::Default<alloc::string::String>" "_root_.Aeneas.Std.core.default.DefaultString";
  (* file: "Aeneas/Std/Sync.lean", line: 106 *)
  mk_trait_impl "core::default::Default<alloc::sync::Arc<@T>>" "_root_.Aeneas.Std.core.default.DefaultArc";
  (* file: "Aeneas/Std/Vec.lean", line: 70 *)
  mk_trait_impl "core::default::Default<alloc::vec::Vec<@T>>" "_root_.Aeneas.Std.alloc.vec.DefaultVec";
  (* file: "Aeneas/Std/Core/Default.lean", line: 16 *)
  mk_trait_impl "core::default::Default<core::option::Option<@T>>" "_root_.Aeneas.Std.core.option.DefaultOption";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 316 *)
  mk_trait_impl "core::fmt::Debug<&'0 @T>" "_root_.Aeneas.Std.core.fmt.DebugShared";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 346 *)
  mk_trait_impl "core::fmt::Debug<()>" "_root_.Aeneas.Std.core.fmt.DebugUnit";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 178 *)
  mk_trait_impl "core::fmt::Debug<(@A, @B)>" "_root_.Aeneas.Std.core.fmt.DebugPair";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 187 *)
  mk_trait_impl "core::fmt::Debug<(@V, @U, @T)>" "_root_.Aeneas.Std.core.fmt.DebugTriple";
  (* file: "Aeneas/Std/Vec.lean", line: 813 *)
  mk_trait_impl "core::fmt::Debug<[@T]>" "_root_.Aeneas.Std.core.fmt.DebugSlice";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 90 *)
  mk_trait_impl "core::fmt::Debug<alloc::boxed::Box<@T>>" "_root_.Aeneas.Std.core.fmt.DebugBox" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 328 *)
  mk_trait_impl "core::fmt::Debug<alloc::collections::btree::map::BTreeMap<@K, @V, @A>>" "_root_.Aeneas.Std.alloc.collections.btree.map.DebugBTreeMap" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [true; true; false]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 105 *)
  mk_trait_impl "core::fmt::Debug<alloc::collections::btree::set::BTreeSet<@T, @A>>" "_root_.Aeneas.Std.alloc.collections.btree.set.DebugBTreeSet" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 75 *)
  mk_trait_impl "core::fmt::Debug<alloc::string::String>" "_root_.Aeneas.Std.core.fmt.DebugString";
  (* file: "Aeneas/Std/Sync.lean", line: 89 *)
  mk_trait_impl "core::fmt::Debug<alloc::sync::Arc<@T>>" "_root_.Aeneas.Std.core.fmt.DebugArc" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 820 *)
  mk_trait_impl "core::fmt::Debug<alloc::vec::Vec<@T>>" "_root_.Aeneas.Std.core.fmt.DebugVec" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 337 *)
  mk_trait_impl "core::fmt::Debug<bool>" "_root_.Aeneas.Std.core.fmt.DebugBool";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 52 *)
  mk_trait_impl "core::fmt::Debug<char>" "_root_.Aeneas.Std.core.fmt.DebugChar";
  (* file: "Aeneas/Std/Array/ArraySlice.lean", line: 184 *)
  mk_trait_impl "core::fmt::Debug<core::array::TryFromSliceError>" "_root_.Aeneas.Std.core.fmt.DebugTryFromSliceError";
  (* file: "Aeneas/Std/Core/Discriminant.lean", line: 125 *)
  mk_trait_impl "core::fmt::Debug<core::mem::Discriminant<@T>>" "_root_.Aeneas.Std.core.mem.DebugDiscriminant";
  (* file: "Aeneas/Std/Parse.lean", line: 329 *)
  mk_trait_impl "core::fmt::Debug<core::num::dec2flt::ParseFloatError>" "_root_.Aeneas.Std.core.fmt.DebugParseFloatError";
  (* file: "Aeneas/Std/Parse.lean", line: 165 *)
  mk_trait_impl "core::fmt::Debug<core::num::error::IntErrorKind>" "_root_.Aeneas.Std.core.fmt.DebugIntErrorKind";
  (* file: "Aeneas/Std/Parse.lean", line: 176 *)
  mk_trait_impl "core::fmt::Debug<core::num::error::ParseIntError>" "_root_.Aeneas.Std.core.fmt.DebugParseIntError";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 194 *)
  mk_trait_impl "core::fmt::Debug<core::num::error::TryFromIntError>" "_root_.Aeneas.Std.core.fmt.DebugTryFromIntError";
  (* file: "Aeneas/Std/Core/NonZeroTraits.lean", line: 63 *)
  mk_trait_impl "core::fmt::Debug<core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>>" "_root_.Aeneas.Std.core.fmt.DebugNonZero" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false; true]);
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 172 *)
  mk_trait_impl "core::fmt::Debug<core::option::Option<@T>>" "_root_.Aeneas.Std.core.fmt.DebugOption";
  (* file: "Aeneas/Std/FloatFmt.lean", line: 161 *)
  mk_trait_impl "core::fmt::Debug<f32>" "_root_.Aeneas.Std.core.fmt.DebugF32";
  (* file: "Aeneas/Std/FloatFmt.lean", line: 170 *)
  mk_trait_impl "core::fmt::Debug<f64>" "_root_.Aeneas.Std.core.fmt.DebugF64";
  (* file: "Aeneas/Std/FloatFmt.lean", line: 223 *)
  mk_trait_impl "core::fmt::Debug<half::bfloat::bf16>" "_root_.Aeneas.Std.core.fmt.DebugBF16";
  (* file: "Aeneas/Std/FloatFmt.lean", line: 214 *)
  mk_trait_impl "core::fmt::Debug<half::binary16::f16>" "_root_.Aeneas.Std.core.fmt.DebugF16";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 149 *)
  mk_trait_impl "core::fmt::Debug<i128>" "_root_.Aeneas.Std.core.fmt.DebugI128";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 113 *)
  mk_trait_impl "core::fmt::Debug<i16>" "_root_.Aeneas.Std.core.fmt.DebugI16";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 125 *)
  mk_trait_impl "core::fmt::Debug<i32>" "_root_.Aeneas.Std.core.fmt.DebugI32";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 137 *)
  mk_trait_impl "core::fmt::Debug<i64>" "_root_.Aeneas.Std.core.fmt.DebugI64";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 101 *)
  mk_trait_impl "core::fmt::Debug<i8>" "_root_.Aeneas.Std.core.fmt.DebugI8";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 161 *)
  mk_trait_impl "core::fmt::Debug<isize>" "_root_.Aeneas.Std.core.fmt.DebugIsize";
  (* file: "Aeneas/Std/BigUint.lean", line: 184 *)
  mk_trait_impl "core::fmt::Debug<num_bigint::biguint::BigUint>" "_root_.Aeneas.Std.num_bigint.DebugBigUint";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 65 *)
  mk_trait_impl "core::fmt::Debug<str>" "_root_.Aeneas.Std.core.fmt.DebugStr";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 77 *)
  mk_trait_impl "core::fmt::Debug<u128>" "_root_.Aeneas.Std.core.fmt.DebugU128";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 41 *)
  mk_trait_impl "core::fmt::Debug<u16>" "_root_.Aeneas.Std.core.fmt.DebugU16";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 53 *)
  mk_trait_impl "core::fmt::Debug<u32>" "_root_.Aeneas.Std.core.fmt.DebugU32";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 65 *)
  mk_trait_impl "core::fmt::Debug<u64>" "_root_.Aeneas.Std.core.fmt.DebugU64";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 29 *)
  mk_trait_impl "core::fmt::Debug<u8>" "_root_.Aeneas.Std.core.fmt.DebugU8";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 89 *)
  mk_trait_impl "core::fmt::Debug<usize>" "_root_.Aeneas.Std.core.fmt.DebugUsize";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 85 *)
  mk_trait_impl "core::fmt::Display<&'0 @T>" "_root_.Aeneas.Std.core.fmt.DisplayShared";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 95 *)
  mk_trait_impl "core::fmt::Display<alloc::boxed::Box<@T>>" "_root_.Aeneas.Std.core.fmt.DisplayBox" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 80 *)
  mk_trait_impl "core::fmt::Display<alloc::string::String>" "_root_.Aeneas.Std.core.fmt.DisplayString";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 341 *)
  mk_trait_impl "core::fmt::Display<bool>" "_root_.Aeneas.Std.core.fmt.DisplayBool";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 60 *)
  mk_trait_impl "core::fmt::Display<char>" "_root_.Aeneas.Std.core.fmt.DisplayChar";
  (* file: "Aeneas/Std/Parse.lean", line: 313 *)
  mk_trait_impl "core::fmt::Display<core::num::dec2flt::ParseFloatError>" "_root_.Aeneas.Std.core.fmt.DisplayParseFloatError";
  (* file: "Aeneas/Std/Parse.lean", line: 345 *)
  mk_trait_impl "core::fmt::Display<core::num::error::ParseIntError>" "_root_.Aeneas.Std.core.fmt.DisplayParseIntError";
  (* file: "Aeneas/Std/FloatFmt.lean", line: 165 *)
  mk_trait_impl "core::fmt::Display<f32>" "_root_.Aeneas.Std.core.fmt.DisplayF32";
  (* file: "Aeneas/Std/FloatFmt.lean", line: 174 *)
  mk_trait_impl "core::fmt::Display<f64>" "_root_.Aeneas.Std.core.fmt.DisplayF64";
  (* file: "Aeneas/Std/FloatFmt.lean", line: 227 *)
  mk_trait_impl "core::fmt::Display<half::bfloat::bf16>" "_root_.Aeneas.Std.core.fmt.DisplayBF16";
  (* file: "Aeneas/Std/FloatFmt.lean", line: 218 *)
  mk_trait_impl "core::fmt::Display<half::binary16::f16>" "_root_.Aeneas.Std.core.fmt.DisplayF16";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 155 *)
  mk_trait_impl "core::fmt::Display<i128>" "_root_.Aeneas.Std.core.fmt.DisplayI128";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 119 *)
  mk_trait_impl "core::fmt::Display<i16>" "_root_.Aeneas.Std.core.fmt.DisplayI16";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 131 *)
  mk_trait_impl "core::fmt::Display<i32>" "_root_.Aeneas.Std.core.fmt.DisplayI32";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 143 *)
  mk_trait_impl "core::fmt::Display<i64>" "_root_.Aeneas.Std.core.fmt.DisplayI64";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 107 *)
  mk_trait_impl "core::fmt::Display<i8>" "_root_.Aeneas.Std.core.fmt.DisplayI8";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 167 *)
  mk_trait_impl "core::fmt::Display<isize>" "_root_.Aeneas.Std.core.fmt.DisplayIsize";
  (* file: "Aeneas/Std/BigUint.lean", line: 180 *)
  mk_trait_impl "core::fmt::Display<num_bigint::biguint::BigUint>" "_root_.Aeneas.Std.num_bigint.DisplayBigUint";
  (* file: "Aeneas/Std/Core/FmtWithSlice.lean", line: 70 *)
  mk_trait_impl "core::fmt::Display<str>" "_root_.Aeneas.Std.core.fmt.DisplayStr";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 83 *)
  mk_trait_impl "core::fmt::Display<u128>" "_root_.Aeneas.Std.core.fmt.DisplayU128";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 47 *)
  mk_trait_impl "core::fmt::Display<u16>" "_root_.Aeneas.Std.core.fmt.DisplayU16";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 59 *)
  mk_trait_impl "core::fmt::Display<u32>" "_root_.Aeneas.Std.core.fmt.DisplayU32";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 71 *)
  mk_trait_impl "core::fmt::Display<u64>" "_root_.Aeneas.Std.core.fmt.DisplayU64";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 35 *)
  mk_trait_impl "core::fmt::Display<u8>" "_root_.Aeneas.Std.core.fmt.DisplayU8";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 95 *)
  mk_trait_impl "core::fmt::Display<usize>" "_root_.Aeneas.Std.core.fmt.DisplayUsize";
  (* file: "Aeneas/Std/FloatFmt.lean", line: 209 *)
  mk_trait_impl "core::fmt::LowerExp<f64>" "_root_.Aeneas.Std.core.fmt.LowerExpF64";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 330 *)
  mk_trait_impl "core::fmt::LowerHex<&'0 @T>" "_root_.Aeneas.Std.core.fmt.LowerHexShared";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 181 *)
  mk_trait_impl "core::fmt::LowerHex<u16>" "_root_.Aeneas.Std.core.fmt.LowerHexU16";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 187 *)
  mk_trait_impl "core::fmt::LowerHex<u32>" "_root_.Aeneas.Std.core.fmt.LowerHexU32";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 193 *)
  mk_trait_impl "core::fmt::LowerHex<u64>" "_root_.Aeneas.Std.core.fmt.LowerHexU64";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 175 *)
  mk_trait_impl "core::fmt::LowerHex<u8>" "_root_.Aeneas.Std.core.fmt.LowerHexU8";
  (* file: "Aeneas/Std/Core/Fmt.lean", line: 323 *)
  mk_trait_impl "core::fmt::UpperHex<&'0 @T>" "_root_.Aeneas.Std.core.fmt.UpperHexShared";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 207 *)
  mk_trait_impl "core::fmt::UpperHex<u32>" "_root_.Aeneas.Std.core.fmt.UpperHexU32";
  (* file: "Aeneas/Std/Scalar/Fmt.lean", line: 201 *)
  mk_trait_impl "core::fmt::UpperHex<u8>" "_root_.Aeneas.Std.core.fmt.UpperHexU8";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 312 *)
  mk_trait_impl "core::hash::Hash<&'0 @T>" "_root_.Aeneas.Std.core.hash.HashShared";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 142 *)
  mk_trait_impl "core::hash::Hash<Box<@T>>" "_root_.Aeneas.Std.core.hash.HashBox" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Core/Hash.lean", line: 323 *)
  mk_trait_impl "core::hash::Hash<[@T]>" "_root_.Aeneas.Std.core.hash.HashSlice";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 334 *)
  mk_trait_impl "core::hash::Hash<alloc::string::String>" "_root_.Aeneas.Std.core.hash.HashString";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 306 *)
  mk_trait_impl "core::hash::Hash<bool>" "_root_.Aeneas.Std.core.hash.HashBool";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 308 *)
  mk_trait_impl "core::hash::Hash<char>" "_root_.Aeneas.Std.core.hash.HashChar";
  (* file: "Aeneas/Std/Core/NonZeroTraits.lean", line: 46 *)
  mk_trait_impl "core::hash::Hash<core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>>" "_root_.Aeneas.Std.core.hash.HashNonZero" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false; true]);
  (* file: "Aeneas/Std/Core/Hash.lean", line: 347 *)
  mk_trait_impl "core::hash::Hash<core::option::Option<@T>>" "_root_.Aeneas.Std.core.hash.HashOption";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 300 *)
  mk_trait_impl "core::hash::Hash<i128>" "_root_.Aeneas.Std.core.hash.HashI128";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 291 *)
  mk_trait_impl "core::hash::Hash<i16>" "_root_.Aeneas.Std.core.hash.HashI16";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 294 *)
  mk_trait_impl "core::hash::Hash<i32>" "_root_.Aeneas.Std.core.hash.HashI32";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 297 *)
  mk_trait_impl "core::hash::Hash<i64>" "_root_.Aeneas.Std.core.hash.HashI64";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 288 *)
  mk_trait_impl "core::hash::Hash<i8>" "_root_.Aeneas.Std.core.hash.HashI8";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 303 *)
  mk_trait_impl "core::hash::Hash<isize>" "_root_.Aeneas.Std.core.hash.HashIsize";
  (* file: "Aeneas/Std/BigUint.lean", line: 115 *)
  mk_trait_impl "core::hash::Hash<num_bigint::biguint::BigUint>" "_root_.Aeneas.Std.num_bigint.HashBigUint";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 310 *)
  mk_trait_impl "core::hash::Hash<str>" "_root_.Aeneas.Std.core.hash.HashStr";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 282 *)
  mk_trait_impl "core::hash::Hash<u128>" "_root_.Aeneas.Std.core.hash.HashU128";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 273 *)
  mk_trait_impl "core::hash::Hash<u16>" "_root_.Aeneas.Std.core.hash.HashU16";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 276 *)
  mk_trait_impl "core::hash::Hash<u32>" "_root_.Aeneas.Std.core.hash.HashU32";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 279 *)
  mk_trait_impl "core::hash::Hash<u64>" "_root_.Aeneas.Std.core.hash.HashU64";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 270 *)
  mk_trait_impl "core::hash::Hash<u8>" "_root_.Aeneas.Std.core.hash.HashU8";
  (* file: "Aeneas/Std/Core/Hash.lean", line: 285 *)
  mk_trait_impl "core::hash::Hash<usize>" "_root_.Aeneas.Std.core.hash.HashUsize";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1222 *)
  mk_trait_impl "core::iter::range::Step<i32>" "_root_.Aeneas.Std.core.iter.range.StepI32";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1320 *)
  mk_trait_impl "core::iter::range::Step<usize>" "_root_.Aeneas.Std.core.iter.range.StepUsize";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 899 *)
  mk_trait_impl "core::iter::traits::accum::Product<usize, &'a usize>" "_root_.Aeneas.Std.core.iter.traits.accum.ProductUsizeSharedUsize";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 918 *)
  mk_trait_impl "core::iter::traits::accum::Product<usize, usize>" "_root_.Aeneas.Std.core.iter.traits.accum.ProductUsizeUsize";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 965 *)
  mk_trait_impl "core::iter::traits::accum::Sum<usize, &'a usize>" "_root_.Aeneas.Std.core.iter.traits.accum.SumUsizeSharedUsize";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 946 *)
  mk_trait_impl "core::iter::traits::accum::Sum<usize, usize>" "_root_.Aeneas.Std.core.iter.traits.accum.SumUsizeUsize";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 767 *)
  mk_trait_impl "core::iter::traits::collect::Extend<alloc::collections::btree::map::BTreeMap<@K, @V, @A>, (@K, @V)>" "_root_.Aeneas.Std.core.iter.traits.collect.ExtendBTreeMap" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 283 *)
  mk_trait_impl "core::iter::traits::collect::Extend<alloc::collections::btree::set::BTreeSet<@T, @A>, @T>" "_root_.Aeneas.Std.core.iter.traits.collect.ExtendBTreeSet" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 118 *)
  mk_trait_impl "core::iter::traits::collect::Extend<alloc::vec::Vec<@T>, &'a @T>" "_root_.Aeneas.Std.alloc.vec.ExtendVecShared" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/Vec.lean", line: 100 *)
  mk_trait_impl "core::iter::traits::collect::Extend<alloc::vec::Vec<@T>, @T>" "_root_.Aeneas.Std.alloc.vec.ExtendVec" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 761 *)
  mk_trait_impl "core::iter::traits::collect::FromIterator<alloc::collections::btree::map::BTreeMap<@K, @V, alloc::alloc::Global>, (@K, @V)>" "_root_.Aeneas.Std.core.iter.traits.collect.FromIteratorBTreeMap";
  (* file: "Aeneas/Std/BTreeSet.lean", line: 277 *)
  mk_trait_impl "core::iter::traits::collect::FromIterator<alloc::collections::btree::set::BTreeSet<@T, alloc::alloc::Global>, @T>" "_root_.Aeneas.Std.core.iter.traits.collect.FromIteratorBTreeSet";
  (* file: "Aeneas/Std/VecDeque.lean", line: 143 *)
  mk_trait_impl "core::iter::traits::collect::FromIterator<alloc::collections::vec_deque::VecDeque<@T, alloc::alloc::Global>, @T>" "_root_.Aeneas.Std.core.iter.traits.collect.FromIteratorVecDeque";
  (* file: "Aeneas/Std/VecIter.lean", line: 276 *)
  mk_trait_impl "core::iter::traits::collect::FromIterator<alloc::string::String, char>" "_root_.Aeneas.Std.core.iter.traits.collect.FromIteratorStringChar";
  (* file: "Aeneas/Std/VecIter.lean", line: 252 *)
  mk_trait_impl "core::iter::traits::collect::FromIterator<alloc::vec::Vec<@T>, @T>" "_root_.Aeneas.Std.core.iter.traits.collect.FromIteratorVec";
  (* file: "Aeneas/Std/ResultIter.lean", line: 177 *)
  mk_trait_impl "core::iter::traits::collect::FromIterator<core::option::Option<@V>, core::option::Option<@A>>" "_root_.Aeneas.Std.core.iter.traits.collect.FromIteratorOption";
  (* file: "Aeneas/Std/ResultIter.lean", line: 148 *)
  mk_trait_impl "core::iter::traits::collect::FromIterator<core::result::Result<@V, @E>, core::result::Result<@A, @E>>" "_root_.Aeneas.Std.core.iter.traits.collect.FromIteratorResult";
  (* file: "Aeneas/Std/SliceIter.lean", line: 429 *)
  mk_trait_impl "core::iter::traits::collect::IntoIterator<&'a [@T; @N], &'a @T, core::slice::iter::Iter<'a, @T>>" "_root_.Aeneas.Std.core.iter.traits.collect.IntoIteratorSharedArray";
  (* file: "Aeneas/Std/SliceIter.lean", line: 412 *)
  mk_trait_impl "core::iter::traits::collect::IntoIterator<&'a [@T], &'a @T, core::slice::iter::Iter<'a, @T>>" "_root_.Aeneas.Std.core.iter.traits.collect.IntoIteratorSharedSlice";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 753 *)
  mk_trait_impl "core::iter::traits::collect::IntoIterator<&'a alloc::collections::btree::map::BTreeMap<@K, @V, @A>, (&'a @K, &'a @V), alloc::collections::btree::map::Iter<'a, @K, @V>>" "_root_.Aeneas.Std.core.iter.traits.collect.IntoIteratorSharedBTreeMap" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 331 *)
  mk_trait_impl "core::iter::traits::collect::IntoIterator<&'a alloc::collections::btree::set::BTreeSet<@T, @A>, &'a @T, alloc::collections::btree::set::Iter<'a, @T>>" "_root_.Aeneas.Std.core.iter.traits.collect.IntoIteratorSharedBTreeSet" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/VecIter.lean", line: 209 *)
  mk_trait_impl "core::iter::traits::collect::IntoIterator<&'a alloc::vec::Vec<@T>, &'a @T, core::slice::iter::Iter<'a, @T>>" "_root_.Aeneas.Std.core.iter.traits.collect.IntoIteratorSharedVec" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/IteratorSources.lean", line: 526 *)
  mk_trait_impl "core::iter::traits::collect::IntoIterator<&'a core::option::Option<@T>, &'a @T, core::option::Iter<'a, @T>>" "_root_.Aeneas.Std.core.iter.traits.collect.IntoIteratorSharedOption";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 995 *)
  mk_trait_impl "core::iter::traits::collect::IntoIterator<@I, @Item, @I>" "_root_.Aeneas.Std.core.iter.traits.collect.IntoIterator.Blanket";
  (* file: "Aeneas/Std/VecIter.lean", line: 190 *)
  mk_trait_impl "core::iter::traits::collect::IntoIterator<Box<[@I]>, @I, alloc::vec::into_iter::IntoIter<@I, @A>>" "_root_.Aeneas.Std.core.iter.traits.collect.IntoIteratorBoxSlice" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/ArrayIter.lean", line: 104 *)
  mk_trait_impl "core::iter::traits::collect::IntoIterator<[@T; @N], @T, core::array::iter::IntoIter<@T, @N>>" "_root_.Aeneas.Std.core.iter.traits.collect.IntoIteratorArray";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 745 *)
  mk_trait_impl "core::iter::traits::collect::IntoIterator<alloc::collections::btree::map::BTreeMap<@K, @V, @A>, (@K, @V), alloc::collections::btree::map::IntoIter<@K, @V, @A>>" "_root_.Aeneas.Std.core.iter.traits.collect.IntoIteratorBTreeMap" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 301 *)
  mk_trait_impl "core::iter::traits::collect::IntoIterator<alloc::collections::btree::set::BTreeSet<@T, @A>, @T, alloc::collections::btree::set::IntoIter<@T, @A>>" "_root_.Aeneas.Std.core.iter.traits.collect.IntoIteratorBTreeSet" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/VecIter.lean", line: 171 *)
  mk_trait_impl "core::iter::traits::collect::IntoIterator<alloc::vec::Vec<@T>, @T, alloc::vec::into_iter::IntoIter<@T, @A>>" "_root_.Aeneas.Std.core.iter.traits.collect.IntoIteratorVec" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/IteratorSources.lean", line: 584 *)
  mk_trait_impl "core::iter::traits::collect::IntoIterator<core::option::Option<@T>, @T, core::option::IntoIter<@T>>" "_root_.Aeneas.Std.core.iter.traits.collect.IntoIteratorOption";
  (* file: "Aeneas/Std/VecDrain.lean", line: 78 *)
  mk_trait_impl "core::iter::traits::double_ended::DoubleEndedIterator<alloc::vec::drain::Drain<'a, @T, @A>, @T>" "_root_.Aeneas.Std.core.iter.traits.double_ended.DoubleEndedIteratorVecDrain" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/VecIter.lean", line: 150 *)
  mk_trait_impl "core::iter::traits::double_ended::DoubleEndedIterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>" "_root_.Aeneas.Std.core.iter.traits.double_ended.DoubleEndedIteratorVecIntoIter" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 396 *)
  mk_trait_impl "core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Clause0_Item)>" "_root_.Aeneas.Std.core.iter.traits.double_ended.DoubleEndedIteratorEnumerate";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 1196 *)
  mk_trait_impl "core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::filter::Filter<@I, @P>, @Clause0_Clause0_Item>" "_root_.Aeneas.Std.core.iter.traits.double_ended.DoubleEndedIteratorFilter";
  (* file: "Aeneas/Std/FlatMap.lean", line: 657 *)
  mk_trait_impl "core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause2_Item, @Clause2_IntoIter>, @Clause2_Item>" "_root_.Aeneas.Std.core.iter.traits.double_ended.DoubleEndedIteratorFlatMap";
  (* file: "Aeneas/Std/FlatMap.lean", line: 944 *)
  mk_trait_impl "core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Clause0_Item, @Clause2_Clause0_Item, @U>, @Clause2_Clause0_Item>" "_root_.Aeneas.Std.core.iter.traits.double_ended.DoubleEndedIteratorFlatten";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 692 *)
  mk_trait_impl "core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::map::Map<@I, @F>, @B>" "_root_.Aeneas.Std.core.iter.traits.double_ended.DoubleEndedIteratorMap";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 178 *)
  mk_trait_impl "core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>" "_root_.Aeneas.Std.core.iter.traits.double_ended.DoubleEndedIteratorRev";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 959 *)
  mk_trait_impl "core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Clause0_Item>" "_root_.Aeneas.Std.core.iter.traits.double_ended.DoubleEndedIteratorSkip";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1890 *)
  mk_trait_impl "core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Clause0_Item>" "_root_.Aeneas.Std.core.iter.traits.double_ended.DoubleEndedIteratorStepBy";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1785 *)
  mk_trait_impl "core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::take::Take<@I>, @Clause0_Clause0_Item>" "_root_.Aeneas.Std.core.iter.traits.double_ended.DoubleEndedIteratorTake";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 636 *)
  mk_trait_impl "core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::zip::Zip<@A, @B>, (@Clause0_Clause0_Item, @Clause2_Clause0_Item)>" "_root_.Aeneas.Std.core.iter.traits.double_ended.DoubleEndedIteratorZip";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1549 *)
  mk_trait_impl "core::iter::traits::double_ended::DoubleEndedIterator<core::ops::range::Range<@A>, @A>" "_root_.Aeneas.Std.core.iter.traits.double_ended.DoubleEndedIteratorRange";
  (* file: "Aeneas/Std/SliceIter.lean", line: 376 *)
  mk_trait_impl "core::iter::traits::double_ended::DoubleEndedIterator<core::slice::iter::Iter<'a, @T>, &'_ @T>" "_root_.Aeneas.Std.core.iter.traits.double_ended.DoubleEndedIteratorSliceIter";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 420 *)
  mk_trait_impl "core::iter::traits::exact_size::ExactSizeIterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Clause0_Item)>" "_root_.Aeneas.Std.core.iter.traits.exact_size.ExactSizeIteratorEnumerate";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 975 *)
  mk_trait_impl "core::iter::traits::exact_size::ExactSizeIterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Clause0_Item>" "_root_.Aeneas.Std.core.iter.traits.exact_size.ExactSizeIteratorSkip";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1903 *)
  mk_trait_impl "core::iter::traits::exact_size::ExactSizeIterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Clause0_Item>" "_root_.Aeneas.Std.core.iter.traits.exact_size.ExactSizeIteratorStepBy";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1799 *)
  mk_trait_impl "core::iter::traits::exact_size::ExactSizeIterator<core::iter::adapters::take::Take<@I>, @Clause0_Clause0_Item>" "_root_.Aeneas.Std.core.iter.traits.exact_size.ExactSizeIteratorTake";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1911 *)
  mk_trait_impl "core::iter::traits::exact_size::ExactSizeIterator<core::ops::range::Range<usize>, usize>" "_root_.Aeneas.Std.core.iter.traits.exact_size.ExactSizeIteratorRangeUsize";
  (* file: "Aeneas/Std/SliceIter.lean", line: 396 *)
  mk_trait_impl "core::iter::traits::exact_size::ExactSizeIterator<core::slice::iter::Iter<'a, @T>, &'_ @T>" "_root_.Aeneas.Std.core.iter.traits.exact_size.ExactSizeIteratorSliceIter";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 464 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<&'a mut @I, @Item>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorMut";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 603 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<alloc::collections::btree::map::IntoIter<@K, @V, @A>, (@K, @V)>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorBTreeIntoIter" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 618 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<alloc::collections::btree::map::IntoValues<@K, @V, @A>, @V>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorBTreeIntoValues" ~keep_params:(Some [true; true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeMap.lean", line: 591 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Iter<'a, @K, @V>, (&'a @K, &'a @V)>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorBTreeIter";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 630 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Keys<'a, @K, @V>, &'a @K>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorBTreeKeys";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 641 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Values<'a, @K, @V>, &'a @V>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorBTreeValues";
  (* file: "Aeneas/Std/BTreeSet.lean", line: 292 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<alloc::collections::btree::set::IntoIter<@T, @A>, @T>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorBTreeSetIntoIter" ~keep_params:(Some [true; false]) ~keep_trait_clauses:(Some [false]);
  (* file: "Aeneas/Std/BTreeSet.lean", line: 312 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<alloc::collections::btree::set::Iter<'a, @T>, &'a @T>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorBTreeSetIter";
  (* file: "Aeneas/Std/VecDrain.lean", line: 66 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<alloc::vec::drain::Drain<'a, @T, @A>, @T>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorVecDrain" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/VecIter.lean", line: 98 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorVecIntoIter" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/ArrayIter.lean", line: 81 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::array::iter::IntoIter<@T, @N>, @T>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorArrayIntoIter";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 274 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::iter::adapters::chain::Chain<@A, @B>, @Clause0_Item>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorChain";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 1006 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::iter::adapters::cloned::Cloned<@I>, @T>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorCloned";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 949 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::iter::adapters::copied::Copied<@I>, @T>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorCopied";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 281 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Item)>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorEnumerate";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 1114 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::iter::adapters::filter::Filter<@I, @P>, @Clause0_Item>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorFilter";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 762 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::iter::adapters::filter_map::FilterMap<@I, @F>, @B>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorFilterMap";
  (* file: "Aeneas/Std/FlatMap.lean", line: 555 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause1_Item, @Clause1_IntoIter>, @Clause1_Item>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorFlatMap";
  (* file: "Aeneas/Std/FlatMap.lean", line: 859 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Item, @Clause2_Item, @U>, @Clause2_Item>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorFlatten";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 545 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorMap";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 96 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorRev";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 813 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Item>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorSkip";
  (* file: "Aeneas/Std/IteratorAdapters.lean", line: 1310 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::iter::adapters::skip_while::SkipWhile<@I, @P>, @Clause0_Item>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorSkipWhile";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 725 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Item>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorStepBy";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1678 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::iter::adapters::take::Take<@I>, @Clause0_Item>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorTake";
  (* file: "Aeneas/Std/IteratorCombinators.lean", line: 522 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::iter::adapters::zip::Zip<@A, @B>, (@Clause0_Item, @Clause1_Item)>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorZip";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 469 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::iter::sources::empty::Empty<@T>, @T>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorEmpty";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 354 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::iter::sources::once::Once<@T>, @T>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorOnce";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 434 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::iter::sources::repeat_with::RepeatWith<@F>, @A>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorRepeatWith";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1472 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::ops::range::Range<@A>, @A>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorRange";
  (* file: "Aeneas/Std/Core/Iter.lean", line: 1523 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::ops::range::RangeFrom<@A>, @A>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorRangeFrom";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 253 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::ops::range::RangeInclusive<@A>, @A>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorRangeInclusive";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 573 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::option::IntoIter<@A>, @A>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorOptionIntoIter";
  (* file: "Aeneas/Std/IteratorSources.lean", line: 507 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::option::Iter<'a, @A>, &'a @A>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorOptionIter";
  (* file: "Aeneas/Std/SliceIter.lean", line: 635 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::slice::iter::Chunks<'a, @T>, &'a [@T]>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorChunks";
  (* file: "Aeneas/Std/SliceIter.lean", line: 739 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::slice::iter::ChunksExact<'a, @T>, &'a [@T]>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorChunksExact";
  (* file: "Aeneas/Std/SliceIter.lean", line: 269 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorSliceIter";
  (* file: "Aeneas/Std/SliceIter.lean", line: 520 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::slice::iter::Windows<'a, @T>, &'a [@T]>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorWindows";
  (* file: "Aeneas/Std/StringIter.lean", line: 744 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::str::iter::Bytes<'a>, u8>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorBytes";
  (* file: "Aeneas/Std/StringIter.lean", line: 144 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::str::iter::Chars<'a>, char>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorChars";
  (* file: "Aeneas/Std/StringIter.lean", line: 237 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::str::iter::Lines<'a>, &'a str>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorLines";
  (* file: "Aeneas/Std/StringIter.lean", line: 870 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::str::iter::RSplit<'a, @P>, &'a str>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorRSplit" ~keep_trait_clauses:(Some [true; false]);
  (* file: "Aeneas/Std/StringIter.lean", line: 628 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::str::iter::Split<'a, @P>, &'a str>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorSplit";
  (* file: "Aeneas/Std/StringIter.lean", line: 678 *)
  mk_trait_impl "core::iter::traits::iterator::Iterator<core::str::iter::SplitN<'a, @P>, &'a str>" "_root_.Aeneas.Std.core.iter.traits.iterator.IteratorSplitN";
  (* file: "Aeneas/Std/Core/Core.lean", line: 141 *)
  mk_trait_impl "core::marker::Copy<bool>" "_root_.Aeneas.Std.core.core.marker.CopyBool";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 97 *)
  mk_trait_impl "core::marker::Copy<char>" "_root_.Aeneas.Std.core.marker.CopyChar";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 446 *)
  mk_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroCharInner>" "_root_.Aeneas.Std.core.marker.CopyNonZeroCharInner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 390 *)
  mk_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroI128Inner>" "_root_.Aeneas.Std.core.marker.CopyNonZeroI128Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 306 *)
  mk_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroI16Inner>" "_root_.Aeneas.Std.core.marker.CopyNonZeroI16Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 334 *)
  mk_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroI32Inner>" "_root_.Aeneas.Std.core.marker.CopyNonZeroI32Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 362 *)
  mk_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroI64Inner>" "_root_.Aeneas.Std.core.marker.CopyNonZeroI64Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 278 *)
  mk_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroI8Inner>" "_root_.Aeneas.Std.core.marker.CopyNonZeroI8Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 418 *)
  mk_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroIsizeInner>" "_root_.Aeneas.Std.core.marker.CopyNonZeroIsizeInner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 222 *)
  mk_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroU128Inner>" "_root_.Aeneas.Std.core.marker.CopyNonZeroU128Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 138 *)
  mk_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroU16Inner>" "_root_.Aeneas.Std.core.marker.CopyNonZeroU16Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 166 *)
  mk_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroU32Inner>" "_root_.Aeneas.Std.core.marker.CopyNonZeroU32Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 194 *)
  mk_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroU64Inner>" "_root_.Aeneas.Std.core.marker.CopyNonZeroU64Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 110 *)
  mk_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroU8Inner>" "_root_.Aeneas.Std.core.marker.CopyNonZeroU8Inner";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 250 *)
  mk_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroUsizeInner>" "_root_.Aeneas.Std.core.marker.CopyNonZeroUsizeInner";
  (* file: "Aeneas/Std/Float.lean", line: 453 *)
  mk_trait_impl "core::marker::Copy<f32>" "_root_.Aeneas.Std.core.marker.CopyF32";
  (* file: "Aeneas/Std/Float.lean", line: 593 *)
  mk_trait_impl "core::marker::Copy<f64>" "_root_.Aeneas.Std.core.marker.CopyF64";
  (* file: "Aeneas/Std/Float.lean", line: 637 *)
  mk_trait_impl "core::marker::Copy<half::bfloat::bf16>" "_root_.Aeneas.Std.core.marker.CopyBF16";
  (* file: "Aeneas/Std/Float.lean", line: 620 *)
  mk_trait_impl "core::marker::Copy<half::binary16::f16>" "_root_.Aeneas.Std.core.marker.CopyF16";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 454 *)
  mk_trait_impl "core::num::nonzero::ZeroablePrimitive<char, core::num::niche_types::NonZeroCharInner>" "_root_.Aeneas.Std.core.num.nonzero.ZeroablePrimitiveChar";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 398 *)
  mk_trait_impl "core::num::nonzero::ZeroablePrimitive<i128, core::num::niche_types::NonZeroI128Inner>" "_root_.Aeneas.Std.core.num.nonzero.ZeroablePrimitiveI128";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 314 *)
  mk_trait_impl "core::num::nonzero::ZeroablePrimitive<i16, core::num::niche_types::NonZeroI16Inner>" "_root_.Aeneas.Std.core.num.nonzero.ZeroablePrimitiveI16";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 342 *)
  mk_trait_impl "core::num::nonzero::ZeroablePrimitive<i32, core::num::niche_types::NonZeroI32Inner>" "_root_.Aeneas.Std.core.num.nonzero.ZeroablePrimitiveI32";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 370 *)
  mk_trait_impl "core::num::nonzero::ZeroablePrimitive<i64, core::num::niche_types::NonZeroI64Inner>" "_root_.Aeneas.Std.core.num.nonzero.ZeroablePrimitiveI64";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 286 *)
  mk_trait_impl "core::num::nonzero::ZeroablePrimitive<i8, core::num::niche_types::NonZeroI8Inner>" "_root_.Aeneas.Std.core.num.nonzero.ZeroablePrimitiveI8";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 426 *)
  mk_trait_impl "core::num::nonzero::ZeroablePrimitive<isize, core::num::niche_types::NonZeroIsizeInner>" "_root_.Aeneas.Std.core.num.nonzero.ZeroablePrimitiveIsize";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 230 *)
  mk_trait_impl "core::num::nonzero::ZeroablePrimitive<u128, core::num::niche_types::NonZeroU128Inner>" "_root_.Aeneas.Std.core.num.nonzero.ZeroablePrimitiveU128";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 146 *)
  mk_trait_impl "core::num::nonzero::ZeroablePrimitive<u16, core::num::niche_types::NonZeroU16Inner>" "_root_.Aeneas.Std.core.num.nonzero.ZeroablePrimitiveU16";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 174 *)
  mk_trait_impl "core::num::nonzero::ZeroablePrimitive<u32, core::num::niche_types::NonZeroU32Inner>" "_root_.Aeneas.Std.core.num.nonzero.ZeroablePrimitiveU32";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 202 *)
  mk_trait_impl "core::num::nonzero::ZeroablePrimitive<u64, core::num::niche_types::NonZeroU64Inner>" "_root_.Aeneas.Std.core.num.nonzero.ZeroablePrimitiveU64";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 118 *)
  mk_trait_impl "core::num::nonzero::ZeroablePrimitive<u8, core::num::niche_types::NonZeroU8Inner>" "_root_.Aeneas.Std.core.num.nonzero.ZeroablePrimitiveU8";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 258 *)
  mk_trait_impl "core::num::nonzero::ZeroablePrimitive<usize, core::num::niche_types::NonZeroUsizeInner>" "_root_.Aeneas.Std.core.num.nonzero.ZeroablePrimitiveUsize";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 451 *)
  mk_trait_impl "core::num::nonzero::private::Sealed<char>" "_root_.Aeneas.Std.core.num.nonzero.private.SealedChar";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 395 *)
  mk_trait_impl "core::num::nonzero::private::Sealed<i128>" "_root_.Aeneas.Std.core.num.nonzero.private.SealedI128";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 311 *)
  mk_trait_impl "core::num::nonzero::private::Sealed<i16>" "_root_.Aeneas.Std.core.num.nonzero.private.SealedI16";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 339 *)
  mk_trait_impl "core::num::nonzero::private::Sealed<i32>" "_root_.Aeneas.Std.core.num.nonzero.private.SealedI32";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 367 *)
  mk_trait_impl "core::num::nonzero::private::Sealed<i64>" "_root_.Aeneas.Std.core.num.nonzero.private.SealedI64";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 283 *)
  mk_trait_impl "core::num::nonzero::private::Sealed<i8>" "_root_.Aeneas.Std.core.num.nonzero.private.SealedI8";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 423 *)
  mk_trait_impl "core::num::nonzero::private::Sealed<isize>" "_root_.Aeneas.Std.core.num.nonzero.private.SealedIsize";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 227 *)
  mk_trait_impl "core::num::nonzero::private::Sealed<u128>" "_root_.Aeneas.Std.core.num.nonzero.private.SealedU128";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 143 *)
  mk_trait_impl "core::num::nonzero::private::Sealed<u16>" "_root_.Aeneas.Std.core.num.nonzero.private.SealedU16";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 171 *)
  mk_trait_impl "core::num::nonzero::private::Sealed<u32>" "_root_.Aeneas.Std.core.num.nonzero.private.SealedU32";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 199 *)
  mk_trait_impl "core::num::nonzero::private::Sealed<u64>" "_root_.Aeneas.Std.core.num.nonzero.private.SealedU64";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 115 *)
  mk_trait_impl "core::num::nonzero::private::Sealed<u8>" "_root_.Aeneas.Std.core.num.nonzero.private.SealedU8";
  (* file: "Aeneas/Std/Core/NonZero.lean", line: 255 *)
  mk_trait_impl "core::num::nonzero::private::Sealed<usize>" "_root_.Aeneas.Std.core.num.nonzero.private.SealedUsize";
  (* file: "Aeneas/Std/Scalar/Ops/Mul.lean", line: 27 *)
  mk_trait_impl "core::ops::arith::MulAssign<usize, &'a usize>" "_root_.Aeneas.Std.core.ops.arith.MulAssignUsizeShared";
  (* file: "Aeneas/Std/Core/Ops.lean", line: 29 *)
  mk_trait_impl "core::ops::deref::Deref<Box<@T>, @T>" "_root_.Aeneas.Std.core.ops.deref.DerefBoxInst" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Core/Borrow.lean", line: 94 *)
  mk_trait_impl "core::ops::deref::Deref<alloc::borrow::Cow<'0, @B, @O>, @B>" "_root_.Aeneas.Std.alloc.borrow.DerefCow";
  (* file: "Aeneas/Std/Sync.lean", line: 77 *)
  mk_trait_impl "core::ops::deref::Deref<alloc::rc::Rc<@T>, @T>" "_root_.Aeneas.Std.core.ops.deref.DerefRc" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Sync.lean", line: 67 *)
  mk_trait_impl "core::ops::deref::Deref<alloc::sync::Arc<@T>, @T>" "_root_.Aeneas.Std.core.ops.deref.DerefArc" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 617 *)
  mk_trait_impl "core::ops::deref::Deref<alloc::vec::Vec<@T>, [@T]>" "_root_.Aeneas.Std.core.ops.deref.DerefVec" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Core/UnwindSafe.lean", line: 24 *)
  mk_trait_impl "core::ops::deref::Deref<core::panic::unwind_safe::AssertUnwindSafe<@T>, @T>" "_root_.Aeneas.Std.core.panic.unwind_safe.DerefAssertUnwindSafe";
  (* file: "Aeneas/Std/Core/Ops.lean", line: 36 *)
  mk_trait_impl "core::ops::deref::DerefMut<Box<@T>, @T>" "_root_.Aeneas.Std.core.ops.deref.DerefMutBoxInst" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Vec.lean", line: 628 *)
  mk_trait_impl "core::ops::deref::DerefMut<alloc::vec::Vec<@T>, [@T]>" "_root_.Aeneas.Std.core.ops.deref.DerefMutVec" ~keep_params:(Some [true; false]);
  (* file: "Aeneas/Std/Core/UnwindSafe.lean", line: 40 *)
  mk_trait_impl "core::ops::deref::DerefMut<core::panic::unwind_safe::AssertUnwindSafe<@T>, @T>" "_root_.Aeneas.Std.core.panic.unwind_safe.DerefMutAssertUnwindSafe";
  (* file: "Aeneas/Std/Core/Ops.lean", line: 222 *)
  mk_trait_impl "core::ops::function::FnMut<&'0 mut @F, @A, @Clause0_Clause0_Output>" "_root_.Aeneas.Std.core.ops.function.FnMutMutRef";
  (* file: "Aeneas/Std/Core/Ops.lean", line: 210 *)
  mk_trait_impl "core::ops::function::FnOnce<&'0 mut @F, @A, @Clause0_Clause0_Output>" "_root_.Aeneas.Std.core.ops.function.FnOnceMutRef";
  (* file: "Aeneas/Std/Core/UnwindSafe.lean", line: 57 *)
  mk_trait_impl "core::ops::function::FnOnce<core::panic::unwind_safe::AssertUnwindSafe<@F>, (), @R>" "_root_.Aeneas.Std.core.panic.unwind_safe.FnOnceAssertUnwindSafe";
  (* file: "Aeneas/Std/Array/ArraySlice.lean", line: 100 *)
  mk_trait_impl "core::ops::index::Index<[@T; @N], @I, @O>" "_root_.Aeneas.Std.core.ops.index.IndexArray";
  (* file: "Aeneas/Std/Slice.lean", line: 574 *)
  mk_trait_impl "core::ops::index::Index<[@T], @I, @O>" "_root_.Aeneas.Std.core.ops.index.IndexSlice";
  (* file: "Aeneas/Std/BTreeMap.lean", line: 787 *)
  mk_trait_impl "core::ops::index::Index<alloc::collections::btree::map::BTreeMap<@K, @V, @A>, &'0 @Q, @V>" "_root_.Aeneas.Std.core.ops.index.IndexBTreeMap" ~keep_params:(Some [true; true; true; false]) ~keep_trait_clauses:(Some [false; true; true; true]);
  (* file: "Aeneas/Std/Vec.lean", line: 390 *)
  mk_trait_impl "core::ops::index::Index<alloc::vec::Vec<@T>, @T, @O>" "_root_.Aeneas.Std.alloc.vec.Vec.Index" ~keep_params:(Some [true; true; false; true]);
  (* file: "Aeneas/Std/Array/ArraySlice.lean", line: 107 *)
  mk_trait_impl "core::ops::index::IndexMut<[@T; @N], @I, @O>" "_root_.Aeneas.Std.core.ops.index.IndexMutArray";
  (* file: "Aeneas/Std/Slice.lean", line: 581 *)
  mk_trait_impl "core::ops::index::IndexMut<[@T], @I, @O>" "_root_.Aeneas.Std.core.ops.index.IndexMutSlice";
  (* file: "Aeneas/Std/Vec.lean", line: 398 *)
  mk_trait_impl "core::ops::index::IndexMut<alloc::vec::Vec<@T>, @T, @O>" "_root_.Aeneas.Std.alloc.vec.Vec.IndexMut" ~keep_params:(Some [true; true; false; true]);
  (* file: "Aeneas/Std/RangeBounds.lean", line: 83 *)
  mk_trait_impl "core::ops::range::RangeBounds<core::ops::range::Range<@T>, @T>" "_root_.Aeneas.Std.core.ops.range.RangeBoundsRange";
  (* file: "Aeneas/Std/RangeBounds.lean", line: 49 *)
  mk_trait_impl "core::ops::range::RangeBounds<core::ops::range::RangeFrom<@T>, @T>" "_root_.Aeneas.Std.core.ops.range.RangeBoundsRangeFrom";
  (* file: "Aeneas/Std/RangeBounds.lean", line: 33 *)
  mk_trait_impl "core::ops::range::RangeBounds<core::ops::range::RangeFull, @T>" "_root_.Aeneas.Std.core.ops.range.RangeBoundsRangeFull";
  (* file: "Aeneas/Std/RangeBounds.lean", line: 101 *)
  mk_trait_impl "core::ops::range::RangeBounds<core::ops::range::RangeInclusive<@T>, @T>" "_root_.Aeneas.Std.core.ops.range.RangeBoundsRangeInclusive";
  (* file: "Aeneas/Std/RangeBounds.lean", line: 66 *)
  mk_trait_impl "core::ops::range::RangeBounds<core::ops::range::RangeTo<@T>, @T>" "_root_.Aeneas.Std.core.ops.range.RangeBoundsRangeTo";
  (* file: "Aeneas/Std/Core/Result.lean", line: 23 *)
  mk_trait_impl "core::ops::try_trait::FromResidual<core::result::Result<@T, @F>, core::result::Result<core::convert::Infallible, @E>>" "_root_.Aeneas.Std.core.result.FromResidualResult";
  (* file: "Aeneas/Std/Core/Result.lean", line: 47 *)
  mk_trait_impl "core::ops::try_trait::Try<core::result::Result<@T, @E>, @T, core::result::Result<core::convert::Infallible, @E>>" "_root_.Aeneas.Std.core.result.TryResult";
  (* file: "Aeneas/Std/Slice.lean", line: 435 *)
  mk_trait_impl "core::slice::index::SliceIndex<core::ops::range::Range<usize>, [@T], [@T]>" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeUsizeSlice";
  (* file: "Aeneas/Std/StringIter.lean", line: 813 *)
  mk_trait_impl "core::slice::index::SliceIndex<core::ops::range::Range<usize>, str, str>" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeUsizeStr";
  (* file: "Aeneas/Std/Slice.lean", line: 714 *)
  mk_trait_impl "core::slice::index::SliceIndex<core::ops::range::RangeFrom<usize>, [@T], [@T]>" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeFromUsizeSlice";
  (* file: "Aeneas/Std/StringIter.lean", line: 543 *)
  mk_trait_impl "core::slice::index::SliceIndex<core::ops::range::RangeFrom<usize>, str, str>" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeFromUsizeStr";
  (* file: "Aeneas/Std/Slice.lean", line: 562 *)
  mk_trait_impl "core::slice::index::SliceIndex<core::ops::range::RangeFull, [@T], [@T]>" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeFullSlice";
  (* file: "Aeneas/Std/Slice.lean", line: 507 *)
  mk_trait_impl "core::slice::index::SliceIndex<core::ops::range::RangeTo<usize>, [@T], [@T]>" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeToUsizeSlice";
  (* file: "Aeneas/Std/StringIter.lean", line: 595 *)
  mk_trait_impl "core::slice::index::SliceIndex<core::ops::range::RangeTo<usize>, str, str>" "_root_.Aeneas.Std.core.slice.index.SliceIndexRangeToUsizeStr";
  (* file: "Aeneas/Std/Slice.lean", line: 624 *)
  mk_trait_impl "core::slice::index::SliceIndex<usize, [@T], @T>" "_root_.Aeneas.Std.core.slice.index.SliceIndexUsizeSlice";
  (* file: "Aeneas/Std/Slice.lean", line: 431 *)
  mk_trait_impl "core::slice::index::private_slice_index::Sealed<core::ops::range::Range<usize>>" "_root_.Aeneas.Std.core.slice.index.private_slice_index.SealedRangeUsize";
  (* file: "Aeneas/Std/Slice.lean", line: 709 *)
  mk_trait_impl "core::slice::index::private_slice_index::Sealed<core::ops::range::RangeFrom<usize>>" "_root_.Aeneas.Std.core.slice.index.private_slice_index.SealedRangeFromUsize";
  (* file: "Aeneas/Std/Slice.lean", line: 524 *)
  mk_trait_impl "core::slice::index::private_slice_index::Sealed<core::ops::range::RangeFull>" "_root_.Aeneas.Std.core.slice.index.private_slice_index.SealedRangeFull";
  (* file: "Aeneas/Std/Slice.lean", line: 447 *)
  mk_trait_impl "core::slice::index::private_slice_index::Sealed<core::ops::range::RangeTo<usize>>" "_root_.Aeneas.Std.core.slice.index.private_slice_index.SealedRangeToUsize";
  (* file: "Aeneas/Std/Slice.lean", line: 620 *)
  mk_trait_impl "core::slice::index::private_slice_index::Sealed<usize>" "_root_.Aeneas.Std.core.slice.index.private_slice_index.SealedUsize";
  (* file: "Aeneas/Std/String.lean", line: 403 *)
  mk_trait_impl "core::str::pattern::Pattern<&'b str>" "_root_.Aeneas.Std.core.str.pattern.PatternSharedStr";
  (* file: "Aeneas/Std/StringIter.lean", line: 62 *)
  mk_trait_impl "core::str::pattern::Pattern<[char; @N]>" "_root_.Aeneas.Std.core.str.pattern.PatternCharArray";
  (* file: "Aeneas/Std/String.lean", line: 420 *)
  mk_trait_impl "core::str::pattern::Pattern<char>" "_root_.Aeneas.Std.core.str.pattern.PatternChar";
  (* file: "Aeneas/Std/StringIter.lean", line: 43 *)
  mk_trait_impl "core::str::pattern::ReverseSearcher<'a, core::str::pattern::CharArraySearcher<'a, @N>>" "_root_.Aeneas.Std.core.str.pattern.ReverseSearcherCharArraySearcher";
  (* file: "Aeneas/Std/String.lean", line: 390 *)
  mk_trait_impl "core::str::pattern::ReverseSearcher<'a, core::str::pattern::CharSearcher<'a>>" "_root_.Aeneas.Std.core.str.pattern.ReverseSearcherCharSearcher";
  (* file: "Aeneas/Std/String.lean", line: 370 *)
  mk_trait_impl "core::str::pattern::ReverseSearcher<'a, core::str::pattern::StrSearcher<'a, 'b>>" "_root_.Aeneas.Std.core.str.pattern.ReverseSearcherStrSearcher";
  (* file: "Aeneas/Std/StringIter.lean", line: 36 *)
  mk_trait_impl "core::str::pattern::Searcher<'a, core::str::pattern::CharArraySearcher<'a, @N>>" "_root_.Aeneas.Std.core.str.pattern.SearcherCharArraySearcher";
  (* file: "Aeneas/Std/String.lean", line: 384 *)
  mk_trait_impl "core::str::pattern::Searcher<'a, core::str::pattern::CharSearcher<'a>>" "_root_.Aeneas.Std.core.str.pattern.SearcherCharSearcher";
  (* file: "Aeneas/Std/String.lean", line: 364 *)
  mk_trait_impl "core::str::pattern::Searcher<'a, core::str::pattern::StrSearcher<'a, 'b>>" "_root_.Aeneas.Std.core.str.pattern.SearcherStrSearcher";
  (* file: "Aeneas/Std/Parse.lean", line: 299 *)
  mk_trait_impl "core::str::traits::FromStr<f32, core::num::dec2flt::ParseFloatError>" "_root_.Aeneas.Std.core.str.traits.FromStrF32";
  (* file: "Aeneas/Std/Parse.lean", line: 288 *)
  mk_trait_impl "core::str::traits::FromStr<f64, core::num::dec2flt::ParseFloatError>" "_root_.Aeneas.Std.core.str.traits.FromStrF64";
  (* file: "Aeneas/Std/Parse.lean", line: 124 *)
  mk_trait_impl "core::str::traits::FromStr<i32, core::num::error::ParseIntError>" "_root_.Aeneas.Std.core.str.traits.FromStrI32";
  (* file: "Aeneas/Std/Parse.lean", line: 135 *)
  mk_trait_impl "core::str::traits::FromStr<i64, core::num::error::ParseIntError>" "_root_.Aeneas.Std.core.str.traits.FromStrI64";
  (* file: "Aeneas/Std/Parse.lean", line: 113 *)
  mk_trait_impl "core::str::traits::FromStr<u64, core::num::error::ParseIntError>" "_root_.Aeneas.Std.core.str.traits.FromStrU64";
  (* file: "Aeneas/Std/Parse.lean", line: 102 *)
  mk_trait_impl "core::str::traits::FromStr<usize, core::num::error::ParseIntError>" "_root_.Aeneas.Std.core.str.traits.FromStrUsize";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 653 *)
  mk_trait_impl "serde_core::de::Deserialize<'de, ()>" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeUnit";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 373 *)
  mk_trait_impl "serde_core::de::Deserialize<'de, (@T0, @T1)>" "_root_.Aeneas.Std.serde_core.de.impls.DeserializePair";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 778 *)
  mk_trait_impl "serde_core::de::Deserialize<'de, Box<@T>>" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeBox";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 842 *)
  mk_trait_impl "serde_core::de::Deserialize<'de, [@T; 32]>" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeArray32";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 762 *)
  mk_trait_impl "serde_core::de::Deserialize<'de, alloc::collections::btree::map::BTreeMap<@K, @V, alloc::alloc::Global>>" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeBTreeMap";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 731 *)
  mk_trait_impl "serde_core::de::Deserialize<'de, alloc::collections::btree::set::BTreeSet<@T, alloc::alloc::Global>>" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeBTreeSet";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 443 *)
  mk_trait_impl "serde_core::de::Deserialize<'de, alloc::string::String>" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeString";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 790 *)
  mk_trait_impl "serde_core::de::Deserialize<'de, alloc::sync::Arc<@T>>" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeArc";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 703 *)
  mk_trait_impl "serde_core::de::Deserialize<'de, alloc::vec::Vec<@T>>" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeVec";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 638 *)
  mk_trait_impl "serde_core::de::Deserialize<'de, bool>" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeBool";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 469 *)
  mk_trait_impl "serde_core::de::Deserialize<'de, core::option::Option<@T>>" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeOption";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 623 *)
  mk_trait_impl "serde_core::de::Deserialize<'de, f64>" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeF64";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 539 *)
  mk_trait_impl "serde_core::de::Deserialize<'de, i16>" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeI16";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 549 *)
  mk_trait_impl "serde_core::de::Deserialize<'de, i32>" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeI32";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 559 *)
  mk_trait_impl "serde_core::de::Deserialize<'de, i64>" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeI64";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 529 *)
  mk_trait_impl "serde_core::de::Deserialize<'de, i8>" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeI8";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 926 *)
  mk_trait_impl "serde_core::de::Deserialize<'de, serde_core::de::ignored_any::IgnoredAny>" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeIgnoredAny";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 414 *)
  mk_trait_impl "serde_core::de::Deserialize<'de, u32>" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeU32";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 579 *)
  mk_trait_impl "serde_core::de::Deserialize<'de, u64>" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeU64";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 569 *)
  mk_trait_impl "serde_core::de::Deserialize<'de, u8>" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeU8";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 589 *)
  mk_trait_impl "serde_core::de::Deserialize<'de, usize>" "_root_.Aeneas.Std.serde_core.de.impls.DeserializeUsize";
  (* file: "Aeneas/Std/Serde/Content.lean", line: 167 *)
  mk_trait_impl "serde_core::de::DeserializeSeed<'de, serde::private::de::content::ContentVisitor<'de>, serde_core::private::content::Content<'de>>" "_root_.Aeneas.Std.serde.private.de.content.DeserializeSeedContentVisitor";
  (* file: "Aeneas/Std/Serde/Content.lean", line: 900 *)
  mk_trait_impl "serde_core::de::Deserializer<'de, serde::private::de::content::ContentDeserializer<'de, @E>, @E>" "_root_.Aeneas.Std.serde.private.de.content.DeserializerContentDeserializer";
  (* file: "Aeneas/Std/Serde/Content.lean", line: 200 *)
  mk_trait_impl "serde_core::de::Deserializer<'de, serde_core::de::value::SeqAccessDeserializer<@A>, @Clause0_Error>" "_root_.Aeneas.Std.serde_core.de.value.DeserializerSeqAccessDeserializer";
  (* file: "Aeneas/Std/Serde/De.lean", line: 137 *)
  mk_trait_impl "serde_core::de::Expected<&'0 str>" "_root_.Aeneas.Std.serde_core.de.ExpectedSharedStr";
  (* file: "Aeneas/Std/Serde/Content.lean", line: 153 *)
  mk_trait_impl "serde_core::de::Visitor<'de, serde::private::de::content::ContentVisitor<'de>, serde_core::private::content::Content<'de>>" "_root_.Aeneas.Std.serde.private.de.content.VisitorContentVisitor";
  (* file: "Aeneas/Std/Serde/Content.lean", line: 392 *)
  mk_trait_impl "serde_core::de::Visitor<'de, serde::private::de::content::TaggedContentVisitor<@T>, (@T, serde_core::private::content::Content<'de>)>" "_root_.Aeneas.Std.serde.private.de.content.VisitorTaggedContentVisitor";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 54 *)
  mk_trait_impl "serde_core::ser::Serialize<&'a @T>" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeShared";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 245 *)
  mk_trait_impl "serde_core::ser::Serialize<()>" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeUnit";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 41 *)
  mk_trait_impl "serde_core::ser::Serialize<(@T0, @T1)>" "_root_.Aeneas.Std.serde_core.ser.impls.SerializePair";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 275 *)
  mk_trait_impl "serde_core::ser::Serialize<Box<@T>>" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeBox";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 333 *)
  mk_trait_impl "serde_core::ser::Serialize<[@T; 32]>" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeArray32";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 127 *)
  mk_trait_impl "serde_core::ser::Serialize<alloc::collections::btree::map::BTreeMap<@K, @V, alloc::alloc::Global>>" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeBTreeMap";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 109 *)
  mk_trait_impl "serde_core::ser::Serialize<alloc::collections::btree::set::BTreeSet<@T, alloc::alloc::Global>>" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeBTreeSet";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 76 *)
  mk_trait_impl "serde_core::ser::Serialize<alloc::string::String>" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeString";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 288 *)
  mk_trait_impl "serde_core::ser::Serialize<alloc::sync::Arc<@T>>" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeArc";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 92 *)
  mk_trait_impl "serde_core::ser::Serialize<alloc::vec::Vec<@T>>" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeVec";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 142 *)
  mk_trait_impl "serde_core::ser::Serialize<bool>" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeBool";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 262 *)
  mk_trait_impl "serde_core::ser::Serialize<core::option::Option<@T>>" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeOption";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 212 *)
  mk_trait_impl "serde_core::ser::Serialize<f64>" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeF64";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 162 *)
  mk_trait_impl "serde_core::ser::Serialize<i16>" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeI16";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 172 *)
  mk_trait_impl "serde_core::ser::Serialize<i32>" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeI32";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 182 *)
  mk_trait_impl "serde_core::ser::Serialize<i64>" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeI64";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 152 *)
  mk_trait_impl "serde_core::ser::Serialize<i8>" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeI8";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 234 *)
  mk_trait_impl "serde_core::ser::Serialize<str>" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeStr";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 65 *)
  mk_trait_impl "serde_core::ser::Serialize<u32>" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeU32";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 202 *)
  mk_trait_impl "serde_core::ser::Serialize<u64>" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeU64";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 192 *)
  mk_trait_impl "serde_core::ser::Serialize<u8>" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeU8";
  (* file: "Aeneas/Std/Serde/Impls.lean", line: 223 *)
  mk_trait_impl "serde_core::ser::Serialize<usize>" "_root_.Aeneas.Std.serde_core.ser.impls.SerializeUsize";
]

