import Lean
import Aeneas.Std

/-! # New `do` Elaborator

The goal for this elaborator is to construct easier Lean terms to reason about.

In particular, we do not introduce join points when a monadic let-binding contains
an `if then else`.

The Aeneas extracted `do` syntax is a proper subset of the Lean `do` syntax,
with no early returns, so the new elaborator can avoid the use of jumps.

We also change the elaboration of pattern matched let bindings to avoid using
the builtin match-based pattern matching.
-/

open Lean Elab Parser Term Meta

namespace Aeneas
namespace Do

/-- Monad info cached from the `do` block's expected type `m α`. -/
structure Context where
  m : Expr
  /-- The element type `α`. -/
  expectedAlpha : Expr
  /-- Instance of `Bind m` -/
  bindInst : Expr
  /-- Instance of `Pure m` -/
  pureInst : Expr

abbrev DoElem := TSyntax `doElem

/-- A sequence tail, together with the metavariable that owns its local context. -/
structure PendingSeq where
  elems : List DoElem
  hole : MVarId

abbrev ElabM := ReaderT Context $ StateT (Option PendingSeq) TermElabM

/-- Split `m α` and synthesize the `Bind m` and `Pure m` instances. -/
def mkContext (expectedType : Expr) : TermElabM Context := do
  let expectedType ← whnf expectedType
  let (m, α) ← match expectedType with
    | Expr.app m α => pure (m, α)
    | _ => throwError "expected a monadic type `m α`, got {indentExpr expectedType}"
  let bindInst ← synthInstance (← mkAppM ``Bind #[m])
  let pureInst ← synthInstance (← mkAppM ``Pure #[m])
  return { m, expectedAlpha := α, bindInst, pureInst }

def ElabM.mkBind (e k : Expr) : ElabM Expr := do
  let ctx ← read
  mkAppOptM ``Bind.bind #[some ctx.m, some ctx.bindInst, none, none, some e, some k]

/-- Build `m α`, constraining the element universe before suspending a tail.
    `mkFreshTypeMVar` initially has type `Sort ?u`. App builders run under
    `withNewMCtxDepth`, so they cannot constrain that older universe once
    asked to construct a bind around a still-unelaborated tail. -/
def ElabM.mkMonadicType (α : Expr) : ElabM Expr := do
  let ctx ← read
  let .forallE _ domain _ _ ← whnf (← inferType ctx.m)
    | throwError "expected a monad type constructor, got{indentExpr ctx.m}"
  unless ← isDefEq (← inferType α) domain do
    throwError "invalid monadic element type{indentExpr α}\nexpected a type in{indentExpr domain}"
  return mkApp ctx.m α

/-- Run an `ElabM` against the given `do` block expected type. -/
def ElabM.execute (x : ElabM Expr) (expectedType : Expr) : TermElabM Expr := do
  let ctx ← mkContext expectedType
  (x.run ctx).run' none

/-- Suspend a sequence tail instead of elaborating it under all preceding binders.
    This is an internal, opaque metavariable, not a synthetic elaboration obligation:
    `elabDoSeqCore` always fills it before returning. -/
def suspendDoSeq (elems : List DoElem) : ElabM Expr := do
  if elems.isEmpty then throwError "unexpected empty `do` block"
  let ctx ← read
  let type ← ElabM.mkMonadicType ctx.expectedAlpha
  let hole ← mkFreshExprMVar type .syntheticOpaque
  set (some { elems, hole := hole.mvarId! } : Option PendingSeq)
  return hole

/-- Fill a match arm's `?m` by elaborating `body` under the arm's pattern binders
    and assigning the abstracted result to the mvar. -/
def ElabM.assignArmMVar (arm : Expr) (body : ElabM Expr) : ElabM Unit := do
  Meta.lambdaTelescope arm fun fvars ebody => do
    let .mvar mvarId := ebody.getAppFn
      | throwError "elabDoMatch: expected metavariable arm body, got{indentExpr ebody}"
    let armExpr ← body
    let value ←
      if ebody.isMVar then
        let usedFVars := fvars.filter (armExpr.occurs ·)
        if usedFVars.isEmpty then pure armExpr
        else mkLambdaFVars usedFVars armExpr
      else
        mkLambdaFVars fvars armExpr
    mvarId.assign value

/-- The constructor telescope, instantiated only at the inductive parameters.
    Keep dependent fields bound until they are introduced into the local context. -/
def getCtorType (ty : Expr) : MetaM (Option Expr) := do
  let ty ← whnf ty
  if ty.isAppOf ``Prod then return none
  let some indName := ty.getAppFn.constName? | return none
  let indVal ← getConstInfoInduct indName
  let [ctorName] := indVal.ctors | return none
  let lvls := ty.getAppFn.constLevels!
  let params := ty.getAppArgs.extract 0 indVal.numParams
  return some (← inferType (mkAppN (mkConst ctorName lvls) params))

/-- Build `T.casesOn discr minor` with a non-dependent motive `fun _ : ty => resultType`. -/
def mkCasesOn (ty : Expr) (indName : Name) (discr : Expr)
    (minor : Expr) (resultType : Expr) : MetaM Expr := do
  let indVal ← getConstInfoInduct indName
  -- `casesOn`'s first universe is the motive's; the rest are the inductive's.
  let casesOnLvls := (← getLevel resultType) :: ty.getAppFn.constLevels!
  let casesOn := Lean.mkConst (mkCasesOnName indName) casesOnLvls
  let params := ty.getAppArgs.extract 0 indVal.numParams
  let motive ← withLocalDeclD `_ ty fun x => mkLambdaFVars #[x] resultType
  return mkAppN casesOn (params ++ #[motive, discr, minor])

def decomposeProductType (ty : Expr) (n : Nat) : MetaM (List Expr) := do
  let mut ty := ty
  let mut types := #[]
  for _ in [:n - 1] do
    let t ← whnf ty
    match_expr t with
    | Prod α β =>
      types := types.push α
      ty := β
    | _ => throwError "expected a product type, got{indentExpr t}"
  return (types.push ty).toList

def mkUncurries (innerLam : Expr) (types : List Expr) : MetaM Expr := do
  if types.length ≤ 1 then return innerLam
  lambdaBoundedTelescope innerLam (types.length - 2) fun fvars body => do
    let mut result ← mkAppM ``Function.uncurry #[body]
    for fv in fvars.reverse do
      result ← mkAppM ``Function.uncurry #[← mkLambdaFVars #[fv] result]
    return result

/-! ## Pattern analysis and continuation building -/

inductive PatShape where
  | leaf (name : Name)
  | prod (subs : Array PatShape)
  | ctor (indName : Name) (subs : Array PatShape)
  deriving Inhabited

/-- Walk `pat` alongside its expected `ty`, producing a `PatShape`. -/
partial def analyzePat (pat : Term) (ty : Expr) : ElabM PatShape := do
  let analyzeSubs (subPats : Array Term) (subTypes : List Expr) : ElabM (Array PatShape) :=
    subPats.toList.zip subTypes |>.toArray.mapM fun (p, t) => analyzePat p t
  match pat with
  | `(_) => return .leaf `_
  | `($id:ident) => return .leaf id.getId
  | `(($x, $xs,*)) =>
    let subPats : Array Term := #[x] ++ xs.getElems
    let subTypes ← decomposeProductType ty subPats.size
    return .prod (← analyzeSubs subPats subTypes)
  | `(⟨$xs,*⟩) =>
    let subPats : Array Term := xs.getElems
    let ty ← whnf ty
    if ty.isAppOf ``Prod then
      let subTypes ← decomposeProductType ty subPats.size
      return .prod (← analyzeSubs subPats subTypes)
    else
      match ← getCtorType ty with
      | some ctorType =>
        let some indName := ty.getAppFn.constName?
          | throwError "analyzePat: cannot determine inductive name for{indentExpr ty}"
        forallTelescopeReducing ctorType fun fields _ => do
          let fieldTypes ← fields.toList.mapM (·.fvarId!.getType)
          return .ctor indName (← analyzeSubs subPats fieldTypes)
      | none => throwError "analyzePat: unsupported anonymous-ctor pattern on type{indentExpr ty}"
  | _ =>
    throwError "analyzePat: unsupported pattern kind `{pat.raw.getKind}`{indentD pat}"

/-- A saved scope lets a loop extend the context without retaining a
    `withLocalDecl` continuation for every field. Local instances are preserved. -/
structure PatternScope where
  lctx : LocalContext
  instances : LocalInstances

def PatternScope.capture : ElabM PatternScope := do
  return { lctx := ← getLCtx, instances := ← getLocalInstances }

def PatternScope.run (scope : PatternScope) (x : ElabM α) : ElabM α :=
  withLCtx scope.lctx scope.instances x

/-- Open a constructor telescope iteratively. Instantiating each remaining
    binder with the newly introduced fvar preserves dependent field types. -/
def openPatternFields (subs : Array PatShape) (type : Expr) :
    ElabM (Array Expr × PatternScope) := do
  let mut scope ← PatternScope.capture
  let mut type := type
  let mut fvars := #[]
  for i in [:subs.size] do
    let (fv, rest, next) ← scope.run do
      let .forallE _ domain rest _ ← whnf type
        | throwError "pattern has too many fields"
      let name := match subs[i]! with
        | .leaf name => name
        | _ => Name.mkSimple s!"_x{i}"
      Meta.withLocalDeclD name domain fun fv => do
        return (fv, rest.instantiate1 fv, ← PatternScope.capture)
    fvars := fvars.push fv
    type := rest
    scope := next
  return (fvars, scope)

def productTelescope (types : List Expr) : Expr :=
  types.foldr (fun ty rest => mkForall `_ .default ty (rest.liftLooseBVars 0 1)) (mkConst ``Unit)

/-- An explicit stack of eliminators, closed after all leaves are in scope. -/
inductive PatFrame where
  | prod (fvars : Array Expr) (types : List Expr) (discr : Expr)
  | ctor (fvars : Array Expr) (ty : Expr) (indName : Name) (discr : Expr)

/-- Unpack in depth-first, left-to-right order without a continuation per field.
    The frame array lives on the heap, including for nested/sibling patterns. -/
def unpackAll (subs : Array PatShape) (fvars : Array Expr)
    (body : Array Expr → ElabM Expr) : ElabM Expr := do
  let mut todo := (subs.zip fvars).toList
  let mut leaves := #[]
  let mut frames : Array PatFrame := #[]
  let mut scope ← PatternScope.capture
  while !todo.isEmpty do
    let (sub, fv) := todo.head!
    todo := todo.tail!
    match sub with
    | .leaf _ => leaves := leaves.push fv
    | .prod children =>
      let (fields, types, next) ← scope.run do
        let types ← decomposeProductType (← inferType fv) children.size
        let (fields, next) ← openPatternFields children (productTelescope types)
        return (fields, types, next)
      scope := next
      frames := frames.push (.prod fields types fv)
      todo := (children.zip fields).toList ++ todo
    | .ctor indName children =>
      let (fields, ty, next) ← scope.run do
        let ty ← whnf (← inferType fv)
        let some ctorType ← getCtorType ty
          | throwError "expected single-constructor inductive, got{indentExpr ty}"
        let (fields, next) ← openPatternFields children ctorType
        return (fields, ty, next)
      scope := next
      frames := frames.push (.ctor fields ty indName fv)
      todo := (children.zip fields).toList ++ todo
  scope.run do
    let mut result ← body leaves
    for frame in frames.reverse do
      match frame with
      | .prod fields types discr =>
        let minor ← mkLambdaFVars fields result
        result := mkApp (← mkUncurries minor types) discr
      | .ctor fields ty indName discr =>
        let resultType ← inferType result
        let minor ← mkLambdaFVars fields result
        result ← mkCasesOn ty indName discr minor resultType
    return result

/-- Construct the same uncurry/casesOn continuation as before; only the
    elaborator's control stack changes, not the generated monadic program. -/
def mkPatContinuation (shape : PatShape) (ty : Expr)
    (body : Array Expr → ElabM Expr) : ElabM Expr := do
  match shape with
  | .leaf name =>
    Meta.withLocalDeclD name ty fun fv => do
      mkLambdaFVars #[fv] (← body #[fv])
  | .prod subs =>
    let types ← decomposeProductType ty subs.size
    let (fields, scope) ← openPatternFields subs (productTelescope types)
    scope.run do
      let minor ← mkLambdaFVars fields (← unpackAll subs fields body)
      mkUncurries minor types
  | .ctor _ _ =>
    Meta.withLocalDeclD `_x ty fun fv => do
      mkLambdaFVars #[fv] (← unpackAll #[shape] #[fv] body)

/-- Elaborate `cond`, returning a `Prop`. `Bool` is coerced to `cond = true`.
    Synthetic mvars are forced so `Decidable` can be inferred downstream. -/
def elabIfCondition (cond : Term) : ElabM Expr := do
  let condExpr ← Lean.Elab.Term.elabTerm cond none
  synthesizeSyntheticMVarsNoPostponing
  let condExpr ← instantiateMVars condExpr
  let condType ← whnf (← instantiateMVars (← inferType condExpr))
  if condType.isConstOf ``Bool then
    mkEq condExpr (mkConst ``Bool.true)
  else
    pure condExpr

/-- Build `ite propExpr thn els`, synthesizing the `Decidable` instance. -/
def mkIteExpr (propExpr thn els : Expr) : MetaM Expr := do
  mkAppOptM ``ite #[none, some propExpr, none, some thn, some els]

/-! ## Individual `doElem` handlers-/


def getDoElems (doSeq : TSyntax ``doSeq) : ElabM (List DoElem) := do
  match doSeq with
  | `(doSeq| $[$elems $[;]?]*) => return elems.toList
  | _ => throwError "unexpected `doSeq` syntax {indentD doSeq}"

mutual

/-- Dispatch a `doElem` to its handler. -/
partial def elabDoElem (elem : DoElem) (rest : List DoElem) : ElabM Expr := do
  match elem with
  | `(doElem| let $x:ident $[: $ty?]? ← $rhs) => elabDoLetArrowId x ty? rhs rest
  | `(doElem| let $pat:term ← $rhs)  => elabDoLetArrowPat pat rhs rest
  | `(doElem| let $x:ident $[: $ty?]? := $rhs) => elabDoLetId x ty? rhs rest
  | `(doElem| let $pat:term := $rhs)  => elabDoLetPat pat rhs rest
  | `(doElem| if $cond:term then $thenSeq:doSeq
              $[else if $econds:term then $eseqs:doSeq]*
              else $elseSeq:doSeq) =>
    let branches : Array (Term × TSyntax ``doSeq) :=
      #[(cond, thenSeq)] ++ econds.zip eseqs
    elabDoIfChain branches elseSeq rest
  | `(doElem| $expr:term)            => elabDoExpr expr rest
  | `(doElem| match $[(generalizing := $gen?)]? $[$motive?:motive]? $discrs,* with $alts:matchAlt*) =>
    elabDoMatch gen? motive? discrs alts rest
  | `(doElem| do $seq:doSeq) =>
    let innerElems ← getDoElems seq
    elabDoSeqCore (innerElems ++ rest)
  | _ =>
    throwError "unsupported `do` element (kind: {elem.raw.getKind}){indentD elem}"

/-- Elaborate a monadic sub-term. If `rest` is empty, use the block's expected
    type `m α`; otherwise elaborate at `m Unit` and bind `rest` onto it. -/
partial def elabMonadicAsDoElem
    (elabAtType : Expr → ElabM Expr) (rest : List DoElem) : ElabM Expr := do
  match rest with
  | [] =>
    let ctx ← read
    let expectedType ← ElabM.mkMonadicType ctx.expectedAlpha
    elabAtType expectedType
  | _ =>
    let unitType ← mkConstWithFreshMVarLevels ``Unit
    let expectedType ← ElabM.mkMonadicType unitType
    let e ← elabAtType expectedType
    Meta.withLocalDeclD `_ unitType fun fvar => do
      let restExpr ← suspendDoSeq rest
      let body ← mkLambdaFVars #[fvar] restExpr
      ElabM.mkBind e body

/-- Elaborate a term in a `doSeq` position. -/
partial def elabDoExpr (term : Term) (rest : List DoElem) : ElabM Expr :=
  elabMonadicAsDoElem (fun ty => elabTermEnsuringType term ty) rest

/-- Elaborate `let x ← e`. -/
partial def elabDoLetArrowId (x : Ident) (ty? : Option Term) (rhs : DoElem)
    (rest : List DoElem) : ElabM Expr := do
  let name := x.getId
  let ty ← match ty? with
    | some ty => elabType ty
    | none    => mkFreshTypeMVar
  let expectedType ← ElabM.mkMonadicType ty
  let e ← withReader (fun ctx => { ctx with expectedAlpha := ty }) do
    match rhs with
    | `(doElem| do $seq:doSeq) =>
      let elems ← getDoElems seq
      elabDoSeqCore elems
    | `(doElem| $expr:term) =>
      elabTermEnsuringType expr expectedType
    | _ => do
      -- RHS is a do-element (e.g. `if`, `match`): elaborate as a singleton seq.
      let e ← elabDoElem rhs []
      let eType ← instantiateMVars (← inferType e)
      if let some α := eType.getAppArgs[0]? then
        discard <| isDefEq ty α
      pure e
  let ty ← instantiateMVars ty
  Meta.withLocalDeclD name ty fun fvar => do
    let restExpr ← suspendDoSeq rest
    let body ← mkLambdaFVars #[fvar] restExpr
    ElabM.mkBind e body

/-- Elaborate `let pat ← e`. -/
partial def elabDoLetArrowPat (pat : Term) (rhs : DoElem) (rest : List DoElem) : ElabM Expr := do
  let α ← mkFreshTypeMVar
  let expectedType ← ElabM.mkMonadicType α
  let e ← withReader (fun ctx => { ctx with expectedAlpha := α }) do
    match rhs with
    | `(doElem| do $seq:doSeq) =>
      let elems ← getDoElems seq
      elabDoSeqCore elems
    | `(doElem| $expr:term) =>
      elabTermEnsuringType expr expectedType
    | _ => do
      let e ← elabDoElem rhs []
      let eType ← instantiateMVars (← inferType e)
      if let some a := eType.getAppArgs[0]? then
        discard <| isDefEq α a
      pure e
  -- The pattern is analyzed against the value's type: resolve the postponed
  -- elaboration problems first (a `match` bound by an earlier `let x := match …`
  -- is postponed until its type is known, and `x` may be this value).
  synthesizeSyntheticMVarsNoPostponing
  let α ← instantiateMVars α
  let shape ← analyzePat pat α
  let k ← mkPatContinuation shape α fun _ => suspendDoSeq rest
  ElabM.mkBind e k

/-- Elaborate `let x := e`. -/
partial def elabDoLetId (x : Ident) (ty? : Option Term) (rhs : Term)
    (rest : List DoElem) : ElabM Expr := do
  let name := x.getId
  let α ← match ty? with
    | some ty => elabType ty
    | none    => mkFreshTypeMVar
  let val ← elabTermEnsuringType rhs α
  let α ← instantiateMVars α
  Meta.withLetDecl name α val fun fvar => do
    let restExpr ← suspendDoSeq rest
    mkLetFVars #[fvar] restExpr

/-- Elaborate `let pat := e`. -/
partial def elabDoLetPat (pat : Term) (rhs : Term)
    (rest : List DoElem) : ElabM Expr := do
  let α ← mkFreshTypeMVar
  let val ← elabTermEnsuringType rhs α
  -- See `elabDoLetArrowPat`: the pattern needs the resolved type of the value.
  synthesizeSyntheticMVarsNoPostponing
  let α ← instantiateMVars α
  let shape ← analyzePat pat α
  let k ← mkPatContinuation shape α fun _ => suspendDoSeq rest
  -- For `.ctor`, `k` is `fun _x => T.casesOn _x …`; headBeta gives `T.casesOn val …`.
  -- For `.prod` the head is `Function.uncurry`, so `headBeta` is a no-op.
  return (mkApp k val).headBeta

/-- Elaborate an `if/else-if/…/else` chain as nested `ite`s. `rest` is bound
    once outside the chain. -/
partial def elabDoIfChain (branches : Array (Term × TSyntax ``doSeq))
    (elseSeq : TSyntax ``doSeq) (rest : List DoElem) : ElabM Expr := do
  let elabAtType (ty : Expr) : ElabM Expr := do
    let some α := ty.getAppArgs[0]?
      | throwError "elabDoIfChain: expected monadic type, got{indentExpr ty}"
    withReader (fun ctx => { ctx with expectedAlpha := α }) do
      let mut result ← elabDoSeqCore (← getDoElems elseSeq)
      for (c, s) in branches.toList.reverse do
        let thenExpr ← elabDoSeqCore (← getDoElems s)
        let propExpr ← elabIfCondition c
        result ← mkIteExpr propExpr thenExpr result
      return result
  elabMonadicAsDoElem elabAtType rest

/-- Elaborate a `match`. Drives Lean's match elaborator with `_` in each arm
    body, then fills the resulting per-arm mvars by elaborating the original
    `doSeq`s directly in the mvar's local context -/
partial def elabDoMatch
    (gen? : Option (TSyntax [`Lean.Parser.Term.trueVal, `Lean.Parser.Term.falseVal]))
    (motive? : Option (TSyntax ``Term.motive))
    (discrs : Array (TSyntax ``Term.matchDiscr))
    (alts : Array (TSyntax ``Term.matchAlt)) (rest : List DoElem) : ElabM Expr := do
  let mut armSeqs : Array (TSyntax ``doSeq) := #[]
  let mut holedAlts : Array (TSyntax ``Term.matchAlt) := #[]
  for alt in alts do
    match alt with
    | `(matchAltExpr| | $pats,* => $body) =>
      armSeqs := armSeqs.push ⟨body.raw⟩
      holedAlts := holedAlts.push (← `(matchAltExpr| | $pats,* => _))
    | _ => throwError "elabDoMatch: unexpected match arm syntax{indentD alt}"
  let termMatch ← `(match $[(generalizing := $gen?)]? $[$motive?]? $[$discrs],* with $holedAlts:matchAlt*)
  let elabAtType (ty : Expr) : ElabM Expr := do
    let some α := ty.getAppArgs[0]?
      | throwError "elabDoMatch: expected monadic type, got{indentExpr ty}"
    /- Synthesize pending metavariables before match elaboration.
       The holed match `match d with | pat => _ | ...` needs fully resolved
       discriminant types to elaborate patterns (e.g., `none` needs `Option ?α`
       to have `?α` assigned). -/
    synthesizeSyntheticMVarsNoPostponing
    let matchExpr ← elabTermEnsuringType termMatch ty
    synthesizeSyntheticMVarsNoPostponing
    let matchExpr ← instantiateMVars matchExpr
    let some fnName := matchExpr.getAppFn.constName?
      | throwError "elabDoMatch: expected matcher application, got{indentExpr matchExpr}"
    let some info ← getMatcherInfo? fnName
      | throwError "elabDoMatch: `{fnName}` is not a matcher"
    let args := matchExpr.getAppArgs
    let firstAltIdx := info.getFirstAltPos
    unless armSeqs.size == info.numAlts do
      throwError "elabDoMatch: arm count mismatch (expected {info.numAlts}, got {armSeqs.size})"
    withReader (fun ctx => { ctx with expectedAlpha := α }) do
      for i in [:info.numAlts] do
        let elems ← getDoElems armSeqs[i]!
        ElabM.assignArmMVar args[firstAltIdx + i]! (elabDoSeqCore elems)
    instantiateMVars matchExpr
  elabMonadicAsDoElem elabAtType rest

/-- Elaborate one statement at a time. Each step returns before its tail is
    visited, so neither binder scopes nor monad continuations accumulate along
    a flat sequence. A hole retains the exact local context (including instances)
    in which its tail must be elaborated. Nested RHS/branch sequences use their
    own driver and cannot overwrite the caller's pending tail. -/
partial def elabDoSeqCore (elems : List DoElem) : ElabM Expr := do
  let ctx ← read
  let expectedType ← ElabM.mkMonadicType ctx.expectedAlpha
  let run : TermElabM Expr := do
    let root ← mkFreshExprMVar expectedType .syntheticOpaque
    let mut pending := { elems, hole := root.mvarId! : PendingSeq }
    repeat
      let (value, next) ← pending.hole.withContext do
        match pending.elems with
        | [] => throwError "unexpected empty `do` block"
        | elem :: rest => ((elabDoElem elem rest).run ctx).run none
      pending.hole.assign value
      match next with
      | none => break
      | some next => pending := next
    instantiateMVars root
  liftM run

end

def elabDoSeq (doSeq : TSyntax ``doSeq) : ElabM Expr :=
  getDoElems doSeq >>= fun elems => elabDoSeqCore elems

/-- Option to toggle the new Aeneas `do` elaborator -/
register_option Aeneas.customDoElab : Bool := {
    defValue := true
    descr  := "Use the custom Aeneas `do` elaborator"
  }

/-- `do`-notation elaborator. Dispatches to the new `ElabM`-based elaborator for
    `Aeneas.Std.Result _` blocks when `Aeneas.newDoElab` is set; otherwise falls
    back to Lean's default. -/
@[term_elab «do»]
def elabDo : TermElab := fun stx expectedType? => do
  let useNewElab ← do
    let some expectedType := expectedType? | pure false
    let expectedType ← instantiateMVars =<< whnf expectedType
    match_expr expectedType with
    | Aeneas.Std.Result _ => pure (Aeneas.customDoElab.get (← getOptions))
    | _ => pure false
  if useNewElab then
    let `(do $doSeq) := stx | throwUnsupportedSyntax
    Do.ElabM.execute (Do.elabDoSeq doSeq) expectedType?.get!
  else
    Term.elabDo stx expectedType?

end Do
end Aeneas
