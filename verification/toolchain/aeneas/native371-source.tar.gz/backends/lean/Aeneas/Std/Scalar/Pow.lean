import Aeneas.Std.Scalar.Core

namespace Aeneas.Std

open Result

@[rust_fun "core::num::{usize}::is_power_of_two"]
def core.num.Usize.is_power_of_two (x : Std.Usize) : Result Bool :=
  ok x.val.isPowerOfTwo

@[step]
theorem core.num.Usize.is_power_of_two_spec (x : Std.Usize) :
  core.num.Usize.is_power_of_two x ⦃ b => b = x.val.isPowerOfTwo ⦄ := by
  simp only [is_power_of_two, eq_iff_iff, WP.spec_ok, decide_eq_true_eq]

/-- `pow` of the unsigned integers (core/src/num/uint_macros.rs, rustc 1.95,
    `#[rustc_inherit_overflow_checks]`): square-and-multiply. The base is squared only while
    a higher bit of the exponent remains, so no intermediate product exceeds the result, and
    a checked caller panics exactly when `self ^ exp` overflows. The powers of 0 and 1 are 0
    and 1 (`x ^ 0 = 1`); a larger base overflows from `exp ≥ numBits` on, so the power is
    computed only below that bound. -/
def UScalar.pow {ty : UScalarTy} (x : UScalar ty) (exp : U32) : Result (UScalar ty) :=
  if x.val ≤ 1 then UScalar.tryMk ty (if exp.val = 0 then 1 else x.val)
  else if exp.val < ty.numBits then UScalar.tryMk ty (x.val ^ exp.val)
  else fail .integerOverflow

@[rust_fun "core::num::{u8}::pow"]
def core.num.U8.pow (x : U8) (exp : U32) : Result U8 := UScalar.pow x exp
@[rust_fun "core::num::{u16}::pow"]
def core.num.U16.pow (x : U16) (exp : U32) : Result U16 := UScalar.pow x exp
@[rust_fun "core::num::{u32}::pow"]
def core.num.U32.pow (x : U32) (exp : U32) : Result U32 := UScalar.pow x exp
@[rust_fun "core::num::{u64}::pow"]
def core.num.U64.pow (x : U64) (exp : U32) : Result U64 := UScalar.pow x exp
@[rust_fun "core::num::{u128}::pow"]
def core.num.U128.pow (x : U128) (exp : U32) : Result U128 := UScalar.pow x exp
@[rust_fun "core::num::{usize}::pow"]
def core.num.Usize.pow (x : Usize) (exp : U32) : Result Usize := UScalar.pow x exp

end Aeneas.Std
