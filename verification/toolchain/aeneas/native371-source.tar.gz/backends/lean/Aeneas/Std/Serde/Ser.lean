import Aeneas.Std.Core.Fmt
import Aeneas.Std.Core.FmtWithSlice
import Aeneas.Std.Core.Error
import Aeneas.Std.Core.Result
import Aeneas.Std.Float
import Aeneas.Std.String
import Aeneas.Std.Core.Iter

/-!
# `serde_core::ser` (serde 1.0.228)

The traits `Serialize`, `Serializer` and `SerializeSeq`/`SerializeTuple`/`SerializeTupleStruct`/
`SerializeTupleVariant`/`SerializeMap`/`SerializeStruct`/`SerializeStructVariant` form a recursive
group: `Serialize::serialize<S: Serializer>` takes a serializer, and a serializer's methods
(`serialize_element<T: Serialize>`, `serialize_some<T: Serialize>`, ...) take `Serialize`
dictionaries. Both occurrences are method-level bounds, i.e. negative positions: the group has no
inductive encoding (the kernel rejects `serialize_element : Serialize T → ...` inside a structure
that `Serialize` refers to as a non-positive occurrence).

## The knot

The *format side* (`Serializer` and its compound states) is defined relative to a family
`X : Type → Type 1` standing for the `Serialize` dictionaries it receives at its *knot positions*
(the method-level `T: Serialize` bounds). The *data side* `SerializeStep X` is an ordinary
structure over the format side at `X`. The level-`n` approximations are
`SerializeAt 0 = PUnit`, `SerializeAt (n + 1) = SerializeStep (SerializeAt n)`: a dictionary that can
be run against formats nesting at most `n` data-side calls. `SerializeΩ T` holds a dictionary at
every level. The Rust traits are the structures at `SerializeΩ`:
`Serializer = SerializerF SerializeΩ`, `Serialize = SerializeStep SerializeΩ`.

`Serialize.wrap : Serialize T → SerializeΩ T` is the knot: at level `n + 1` it runs the dictionary
against the level-`n` format seen at `SerializeΩ` (`SerializerF.map`, projecting the nested
dictionaries to level `n`); `wrap_level_succ` is `rfl`. It is the `knot` of the `rust_trait`
attribute of `Serialize`: Aeneas extracts a call `inst.SerializeSeqInst.serialize_element d s v` as
`serialize_element (Serialize.wrap d) s v`.

`FormatProgram` (below) is what a Rust implementation of the format side is: the dictionaries of a
family of format types, generic in the knot family, built from the family one level down (a Rust
format can use a `T: Serialize` it receives only by calling `serialize` with a serializer of its
own family). `FormatProgram.encode` turns every such program into `Serializer` dictionaries, and
`FormatProgram.stepDict_serialize` states, by `rfl`, that the encoded format given `wrap d` runs the
program with `d` run against the encoded formats one level down: the Rust semantics, with the nesting
depth explicit. Statements about the extracted (generic) data-side implementations quantify over
all `Serializer` dictionaries, hence cover every Rust format.
-/

namespace Aeneas.Std

open Result

/-- `serde_core::ser::Error` -/
@[rust_trait "serde_core::ser::Error" (parentClauses := ["coreerrorErrorInst"])]
structure serde_core.ser.Error (Self : Type) where
  coreerrorErrorInst : core.error.Error Self
  custom : {T : Type} → core.fmt.Display T → T → Result Self

namespace serde_core.ser

/-! ## Format side, relative to the knot family `X` -/

section
variable (X : Type → Type 1)

structure SerializeSeqF (Self Ok Error : Type) : Type 1 where
  serde_coreserErrorInst : serde_core.ser.Error Error
  serialize_element : {T : Type} → X T → Self → T →
    Result (core.result.Result Unit Error × Self)
  «end» : Self → Result (core.result.Result Ok Error)

structure SerializeTupleF (Self Ok Error : Type) : Type 1 where
  serde_coreserErrorInst : serde_core.ser.Error Error
  serialize_element : {T : Type} → X T → Self → T →
    Result (core.result.Result Unit Error × Self)
  «end» : Self → Result (core.result.Result Ok Error)

structure SerializeTupleStructF (Self Ok Error : Type) : Type 1 where
  serde_coreserErrorInst : serde_core.ser.Error Error
  serialize_field : {T : Type} → X T → Self → T →
    Result (core.result.Result Unit Error × Self)
  «end» : Self → Result (core.result.Result Ok Error)

structure SerializeTupleVariantF (Self Ok Error : Type) : Type 1 where
  serde_coreserErrorInst : serde_core.ser.Error Error
  serialize_field : {T : Type} → X T → Self → T →
    Result (core.result.Result Unit Error × Self)
  «end» : Self → Result (core.result.Result Ok Error)

structure SerializeMapF (Self Ok Error : Type) : Type 1 where
  serde_coreserErrorInst : serde_core.ser.Error Error
  serialize_key : {T : Type} → X T → Self → T →
    Result (core.result.Result Unit Error × Self)
  serialize_value : {T : Type} → X T → Self → T →
    Result (core.result.Result Unit Error × Self)
  /-- Provided: `serialize_key(key)?; serialize_value(value)`. -/
  serialize_entry : {K V : Type} → X K → X V → Self → K → V →
    Result (core.result.Result Unit Error × Self) :=
    fun kInst vInst self key value => do
      let (r, self) ← serialize_key kInst self key
      match r with
      | .Err e => ok (.Err e, self)
      | .Ok () => serialize_value vInst self value
  «end» : Self → Result (core.result.Result Ok Error)

structure SerializeStructF (Self Ok Error : Type) : Type 1 where
  serde_coreserErrorInst : serde_core.ser.Error Error
  serialize_field : {T : Type} → X T → Self → Str → T →
    Result (core.result.Result Unit Error × Self)
  /-- Provided: `let _ = key; Ok(())`. -/
  skip_field : Self → Str → Result (core.result.Result Unit Error × Self) :=
    fun self _ => ok (.Ok (), self)
  «end» : Self → Result (core.result.Result Ok Error)

structure SerializeStructVariantF (Self Ok Error : Type) : Type 1 where
  serde_coreserErrorInst : serde_core.ser.Error Error
  serialize_field : {T : Type} → X T → Self → Str → T →
    Result (core.result.Result Unit Error × Self)
  /-- Provided: `let _ = key; Ok(())`. -/
  skip_field : Self → Str → Result (core.result.Result Unit Error × Self) :=
    fun self _ => ok (.Ok (), self)
  «end» : Self → Result (core.result.Result Ok Error)

/-- `iterator_len_hint` (ser/mod.rs): `Some(lo)` when `iter.size_hint()` is `(lo, Some(hi))` with
    `lo == hi`, else `None`. -/
def iteratorLenHint {I Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
    (iter : I) : Result (Option Usize) := do
  let (lo, hi) ← iterInst.size_hint iter
  match hi with
  | some hi => ok (if lo = hi then some lo else none)
  | none => ok none

/-- `iter.try_for_each(f)` (the provided `Iterator::try_for_each`: `self.try_fold((), call(f))`,
    `call(f) = move |(), x| f(x)`) for a closure `f` whose state is `state` and whose call is
    `call`, returning `Result<(), E>`: the `try_fold` of the iterator's dictionary, the closure
    state threaded through the calls. -/
def tryForEachResult {I Item St E : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
    (call : St → Item → Result (core.result.Result Unit E × St)) (iter : I) (state : St) :
    Result (core.result.Result Unit E × I × St) :=
  let fnInst : core.ops.function.FnMut St (Unit × Item) (core.result.Result Unit E) :=
    { FnOnceInst := { call_once := fun s args => call s args.2 },
      call_mut := fun s args => call s args.2 }
  iterInst.try_fold fnInst (core.result.TryResult Unit E) iter () state

/-- The provided `Serializer::collect_seq` (ser/mod.rs):
    `let mut iter = iter.into_iter();
     let mut serializer = tri!(self.serialize_seq(iterator_len_hint(&iter)));
     tri!(iter.try_for_each(|item| serializer.serialize_element(&item)));
     serializer.end()`. -/
def collectSeq {S Ok Error SS I Item IntoIter : Type} (seqInst : SerializeSeqF X SS Ok Error)
    (serialize_seq : S → Option Usize → Result (core.result.Result SS Error))
    (intoIterInst : core.iter.traits.collect.IntoIterator I Item IntoIter) (itemInst : X Item)
    (self : S) (iter : I) : Result (core.result.Result Ok Error) := do
  let (iter, _) ← intoIterInst.into_iter iter
  match ← serialize_seq self (← iteratorLenHint intoIterInst.iteratorInst iter) with
  | .Err e => ok (.Err e)
  | .Ok serializer =>
    let (r, _, serializer) ← tryForEachResult intoIterInst.iteratorInst
      (fun s item => seqInst.serialize_element itemInst s item) iter serializer
    match r with
    | .Err e => ok (.Err e)
    | .Ok () => seqInst.«end» serializer

/-- The provided `Serializer::collect_map` (ser/mod.rs):
    `let mut iter = iter.into_iter();
     let mut serializer = tri!(self.serialize_map(iterator_len_hint(&iter)));
     tri!(iter.try_for_each(|(key, value)| serializer.serialize_entry(&key, &value)));
     serializer.end()`. -/
def collectMap {S Ok Error SM K V I IntoIter : Type} (mapInst : SerializeMapF X SM Ok Error)
    (serialize_map : S → Option Usize → Result (core.result.Result SM Error))
    (kInst : X K) (vInst : X V) (intoIterInst : core.iter.traits.collect.IntoIterator I (K × V) IntoIter)
    (self : S) (iter : I) : Result (core.result.Result Ok Error) := do
  let (iter, _) ← intoIterInst.into_iter iter
  match ← serialize_map self (← iteratorLenHint intoIterInst.iteratorInst iter) with
  | .Err e => ok (.Err e)
  | .Ok serializer =>
    let (r, _, serializer) ← tryForEachResult intoIterInst.iteratorInst
      (fun s entry => mapInst.serialize_entry kInst vInst s entry.1 entry.2) iter serializer
    match r with
    | .Err e => ok (.Err e)
    | .Ok () => mapInst.«end» serializer

/-- The message of the provided `serialize_i128`/`serialize_u128`:
    `Err(Error::custom("i128 is not supported"))`. -/
def unsupported {Ok Error : Type} (errInst : serde_core.ser.Error Error) (msg : String) :
    Result (core.result.Result Ok Error) := do
  .ok (.Err (← errInst.custom core.fmt.DisplayStr (← Str.ofString msg)))

structure SerializerF (Self Ok Error SerializeSeq SerializeTuple SerializeTupleStruct
    SerializeTupleVariant SerializeMap SerializeStruct SerializeStructVariant : Type) : Type 1 where
  serde_coreserErrorInst : serde_core.ser.Error Error
  SerializeSeqInst : SerializeSeqF X SerializeSeq Ok Error
  SerializeTupleInst : SerializeTupleF X SerializeTuple Ok Error
  SerializeTupleStructInst : SerializeTupleStructF X SerializeTupleStruct Ok Error
  SerializeTupleVariantInst : SerializeTupleVariantF X SerializeTupleVariant Ok Error
  SerializeMapInst : SerializeMapF X SerializeMap Ok Error
  SerializeStructInst : SerializeStructF X SerializeStruct Ok Error
  SerializeStructVariantInst : SerializeStructVariantF X SerializeStructVariant Ok Error
  serialize_bool : Self → Bool → Result (core.result.Result Ok Error)
  serialize_i8 : Self → I8 → Result (core.result.Result Ok Error)
  serialize_i16 : Self → I16 → Result (core.result.Result Ok Error)
  serialize_i32 : Self → I32 → Result (core.result.Result Ok Error)
  serialize_i64 : Self → I64 → Result (core.result.Result Ok Error)
  /-- Provided: `Err(Error::custom("i128 is not supported"))`. -/
  serialize_i128 : Self → I128 → Result (core.result.Result Ok Error) :=
    fun _ _ => unsupported serde_coreserErrorInst "i128 is not supported"
  serialize_u8 : Self → U8 → Result (core.result.Result Ok Error)
  serialize_u16 : Self → U16 → Result (core.result.Result Ok Error)
  serialize_u32 : Self → U32 → Result (core.result.Result Ok Error)
  serialize_u64 : Self → U64 → Result (core.result.Result Ok Error)
  /-- Provided: `Err(Error::custom("u128 is not supported"))`. -/
  serialize_u128 : Self → U128 → Result (core.result.Result Ok Error) :=
    fun _ _ => unsupported serde_coreserErrorInst "u128 is not supported"
  serialize_f32 : Self → F32 → Result (core.result.Result Ok Error)
  serialize_f64 : Self → F64 → Result (core.result.Result Ok Error)
  serialize_char : Self → Char → Result (core.result.Result Ok Error)
  serialize_str : Self → Str → Result (core.result.Result Ok Error)
  serialize_bytes : Self → Slice U8 → Result (core.result.Result Ok Error)
  serialize_none : Self → Result (core.result.Result Ok Error)
  serialize_some : {T : Type} → X T → Self → T → Result (core.result.Result Ok Error)
  serialize_unit : Self → Result (core.result.Result Ok Error)
  serialize_unit_struct : Self → Str → Result (core.result.Result Ok Error)
  serialize_unit_variant : Self → Str → U32 → Str → Result (core.result.Result Ok Error)
  serialize_newtype_struct : {T : Type} → X T → Self → Str → T →
    Result (core.result.Result Ok Error)
  serialize_newtype_variant : {T : Type} → X T → Self → Str → U32 → Str → T →
    Result (core.result.Result Ok Error)
  serialize_seq : Self → Option Usize → Result (core.result.Result SerializeSeq Error)
  serialize_tuple : Self → Usize → Result (core.result.Result SerializeTuple Error)
  serialize_tuple_struct : Self → Str → Usize →
    Result (core.result.Result SerializeTupleStruct Error)
  serialize_tuple_variant : Self → Str → U32 → Str → Usize →
    Result (core.result.Result SerializeTupleVariant Error)
  serialize_map : Self → Option Usize → Result (core.result.Result SerializeMap Error)
  serialize_struct : Self → Str → Usize → Result (core.result.Result SerializeStruct Error)
  serialize_struct_variant : Self → Str → U32 → Str → Usize →
    Result (core.result.Result SerializeStructVariant Error)
  /-- Provided: `true`. -/
  is_human_readable : Self → Result Bool := fun _ => ok true
  /-- Provided: `collectSeq`. -/
  collect_seq : {I Item IntoIter : Type} → core.iter.traits.collect.IntoIterator I Item IntoIter →
    X Item → Self → I → Result (core.result.Result Ok Error) :=
    fun intoIterInst itemInst self iter =>
      collectSeq X SerializeSeqInst serialize_seq intoIterInst itemInst self iter
  /-- Provided: `collectMap`. -/
  collect_map : {K V I IntoIter : Type} → X K → X V →
    core.iter.traits.collect.IntoIterator I (K × V) IntoIter → Self → I →
    Result (core.result.Result Ok Error) :=
    fun kInst vInst intoIterInst self iter =>
      collectMap X SerializeMapInst serialize_map kInst vInst intoIterInst self iter

/-- The data side (`Serialize`) relative to the knot family. -/
structure SerializeStep (Self : Type) : Type 1 where
  serialize : {S Ok Error SerializeSeq SerializeTuple SerializeTupleStruct SerializeTupleVariant
    SerializeMap SerializeStruct SerializeStructVariant : Type} →
    SerializerF X S Ok Error SerializeSeq SerializeTuple SerializeTupleStruct
      SerializeTupleVariant SerializeMap SerializeStruct SerializeStructVariant →
    Self → S → Result (core.result.Result Ok Error)
end

/-! ## Contravariance of the format side in the knot family -/

section map
variable {X Y : Type → Type 1} (g : ∀ {T : Type}, Y T → X T)

def SerializeSeqF.map {Self Ok Error : Type} (d : SerializeSeqF X Self Ok Error) :
    SerializeSeqF Y Self Ok Error :=
  { serde_coreserErrorInst := d.serde_coreserErrorInst
    serialize_element := fun x => d.serialize_element (g x)
    «end» := d.«end» }

def SerializeTupleF.map {Self Ok Error : Type} (d : SerializeTupleF X Self Ok Error) :
    SerializeTupleF Y Self Ok Error :=
  { serde_coreserErrorInst := d.serde_coreserErrorInst
    serialize_element := fun x => d.serialize_element (g x)
    «end» := d.«end» }

def SerializeTupleStructF.map {Self Ok Error : Type} (d : SerializeTupleStructF X Self Ok Error) :
    SerializeTupleStructF Y Self Ok Error :=
  { serde_coreserErrorInst := d.serde_coreserErrorInst
    serialize_field := fun x => d.serialize_field (g x)
    «end» := d.«end» }

def SerializeTupleVariantF.map {Self Ok Error : Type}
    (d : SerializeTupleVariantF X Self Ok Error) : SerializeTupleVariantF Y Self Ok Error :=
  { serde_coreserErrorInst := d.serde_coreserErrorInst
    serialize_field := fun x => d.serialize_field (g x)
    «end» := d.«end» }

def SerializeMapF.map {Self Ok Error : Type} (d : SerializeMapF X Self Ok Error) :
    SerializeMapF Y Self Ok Error :=
  { serde_coreserErrorInst := d.serde_coreserErrorInst
    serialize_key := fun x => d.serialize_key (g x)
    serialize_value := fun x => d.serialize_value (g x)
    serialize_entry := fun k v => d.serialize_entry (g k) (g v)
    «end» := d.«end» }

def SerializeStructF.map {Self Ok Error : Type} (d : SerializeStructF X Self Ok Error) :
    SerializeStructF Y Self Ok Error :=
  { serde_coreserErrorInst := d.serde_coreserErrorInst
    serialize_field := fun x => d.serialize_field (g x)
    skip_field := d.skip_field
    «end» := d.«end» }

def SerializeStructVariantF.map {Self Ok Error : Type}
    (d : SerializeStructVariantF X Self Ok Error) : SerializeStructVariantF Y Self Ok Error :=
  { serde_coreserErrorInst := d.serde_coreserErrorInst
    serialize_field := fun x => d.serialize_field (g x)
    skip_field := d.skip_field
    «end» := d.«end» }

def SerializerF.map {Self Ok Error SS ST STS STV SM SSt SSV : Type}
    (d : SerializerF X Self Ok Error SS ST STS STV SM SSt SSV) :
    SerializerF Y Self Ok Error SS ST STS STV SM SSt SSV :=
  { serde_coreserErrorInst := d.serde_coreserErrorInst
    SerializeSeqInst := d.SerializeSeqInst.map g
    SerializeTupleInst := d.SerializeTupleInst.map g
    SerializeTupleStructInst := d.SerializeTupleStructInst.map g
    SerializeTupleVariantInst := d.SerializeTupleVariantInst.map g
    SerializeMapInst := d.SerializeMapInst.map g
    SerializeStructInst := d.SerializeStructInst.map g
    SerializeStructVariantInst := d.SerializeStructVariantInst.map g
    serialize_bool := d.serialize_bool
    serialize_i8 := d.serialize_i8
    serialize_i16 := d.serialize_i16
    serialize_i32 := d.serialize_i32
    serialize_i64 := d.serialize_i64
    serialize_i128 := d.serialize_i128
    serialize_u8 := d.serialize_u8
    serialize_u16 := d.serialize_u16
    serialize_u32 := d.serialize_u32
    serialize_u64 := d.serialize_u64
    serialize_u128 := d.serialize_u128
    serialize_f32 := d.serialize_f32
    serialize_f64 := d.serialize_f64
    serialize_char := d.serialize_char
    serialize_str := d.serialize_str
    serialize_bytes := d.serialize_bytes
    serialize_none := d.serialize_none
    serialize_some := fun x => d.serialize_some (g x)
    serialize_unit := d.serialize_unit
    serialize_unit_struct := d.serialize_unit_struct
    serialize_unit_variant := d.serialize_unit_variant
    serialize_newtype_struct := fun x => d.serialize_newtype_struct (g x)
    serialize_newtype_variant := fun x => d.serialize_newtype_variant (g x)
    serialize_seq := d.serialize_seq
    serialize_tuple := d.serialize_tuple
    serialize_tuple_struct := d.serialize_tuple_struct
    serialize_tuple_variant := d.serialize_tuple_variant
    serialize_map := d.serialize_map
    serialize_struct := d.serialize_struct
    serialize_struct_variant := d.serialize_struct_variant
    is_human_readable := d.is_human_readable
    collect_seq := fun intoIterInst x => d.collect_seq intoIterInst (g x)
    collect_map := fun k v => d.collect_map (g k) (g v) }
end map

/-! ## Levels and the limit -/

/-- The data-side dictionaries usable with formats nesting at most `n` data-side calls. -/
def SerializeAt : Nat → Type → Type 1
  | 0, _ => PUnit
  | n + 1, T => SerializeStep (SerializeAt n) T

/-- A `Serialize` dictionary at every level: the knot positions of the format side. -/
structure SerializeΩ (T : Type) : Type 1 where
  level : ∀ n, SerializeAt n T

end serde_core.ser

/-! ## The Rust traits -/

@[reducible, rust_trait "serde_core::ser::SerializeSeq"
  (parentClauses := ["serde_coreserErrorInst"]) (methods := ["serialize_element", "end"])]
def serde_core.ser.SerializeSeq := serde_core.ser.SerializeSeqF serde_core.ser.SerializeΩ

@[reducible, rust_trait "serde_core::ser::SerializeTuple"
  (parentClauses := ["serde_coreserErrorInst"]) (methods := ["serialize_element", "end"])]
def serde_core.ser.SerializeTuple := serde_core.ser.SerializeTupleF serde_core.ser.SerializeΩ

@[reducible, rust_trait "serde_core::ser::SerializeTupleStruct"
  (parentClauses := ["serde_coreserErrorInst"]) (methods := ["serialize_field", "end"])]
def serde_core.ser.SerializeTupleStruct :=
  serde_core.ser.SerializeTupleStructF serde_core.ser.SerializeΩ

@[reducible, rust_trait "serde_core::ser::SerializeTupleVariant"
  (parentClauses := ["serde_coreserErrorInst"]) (methods := ["serialize_field", "end"])]
def serde_core.ser.SerializeTupleVariant :=
  serde_core.ser.SerializeTupleVariantF serde_core.ser.SerializeΩ

@[reducible, rust_trait "serde_core::ser::SerializeMap"
  (parentClauses := ["serde_coreserErrorInst"])
  (methods := ["serialize_key", "serialize_value", "serialize_entry", "end"])
  (defaultMethods := ["serialize_entry"])]
def serde_core.ser.SerializeMap := serde_core.ser.SerializeMapF serde_core.ser.SerializeΩ

@[reducible, rust_trait "serde_core::ser::SerializeStruct"
  (parentClauses := ["serde_coreserErrorInst"])
  (methods := ["serialize_field", "skip_field", "end"]) (defaultMethods := ["skip_field"])]
def serde_core.ser.SerializeStruct := serde_core.ser.SerializeStructF serde_core.ser.SerializeΩ

@[reducible, rust_trait "serde_core::ser::SerializeStructVariant"
  (parentClauses := ["serde_coreserErrorInst"])
  (methods := ["serialize_field", "skip_field", "end"]) (defaultMethods := ["skip_field"])]
def serde_core.ser.SerializeStructVariant :=
  serde_core.ser.SerializeStructVariantF serde_core.ser.SerializeΩ

@[reducible, rust_trait "serde_core::ser::Serializer"
  (parentClauses := ["serde_coreserErrorInst", "SerializeSeqInst", "SerializeTupleInst",
    "SerializeTupleStructInst", "SerializeTupleVariantInst", "SerializeMapInst",
    "SerializeStructInst", "SerializeStructVariantInst"])
  (methods := ["serialize_bool", "serialize_i8", "serialize_i16", "serialize_i32",
    "serialize_i64", "serialize_i128", "serialize_u8", "serialize_u16", "serialize_u32",
    "serialize_u64", "serialize_u128", "serialize_f32", "serialize_f64", "serialize_char",
    "serialize_str", "serialize_bytes", "serialize_none", "serialize_some", "serialize_unit",
    "serialize_unit_struct", "serialize_unit_variant", "serialize_newtype_struct",
    "serialize_newtype_variant", "serialize_seq", "serialize_tuple", "serialize_tuple_struct",
    "serialize_tuple_variant", "serialize_map", "serialize_struct", "serialize_struct_variant",
    "is_human_readable", "collect_seq", "collect_map"])
  (defaultMethods := ["serialize_i128", "serialize_u128", "is_human_readable", "collect_seq",
    "collect_map"])]
def serde_core.ser.Serializer := serde_core.ser.SerializerF serde_core.ser.SerializeΩ

@[reducible, rust_trait "serde_core::ser::Serialize" (methods := ["serialize"])
  (knot := "Aeneas.Std.serde_core.ser.Serialize.wrap")]
def serde_core.ser.Serialize := serde_core.ser.SerializeStep serde_core.ser.SerializeΩ

namespace serde_core.ser

/-- The knot: a `Serialize` dictionary at every level. At level `n + 1` it runs against the
    level-`n` format, seen at `SerializeΩ` by projecting its nested dictionaries to level `n`. -/
def Serialize.wrap {T : Type} (d : serde_core.ser.Serialize T) : SerializeΩ T :=
  ⟨fun n => match n with
    | 0 => PUnit.unit
    | n + 1 => ⟨fun inst => d.serialize (inst.map (fun x => x.level n))⟩⟩

/-- The knot is definitional: a wrapped dictionary at level `n + 1` is the dictionary run against
    the level-`n` format. -/
theorem Serialize.wrap_level_succ {T : Type} (d : serde_core.ser.Serialize T) (n : Nat) :
    (Serialize.wrap d).level (n + 1) =
      ⟨fun inst => d.serialize (inst.map (fun x => x.level n))⟩ := rfl

/-! ## Every Rust format has an encoding

A family of format types (indexed by `ι`: the serializers a Rust format passes to nested
`serialize` calls, e.g. serde_json's `&mut Serializer` and `MapKeySerializer`) with their associated
types. -/
structure FormatTypes (ι : Type) where
  S : ι → Type
  Ok : ι → Type
  Error : ι → Type
  SerializeSeq : ι → Type
  SerializeTuple : ι → Type
  SerializeTupleStruct : ι → Type
  SerializeTupleVariant : ι → Type
  SerializeMap : ι → Type
  SerializeStruct : ι → Type
  SerializeStructVariant : ι → Type

/-- The format-side dictionaries of the family at the knot family `X`. -/
def FormatTypes.Dicts {ι : Type} (τ : FormatTypes ι) (X : Type → Type 1) : Type 1 :=
  ∀ i, SerializerF X (τ.S i) (τ.Ok i) (τ.Error i) (τ.SerializeSeq i) (τ.SerializeTuple i)
    (τ.SerializeTupleStruct i) (τ.SerializeTupleVariant i) (τ.SerializeMap i)
    (τ.SerializeStruct i) (τ.SerializeStructVariant i)

/-- A Rust format: its dictionaries, generic in the knot family, given the family's dictionaries
    one level down. A Rust format receives `T: Serialize` at a knot position and can use it only by
    calling `serialize` with a serializer; with `X` abstract, the received `SerializeStep X T` can
    only be run against formats at `X`, i.e. the family one level down (or formats built from it). -/
structure FormatProgram {ι : Type} (τ : FormatTypes ι) where
  /-- The format when no nested data-side call is left (only the knot positions matter). -/
  base : τ.Dicts (SerializeAt 0)
  step : ∀ (X : Type → Type 1), τ.Dicts X → τ.Dicts (SerializeStep X)

/-- The format at level `n`. -/
def FormatProgram.level {ι : Type} {τ : FormatTypes ι} (p : FormatProgram τ) :
    (n : Nat) → τ.Dicts (SerializeAt n)
  | 0 => p.base
  | n + 1 => p.step (SerializeAt n) (p.level n)

/-- The encoding of a Rust format with nesting bound `n`: a `Serializer` dictionary. -/
def FormatProgram.encode {ι : Type} {τ : FormatTypes ι} (p : FormatProgram τ) (n : Nat) (i : ι) :
    serde_core.ser.Serializer (τ.S i) (τ.Ok i) (τ.Error i) (τ.SerializeSeq i)
      (τ.SerializeTuple i) (τ.SerializeTupleStruct i) (τ.SerializeTupleVariant i)
      (τ.SerializeMap i) (τ.SerializeStruct i) (τ.SerializeStructVariant i) :=
  (p.level n i).map (fun x => x.level n)

/-- The data-side dictionary a program receives at level `n + 1` for a wrapped `d`. -/
def stepDict {T : Type} (d : serde_core.ser.Serialize T) (n : Nat) :
    SerializeStep (SerializeAt n) T :=
  ⟨fun inst => d.serialize (inst.map (fun x => x.level n))⟩

/-- The encoded format at bound `n + 1` is the program's step over the level-`n` family, with the
    nested dictionaries at level `n + 1`. -/
theorem FormatProgram.encode_succ {ι : Type} {τ : FormatTypes ι} (p : FormatProgram τ) (n : Nat)
    (i : ι) : p.encode (n + 1) i =
      (p.step (SerializeAt n) (p.level n) i).map (fun x => x.level (n + 1)) := rfl

/-- A wrapped dictionary reaches the program as `stepDict d n`. -/
theorem FormatProgram.wrap_reaches {T : Type} (d : serde_core.ser.Serialize T) (n : Nat) :
    (Serialize.wrap d).level (n + 1) = stepDict d n := rfl

/-- Running the received dictionary against a format of the family one level down runs `d`
    against that format's encoding: the Rust semantics of a nested `value.serialize(sub)`. -/
theorem FormatProgram.stepDict_serialize {ι : Type} {τ : FormatTypes ι} (p : FormatProgram τ)
    {T : Type} (d : serde_core.ser.Serialize T) (n : Nat) (j : ι) :
    (stepDict d n).serialize (p.level n j) = d.serialize (p.encode n j) := rfl

/-- Every family of format types has a program, e.g. the one whose methods diverge. Hence the
    `Serializer` dictionaries of statements about data-side implementations are never vacuous. -/
def bottom (X : Type → Type 1) {S Ok Error SS ST STS STV SM SSt SSV : Type} :
    SerializerF X S Ok Error SS ST STS STV SM SSt SSV :=
  let err : serde_core.ser.Error Error :=
    { coreerrorErrorInst := ⟨⟨fun _ _ => .div⟩, ⟨fun _ _ => .div⟩⟩, custom := fun _ _ => .div }
  { serde_coreserErrorInst := err
    SerializeSeqInst := ⟨err, fun _ _ _ => .div, fun _ => .div⟩
    SerializeTupleInst := ⟨err, fun _ _ _ => .div, fun _ => .div⟩
    SerializeTupleStructInst := ⟨err, fun _ _ _ => .div, fun _ => .div⟩
    SerializeTupleVariantInst := ⟨err, fun _ _ _ => .div, fun _ => .div⟩
    SerializeMapInst := { serde_coreserErrorInst := err, serialize_key := fun _ _ _ => .div,
                          serialize_value := fun _ _ _ => .div, «end» := fun _ => .div }
    SerializeStructInst := { serde_coreserErrorInst := err,
                             serialize_field := fun _ _ _ _ => .div, «end» := fun _ => .div }
    SerializeStructVariantInst := { serde_coreserErrorInst := err,
                                    serialize_field := fun _ _ _ _ => .div,
                                    «end» := fun _ => .div }
    serialize_bool := fun _ _ => .div, serialize_i8 := fun _ _ => .div,
    serialize_i16 := fun _ _ => .div, serialize_i32 := fun _ _ => .div,
    serialize_i64 := fun _ _ => .div, serialize_u8 := fun _ _ => .div,
    serialize_u16 := fun _ _ => .div, serialize_u32 := fun _ _ => .div,
    serialize_u64 := fun _ _ => .div, serialize_f32 := fun _ _ => .div,
    serialize_f64 := fun _ _ => .div, serialize_char := fun _ _ => .div,
    serialize_str := fun _ _ => .div, serialize_bytes := fun _ _ => .div,
    serialize_none := fun _ => .div, serialize_some := fun _ _ _ => .div,
    serialize_unit := fun _ => .div, serialize_unit_struct := fun _ _ => .div,
    serialize_unit_variant := fun _ _ _ _ => .div,
    serialize_newtype_struct := fun _ _ _ _ => .div,
    serialize_newtype_variant := fun _ _ _ _ _ _ => .div,
    serialize_seq := fun _ _ => .div, serialize_tuple := fun _ _ => .div,
    serialize_tuple_struct := fun _ _ _ => .div,
    serialize_tuple_variant := fun _ _ _ _ _ => .div, serialize_map := fun _ _ => .div,
    serialize_struct := fun _ _ _ => .div, serialize_struct_variant := fun _ _ _ _ _ => .div }

end serde_core.ser

end Aeneas.Std
