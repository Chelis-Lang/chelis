import Aeneas.Std.Slice
import Aeneas.Std.Core.Cmp
import Aeneas.Std.Array.ArraySlice
import Aeneas.Std.Vec

/-!
# Comparison impls of `[T]` (`core/src/slice/cmp.rs`)

Lexicographic comparison through the element impls, in the order the library
evaluates them: elements pairwise up to the shorter length (`chaining_impl`),
then the lengths. `eq` compares lengths first and then stops at the first pair
whose element `ne` holds (`SlicePartialEq::equal_same_length`). The bytewise
specializations for primitive element types compute the same results.
-/

namespace Aeneas.Std

open Result

namespace core.slice.cmp

/-- `chaining_impl`: elements until the first `Break`, then the length chain.
    Both lists lose the same prefix, so comparing the remaining lengths is
    comparing the original lengths. -/
def chaining {T B C : Type} (elem : T → T → Result (core.ops.control_flow.ControlFlow B Unit))
    (len : Nat → Nat → core.ops.control_flow.ControlFlow B C) : List T → List T → Result (core.ops.control_flow.ControlFlow B C)
  | x :: xs, y :: ys => do
    match ← elem x y with
    | .Break b => ok (.Break b)
    | .Continue _ => chaining elem len xs ys
  | xs, ys => ok (len xs.length ys.length)

/-- `usize::__chaining_*`: `Continue` on equal lengths, else `Break (test)`. -/
def lenChain (test : Nat → Nat → Bool) (a b : Nat) : core.ops.control_flow.ControlFlow Bool Unit :=
  if a = b then .Continue () else .Break (test a b)

/-- `as_underlying(flow) == 1`: the flow broke with `true`. -/
def isBreakTrue : core.ops.control_flow.ControlFlow Bool Unit → Bool
  | .Break b => b
  | .Continue _ => false

/-- `as_underlying(flow) != 0`: the flow did not break with `false`. -/
def notBreakFalse : core.ops.control_flow.ControlFlow Bool Unit → Bool
  | .Break b => b
  | .Continue _ => true

def eqList {T U : Type} (ne : T → U → Result Bool) : List T → List U → Result Bool
  | x :: xs, y :: ys => do if ← ne x y then ok false else eqList ne xs ys
  | _, _ => ok true

end core.slice.cmp

open core.slice.cmp

@[rust_fun "core::slice::cmp::{core::cmp::PartialEq<[@T], [@U]>}::eq"]
def core.slice.cmp.PartialEqSlice.eq {T U : Type} (inst : core.cmp.PartialEq T U)
    (x : Slice T) (y : Slice U) : Result Bool :=
  if x.length = y.length then eqList inst.ne x.val y.val else ok false

@[rust_fun "core::slice::cmp::{core::cmp::PartialEq<[@T], [@U]>}::ne"]
def core.slice.cmp.PartialEqSlice.ne {T U : Type} (inst : core.cmp.PartialEq T U)
    (x : Slice T) (y : Slice U) : Result Bool := do
  ok (!(← core.slice.cmp.PartialEqSlice.eq inst x y))

@[reducible, rust_trait_impl "core::cmp::PartialEq<[@T], [@U]>"]
def core.slice.cmp.PartialEqSliceInst {T U : Type} (inst : core.cmp.PartialEq T U) :
    core.cmp.PartialEq (Slice T) (Slice U) := {
  eq := core.slice.cmp.PartialEqSlice.eq inst
  ne := core.slice.cmp.PartialEqSlice.ne inst
}

@[reducible, rust_trait_impl "core::cmp::Eq<[@T]>"]
def core.slice.cmp.EqSliceInst {T : Type} (inst : core.cmp.Eq T) : core.cmp.Eq (Slice T) := {
  partialEqInst := core.slice.cmp.PartialEqSliceInst inst.partialEqInst
}

@[rust_fun "core::slice::cmp::{core::cmp::PartialOrd<[@T], [@T]>}::partial_cmp"]
def core.slice.cmp.PartialOrdSlice.partial_cmp {T : Type} (inst : core.cmp.PartialOrd T T)
    (x y : Slice T) : Result (Option Ordering) := do
  let elem := fun a b => do
    match ← inst.partial_cmp a b with
    | some .eq => ok (core.ops.control_flow.ControlFlow.Continue ())
    | nonEq => ok (core.ops.control_flow.ControlFlow.Break nonEq)
  match ← chaining elem (fun a b => (.Break (some (compare a b)) : core.ops.control_flow.ControlFlow _ Empty)) x.val y.val with
  | .Break r => ok r
  | .Continue e => nomatch e

@[rust_fun "core::slice::cmp::{core::cmp::PartialOrd<[@T], [@T]>}::__chaining_lt"]
def core.slice.cmp.PartialOrdSlice.chaining_lt {T : Type} (inst : core.cmp.PartialOrd T T)
    (x y : Slice T) : Result (core.ops.control_flow.ControlFlow Bool Unit) :=
  chaining inst.__chaining_lt (lenChain (· < ·)) x.val y.val
@[rust_fun "core::slice::cmp::{core::cmp::PartialOrd<[@T], [@T]>}::__chaining_le"]
def core.slice.cmp.PartialOrdSlice.chaining_le {T : Type} (inst : core.cmp.PartialOrd T T)
    (x y : Slice T) : Result (core.ops.control_flow.ControlFlow Bool Unit) :=
  chaining inst.__chaining_le (lenChain (· ≤ ·)) x.val y.val
@[rust_fun "core::slice::cmp::{core::cmp::PartialOrd<[@T], [@T]>}::__chaining_gt"]
def core.slice.cmp.PartialOrdSlice.chaining_gt {T : Type} (inst : core.cmp.PartialOrd T T)
    (x y : Slice T) : Result (core.ops.control_flow.ControlFlow Bool Unit) :=
  chaining inst.__chaining_gt (lenChain (· > ·)) x.val y.val
@[rust_fun "core::slice::cmp::{core::cmp::PartialOrd<[@T], [@T]>}::__chaining_ge"]
def core.slice.cmp.PartialOrdSlice.chaining_ge {T : Type} (inst : core.cmp.PartialOrd T T)
    (x y : Slice T) : Result (core.ops.control_flow.ControlFlow Bool Unit) :=
  chaining inst.__chaining_ge (lenChain (· ≥ ·)) x.val y.val

@[rust_fun "core::slice::cmp::{core::cmp::PartialOrd<[@T], [@T]>}::lt"]
def core.slice.cmp.PartialOrdSlice.lt {T : Type} (inst : core.cmp.PartialOrd T T)
    (x y : Slice T) : Result Bool := do
  ok (isBreakTrue (← core.slice.cmp.PartialOrdSlice.chaining_lt inst x y))
@[rust_fun "core::slice::cmp::{core::cmp::PartialOrd<[@T], [@T]>}::le"]
def core.slice.cmp.PartialOrdSlice.le {T : Type} (inst : core.cmp.PartialOrd T T)
    (x y : Slice T) : Result Bool := do
  ok (notBreakFalse (← core.slice.cmp.PartialOrdSlice.chaining_le inst x y))
@[rust_fun "core::slice::cmp::{core::cmp::PartialOrd<[@T], [@T]>}::gt"]
def core.slice.cmp.PartialOrdSlice.gt {T : Type} (inst : core.cmp.PartialOrd T T)
    (x y : Slice T) : Result Bool := do
  ok (isBreakTrue (← core.slice.cmp.PartialOrdSlice.chaining_gt inst x y))
@[rust_fun "core::slice::cmp::{core::cmp::PartialOrd<[@T], [@T]>}::ge"]
def core.slice.cmp.PartialOrdSlice.ge {T : Type} (inst : core.cmp.PartialOrd T T)
    (x y : Slice T) : Result Bool := do
  ok (notBreakFalse (← core.slice.cmp.PartialOrdSlice.chaining_ge inst x y))

@[reducible, rust_trait_impl "core::cmp::PartialOrd<[@T], [@T]>"]
def core.slice.cmp.PartialOrdSliceInst {T : Type} (inst : core.cmp.PartialOrd T T) :
    core.cmp.PartialOrd (Slice T) (Slice T) := {
  partialEqInst := core.slice.cmp.PartialEqSliceInst inst.partialEqInst
  partial_cmp := core.slice.cmp.PartialOrdSlice.partial_cmp inst
  lt := core.slice.cmp.PartialOrdSlice.lt inst
  le := core.slice.cmp.PartialOrdSlice.le inst
  gt := core.slice.cmp.PartialOrdSlice.gt inst
  ge := core.slice.cmp.PartialOrdSlice.ge inst
  __chaining_lt := core.slice.cmp.PartialOrdSlice.chaining_lt inst
  __chaining_le := core.slice.cmp.PartialOrdSlice.chaining_le inst
  __chaining_gt := core.slice.cmp.PartialOrdSlice.chaining_gt inst
  __chaining_ge := core.slice.cmp.PartialOrdSlice.chaining_ge inst
}

@[rust_fun "core::slice::cmp::{core::cmp::Ord<[@T]>}::cmp"]
def core.slice.cmp.OrdSlice.cmp {T : Type} (inst : core.cmp.Ord T) (x y : Slice T) :
    Result Ordering := do
  let elem := fun a b => do
    match ← inst.cmp a b with
    | .eq => ok (core.ops.control_flow.ControlFlow.Continue ())
    | nonEq => ok (core.ops.control_flow.ControlFlow.Break nonEq)
  match ← chaining elem (fun a b => (.Break (compare a b) : core.ops.control_flow.ControlFlow _ Empty)) x.val y.val with
  | .Break r => ok r
  | .Continue e => nomatch e

@[reducible, rust_trait_impl "core::cmp::Ord<[@T]>"]
def core.slice.cmp.OrdSliceInst {T : Type} (inst : core.cmp.Ord T) : core.cmp.Ord (Slice T) := {
  eqInst := core.slice.cmp.EqSliceInst inst.eqInst
  partialOrdInst := core.slice.cmp.PartialOrdSliceInst inst.partialOrdInst
  cmp := core.slice.cmp.OrdSlice.cmp inst
}

/-- `impl PartialEq<[U; N]> for Vec<T, A>` (alloc/src/vec/partial_eq.rs, `__impl_slice_eq1`):
    `self[..] == other[..]`, the slice comparison. -/
@[rust_fun "alloc::vec::partial_eq::{core::cmp::PartialEq<alloc::vec::Vec<@T>, [@U; @N]>}::eq"
  (keepParams := [true, true, false])]
def alloc.vec.partial_eq.PartialEqVecArray.eq {T U : Type} {N : Usize}
    (inst : core.cmp.PartialEq T U) (v : alloc.vec.Vec T) (a : Array U N) : Result Bool :=
  core.slice.cmp.PartialEqSlice.eq inst (alloc.vec.Vec.deref v) a.to_slice

/-- `impl PartialEq<[U; N]> for Vec<T, A>`: `self[..] != other[..]`. -/
@[rust_fun "alloc::vec::partial_eq::{core::cmp::PartialEq<alloc::vec::Vec<@T>, [@U; @N]>}::ne"
  (keepParams := [true, true, false])]
def alloc.vec.partial_eq.PartialEqVecArray.ne {T U : Type} {N : Usize}
    (inst : core.cmp.PartialEq T U) (v : alloc.vec.Vec T) (a : Array U N) : Result Bool :=
  core.slice.cmp.PartialEqSlice.ne inst (alloc.vec.Vec.deref v) a.to_slice

end Aeneas.Std
