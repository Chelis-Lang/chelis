import Aeneas.Std.Core.NonZero
import Aeneas.Std.Core.Cmp
import Aeneas.Std.Core.Hash
import Aeneas.Std.Core.Fmt

/-! The trait impls of `NonZero<T>` (core/src/num/nonzero.rs, rustc 1.95), each of which applies
    the primitive's impl to `self.get()` (the model's `val`). Their `T: ZeroablePrimitive` clause
    (and its `NonZeroInner` parameter) is not used by the models. -/

namespace Aeneas.Std

/-- `impl PartialEq for NonZero<T> where T: ZeroablePrimitive + PartialEq`: `eq` is
    `self.get() == other.get()` and `ne` is `self.get() != other.get()` (the primitive's `ne`). -/
@[rust_fun
  "core::num::nonzero::{core::cmp::PartialEq<core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>, core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>>}::eq"
  (keepParams := [true, false]) (keepTraitClauses := [false, true])]
def core.num.nonzero.PartialEqNonZero.eq {T : Type} (eqInst : core.cmp.PartialEq T T)
    (self other : core.num.nonzero.NonZero T) : Result Bool :=
  eqInst.eq self.val other.val

@[rust_fun
  "core::num::nonzero::{core::cmp::PartialEq<core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>, core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>>}::ne"
  (keepParams := [true, false]) (keepTraitClauses := [false, true])]
def core.num.nonzero.PartialEqNonZero.ne {T : Type} (eqInst : core.cmp.PartialEq T T)
    (self other : core.num.nonzero.NonZero T) : Result Bool :=
  eqInst.ne self.val other.val

@[reducible, rust_trait_impl
  "core::cmp::PartialEq<core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>, core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>>"
  (keepParams := [true, false]) (keepTraitClauses := [false, true])]
def core.cmp.PartialEqNonZero {T : Type} (eqInst : core.cmp.PartialEq T T) :
    core.cmp.PartialEq (core.num.nonzero.NonZero T) (core.num.nonzero.NonZero T) := {
  eq := core.num.nonzero.PartialEqNonZero.eq eqInst
  ne := core.num.nonzero.PartialEqNonZero.ne eqInst
}

/-- `impl Hash for NonZero<T> where T: ZeroablePrimitive + Hash`: `self.get().hash(state)`. -/
@[rust_fun
  "core::num::nonzero::{core::hash::Hash<core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>>}::hash"
  (keepParams := [true, false, true]) (keepTraitClauses := [false, true, true])]
def core.num.nonzero.HashNonZero.hash {T H : Type} (hashInst : core.hash.Hash T)
    (hasherInst : core.hash.Hasher H) (self : core.num.nonzero.NonZero T) (state : H) :
    Result H :=
  hashInst.hash hasherInst self.val state

@[reducible, rust_trait_impl
  "core::hash::Hash<core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>>"
  (keepParams := [true, false]) (keepTraitClauses := [false, true])]
def core.hash.HashNonZero {T : Type} (hashInst : core.hash.Hash T) :
    core.hash.Hash (core.num.nonzero.NonZero T) := {
  hash := fun hasherInst => core.num.nonzero.HashNonZero.hash hashInst hasherInst
}

/-- `impl Debug for NonZero<T> where T: ZeroablePrimitive + Debug` (`impl_nonzero_fmt!`):
    `self.get().fmt(f)`, with the caller's formatting options. -/
@[rust_fun
  "core::num::nonzero::{core::fmt::Debug<core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>>}::fmt"
  (keepParams := [true, false]) (keepTraitClauses := [false, true])]
def core.num.nonzero.DebugNonZero.fmt {T : Type} (inst : core.fmt.Debug T)
    (self : core.num.nonzero.NonZero T) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  inst.fmt self.val fmt

@[reducible, rust_trait_impl
  "core::fmt::Debug<core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>>"
  (keepParams := [true, false]) (keepTraitClauses := [false, true])]
def core.fmt.DebugNonZero {T : Type} (inst : core.fmt.Debug T) :
    core.fmt.Debug (core.num.nonzero.NonZero T) :=
  ⟨core.num.nonzero.DebugNonZero.fmt inst⟩

end Aeneas.Std
