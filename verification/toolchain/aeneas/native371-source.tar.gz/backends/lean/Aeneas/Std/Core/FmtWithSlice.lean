import Aeneas.Std.Slice
import Aeneas.Std.Core.Fmt
import Aeneas.Std.Core.FmtUnicode
import Aeneas.Std.Core.Convert
import Aeneas.Std.String
import Aeneas.Std.Scalar.Fmt

namespace Aeneas.Std

namespace core.fmt

@[rust_fun "core::fmt::{core::fmt::Formatter<'a>}::debug_struct_fields_finish"]
def Formatter.debug_struct_fields_finish (fmt : Formatter) (name : Str)
    (names : Slice Str) (values : Slice DebugValue) : Outcome := do
  if names.val.length != values.val.length then return ← .fail .panic
  let names ← names.val.mapM (fun s => decode s.val)
  fmt.debugStruct (← decode name.val) (names.zip values.val)

def escapeDebugChar (c : Char) (quote : Char := '"') : String :=
  if c == '\x00' then "\\0"
  else if c == '\t' then "\\t"
  else if c == '\r' then "\\r"
  else if c == '\n' then "\\n"
  else if c == '\\' then "\\\\"
  else if c == quote then "\\" ++ String.singleton c
  else if needsDebugEscape c then "\\u{" ++ digits c.toNat 16 ++ "}"
  else String.singleton c

def debugStringParts : List Char → String → Formatter → Outcome
  | [], printable, fmt => fmt.append printable
  | c :: rest, printable, fmt =>
    let escaped := escapeDebugChar c
    if escaped == String.singleton c then debugStringParts rest (printable.push c) fmt
    else thenFormat (fmt.append printable) (fun fmt =>
      thenFormat (fmt.append escaped) (debugStringParts rest ""))

def debugString (s : String) (fmt : Formatter) : Outcome :=
  thenFormat (fmt.append "\"") (fun fmt =>
    thenFormat (debugStringParts s.toList "" fmt) (fun fmt => fmt.append "\""))

def displayString (s : String) (fmt : Formatter) : Outcome :=
  let s := if fmt.options.bit 28 then String.ofList (s.toList.take fmt.options.precision) else s
  fmt.pad s

/-- `impl Debug for char` (core/src/fmt/mod.rs, rustc 1.95): `'`, the `escape_debug_ext` of the
    character with `escape_grapheme_extended` and `escape_single_quote` (not the double quote)
    written with `Display for EscapeDebug` (a single write, no padding), then `'`. -/
@[rust_fun "core::fmt::{core::fmt::Debug<char>}::fmt"]
def DebugChar.fmt (c : Char) (fmt : Formatter) : Outcome :=
  thenFormat (fmt.append "'") (fun fmt =>
    thenFormat (fmt.append (escapeDebugChar c '\'')) (fun fmt => fmt.append "'"))
@[reducible, rust_trait_impl "core::fmt::Debug<char>"]
def DebugChar : Debug Char := ⟨DebugChar.fmt⟩

/-- `impl Display for char` (core/src/fmt/mod.rs): `write_char` without width and precision,
    else `pad` of its UTF-8 encoding (the precision truncates, the width pads). -/
@[rust_fun "core::fmt::{core::fmt::Display<char>}::fmt"]
def DisplayChar.fmt (c : Char) (fmt : Formatter) : Outcome :=
  displayString (String.singleton c) fmt
@[reducible, rust_trait_impl "core::fmt::Display<char>"]
def DisplayChar : Display Char := ⟨DisplayChar.fmt⟩

@[rust_fun "core::fmt::{core::fmt::Debug<str>}::fmt"]
def DebugStr.fmt (s : Str) (fmt : Formatter) : Outcome := do debugString (← decode s.val) fmt
@[reducible, rust_trait_impl "core::fmt::Debug<str>"]
def DebugStr : Debug Str := ⟨DebugStr.fmt⟩

@[rust_fun "core::fmt::{core::fmt::Display<str>}::fmt"]
def DisplayStr.fmt (s : Str) (fmt : Formatter) : Outcome := do displayString (← decode s.val) fmt
@[reducible, rust_trait_impl "core::fmt::Display<str>"]
def DisplayStr : Display Str := ⟨DisplayStr.fmt⟩

@[rust_fun "alloc::string::{core::fmt::Debug<alloc::string::String>}::fmt"]
def DebugString.fmt := debugString
@[reducible, rust_trait_impl "core::fmt::Debug<alloc::string::String>"]
def DebugString : Debug String := ⟨DebugString.fmt⟩

@[rust_fun "alloc::string::{core::fmt::Display<alloc::string::String>}::fmt"]
def DisplayString.fmt := displayString
@[reducible, rust_trait_impl "core::fmt::Display<alloc::string::String>"]
def DisplayString : Display String := ⟨DisplayString.fmt⟩

@[rust_fun "core::fmt::{core::fmt::Display<&'0 @T>}::fmt"]
def DisplayShared.fmt {T : Type} (inst : Display T) (x : T) (fmt : Formatter) : Outcome := inst.fmt x fmt
@[reducible, rust_trait_impl "core::fmt::Display<&'0 @T>"]
def DisplayShared {T : Type} (inst : Display T) : Display T := ⟨DisplayShared.fmt inst⟩

@[rust_fun "alloc::boxed::{core::fmt::Debug<alloc::boxed::Box<@T>>}::fmt" (keepParams := [true, false])]
def DebugBox.fmt {T : Type} (inst : Debug T) (x : T) (fmt : Formatter) : Outcome := inst.fmt x fmt
@[reducible, rust_trait_impl "core::fmt::Debug<alloc::boxed::Box<@T>>" (keepParams := [true, false])]
def DebugBox {T : Type} (inst : Debug T) : Debug T := ⟨DebugBox.fmt inst⟩

@[rust_fun "alloc::boxed::{core::fmt::Display<alloc::boxed::Box<@T>>}::fmt" (keepParams := [true, false])]
def DisplayBox.fmt {T : Type} (inst : Display T) (x : T) (fmt : Formatter) : Outcome := inst.fmt x fmt
@[reducible, rust_trait_impl "core::fmt::Display<alloc::boxed::Box<@T>>" (keepParams := [true, false])]
def DisplayBox {T : Type} (inst : Display T) : Display T := ⟨DisplayBox.fmt inst⟩

section Monotonicity

open Lean.Order

@[partial_fixpoint_monotone]
theorem DisplayShared.fmt.monotone {α : Type u} [Lean.Order.PartialOrder α]
    {T : Type} (callback : α → T → Callback)
    (hfmt : monotone callback) :
    monotone (fun a => DisplayShared.fmt ⟨callback a⟩) :=
  hfmt

@[partial_fixpoint_monotone]
theorem DebugBox.fmt.monotone {α : Type u} [Lean.Order.PartialOrder α]
    {T : Type} (callback : α → T → Callback)
    (hfmt : monotone callback) :
    monotone (fun a => DebugBox.fmt ⟨callback a⟩) :=
  hfmt

@[partial_fixpoint_monotone]
theorem DisplayBox.fmt.monotone {α : Type u} [Lean.Order.PartialOrder α]
    {T : Type} (callback : α → T → Callback)
    (hfmt : monotone callback) :
    monotone (fun a => DisplayBox.fmt ⟨callback a⟩) :=
  hfmt

@[partial_fixpoint_monotone]
theorem DisplayShared.fmt.apply_monotone {α : Type u} [Lean.Order.PartialOrder α]
    {T : Type} (callback : α → T → Callback) (x : T)
    (hfmt : Lean.Order.monotone callback) :
    Lean.Order.monotone (fun a => DisplayShared.fmt ⟨callback a⟩ x) :=
  monotone_apply x _ hfmt

@[partial_fixpoint_monotone]
theorem DebugBox.fmt.apply_monotone {α : Type u} [Lean.Order.PartialOrder α]
    {T : Type} (callback : α → T → Callback) (x : T)
    (hfmt : Lean.Order.monotone callback) :
    Lean.Order.monotone (fun a => DebugBox.fmt ⟨callback a⟩ x) :=
  monotone_apply x _ hfmt

@[partial_fixpoint_monotone]
theorem DisplayBox.fmt.apply_monotone {α : Type u} [Lean.Order.PartialOrder α]
    {T : Type} (callback : α → T → Callback) (x : T)
    (hfmt : Lean.Order.monotone callback) :
    Lean.Order.monotone (fun a => DisplayBox.fmt ⟨callback a⟩ x) :=
  monotone_apply x _ hfmt

@[partial_fixpoint_monotone]
theorem DisplayShared.fmt.apply_fmt_monotone {α : Type u} [Lean.Order.PartialOrder α]
    {T : Type} (callback : α → T → Callback) (x : T) (fmt : Formatter)
    (hfmt : Lean.Order.monotone callback) :
    Lean.Order.monotone (fun a => DisplayShared.fmt ⟨callback a⟩ x fmt) :=
  monotone_apply fmt _ (monotone_apply x _ hfmt)

@[partial_fixpoint_monotone]
theorem DebugBox.fmt.apply_fmt_monotone {α : Type u} [Lean.Order.PartialOrder α]
    {T : Type} (callback : α → T → Callback) (x : T) (fmt : Formatter)
    (hfmt : Lean.Order.monotone callback) :
    Lean.Order.monotone (fun a => DebugBox.fmt ⟨callback a⟩ x fmt) :=
  monotone_apply fmt _ (monotone_apply x _ hfmt)

@[partial_fixpoint_monotone]
theorem DisplayBox.fmt.apply_fmt_monotone {α : Type u} [Lean.Order.PartialOrder α]
    {T : Type} (callback : α → T → Callback) (x : T) (fmt : Formatter)
    (hfmt : Lean.Order.monotone callback) :
    Lean.Order.monotone (fun a => DisplayBox.fmt ⟨callback a⟩ x fmt) :=
  monotone_apply fmt _ (monotone_apply x _ hfmt)

end Monotonicity

@[rust_fun "core::option::{core::fmt::Debug<core::option::Option<@T>>}::fmt"]
def DebugOption.fmt {T : Type} (inst : Debug T) (x : Option T) (fmt : Formatter) : Outcome :=
  match x with
  | none => fmt.append "None"
  | some x => fmt.debugTuple "Some" [⟨T, inst, x⟩]
@[reducible, rust_trait_impl "core::fmt::Debug<core::option::Option<@T>>"]
def DebugOption {T : Type} (inst : Debug T) : Debug (Option T) := ⟨DebugOption.fmt inst⟩

@[rust_fun "core::fmt::{core::fmt::Debug<(@A, @B)>}::fmt"]
def DebugPair.fmt {A B : Type} (a : Debug A) (b : Debug B) (x : A × B) (fmt : Formatter) : Outcome :=
  fmt.debugTuple "" [⟨A, a, x.1⟩, ⟨B, b, x.2⟩]
@[reducible, rust_trait_impl "core::fmt::Debug<(@A, @B)>"]
def DebugPair {A B : Type} (a : Debug A) (b : Debug B) : Debug (A × B) := ⟨DebugPair.fmt a b⟩

/-- `impl<V: Debug, U: Debug, T: Debug> Debug for (V, U, T)` (core/src/fmt/mod.rs `tuple!`):
    `f.debug_tuple("")` with the three fields, then `finish()`, as for pairs. -/
@[rust_fun "core::fmt::{core::fmt::Debug<(@V, @U, @T)>}::fmt"]
def DebugTriple.fmt {V U T : Type} (v : Debug V) (u : Debug U) (t : Debug T) (x : V × U × T)
    (fmt : Formatter) : Outcome :=
  fmt.debugTuple "" [⟨V, v, x.1⟩, ⟨U, u, x.2.1⟩, ⟨T, t, x.2.2⟩]
@[reducible, rust_trait_impl "core::fmt::Debug<(@V, @U, @T)>"]
def DebugTriple {V U T : Type} (v : Debug V) (u : Debug U) (t : Debug T) : Debug (V × U × T) :=
  ⟨DebugTriple.fmt v u t⟩

@[rust_fun "core::num::error::{core::fmt::Debug<core::num::error::TryFromIntError>}::fmt"]
def DebugTryFromIntError.fmt (_ : core.num.error.TryFromIntError) (fmt : Formatter) : Outcome :=
  fmt.debugTuple "TryFromIntError" [⟨Unit, DebugUnit, ()⟩]
@[reducible, rust_trait_impl "core::fmt::Debug<core::num::error::TryFromIntError>"]
def DebugTryFromIntError : Debug core.num.error.TryFromIntError := ⟨DebugTryFromIntError.fmt⟩

end core.fmt

@[rust_fun "alloc::fmt::format"]
def alloc.fmt.format (args : core.fmt.Arguments) : Result String := do
  let (status, fmt) ← core.fmt.Formatter.write_fmt {} args
  match status with
  | .Ok () => .ok fmt.output
  | .Err _ => .fail .panic

/-! `impl fmt::Write for String` (alloc/src/string.rs, rustc 1.95): `write_str` is `push_str`
    and `write_char` is `push`, both `Ok(())`. -/

@[rust_fun "alloc::string::{core::fmt::Write<alloc::string::String>}::write_str"]
def alloc.string.WriteString.write_str (self : String) (s : Str) :
    Result (core.result.Result Unit core.fmt.Error × String) := do
  .ok (.Ok (), ← alloc.string.String.push_str self s)

@[rust_fun "alloc::string::{core::fmt::Write<alloc::string::String>}::write_char"]
def alloc.string.WriteString.write_char (self : String) (c : Char) :
    Result (core.result.Result Unit core.fmt.Error × String) := do
  .ok (.Ok (), ← alloc.string.String.push self c)

/-- `write_fmt` is `fmt::Write`'s provided method (core/src/fmt/mod.rs): `fmt::write(self, args)`
    (`args.as_statically_known_str()` writes the same text through `write_str`): the literal
    pieces are written with `write_str` and each placeholder is formatted by its callback with a
    `Formatter` over the string with the placeholder's options. Its status is returned: the
    first `fmt::Error` of a callback stops the rendering, and what was written before it stays
    in the string. -/
@[rust_fun "alloc::string::{core::fmt::Write<alloc::string::String>}::write_fmt"]
def alloc.string.WriteString.write_fmt (self : String) (args : core.fmt.Arguments) :
    Result (core.result.Result Unit core.fmt.Error × String) := do
  let (status, fmt) ← core.fmt.Formatter.write_fmt { output := self } args
  .ok (status, fmt.output)

@[rust_trait "alloc::string::ToString"]
structure alloc.string.ToString (T : Type) where
  to_string : T → Result String

@[rust_fun "alloc::string::{alloc::string::ToString<@T>}::to_string"]
def alloc.string.ToStringBlanket.to_string {T : Type} (inst : core.fmt.Display T) (x : T) : Result String := do
  let (status, fmt) ← inst.fmt x {}
  match status with
  | .Ok () => .ok fmt.output
  | .Err _ => .fail .panic

@[reducible, rust_trait_impl "alloc::string::ToString<@T>"]
def alloc.string.ToStringBlanket {T : Type} (inst : core.fmt.Display T) : alloc.string.ToString T :=
  ⟨alloc.string.ToStringBlanket.to_string inst⟩

end Aeneas.Std

namespace Aeneas.Std
open Lean.Order

/-- A least fixpoint is monotone in a parameter of its functional, if the functional is
    monotone in the parameter and the recursive function together (fixpoint induction). -/
theorem fix_monotone_param {γ : Sort u} {α : Sort v} [PartialOrder γ] [CCPO α]
    (F : γ → α → α) (hF : ∀ g, monotone (F g))
    (hjoint : monotone (fun (p : γ ×' α) => F p.1 p.2)) :
    monotone (fun g => fix (F g) (hF g)) := by
  intro g₁ g₂ h
  refine fix_induct (hF g₁) (fun x => x ⊑ fix (F g₂) (hF g₂)) ?_ ?_
  · intro c hc hx
    exact csup_le hc hx
  · intro x hx
    have hstep := hjoint ⟨g₁, x⟩ ⟨g₂, fix (F g₂) (hF g₂)⟩ ⟨h, hx⟩
    rw [fix_eq (hF g₂)]
    exact hstep

end Aeneas.Std

namespace Aeneas.Std.Monotonicity
open Lean Meta

/-- `e` without its metadata nodes (definitionally equal to `e`). -/
partial def eraseMData (e : Expr) : Expr :=
  e.replace fun e => if let .mdata _ b := e then some (eraseMData b) else none

/-- `proj (S.mk .. xᵢ ..) args` to `xᵢ args`, when the structure argument of the projection
    function reduces to a constructor application: a definition building a structure (e.g. an
    instance, `(IteratorMap i f).next`, or a closure's `FnMut` built from its call). -/
def reduceProjOfDef? (b : Expr) : MetaM (Option Expr) := do
  let .const c _ := b.getAppFn | return none
  let some info ← getProjectionFnInfo? c | return none
  let args := b.getAppArgs
  unless args.size > info.numParams do return none
  let s ← whnfD args[info.numParams]!
  let .const ctor _ := s.getAppFn | return none
  let some (.ctorInfo ctorVal) := (← getEnv).find? ctor | return none
  let sargs := s.getAppArgs
  unless sargs.size == ctorVal.numParams + ctorVal.numFields do return none
  return some (mkAppN sargs[ctorVal.numParams + info.i]! args[info.numParams + 1:]).headBeta

/-- What lies between a `fix` and the expression it is part of. -/
inductive Layer where
  | app (a : Expr)
  | proj (s : Name) (i : Nat)

/-- The head of `e` below its applications and projections (`PProd.fst/snd` included),
    and those layers, innermost first. -/
partial def strip (e : Expr) (acc : List Layer := []) : Expr × List Layer :=
  match e with
  | .mdata _ b => strip b acc
  | .proj s i b => strip b (.proj s i :: acc)
  | .app f a =>
    if e.isAppOfArity ``PProd.fst 3 then strip a (.proj ``PProd 0 :: acc)
    else if e.isAppOfArity ``PProd.snd 3 then strip a (.proj ``PProd 1 :: acc)
    else strip f (.app a :: acc)
  | _ => (e, acc)

def rebuild (e : Expr) (layers : List Layer) : Expr :=
  layers.foldl (init := e) fun e l =>
    match l with
    | .app a => (mkApp e a).headBeta
    | .proj s i => mkProj s i e

/-- The body of a definition below its parameters. -/
partial def lambdaBody : Expr → Expr
  | .lam _ _ b _ => lambdaBody b
  | .mdata _ b => lambdaBody b
  | e => e

/-- Whether `c` is defined by `partial_fixpoint`, or is the auxiliary definition of a mutual
    group of such definitions (its body is a projection of a `fix`). -/
def isFixpointDef (c : Name) : MetaM Bool := do
  if (Lean.Elab.PartialFixpoint.eqnInfoExt.find? (← getEnv) c).isSome then return true
  let some (.defnInfo info) := (← getEnv).find? c | return false
  return (strip (lambdaBody info.value)).1.isConstOf ``Lean.Order.fix

/-- Unfold the fixpoint definitions at the head of `e` until its head is `fix`. -/
partial def unfoldToFix (e : Expr) (fuel : Nat := 8) : MetaM Expr := do
  let (head, layers) := strip e
  let .const c us := head | throwError "aeneas_fix_monotone: no head constant in{indentExpr e}"
  if c == ``Lean.Order.fix then return e
  if fuel == 0 || !(← isFixpointDef c) then
    throwError "aeneas_fix_monotone: {c} is not a partial fixpoint"
  let some (.defnInfo info) := (← getEnv).find? c | throwError "aeneas_fix_monotone: {c}"
  unfoldToFix (rebuild (info.value.instantiateLevelParams info.levelParams us) layers) (fuel - 1)

/-- `p.1`, `p.2` as projections, which the monotonicity tactic follows to the recursive
    function, instead of projection function applications. -/
partial def projOfPProdFn (e : Expr) : Expr :=
  e.replace fun e =>
    if e.isAppOfArity ``PProd.fst 3 then some (mkProj ``PProd 0 (projOfPProdFn e.appArg!))
    else if e.isAppOfArity ``PProd.snd 3 then some (mkProj ``PProd 1 (projOfPProdFn e.appArg!))
    else none

/-- From `h : monotone f`, with `f : γ → ∀ x, β x`, the monotonicity of `fun g => f g a` (layer
    `.app a`) or, with `f : γ → α ×' β`, of `fun g => (f g).1` or `(f g).2` (layer `.proj`).
    The order instances are read off `h`'s type, as the `monotonicity` tactic does for the
    recursive calls: synthesizing the order of the tuple of a large mutual group of functions
    can exceed the instance search limits. -/
def monotoneLayer (γ instγ : Expr) (h : Expr) (layer : Layer) : MetaM Expr := do
  let_expr Lean.Order.monotone _ _ _ inst _ := (← inferType h)
    | throwError "aeneas_fix_monotone: unexpected{indentExpr (← inferType h)}"
  match layer with
  | .app a =>
    let some inst ← whnfUntil inst ``Lean.Order.instOrderPi
      | throwError "aeneas_fix_monotone: not a function order{indentExpr inst}"
    let_expr Lean.Order.instOrderPi α β instβ ← inst
      | throwError "aeneas_fix_monotone: not a function order{indentExpr inst}"
    mkAppOptM ``Lean.Order.monotone_apply #[α, β, γ, instγ, instβ, a, none, h]
  | .proj _ i =>
    let some inst ← whnfUntil inst ``Lean.Order.instPartialOrderPProd
      | throwError "aeneas_fix_monotone: not a product order{indentExpr inst}"
    let_expr Lean.Order.instPartialOrderPProd α β instα instβ ← inst
      | throwError "aeneas_fix_monotone: not a product order{indentExpr inst}"
    let n := if i == 0 then ``Lean.Order.PProd.monotone_fst else ``Lean.Order.PProd.monotone_snd
    mkAppOptM n #[α, β, γ, instα, instβ, instγ, none, h]

/-- `e` with the applications which mention the variable `x` only through types unfolded
    (delta and beta), where unfolding eliminates `x`: applications of type definitions, e.g.
    the state type `visit_children.closure… inst` of a closure specialized to an instance
    `inst` built from `x` (the extraction parameterizes a closure's type by the trait clauses
    of its function, which the type never uses), and applications of matchers whose
    parameters mention `x` only for such types (a `match` on a value of that state type). The
    result is definitionally equal to `e`; other occurrences of `x` are left as they are.
    Subterms are rewritten before the terms containing them, so a matcher is unfolded only
    if its discriminants and alternatives no longer mention `x`: `x` is then only in its
    parameters and motive, which the matcher uses in types only. -/
partial def erasePhantomTypes (x : FVarId) (e : Expr) (fuel : Nat := 16) : MetaM Expr := do
  if !e.containsFVar x then return e
  Meta.transform e (post := fun t => do
    if fuel == 0 || !t.containsFVar x then return .done t
    let .const c _ := t.getAppFn | return .done t
    let some (.defnInfo _) := (← getEnv).find? c | return .done t
    if let some info ← getMatcherInfo? c then
      if t.getAppArgs[info.getFirstDiscrPos:].toArray.any (·.containsFVar x) then
        return .done t
    else
      if (← isProjectionFn c) || (← isRecursiveDefinition c) then return .done t
      unless ← isType t do return .done t
    -- `delta?`, not `unfoldDefinition?`, which does not unfold matchers
    let some t' ← delta? t | return .done t
    let t' ← erasePhantomTypes x t' (fuel - 1)
    return .done (if t'.containsFVar x then t else t'))

/-- The outcome of the fallback step on a goal `monotone (fun f => c args)`. -/
inductive UnfoldStep where
  /-- the goal with `c` unfolded, or without its metadata -/
  | unfolded (goal : MVarId)
  /-- `c` is a structure projection: the body with it reduced, if its structure argument
      is a definition building a structure -/
  | proj (reduced? : Option Expr)

end Aeneas.Std.Monotonicity

open Lean Meta Elab Tactic Aeneas.Std.Monotonicity in
/-- Fallback step of `aeneas_monotonicity`, for a goal `monotone (fun f => c args)` to
    which no monotonicity lemma applies. If the goal holds metadata, erase it:
    `monotonicity` only looks through metadata around a whole recursive call, while the
    recursive function used as a trait method (`{ eq := f }`, marked `_recApp`) ends up
    at the head of the calls of the trait's default methods (`ne := fun a b => ... f a b`,
    so `(mdata f) a b`). Otherwise, if `c` is a non-recursive definition (e.g. the
    derived method of a generic type, called with an instance built from the recursive
    function `f`), unfold it once; if `c` is a structure projection, reduce it, unfolding
    the definition which builds the structure if needed (the method of an instance, e.g.
    `(IteratorMap i {..f..}).next`, or of a closure built from its call).
    Recursive definitions (structural, well-founded, `partial_fixpoint`) and matchers
    are never unfolded, so repeating this step terminates. -/
elab "aeneas_unfold_monotone" : tactic => do
  let goal ← getMainGoal
  let step ← goal.withContext do
    let type ← instantiateMVars (← goal.getType)
    let_expr Lean.Order.monotone α inst_α β inst_β f := type
      | throwError "aeneas_unfold_monotone: not a monotonicity goal"
    if (f.find? Expr.isMData).isSome then
      return UnfoldStep.unfolded (← goal.replaceTargetDefEq
        (mkAppN type.getAppFn #[α, inst_α, β, inst_β, eraseMData f]))
    let f := f.headBeta
    unless f.isLambda do throwError "aeneas_unfold_monotone: not a lambda"
    let some c := f.bindingBody!.getAppFn.constName?
      | throwError "aeneas_unfold_monotone: no head constant"
    let env ← getEnv
    if (← isProjectionFn c) then
      return UnfoldStep.proj (← lambdaBoundedTelescope f 1 fun xs b => do
        let some b' ← reduceProjOfDef? b | return none
        return some (← mkLambdaFVars xs b'))
    if isMatcherCore env c || (← isRecursiveDefinition c) ||
        (Lean.Elab.PartialFixpoint.eqnInfoExt.find? env c).isSome then
      throwError "aeneas_unfold_monotone: {c} is recursive or a matcher"
    let f' ← lambdaBoundedTelescope f 1 fun xs b => do
      let some b' ← unfoldDefinition? b
        | throwError "aeneas_unfold_monotone: cannot unfold {c}"
      mkLambdaFVars xs b'.headBeta
    return UnfoldStep.unfolded
      (← goal.replaceTargetDefEq (mkAppN type.getAppFn #[α, inst_α, β, inst_β, f']))
  match step with
  | .unfolded goal' =>
    replaceMainGoal [goal']
    evalTactic (← `(tactic| dsimp (config := { failIfUnchanged := false }) only))
  | .proj reduced? =>
    try evalTactic (← `(tactic| dsimp only))
    catch ex =>
      let some f' := reduced? | throw ex
      let goal' ← goal.withContext do
        let type ← instantiateMVars (← goal.getType)
        goal.replaceTargetDefEq (mkAppN type.getAppFn (type.getAppArgs.set! 4 f'))
      replaceMainGoal [goal']

open Lean Meta Elab Tactic Aeneas.Std.Monotonicity in
/-- Step of `aeneas_monotonicity` for a goal `monotone (fun g => P a₁ … aₙ)` where `P` is
    defined by `partial_fixpoint` (e.g. the model `iterToList` of `collect`, a fold, or a
    specialized visitor's loops) and some of its fixed parameters depend on `g`: a trait
    instance, typically a closure's, built from the function being defined. `P` unfolds to
    a least fixpoint `fix (F a)`, which is monotone in `a` if `F` is monotone in `a` and in
    its recursive function together (`fix_monotone_param`); that joint monotonicity is the
    new goal. The arguments of the fixpoint itself must not depend on `g`, nor its type,
    except through types which do not use it (`erasePhantomTypes`: the functions of a
    visitor specialized to a closure take the closure's state, whose type is parameterized
    by the instance). -/
elab "aeneas_fix_monotone" : tactic => do
  let goal ← getMainGoal
  let newGoal ← goal.withContext do
    let type ← instantiateMVars (← goal.getType)
    let_expr Lean.Order.monotone γ instγ _ _ f := type
      | throwError "aeneas_fix_monotone: not a monotonicity goal"
    let f := f.headBeta
    unless f.isLambda do throwError "aeneas_fix_monotone: not a lambda"
    withLocalDeclD f.bindingName! γ fun g => do
      let e ← unfoldToFix (f.bindingBody!.instantiate1 g)
      let (_, layers) := strip e
      let (args, rest) := layers.splitAt 4
      let args := args.filterMap fun | .app a => some a | .proj .. => none
      let [α, instα, F, hF] := args
        | throwError "aeneas_fix_monotone: unexpected fixpoint{indentExpr e}"
      let α ← erasePhantomTypes g.fvarId! α
      let instα ← erasePhantomTypes g.fvarId! instα
      if α.containsFVar g.fvarId! || instα.containsFVar g.fvarId! then
        throwError "aeneas_fix_monotone: the fixpoint's type depends on the variable"
      unless F.containsFVar g.fvarId! do
        throwError "aeneas_fix_monotone: the fixpoint does not depend on the variable"
      let lem ← mkAppOptM ``Aeneas.Std.fix_monotone_param
        #[γ, α, instγ, instα, ← mkLambdaFVars #[g] F, ← mkLambdaFVars #[g] hF]
      let .forallE _ jointTy _ _ ← whnfR (← inferType lem)
        | throwError "aeneas_fix_monotone: unexpected lemma type"
      let jointTy := projOfPProdFn (← Core.betaReduce (← instantiateMVars jointTy))
      let joint ← mkFreshExprSyntheticOpaqueMVar jointTy
      let mut prf := mkApp lem joint
      for l in rest do
        if let .app a := l then
          if a.containsFVar g.fvarId! then
            throwError "aeneas_fix_monotone: an argument of the fixpoint depends on the variable"
        prf ← monotoneLayer γ instγ prf l
      -- `P` is irreducible: the elaborator unfolds it only at transparency `all`
      unless ← withTransparency .all <| isDefEq (← inferType prf) type do
        throwError "aeneas_fix_monotone: the unfolded fixpoint does not match the goal"
      goal.assign prf
      pure joint.mvarId!
  replaceMainGoal [newGoal]

open Lean Meta Elab Tactic Aeneas.Std.Monotonicity in
/-- Step of `aeneas_monotonicity` for a goal `monotone (fun g => e)` where `g` occurs in
    types which do not use it: unfold them (`erasePhantomTypes`). The state type of a closure
    specialized to an instance built from `g` (a visitor's closure capturing the closure
    which calls the function being defined) is such a type: the type of a monadic value,
    of a lambda's binder or of a matcher's parameter, which the monotonicity lemmas require
    to be independent of `g` (`monotone_bind`, `monotone_of_monotone_apply`,
    `monotone_const`). Fails if there is none, so repeating this step terminates. -/
elab "aeneas_phantom_monotone" : tactic => do
  let goal ← getMainGoal
  let goal' ← goal.withContext do
    let type ← instantiateMVars (← goal.getType)
    let_expr Lean.Order.monotone α inst_α β inst_β f := type
      | throwError "aeneas_phantom_monotone: not a monotonicity goal"
    let f := f.headBeta
    unless f.isLambda do throwError "aeneas_phantom_monotone: not a lambda"
    let f' ← withLocalDecl f.bindingName! f.binderInfo f.bindingDomain! fun x => do
      let b := f.bindingBody!.instantiate1 x
      let b' ← erasePhantomTypes x.fvarId! b
      if b' == b then throwError "aeneas_phantom_monotone: no type to unfold"
      mkLambdaFVars #[x] b'
    goal.replaceTargetDefEq (mkAppN type.getAppFn #[α, inst_α, β, inst_β, f'])
  replaceMainGoal [goal']
