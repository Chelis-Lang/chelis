import Aeneas.Std.Core.Core
import Aeneas.Std.Core.Fmt
import Aeneas.Std.Core.Cmp
import Aeneas.Std.Core.Hash
import Aeneas.Std.Core.Ops
import Aeneas.Std.Core.Result
import Aeneas.Std.Core.Borrow
import Aeneas.Std.RangeBounds
import Aeneas.Data.Discriminant
import Aeneas.Std.Scalar.Fmt

namespace Aeneas.Std

-- Rust's Ordering is repr(i8), not the native Lean constructor index.
instance : Discriminant Ordering I8 where
  read_discriminant
    | .lt => (-1)#i8
    | .eq => 0#i8
    | .gt => 1#i8

/-! The discriminants of the other standard enums the library models (the extracted bodies of
their methods read them, e.g. `Result::is_ok` is `matches!(*self, Ok(_))`, and so does
`core::mem::discriminant`): Rust numbers the variants of an enum without `repr` from `0`,
in declaration order, as `isize`. -/

instance core.option.Option.instDiscriminant {T : Type u} : Discriminant (Option T) Isize where
  read_discriminant
    | none => 0#isize
    | some _ => 1#isize

instance core.result.Result.instDiscriminant {T : Type u} {E : Type v} :
    Discriminant (core.result.Result T E) Isize where
  read_discriminant
    | .Ok _ => 0#isize
    | .Err _ => 1#isize

instance core.ops.control_flow.ControlFlow.instDiscriminant {B C : Type} :
    Discriminant (core.ops.control_flow.ControlFlow B C) Isize where
  read_discriminant
    | .Continue _ => 0#isize
    | .Break _ => 1#isize

instance core.ops.range.Bound.instDiscriminant {T : Type} :
    Discriminant (core.ops.range.Bound T) Isize where
  read_discriminant
    | .Included _ => 0#isize
    | .Excluded _ => 1#isize
    | .Unbounded => 2#isize

instance alloc.borrow.Cow.instDiscriminant {B O : Type} :
    Discriminant (alloc.borrow.Cow B O) Isize where
  read_discriminant
    | .Borrowed _ => 0#isize
    | .Owned _ => 1#isize

@[rust_trait "core::marker::DiscriminantKind"
  (parentClauses := ["cloneInst", "copyInst", "debugInst", "partialEqInst", "eqInst", "hashInst"])
  (types := ["Discriminant"])]
structure DiscriminantKind (Self : Type) where
  Discriminant : Type -- TODO: this should be a parameter
  cloneInst : core.clone.Clone Discriminant
  copyInst : core.marker.Copy Discriminant
  debugInst : core.fmt.Debug Discriminant
  partialEqInst : core.cmp.PartialEq Discriminant Discriminant
  eqInst : core.cmp.Eq Discriminant
  hashInst : core.hash.Hash Discriminant

/-- **IMPORTANT:** the type of this function is not correct, the reason being that we can not
actually model it (it relies on the existence of some builtin implementation of `DiscriminantKind`,
which are available to rustc but which we can't provide). Any code which relies on this definition
will not type-check. The reason why we provide it is that it happens that the LLBC crate contains
this definition, while it is actually not used in the extracted model: we just want Aeneas to consider
it as builtin so that it doesn't generate any axiom for it (this is a way of ignoring it). -/
@[rust_fun "core::intrinsics::discriminant_value"]
def core.intrinsics.discriminant_value
  {T : Type} (DiscrInst : DiscriminantKind T) (_ : T) :
  Result (DiscrInst.Discriminant) := .fail .undef -- TODO: we need

/-- The integer value of a discriminant, and its two's-complement encoding (which the
    `{:x?}` debug flags print). -/
class core.mem.DiscriminantValue (β : Type) where
  value : β → Int
  bits : β → Nat

instance {ty} : core.mem.DiscriminantValue (IScalar ty) := ⟨(·.val), (·.bv.toNat)⟩
instance {ty} : core.mem.DiscriminantValue (UScalar ty) := ⟨fun x => (x.val : Int), (·.bv.toNat)⟩

/-- `core::mem::Discriminant<T>` (core/src/mem/mod.rs): a wrapper of
    `<T as DiscriminantKind>::Discriminant`, here that integer's value and encoding. -/
@[rust_type "core::mem::Discriminant"]
structure core.mem.Discriminant (T : Type) where
  value : Int
  bits : Nat
  deriving DecidableEq

/-- `core::mem::discriminant(v)`: the discriminant that `v`'s enum declares for its variant,
    read through the `@[discriminant]` instance that Aeneas generates for every enum. Rust
    also defines it (as `0`) on non-enum types; those have no `Discriminant` instance, so such
    a call fails to elaborate rather than being modeled. -/
@[rust_fun "core::mem::discriminant"]
def core.mem.discriminant {T β : Type} [_root_.Aeneas.Std.Discriminant T β] [core.mem.DiscriminantValue β]
    (v : T) : Result (core.mem.Discriminant T) :=
  let d := read_discriminant v
  .ok ⟨core.mem.DiscriminantValue.value d, core.mem.DiscriminantValue.bits d⟩

/-- `PartialEq for Discriminant<T>`: `self.0 == rhs.0`. -/
@[rust_fun "core::mem::{core::cmp::PartialEq<core::mem::Discriminant<@T>, core::mem::Discriminant<@T>>}::eq"]
def core.mem.PartialEqDiscriminant.eq {T : Type} (x y : core.mem.Discriminant T) : Result Bool :=
  .ok (x.value == y.value)

@[reducible, rust_trait_impl "core::cmp::PartialEq<core::mem::Discriminant<@T>, core::mem::Discriminant<@T>>"]
def core.mem.PartialEqDiscriminant (T : Type) :
  core.cmp.PartialEq (core.mem.Discriminant T) (core.mem.Discriminant T) := {
  eq := core.mem.PartialEqDiscriminant.eq
}

/-- `Debug for Discriminant<T>`: `fmt.debug_tuple("Discriminant").field(&self.0).finish()`,
    the field an integer (integer `Debug`, honouring the hex-debug flags). -/
@[rust_fun "core::mem::{core::fmt::Debug<core::mem::Discriminant<@T>>}::fmt"]
def core.mem.DebugDiscriminant.fmt {T : Type} (x : core.mem.Discriminant T)
    (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.debugTuple "Discriminant"
    [⟨Unit, ⟨fun _ f => core.fmt.debugInteger f x.value x.bits⟩, ()⟩]

@[reducible, rust_trait_impl "core::fmt::Debug<core::mem::Discriminant<@T>>"]
def core.mem.DebugDiscriminant (T : Type) : core.fmt.Debug (core.mem.Discriminant T) := {
  fmt := core.mem.DebugDiscriminant.fmt
}

end Aeneas.Std
