import Lean
import Aeneas.Std.Primitives
import Aeneas.Tactic.Step.Init
import Aeneas.Std.Alloc

namespace Aeneas

namespace Std

open Result

attribute [rust_type "core::option::Option" -prefixVariantNames] Option

@[rust_fun "alloc::boxed::{core::convert::AsMut<Box<@T>, @T>}::as_mut" -canFail (keepParams := [true,false])]
def alloc.boxed.AsMutBox.as_mut {T : Type} (x : T) : T × (T → T) :=
  (x, fun x => x)

/-- `AsRef<T> for Box<T, A>` (alloc/src/boxed.rs): `&**self`, the boxed value. -/
@[rust_fun "alloc::boxed::{core::convert::AsRef<Box<@T>, @T>}::as_ref" -canFail (keepParams := [true,false])]
def alloc.boxed.AsRefBox.as_ref {T : Type} (x : T) : T := x

/-! Rust's primitive ordered comparisons of `bool` (MIR `Lt`/`Le`/`Ge`/`Gt`,
    `impl PartialOrd for bool`): `false < true`. -/
def Bool.lt (x y : Bool) : Bool := !x && y
def Bool.le (x y : Bool) : Bool := !x || y
def Bool.ge (x y : Bool) : Bool := x || !y
def Bool.gt (x y : Bool) : Bool := x && !y

/-! Rust's non-short-circuiting logical operators on `bool` (MIR `BitAnd`,
    `BitOr`, `BitXor`; e.g. `impl Ord for bool`'s `min` is `self & other` and
    its `max` is `self | other`): both operands are evaluated. -/
def Bool.bitand (x y : Bool) : Bool := x && y
def Bool.bitor (x y : Bool) : Bool := x || y
def Bool.bitxor (x y : Bool) : Bool := x != y

/-! Rust's primitive ordered comparisons of `char` (MIR `Lt`/`Le`/`Ge`/`Gt`,
    `impl PartialOrd for char`): the order of the Unicode scalar values, which
    Lean's `Char` order (`Char.val : UInt32`) is. -/
def Char.lt (x y : Char) : Bool := decide (x.val < y.val)
def Char.le (x y : Char) : Bool := decide (x.val ≤ y.val)
def Char.ge (x y : Char) : Bool := decide (y.val ≤ x.val)
def Char.gt (x y : Char) : Bool := decide (y.val < x.val)

namespace core

@[rust_type "core::convert::Infallible"]
inductive convert.Infallible where

@[rust_trait "core::convert::From" (methodsInfo := [⟨ "from", "from_" ⟩])]
structure convert.From (Self T : Type) where
  from_ : T → Result Self

@[simp, step_simps, rust_fun "core::convert::{core::convert::From<@T, @T>}::from" -canFail]
def convert.FromSame.from_ {T : Type} (x : T) : T := x

@[reducible, rust_trait_impl "core::convert::From<@Self, @Self>"]
def convert.FromSame (T : Type) : convert.From T T := {
  from_ := fun x => ok (convert.FromSame.from_ x)
}

@[simp, step_simps, rust_fun "alloc::boxed::convert::{core::convert::From<Box<@T>, @T>}::from" -canFail]
def convert.FromBox.from_ {T : Type} (x : T) : T := x

@[reducible, rust_trait_impl "core::convert::From<Box<@T>, @T>"]
def convert.FromBox (T : Type) : convert.From T T := {
  from_ := fun x => ok (convert.FromBox.from_ x)
}

@[simp, step_simps, rust_fun "core::hint::must_use" -canFail]
def hint.must_use {T : Type} (value : T) : T := value

/-- `core::intrinsics::ub_checks` (read by `core::ub_checks::check_language_ub`
    and `check_library_ub`): whether the build runs the library's UB
    precondition checks, `cfg!(ub_checks)`. It follows `debug_assertions`, so
    native tests and debug builds run with the checks and release builds
    without them. Aeneas translates the MIR `NullaryOp(UbChecks)` to this
    constant.

    This is a configuration parameter, not a modeled value. It is opaque: no
    proof can depend on its value, so every theorem about extracted code holds
    for both configurations. Compiled evaluation (`#eval`, `#guard`) uses the
    default `false`; such evidence never counts as proof. Trust boundary:
    verification/trusted_base.json. -/
opaque intrinsics.ub_checks : Bool

/-- The precondition check of `core::hint::unreachable_unchecked`
    (core/src/hint.rs): `assert_unsafe_precondition!(check_language_ub,
    "hint::unreachable_unchecked must never be reached", () => false)` defines
    it with the condition `false`, so it always calls `panic_nounwind`, which
    aborts. It only runs when `ub_checks` holds; otherwise the next statement
    is the undefined behavior of `intrinsics::unreachable`. -/
@[rust_fun "core::hint::unreachable_unchecked::precondition_check"]
def hint.unreachable_unchecked.precondition_check : Result Unit := fail .panic

@[simp, step_simps, rust_fun "core::bool::{bool}::then_some" -canFail]
def bool.then_some {T : Type} (condition : Bool) (value : T) :
    Option T × (Option T → T) :=
  -- A discarded payload still owns its original borrow; a selected payload
  -- gives back the value updated through the returned Option.
  (if condition then some value else none, fun updated => updated.getD value)

@[rust_trait "core::clone::Clone" (defaultMethods := ["clone_from"])]
structure clone.Clone (Self : Type) where
  clone : Self → Result Self
  clone_from : Self → Self → Result Self := fun _ => clone

def clone.Clone.from_from.default {Self : Type} (clone : Self → Result Self)
  (_self source : Self) : Result Self :=
  clone source

@[reducible, rust_trait_impl "core::clone::Clone<alloc::alloc::Global>"]
def core.clone.CloneGlobal : core.clone.Clone Global := {
  clone := alloc.alloc.CloneGlobal.clone
}

/- [core::clone::impls::{(core::clone::Clone for bool)#19}::clone] -/
@[reducible, simp, step_simps]
def clone.impls.CloneBool.clone (b : Bool) : Bool := b

@[reducible, rust_trait_impl "core::clone::Clone<bool>"]
def clone.CloneBool : clone.Clone Bool := {
  clone := fun b => ok (clone.impls.CloneBool.clone b)
  clone_from := fun _ b => ok (clone.impls.CloneBool.clone b)
}

@[rust_fun "alloc::boxed::{core::clone::Clone<Box<@T>>}::clone"
    (keepParams := [true, false]) (keepTraitClauses := [true, false])]
def alloc.boxed.CloneBox.clone {T : Type} (cloneInst : core.clone.Clone T) : T → Result T :=
  cloneInst.clone

@[reducible, rust_trait_impl "core::clone::Clone<Box<@T>>"
    (keepParams := [true, false]) (keepTraitClauses := [true, false])]
def core.clone.CloneBox {T : Type} (cloneInst : core.clone.Clone T) : core.clone.Clone T := {
  clone := alloc.boxed.CloneBox.clone cloneInst
}

@[rust_trait "core::marker::Copy" (parentClauses := ["cloneInst"])]
structure marker.Copy (Self : Type) where
  cloneInst : core.clone.Clone Self

@[reducible, rust_trait_impl "core::marker::Copy<bool>"]
def core.marker.CopyBool : core.marker.Copy Bool := {
  cloneInst := core.clone.CloneBool
}

/-- `core::any::Any` (core/src/any.rs): only the evidence that a type
    implements it is modeled. Its one method, `type_id`, returns a
    compiler-assigned `TypeId` that the model does not represent, so an
    extracted call to it fails closed as an unknown external. -/
@[rust_trait "core::any::Any"]
structure any.Any (Self : Type) where

/-- `impl<T: 'static + ?Sized> Any for T` (core/src/any.rs). -/
@[reducible, rust_trait_impl "core::any::Any<@T>"]
def any.AnyBlanket (T : Type) : any.Any T := {}

/- [core::mem::replace]

   This acts like a swap effectively in a functional pure world.
   We return the old value of `dst`, i.e. `dst` itself.
   The new value of `dst` is `src`. -/
@[simp, step_simps, rust_fun "core::mem::replace" (canFail := false) (lift := false)]
def mem.replace {a : Type} (dst : a) (src : a) : a × a := (dst, src)

/- [core::mem::swap] -/
@[simp, step_simps, rust_fun "core::mem::swap" (canFail := false) (lift := false)]
def mem.swap {T : Type} (a b : T): T × T := (b, a)

end core

/-- Builtin clone implementation (used for some builtin types) -/
def BuiltinClone (Self : Type) : core.clone.Clone Self where
  clone := .ok
  clone_from := fun _ x => .ok x

/-- Builtin clone implementation (used for some builtin types) -/
def BuiltinCopy (Self : Type) : core.marker.Copy Self where
  cloneInst := BuiltinClone Self

/-- The constructor `Option::Some` used as a function value (e.g. `.map(Some)`). -/
@[rust_fun "core::option::Option::Some"]
def core.option.Option.Some {T : Type} (x : T) : Result (Option T) := ok (some x)

@[rust_fun "core::option::{core::option::Option<@T>}::unwrap"]
def core.option.Option.unwrap {T : Type} (x : Option T) : Result T :=
  Result.ofOption x Error.panic

@[step]
theorem core.option.Option.unwrap.spec {T : Type} (x : Option T) (h : x.isSome) :
  unwrap x ⦃ v => x = some v ⦄ := by
  simp only [unwrap, ofOption]; grind

@[step_pure_def, rust_fun "core::option::{core::option::Option<@T>}::unwrap_or" -canFail]
def core.option.Option.unwrap_or (self : Option T) (default : T) : T :=
  match self with
  | none => default
  | some self => self

@[simp] def core.option.Option.unwrap_or_some (self default : T) :
  core.option.Option.unwrap_or (some self) default = self := by simp [unwrap_or]

@[simp] def core.option.Option.unwrap_or_none (default : T) :
  core.option.Option.unwrap_or none default = default := by simp [unwrap_or]

@[simp, step_simps, rust_fun "core::option::{core::option::Option<@T>}::take" -canFail -lift]
def core.option.Option.take {T: Type} (self: Option T): Option T × Option T := (self, .none)

@[simp, step_simps, rust_fun "core::option::{core::option::Option<@T>}::is_none" -canFail -lift]
def core.option.Option.is_none {T: Type} (self: Option T): Bool := self.isNone

/-- Returns `true` if the option is `some`. -/
@[simp, step_simps, rust_fun "core::option::{core::option::Option<@T>}::is_some" -canFail -lift]
def core.option.Option.is_some {T: Type} (self: Option T): Bool := self.isSome

@[rust_type "core::ops::range::RangeFrom"]
structure core.ops.range.RangeFrom (Idx : Type) where
  start : Idx

@[rust_type "core::panicking::AssertKind"]
inductive core.panicking.AssertKind where
| Eq : core.panicking.AssertKind
| Ne : core.panicking.AssertKind
| Match : core.panicking.AssertKind

@[rust_fun "core::clone::impls::{core::clone::Clone<&'0 @T>}::clone"]
def core.clone.impls.CloneShared.clone {T : Type} (x : T) : Result T := .ok x

end Std

end Aeneas
