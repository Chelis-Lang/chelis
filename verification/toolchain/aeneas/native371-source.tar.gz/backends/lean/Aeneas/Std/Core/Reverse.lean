import Aeneas.Std.Core.Cmp

/-! `core::cmp::Reverse<T>` (core/src/cmp.rs, rustc 1.95): `pub struct Reverse<T>(pub T)` with
    the derived `PartialEq` and `Eq` and the hand-written `PartialOrd` and `Ord`, which compare
    the fields in the other order. Aeneas represents a tuple structure of one field by that field
    (`Reverse(x)` is `x` and `r.0` is `r`), so the model of the type is the alias `T`. -/

namespace Aeneas.Std

open Result

@[reducible, rust_type "core::cmp::Reverse"]
def core.cmp.Reverse (T : Type) : Type := T

/-- `#[derive(PartialEq)]`: `self.0 == other.0`. -/
@[rust_fun "core::cmp::{core::cmp::PartialEq<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>}::eq"]
def core.cmp.PartialEqReverse.eq {T : Type} (inst : core.cmp.PartialEq T T)
    (self other : core.cmp.Reverse T) : Result Bool :=
  inst.eq self other

/-- The derive defines only `eq`: `ne` is the provided `!self.eq(other)`, not `T::ne`. -/
@[rust_fun "core::cmp::{core::cmp::PartialEq<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>}::ne"]
def core.cmp.PartialEqReverse.ne {T : Type} (inst : core.cmp.PartialEq T T)
    (self other : core.cmp.Reverse T) : Result Bool := do
  ok (not (← inst.eq self other))

@[reducible, rust_trait_impl "core::cmp::PartialEq<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>"]
def core.cmp.PartialEqReverse {T : Type} (inst : core.cmp.PartialEq T T) :
    core.cmp.PartialEq (core.cmp.Reverse T) (core.cmp.Reverse T) := {
  eq := core.cmp.PartialEqReverse.eq inst
  ne := core.cmp.PartialEqReverse.ne inst
}

/-- `#[derive(Eq)]`: the receiver check exists only at compile time. -/
@[rust_fun "core::cmp::{core::cmp::Eq<core::cmp::Reverse<@T>>}::assert_receiver_is_total_eq"]
def core.cmp.EqReverse.assert_receiver_is_total_eq {T : Type} (_ : core.cmp.Eq T)
    (_ : core.cmp.Reverse T) : Result Unit :=
  ok ()

@[reducible, rust_trait_impl "core::cmp::Eq<core::cmp::Reverse<@T>>"]
def core.cmp.EqReverse {T : Type} (inst : core.cmp.Eq T) : core.cmp.Eq (core.cmp.Reverse T) := {
  partialEqInst := core.cmp.PartialEqReverse inst.partialEqInst
  assert_receiver_is_total_eq := core.cmp.EqReverse.assert_receiver_is_total_eq inst
}

/-- `partial_cmp` is `other.0.partial_cmp(&self.0)`. -/
@[rust_fun
  "core::cmp::{core::cmp::PartialOrd<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>}::partial_cmp"]
def core.cmp.PartialOrdReverse.partial_cmp {T : Type} (inst : core.cmp.PartialOrd T T)
    (self other : core.cmp.Reverse T) : Result (Option Ordering) :=
  inst.partial_cmp other self

/-- `lt` is `other.0 < self.0` (`T::lt`, not through `partial_cmp`), and so for `le`, `gt`
    and `ge`. -/
@[rust_fun "core::cmp::{core::cmp::PartialOrd<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>}::lt"]
def core.cmp.PartialOrdReverse.lt {T : Type} (inst : core.cmp.PartialOrd T T)
    (self other : core.cmp.Reverse T) : Result Bool :=
  inst.lt other self

@[rust_fun "core::cmp::{core::cmp::PartialOrd<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>}::le"]
def core.cmp.PartialOrdReverse.le {T : Type} (inst : core.cmp.PartialOrd T T)
    (self other : core.cmp.Reverse T) : Result Bool :=
  inst.le other self

@[rust_fun "core::cmp::{core::cmp::PartialOrd<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>}::gt"]
def core.cmp.PartialOrdReverse.gt {T : Type} (inst : core.cmp.PartialOrd T T)
    (self other : core.cmp.Reverse T) : Result Bool :=
  inst.gt other self

@[rust_fun "core::cmp::{core::cmp::PartialOrd<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>}::ge"]
def core.cmp.PartialOrdReverse.ge {T : Type} (inst : core.cmp.PartialOrd T T)
    (self other : core.cmp.Reverse T) : Result Bool :=
  inst.ge other self

/-- The `__chaining_*` methods are the provided ones (`default_chaining_impl`): one call of
    `Reverse`'s `partial_cmp`, `Continue` on `Equal`, `Break(p(c))` on another ordering and
    `Break(false)` on `None`. -/
@[rust_fun
  "core::cmp::{core::cmp::PartialOrd<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>}::__chaining_lt"]
def core.cmp.PartialOrdReverse.__chaining_lt {T : Type} (inst : core.cmp.PartialOrd T T)
    (self other : core.cmp.Reverse T) : Result (core.ops.control_flow.ControlFlow Bool Unit) :=
  core.cmp.PartialOrd.chaining_body (· == .lt) (core.cmp.PartialOrdReverse.partial_cmp inst)
    self other

@[rust_fun
  "core::cmp::{core::cmp::PartialOrd<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>}::__chaining_le"]
def core.cmp.PartialOrdReverse.__chaining_le {T : Type} (inst : core.cmp.PartialOrd T T)
    (self other : core.cmp.Reverse T) : Result (core.ops.control_flow.ControlFlow Bool Unit) :=
  core.cmp.PartialOrd.chaining_body (· != .gt) (core.cmp.PartialOrdReverse.partial_cmp inst)
    self other

@[rust_fun
  "core::cmp::{core::cmp::PartialOrd<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>}::__chaining_gt"]
def core.cmp.PartialOrdReverse.__chaining_gt {T : Type} (inst : core.cmp.PartialOrd T T)
    (self other : core.cmp.Reverse T) : Result (core.ops.control_flow.ControlFlow Bool Unit) :=
  core.cmp.PartialOrd.chaining_body (· == .gt) (core.cmp.PartialOrdReverse.partial_cmp inst)
    self other

@[rust_fun
  "core::cmp::{core::cmp::PartialOrd<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>}::__chaining_ge"]
def core.cmp.PartialOrdReverse.__chaining_ge {T : Type} (inst : core.cmp.PartialOrd T T)
    (self other : core.cmp.Reverse T) : Result (core.ops.control_flow.ControlFlow Bool Unit) :=
  core.cmp.PartialOrd.chaining_body (· != .lt) (core.cmp.PartialOrdReverse.partial_cmp inst)
    self other

@[reducible, rust_trait_impl
  "core::cmp::PartialOrd<core::cmp::Reverse<@T>, core::cmp::Reverse<@T>>"]
def core.cmp.PartialOrdReverse {T : Type} (inst : core.cmp.PartialOrd T T) :
    core.cmp.PartialOrd (core.cmp.Reverse T) (core.cmp.Reverse T) := {
  partialEqInst := core.cmp.PartialEqReverse inst.partialEqInst
  partial_cmp := core.cmp.PartialOrdReverse.partial_cmp inst
  lt := core.cmp.PartialOrdReverse.lt inst
  le := core.cmp.PartialOrdReverse.le inst
  gt := core.cmp.PartialOrdReverse.gt inst
  ge := core.cmp.PartialOrdReverse.ge inst
  __chaining_lt := core.cmp.PartialOrdReverse.__chaining_lt inst
  __chaining_le := core.cmp.PartialOrdReverse.__chaining_le inst
  __chaining_gt := core.cmp.PartialOrdReverse.__chaining_gt inst
  __chaining_ge := core.cmp.PartialOrdReverse.__chaining_ge inst
}

/-- `cmp` is `other.0.cmp(&self.0)`. -/
@[rust_fun "core::cmp::{core::cmp::Ord<core::cmp::Reverse<@T>>}::cmp"]
def core.cmp.OrdReverse.cmp {T : Type} (inst : core.cmp.Ord T)
    (self other : core.cmp.Reverse T) : Result Ordering :=
  inst.cmp other self

/-- `max`, `min` and `clamp` are `Ord`'s provided methods, through `Reverse`'s `lt`, `le` and
    `gt`: `max` is `if other < self { self } else { other }`, `min` is
    `if other < self { other } else { self }`, and `clamp` asserts `min <= max`. -/
@[rust_fun "core::cmp::{core::cmp::Ord<core::cmp::Reverse<@T>>}::max"]
def core.cmp.OrdReverse.max {T : Type} (inst : core.cmp.Ord T)
    (self other : core.cmp.Reverse T) : Result (core.cmp.Reverse T) :=
  core.cmp.Ord.max_body (core.cmp.PartialOrdReverse.lt inst.partialOrdInst) self other

@[rust_fun "core::cmp::{core::cmp::Ord<core::cmp::Reverse<@T>>}::min"]
def core.cmp.OrdReverse.min {T : Type} (inst : core.cmp.Ord T)
    (self other : core.cmp.Reverse T) : Result (core.cmp.Reverse T) :=
  core.cmp.Ord.min_body (core.cmp.PartialOrdReverse.lt inst.partialOrdInst) self other

@[rust_fun "core::cmp::{core::cmp::Ord<core::cmp::Reverse<@T>>}::clamp"]
def core.cmp.OrdReverse.clamp {T : Type} (inst : core.cmp.Ord T)
    (self min max : core.cmp.Reverse T) : Result (core.cmp.Reverse T) :=
  core.cmp.Ord.clamp_body (core.cmp.PartialOrdReverse.le inst.partialOrdInst)
    (core.cmp.PartialOrdReverse.lt inst.partialOrdInst)
    (core.cmp.PartialOrdReverse.gt inst.partialOrdInst) self min max

@[reducible, rust_trait_impl "core::cmp::Ord<core::cmp::Reverse<@T>>"]
def core.cmp.OrdReverse {T : Type} (inst : core.cmp.Ord T) :
    core.cmp.Ord (core.cmp.Reverse T) := {
  eqInst := core.cmp.EqReverse inst.eqInst
  partialOrdInst := core.cmp.PartialOrdReverse inst.partialOrdInst
  cmp := core.cmp.OrdReverse.cmp inst
  max := core.cmp.OrdReverse.max inst
  min := core.cmp.OrdReverse.min inst
  clamp := core.cmp.OrdReverse.clamp inst
}

end Aeneas.Std
