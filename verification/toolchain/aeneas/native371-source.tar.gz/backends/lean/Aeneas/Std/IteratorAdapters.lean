import Aeneas.Std.Core.Iter
import Aeneas.Std.Scalar.WrappingOps

namespace Aeneas.Std

open Result

/-- A stateful callback built from its shared call implementation. -/
private def iteratorCallback {F A B : Type} (call : F → A → Result (B × F)) :
    core.ops.function.FnMut F A B :=
  { FnOnceInst := { call_once := call }, call_mut := call }

-- The Iterator and DoubleEndedIterator bounds are separate Rust clauses, with
-- separately extracted Item parameters. Keep rev outside the Iterator record
-- because DoubleEndedIterator already contains its Iterator parent dictionary.
@[rust_fun "core::iter::traits::iterator::Iterator::rev"]
def core.iter.traits.iterator.Iterator.rev.default
  {Self Item RevItem : Type}
  (_iterInst : core.iter.traits.iterator.Iterator Self Item)
  (_doubleEndedInst : core.iter.traits.double_ended.DoubleEndedIterator Self RevItem)
  (self : Self) : Result (core.iter.adapters.rev.Rev Self) :=
  ok ⟨self⟩

@[rust_fun
  "core::iter::adapters::rev::{core::iter::traits::iterator::Iterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::next"]
def core.iter.adapters.rev.IteratorRev.next
  {I Item : Type}
  (doubleEndedInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
  (self : core.iter.adapters.rev.Rev I) :
  Result (Option Item × core.iter.adapters.rev.Rev I) := do
  let (item, iter) ← doubleEndedInst.next_back self.iter
  ok (item, ⟨iter⟩)

@[rust_fun
  "core::iter::adapters::rev::{core::iter::traits::iterator::Iterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::nth"]
def core.iter.adapters.rev.IteratorRev.nth
  {I Item : Type}
  (doubleEndedInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
  (self : core.iter.adapters.rev.Rev I) (n : Usize) :
  Result (Option Item × core.iter.adapters.rev.Rev I) := do
  let (result, iter) ← doubleEndedInst.nth_back self.iter n
  ok (result, ⟨iter⟩)

@[rust_fun
  "core::iter::adapters::rev::{core::iter::traits::iterator::Iterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::advance_by"]
def core.iter.adapters.rev.IteratorRev.advance_by
  {I Item : Type}
  (doubleEndedInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
  (self : core.iter.adapters.rev.Rev I) (n : Usize) :
  Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) × core.iter.adapters.rev.Rev I) := do
  let (result, iter) ← doubleEndedInst.advance_back_by self.iter n
  ok (result, ⟨iter⟩)

@[rust_fun
  "core::iter::adapters::rev::{core::iter::traits::iterator::Iterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::fold"]
def core.iter.adapters.rev.IteratorRev.fold
  {I B F Item : Type}
  (doubleEndedInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
  (fnInst : core.ops.function.FnMut F (B × Item) B)
  (self : core.iter.adapters.rev.Rev I) (init : B) (f : F) :
  Result (B × core.iter.adapters.rev.Rev I × F) := do
  let (result, iter, f) ← doubleEndedInst.rfold fnInst self.iter init f
  ok (result, ⟨iter⟩, f)

@[rust_fun
  "core::iter::adapters::rev::{core::iter::traits::iterator::Iterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::try_fold"]
def core.iter.adapters.rev.IteratorRev.try_fold
  {I B F R Item Residual : Type}
  (doubleEndedInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
  (fnInst : core.ops.function.FnMut F (B × Item) R)
  (tryInst : core.ops.try_trait.Try R B Residual)
  (self : core.iter.adapters.rev.Rev I) (init : B) (f : F) :
  Result (R × core.iter.adapters.rev.Rev I × F) := do
  let (result, iter, f) ← doubleEndedInst.try_rfold fnInst tryInst self.iter init f
  ok (result, ⟨iter⟩, f)

@[rust_fun
  "core::iter::adapters::rev::{core::iter::traits::iterator::Iterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::size_hint"]
def core.iter.adapters.rev.IteratorRev.size_hint
  {I Item : Type}
  (doubleEndedInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
  (self : core.iter.adapters.rev.Rev I) : Result (Usize × Option Usize) :=
  doubleEndedInst.iteratorInst.size_hint self.iter

@[rust_fun
  "core::iter::adapters::rev::{core::iter::traits::iterator::Iterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::find"]
def core.iter.adapters.rev.IteratorRev.find
  {I P Item : Type}
  (doubleEndedInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
  (fnInst : core.ops.function.FnMut P Item Bool)
  (self : core.iter.adapters.rev.Rev I) (predicate : P) :
  Result (Option Item × core.iter.adapters.rev.Rev I × P) := do
  let (item, iter, predicate) ← doubleEndedInst.rfind fnInst self.iter predicate
  ok (item, ⟨iter⟩, predicate)

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>"]
def core.iter.traits.iterator.IteratorRev
  {I Item : Type}
  (doubleEndedInst : core.iter.traits.double_ended.DoubleEndedIterator I Item) :
  core.iter.traits.iterator.Iterator (core.iter.adapters.rev.Rev I) Item := {
  next := core.iter.adapters.rev.IteratorRev.next doubleEndedInst
  nth := core.iter.adapters.rev.IteratorRev.nth doubleEndedInst
  advance_by := core.iter.adapters.rev.IteratorRev.advance_by doubleEndedInst
  fold := core.iter.adapters.rev.IteratorRev.fold doubleEndedInst
  try_fold := core.iter.adapters.rev.IteratorRev.try_fold doubleEndedInst
  size_hint := core.iter.adapters.rev.IteratorRev.size_hint doubleEndedInst
  find := core.iter.adapters.rev.IteratorRev.find doubleEndedInst
  trusted_len := doubleEndedInst.iteratorInst.trusted_len
  fused := doubleEndedInst.iteratorInst.fused
}

@[rust_fun
  "core::iter::adapters::rev::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::next_back"]
def core.iter.adapters.rev.DoubleEndedIteratorRev.next_back
  {I Item : Type}
  (doubleEndedInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
  (self : core.iter.adapters.rev.Rev I) :
  Result (Option Item × core.iter.adapters.rev.Rev I) := do
  let (item, iter) ← doubleEndedInst.iteratorInst.next self.iter
  ok (item, ⟨iter⟩)


@[rust_fun
  "core::iter::adapters::rev::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::nth_back"]
def core.iter.adapters.rev.DoubleEndedIteratorRev.nth_back
  {I Item : Type}
  (doubleEndedInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
  (self : core.iter.adapters.rev.Rev I) (n : Usize) :
  Result (Option Item × core.iter.adapters.rev.Rev I) := do
  let (result, iter) ← doubleEndedInst.iteratorInst.nth self.iter n
  ok (result, ⟨iter⟩)

@[rust_fun
  "core::iter::adapters::rev::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::advance_back_by"]
def core.iter.adapters.rev.DoubleEndedIteratorRev.advance_back_by
  {I Item : Type}
  (doubleEndedInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
  (self : core.iter.adapters.rev.Rev I) (n : Usize) :
  Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) × core.iter.adapters.rev.Rev I) := do
  let (result, iter) ← doubleEndedInst.iteratorInst.advance_by self.iter n
  ok (result, ⟨iter⟩)

@[rust_fun
  "core::iter::adapters::rev::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::rfold"]
def core.iter.adapters.rev.DoubleEndedIteratorRev.rfold
  {I B F Item : Type}
  (doubleEndedInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
  (fnInst : core.ops.function.FnMut F (B × Item) B)
  (self : core.iter.adapters.rev.Rev I) (init : B) (f : F) :
  Result (B × core.iter.adapters.rev.Rev I × F) := do
  let (result, iter, f) ← doubleEndedInst.iteratorInst.fold fnInst self.iter init f
  ok (result, ⟨iter⟩, f)

@[rust_fun
  "core::iter::adapters::rev::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::try_rfold"]
def core.iter.adapters.rev.DoubleEndedIteratorRev.try_rfold
  {I B F R Item Residual : Type}
  (doubleEndedInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
  (fnInst : core.ops.function.FnMut F (B × Item) R)
  (tryInst : core.ops.try_trait.Try R B Residual)
  (self : core.iter.adapters.rev.Rev I) (init : B) (f : F) :
  Result (R × core.iter.adapters.rev.Rev I × F) := do
  let (result, iter, f) ← doubleEndedInst.iteratorInst.try_fold fnInst tryInst self.iter init f
  ok (result, ⟨iter⟩, f)

@[rust_fun
  "core::iter::adapters::rev::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>}::rfind"]
def core.iter.adapters.rev.DoubleEndedIteratorRev.rfind
  {I P Item : Type}
  (doubleEndedInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
  (fnInst : core.ops.function.FnMut P Item Bool)
  (self : core.iter.adapters.rev.Rev I) (predicate : P) :
  Result (Option Item × core.iter.adapters.rev.Rev I × P) := do
  let (item, iter, predicate) ← doubleEndedInst.iteratorInst.find fnInst self.iter predicate
  ok (item, ⟨iter⟩, predicate)

@[reducible, rust_trait_impl
  "core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::rev::Rev<@I>, @Clause0_Clause0_Item>"]
def core.iter.traits.double_ended.DoubleEndedIteratorRev
  {I Item : Type}
  (doubleEndedInst : core.iter.traits.double_ended.DoubleEndedIterator I Item) :
  core.iter.traits.double_ended.DoubleEndedIterator (core.iter.adapters.rev.Rev I) Item := {
  iteratorInst := core.iter.traits.iterator.IteratorRev doubleEndedInst
  next_back := core.iter.adapters.rev.DoubleEndedIteratorRev.next_back doubleEndedInst
  nth_back := core.iter.adapters.rev.DoubleEndedIteratorRev.nth_back doubleEndedInst
  advance_back_by := core.iter.adapters.rev.DoubleEndedIteratorRev.advance_back_by doubleEndedInst
  rfold := core.iter.adapters.rev.DoubleEndedIteratorRev.rfold doubleEndedInst
  try_rfold := core.iter.adapters.rev.DoubleEndedIteratorRev.try_rfold doubleEndedInst
  rfind := core.iter.adapters.rev.DoubleEndedIteratorRev.rfind doubleEndedInst
}

@[rust_fun
  "core::iter::adapters::enumerate::{core::iter::traits::iterator::Iterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Item)>}::next"]
def core.iter.adapters.enumerate.IteratorEnumerate.next
  {I Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (self : core.iter.adapters.enumerate.Enumerate I) :
  Result (Option (Usize × Item) × core.iter.adapters.enumerate.Enumerate I) := do
  let (item, iter) ← iterInst.next self.iter
  match item with
  | none => ok (none, { self with iter })
  | some item =>
    let count ← self.count + 1#usize
    ok (some (self.count, item), { iter, count })

-- Enumerate overrides count by delegating to the inner iterator, without
-- advancing the enumeration index or losing an inner count override.
@[rust_fun
  "core::iter::adapters::enumerate::{core::iter::traits::iterator::Iterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Item)>}::count"]
def core.iter.adapters.enumerate.IteratorEnumerate.count
  {I Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (self : core.iter.adapters.enumerate.Enumerate I) :
  Result (Usize × core.iter.adapters.enumerate.Enumerate I) := do
  let (count, iter) ← iterInst.count self.iter
  ok (count, { self with iter })


@[rust_fun
  "core::iter::adapters::enumerate::{core::iter::traits::iterator::Iterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Item)>}::nth"]
def core.iter.adapters.enumerate.IteratorEnumerate.nth
  {I Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (self : core.iter.adapters.enumerate.Enumerate I) (n : Usize) :
  Result (Option (Usize × Item) × core.iter.adapters.enumerate.Enumerate I) := do
  let (item, iter) ← iterInst.nth self.iter n
  match item with
  | none => ok (none, { self with iter })
  | some item =>
    let index ← self.count + n
    let count ← index + 1#usize
    ok (some (index, item), { iter, count })

@[rust_fun
  "core::iter::adapters::enumerate::{core::iter::traits::iterator::Iterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Item)>}::fold"]
def core.iter.adapters.enumerate.IteratorEnumerate.fold
  {I Acc F Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (fnInst : core.ops.function.FnMut F (Acc × (Usize × Item)) Acc)
  (self : core.iter.adapters.enumerate.Enumerate I) (init : Acc) (f : F) :
  Result (Acc × core.iter.adapters.enumerate.Enumerate I × F) := do
  let callback := iteratorCallback fun (state : Usize × F) (args : Acc × Item) => do
    let (acc, f) ← fnInst.call_mut state.2 (args.1, (state.1, args.2))
    let count ← state.1 + 1#usize
    ok (acc, (count, f))
  let (acc, iter, count, f) ← iterInst.fold callback self.iter init (self.count, f)
  ok (acc, { iter, count }, f)

@[rust_fun
  "core::iter::adapters::enumerate::{core::iter::traits::iterator::Iterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Item)>}::try_fold"]
def core.iter.adapters.enumerate.IteratorEnumerate.try_fold
  {I Acc F R Item Residual : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (fnInst : core.ops.function.FnMut F (Acc × (Usize × Item)) R)
  (tryInst : core.ops.try_trait.Try R Acc Residual)
  (self : core.iter.adapters.enumerate.Enumerate I) (init : Acc) (f : F) :
  Result (R × core.iter.adapters.enumerate.Enumerate I × F) := do
  let callback := iteratorCallback fun (state : Usize × F) (args : Acc × Item) => do
    let (acc, f) ← fnInst.call_mut state.2 (args.1, (state.1, args.2))
    let count ← state.1 + 1#usize
    ok (acc, (count, f))
  let (acc, iter, count, f) ← iterInst.try_fold callback tryInst self.iter init (self.count, f)
  ok (acc, { iter, count }, f)

@[rust_fun
  "core::iter::adapters::enumerate::{core::iter::traits::iterator::Iterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Item)>}::size_hint"]
def core.iter.adapters.enumerate.IteratorEnumerate.size_hint
  {I Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (self : core.iter.adapters.enumerate.Enumerate I) : Result (Usize × Option Usize) :=
  iterInst.size_hint self.iter

@[rust_fun
  "core::iter::adapters::enumerate::{core::iter::traits::iterator::Iterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Item)>}::advance_by"]
def core.iter.adapters.enumerate.IteratorEnumerate.advance_by
  {I Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (self : core.iter.adapters.enumerate.Enumerate I) (n : Usize) :
  Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) ×
    core.iter.adapters.enumerate.Enumerate I) := do
  let (result, iter) ← iterInst.advance_by self.iter n
  let advanced ← match result with
    | .Ok _ => ok n
    | .Err remaining => n - remaining.val
  let count ← self.count + advanced
  ok (result, { iter, count })
@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Item)>"]
def core.iter.traits.iterator.IteratorEnumerate
  {I Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item) :
  core.iter.traits.iterator.Iterator
    (core.iter.adapters.enumerate.Enumerate I) (Usize × Item) := {
  next := core.iter.adapters.enumerate.IteratorEnumerate.next iterInst
  count := core.iter.adapters.enumerate.IteratorEnumerate.count iterInst
  nth := core.iter.adapters.enumerate.IteratorEnumerate.nth iterInst
  advance_by := core.iter.adapters.enumerate.IteratorEnumerate.advance_by iterInst
  fold := core.iter.adapters.enumerate.IteratorEnumerate.fold iterInst
  try_fold := core.iter.adapters.enumerate.IteratorEnumerate.try_fold iterInst
  size_hint := core.iter.adapters.enumerate.IteratorEnumerate.size_hint iterInst
  trusted_len := iterInst.trusted_len
  fused := iterInst.fused
  random_access := iterInst.random_access.map fun access => {
    is_full := access.is_full
    may_have_side_effect := access.may_have_side_effect
    get_unchecked self n := do
      let (item, iter) ← access.get_unchecked self.iter n
      let index ← self.count + n
      ok ((index, item), { self with iter })
  }
}

/-! `DoubleEndedIterator for Enumerate<I>` (core enumerate.rs, rustc 1.95),
    for `I: ExactSizeIterator + DoubleEndedIterator` (clauses in that order):
    the index of an item taken from the back is `count + I::len()` once it has
    been taken, and the back folds count down from `count + I::len()`. Core
    computes these with its unchecked `+` and `-=` (std is built without
    overflow checks, and ExactSizeIterator promises that they cannot
    overflow): wrapping operations here. -/

@[rust_fun
  "core::iter::adapters::enumerate::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Clause0_Item)>}::next_back"]
def core.iter.adapters.enumerate.DoubleEndedIteratorEnumerate.next_back {I Item : Type}
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item)
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (self : core.iter.adapters.enumerate.Enumerate I) :
    Result (Option (Usize × Item) × core.iter.adapters.enumerate.Enumerate I) := do
  let (item, iter) ← backInst.next_back self.iter
  match item with
  | none => ok (none, { self with iter })
  | some item =>
    let len ← exactInst.len iter
    ok (some (UScalar.wrapping_add self.count len, item), { self with iter })

@[rust_fun
  "core::iter::adapters::enumerate::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Clause0_Item)>}::nth_back"]
def core.iter.adapters.enumerate.DoubleEndedIteratorEnumerate.nth_back {I Item : Type}
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item)
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (self : core.iter.adapters.enumerate.Enumerate I) (n : Usize) :
    Result (Option (Usize × Item) × core.iter.adapters.enumerate.Enumerate I) := do
  let (item, iter) ← backInst.nth_back self.iter n
  match item with
  | none => ok (none, { self with iter })
  | some item =>
    let len ← exactInst.len iter
    ok (some (UScalar.wrapping_add self.count len, item), { self with iter })

/-- The back fold callback: `count -= 1; fold(acc, (count, item))`. -/
def core.iter.adapters.enumerate.DoubleEndedIteratorEnumerate.countDown {Item B F R : Type}
    (fnInst : core.ops.function.FnMut F (B × (Usize × Item)) R) :
    core.ops.function.FnMut (F × Usize) (B × Item) R :=
  let call := fun (state : F × Usize) (args : B × Item) => do
    let count := UScalar.wrapping_sub state.2 1#usize
    let (r, f) ← fnInst.call_mut state.1 (args.1, (count, args.2))
    ok (r, (f, count))
  { FnOnceInst := { call_once := call }, call_mut := call }

@[rust_fun
  "core::iter::adapters::enumerate::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Clause0_Item)>}::try_rfold"]
def core.iter.adapters.enumerate.DoubleEndedIteratorEnumerate.try_rfold
    {I Item B F R Residual : Type}
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item)
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (fnInst : core.ops.function.FnMut F (B × (Usize × Item)) R)
    (tryInst : core.ops.try_trait.Try R B Residual)
    (self : core.iter.adapters.enumerate.Enumerate I) (init : B) (f : F) :
    Result (R × core.iter.adapters.enumerate.Enumerate I × F) := do
  let len ← exactInst.len self.iter
  let count := UScalar.wrapping_add self.count len
  let (r, iter, (f, _)) ← backInst.try_rfold
    (core.iter.adapters.enumerate.DoubleEndedIteratorEnumerate.countDown fnInst) tryInst
    self.iter init (f, count)
  ok (r, { self with iter }, f)

@[rust_fun
  "core::iter::adapters::enumerate::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Clause0_Item)>}::rfold"]
def core.iter.adapters.enumerate.DoubleEndedIteratorEnumerate.rfold {I Item B F : Type}
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item)
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (fnInst : core.ops.function.FnMut F (B × (Usize × Item)) B)
    (self : core.iter.adapters.enumerate.Enumerate I) (init : B) (f : F) :
    Result (B × core.iter.adapters.enumerate.Enumerate I × F) := do
  let len ← exactInst.len self.iter
  let count := UScalar.wrapping_add self.count len
  let (acc, iter, (f, _)) ← backInst.rfold
    (core.iter.adapters.enumerate.DoubleEndedIteratorEnumerate.countDown fnInst)
    self.iter init (f, count)
  ok (acc, { self with iter }, f)

/-- Items taken from the back never change the front count. -/
@[rust_fun
  "core::iter::adapters::enumerate::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Clause0_Item)>}::advance_back_by"]
def core.iter.adapters.enumerate.DoubleEndedIteratorEnumerate.advance_back_by {I Item : Type}
    (_exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item)
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (self : core.iter.adapters.enumerate.Enumerate I) (n : Usize) :
    Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) ×
      core.iter.adapters.enumerate.Enumerate I) := do
  let (r, iter) ← backInst.advance_back_by self.iter n
  ok (r, { self with iter })

@[reducible, rust_trait_impl
  "core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Clause0_Item)>"]
def core.iter.traits.double_ended.DoubleEndedIteratorEnumerate {I Item : Type}
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item)
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item) :
    core.iter.traits.double_ended.DoubleEndedIterator
      (core.iter.adapters.enumerate.Enumerate I) (Usize × Item) := {
  iteratorInst := core.iter.traits.iterator.IteratorEnumerate exactInst.iteratorInst
  next_back := core.iter.adapters.enumerate.DoubleEndedIteratorEnumerate.next_back exactInst backInst
  nth_back := core.iter.adapters.enumerate.DoubleEndedIteratorEnumerate.nth_back exactInst backInst
  advance_back_by :=
    core.iter.adapters.enumerate.DoubleEndedIteratorEnumerate.advance_back_by exactInst backInst
  rfold := core.iter.adapters.enumerate.DoubleEndedIteratorEnumerate.rfold exactInst backInst
  try_rfold := core.iter.adapters.enumerate.DoubleEndedIteratorEnumerate.try_rfold exactInst backInst
}

/-- `ExactSizeIterator for Enumerate<I>`: `len` is `self.iter.len()`. -/
@[rust_fun
  "core::iter::adapters::enumerate::{core::iter::traits::exact_size::ExactSizeIterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Clause0_Item)>}::len"]
def core.iter.adapters.enumerate.ExactSizeIteratorEnumerate.len {I Item : Type}
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item)
    (self : core.iter.adapters.enumerate.Enumerate I) : Result Usize :=
  exactInst.len self.iter

@[reducible, rust_trait_impl
  "core::iter::traits::exact_size::ExactSizeIterator<core::iter::adapters::enumerate::Enumerate<@I>, (usize, @Clause0_Clause0_Item)>"]
def core.iter.traits.exact_size.ExactSizeIteratorEnumerate {I Item : Type}
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item) :
    core.iter.traits.exact_size.ExactSizeIterator
      (core.iter.adapters.enumerate.Enumerate I) (Usize × Item) := {
  iteratorInst := core.iter.traits.iterator.IteratorEnumerate exactInst.iteratorInst
  len := core.iter.adapters.enumerate.ExactSizeIteratorEnumerate.len exactInst
}

@[rust_fun "core::iter::traits::iterator::Iterator::map"]
def core.iter.traits.iterator.Iterator.map.default
  {Self B F Item : Type}
  (_iterInst : core.iter.traits.iterator.Iterator Self Item)
  (_fnInst : core.ops.function.FnMut F Item B)
  (self : Self) (f : F) : Result (core.iter.adapters.map.Map Self F) :=
  ok ⟨self, f⟩

@[rust_fun
  "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::next"]
def core.iter.adapters.map.IteratorMap.next
  {B I F Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (fnInst : core.ops.function.FnMut F Item B)
  (self : core.iter.adapters.map.Map I F) :
  Result (Option B × core.iter.adapters.map.Map I F) := do
  let (item, iter) ← iterInst.next self.iter
  match item with
  | none => ok (none, { self with iter })
  | some item =>
    let (item, f) ← fnInst.call_mut self.f item
    ok (some item, { iter, f })

@[rust_fun
  "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::step_by"]
def core.iter.adapters.map.IteratorMap.step_by
  {B I F Item : Type} (_iterInst : core.iter.traits.iterator.Iterator I Item)
  (_fnInst : core.ops.function.FnMut F Item B)
  (self : core.iter.adapters.map.Map I F) (step : Usize) :
  Result (core.iter.adapters.step_by.StepBy (core.iter.adapters.map.Map I F)) :=
  core.iter.traits.iterator.Iterator.step_by.default self step

@[rust_fun
  "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::enumerate"]
def core.iter.adapters.map.IteratorMap.enumerate
  {B I F Item : Type} (_iterInst : core.iter.traits.iterator.Iterator I Item)
  (_fnInst : core.ops.function.FnMut F Item B)
  (self : core.iter.adapters.map.Map I F) :
  Result (core.iter.adapters.enumerate.Enumerate (core.iter.adapters.map.Map I F)) :=
  core.iter.traits.iterator.Iterator.enumerate.default self

@[rust_fun
  "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::take"]
def core.iter.adapters.map.IteratorMap.take
  {B I F Item : Type} (_iterInst : core.iter.traits.iterator.Iterator I Item)
  (_fnInst : core.ops.function.FnMut F Item B)
  (self : core.iter.adapters.map.Map I F) (n : Usize) :
  Result (core.iter.adapters.take.Take (core.iter.adapters.map.Map I F)) :=
  core.iter.traits.iterator.Iterator.take.default self n


@[rust_fun
  "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::fold"]
def core.iter.adapters.map.IteratorMap.fold
  {B I F Acc G Item : Type}
  (iterInst : core.iter.traits.iterator.Iterator I Item)
  (fnInst : core.ops.function.FnMut F Item B)
  (foldInst : core.ops.function.FnMut G (Acc × B) Acc)
  (self : core.iter.adapters.map.Map I F) (init : Acc) (g : G) :
  Result (Acc × core.iter.adapters.map.Map I F × G) := do
  let callback := iteratorCallback fun (state : F × G) (args : Acc × Item) => do
    let (item, f) ← fnInst.call_mut state.1 args.2
    let (acc, g) ← foldInst.call_mut state.2 (args.1, item)
    ok (acc, (f, g))
  let (acc, iter, f, g) ← iterInst.fold callback self.iter init (self.f, g)
  ok (acc, { iter, f }, g)

@[rust_fun
  "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::try_fold"]
def core.iter.adapters.map.IteratorMap.try_fold
  {B I F Acc G R Item Residual : Type}
  (iterInst : core.iter.traits.iterator.Iterator I Item)
  (fnInst : core.ops.function.FnMut F Item B)
  (foldInst : core.ops.function.FnMut G (Acc × B) R)
  (tryInst : core.ops.try_trait.Try R Acc Residual)
  (self : core.iter.adapters.map.Map I F) (init : Acc) (g : G) :
  Result (R × core.iter.adapters.map.Map I F × G) := do
  let callback := iteratorCallback fun (state : F × G) (args : Acc × Item) => do
    let (item, f) ← fnInst.call_mut state.1 args.2
    let (acc, g) ← foldInst.call_mut state.2 (args.1, item)
    ok (acc, (f, g))
  let (acc, iter, f, g) ← iterInst.try_fold callback tryInst self.iter init (self.f, g)
  ok (acc, { iter, f }, g)

@[rust_fun
  "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::size_hint"]
def core.iter.adapters.map.IteratorMap.size_hint
  {B I F Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (_fnInst : core.ops.function.FnMut F Item B)
  (self : core.iter.adapters.map.Map I F) : Result (Usize × Option Usize) :=
  iterInst.size_hint self.iter
-- Rust's inherited count folds through Map::fold: it must call the mapper
-- on every item, rather than selecting the underlying iterator's count.
@[rust_fun
  "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::count"]
def core.iter.adapters.map.IteratorMap.count
  {B I F Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (fnInst : core.ops.function.FnMut F Item B)
  (self : core.iter.adapters.map.Map I F) :
  Result (Usize × core.iter.adapters.map.Map I F) :=
  core.iter.traits.iterator.countFromFold
    (core.iter.adapters.map.IteratorMap.fold iterInst fnInst) self

-- Rust's inherited any uses Map::try_fold. The matching mapped item is consumed,
-- and the remaining iterator, updated mapper, and updated predicate all survive.
@[rust_fun
  "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::any"]
def core.iter.adapters.map.IteratorMap.any
  {B I F G Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (fnInst : core.ops.function.FnMut F Item B)
  (predInst : core.ops.function.FnMut G B Bool)
  (self : core.iter.adapters.map.Map I F) (predicate : G) :
  Result (Bool × core.iter.adapters.map.Map I F × G) :=
  core.iter.traits.iterator.anyFromTryFold
    (core.iter.adapters.map.IteratorMap.try_fold iterInst fnInst) predInst self predicate

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>"]
def core.iter.traits.iterator.IteratorMap
  {B I F Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (fnInst : core.ops.function.FnMut F Item B) :
  core.iter.traits.iterator.Iterator (core.iter.adapters.map.Map I F) B := {
  next := core.iter.adapters.map.IteratorMap.next iterInst fnInst
  step_by := core.iter.adapters.map.IteratorMap.step_by iterInst fnInst
  enumerate := core.iter.adapters.map.IteratorMap.enumerate iterInst fnInst
  take := core.iter.adapters.map.IteratorMap.take iterInst fnInst
  count := core.iter.adapters.map.IteratorMap.count iterInst fnInst
  any := core.iter.adapters.map.IteratorMap.any iterInst fnInst
  fold := core.iter.adapters.map.IteratorMap.fold iterInst fnInst
  try_fold := core.iter.adapters.map.IteratorMap.try_fold iterInst fnInst
  size_hint := core.iter.adapters.map.IteratorMap.size_hint iterInst fnInst
  trusted_len := iterInst.trusted_len
  one_shot := iterInst.one_shot
  fused := iterInst.fused
  random_access := iterInst.random_access.map fun access => {
    is_full := access.is_full
    may_have_side_effect := true
    get_unchecked self n := do
      let (item, iter) ← access.get_unchecked self.iter n
      let (item, f) ← fnInst.call_mut self.f item
      ok (item, { iter, f })
  }
}

/-- `Map`'s inherited `Iterator::reduce` over the mapped items (`Map` overrides `fold`). -/
@[rust_fun
  "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::reduce"]
def core.iter.adapters.map.IteratorMap.reduce {B I F G Item : Type}
    (iterInst : core.iter.traits.iterator.Iterator I Item)
    (fnInst : core.ops.function.FnMut F Item B)
    (reduceInst : core.ops.function.FnMut G (B × B) B)
    (self : core.iter.adapters.map.Map I F) (g : G) :
    Result (Option B × core.iter.adapters.map.Map I F × G) :=
  core.iter.traits.iterator.Iterator.reduce.default
    (core.iter.traits.iterator.IteratorMap iterInst fnInst) reduceInst self g

/-- `Map`'s inherited `Iterator::sum`: `Sum::sum(self)` over the mapped items. -/
@[rust_fun
  "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::sum"]
def core.iter.adapters.map.IteratorMap.sum
  {B I F S Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (fnInst : core.ops.function.FnMut F Item B)
  (sumInst : core.iter.traits.accum.Sum S B)
  (self : core.iter.adapters.map.Map I F) : Result (S × core.iter.adapters.map.Map I F) :=
  sumInst.sum (core.iter.traits.iterator.IteratorMap iterInst fnInst) self

/-- `Map`'s inherited `Iterator::product`: `Product::product(self)` over the mapped items. -/
@[rust_fun
  "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::product"]
def core.iter.adapters.map.IteratorMap.product
  {B I F P Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (fnInst : core.ops.function.FnMut F Item B)
  (productInst : core.iter.traits.accum.Product P B)
  (self : core.iter.adapters.map.Map I F) : Result (P × core.iter.adapters.map.Map I F) :=
  productInst.product (core.iter.traits.iterator.IteratorMap iterInst fnInst) self

/-- `Map`'s inherited `Iterator::min` over the mapped items. -/
@[rust_fun
  "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::min"]
def core.iter.adapters.map.IteratorMap.min
  {B I F Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (fnInst : core.ops.function.FnMut F Item B) (ordInst : core.cmp.Ord B)
  (self : core.iter.adapters.map.Map I F) : Result (Option B × core.iter.adapters.map.Map I F) :=
  core.iter.traits.iterator.Iterator.min.default
    (core.iter.traits.iterator.IteratorMap iterInst fnInst) ordInst self

/-- `Map`'s inherited `Iterator::ne` against `other` (`!self.eq(other)`). -/
@[rust_fun
  "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::ne"]
def core.iter.adapters.map.IteratorMap.ne
  {B I F U UItem IntoIter Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (fnInst : core.ops.function.FnMut F Item B)
  (intoInst : core.iter.traits.collect.IntoIterator U UItem IntoIter)
  (eqInst : core.cmp.PartialEq B UItem) (self : core.iter.adapters.map.Map I F) (other : U) :
  Result (Bool × core.iter.adapters.map.Map I F × U) :=
  core.iter.traits.iterator.Iterator.ne.default
    (core.iter.traits.iterator.IteratorMap iterInst fnInst) intoInst eqInst self other

/-- `Map`'s inherited `Iterator::eq` against `other`. -/
@[rust_fun
  "core::iter::adapters::map::{core::iter::traits::iterator::Iterator<core::iter::adapters::map::Map<@I, @F>, @B>}::eq"]
def core.iter.adapters.map.IteratorMap.eq
  {B I F U UItem IntoIter Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (fnInst : core.ops.function.FnMut F Item B)
  (intoInst : core.iter.traits.collect.IntoIterator U UItem IntoIter)
  (eqInst : core.cmp.PartialEq B UItem) (self : core.iter.adapters.map.Map I F) (other : U) :
  Result (Bool × core.iter.adapters.map.Map I F × U) :=
  core.iter.traits.iterator.Iterator.eq.default
    (core.iter.traits.iterator.IteratorMap iterInst fnInst) intoInst eqInst self other

/-! `DoubleEndedIterator for Map<I, F>` (core map.rs, rustc 1.95), for
    `I: DoubleEndedIterator` and `F: FnMut(I::Item) -> B`: `next_back` is
    `self.iter.next_back().map(&mut self.f)`, and the back folds fold the inner
    iterator from the back with `g(acc, f(item))` (`map_fold`/`map_try_fold`).
    `nth_back`, `advance_back_by` and `rfind` are the trait's defaults. -/

@[rust_fun
  "core::iter::adapters::map::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::map::Map<@I, @F>, @B>}::next_back"]
def core.iter.adapters.map.DoubleEndedIteratorMap.next_back
  {B I F Item : Type} (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
  (fnInst : core.ops.function.FnMut F Item B)
  (self : core.iter.adapters.map.Map I F) :
  Result (Option B × core.iter.adapters.map.Map I F) := do
  let (item, iter) ← backInst.next_back self.iter
  match item with
  | none => ok (none, { self with iter })
  | some item =>
    let (item, f) ← fnInst.call_mut self.f item
    ok (some item, { iter, f })

@[rust_fun
  "core::iter::adapters::map::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::map::Map<@I, @F>, @B>}::rfold"]
def core.iter.adapters.map.DoubleEndedIteratorMap.rfold
  {B I F Acc G Item : Type}
  (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
  (fnInst : core.ops.function.FnMut F Item B)
  (foldInst : core.ops.function.FnMut G (Acc × B) Acc)
  (self : core.iter.adapters.map.Map I F) (init : Acc) (g : G) :
  Result (Acc × core.iter.adapters.map.Map I F × G) := do
  let callback := iteratorCallback fun (state : F × G) (args : Acc × Item) => do
    let (item, f) ← fnInst.call_mut state.1 args.2
    let (acc, g) ← foldInst.call_mut state.2 (args.1, item)
    ok (acc, (f, g))
  let (acc, iter, f, g) ← backInst.rfold callback self.iter init (self.f, g)
  ok (acc, { iter, f }, g)

@[rust_fun
  "core::iter::adapters::map::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::map::Map<@I, @F>, @B>}::try_rfold"]
def core.iter.adapters.map.DoubleEndedIteratorMap.try_rfold
  {B I F Acc G R Item Residual : Type}
  (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
  (fnInst : core.ops.function.FnMut F Item B)
  (foldInst : core.ops.function.FnMut G (Acc × B) R)
  (tryInst : core.ops.try_trait.Try R Acc Residual)
  (self : core.iter.adapters.map.Map I F) (init : Acc) (g : G) :
  Result (R × core.iter.adapters.map.Map I F × G) := do
  let callback := iteratorCallback fun (state : F × G) (args : Acc × Item) => do
    let (item, f) ← fnInst.call_mut state.1 args.2
    let (acc, g) ← foldInst.call_mut state.2 (args.1, item)
    ok (acc, (f, g))
  let (acc, iter, f, g) ← backInst.try_rfold callback tryInst self.iter init (self.f, g)
  ok (acc, { iter, f }, g)

@[reducible, rust_trait_impl
  "core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::map::Map<@I, @F>, @B>"]
def core.iter.traits.double_ended.DoubleEndedIteratorMap
  {B I F Item : Type} (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
  (fnInst : core.ops.function.FnMut F Item B) :
  core.iter.traits.double_ended.DoubleEndedIterator (core.iter.adapters.map.Map I F) B := {
  iteratorInst := core.iter.traits.iterator.IteratorMap backInst.iteratorInst fnInst
  next_back := core.iter.adapters.map.DoubleEndedIteratorMap.next_back backInst fnInst
  rfold := core.iter.adapters.map.DoubleEndedIteratorMap.rfold backInst fnInst
  try_rfold := core.iter.adapters.map.DoubleEndedIteratorMap.try_rfold backInst fnInst
}

@[rust_fun
  "core::iter::adapters::filter_map::{core::iter::traits::iterator::Iterator<core::iter::adapters::filter_map::FilterMap<@I, @F>, @B>}::next"]
def core.iter.adapters.filter_map.IteratorFilterMap.next
  {B I F Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (fnInst : core.ops.function.FnMut F Item (Option B))
  (self : core.iter.adapters.filter_map.FilterMap I F) :
  Result (Option B × core.iter.adapters.filter_map.FilterMap I F) := do
  let (item, iter, f) ← iterInst.find_map fnInst self.iter self.f
  ok (item, { iter, f })


@[rust_fun
  "core::iter::adapters::filter_map::{core::iter::traits::iterator::Iterator<core::iter::adapters::filter_map::FilterMap<@I, @F>, @B>}::fold"]
def core.iter.adapters.filter_map.IteratorFilterMap.fold
  {B I F Acc G Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (fnInst : core.ops.function.FnMut F Item (Option B))
  (foldInst : core.ops.function.FnMut G (Acc × B) Acc)
  (self : core.iter.adapters.filter_map.FilterMap I F) (init : Acc) (g : G) :
  Result (Acc × core.iter.adapters.filter_map.FilterMap I F × G) := do
  let callback := iteratorCallback fun (state : F × G) (args : Acc × Item) => do
    let (mapped, f) ← fnInst.call_mut state.1 args.2
    match mapped with
    | none => ok (args.1, (f, state.2))
    | some item => do
      let (acc, g) ← foldInst.call_mut state.2 (args.1, item)
      ok (acc, (f, g))
  let (acc, iter, f, g) ← iterInst.fold callback self.iter init (self.f, g)
  ok (acc, { iter, f := f }, g)

@[rust_fun
  "core::iter::adapters::filter_map::{core::iter::traits::iterator::Iterator<core::iter::adapters::filter_map::FilterMap<@I, @F>, @B>}::try_fold"]
def core.iter.adapters.filter_map.IteratorFilterMap.try_fold
  {B I F Acc G R Item Residual : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (fnInst : core.ops.function.FnMut F Item (Option B))
  (foldInst : core.ops.function.FnMut G (Acc × B) R)
  (tryInst : core.ops.try_trait.Try R Acc Residual)
  (self : core.iter.adapters.filter_map.FilterMap I F) (init : Acc) (g : G) :
  Result (R × core.iter.adapters.filter_map.FilterMap I F × G) := do
  let callback := iteratorCallback fun (state : F × G) (args : Acc × Item) => do
    let (mapped, f) ← fnInst.call_mut state.1 args.2
    match mapped with
    | none => do
      let result ← tryInst.from_output args.1
      ok (result, (f, state.2))
    | some item => do
      let (acc, g) ← foldInst.call_mut state.2 (args.1, item)
      ok (acc, (f, g))
  let (acc, iter, f, g) ← iterInst.try_fold callback tryInst self.iter init (self.f, g)
  ok (acc, { iter, f := f }, g)

@[rust_fun
  "core::iter::adapters::filter_map::{core::iter::traits::iterator::Iterator<core::iter::adapters::filter_map::FilterMap<@I, @F>, @B>}::size_hint"]
def core.iter.adapters.filter_map.IteratorFilterMap.size_hint
  {B I F Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (fnInst : core.ops.function.FnMut F Item (Option B))
  (self : core.iter.adapters.filter_map.FilterMap I F) : Result (Usize × Option Usize) := do
  let (_, upper) ← iterInst.size_hint self.iter
  ok (0#usize, upper)
@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::iter::adapters::filter_map::FilterMap<@I, @F>, @B>"]
def core.iter.traits.iterator.IteratorFilterMap
  {B I F Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (fnInst : core.ops.function.FnMut F Item (Option B)) :
  core.iter.traits.iterator.Iterator (core.iter.adapters.filter_map.FilterMap I F) B := {
  next := core.iter.adapters.filter_map.IteratorFilterMap.next iterInst fnInst
  fold := core.iter.adapters.filter_map.IteratorFilterMap.fold iterInst fnInst
  try_fold := core.iter.adapters.filter_map.IteratorFilterMap.try_fold iterInst fnInst
  size_hint := core.iter.adapters.filter_map.IteratorFilterMap.size_hint iterInst fnInst
  one_shot := iterInst.one_shot
  fused := iterInst.fused
}

/-- `FilterMap`'s inherited `Iterator::max` over the mapped items. -/
@[rust_fun
  "core::iter::adapters::filter_map::{core::iter::traits::iterator::Iterator<core::iter::adapters::filter_map::FilterMap<@I, @F>, @B>}::max"]
def core.iter.adapters.filter_map.IteratorFilterMap.max {B I F Item : Type}
    (iterInst : core.iter.traits.iterator.Iterator I Item)
    (fnInst : core.ops.function.FnMut F Item (Option B)) (ordInst : core.cmp.Ord B)
    (self : core.iter.adapters.filter_map.FilterMap I F) :
    Result (Option B × core.iter.adapters.filter_map.FilterMap I F) :=
  core.iter.traits.iterator.Iterator.max.default
    (core.iter.traits.iterator.IteratorFilterMap iterInst fnInst) ordInst self

/-- `FilterMap`'s inherited `Iterator::min` over the mapped items. -/
@[rust_fun
  "core::iter::adapters::filter_map::{core::iter::traits::iterator::Iterator<core::iter::adapters::filter_map::FilterMap<@I, @F>, @B>}::min"]
def core.iter.adapters.filter_map.IteratorFilterMap.min {B I F Item : Type}
    (iterInst : core.iter.traits.iterator.Iterator I Item)
    (fnInst : core.ops.function.FnMut F Item (Option B)) (ordInst : core.cmp.Ord B)
    (self : core.iter.adapters.filter_map.FilterMap I F) :
    Result (Option B × core.iter.adapters.filter_map.FilterMap I F) :=
  core.iter.traits.iterator.Iterator.min.default
    (core.iter.traits.iterator.IteratorFilterMap iterInst fnInst) ordInst self


@[rust_type "core::iter::adapters::copied::Copied"]
structure core.iter.adapters.copied.Copied (I : Type) where
  it : I

@[rust_type "core::iter::adapters::cloned::Cloned"]
structure core.iter.adapters.cloned.Cloned (I : Type) where
  it : I

-- The two Iterator bounds are distinct clauses in the Rust declaration:
-- Self: Iterator and Self: Iterator<Item = &'a T>, in that order around Copy/Clone.
@[rust_fun "core::iter::traits::iterator::Iterator::copied"]
def core.iter.traits.iterator.Iterator.copied.default
  {Self T : Type}
  (_iterInst : core.iter.traits.iterator.Iterator Self T)
  (_copyInst : core.marker.Copy T)
  (_refIterInst : core.iter.traits.iterator.Iterator Self T)
  (self : Self) : Result (core.iter.adapters.copied.Copied Self) :=
  ok ⟨self⟩

@[rust_fun "core::iter::traits::iterator::Iterator::cloned"]
def core.iter.traits.iterator.Iterator.cloned.default
  {Self T : Type}
  (_iterInst : core.iter.traits.iterator.Iterator Self T)
  (_cloneInst : core.clone.Clone T)
  (_refIterInst : core.iter.traits.iterator.Iterator Self T)
  (self : Self) : Result (core.iter.adapters.cloned.Cloned Self) :=
  ok ⟨self⟩

@[rust_fun
  "core::iter::adapters::copied::{core::iter::traits::iterator::Iterator<core::iter::adapters::copied::Copied<@I>, @T>}::next"]
def core.iter.adapters.copied.IteratorCopied.next
  {I T : Type} (iterInst : core.iter.traits.iterator.Iterator I T)
  (_copyInst : core.marker.Copy T) (self : core.iter.adapters.copied.Copied I) :
  Result (Option T × core.iter.adapters.copied.Copied I) := do
  let (item, it) ← iterInst.next self.it
  -- Copy is a value copy, not a call to its Clone supertrait dictionary.
  ok (item, ⟨it⟩)

-- Copied explicitly overrides count in Rust and delegates to the inner iterator.
-- Keep that dispatch, including an inner iterator's explicit count override.
@[rust_fun
  "core::iter::adapters::copied::{core::iter::traits::iterator::Iterator<core::iter::adapters::copied::Copied<@I>, @T>}::count"]
def core.iter.adapters.copied.IteratorCopied.count
  {I T : Type} (iterInst : core.iter.traits.iterator.Iterator I T)
  (_copyInst : core.marker.Copy T) (self : core.iter.adapters.copied.Copied I) :
  Result (Usize × core.iter.adapters.copied.Copied I) := do
  let (count, it) ← iterInst.count self.it
  ok (count, ⟨it⟩)

@[rust_fun
  "core::iter::adapters::cloned::{core::iter::traits::iterator::Iterator<core::iter::adapters::cloned::Cloned<@I>, @T>}::next"]
def core.iter.adapters.cloned.IteratorCloned.next
  {I T : Type} (iterInst : core.iter.traits.iterator.Iterator I T)
  (cloneInst : core.clone.Clone T) (self : core.iter.adapters.cloned.Cloned I) :
  Result (Option T × core.iter.adapters.cloned.Cloned I) := do
  let (item, it) ← iterInst.next self.it
  match item with
  | none => ok (none, ⟨it⟩)
  | some item =>
    let item ← cloneInst.clone item
    ok (some item, ⟨it⟩)


@[rust_fun
  "core::iter::adapters::copied::{core::iter::traits::iterator::Iterator<core::iter::adapters::copied::Copied<@I>, @T>}::fold"]
def core.iter.adapters.copied.IteratorCopied.fold
  {I T Acc F : Type} (iterInst : core.iter.traits.iterator.Iterator I T)
  (copyInst : core.marker.Copy T)
  (foldInst : core.ops.function.FnMut F (Acc × T) Acc)
  (self : core.iter.adapters.copied.Copied I) (init : Acc) (f : F) :
  Result (Acc × core.iter.adapters.copied.Copied I × F) := do
  let (acc, it, f) ← iterInst.fold foldInst self.it init f
  ok (acc, ⟨it⟩, f)

@[rust_fun
  "core::iter::adapters::copied::{core::iter::traits::iterator::Iterator<core::iter::adapters::copied::Copied<@I>, @T>}::try_fold"]
def core.iter.adapters.copied.IteratorCopied.try_fold
  {I T Acc F R Residual : Type} (iterInst : core.iter.traits.iterator.Iterator I T)
  (copyInst : core.marker.Copy T)
  (foldInst : core.ops.function.FnMut F (Acc × T) R)
  (tryInst : core.ops.try_trait.Try R Acc Residual)
  (self : core.iter.adapters.copied.Copied I) (init : Acc) (f : F) :
  Result (R × core.iter.adapters.copied.Copied I × F) := do
  let (acc, it, f) ← iterInst.try_fold foldInst tryInst self.it init f
  ok (acc, ⟨it⟩, f)

@[rust_fun
  "core::iter::adapters::copied::{core::iter::traits::iterator::Iterator<core::iter::adapters::copied::Copied<@I>, @T>}::size_hint"]
def core.iter.adapters.copied.IteratorCopied.size_hint
  {I T : Type} (iterInst : core.iter.traits.iterator.Iterator I T)
  (copyInst : core.marker.Copy T)
  (self : core.iter.adapters.copied.Copied I) : Result (Usize × Option Usize) :=
  iterInst.size_hint self.it

@[rust_fun
  "core::iter::adapters::copied::{core::iter::traits::iterator::Iterator<core::iter::adapters::copied::Copied<@I>, @T>}::nth"]
def core.iter.adapters.copied.IteratorCopied.nth
  {I T : Type} (iterInst : core.iter.traits.iterator.Iterator I T)
  (copyInst : core.marker.Copy T)
  (self : core.iter.adapters.copied.Copied I) (n : Usize) :
  Result (Option T × core.iter.adapters.copied.Copied I) := do
  let (result, it) ← iterInst.nth self.it n
  ok (result, ⟨it⟩)

@[rust_fun
  "core::iter::adapters::copied::{core::iter::traits::iterator::Iterator<core::iter::adapters::copied::Copied<@I>, @T>}::advance_by"]
def core.iter.adapters.copied.IteratorCopied.advance_by
  {I T : Type} (iterInst : core.iter.traits.iterator.Iterator I T)
  (copyInst : core.marker.Copy T)
  (self : core.iter.adapters.copied.Copied I) (n : Usize) :
  Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) × core.iter.adapters.copied.Copied I) := do
  let (result, it) ← iterInst.advance_by self.it n
  ok (result, ⟨it⟩)

@[rust_fun
  "core::iter::adapters::cloned::{core::iter::traits::iterator::Iterator<core::iter::adapters::cloned::Cloned<@I>, @T>}::fold"]
def core.iter.adapters.cloned.IteratorCloned.fold
  {I T Acc F : Type} (iterInst : core.iter.traits.iterator.Iterator I T)
  (cloneInst : core.clone.Clone T)
  (foldInst : core.ops.function.FnMut F (Acc × T) Acc)
  (self : core.iter.adapters.cloned.Cloned I) (init : Acc) (f : F) :
  Result (Acc × core.iter.adapters.cloned.Cloned I × F) := do
  let callback := iteratorCallback fun (f : F) (args : Acc × T) => do
    let item ← cloneInst.clone args.2
    foldInst.call_mut f (args.1, item)
  let (acc, it, f) ← iterInst.fold callback self.it init f
  ok (acc, ⟨it⟩, f)

@[rust_fun
  "core::iter::adapters::cloned::{core::iter::traits::iterator::Iterator<core::iter::adapters::cloned::Cloned<@I>, @T>}::try_fold"]
def core.iter.adapters.cloned.IteratorCloned.try_fold
  {I T Acc F R Residual : Type} (iterInst : core.iter.traits.iterator.Iterator I T)
  (cloneInst : core.clone.Clone T)
  (foldInst : core.ops.function.FnMut F (Acc × T) R)
  (tryInst : core.ops.try_trait.Try R Acc Residual)
  (self : core.iter.adapters.cloned.Cloned I) (init : Acc) (f : F) :
  Result (R × core.iter.adapters.cloned.Cloned I × F) := do
  let callback := iteratorCallback fun (f : F) (args : Acc × T) => do
    let item ← cloneInst.clone args.2
    foldInst.call_mut f (args.1, item)
  let (acc, it, f) ← iterInst.try_fold callback tryInst self.it init f
  ok (acc, ⟨it⟩, f)

@[rust_fun
  "core::iter::adapters::cloned::{core::iter::traits::iterator::Iterator<core::iter::adapters::cloned::Cloned<@I>, @T>}::size_hint"]
def core.iter.adapters.cloned.IteratorCloned.size_hint
  {I T : Type} (iterInst : core.iter.traits.iterator.Iterator I T)
  (cloneInst : core.clone.Clone T)
  (self : core.iter.adapters.cloned.Cloned I) : Result (Usize × Option Usize) :=
  iterInst.size_hint self.it
@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::iter::adapters::copied::Copied<@I>, @T>"]
def core.iter.traits.iterator.IteratorCopied
  {I T : Type} (iterInst : core.iter.traits.iterator.Iterator I T)
  (copyInst : core.marker.Copy T) :
  core.iter.traits.iterator.Iterator (core.iter.adapters.copied.Copied I) T := {
  next := core.iter.adapters.copied.IteratorCopied.next iterInst copyInst
  count := core.iter.adapters.copied.IteratorCopied.count iterInst copyInst
  fold := core.iter.adapters.copied.IteratorCopied.fold iterInst copyInst
  try_fold := core.iter.adapters.copied.IteratorCopied.try_fold iterInst copyInst
  size_hint := core.iter.adapters.copied.IteratorCopied.size_hint iterInst copyInst
  nth := core.iter.adapters.copied.IteratorCopied.nth iterInst copyInst
  advance_by := core.iter.adapters.copied.IteratorCopied.advance_by iterInst copyInst
  trusted_len := iterInst.trusted_len
  one_shot := iterInst.one_shot
  fused := iterInst.fused
  random_access := iterInst.random_access.map fun access => {
    is_full := access.is_full
    may_have_side_effect := access.may_have_side_effect
    get_unchecked self n := do
      let (item, it) ← access.get_unchecked self.it n
      ok (item, ⟨it⟩)
  }
}

/-- `Copied`'s inherited `Iterator::product`: `Product::product(self)` over the copied items. -/
@[rust_fun
  "core::iter::adapters::copied::{core::iter::traits::iterator::Iterator<core::iter::adapters::copied::Copied<@I>, @T>}::product"]
def core.iter.adapters.copied.IteratorCopied.product {I T P : Type}
    (iterInst : core.iter.traits.iterator.Iterator I T) (copyInst : core.marker.Copy T)
    (productInst : core.iter.traits.accum.Product P T)
    (self : core.iter.adapters.copied.Copied I) :
    Result (P × core.iter.adapters.copied.Copied I) :=
  productInst.product (core.iter.traits.iterator.IteratorCopied iterInst copyInst) self

/-- `Copied`'s inherited `Iterator::min_by_key` over the copied items. -/
@[rust_fun
  "core::iter::adapters::copied::{core::iter::traits::iterator::Iterator<core::iter::adapters::copied::Copied<@I>, @T>}::min_by_key"]
def core.iter.adapters.copied.IteratorCopied.min_by_key {I T B F : Type}
    (iterInst : core.iter.traits.iterator.Iterator I T) (copyInst : core.marker.Copy T)
    (ordInst : core.cmp.Ord B) (fnInst : core.ops.function.FnMut F T B)
    (self : core.iter.adapters.copied.Copied I) (f : F) :
    Result (Option T × core.iter.adapters.copied.Copied I × F) :=
  core.iter.traits.iterator.Iterator.min_by_key.default
    (core.iter.traits.iterator.IteratorCopied iterInst copyInst) ordInst fnInst self f

/-- `Copied`'s inherited `Iterator::eq` against `other`, over the copied items. -/
@[rust_fun
  "core::iter::adapters::copied::{core::iter::traits::iterator::Iterator<core::iter::adapters::copied::Copied<@I>, @T>}::eq"]
def core.iter.adapters.copied.IteratorCopied.eq {I T U UItem IntoIter : Type}
    (iterInst : core.iter.traits.iterator.Iterator I T) (copyInst : core.marker.Copy T)
    (intoInst : core.iter.traits.collect.IntoIterator U UItem IntoIter)
    (eqInst : core.cmp.PartialEq T UItem) (self : core.iter.adapters.copied.Copied I)
    (other : U) : Result (Bool × core.iter.adapters.copied.Copied I × U) :=
  core.iter.traits.iterator.Iterator.eq.default
    (core.iter.traits.iterator.IteratorCopied iterInst copyInst) intoInst eqInst self other

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::iter::adapters::cloned::Cloned<@I>, @T>"]
def core.iter.traits.iterator.IteratorCloned
  {I T : Type} (iterInst : core.iter.traits.iterator.Iterator I T)
  (cloneInst : core.clone.Clone T) :
  core.iter.traits.iterator.Iterator (core.iter.adapters.cloned.Cloned I) T := {
  next := core.iter.adapters.cloned.IteratorCloned.next iterInst cloneInst
  fold := core.iter.adapters.cloned.IteratorCloned.fold iterInst cloneInst
  try_fold := core.iter.adapters.cloned.IteratorCloned.try_fold iterInst cloneInst
  size_hint := core.iter.adapters.cloned.IteratorCloned.size_hint iterInst cloneInst
  trusted_len := iterInst.trusted_len
  one_shot := iterInst.one_shot
  fused := iterInst.fused
  random_access := iterInst.random_access.map fun access => {
    is_full := access.is_full
    may_have_side_effect := true
    get_unchecked self n := do
      let (item, it) ← access.get_unchecked self.it n
      let item ← cloneInst.clone item
      ok (item, ⟨it⟩)
  }
}

-- Both adapters use core.iter.traits.collect.IntoIterator.Blanket, preserving
-- these selected Iterator dictionaries and returning the complete adapter state.

@[rust_type "core::iter::adapters::filter::Filter"]
structure core.iter.adapters.filter.Filter (I P : Type) where
  iter : I
  predicate : P

@[rust_fun "core::iter::traits::iterator::Iterator::filter"]
def core.iter.traits.iterator.Iterator.filter.default
  {Self P Item : Type}
  (_iterInst : core.iter.traits.iterator.Iterator Self Item)
  (_predInst : core.ops.function.FnMut P Item Bool)
  (self : Self) (predicate : P) :
  Result (core.iter.adapters.filter.Filter Self P) :=
  ok ⟨self, predicate⟩

@[rust_fun
  "core::iter::adapters::filter::{core::iter::traits::iterator::Iterator<core::iter::adapters::filter::Filter<@I, @P>, @Clause0_Item>}::next"]
def core.iter.adapters.filter.IteratorFilter.next
  {I P Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (predInst : core.ops.function.FnMut P Item Bool)
  (self : core.iter.adapters.filter.Filter I P) :
  Result (Option Item × core.iter.adapters.filter.Filter I P) := do
  let (item, iter, predicate) ← iterInst.find predInst self.iter self.predicate
  ok (item, { iter, predicate })


@[rust_fun
  "core::iter::adapters::filter::{core::iter::traits::iterator::Iterator<core::iter::adapters::filter::Filter<@I, @P>, @Clause0_Item>}::fold"]
def core.iter.adapters.filter.IteratorFilter.fold
  {I P Acc G Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (predInst : core.ops.function.FnMut P Item Bool)
  (foldInst : core.ops.function.FnMut G (Acc × Item) Acc)
  (self : core.iter.adapters.filter.Filter I P) (init : Acc) (g : G) :
  Result (Acc × core.iter.adapters.filter.Filter I P × G) := do
  let callback := iteratorCallback fun (state : P × G) (args : Acc × Item) => do
    let (mapped, f) ← predInst.call_mut state.1 args.2
    if mapped then do
      let (acc, g) ← foldInst.call_mut state.2 args
      ok (acc, (f, g))
    else ok (args.1, (f, state.2))
  let (acc, iter, f, g) ← iterInst.fold callback self.iter init (self.predicate, g)
  ok (acc, { iter, predicate := f }, g)

@[rust_fun
  "core::iter::adapters::filter::{core::iter::traits::iterator::Iterator<core::iter::adapters::filter::Filter<@I, @P>, @Clause0_Item>}::try_fold"]
def core.iter.adapters.filter.IteratorFilter.try_fold
  {I P Acc G R Item Residual : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (predInst : core.ops.function.FnMut P Item Bool)
  (foldInst : core.ops.function.FnMut G (Acc × Item) R)
  (tryInst : core.ops.try_trait.Try R Acc Residual)
  (self : core.iter.adapters.filter.Filter I P) (init : Acc) (g : G) :
  Result (R × core.iter.adapters.filter.Filter I P × G) := do
  let callback := iteratorCallback fun (state : P × G) (args : Acc × Item) => do
    let (mapped, f) ← predInst.call_mut state.1 args.2
    if mapped then do
      let (acc, g) ← foldInst.call_mut state.2 args
      ok (acc, (f, g))
    else do
      let result ← tryInst.from_output args.1
      ok (result, (f, state.2))
  let (acc, iter, f, g) ← iterInst.try_fold callback tryInst self.iter init (self.predicate, g)
  ok (acc, { iter, predicate := f }, g)

@[rust_fun
  "core::iter::adapters::filter::{core::iter::traits::iterator::Iterator<core::iter::adapters::filter::Filter<@I, @P>, @Clause0_Item>}::size_hint"]
def core.iter.adapters.filter.IteratorFilter.size_hint
  {I P Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (predInst : core.ops.function.FnMut P Item Bool)
  (self : core.iter.adapters.filter.Filter I P) : Result (Usize × Option Usize) := do
  let (_, upper) ← iterInst.size_hint self.iter
  ok (0#usize, upper)
-- Filter::count observes the upper bound before folding the predicate.
@[rust_fun
  "core::iter::adapters::filter::{core::iter::traits::iterator::Iterator<core::iter::adapters::filter::Filter<@I, @P>, @Clause0_Item>}::count"]
def core.iter.adapters.filter.IteratorFilter.count
  {I P Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (predInst : core.ops.function.FnMut P Item Bool)
  (self : core.iter.adapters.filter.Filter I P) :
  Result (Usize × core.iter.adapters.filter.Filter I P) := do
  let _ ← iterInst.size_hint self.iter
  core.iter.traits.iterator.countFromFold
    (core.iter.adapters.filter.IteratorFilter.fold iterInst predInst) self

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::iter::adapters::filter::Filter<@I, @P>, @Clause0_Item>"]
def core.iter.traits.iterator.IteratorFilter
  {I P Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (predInst : core.ops.function.FnMut P Item Bool) :
  core.iter.traits.iterator.Iterator (core.iter.adapters.filter.Filter I P) Item := {
  next := core.iter.adapters.filter.IteratorFilter.next iterInst predInst
  count := core.iter.adapters.filter.IteratorFilter.count iterInst predInst
  fold := core.iter.adapters.filter.IteratorFilter.fold iterInst predInst
  try_fold := core.iter.adapters.filter.IteratorFilter.try_fold iterInst predInst
  size_hint := core.iter.adapters.filter.IteratorFilter.size_hint iterInst predInst
  one_shot := iterInst.one_shot
  fused := iterInst.fused
}

/-- `Filter`'s inherited `Iterator::min_by_key` over the kept items. -/
@[rust_fun
  "core::iter::adapters::filter::{core::iter::traits::iterator::Iterator<core::iter::adapters::filter::Filter<@I, @P>, @Clause0_Item>}::min_by_key"]
def core.iter.adapters.filter.IteratorFilter.min_by_key {I P Item B F : Type}
    (iterInst : core.iter.traits.iterator.Iterator I Item)
    (predInst : core.ops.function.FnMut P Item Bool)
    (ordInst : core.cmp.Ord B) (fnInst : core.ops.function.FnMut F Item B)
    (self : core.iter.adapters.filter.Filter I P) (f : F) :
    Result (Option Item × core.iter.adapters.filter.Filter I P × F) :=
  core.iter.traits.iterator.Iterator.min_by_key.default
    (core.iter.traits.iterator.IteratorFilter iterInst predInst) ordInst fnInst self f

/-! `DoubleEndedIterator for Filter<I, P>` (core filter.rs, rustc 1.95), for
    `I: DoubleEndedIterator` and `P: FnMut(&I::Item) -> bool`: `next_back` is
    `self.iter.rfind(&mut self.predicate)` (the inner iterator's own rfind), and
    the back folds fold the inner iterator from the back, passing on only the
    items the predicate accepts (`filter_fold`/`filter_try_fold`). `nth_back`,
    `advance_back_by` and `rfind` are the trait's defaults. -/

@[rust_fun
  "core::iter::adapters::filter::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::filter::Filter<@I, @P>, @Clause0_Clause0_Item>}::next_back"]
def core.iter.adapters.filter.DoubleEndedIteratorFilter.next_back
  {I P Item : Type} (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
  (predInst : core.ops.function.FnMut P Item Bool)
  (self : core.iter.adapters.filter.Filter I P) :
  Result (Option Item × core.iter.adapters.filter.Filter I P) := do
  let (item, iter, predicate) ← backInst.rfind predInst self.iter self.predicate
  ok (item, { iter, predicate })

@[rust_fun
  "core::iter::adapters::filter::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::filter::Filter<@I, @P>, @Clause0_Clause0_Item>}::rfold"]
def core.iter.adapters.filter.DoubleEndedIteratorFilter.rfold
  {I P Acc G Item : Type} (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
  (predInst : core.ops.function.FnMut P Item Bool)
  (foldInst : core.ops.function.FnMut G (Acc × Item) Acc)
  (self : core.iter.adapters.filter.Filter I P) (init : Acc) (g : G) :
  Result (Acc × core.iter.adapters.filter.Filter I P × G) := do
  let callback := iteratorCallback fun (state : P × G) (args : Acc × Item) => do
    let (keep, f) ← predInst.call_mut state.1 args.2
    if keep then do
      let (acc, g) ← foldInst.call_mut state.2 args
      ok (acc, (f, g))
    else ok (args.1, (f, state.2))
  let (acc, iter, f, g) ← backInst.rfold callback self.iter init (self.predicate, g)
  ok (acc, { iter, predicate := f }, g)

@[rust_fun
  "core::iter::adapters::filter::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::filter::Filter<@I, @P>, @Clause0_Clause0_Item>}::try_rfold"]
def core.iter.adapters.filter.DoubleEndedIteratorFilter.try_rfold
  {I P Acc G R Item Residual : Type}
  (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
  (predInst : core.ops.function.FnMut P Item Bool)
  (foldInst : core.ops.function.FnMut G (Acc × Item) R)
  (tryInst : core.ops.try_trait.Try R Acc Residual)
  (self : core.iter.adapters.filter.Filter I P) (init : Acc) (g : G) :
  Result (R × core.iter.adapters.filter.Filter I P × G) := do
  let callback := iteratorCallback fun (state : P × G) (args : Acc × Item) => do
    let (keep, f) ← predInst.call_mut state.1 args.2
    if keep then do
      let (acc, g) ← foldInst.call_mut state.2 args
      ok (acc, (f, g))
    else do
      let result ← tryInst.from_output args.1
      ok (result, (f, state.2))
  let (acc, iter, f, g) ← backInst.try_rfold callback tryInst self.iter init (self.predicate, g)
  ok (acc, { iter, predicate := f }, g)

@[reducible, rust_trait_impl
  "core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::filter::Filter<@I, @P>, @Clause0_Clause0_Item>"]
def core.iter.traits.double_ended.DoubleEndedIteratorFilter
  {I P Item : Type} (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
  (predInst : core.ops.function.FnMut P Item Bool) :
  core.iter.traits.double_ended.DoubleEndedIterator (core.iter.adapters.filter.Filter I P) Item := {
  iteratorInst := core.iter.traits.iterator.IteratorFilter backInst.iteratorInst predInst
  next_back := core.iter.adapters.filter.DoubleEndedIteratorFilter.next_back backInst predInst
  rfold := core.iter.adapters.filter.DoubleEndedIteratorFilter.rfold backInst predInst
  try_rfold := core.iter.adapters.filter.DoubleEndedIteratorFilter.try_rfold backInst predInst
}

/-! `SkipWhile<I, P> { iter, flag, predicate }` (core/src/iter/adapters/skip_while.rs, rustc
    1.95): `Iterator::skip_while` is `SkipWhile::new(self, predicate)` with `flag = false`.
    `next` is `self.iter.find(check(&mut self.flag, &mut self.predicate))` through the inner
    iterator's own `find`, where `check(x) = if *flag || !pred(x) { *flag = true; true } else
    { false }` (the predicate is not called once the flag is set); `size_hint` is
    `(0, upper)` of the inner iterator; `fold` and `try_fold` take the first item with `next`
    while the flag is unset (returning the initial value if there is none), then fold the inner
    iterator. `SkipWhile` is `FusedIterator` when the inner iterator is, never `TrustedLen`. -/

@[rust_type "core::iter::adapters::skip_while::SkipWhile"]
structure core.iter.adapters.skip_while.SkipWhile (I P : Type) where
  iter : I
  flag : Bool
  predicate : P

@[rust_fun "core::iter::traits::iterator::Iterator::skip_while"]
def core.iter.traits.iterator.Iterator.skip_while.default
  {Self P Item : Type}
  (_iterInst : core.iter.traits.iterator.Iterator Self Item)
  (_predInst : core.ops.function.FnMut P Item Bool)
  (self : Self) (predicate : P) :
  Result (core.iter.adapters.skip_while.SkipWhile Self P) :=
  ok { iter := self, flag := false, predicate }

/-- `Copied`'s inherited `Iterator::skip_while`: `SkipWhile::new(self, predicate)`. -/
@[rust_fun
  "core::iter::adapters::copied::{core::iter::traits::iterator::Iterator<core::iter::adapters::copied::Copied<@I>, @T>}::skip_while"]
def core.iter.adapters.copied.IteratorCopied.skip_while {I T P : Type}
    (_iterInst : core.iter.traits.iterator.Iterator I T) (_copyInst : core.marker.Copy T)
    (_predInst : core.ops.function.FnMut P T Bool) (self : core.iter.adapters.copied.Copied I)
    (predicate : P) :
    Result (core.iter.adapters.skip_while.SkipWhile (core.iter.adapters.copied.Copied I) P) :=
  ok { iter := self, flag := false, predicate }

@[rust_fun
  "core::iter::adapters::skip_while::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip_while::SkipWhile<@I, @P>, @Clause0_Item>}::next"]
def core.iter.adapters.skip_while.IteratorSkipWhile.next
  {I P Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (predInst : core.ops.function.FnMut P Item Bool)
  (self : core.iter.adapters.skip_while.SkipWhile I P) :
  Result (Option Item × core.iter.adapters.skip_while.SkipWhile I P) := do
  let check := iteratorCallback fun (state : Bool × P) (x : Item) => do
    if state.1 then ok (true, state)
    else
      let (skip, predicate) ← predInst.call_mut state.2 x
      if skip then ok (false, (false, predicate)) else ok (true, (true, predicate))
  let (item, iter, flag, predicate) ← iterInst.find check self.iter (self.flag, self.predicate)
  ok (item, { iter, flag, predicate })

@[rust_fun
  "core::iter::adapters::skip_while::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip_while::SkipWhile<@I, @P>, @Clause0_Item>}::size_hint"]
def core.iter.adapters.skip_while.IteratorSkipWhile.size_hint
  {I P Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (_predInst : core.ops.function.FnMut P Item Bool)
  (self : core.iter.adapters.skip_while.SkipWhile I P) : Result (Usize × Option Usize) := do
  let (_, upper) ← iterInst.size_hint self.iter
  ok (0#usize, upper)

@[rust_fun
  "core::iter::adapters::skip_while::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip_while::SkipWhile<@I, @P>, @Clause0_Item>}::fold"]
def core.iter.adapters.skip_while.IteratorSkipWhile.fold
  {I P Acc G Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (predInst : core.ops.function.FnMut P Item Bool)
  (foldInst : core.ops.function.FnMut G (Acc × Item) Acc)
  (self : core.iter.adapters.skip_while.SkipWhile I P) (init : Acc) (g : G) :
  Result (Acc × core.iter.adapters.skip_while.SkipWhile I P × G) := do
  if self.flag then
    let (acc, iter, g) ← iterInst.fold foldInst self.iter init g
    ok (acc, { self with iter }, g)
  else
    let (item, self) ← core.iter.adapters.skip_while.IteratorSkipWhile.next iterInst predInst self
    match item with
    | none => ok (init, self, g)
    | some v =>
      let (init, g) ← foldInst.call_mut g (init, v)
      let (acc, iter, g) ← iterInst.fold foldInst self.iter init g
      ok (acc, { self with iter }, g)

@[rust_fun
  "core::iter::adapters::skip_while::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip_while::SkipWhile<@I, @P>, @Clause0_Item>}::try_fold"]
def core.iter.adapters.skip_while.IteratorSkipWhile.try_fold
  {I P Acc G R Item Residual : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (predInst : core.ops.function.FnMut P Item Bool)
  (foldInst : core.ops.function.FnMut G (Acc × Item) R)
  (tryInst : core.ops.try_trait.Try R Acc Residual)
  (self : core.iter.adapters.skip_while.SkipWhile I P) (init : Acc) (g : G) :
  Result (R × core.iter.adapters.skip_while.SkipWhile I P × G) := do
  if self.flag then
    let (r, iter, g) ← iterInst.try_fold foldInst tryInst self.iter init g
    ok (r, { self with iter }, g)
  else
    let (item, self) ← core.iter.adapters.skip_while.IteratorSkipWhile.next iterInst predInst self
    match item with
    | none => ok (← tryInst.from_output init, self, g)
    | some v =>
      let (r, g) ← foldInst.call_mut g (init, v)
      match ← tryInst.branch r with
      | .Break residual => ok (← tryInst.FromResidualInst.from_residual residual, self, g)
      | .Continue init =>
        let (r, iter, g) ← iterInst.try_fold foldInst tryInst self.iter init g
        ok (r, { self with iter }, g)

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::iter::adapters::skip_while::SkipWhile<@I, @P>, @Clause0_Item>"]
def core.iter.traits.iterator.IteratorSkipWhile
  {I P Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (predInst : core.ops.function.FnMut P Item Bool) :
  core.iter.traits.iterator.Iterator (core.iter.adapters.skip_while.SkipWhile I P) Item := {
  next := core.iter.adapters.skip_while.IteratorSkipWhile.next iterInst predInst
  size_hint := core.iter.adapters.skip_while.IteratorSkipWhile.size_hint iterInst predInst
  fold := core.iter.adapters.skip_while.IteratorSkipWhile.fold iterInst predInst
  try_fold := core.iter.adapters.skip_while.IteratorSkipWhile.try_fold iterInst predInst
  fused := iterInst.fused
}

end Aeneas.Std
