import Aeneas.Std.Scalar.Core
import Aeneas.Std.Core.Cmp
import Aeneas.Std.Core.Core
import Batteries.Data.Nat.Basic

namespace Aeneas.Std

/-- The four IEEE interchange formats used by scalar finalization. -/
inductive BinaryFormat where
  | binary16 | bfloat16 | binary32 | binary64
  deriving DecidableEq, Repr

namespace BinaryFormat

def fractionBits : BinaryFormat → Nat
  | .binary16 => 10 | .bfloat16 => 7 | .binary32 => 23 | .binary64 => 52

def exponentBits : BinaryFormat → Nat
  | .binary16 => 5 | .bfloat16 => 8 | .binary32 => 8 | .binary64 => 11

def width (f : BinaryFormat) : Nat := 1 + f.exponentBits + f.fractionBits
def bias (f : BinaryFormat) : Nat := 2 ^ (f.exponentBits - 1) - 1
def maxExponent (f : BinaryFormat) : Nat := 2 ^ f.exponentBits - 1

end BinaryFormat

/-- A bit carrier, not Lean's opaque native Float. All definitions below reduce in
    the kernel. In particular, constructing a signaling NaN does not quiet it. -/
structure BinaryFloat (format : BinaryFormat) where
  bits : BitVec format.width
  deriving DecidableEq, Repr

abbrev F32 := BinaryFloat .binary32
abbrev F64 := BinaryFloat .binary64
@[rust_type "half::binary16::f16"]
abbrev F16 := BinaryFloat .binary16
@[rust_type "half::bfloat::bf16"]
abbrev BF16 := BinaryFloat .bfloat16

namespace BinaryFloat

def ofNat (f : BinaryFormat) (bits : Nat) : BinaryFloat f :=
  ⟨BitVec.ofNat f.width bits⟩

def magnitude {f} (x : BinaryFloat f) : Nat :=
  x.bits.toNat % 2 ^ (f.width - 1)

def sign {f} (x : BinaryFloat f) : Bool :=
  decide (x.bits.toNat ≥ 2 ^ (f.width - 1))

def exponent {f} (x : BinaryFloat f) : Nat := x.magnitude / 2 ^ f.fractionBits
def fraction {f} (x : BinaryFloat f) : Nat := x.magnitude % 2 ^ f.fractionBits
def isNaN {f} (x : BinaryFloat f) : Bool :=
  x.exponent == f.maxExponent && x.fraction != 0

def isInfinite {f} (x : BinaryFloat f) : Bool :=
  x.exponent == f.maxExponent && x.fraction == 0

def isFinite {f} (x : BinaryFloat f) : Bool := x.exponent != f.maxExponent
def isZero {f} (x : BinaryFloat f) : Bool := x.magnitude == 0

def pack (f : BinaryFormat) (negative : Bool) (e m : Nat) : BinaryFloat f :=
  ofNat f ((if negative then 2 ^ (f.width - 1) else 0) + e * 2 ^ f.fractionBits + m)

def zero (f : BinaryFormat) (negative : Bool) : BinaryFloat f := pack f negative 0 0
def infinity (f : BinaryFormat) (negative : Bool) : BinaryFloat f :=
  pack f negative f.maxExponent 0

/-- Arithmetic chooses the positive canonical quiet NaN (the preferred quiet
    payload). Rust permits this choice; this is not a claim that NaN arithmetic
    has the same bits on every Rust target. Bit conversions, negation and abs
    instead preserve every payload bit. Width casts choose the same preferred
    quiet payload, preserving the source sign. -/
def nan (f : BinaryFormat) (negative : Bool := false) : BinaryFloat f :=
  pack f negative f.maxExponent (2 ^ (f.fractionBits - 1))

def neg {f} (x : BinaryFloat f) : BinaryFloat f :=
  ofNat f ((if x.sign then 0 else 2 ^ (f.width - 1)) + x.magnitude)

def abs {f} (x : BinaryFloat f) : BinaryFloat f := ofNat f x.magnitude

/-- Unsigned exact rational value of a finite encoding. Callers classify special
    encodings first. The denominator is always a positive power of two. -/
def ratio {f} (x : BinaryFloat f) : Nat × Nat :=
  let m := if x.exponent == 0 then x.fraction else 2 ^ f.fractionBits + x.fraction
  let e : Int := ((max 1 x.exponent : Nat) : Int) - (f.bias : Int) - (f.fractionBits : Int)
  if e ≥ 0 then (m * 2 ^ e.toNat, 1) else (m, 2 ^ (-e).toNat)

/-- Round a nonnegative rational to the nearest integer, breaking ties to even. -/
def roundQuotient (n d : Nat) : Nat :=
  let q := n / d
  let r := n % d
  q + if 2 * r > d || (2 * r == d && q % 2 == 1) then 1 else 0

/-- Floor(log2(n/d)) for positive numerator and denominator. The difference of
    the integer logarithms is either the answer or one above it. -/
def ratioExponent (n d : Nat) : Int :=
  let e : Int := (n.log2 : Int) - (d.log2 : Int)
  let below := if e ≥ 0 then n < d * 2 ^ e.toNat else n * 2 ^ (-e).toNat < d
  if below then e - 1 else e

/-- One rounding, including gradual underflow, the subnormal/normal carry, and
    the largest-finite/infinity carry. A zero denominator has the ordinary IEEE
    division interpretation, so this helper is total even outside finite paths. -/
def round (f : BinaryFormat) (negative : Bool) (n d : Nat) : BinaryFloat f :=
  if d == 0 then if n == 0 then nan f else infinity f negative
  else if n == 0 then zero f negative
  else
    let p : Int := f.fractionBits
    let unit := max (1 - (f.bias : Int) - p) (ratioExponent n d - p)
    let q := if unit ≥ 0 then roundQuotient n (d * 2 ^ unit.toNat)
             else roundQuotient (n * 2 ^ (-unit).toNat) d
    let carry := q ≥ 2 ^ (f.fractionBits + 1)
    let q := if carry then q / 2 else q
    let unit := if carry then unit + 1 else unit
    let e := if q < 2 ^ f.fractionBits then 0 else (unit + p + f.bias).toNat
    if e ≥ f.maxExponent then infinity f negative
    else pack f negative e (if e == 0 then q else q - 2 ^ f.fractionBits)

def ofInt (f : BinaryFormat) (x : Int) : BinaryFloat f := round f (x < 0) x.natAbs 1

def cast {f} (g : BinaryFormat) (x : BinaryFloat f) : BinaryFloat g :=
  if x.isNaN then nan g x.sign
  else if x.isInfinite then infinity g x.sign
  else let (n, d) := x.ratio; round g x.sign n d

/-- IEEE equality is not structural equality: both zeros compare equal and no
    NaN compares equal even to itself. -/
def eq {f} (x y : BinaryFloat f) : Bool :=
  !x.isNaN && !y.isNaN && ((x.isZero && y.isZero) || x.bits == y.bits)

def lt {f} (x y : BinaryFloat f) : Bool :=
  if x.isNaN || y.isNaN || (x.isZero && y.isZero) then false
  else if x.sign != y.sign then x.sign
  else if x.sign then y.magnitude < x.magnitude else x.magnitude < y.magnitude

def le {f} (x y : BinaryFloat f) : Bool := eq x y || lt x y

def partialCmp {f} (x y : BinaryFloat f) : Option Ordering :=
  if x.isNaN || y.isNaN then none
  else if eq x y then some .eq else if lt x y then some .lt else some .gt

def add {f} (x y : BinaryFloat f) : BinaryFloat f :=
  if x.isNaN || y.isNaN then nan f
  else if x.isInfinite then
    if y.isInfinite && x.sign != y.sign then nan f else x
  else if y.isInfinite then y
  else
    let (xn, xd) := x.ratio
    let (yn, yd) := y.ratio
    let a : Int := if x.sign then -(xn : Int) else xn
    let b : Int := if y.sign then -(yn : Int) else yn
    let n := a * yd + b * xd
    -- Exact cancellation rounds to +0, except -0 + -0.
    let negative := if n == 0 then x.sign && y.sign else n < 0
    round f negative n.natAbs (xd * yd)

def sub {f} (x y : BinaryFloat f) : BinaryFloat f := add x (neg y)

def mul {f} (x y : BinaryFloat f) : BinaryFloat f :=
  let negative := x.sign != y.sign
  if x.isNaN || y.isNaN then nan f
  else if (x.isInfinite && y.isZero) || (y.isInfinite && x.isZero) then nan f
  else if x.isInfinite || y.isInfinite then infinity f negative
  else
    let (xn, xd) := x.ratio
    let (yn, yd) := y.ratio
    round f negative (xn * yn) (xd * yd)

def div {f} (x y : BinaryFloat f) : BinaryFloat f :=
  let negative := x.sign != y.sign
  if x.isNaN || y.isNaN then nan f
  else if (x.isInfinite && y.isInfinite) || (x.isZero && y.isZero) then nan f
  else if x.isInfinite || y.isZero then infinity f negative
  else if y.isInfinite then zero f negative
  else
    let (xn, xd) := x.ratio
    let (yn, yd) := y.ratio
    round f negative (xn * yd) (xd * yn)

/-- Rust remainder uses a quotient truncated toward zero, not IEEE's
    nearest-integer remainder. Compute that quotient before target rounding. -/
def rem {f} (x y : BinaryFloat f) : BinaryFloat f :=
  if x.isNaN || y.isNaN || x.isInfinite || y.isZero then nan f
  else if y.isInfinite then x
  else
    let (xn, xd) := x.ratio
    let (yn, yd) := y.ratio
    round f x.sign ((xn * yd) % (yn * xd)) (xd * yd)

def trunc {f} (x : BinaryFloat f) : BinaryFloat f :=
  if x.isNaN then nan f
  else if x.isInfinite then x
  else let (n, d) := x.ratio; round f x.sign (n / d) 1

def fract {f} (x : BinaryFloat f) : BinaryFloat f := sub x (trunc x)

/-- Round toward negative infinity; the result keeps the sign of `x` (so
    `floor (-0.0) = -0.0` and `floor (-0.5) = -1.0`). -/
def floor {f} (x : BinaryFloat f) : BinaryFloat f :=
  if x.isNaN then nan f
  else if x.isInfinite then x
  else
    let (n, d) := x.ratio
    round f x.sign (if x.sign then (n + d - 1) / d else n / d) 1

/-- Round toward positive infinity; the result keeps the sign of `x` (so
    `ceil (-0.5) = -0.0`). IEEE `roundToIntegralTowardPositive`, exact. -/
def ceil {f} (x : BinaryFloat f) : BinaryFloat f :=
  if x.isNaN then nan f
  else if x.isInfinite then x
  else
    let (n, d) := x.ratio
    round f x.sign (if x.sign then n / d else (n + d - 1) / d) 1

/-- Round to the nearest integer, ties to even; the result keeps the sign of `x`
    (`roundTiesEven (-0.5) = -0.0`). IEEE `roundToIntegralTiesToEven`, exact. -/
def roundTiesEven {f} (x : BinaryFloat f) : BinaryFloat f :=
  if x.isNaN then nan f
  else if x.isInfinite then x
  else let (n, d) := x.ratio; round f x.sign (roundQuotient n d) 1

/-- IEEE `squareRoot`, correctly rounded: `√-0 = -0`, `√+∞ = +∞`, and a NaN for
    every other negative operand. For a positive finite `n / 2^k` (`k` made even)
    the root is `√(n·4^t) / 2^(t + k/2)`. With `t = fractionBits + 3`, the integer
    root `s = ⌊√(n·4^t)⌋` has at least `fractionBits + 4` bits, so every rounding
    boundary is an integer multiple of the root's scale: when the root is not an
    integer, it and `s + 1/2` lie strictly between the same two integers and round
    identically (the usual sticky bit). -/
def sqrt {f} (x : BinaryFloat f) : BinaryFloat f :=
  if x.isNaN then nan f
  else if x.isZero then x
  else if x.sign then nan f
  else if x.isInfinite then x
  else
    let (n, d) := x.ratio
    let k := d.log2
    let (n, k) := if k % 2 == 1 then (2 * n, k + 1) else (n, k)
    let t := f.fractionBits + 3
    let m := n * 4 ^ t
    let s := m.sqrt
    round f false (2 * s + (if s * s == m then 0 else 1)) (2 ^ (t + k / 2 + 1))

/-- IEEE `fusedMultiplyAdd`: `x * y + z` with a single rounding. An exact zero
    sum is `-0` only when the product and `z` are both negative zeros; exact
    cancellation of nonzero terms gives `+0`, as for `add`. -/
def mulAdd {f} (x y z : BinaryFloat f) : BinaryFloat f :=
  let productSign := x.sign != y.sign
  if x.isNaN || y.isNaN || z.isNaN then nan f
  else if (x.isInfinite && y.isZero) || (y.isInfinite && x.isZero) then nan f
  else if x.isInfinite || y.isInfinite then
    if z.isInfinite && z.sign != productSign then nan f else infinity f productSign
  else if z.isInfinite then z
  else
    let (xn, xd) := x.ratio
    let (yn, yd) := y.ratio
    let (zn, zd) := z.ratio
    let p : Int := if productSign then -((xn * yn : Nat) : Int) else ((xn * yn : Nat) : Int)
    let c : Int := if z.sign then -(zn : Int) else zn
    let n := p * zd + c * (xd * yd)
    let negative := if n == 0 then productSign && z.sign else n < 0
    round f negative n.natAbs (xd * yd * zd)

/-- A NaN whose quiet bit (the fraction's top bit) is clear. -/
def isSignalingNaN {f} (x : BinaryFloat f) : Bool :=
  x.isNaN && x.fraction < 2 ^ (f.fractionBits - 1)

/-- The same encoding with the quiet bit set (payload and sign kept). -/
def quiet {f} (x : BinaryFloat f) : BinaryFloat f :=
  ofNat f (x.bits.toNat ||| 2 ^ (f.fractionBits - 1))

/-- `f32/f64::max` (`isMax`) and `min` as executed on aarch64: rustc lowers them to
    LLVM `maxnum`/`minnum`, which the AArch64 backend selects as `FMAXNM`/`FMINNM`.
    Rust itself leaves the sign of a zero result unspecified (`max(-0.0, +0.0)` may
    be either zero) and NaN payloads nondeterministic; this is the Arm ARM
    `FPMaxNum`/`FPMinNum` with the default FPCR.DN = 0, bit for bit:
    - `-0 < +0`;
    - a quiet NaN operand yields the other operand (both quiet NaNs: the first);
    - a signaling NaN operand yields that NaN quieted (the first if both are), even
      against a number.
    This is a platform assumption (verification/trusted_base.json
    "platform_assumptions"): x86-64 lowers `maxnum` differently. -/
def maxNum {f} (isMax : Bool) (x y : BinaryFloat f) : BinaryFloat f :=
  if x.isSignalingNaN then x.quiet
  else if y.isSignalingNaN then y.quiet
  else if x.isNaN then (if y.isNaN then x else y)
  else if y.isNaN then x
  else
    let yAbove := lt x y || (x.isZero && y.isZero && x.sign && !y.sign)
    if isMax then (if yAbove then y else x) else (if yAbove then x else y)

/-- Binary exponentiation with an IEEE rounding at each multiplication. The
    accumulator follows compiler-rt's low-bit-first evaluation order. Rust does
    not specify powi's rounding order; this fixes that implementation choice.
    Intermediate values stay bounded even for the largest i32 exponent. -/
def powNat {f} (x : BinaryFloat f) (n : Nat) (acc : BinaryFloat f) : BinaryFloat f :=
  if h : n = 0 then acc
  else
    let acc := if n % 2 == 1 then mul acc x else acc
    if n / 2 == 0 then acc else powNat (mul x x) (n / 2) acc
termination_by n
decreasing_by exact Nat.div_lt_self (Nat.pos_of_ne_zero h) (by decide)

def powi {f} (x : BinaryFloat f) (power : Int) : BinaryFloat f :=
  let value := powNat x power.natAbs (ofInt f 1)
  if power < 0 then div (ofInt f 1) value else value

/-- Rust's float-to-integer cast: truncate toward zero, saturate at bounds,
    and map every NaN to zero. Bounds are mathematical integers. -/
def saturatingInt {f} (x : BinaryFloat f) (lo hi : Int) : Int :=
  if x.isNaN then 0
  else if x.isInfinite then if x.sign then lo else hi
  else
    let (n, d) := x.ratio
    let q : Int := n / d
    max lo (min hi (if x.sign then -q else q))

def toIScalar {f} (ty : IScalarTy) (x : BinaryFloat f) : IScalar ty :=
  let bound : Int := 2 ^ (ty.numBits - 1)
  ⟨BitVec.ofInt ty.numBits (saturatingInt x (-bound) (bound - 1))⟩

def toUScalar {f} (ty : UScalarTy) (x : BinaryFloat f) : UScalar ty :=
  ⟨BitVec.ofNat ty.numBits (saturatingInt x 0 (2 ^ ty.numBits - 1)).toNat⟩

end BinaryFloat

namespace F32

def ofBits (x : U32) : F32 := ⟨x.bv⟩
@[rust_fun "core::f32::{f32}::from_bits"]
def from_bits (x : U32) : Result F32 := .ok (ofBits x)
@[rust_fun "core::f32::{f32}::to_bits"]
def to_bits (x : F32) : Result U32 := .ok ⟨x.bits⟩

def ofIScalar {ty} (x : IScalar ty) : F32 := BinaryFloat.ofInt _ x.val
def ofUScalar {ty} (x : UScalar ty) : F32 := BinaryFloat.round _ false x.val 1
def toIScalar (ty : IScalarTy) (x : F32) : IScalar ty := BinaryFloat.toIScalar ty x
def toUScalar (ty : UScalarTy) (x : F32) : UScalar ty := BinaryFloat.toUScalar ty x
def add (x y : F32) : F32 := BinaryFloat.add x y
def sub (x y : F32) : F32 := BinaryFloat.sub x y
def mul (x y : F32) : F32 := BinaryFloat.mul x y
def div (x y : F32) : F32 := BinaryFloat.div x y
def rem (x y : F32) : F32 := BinaryFloat.rem x y
def neg (x : F32) : F32 := BinaryFloat.neg x
def eq (x y : F32) : Bool := BinaryFloat.eq x y
def lt (x y : F32) : Bool := BinaryFloat.lt x y
def le (x y : F32) : Bool := BinaryFloat.le x y
def ne (x y : F32) : Bool := !eq x y
def gt (x y : F32) : Bool := lt y x
def ge (x y : F32) : Bool := le y x
@[rust_fun "core::f32::{f32}::is_nan"]
def is_nan (x : F32) : Result Bool := .ok (BinaryFloat.isNaN x)
@[rust_fun "core::f32::{f32}::is_infinite"]
def is_infinite (x : F32) : Result Bool := .ok (BinaryFloat.isInfinite x)
@[rust_fun "core::f32::{f32}::is_finite"]
def is_finite (x : F32) : Result Bool := .ok (BinaryFloat.isFinite x)
@[rust_fun "core::f32::{f32}::is_sign_negative"]
def is_sign_negative (x : F32) : Result Bool := .ok (BinaryFloat.sign x)
@[rust_fun "core::f32::{f32}::abs"]
def abs (x : F32) : Result F32 := .ok (BinaryFloat.abs x)
@[rust_fun "std::f32::{f32}::trunc"]
def trunc (x : F32) : Result F32 := .ok (BinaryFloat.trunc x)
@[rust_fun "std::f32::{f32}::fract"]
def fract (x : F32) : Result F32 := .ok (BinaryFloat.fract x)
@[rust_fun "std::f32::{f32}::floor"]
def floor (x : F32) : Result F32 := .ok (BinaryFloat.floor x)
@[rust_fun "std::f32::{f32}::powi"]
def powi (x : F32) (n : I32) : Result F32 := .ok (BinaryFloat.powi x n.val)
/-- `f32::recip` (core/src/num/f32.rs): `1.0 / self`; `1.0_f32` has bits 0x3f800000. -/
@[rust_fun "core::f32::{f32}::recip"]
def recip (x : F32) : Result F32 := .ok (div (BinaryFloat.ofNat _ 0x3F800000) x)

@[rust_fun "std::f32::{f32}::ceil"]
def ceil (x : F32) : Result F32 := .ok (BinaryFloat.ceil x)
@[rust_fun "std::f32::{f32}::round_ties_even"]
def round_ties_even (x : F32) : Result F32 := .ok (BinaryFloat.roundTiesEven x)
@[rust_fun "std::f32::{f32}::sqrt"]
def sqrt (x : F32) : Result F32 := .ok (BinaryFloat.sqrt x)
/-- `self.mul_add(a, b)` is `self * a + b` with one rounding (`FMADD` on aarch64). -/
@[rust_fun "std::f32::{f32}::mul_add"]
def mul_add (x a b : F32) : Result F32 := .ok (BinaryFloat.mulAdd x a b)
/-- `FMAXNM` semantics, see `BinaryFloat.maxNum` (a platform assumption). -/
@[rust_fun "core::f32::{f32}::max"]
def max (x y : F32) : Result F32 := .ok (BinaryFloat.maxNum true x y)
/-- `FMINNM` semantics, see `BinaryFloat.maxNum` (a platform assumption). -/
@[rust_fun "core::f32::{f32}::min"]
def min (x y : F32) : Result F32 := .ok (BinaryFloat.maxNum false x y)

/-! The transcendental functions call the platform libm, whose results are not
    correctly rounded and differ between platforms and versions. Each is an opaque
    function with no axiom about its values (verification/trusted_base.json
    "opaque"): no accepted theorem may depend on them, and no evaluation through
    them is evidence (the compiled stand-in returns a NaN). -/
/-- `f32::sin` (libm; unconstrained platform `sin`). -/
opaque Libm.sin : F32 → F32 := fun _ => BinaryFloat.nan _
@[rust_fun "std::f32::{f32}::sin"]
def sin (x : F32) : Result F32 := .ok (Libm.sin x)
/-- `f32::cos` (libm; unconstrained platform `cos`). -/
opaque Libm.cos : F32 → F32 := fun _ => BinaryFloat.nan _
@[rust_fun "std::f32::{f32}::cos"]
def cos (x : F32) : Result F32 := .ok (Libm.cos x)
/-- `f32::tan` (libm; unconstrained platform `tan`). -/
opaque Libm.tan : F32 → F32 := fun _ => BinaryFloat.nan _
@[rust_fun "std::f32::{f32}::tan"]
def tan (x : F32) : Result F32 := .ok (Libm.tan x)
/-- `f32::atan` (libm; unconstrained platform `atan`). -/
opaque Libm.atan : F32 → F32 := fun _ => BinaryFloat.nan _
@[rust_fun "std::f32::{f32}::atan"]
def atan (x : F32) : Result F32 := .ok (Libm.atan x)
/-- `f32::exp` (libm; unconstrained platform `exp`). -/
opaque Libm.exp : F32 → F32 := fun _ => BinaryFloat.nan _
@[rust_fun "std::f32::{f32}::exp"]
def exp (x : F32) : Result F32 := .ok (Libm.exp x)
/-- `f32::ln` (libm `log`; unconstrained platform `ln`). -/
opaque Libm.ln : F32 → F32 := fun _ => BinaryFloat.nan _
@[rust_fun "std::f32::{f32}::ln"]
def ln (x : F32) : Result F32 := .ok (Libm.ln x)

end F32
@[rust_fun "core::cmp::impls::{core::cmp::PartialEq<f32, f32>}::eq"]
def core.cmp.impls.PartialEqF32.eq (x y : F32) : Result Bool := .ok (F32.eq x y)
@[rust_fun "core::cmp::impls::{core::cmp::PartialEq<f32, f32>}::ne"]
def core.cmp.impls.PartialEqF32.ne (x y : F32) : Result Bool := .ok (F32.ne x y)
@[reducible, rust_trait_impl "core::cmp::PartialEq<f32, f32>"]
def core.cmp.PartialEqF32 : core.cmp.PartialEq F32 F32 := {
  eq := core.cmp.impls.PartialEqF32.eq
  ne := core.cmp.impls.PartialEqF32.ne
}
@[rust_fun "core::cmp::impls::{core::cmp::PartialOrd<f32, f32>}::partial_cmp"]
def core.cmp.impls.PartialOrdF32.partial_cmp (x y : F32) : Result (Option Ordering) :=
  .ok (BinaryFloat.partialCmp x y)
@[rust_fun "core::cmp::impls::{core::cmp::PartialOrd<f32, f32>}::lt"]
def core.cmp.impls.PartialOrdF32.lt (x y : F32) : Result Bool := .ok (F32.lt x y)
@[rust_fun "core::cmp::impls::{core::cmp::PartialOrd<f32, f32>}::le"]
def core.cmp.impls.PartialOrdF32.le (x y : F32) : Result Bool := .ok (F32.le x y)
@[rust_fun "core::cmp::impls::{core::cmp::PartialOrd<f32, f32>}::gt"]
def core.cmp.impls.PartialOrdF32.gt (x y : F32) : Result Bool := .ok (F32.gt x y)
@[rust_fun "core::cmp::impls::{core::cmp::PartialOrd<f32, f32>}::ge"]
def core.cmp.impls.PartialOrdF32.ge (x y : F32) : Result Bool := .ok (F32.ge x y)
@[reducible, rust_trait_impl "core::cmp::PartialOrd<f32, f32>"]
def core.cmp.PartialOrdF32 : core.cmp.PartialOrd F32 F32 := {
  partialEqInst := core.cmp.PartialEqF32
  partial_cmp := core.cmp.impls.PartialOrdF32.partial_cmp
  lt := core.cmp.impls.PartialOrdF32.lt
  le := core.cmp.impls.PartialOrdF32.le
  gt := core.cmp.impls.PartialOrdF32.gt
  ge := core.cmp.impls.PartialOrdF32.ge
}
@[rust_fun "core::clone::impls::{core::clone::Clone<f32>}::clone"]
def F32.clone (x : F32) : Result F32 := .ok x
@[reducible, rust_trait_impl "core::clone::Clone<f32>"]
def core.clone.CloneF32 : core.clone.Clone F32 := { clone := F32.clone }
@[reducible, rust_trait_impl "core::marker::Copy<f32>"]
def core.marker.CopyF32 : core.marker.Copy F32 := { cloneInst := core.clone.CloneF32 }

namespace F64

def ofBits (x : U64) : F64 := ⟨x.bv⟩
@[rust_fun "core::f64::{f64}::from_bits"]
def from_bits (x : U64) : Result F64 := .ok (ofBits x)
@[rust_fun "core::f64::{f64}::to_bits"]
def to_bits (x : F64) : Result U64 := .ok ⟨x.bits⟩
/-- `f64::INFINITY = 1.0_f64 / 0.0_f64` (core/src/num/f64.rs): bits 0x7ff0000000000000. -/
@[rust_const "core::f64::{f64}::INFINITY"]
def INFINITY : F64 := BinaryFloat.ofNat _ 0x7FF0000000000000
/-- `f64::NEG_INFINITY = -1.0_f64 / 0.0_f64`: bits 0xfff0000000000000. -/
@[rust_const "core::f64::{f64}::NEG_INFINITY"]
def NEG_INFINITY : F64 := BinaryFloat.ofNat _ 0xFFF0000000000000

def ofIScalar {ty} (x : IScalar ty) : F64 := BinaryFloat.ofInt _ x.val
def ofUScalar {ty} (x : UScalar ty) : F64 := BinaryFloat.round _ false x.val 1
def toIScalar (ty : IScalarTy) (x : F64) : IScalar ty := BinaryFloat.toIScalar ty x
def toUScalar (ty : UScalarTy) (x : F64) : UScalar ty := BinaryFloat.toUScalar ty x
def add (x y : F64) : F64 := BinaryFloat.add x y
def sub (x y : F64) : F64 := BinaryFloat.sub x y
def mul (x y : F64) : F64 := BinaryFloat.mul x y
def div (x y : F64) : F64 := BinaryFloat.div x y
def rem (x y : F64) : F64 := BinaryFloat.rem x y
def neg (x : F64) : F64 := BinaryFloat.neg x
def eq (x y : F64) : Bool := BinaryFloat.eq x y
def lt (x y : F64) : Bool := BinaryFloat.lt x y
def le (x y : F64) : Bool := BinaryFloat.le x y
def ne (x y : F64) : Bool := !eq x y
def gt (x y : F64) : Bool := lt y x
def ge (x y : F64) : Bool := le y x
@[rust_fun "core::f64::{f64}::is_nan"]
def is_nan (x : F64) : Result Bool := .ok (BinaryFloat.isNaN x)
@[rust_fun "core::f64::{f64}::is_infinite"]
def is_infinite (x : F64) : Result Bool := .ok (BinaryFloat.isInfinite x)
@[rust_fun "core::f64::{f64}::is_finite"]
def is_finite (x : F64) : Result Bool := .ok (BinaryFloat.isFinite x)
@[rust_fun "core::f64::{f64}::is_sign_negative"]
def is_sign_negative (x : F64) : Result Bool := .ok (BinaryFloat.sign x)
@[rust_fun "core::f64::{f64}::abs"]
def abs (x : F64) : Result F64 := .ok (BinaryFloat.abs x)
@[rust_fun "std::f64::{f64}::trunc"]
def trunc (x : F64) : Result F64 := .ok (BinaryFloat.trunc x)
@[rust_fun "std::f64::{f64}::fract"]
def fract (x : F64) : Result F64 := .ok (BinaryFloat.fract x)
@[rust_fun "std::f64::{f64}::floor"]
def floor (x : F64) : Result F64 := .ok (BinaryFloat.floor x)
@[rust_fun "std::f64::{f64}::powi"]
def powi (x : F64) (n : I32) : Result F64 := .ok (BinaryFloat.powi x n.val)
/-- `f64::recip` (core/src/num/f64.rs): `1.0 / self`; `1.0_f64` has bits 0x3ff0000000000000. -/
@[rust_fun "core::f64::{f64}::recip"]
def recip (x : F64) : Result F64 := .ok (div (BinaryFloat.ofNat _ 0x3FF0000000000000) x)

@[rust_fun "std::f64::{f64}::ceil"]
def ceil (x : F64) : Result F64 := .ok (BinaryFloat.ceil x)
@[rust_fun "std::f64::{f64}::round_ties_even"]
def round_ties_even (x : F64) : Result F64 := .ok (BinaryFloat.roundTiesEven x)
@[rust_fun "std::f64::{f64}::sqrt"]
def sqrt (x : F64) : Result F64 := .ok (BinaryFloat.sqrt x)
/-- `self.mul_add(a, b)` is `self * a + b` with one rounding (`FMADD` on aarch64). -/
@[rust_fun "std::f64::{f64}::mul_add"]
def mul_add (x a b : F64) : Result F64 := .ok (BinaryFloat.mulAdd x a b)
/-- `FMAXNM` semantics, see `BinaryFloat.maxNum` (a platform assumption). -/
@[rust_fun "core::f64::{f64}::max"]
def max (x y : F64) : Result F64 := .ok (BinaryFloat.maxNum true x y)
/-- `FMINNM` semantics, see `BinaryFloat.maxNum` (a platform assumption). -/
@[rust_fun "core::f64::{f64}::min"]
def min (x y : F64) : Result F64 := .ok (BinaryFloat.maxNum false x y)

/-! The transcendental functions call the platform libm, whose results are not
    correctly rounded and differ between platforms and versions. Each is an opaque
    function with no axiom about its values (verification/trusted_base.json
    "opaque"): no accepted theorem may depend on them, and no evaluation through
    them is evidence (the compiled stand-in returns a NaN). -/
/-- `f64::sin` (libm; unconstrained platform `sin`). -/
opaque Libm.sin : F64 → F64 := fun _ => BinaryFloat.nan _
@[rust_fun "std::f64::{f64}::sin"]
def sin (x : F64) : Result F64 := .ok (Libm.sin x)
/-- `f64::cos` (libm; unconstrained platform `cos`). -/
opaque Libm.cos : F64 → F64 := fun _ => BinaryFloat.nan _
@[rust_fun "std::f64::{f64}::cos"]
def cos (x : F64) : Result F64 := .ok (Libm.cos x)
/-- `f64::tan` (libm; unconstrained platform `tan`). -/
opaque Libm.tan : F64 → F64 := fun _ => BinaryFloat.nan _
@[rust_fun "std::f64::{f64}::tan"]
def tan (x : F64) : Result F64 := .ok (Libm.tan x)
/-- `f64::atan` (libm; unconstrained platform `atan`). -/
opaque Libm.atan : F64 → F64 := fun _ => BinaryFloat.nan _
@[rust_fun "std::f64::{f64}::atan"]
def atan (x : F64) : Result F64 := .ok (Libm.atan x)
/-- `f64::exp` (libm; unconstrained platform `exp`). -/
opaque Libm.exp : F64 → F64 := fun _ => BinaryFloat.nan _
@[rust_fun "std::f64::{f64}::exp"]
def exp (x : F64) : Result F64 := .ok (Libm.exp x)
/-- `f64::ln` (libm `log`; unconstrained platform `ln`). -/
opaque Libm.ln : F64 → F64 := fun _ => BinaryFloat.nan _
@[rust_fun "std::f64::{f64}::ln"]
def ln (x : F64) : Result F64 := .ok (Libm.ln x)

end F64
/-- `impl AddAssign<&f64> for f64` (core/src/internal_macros.rs `forward_ref_op_assign!`):
    `*self += *other`. -/
@[rust_fun "core::ops::arith::{core::ops::arith::AddAssign<f64, &'a f64>}::add_assign"]
def core.ops.arith.AddAssignF64SharedF64.add_assign (self rhs : F64) : Result F64 :=
  .ok (F64.add self rhs)
@[rust_fun "core::cmp::impls::{core::cmp::PartialEq<f64, f64>}::eq"]
def core.cmp.impls.PartialEqF64.eq (x y : F64) : Result Bool := .ok (F64.eq x y)
@[rust_fun "core::cmp::impls::{core::cmp::PartialEq<f64, f64>}::ne"]
def core.cmp.impls.PartialEqF64.ne (x y : F64) : Result Bool := .ok (F64.ne x y)
@[reducible, rust_trait_impl "core::cmp::PartialEq<f64, f64>"]
def core.cmp.PartialEqF64 : core.cmp.PartialEq F64 F64 := {
  eq := core.cmp.impls.PartialEqF64.eq
  ne := core.cmp.impls.PartialEqF64.ne
}
@[rust_fun "core::cmp::impls::{core::cmp::PartialOrd<f64, f64>}::partial_cmp"]
def core.cmp.impls.PartialOrdF64.partial_cmp (x y : F64) : Result (Option Ordering) :=
  .ok (BinaryFloat.partialCmp x y)
@[rust_fun "core::cmp::impls::{core::cmp::PartialOrd<f64, f64>}::lt"]
def core.cmp.impls.PartialOrdF64.lt (x y : F64) : Result Bool := .ok (F64.lt x y)
@[rust_fun "core::cmp::impls::{core::cmp::PartialOrd<f64, f64>}::le"]
def core.cmp.impls.PartialOrdF64.le (x y : F64) : Result Bool := .ok (F64.le x y)
@[rust_fun "core::cmp::impls::{core::cmp::PartialOrd<f64, f64>}::gt"]
def core.cmp.impls.PartialOrdF64.gt (x y : F64) : Result Bool := .ok (F64.gt x y)
@[rust_fun "core::cmp::impls::{core::cmp::PartialOrd<f64, f64>}::ge"]
def core.cmp.impls.PartialOrdF64.ge (x y : F64) : Result Bool := .ok (F64.ge x y)
@[reducible, rust_trait_impl "core::cmp::PartialOrd<f64, f64>"]
def core.cmp.PartialOrdF64 : core.cmp.PartialOrd F64 F64 := {
  partialEqInst := core.cmp.PartialEqF64
  partial_cmp := core.cmp.impls.PartialOrdF64.partial_cmp
  lt := core.cmp.impls.PartialOrdF64.lt
  le := core.cmp.impls.PartialOrdF64.le
  gt := core.cmp.impls.PartialOrdF64.gt
  ge := core.cmp.impls.PartialOrdF64.ge
}
@[rust_fun "core::clone::impls::{core::clone::Clone<f64>}::clone"]
def F64.clone (x : F64) : Result F64 := .ok x
@[reducible, rust_trait_impl "core::clone::Clone<f64>"]
def core.clone.CloneF64 : core.clone.Clone F64 := { clone := F64.clone }
@[reducible, rust_trait_impl "core::marker::Copy<f64>"]
def core.marker.CopyF64 : core.marker.Copy F64 := { cloneInst := core.clone.CloneF64 }

def F32.toF64 (x : F32) : F64 := BinaryFloat.cast .binary64 x
def F64.toF32 (x : F64) : F32 := BinaryFloat.cast .binary32 x

@[rust_fun "core::convert::num::{core::convert::From<f64, f32>}::from"]
def core.convert.num.FromF64F32.from_ (x : F32) : Result F64 := .ok (F32.toF64 x)
@[reducible, rust_trait_impl "core::convert::From<f64, f32>"]
def core.convert.num.FromF64F32 : core.convert.From F64 F32 := {
  from_ := core.convert.num.FromF64F32.from_
}

namespace F16

def ofBits (x : U16) : F16 := ⟨x.bv⟩
@[rust_fun "half::binary16::{half::binary16::f16}::from_bits"]
def from_bits (x : U16) : Result F16 := .ok (ofBits x)
@[rust_fun "half::binary16::{half::binary16::f16}::to_bits"]
def to_bits (x : F16) : Result U16 := .ok ⟨x.bits⟩
@[rust_fun "half::binary16::{core::clone::Clone<half::binary16::f16>}::clone"]
def clone (x : F16) : Result F16 := .ok x

end F16

@[reducible, rust_trait_impl "core::clone::Clone<half::binary16::f16>"]
def core.clone.CloneF16 : core.clone.Clone F16 := { clone := F16.clone }
@[reducible, rust_trait_impl "core::marker::Copy<half::binary16::f16>"]
def core.marker.CopyF16 : core.marker.Copy F16 := { cloneInst := core.clone.CloneF16 }

namespace BF16

def ofBits (x : U16) : BF16 := ⟨x.bv⟩
@[rust_fun "half::bfloat::{half::bfloat::bf16}::from_bits"]
def from_bits (x : U16) : Result BF16 := .ok (ofBits x)
@[rust_fun "half::bfloat::{half::bfloat::bf16}::to_bits"]
def to_bits (x : BF16) : Result U16 := .ok ⟨x.bits⟩
@[rust_fun "half::bfloat::{core::clone::Clone<half::bfloat::bf16>}::clone"]
def clone (x : BF16) : Result BF16 := .ok x

end BF16

@[reducible, rust_trait_impl "core::clone::Clone<half::bfloat::bf16>"]
def core.clone.CloneBF16 : core.clone.Clone BF16 := { clone := BF16.clone }
@[reducible, rust_trait_impl "core::marker::Copy<half::bfloat::bf16>"]
def core.marker.CopyBF16 : core.marker.Copy BF16 := { cloneInst := core.clone.CloneBF16 }

end Aeneas.Std
