import Aeneas.Std.Core.Core
import Aeneas.Std.Scalar.Core

namespace Aeneas.Std

/-- `core::any::TypeId` (core/src/any.rs): at runtime the 128-bit hash of a type
    (its array of pointers carries provenance only for const evaluation and Miri).
    `Any::type_id` mentions it, so every crate with `Any` evidence retains the type.
    No operation on it is modeled: a call to `Any::type_id` or to a comparison
    fails closed as an unknown external. -/
@[rust_type "core::any::TypeId" (body := .opaque)]
structure core.any.TypeId where
  hash : U128

end Aeneas.Std
