import Aeneas.Std.Array.Array
import Aeneas.Std.Core.Default
import Aeneas.Std.Core.Convert
import Aeneas.Std.VecIter

namespace Aeneas.Std

/- `VecDeque<T, A>` (alloc/src/collections/vec_deque/mod.rs, rustc 1.95) is a
ring buffer over a `RawVec`: `head` is the physical index of the front element
and `len` the number of elements. The model is its logical sequence, front
first (the order of `VecDeque::iter`); the physical layout (head, capacity,
wrap-around) is not observable through the modeled methods. The allocator is
erased as for `Vec` and `BTreeMap`: allocation failure and destructor effects
are outside the model. -/
@[rust_type "alloc::collections::vec_deque::VecDeque"
  (keepParams := [true, false]) (body := .opaque)]
structure alloc.collections.vec_deque.VecDeque (T : Type) where
  items : List T

namespace alloc.collections.vec_deque

/-- `VecDeque::new`: `VecDeque { head: 0, len: 0, buf: RawVec::new() }`. -/
@[rust_fun
  "alloc::collections::vec_deque::{alloc::collections::vec_deque::VecDeque<@T, alloc::alloc::Global>}::new"]
def VecDeque.new (T : Type) : Result (VecDeque T) := .ok ⟨[]⟩

/-- `Default for VecDeque<T>`: `VecDeque::new()`. -/
@[rust_fun
  "alloc::collections::vec_deque::{core::default::Default<alloc::collections::vec_deque::VecDeque<@T, alloc::alloc::Global>>}::default"]
def DefaultVecDeque.default (T : Type) : Result (VecDeque T) := VecDeque.new T

@[reducible, rust_trait_impl
  "core::default::Default<alloc::collections::vec_deque::VecDeque<@T, alloc::alloc::Global>>"]
def DefaultVecDeque (T : Type) : core.default.Default (VecDeque T) := {
  default := DefaultVecDeque.default T
}

/-- `From<[T; N]> for VecDeque<T>`: the array's elements, in order
    (`ptr::copy_nonoverlapping` into a buffer of capacity `N`, `head = 0`). -/
@[rust_fun
  "alloc::collections::vec_deque::{core::convert::From<alloc::collections::vec_deque::VecDeque<@T, alloc::alloc::Global>, [@T; @N]>}::from"]
def FromVecDequeArray.from {T : Type} {N : Usize} (a : Array T N) : Result (VecDeque T) :=
  .ok ⟨a.val⟩

@[reducible, rust_trait_impl
  "core::convert::From<alloc::collections::vec_deque::VecDeque<@T, alloc::alloc::Global>, [@T; @N]>"]
def FromVecDequeArray (T : Type) (N : Usize) : core.convert.From (VecDeque T) (Array T N) := {
  from_ := FromVecDequeArray.from
}

/-- `FromIterator<T> for VecDeque<T>` (alloc/src/collections/vec_deque/mod.rs:3640, rustc 1.95):
    `SpecFromIter::spec_from_iter(iter.into_iter())`. Its default (vec_deque/spec_from_iter.rs:8-19)
    is `Vec::from_iter(iterator).into()`, and `From<Vec<T, A>>` (mod.rs:3736-3750) keeps the
    vector's elements in order (`head = 0`, no reallocation). Its specializations for
    `vec::IntoIter<T>` and `vec_deque::IntoIter<T>` (spec_from_iter.rs:21-34, `into_vecdeque`)
    keep the remaining elements in order without calling `next`, which moves them out without
    callbacks. The deque therefore holds the items of the Vec collector
    (`alloc.vec.FromIteratorVec.from_iter`, repeated `next`), and the collection contract
    (`CollectionContracts`) admits it exactly where it admits the Vec collector. The value given
    back is the Vec collector's. -/
@[rust_fun
  "alloc::collections::vec_deque::{core::iter::traits::collect::FromIterator<alloc::collections::vec_deque::VecDeque<@T, alloc::alloc::Global>, @T>}::from_iter"]
def FromIteratorVecDeque.from_iter {T I IntoIter : Type}
    (into : core.iter.traits.collect.IntoIterator I T IntoIter)
    (input : I) : Result (VecDeque T × I) := do
  let (items, input) ← alloc.vec.FromIteratorVec.from_iter into input
  .ok (⟨items.val⟩, input)

/-- `VecDeque::len`: the element count. A native deque never holds more than
    `usize::MAX` elements (`push_back`/`push_front` panic with "capacity
    overflow" first, see `VecDeque.push_back`), so the failing branch is
    unreachable from modeled operations. -/
@[rust_fun "alloc::collections::vec_deque::{alloc::collections::vec_deque::VecDeque<@T, @A>}::len"
  (keepParams := [true, false])]
def VecDeque.len {T : Type} (self : VecDeque T) : Result Usize :=
  if h : self.items.length < 2 ^ UScalarTy.Usize.numBits then
    .ok (Usize.ofNatCore self.items.length h)
  else .fail .panic

/-- `VecDeque::is_empty`: `self.len == 0`. -/
@[rust_fun
  "alloc::collections::vec_deque::{alloc::collections::vec_deque::VecDeque<@T, @A>}::is_empty"
  (keepParams := [true, false])]
def VecDeque.is_empty {T : Type} (self : VecDeque T) : Result Bool :=
  .ok self.items.isEmpty

/-- `VecDeque::clear`: `self.truncate(0)` (dropping every element), then `head = 0`. -/
@[rust_fun "alloc::collections::vec_deque::{alloc::collections::vec_deque::VecDeque<@T, @A>}::clear"
  (keepParams := [true, false])]
def VecDeque.clear {T : Type} (_self : VecDeque T) : Result (VecDeque T) := .ok ⟨[]⟩

/-- `VecDeque::push_back`: when full, `grow` doubles the buffer, which panics with
    "capacity overflow" when the capacity would exceed `usize::MAX` (reachable only
    for zero-sized `T`: otherwise the allocation fails first, which is outside the
    model); then the value is written after the last element. -/
@[rust_fun
  "alloc::collections::vec_deque::{alloc::collections::vec_deque::VecDeque<@T, @A>}::push_back"
  (keepParams := [true, false])]
def VecDeque.push_back {T : Type} (self : VecDeque T) (value : T) : Result (VecDeque T) :=
  if self.items.length < Usize.max then .ok ⟨self.items ++ [value]⟩
  else .fail .maximumSizeExceeded

/-- `VecDeque::push_front`: as `push_back`, the value written before the first element. -/
@[rust_fun
  "alloc::collections::vec_deque::{alloc::collections::vec_deque::VecDeque<@T, @A>}::push_front"
  (keepParams := [true, false])]
def VecDeque.push_front {T : Type} (self : VecDeque T) (value : T) : Result (VecDeque T) :=
  if self.items.length < Usize.max then .ok ⟨value :: self.items⟩
  else .fail .maximumSizeExceeded

/-- `VecDeque::pop_front`: `None` when empty, else the front element, removed. -/
@[rust_fun
  "alloc::collections::vec_deque::{alloc::collections::vec_deque::VecDeque<@T, @A>}::pop_front"
  (keepParams := [true, false])]
def VecDeque.pop_front {T : Type} (self : VecDeque T) : Result (Option T × VecDeque T) :=
  match self.items with
  | [] => .ok (none, self)
  | item :: rest => .ok (some item, ⟨rest⟩)

/-- `VecDeque::pop_back`: `None` when empty, else the back element, removed. -/
@[rust_fun
  "alloc::collections::vec_deque::{alloc::collections::vec_deque::VecDeque<@T, @A>}::pop_back"
  (keepParams := [true, false])]
def VecDeque.pop_back {T : Type} (self : VecDeque T) : Result (Option T × VecDeque T) :=
  match self.items.getLast? with
  | none => .ok (none, self)
  | some item => .ok (some item, ⟨self.items.dropLast⟩)

/-- `VecDeque::front`: the first element, `None` when empty. -/
@[rust_fun "alloc::collections::vec_deque::{alloc::collections::vec_deque::VecDeque<@T, @A>}::front"
  (keepParams := [true, false])]
def VecDeque.front {T : Type} (self : VecDeque T) : Result (Option T) :=
  .ok self.items.head?

/-- `VecDeque::back`: the last element, `None` when empty. -/
@[rust_fun "alloc::collections::vec_deque::{alloc::collections::vec_deque::VecDeque<@T, @A>}::back"
  (keepParams := [true, false])]
def VecDeque.back {T : Type} (self : VecDeque T) : Result (Option T) :=
  .ok self.items.getLast?

end alloc.collections.vec_deque

@[reducible, rust_trait_impl
  "core::iter::traits::collect::FromIterator<alloc::collections::vec_deque::VecDeque<@T, alloc::alloc::Global>, @T>"]
def core.iter.traits.collect.FromIteratorVecDeque (T : Type) :
    core.iter.traits.collect.FromIterator (alloc.collections.vec_deque.VecDeque T) T := {
  from_iter := alloc.collections.vec_deque.FromIteratorVecDeque.from_iter
}

end Aeneas.Std
