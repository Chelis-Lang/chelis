import Aeneas.Std.Slice
import Aeneas.Std.Core.Cmp
import Aeneas.Std.Core.Ops

namespace Aeneas.Std

open Result

namespace alloc.slice

/-- A stable merge: take the right item only when it is strictly less than
 the left one. Every comparison threads its callback state and may fail. -/
def stableMerge {T S : Type} (less : S → T → T → Result (Bool × S))
    (left right : List T) (state : S) :
    Result ({out : List T // out.length = left.length + right.length} × S) :=
  match left, right with
  | [], right => ok (⟨right, by simp⟩, state)
  | left, [] => ok (⟨left, by simp⟩, state)
  | x :: xs, y :: ys => do
    let (before, state) ← less state y x
    if before then
      let (out, state) ← stableMerge less (x :: xs) ys state
      return (⟨y :: out.val, by
        have h := out.property
        simp only [List.length_cons] at h ⊢
        omega⟩, state)
    else
      let (out, state) ← stableMerge less xs (y :: ys) state
      return (⟨x :: out.val, by
        have h := out.property
        simp only [List.length_cons] at h ⊢
        omega⟩, state)
termination_by left.length + right.length
decreasing_by
  all_goals simp_all only [List.length_cons]
  all_goals omega

/-- Stable merge sorting with a length-preserving result. This specifies a
 comparison schedule, not an API guarantee about Rust callback call counts.
 Keys are recomputed for each comparison, unlike `sort_by_cached_key`. -/
def stableSort {T S : Type} (less : S → T → T → Result (Bool × S))
    (input : List T) (state : S) :
    Result ({out : List T // out.length = input.length} × S) :=
  match input with
  | [] => ok (⟨[], rfl⟩, state)
  | [x] => ok (⟨[x], rfl⟩, state)
  | x :: y :: xs => do
    let input := x :: y :: xs
    let middle := input.length / 2
    let (left, state) ← stableSort less (input.take middle) state
    let (right, state) ← stableSort less (input.drop middle) state
    let (out, state) ← stableMerge less left.val right.val state
    return (⟨out.val, by
      change out.val.length = input.length
      have hl := left.property
      have hr := right.property
      have ho := out.property
      simp only [List.length_take, List.length_drop] at hl hr
      omega⟩, state)
termination_by input.length
decreasing_by
  all_goals simp_all only [List.length_take, List.length_drop, List.length_cons]
  all_goals omega

@[rust_fun "alloc::slice::{[@T]}::sort"]
def Slice.sort {T : Type} (ordInst : core.cmp.Ord T) (self : Std.Slice T) :
    Result (Std.Slice T) := do
  -- Rust's entry point passes T::lt, rather than calling Ord::cmp.
  let (out, _) ← stableSort
    (fun (_ : Unit) x y => do return (← ordInst.partialOrdInst.lt x y, ())) self.val ()
  return ⟨out.val, by rw [out.property]; exact self.property⟩

@[rust_fun "alloc::slice::{[@T]}::sort_by_key"]
def Slice.sort_by_key {T K F : Type}
    (fnInst : core.ops.function.FnMut F T K) (ordInst : core.cmp.Ord K)
    (self : Std.Slice T) (f : F) : Result (Unit × Std.Slice T × F) := do
  let (out, f) ← stableSort (fun f x y => do
    let (kx, f) ← fnInst.call_mut f x
    let (ky, f) ← fnInst.call_mut f y
    return (← ordInst.partialOrdInst.lt kx ky, f)) self.val f
  return ((), ⟨out.val, by rw [out.property]; exact self.property⟩, f)

/-- `<[T]>::sort_by` (alloc/src/slice.rs): `stable_sort(self, |a, b| compare(a, b) == Less)`
 (driftsort). Natively, the sequence of comparisons is unspecified, and the result is
 unspecified (or a panic) when `compare` is not a total order. Aeneas admits a call only
 where `compare` is a closure returning `Ord::cmp` of the same key of its two arguments, a
 key projected from the argument without computation (llbc/SortContracts.ml), on a key type
 as for `sort_unstable`: the comparator is pure and a total preorder, so the stable order
 is unique and this merge sort returns the native result. -/
@[rust_fun "alloc::slice::{[@T]}::sort_by"]
def Slice.sort_by {T F : Type}
    (fnInst : core.ops.function.FnMut F (T × T) Ordering) (self : Std.Slice T) (compare : F) :
    Result (Unit × Std.Slice T × F) := do
  let (out, compare) ← stableSort (fun compare x y => do
    let (order, compare) ← fnInst.call_mut compare (x, y)
    return (order matches .lt, compare)) self.val compare
  return ((), ⟨out.val, by rw [out.property]; exact self.property⟩, compare)

end alloc.slice

/-- `<[T]>::sort_unstable` (core/src/slice/mod.rs): `sort::unstable::sort(self, &mut T::lt)`
 (ipnsort). Natively, the order of the elements that compare `Equal`, and the sequence of
 comparisons, are unspecified. Aeneas admits a call only where `Ord` is total and `Equal`
 holds exactly for indistinguishable values (llbc/SortContracts.ml: integers, `bool`,
 `char`, `str`, `String`, references, boxes, tuples and derived `Ord` types of those):
 there every sorted permutation is the same list, which this stable sort returns. -/
@[rust_fun "core::slice::{[@T]}::sort_unstable"]
def core.slice.Slice.sort_unstable {T : Type} (ordInst : core.cmp.Ord T) (self : Std.Slice T) :
    Result (Std.Slice T) := do
  let (out, _) ← alloc.slice.stableSort
    (fun (_ : Unit) x y => do return (← ordInst.partialOrdInst.lt x y, ())) self.val ()
  return ⟨out.val, by rw [out.property]; exact self.property⟩

/-- `<[T]>::sort_unstable_by` (core/src/slice/mod.rs):
 `sort::unstable::sort(self, &mut |a, b| compare(a, b) == Ordering::Less)`. Aeneas admits a
 call only where `compare` is a closure returning `Ord::cmp(a, b)` or `Ord::cmp(b, a)` on
 an element type as for `sort_unstable` (llbc/SortContracts.ml): the comparator is pure,
 total and returns `Equal` only for indistinguishable values, so the list sorted by it is
 unique and this stable sort returns the native result. -/
@[rust_fun "core::slice::{[@T]}::sort_unstable_by"]
def core.slice.Slice.sort_unstable_by {T F : Type}
    (fnInst : core.ops.function.FnMut F (T × T) Ordering) (self : Std.Slice T) (compare : F) :
    Result (Unit × Std.Slice T × F) := do
  let (out, compare) ← alloc.slice.stableSort (fun compare x y => do
    let (order, compare) ← fnInst.call_mut compare (x, y)
    return (order matches .lt, compare)) self.val compare
  return ((), ⟨out.val, by rw [out.property]; exact self.property⟩, compare)

end Aeneas.Std
