import Aeneas.Std.RangeBounds
import Aeneas.Std.VecIter

namespace Aeneas.Std

open Result

/-- `vec::Drain<'a, T, A>` (alloc/src/vec/drain.rs, rustc 1.95): the unyielded
elements of the drained range, and the vector that dropping the drain leaves:
the prefix before the range and the tail after it. `Drop for Drain` drops the
unyielded elements and moves the tail back, so the range is removed whether or
not the iterator was exhausted; ending the borrow of the vector gives `kept`
back. -/
@[rust_type "alloc::vec::drain::Drain" (keepParams := [true, false]) (mutRegions := #[0])
  (body := .opaque)]
structure alloc.vec.drain.Drain (T : Type) where
  remaining : List T
  kept : alloc.vec.Vec T

/-- `Vec::drain` (alloc/src/vec/mod.rs): `slice::range(range, ..len)`, then the
elements `start..end` are drained and `start..` of the vector is closed up when
the drain is dropped. -/
@[rust_fun "alloc::vec::{alloc::vec::Vec<@T>}::drain" (keepParams := [true, false, true])]
def alloc.vec.Vec.drain {T R : Type} (bounds : core.ops.range.RangeBounds R Usize)
    (v : alloc.vec.Vec T) (range : R) :
    Result (alloc.vec.drain.Drain T × (alloc.vec.drain.Drain T → alloc.vec.Vec T)) :=
  match h : core.slice.index.rangeOf bounds range v.length with
  | ok (start, end_) =>
    have hr := core.slice.index.rangeOf_le h
    let kept : alloc.vec.Vec T := ⟨v.val.take start ++ v.val.drop end_, by
      have := v.len_ineq; simp only [List.length_append, List.length_take, List.length_drop]
      simp only [alloc.vec.Vec.length] at hr; omega⟩
    ok (⟨(v.val.take end_).drop start, kept⟩, fun drain => drain.kept)
  | fail e => fail e
  | div => div

@[rust_fun
  "alloc::vec::drain::{core::iter::traits::iterator::Iterator<alloc::vec::drain::Drain<'a, @T, @A>, @T>}::next"
  (keepParams := [true, false])]
def alloc.vec.drain.IteratorDrain.next {T : Type} (it : alloc.vec.drain.Drain T) :
    Result (Option T × alloc.vec.drain.Drain T) :=
  match it.remaining with
  | [] => ok (none, it)
  | item :: rest => ok (some item, { it with remaining := rest })

/-- `self.iter.size_hint()`: the slice iterator's exact length. -/
@[rust_fun
  "alloc::vec::drain::{core::iter::traits::iterator::Iterator<alloc::vec::drain::Drain<'a, @T, @A>, @T>}::size_hint"
  (keepParams := [true, false])]
def alloc.vec.drain.IteratorDrain.size_hint {T : Type} (it : alloc.vec.drain.Drain T) :
    Result (Usize × Option Usize) := do
  let length ← UScalar.tryMk .Usize it.remaining.length
  ok (length, some length)

@[rust_fun
  "alloc::vec::drain::{core::iter::traits::double_ended::DoubleEndedIterator<alloc::vec::drain::Drain<'a, @T, @A>, @T>}::next_back"
  (keepParams := [true, false])]
def alloc.vec.drain.DoubleEndedIteratorDrain.next_back {T : Type} (it : alloc.vec.drain.Drain T) :
    Result (Option T × alloc.vec.drain.Drain T) :=
  match it.remaining.getLast? with
  | none => ok (none, it)
  | some item => ok (some item, { it with remaining := it.remaining.dropLast })

/-- `impl Iterator for Drain` overrides `next` and `size_hint`; `Drain` is
`TrustedLen` and `FusedIterator`, not `TrustedRandomAccess`. -/
@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<alloc::vec::drain::Drain<'a, @T, @A>, @T>"
  (keepParams := [true, false])]
def core.iter.traits.iterator.IteratorVecDrain (T : Type) :
    core.iter.traits.iterator.Iterator (alloc.vec.drain.Drain T) T := {
  next := alloc.vec.drain.IteratorDrain.next
  size_hint := alloc.vec.drain.IteratorDrain.size_hint
  trusted_len := true
  fused := true
}

/-- `impl DoubleEndedIterator for Drain` overrides `next_back` only. -/
@[reducible, rust_trait_impl
  "core::iter::traits::double_ended::DoubleEndedIterator<alloc::vec::drain::Drain<'a, @T, @A>, @T>"
  (keepParams := [true, false])]
def core.iter.traits.double_ended.DoubleEndedIteratorVecDrain (T : Type) :
    core.iter.traits.double_ended.DoubleEndedIterator (alloc.vec.drain.Drain T) T := {
  iteratorInst := core.iter.traits.iterator.IteratorVecDrain T
  next_back := alloc.vec.drain.DoubleEndedIteratorDrain.next_back
}

/-- Dropping a drain, exhausted or not, leaves the vector without the range. -/
theorem alloc.vec.Vec.drain_kept {T R : Type} {bounds : core.ops.range.RangeBounds R Usize}
    {v : alloc.vec.Vec T} {range : R} {drain : alloc.vec.drain.Drain T}
    {back : alloc.vec.drain.Drain T → alloc.vec.Vec T} {start end_ : Nat}
    (hr : core.slice.index.rangeOf bounds range v.length = ok (start, end_))
    (h : alloc.vec.Vec.drain bounds v range = ok (drain, back)) (final : alloc.vec.drain.Drain T)
    (hkept : final.kept = drain.kept) :
    (back final).val = v.val.take start ++ v.val.drop end_ := by
  unfold alloc.vec.Vec.drain at h
  split at h <;> simp_all
  obtain ⟨rfl, rfl⟩ := h
  simp [hkept]

end Aeneas.Std
