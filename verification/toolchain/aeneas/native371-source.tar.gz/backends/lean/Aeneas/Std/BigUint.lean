import Aeneas.Std.Core.Cmp
import Aeneas.Std.Core.Convert
import Aeneas.Std.Core.Hash
import Aeneas.Std.Scalar.Core
import Aeneas.Std.Scalar.Fmt

/-!
# Models of `num-bigint` 0.4.6 `BigUint`

A `BigUint` is a normalized little-endian digit vector; its value is a natural
number, and every operation modeled here is exact on that value. The model type
is `Nat` itself. Operations panic exactly where the crate does: division and
remainder by zero (`div_rem_ref`/`rem_digit`: `panic!("attempt to divide by
zero")`). Everything else is total (allocation failure aborts rather than
panicking and is outside the model, as for `Vec`).
-/

namespace Aeneas.Std

@[rust_type "num_bigint::biguint::BigUint"]
abbrev num_bigint.BigUint := Nat

/-- `TryFromBigIntError<T>` carries the rejected original value. -/
@[rust_type "num_bigint::TryFromBigIntError"]
structure num_bigint.TryFromBigIntError (T : Type) where
  original : T

namespace num_bigint.BigUint

@[rust_fun "num_bigint::biguint::convert::{core::convert::From<num_bigint::biguint::BigUint, u8>}::from"]
def FromU8.from_ (n : U8) : Result BigUint := .ok n.val
@[rust_fun "num_bigint::biguint::convert::{core::convert::From<num_bigint::biguint::BigUint, u16>}::from"]
def FromU16.from_ (n : U16) : Result BigUint := .ok n.val
@[rust_fun "num_bigint::biguint::convert::{core::convert::From<num_bigint::biguint::BigUint, u32>}::from"]
def FromU32.from_ (n : U32) : Result BigUint := .ok n.val
@[rust_fun "num_bigint::biguint::convert::{core::convert::From<num_bigint::biguint::BigUint, u64>}::from"]
def FromU64.from_ (n : U64) : Result BigUint := .ok n.val
@[rust_fun "num_bigint::biguint::convert::{core::convert::From<num_bigint::biguint::BigUint, usize>}::from"]
def FromUsize.from_ (n : Usize) : Result BigUint := .ok n.val
@[rust_fun "num_bigint::biguint::convert::{core::convert::From<num_bigint::biguint::BigUint, u128>}::from"]
def FromU128.from_ (n : U128) : Result BigUint := .ok n.val

/-- `impl TryFrom<BigUint> for u64`: `to_u64` succeeds exactly on values below `2^64`;
    otherwise the error returns the original value. -/
@[rust_fun "num_bigint::biguint::convert::{core::convert::TryFrom<u64, num_bigint::biguint::BigUint, num_bigint::TryFromBigIntError<num_bigint::biguint::BigUint>>}::try_from"]
def TryFromU64.try_from (value : BigUint) :
    Result (core.result.Result U64 (TryFromBigIntError BigUint)) :=
  if value ≤ U64.max then .ok (.Ok ⟨BitVec.ofNat 64 value⟩) else .ok (.Err ⟨value⟩)

/-- `impl TryFrom<BigUint> for usize` (64-bit targets, as `Usize` in the models). -/
@[rust_fun "num_bigint::biguint::convert::{core::convert::TryFrom<usize, num_bigint::biguint::BigUint, num_bigint::TryFromBigIntError<num_bigint::biguint::BigUint>>}::try_from"]
def TryFromUsize.try_from (value : BigUint) :
    Result (core.result.Result Usize (TryFromBigIntError BigUint)) :=
  if value ≤ Usize.max then .ok (.Ok ⟨BitVec.ofNat _ value⟩) else .ok (.Err ⟨value⟩)

@[rust_fun "num_bigint::biguint::multiplication::{core::ops::arith::Mul<num_bigint::biguint::BigUint, num_bigint::biguint::BigUint, num_bigint::biguint::BigUint>}::mul"]
def MulBigUint.mul (x y : BigUint) : Result BigUint := .ok (x * y)
@[rust_fun "num_bigint::biguint::multiplication::{core::ops::arith::Mul<&'a num_bigint::biguint::BigUint, &'b num_bigint::biguint::BigUint, num_bigint::biguint::BigUint>}::mul"]
def MulShared.mul (x y : BigUint) : Result BigUint := .ok (x * y)

/-- `&a / &b`: `div_rem_ref` panics on a zero divisor. -/
@[rust_fun "num_bigint::biguint::division::{core::ops::arith::Div<&'a num_bigint::biguint::BigUint, &'b num_bigint::biguint::BigUint, num_bigint::biguint::BigUint>}::div"]
def DivShared.div (x y : BigUint) : Result BigUint :=
  if y = 0 then .fail .panic else .ok (x / y)
@[rust_fun "num_bigint::biguint::division::{core::ops::arith::Div<num_bigint::biguint::BigUint, num_bigint::biguint::BigUint, num_bigint::biguint::BigUint>}::div"]
def DivBigUint.div (x y : BigUint) : Result BigUint :=
  if y = 0 then .fail .panic else .ok (x / y)

/-- `&a % &b`: both the `u32` fast path (`rem_digit`) and `div_rem_ref` panic on
    a zero divisor. -/
@[rust_fun "num_bigint::biguint::division::{core::ops::arith::Rem<&'a num_bigint::biguint::BigUint, &'b num_bigint::biguint::BigUint, num_bigint::biguint::BigUint>}::rem"]
def RemShared.rem (x y : BigUint) : Result BigUint :=
  if y = 0 then .fail .panic else .ok (x % y)
@[rust_fun "num_bigint::biguint::division::{core::ops::arith::Rem<num_bigint::biguint::BigUint, num_bigint::biguint::BigUint, num_bigint::biguint::BigUint>}::rem"]
def RemBigUint.rem (x y : BigUint) : Result BigUint :=
  if y = 0 then .fail .panic else .ok (x % y)

@[rust_fun "num_bigint::biguint::{core::clone::Clone<num_bigint::biguint::BigUint>}::clone"]
def CloneBigUint.clone (x : BigUint) : Result BigUint := .ok x

/-- Digit vectors are normalized, so structural equality is value equality. -/
@[rust_fun "num_bigint::biguint::{core::cmp::PartialEq<num_bigint::biguint::BigUint, num_bigint::biguint::BigUint>}::eq"]
def PartialEqBigUint.eq (x y : BigUint) : Result Bool := .ok (x == y)

/-- `cmp`: fewer normalized digits is smaller, otherwise `cmp_slice` compares from
    the most significant digit: numeric order. -/
@[rust_fun "num_bigint::biguint::{core::cmp::Ord<num_bigint::biguint::BigUint>}::cmp"]
def OrdBigUint.cmp (x y : BigUint) : Result Ordering := .ok (compare x y)

/-- `partial_cmp` is `Some(self.cmp(other))`. -/
@[rust_fun "num_bigint::biguint::{core::cmp::PartialOrd<num_bigint::biguint::BigUint, num_bigint::biguint::BigUint>}::partial_cmp"]
def PartialOrdBigUint.partial_cmp (x y : BigUint) : Result (Option Ordering) :=
  .ok (some (compare x y))

/-- The digit vector `data` of 64-bit targets (`BigDigit = u64`): the little-endian base-`2^64`
    digits, normalized (no most significant zero digit; zero has none). -/
def digits64 (n : Nat) : List U64 :=
  if n = 0 then [] else ⟨BitVec.ofNat 64 n⟩ :: digits64 (n / 2 ^ 64)
decreasing_by omega

/-- `impl Hash for BigUint` (num-bigint 0.4.6 biguint.rs): `self.data.hash(state)`, the `Hash` of
    `Vec<u64>`, i.e. of `[u64]`: `write_length_prefix` of the digit count, then one `write` of the
    digits' native-order bytes (`u64`'s `hash_slice`). -/
@[rust_fun "num_bigint::biguint::{core::hash::Hash<num_bigint::biguint::BigUint>}::hash"]
def HashBigUint.hash {H : Type} (HasherInst : core.hash.Hasher H) (self : BigUint) (state : H) :
    Result H :=
  let digits := digits64 self
  if h : digits.length ≤ Usize.max then
    core.hash.impls.HashSlice.hash core.hash.HashU64 HasherInst ⟨digits, h⟩ state
  else .fail .panic

end num_bigint.BigUint

open num_bigint in
@[reducible, rust_trait_impl "core::hash::Hash<num_bigint::biguint::BigUint>"]
def num_bigint.HashBigUint : core.hash.Hash BigUint :=
  { hash := fun HasherInst => BigUint.HashBigUint.hash HasherInst }

open num_bigint in
@[reducible, rust_trait_impl "core::clone::Clone<num_bigint::biguint::BigUint>"]
def num_bigint.CloneBigUint : core.clone.Clone BigUint := { clone := BigUint.CloneBigUint.clone }

open num_bigint in
@[reducible, rust_trait_impl "core::cmp::PartialEq<num_bigint::biguint::BigUint, num_bigint::biguint::BigUint>"]
def num_bigint.PartialEqBigUint : core.cmp.PartialEq BigUint BigUint := {
  eq := BigUint.PartialEqBigUint.eq
}

open num_bigint in
@[reducible, rust_trait_impl "core::cmp::Eq<num_bigint::biguint::BigUint>"]
def num_bigint.EqBigUint : core.cmp.Eq BigUint := { partialEqInst := PartialEqBigUint }

open num_bigint in
@[reducible, rust_trait_impl "core::cmp::PartialOrd<num_bigint::biguint::BigUint, num_bigint::biguint::BigUint>"]
def num_bigint.PartialOrdBigUint : core.cmp.PartialOrd BigUint BigUint := {
  partialEqInst := PartialEqBigUint
  partial_cmp := BigUint.PartialOrdBigUint.partial_cmp
}

open num_bigint in
@[reducible, rust_trait_impl "core::cmp::Ord<num_bigint::biguint::BigUint>"]
def num_bigint.OrdBigUint : core.cmp.Ord BigUint := {
  eqInst := EqBigUint
  partialOrdInst := PartialOrdBigUint
  cmp := BigUint.OrdBigUint.cmp
}

open num_bigint in
@[reducible, rust_trait_impl "core::convert::From<num_bigint::biguint::BigUint, u8>"]
def num_bigint.FromBigUintU8 : core.convert.From BigUint U8 := { from_ := BigUint.FromU8.from_ }
open num_bigint in
@[reducible, rust_trait_impl "core::convert::From<num_bigint::biguint::BigUint, u64>"]
def num_bigint.FromBigUintU64 : core.convert.From BigUint U64 := { from_ := BigUint.FromU64.from_ }
open num_bigint in
@[reducible, rust_trait_impl "core::convert::From<num_bigint::biguint::BigUint, usize>"]
def num_bigint.FromBigUintUsize : core.convert.From BigUint Usize :=
  { from_ := BigUint.FromUsize.from_ }

open num_bigint in
@[reducible, rust_trait_impl "core::convert::TryFrom<u64, num_bigint::biguint::BigUint, num_bigint::TryFromBigIntError<num_bigint::biguint::BigUint>>"]
def num_bigint.TryFromU64BigUint : core.convert.TryFrom U64 BigUint (TryFromBigIntError BigUint) :=
  { try_from := BigUint.TryFromU64.try_from }

/-- `Display` is `f.pad_integral(true, "", &self.to_str_radix(10))` (biguint.rs:110-114):
    decimal digits, never a `-` sign, `+` only with the sign-plus flag, and the
    width, fill, alignment and zero-pad flags of `pad_integral`. The `#` flag adds
    the empty prefix. -/
@[rust_fun "num_bigint::biguint::{core::fmt::Display<num_bigint::biguint::BigUint>}::fmt"]
def num_bigint.BigUint.DisplayBigUint.fmt (x : num_bigint.BigUint) (fmt : core.fmt.Formatter) :
    core.fmt.Outcome :=
  fmt.padIntegral false "" (core.fmt.digits x)

/-- `Debug` calls `Display` (biguint.rs:104-108). Thus the `{:x?}` flags have no effect,
    unlike the `Debug` of the primitive integers. -/
@[rust_fun "num_bigint::biguint::{core::fmt::Debug<num_bigint::biguint::BigUint>}::fmt"]
def num_bigint.BigUint.DebugBigUint.fmt (x : num_bigint.BigUint) (fmt : core.fmt.Formatter) :
    core.fmt.Outcome :=
  num_bigint.BigUint.DisplayBigUint.fmt x fmt

@[reducible, rust_trait_impl "core::fmt::Display<num_bigint::biguint::BigUint>"]
def num_bigint.DisplayBigUint : core.fmt.Display num_bigint.BigUint :=
  ⟨num_bigint.BigUint.DisplayBigUint.fmt⟩

@[reducible, rust_trait_impl "core::fmt::Debug<num_bigint::biguint::BigUint>"]
def num_bigint.DebugBigUint : core.fmt.Debug num_bigint.BigUint :=
  ⟨num_bigint.BigUint.DebugBigUint.fmt⟩

end Aeneas.Std
