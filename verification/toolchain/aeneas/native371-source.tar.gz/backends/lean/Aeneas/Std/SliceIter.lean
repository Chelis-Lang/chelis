/- Arrays/Slices -/
import Aeneas.Std.Slice
import Aeneas.Std.Array.ArraySlice
import Aeneas.Std.Core.Iter
import Aeneas.Std.IteratorAdapters

namespace Aeneas.Std

open Result Error core.ops.range WP

attribute [-simp] List.getElem!_eq_getElem?_getD


@[rust_type "core::slice::iter::Iter"]
structure core.slice.iter.Iter (T : Type) where
  /- Retain the original storage for giveback. The remaining range is
     [i, slice.length - back), so neither end may cross the other. -/
  slice : Slice T
  i : Nat
  back : Nat := 0

@[rust_type "core::slice::iter::IterMut" (mutRegions := #[0]) (body := .opaque)]
structure core.slice.iter.IterMut (T : Type) where
  /- We need to remember the slice and an index inside the slice (this is necessary)
     for double ended iterators) -/
  slice : Slice T
  i : Nat := 0

@[rust_fun "core::slice::{[@T]}::iter"]
def core.slice.Slice.iter {T : Type} (s : Slice T) : Result (core.slice.iter.Iter T) :=
  ok { slice := s, i := 0, back := 0 }

@[rust_fun "core::slice::{[@T]}::contains"]
def core.slice.Slice.contains {T : Type} (partialEqInst : core.cmp.PartialEq T T)
  (s : Slice T) (x : T) : Result Bool :=
  List.anyM (partialEqInst.eq x) s.val

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::IterMut<'a, @T>, &'a mut @T>}::next"]
def core.slice.iter.IteratorIterMut.next
  {T : Type}
  (it : core.slice.iter.IterMut T) :
  Result ((Option T) × (core.slice.iter.IterMut T) ×
          (core.slice.iter.IterMut T → Option T → core.slice.iter.IterMut T)) :=
  if h: it.i < it.slice.len then
    let x := it.slice[it.i]
    let i := it.i
    let it := { it with i := i + 1 }
    let back it' x :=
      match x with
      | none => it'
      | some x => { it' with slice := it'.slice.setAtNat i x }
    ok (some x, it, back)
  else ok (none, it, fun it _ => it)

/-- Native `find` uses a `next` loop. The result retains the item restoration
    function from the terminal call and the final predicate state.
    The predicate reads the item and can change its captured state. -/
@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::IterMut<'a, @T>, &'a mut @T>}::find"]
def core.slice.iter.IteratorIterMut.find {T P : Type}
    (fnInst : core.ops.function.FnMutSharedMutArg P T Bool)
    (it : core.slice.iter.IterMut T) (predicate : P) :
    Result ((Option T) × (core.slice.iter.IterMut T) × P ×
            (core.slice.iter.IterMut T → Option T → core.slice.iter.IterMut T)) := do
  let (item, it, back) ← core.slice.iter.IteratorIterMut.next it
  match item with
  | none => ok (none, it, predicate, back)
  | some x =>
    let (found, predicate) ← fnInst.call_mut predicate x
    if found then ok (some x, it, predicate, back)
    else core.slice.iter.IteratorIterMut.find fnInst it predicate
partial_fixpoint

@[rust_fun "core::slice::{[@T]}::iter_mut"]
def core.slice.Slice.iter_mut {T : Type} (slice : Slice T) :
  Result ((core.slice.iter.IterMut T) × (core.slice.iter.IterMut T → Slice T)) :=
  ok ({slice}, fun it => it.slice)

@[rust_fun
  "core::slice::iter::{core::iter::traits::collect::IntoIterator<&'a mut [@T], &'a mut @T, core::slice::iter::IterMut<'a, @T>>}::into_iter"]
def core.slice.iter.IntoIteratorMutSlice.into_iter
  {T : Type} (slice : Slice T) :
  Result (core.slice.iter.IterMut T × (core.slice.iter.IterMut T → Slice T)) :=
  core.slice.Slice.iter_mut slice

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::next"]
def core.slice.iter.IteratorSliceIter.next
  {T : Type} (it : core.slice.iter.Iter T) : Result ((Option T) × (core.slice.iter.Iter T)) :=
  if h : it.i < it.slice.length - it.back then
    let x := it.slice[it.i]'(by
      simp only [Slice.length] at h ⊢
      omega)
    let it := { it with i := it.i + 1}
    ok (some x, it)
  else ok (none, it)

@[rust_fun
  "core::slice::iter::{core::iter::traits::double_ended::DoubleEndedIterator<core::slice::iter::Iter<'a, @T>, &'_ @T>}::next_back"]
def core.slice.iter.DoubleEndedIteratorSliceIter.next_back
  {T : Type} (it : core.slice.iter.Iter T) : Result ((Option T) × (core.slice.iter.Iter T)) :=
  if h : it.i < it.slice.length - it.back then
    let x := it.slice[it.slice.length - it.back - 1]'(by
      simp only [Slice.length] at h ⊢
      omega)
    ok (some x, { it with back := it.back + 1 })
  else ok (none, it)

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::step_by"]
def core.slice.iter.IteratorSliceIter.step_by {T} (slice : core.slice.iter.Iter T) (steps : Usize) :
  Result (core.iter.adapters.step_by.StepBy (core.slice.iter.Iter T)) :=
  if steps.val = 0 then .fail .panic
  else ok { iter := slice, step_by := steps }

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::enumerate"]
def core.slice.iter.IteratorSliceIter.enumerate {T} (slice : core.slice.iter.Iter T) :
  Result (core.iter.adapters.enumerate.Enumerate (core.slice.iter.Iter T)) :=
  .ok { iter := slice, count := 0#usize }

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::take"]
def core.slice.iter.IteratorSliceIter.take {T} (slice : core.slice.iter.Iter T) (n : Usize) :
  Result (core.iter.adapters.take.Take (core.slice.iter.Iter T)) :=
  ok ⟨ slice, n ⟩


@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::size_hint"]
def core.slice.iter.IteratorSliceIter.size_hint {T : Type}
  (self : core.slice.iter.Iter T) : Result (Usize × Option Usize) :=
  let n := Usize.ofNatCore (self.slice.length - self.back - self.i) (by
    have := self.slice.property
    simp only [Slice.length]
    scalar_tac)
  ok (n, some n)

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::advance_by"]
def core.slice.iter.IteratorSliceIter.advance_by {T : Type}
  (self : core.slice.iter.Iter T) (n : Usize) :
  Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) × core.slice.iter.Iter T) := do
  let step := min n.val (self.slice.length - self.back - self.i)
  let self := { self with i := self.i + step }
  if h : n.val ≤ step then ok (.Ok (), self)
  else
    let left := Usize.ofNatCore (n.val - step) (by scalar_tac)
    let left ← core.num.nonzero.NonZero.new_unchecked left
    ok (.Err left, self)

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::nth"]
def core.slice.iter.IteratorSliceIter.nth {T : Type}
  (self : core.slice.iter.Iter T) (n : Usize) :
  Result (Option T × core.slice.iter.Iter T) := do
  let (result, self) ← core.slice.iter.IteratorSliceIter.advance_by self n
  match result with
  | .Err _ => ok (none, self)
  | .Ok _ => core.slice.iter.IteratorSliceIter.next self

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::fold"]
def core.slice.iter.IteratorSliceIter.fold
  {T B F : Type}
  (fnInst : core.ops.function.FnMut F (B × T) B)
  (self : core.slice.iter.Iter T) (init : B) (f : F) :
  Result (B × core.slice.iter.Iter T × F) := do
  -- Native fold advances a local index, not the iterator's stored start pointer.
  let (acc, _, f) ← core.iter.traits.iterator.foldFromNext
    core.slice.iter.IteratorSliceIter.next fnInst self init f
  ok (acc, self, f)

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::try_fold"]
def core.slice.iter.IteratorSliceIter.try_fold
  {T B F R Residual : Type}
  (fnInst : core.ops.function.FnMut F (B × T) R)
  (tryInst : core.ops.try_trait.Try R B Residual)
  (self : core.slice.iter.Iter T) (init : B) (f : F) :
  Result (R × core.slice.iter.Iter T × F) :=
  core.iter.traits.iterator.tryFoldFromNext core.slice.iter.IteratorSliceIter.next
    fnInst tryInst self init f
@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::count"]
def core.slice.iter.IteratorSliceIter.count {T} (it : core.slice.iter.Iter T) :
  Result (Usize × core.slice.iter.Iter T) := do
  let (n, _) ← core.slice.iter.IteratorSliceIter.size_hint it
  ok (n, it)

/-- `Iterator::any` of the slice iterator given the call of its closure: each element in
    turn, until the closure returns `true`; the iterator's and the closure's final states are
    returned. -/
def core.slice.iter.IteratorSliceIter.any_with {T F}
  (call : F → T → Result (Bool × F)) (it : core.slice.iter.Iter T) (f : F) :
  Result (Bool × core.slice.iter.Iter T × F) :=
  core.iter.traits.iterator.anyFromNextWith core.slice.iter.IteratorSliceIter.next call it f

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::any"]
def core.slice.iter.IteratorSliceIter.any {T F}
  (fnInst : core.ops.function.FnMut F T Bool) (it : core.slice.iter.Iter T) (f : F) :
  Result (Bool × core.slice.iter.Iter T × F) :=
  core.slice.iter.IteratorSliceIter.any_with fnInst.call_mut it f

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::all"]
def core.slice.iter.IteratorSliceIter.all {T F : Type}
    (fnInst : core.ops.function.FnMut F T Bool) (self : core.slice.iter.Iter T) (f : F) :
    Result (Bool × core.slice.iter.Iter T × F) :=
  core.iter.traits.iterator.allFromTryFold
    (core.slice.iter.IteratorSliceIter.try_fold (T := T)) fnInst self f

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::find"]
def core.slice.iter.IteratorSliceIter.find {T P : Type}
    (fnInst : core.ops.function.FnMut P T Bool) (self : core.slice.iter.Iter T) (predicate : P) :
    Result (Option T × core.slice.iter.Iter T × P) :=
  core.iter.traits.iterator.findFromTryFold
    (core.slice.iter.IteratorSliceIter.try_fold (T := T)) fnInst self predicate

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::find_map"]
def core.slice.iter.IteratorSliceIter.find_map {T B F : Type}
    (fnInst : core.ops.function.FnMut F T (Option B)) (self : core.slice.iter.Iter T) (f : F) :
    Result (Option B × core.slice.iter.Iter T × F) :=
  core.iter.traits.iterator.findMapFromTryFold
    (core.slice.iter.IteratorSliceIter.try_fold (T := T)) fnInst self f

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::position"]
def core.slice.iter.IteratorSliceIter.position {T P : Type}
    (fnInst : core.ops.function.FnMut P T Bool) (self : core.slice.iter.Iter T) (predicate : P) :
    Result (Option Usize × core.slice.iter.Iter T × P) :=
  core.iter.traits.iterator.positionFromTryFold
    (core.slice.iter.IteratorSliceIter.try_fold (T := T)) fnInst self predicate

/-- The loop of `Iter::rposition` from the index `i` (the number of elements left before the
    back): `while let Some(x) = self.next_back() { i -= 1; if predicate(x) { return Some(i) } }
    None`. -/
def core.slice.iter.IteratorSliceIter.rpositionFrom {T P : Type}
    (fnInst : core.ops.function.FnMut P T Bool) :
    Nat → core.slice.iter.Iter T → P → Result (Option Usize × core.slice.iter.Iter T × P)
  | 0, self, predicate => ok (none, self, predicate)
  | i + 1, self, predicate => do
    let (x, self) ← core.slice.iter.DoubleEndedIteratorSliceIter.next_back self
    match x with
    | none => ok (none, self, predicate)
    | some x =>
      let (found, predicate) ← fnInst.call_mut predicate x
      if found then ok (some ⟨BitVec.ofNat _ i⟩, self, predicate)
      else core.slice.iter.IteratorSliceIter.rpositionFrom fnInst i self predicate

/-- `Iter::rposition` (core/src/slice/iter/macros.rs, rustc 1.95): `let n = len!(self); let mut
    i = n;` then the loop of `rpositionFrom`: the index, from the front of the remaining elements,
    of the last one satisfying the predicate, the elements from the back through it consumed.
    Without an element left, `next_back` is `None` (`i = 0`). The `ExactSizeIterator` and
    `DoubleEndedIterator` clauses of `Self` are the slice iterator's own. -/
@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::rposition"
  (keepTraitClauses := [true, false, false])]
def core.slice.iter.IteratorSliceIter.rposition {T P : Type}
    (fnInst : core.ops.function.FnMut P T Bool) (self : core.slice.iter.Iter T) (predicate : P) :
    Result (Option Usize × core.slice.iter.Iter T × P) :=
  core.slice.iter.IteratorSliceIter.rpositionFrom fnInst
    (self.slice.length - self.back - self.i) self predicate

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>"]
def core.iter.traits.iterator.IteratorSliceIter (T : Type) :
  core.iter.traits.iterator.Iterator (core.slice.iter.Iter T) T := {
  next := core.slice.iter.IteratorSliceIter.next
  step_by := core.slice.iter.IteratorSliceIter.step_by
  enumerate := core.slice.iter.IteratorSliceIter.enumerate
  take := core.slice.iter.IteratorSliceIter.take
  count := core.slice.iter.IteratorSliceIter.count
  any := core.slice.iter.IteratorSliceIter.any
  all := core.slice.iter.IteratorSliceIter.all
  find := core.slice.iter.IteratorSliceIter.find
  find_map := core.slice.iter.IteratorSliceIter.find_map
  position := core.slice.iter.IteratorSliceIter.position
  nth := core.slice.iter.IteratorSliceIter.nth
  advance_by := core.slice.iter.IteratorSliceIter.advance_by
  fold := core.slice.iter.IteratorSliceIter.fold
  try_fold := core.slice.iter.IteratorSliceIter.try_fold
  size_hint := core.slice.iter.IteratorSliceIter.size_hint
  trusted_len := true
  fused := true
  random_access := some {
    is_full := true
    may_have_side_effect := false
    get_unchecked self n :=
      if h : self.i + n.val < self.slice.length - self.back then
        ok (self.slice[self.i + n.val]'(by
          simp only [Slice.length] at h ⊢
          omega), self)
      else fail .panic
  }
}

/-- `slice::Iter::for_each` (core/src/slice/iter/macros.rs, rustc 1.95):
    `while let Some(x) = self.next() { f(x); }`: the closure on each item in order, the
    schedule of the default. -/
@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::for_each"]
def core.slice.iter.IteratorSliceIter.for_each {T F : Type}
    (fnInst : core.ops.function.FnMut F T Unit) (self : core.slice.iter.Iter T) (f : F) :
    Result (Unit × core.slice.iter.Iter T × F) :=
  core.iter.traits.iterator.Iterator.for_each.default
    (core.iter.traits.iterator.IteratorSliceIter T) fnInst self f

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::try_for_each"]
def core.slice.iter.IteratorSliceIter.try_for_each {T F R Residual : Type}
    (fnInst : core.ops.function.FnMut F T R)
    -- Preserve the result.
    (tryInst : core.ops.try_trait.Try R Unit Residual)
    (self : core.slice.iter.Iter T) (f : F) :
    -- Return the source after the last callback.
    Result (R × core.slice.iter.Iter T × F) :=
  core.iter.traits.iterator.Iterator.try_for_each.default
    (core.iter.traits.iterator.IteratorSliceIter T) fnInst tryInst self f


/-- The slice `Iter` inherits `Iterator::product` (core/src/slice/iter/macros.rs
    does not override it): `Product::product(self)` with this implementation. -/
@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::product"]
def core.slice.iter.IteratorSliceIter.product {T P : Type}
  (productInst : core.iter.traits.accum.Product P T) (self : core.slice.iter.Iter T) :
  Result (P × core.slice.iter.Iter T) :=
  productInst.product (core.iter.traits.iterator.IteratorSliceIter T) self

/-- The slice `Iter` inherits `Iterator::sum` (core/src/slice/iter/macros.rs does not
    override it): `Sum::sum(self)` with this implementation. -/
@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::sum"]
def core.slice.iter.IteratorSliceIter.sum {T S : Type}
  (sumInst : core.iter.traits.accum.Sum S T) (self : core.slice.iter.Iter T) :
  Result (S × core.slice.iter.Iter T) :=
  sumInst.sum (core.iter.traits.iterator.IteratorSliceIter T) self

/-- The slice `Iter` inherits `Iterator::min` (core/src/slice/iter/macros.rs does not
    override it): `self.min_by(Ord::cmp)` with this implementation. -/
@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Iter<'a, @T>, &'a @T>}::min"]
def core.slice.iter.IteratorSliceIter.min {T : Type}
  (ordInst : core.cmp.Ord T) (self : core.slice.iter.Iter T) :
  Result (Option T × core.slice.iter.Iter T) :=
  core.iter.traits.iterator.Iterator.min.default (core.iter.traits.iterator.IteratorSliceIter T)
    ordInst self

@[rust_fun
  "core::slice::iter::{core::iter::traits::double_ended::DoubleEndedIterator<core::slice::iter::Iter<'a, @T>, &'_ @T>}::advance_back_by"]
def core.slice.iter.DoubleEndedIteratorSliceIter.advance_back_by {T : Type}
  (self : core.slice.iter.Iter T) (n : Usize) :
  Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) × core.slice.iter.Iter T) := do
  let step := min n.val (self.slice.length - self.back - self.i)
  let self := { self with back := self.back + step }
  if h : n.val ≤ step then ok (.Ok (), self)
  else
    let left := Usize.ofNatCore (n.val - step) (by scalar_tac)
    let left ← core.num.nonzero.NonZero.new_unchecked left
    ok (.Err left, self)

@[rust_fun
  "core::slice::iter::{core::iter::traits::double_ended::DoubleEndedIterator<core::slice::iter::Iter<'a, @T>, &'_ @T>}::nth_back"]
def core.slice.iter.DoubleEndedIteratorSliceIter.nth_back {T : Type}
  (self : core.slice.iter.Iter T) (n : Usize) :
  Result (Option T × core.slice.iter.Iter T) := do
  let (result, self) ← core.slice.iter.DoubleEndedIteratorSliceIter.advance_back_by self n
  match result with
  | .Err _ => ok (none, self)
  | .Ok _ => core.slice.iter.DoubleEndedIteratorSliceIter.next_back self
@[reducible, rust_trait_impl
  "core::iter::traits::double_ended::DoubleEndedIterator<core::slice::iter::Iter<'a, @T>, &'_ @T>"]
def core.iter.traits.double_ended.DoubleEndedIteratorSliceIter (T : Type) :
  core.iter.traits.double_ended.DoubleEndedIterator (core.slice.iter.Iter T) T := {
  iteratorInst := core.iter.traits.iterator.IteratorSliceIter T
  next_back := core.slice.iter.DoubleEndedIteratorSliceIter.next_back
  advance_back_by := core.slice.iter.DoubleEndedIteratorSliceIter.advance_back_by
  nth_back := core.slice.iter.DoubleEndedIteratorSliceIter.nth_back
}

/-- `impl ExactSizeIterator for Iter<'_, T>` (core slice/iter/macros.rs,
    rustc 1.95): `len` is `len!(self)`, the number of remaining elements (the
    exact bounds of `size_hint`). -/
@[rust_fun
  "core::slice::iter::{core::iter::traits::exact_size::ExactSizeIterator<core::slice::iter::Iter<'a, @T>, &'_ @T>}::len"]
def core.slice.iter.ExactSizeIteratorSliceIter.len {T : Type}
  (self : core.slice.iter.Iter T) : Result Usize := do
  let (n, _) ← core.slice.iter.IteratorSliceIter.size_hint self
  ok n

@[reducible, rust_trait_impl
  "core::iter::traits::exact_size::ExactSizeIterator<core::slice::iter::Iter<'a, @T>, &'_ @T>"]
def core.iter.traits.exact_size.ExactSizeIteratorSliceIter (T : Type) :
  core.iter.traits.exact_size.ExactSizeIterator (core.slice.iter.Iter T) T := {
  iteratorInst := core.iter.traits.iterator.IteratorSliceIter T
  len := core.slice.iter.ExactSizeIteratorSliceIter.len
}

@[rust_fun
  "core::slice::iter::{core::iter::traits::collect::IntoIterator<&'a [@T], &'a @T, core::slice::iter::Iter<'a, @T>>}::into_iter"]
def core.slice.iter.IntoIteratorSharedSlice.into_iter
  {T : Type} (s : Slice T) :
  Result (core.slice.iter.Iter T × (core.slice.iter.Iter T → Slice T)) := do
  let it ← core.slice.Slice.iter s
  ok (it, fun it => it.slice)

@[reducible, rust_trait_impl
  "core::iter::traits::collect::IntoIterator<&'a [@T], &'a @T, core::slice::iter::Iter<'a, @T>>"]
def core.iter.traits.collect.IntoIteratorSharedSlice (T : Type) :
  core.iter.traits.collect.IntoIterator (Slice T) T (core.slice.iter.Iter T) := {
  iteratorInst := core.iter.traits.iterator.IteratorSliceIter T
  into_iter := core.slice.iter.IntoIteratorSharedSlice.into_iter
}

@[rust_fun
  "core::array::{core::iter::traits::collect::IntoIterator<&'a [@T; @N], &'a @T, core::slice::iter::Iter<'a, @T>>}::into_iter"]
def core.array.IntoIteratorSharedArray.into_iter
  {T : Type} {N : Usize} (a : Array T N) :
  Result (core.slice.iter.Iter T × (core.slice.iter.Iter T → Array T N)) := do
  let it ← core.slice.Slice.iter a.to_slice
  -- Iteration advances the cursor, retaining the full, same-length storage.
  ok (it, fun it => Array.from_slice a it.slice)

@[reducible, rust_trait_impl
  "core::iter::traits::collect::IntoIterator<&'a [@T; @N], &'a @T, core::slice::iter::Iter<'a, @T>>"]
def core.iter.traits.collect.IntoIteratorSharedArray (T : Type) (N : Usize) :
  core.iter.traits.collect.IntoIterator (Array T N) T (core.slice.iter.Iter T) := {
  iteratorInst := core.iter.traits.iterator.IteratorSliceIter T
  into_iter := core.array.IntoIteratorSharedArray.into_iter
  const_size := some N
}

@[rust_type "core::slice::iter::Windows" (body := .opaque)]
structure core.slice.iter.Windows (T : Type) where
  slice : Slice T
  size : Usize
  positive : 0 < size.val

@[rust_fun "core::slice::{[@T]}::windows"]
def core.slice.Slice.windows {T : Type} (self : Slice T) (size : Usize) :
  Result (core.slice.iter.Windows T) :=
  if h : size.val = 0 then fail .panic
  else ok ⟨self, size, Nat.pos_of_ne_zero h⟩

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Windows<'a, @T>, &'a [@T]>}::next"]
def core.slice.iter.IteratorWindows.next
  {T : Type} (self : core.slice.iter.Windows T) :
  Result ((Option (Slice T)) × core.slice.iter.Windows T) :=
  if self.size.val ≤ self.slice.length then
    let window : Slice T := ⟨self.slice.val.take self.size.val, by
      simp only [List.length_take]
      exact Nat.le_trans (Nat.min_le_right _ _) self.slice.property⟩
    ok (some window, { self with slice := self.slice.drop 1#usize })
  else ok (none, self)

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Windows<'a, @T>, &'a [@T]>}::step_by"]
def core.slice.iter.IteratorWindows.step_by {T : Type}
  (self : core.slice.iter.Windows T) (step_by : Usize) :
  Result (core.iter.adapters.step_by.StepBy (core.slice.iter.Windows T)) :=
  core.iter.traits.iterator.Iterator.step_by.default self step_by

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Windows<'a, @T>, &'a [@T]>}::enumerate"]
def core.slice.iter.IteratorWindows.enumerate {T : Type}
  (self : core.slice.iter.Windows T) :
  Result (core.iter.adapters.enumerate.Enumerate (core.slice.iter.Windows T)) :=
  ok { iter := self, count := 0#usize }

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Windows<'a, @T>, &'a [@T]>}::take"]
def core.slice.iter.IteratorWindows.take {T : Type}
  (self : core.slice.iter.Windows T) (n : Usize) :
  Result (core.iter.adapters.take.Take (core.slice.iter.Windows T)) :=
  ok ⟨self, n⟩

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Windows<'a, @T>, &'a [@T]>}::count"]
def core.slice.iter.IteratorWindows.count {T : Type}
  (self : core.slice.iter.Windows T) : Result (Usize × core.slice.iter.Windows T) :=
  if h : self.size.val ≤ self.slice.length then
    let count := Usize.ofNatCore (self.slice.length - self.size.val + 1) (by
      have := self.positive
      have := self.slice.property
      scalar_tac)
    ok (count, self)
  else ok (0#usize, self)

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Windows<'a, @T>, &'a [@T]>}::any"]
def core.slice.iter.IteratorWindows.any {T F : Type}
  (fnInst : core.ops.function.FnMut F (Slice T) Bool)
  (self : core.slice.iter.Windows T) (f : F) :
  Result (Bool × core.slice.iter.Windows T × F) :=
  core.iter.traits.iterator.anyFromNext
    core.slice.iter.IteratorWindows.next fnInst self f


@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Windows<'a, @T>, &'a [@T]>}::size_hint"]
def core.slice.iter.IteratorWindows.size_hint {T : Type}
  (self : core.slice.iter.Windows T) : Result (Usize × Option Usize) := do
  let (n, _) ← core.slice.iter.IteratorWindows.count self
  ok (n, some n)

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Windows<'a, @T>, &'a [@T]>}::nth"]
def core.slice.iter.IteratorWindows.nth {T : Type}
  (self : core.slice.iter.Windows T) (n : Usize) :
  Result (Option (Slice T) × core.slice.iter.Windows T) :=
  if n.val + self.size.val ≤ self.slice.length then
    core.slice.iter.IteratorWindows.next { self with slice := self.slice.drop n }
  else ok (none, { self with slice := ⟨[], by simp⟩ })
@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::slice::iter::Windows<'a, @T>, &'a [@T]>"]
def core.iter.traits.iterator.IteratorWindows (T : Type) :
  core.iter.traits.iterator.Iterator (core.slice.iter.Windows T) (Slice T) := {
  next := core.slice.iter.IteratorWindows.next
  step_by := core.slice.iter.IteratorWindows.step_by
  enumerate := core.slice.iter.IteratorWindows.enumerate
  take := core.slice.iter.IteratorWindows.take
  count := core.slice.iter.IteratorWindows.count
  any := core.slice.iter.IteratorWindows.any
  nth := core.slice.iter.IteratorWindows.nth
  size_hint := core.slice.iter.IteratorWindows.size_hint
  trusted_len := true
  fused := true
  random_access := some {
    is_full := true
    may_have_side_effect := false
    get_unchecked self n :=
      if n.val + self.size.val ≤ self.slice.length then
        let rest := self.slice.drop n
        let window : Slice T := ⟨rest.val.take self.size.val, by
          simp only [List.length_take]
          exact Nat.le_trans (Nat.min_le_right _ _) rest.property⟩
        ok (window, self)
      else fail .panic
  }
}

@[rust_type "core::slice::iter::Chunks" (body := .opaque)]
structure core.slice.iter.Chunks (T : Type) where
  slice : Slice T
  size : Usize
  positive : 0 < size.val

@[rust_fun "core::slice::{[@T]}::chunks"]
def core.slice.Slice.chunks {T : Type} (self : Slice T) (chunk_size : Usize) :
  Result (core.slice.iter.Chunks T) :=
  if h : chunk_size.val = 0 then fail .panic
  else ok ⟨self, chunk_size, Nat.pos_of_ne_zero h⟩

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Chunks<'a, @T>, &'a [@T]>}::next"]
def core.slice.iter.IteratorChunks.next
  {T : Type} (self : core.slice.iter.Chunks T) :
  Result ((Option (Slice T)) × core.slice.iter.Chunks T) :=
  if self.slice.length = 0 then ok (none, self)
  else
    let chunk : Slice T := ⟨self.slice.val.take self.size.val, by
      simp only [List.length_take]
      exact Nat.le_trans (Nat.min_le_right _ _) self.slice.property⟩
    ok (some chunk, { self with slice := self.slice.drop self.size })

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Chunks<'a, @T>, &'a [@T]>}::step_by"]
def core.slice.iter.IteratorChunks.step_by {T : Type}
  (self : core.slice.iter.Chunks T) (step_by : Usize) :
  Result (core.iter.adapters.step_by.StepBy (core.slice.iter.Chunks T)) :=
  core.iter.traits.iterator.Iterator.step_by.default self step_by

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Chunks<'a, @T>, &'a [@T]>}::enumerate"]
def core.slice.iter.IteratorChunks.enumerate {T : Type}
  (self : core.slice.iter.Chunks T) :
  Result (core.iter.adapters.enumerate.Enumerate (core.slice.iter.Chunks T)) :=
  ok { iter := self, count := 0#usize }

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Chunks<'a, @T>, &'a [@T]>}::take"]
def core.slice.iter.IteratorChunks.take {T : Type}
  (self : core.slice.iter.Chunks T) (n : Usize) :
  Result (core.iter.adapters.take.Take (core.slice.iter.Chunks T)) :=
  ok ⟨self, n⟩

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Chunks<'a, @T>, &'a [@T]>}::count"]
def core.slice.iter.IteratorChunks.count {T : Type}
  (self : core.slice.iter.Chunks T) : Result (Usize × core.slice.iter.Chunks T) :=
  if h : self.slice.length = 0 then ok (0#usize, self)
  else
    let count := Usize.ofNatCore ((self.slice.length - 1) / self.size.val + 1) (by
      have := self.slice.property
      have := Nat.div_le_self (self.slice.length - 1) self.size.val
      scalar_tac)
    ok (count, self)

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Chunks<'a, @T>, &'a [@T]>}::any"]
def core.slice.iter.IteratorChunks.any {T F : Type}
  (fnInst : core.ops.function.FnMut F (Slice T) Bool)
  (self : core.slice.iter.Chunks T) (f : F) :
  Result (Bool × core.slice.iter.Chunks T × F) :=
  core.iter.traits.iterator.anyFromNext
    core.slice.iter.IteratorChunks.next fnInst self f


@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Chunks<'a, @T>, &'a [@T]>}::size_hint"]
def core.slice.iter.IteratorChunks.size_hint {T : Type}
  (self : core.slice.iter.Chunks T) : Result (Usize × Option Usize) := do
  let (n, _) ← core.slice.iter.IteratorChunks.count self
  ok (n, some n)

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::Chunks<'a, @T>, &'a [@T]>}::nth"]
def core.slice.iter.IteratorChunks.nth {T : Type}
  (self : core.slice.iter.Chunks T) (n : Usize) :
  Result (Option (Slice T) × core.slice.iter.Chunks T) :=
  let offset := n.val * self.size.val
  if h : offset < self.slice.length then
    let offset := Usize.ofNatCore offset (by
      have := self.slice.property
      simp only [Slice.length] at h
      scalar_tac)
    core.slice.iter.IteratorChunks.next { self with slice := self.slice.drop offset }
  else ok (none, { self with slice := ⟨[], by simp⟩ })
@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::slice::iter::Chunks<'a, @T>, &'a [@T]>"]
def core.iter.traits.iterator.IteratorChunks (T : Type) :
  core.iter.traits.iterator.Iterator (core.slice.iter.Chunks T) (Slice T) := {
  next := core.slice.iter.IteratorChunks.next
  step_by := core.slice.iter.IteratorChunks.step_by
  enumerate := core.slice.iter.IteratorChunks.enumerate
  take := core.slice.iter.IteratorChunks.take
  count := core.slice.iter.IteratorChunks.count
  any := core.slice.iter.IteratorChunks.any
  nth := core.slice.iter.IteratorChunks.nth
  size_hint := core.slice.iter.IteratorChunks.size_hint
  trusted_len := true
  fused := true
  random_access := some {
    is_full := true
    may_have_side_effect := false
    get_unchecked self n :=
      let offset := n.val * self.size.val
      if h : offset < self.slice.length then
        let offset := Usize.ofNatCore offset (by
          have := self.slice.property
          simp only [Slice.length] at h
          scalar_tac)
        let rest := self.slice.drop offset
        let chunk : Slice T := ⟨rest.val.take self.size.val, by
          simp only [List.length_take]
          exact Nat.le_trans (Nat.min_le_right _ _) rest.property⟩
        ok (chunk, self)
      else fail .panic
  }
}

@[rust_type "core::slice::iter::ChunksExact" (body := .opaque)]
structure core.slice.iter.ChunksExact (T : Type) where
  slice : Slice T
  remainder : Slice T
  size : Usize
  positive : 0 < size.val

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::ChunksExact<'a, @T>, &'a [@T]>}::next"]
def core.slice.iter.IteratorChunksExact.next
  {T : Type} (self : core.slice.iter.ChunksExact T) :
  Result ((Option (Slice T)) × (core.slice.iter.ChunksExact T)) :=
  if self.size.val ≤ self.slice.length then
    let chunk : Slice T := ⟨self.slice.val.take self.size.val, by
      simp only [List.length_take]
      exact Nat.le_trans (Nat.min_le_right _ _) self.slice.property⟩
    ok (some chunk, { self with slice := self.slice.drop self.size })
  else ok (none, self)

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::ChunksExact<'a, @T>, &'a [@T]>}::step_by"]
def core.slice.iter.IteratorChunksExact.step_by
  {T : Type} (self : slice.iter.ChunksExact T) (steps : Usize) :
  Result (core.iter.adapters.step_by.StepBy (slice.iter.ChunksExact T)) :=
  if steps.val = 0 then .fail .panic
  else ok { iter := self, step_by := steps }

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::ChunksExact<'a, @T>, &'a [@T]>}::enumerate"]
def core.slice.iter.IteratorChunksExact.enumerate {T : Type} (self : core.slice.iter.ChunksExact T) :
  Result (core.iter.adapters.enumerate.Enumerate (core.slice.iter.ChunksExact T)) :=
  .ok { iter := self, count := 0#usize }

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::ChunksExact<'a, @T>, &'a [@T]>}::take"]
def core.slice.iter.IteratorChunksExact.take {T : Type} (self : core.slice.iter.ChunksExact T) (n : Usize) :
  Result (core.iter.adapters.take.Take (core.slice.iter.ChunksExact T)) :=
  ok ⟨ self, n ⟩


@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::ChunksExact<'a, @T>, &'a [@T]>}::size_hint"]
def core.slice.iter.IteratorChunksExact.size_hint {T : Type}
  (self : core.slice.iter.ChunksExact T) : Result (Usize × Option Usize) :=
  let n := Usize.ofNatCore (self.slice.length / self.size.val) (by
    have := self.slice.property
    have := Nat.div_le_self self.slice.length self.size.val
    simp only [Slice.length] at *
    scalar_tac)
  ok (n, some n)

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::ChunksExact<'a, @T>, &'a [@T]>}::count"]
def core.slice.iter.IteratorChunksExact.count {T : Type}
  (self : core.slice.iter.ChunksExact T) : Result (Usize × core.slice.iter.ChunksExact T) := do
  let (n, _) ← core.slice.iter.IteratorChunksExact.size_hint self
  ok (n, self)

@[rust_fun
  "core::slice::iter::{core::iter::traits::iterator::Iterator<core::slice::iter::ChunksExact<'a, @T>, &'a [@T]>}::nth"]
def core.slice.iter.IteratorChunksExact.nth {T : Type}
  (self : core.slice.iter.ChunksExact T) (n : Usize) :
  Result (Option (Slice T) × core.slice.iter.ChunksExact T) :=
  let offset := n.val * self.size.val
  if h : offset < self.slice.length then
    let offset := Usize.ofNatCore offset (by
      have := self.slice.property
      simp only [Slice.length] at h
      scalar_tac)
    core.slice.iter.IteratorChunksExact.next { self with slice := self.slice.drop offset }
  else ok (none, { self with slice := ⟨[], by simp⟩ })
@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::slice::iter::ChunksExact<'a, @T>, &'a [@T]>"]
def core.iter.traits.iterator.IteratorChunksExact (T : Type) :
  core.iter.traits.iterator.Iterator (core.slice.iter.ChunksExact T) (Slice T)
  := {
  next := core.slice.iter.IteratorChunksExact.next
  step_by := core.slice.iter.IteratorChunksExact.step_by
  enumerate := core.slice.iter.IteratorChunksExact.enumerate
  take := core.slice.iter.IteratorChunksExact.take
  nth := core.slice.iter.IteratorChunksExact.nth
  count := core.slice.iter.IteratorChunksExact.count
  size_hint := core.slice.iter.IteratorChunksExact.size_hint
  trusted_len := true
  fused := true
  random_access := some {
    is_full := true
    may_have_side_effect := false
    get_unchecked self n :=
      let offset := n.val * self.size.val
      if h : offset + self.size.val ≤ self.slice.length then
        let offset := Usize.ofNatCore offset (by
          have := self.slice.property
          simp only [Slice.length] at h
          scalar_tac)
        let rest := self.slice.drop offset
        let chunk : Slice T := ⟨rest.val.take self.size.val, by
          simp only [List.length_take]
          exact Nat.le_trans (Nat.min_le_right _ _) rest.property⟩
        ok (chunk, self)
      else fail .panic
  }
}

@[rust_fun "core::slice::{[@T]}::chunks_exact"]
def core.slice.Slice.chunks_exact {T : Type} (s : Slice T) (chunk_size : Std.Usize) :
  Result (core.slice.iter.ChunksExact T) :=
  if h : chunk_size.val = 0 then fail .panic
  else
    let split := s.length - s.length % chunk_size.val
    let chunks : Slice T := ⟨s.val.take split, by
      simp only [List.length_take]
      exact Nat.le_trans (Nat.min_le_right _ _) s.property⟩
    let remainder : Slice T := ⟨s.val.drop split, by
      simp only [List.length_drop]
      exact Nat.le_trans (Nat.sub_le _ _) s.property⟩
    ok ⟨chunks, remainder, chunk_size, Nat.pos_of_ne_zero h⟩


-- ============================================================================
-- StepBy tests
-- ============================================================================

private def mkSliceIter (l : List Nat) (h : l.length ≤ Usize.max := by scalar_tac) :
    core.slice.iter.Iter Nat :=
  { slice := ⟨l, h⟩, i := 0 }

private def collectStepBy (sbi : core.iter.adapters.step_by.StepBy (core.slice.iter.Iter Nat))
    (fuel : Nat := 100) : Result (List Nat) :=
  match fuel with
  | 0 => .ok []
  | fuel + 1 => do
    let (opt, sbi) ←
      core.iter.adapters.step_by.IteratorStepBy.next
        (core.iter.traits.iterator.IteratorSliceIter Nat) sbi
    match opt with
    | none => .ok []
    | some x => do
      let rest ← collectStepBy sbi fuel
      .ok (x :: rest)

-- step_by(0) panics
#assert
  match core.slice.iter.IteratorSliceIter.step_by (mkSliceIter [1, 2, 3]) 0#usize with
  | .fail .panic => true
  | _ => false

-- step_by(1) returns all elements
#assert (do
  let sbi ← core.slice.iter.IteratorSliceIter.step_by (mkSliceIter [0, 1, 2, 3, 4]) 1#usize
  collectStepBy sbi) == .ok [0, 1, 2, 3, 4]

-- step_by(2) returns every other element
#assert (do
  let sbi ← core.slice.iter.IteratorSliceIter.step_by (mkSliceIter [0, 1, 2, 3, 4]) 2#usize
  collectStepBy sbi) == .ok [0, 2, 4]

-- step_by(3)
#assert (do
  let sbi ← core.slice.iter.IteratorSliceIter.step_by (mkSliceIter [0, 1, 2, 3, 4, 5, 6]) 3#usize
  collectStepBy sbi) == .ok [0, 3, 6]

-- step_by larger than collection: returns only first element
#assert (do
  let sbi ← core.slice.iter.IteratorSliceIter.step_by (mkSliceIter [0, 1, 2]) 10#usize
  collectStepBy sbi) == .ok [0]

-- step_by on empty iterator
#assert (do
  let sbi ← core.slice.iter.IteratorSliceIter.step_by (mkSliceIter []) 2#usize
  collectStepBy sbi) == .ok []

-- step_by(1) on single element
#assert (do
  let sbi ← core.slice.iter.IteratorSliceIter.step_by (mkSliceIter [42]) 1#usize
  collectStepBy sbi) == .ok [42]

-- step_by(2) on single element
#assert (do
  let sbi ← core.slice.iter.IteratorSliceIter.step_by (mkSliceIter [42]) 2#usize
  collectStepBy sbi) == .ok [42]

-- step_by equal to length: returns only first element
#assert (do
  let sbi ← core.slice.iter.IteratorSliceIter.step_by (mkSliceIter [0, 1, 2]) 3#usize
  collectStepBy sbi) == .ok [0]

-- step_by = length - 1
#assert (do
  let sbi ← core.slice.iter.IteratorSliceIter.step_by (mkSliceIter [0, 1, 2]) 2#usize
  collectStepBy sbi) == .ok [0, 2]

-- step_by(2) on two elements: returns only first
#assert (do
  let sbi ← core.slice.iter.IteratorSliceIter.step_by (mkSliceIter [0, 1]) 2#usize
  collectStepBy sbi) == .ok [0]

-- step_by(2) on three elements: returns first and third
#assert (do
  let sbi ← core.slice.iter.IteratorSliceIter.step_by (mkSliceIter [0, 1, 2]) 2#usize
  collectStepBy sbi) == .ok [0, 2]

-- step_by(4) on longer sequence
#assert (do
  let sbi ← core.slice.iter.IteratorSliceIter.step_by
    (mkSliceIter [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]) 4#usize
  collectStepBy sbi) == .ok [0, 4, 8]

-- Verify that step_by(0) on the generic Iterator.step_by.default also panics
#assert
  match core.iter.traits.iterator.Iterator.step_by.default (mkSliceIter [1]) 0#usize with
  | .fail .panic => true
  | _ => false

-- Nested step_by: step_by(2) then step_by(2) on [0..8] gives [0, 4]
private def collectNestedStepBy
    (sbi : core.iter.adapters.step_by.StepBy
      (core.iter.adapters.step_by.StepBy (core.slice.iter.Iter Nat)))
    (fuel : Nat := 100) : Result (List Nat) :=
  match fuel with
  | 0 => .ok []
  | fuel + 1 => do
    let (opt, sbi) ←
      (core.iter.traits.iterator.IteratorStepBy
        (core.iter.traits.iterator.IteratorStepBy
          (core.iter.traits.iterator.IteratorSliceIter Nat))).next sbi
    match opt with
    | none => .ok []
    | some x => do
      let rest ← collectNestedStepBy sbi fuel
      .ok (x :: rest)

#assert (do
  let sbi ← core.slice.iter.IteratorSliceIter.step_by
    (mkSliceIter [0, 1, 2, 3, 4, 5, 6, 7]) 2#usize
  let sbi2 ← core.iter.adapters.step_by.IteratorStepBy.step_by
    (core.iter.traits.iterator.IteratorSliceIter Nat) sbi 2#usize
  collectNestedStepBy sbi2) == .ok [0, 4]

end Aeneas.Std
