import Aeneas.Std.String
import Aeneas.Std.Core.Iter
import Aeneas.Std.SliceIter

namespace Aeneas.Std

/-- `core::str::pattern::CharArraySearcher<'a, N>`, the searcher of a `[char; N]`
    needle (a `MultiCharEqSearcher` over the haystack's `char_indices`). As for
    `CharSearcher`, only its construction data are modeled. -/
@[rust_type "core::str::pattern::CharArraySearcher" (body := .opaque)]
structure core.str.pattern.CharArraySearcher (N : Usize) where
  haystack : Str
  needles : Array Char N

/-- The successive `next_match` results of a `MultiCharEqSearcher` (core
    str/pattern.rs, rustc 1.95): its `next` steps through `char_indices`, a
    `Match` of the char's byte range when `char_eq.matches(c)` holds (`isNeedle`), else a
    `Reject`, so `next_match` returns the byte ranges of the matching chars,
    from the first. `next_back` steps through `char_indices` from the back:
    `next_match_back` returns the same ranges from the last. -/
def core.str.pattern.MultiCharEqSearcher.forwardMatches (haystack : Str)
    (isNeedle : Char → Bool) : Result (List (Nat × Nat)) := do
  let chars := (← Str.toString haystack).toList
  let starts := chars.scanl (fun pos char => pos + char.utf8Size) 0
  .ok ((chars.zip starts).filterMap fun (char, pos) =>
    if isNeedle char then some (pos, pos + char.utf8Size) else none)

/-- `impl Searcher for CharArraySearcher`, pattern.rs: `haystack` returns the
    haystack of its `MultiCharEqSearcher`. -/
@[rust_fun
  "core::str::pattern::{core::str::pattern::Searcher<'a, core::str::pattern::CharArraySearcher<'a, @N>>}::haystack"]
def core.str.pattern.SearcherCharArraySearcher.haystack {N : Usize}
    (self : core.str.pattern.CharArraySearcher N) : Result Str :=
  .ok self.haystack

@[reducible, rust_trait_impl
  "core::str::pattern::Searcher<'a, core::str::pattern::CharArraySearcher<'a, @N>>"]
def core.str.pattern.SearcherCharArraySearcher (N : Usize) :
    core.str.pattern.Searcher (core.str.pattern.CharArraySearcher N) := {
  haystack := core.str.pattern.SearcherCharArraySearcher.haystack
}

@[reducible, rust_trait_impl
  "core::str::pattern::ReverseSearcher<'a, core::str::pattern::CharArraySearcher<'a, @N>>"]
def core.str.pattern.ReverseSearcherCharArraySearcher (N : Usize) :
    core.str.pattern.ReverseSearcher (core.str.pattern.CharArraySearcher N) := {
  searcherInst := core.str.pattern.SearcherCharArraySearcher N
}

/-- `impl Pattern for [char; N]`, pattern.rs: the methods of
    `MultiCharEqPattern(self)`, whose searcher is `CharArraySearcher` and whose
    `char_eq.matches(c)` is `self.contains(&c)`. Its `is_prefix_of` is
    `Pattern`'s default, `matches!(self.into_searcher(haystack).next(),
    SearchStep::Match(0, _))`: the haystack's first char is in the array. -/
@[rust_fun "core::str::pattern::{core::str::pattern::Pattern<[char; @N]>}::is_prefix_of"]
def core.str.pattern.PatternCharArray.is_prefix_of {N : Usize} (needles : Array Char N)
    (haystack : Str) : Result Bool := do
  match (← Str.toString haystack).toList with
  | [] => .ok false
  | char :: _ => .ok (needles.val.contains char)

@[reducible, rust_trait_impl "core::str::pattern::Pattern<[char; @N]>"]
def core.str.pattern.PatternCharArray (N : Usize) : core.str.pattern.Pattern (Array Char N) := {
  is_prefix_of := core.str.pattern.PatternCharArray.is_prefix_of
  forward_matches := some fun needles haystack =>
    core.str.pattern.MultiCharEqSearcher.forwardMatches haystack (needles.val.contains ·)
  reverse_matches := some fun needles haystack => do
    .ok (← core.str.pattern.MultiCharEqSearcher.forwardMatches haystack
      (needles.val.contains ·)).reverse
}

@[rust_type "core::str::iter::Chars" (body := .opaque)]
structure core.str.iter.Chars where
  iter : core.slice.iter.Iter U8

/-- Decode the remaining continuation bytes, advancing the byte iterator itself.
`Str` is represented by an unconstrained byte slice, unlike Rust's valid UTF-8
`str`: malformed encodings are undefined, never replacement characters. The
minimum scalar excludes overlong encodings; scalar validity excludes surrogates
and values above U+10FFFF. Validation is performed as bytes are consumed. -/
def core.str.iter.IteratorChars.decodeUtf8
  (remaining value minimum : Nat) (it : core.slice.iter.Iter U8) :
  Result (Char × core.slice.iter.Iter U8) :=
  match remaining with
  | 0 =>
    if minimum ≤ value then
      if h : Char.isValidCharNat value then
        .ok (⟨UInt32.ofNatLT value (Char.isValidUInt32 value h),
          Char.isValidChar_of_isValidCharNat value h⟩, it)
      else .fail .undef
    else .fail .undef
  | remaining + 1 => do
    let (byte, it) ← core.slice.iter.IteratorSliceIter.next it
    match byte with
    | none => .fail .undef
    | some byte =>
      if 0x80 ≤ byte.val ∧ byte.val < 0xc0 then
        core.str.iter.IteratorChars.decodeUtf8 remaining
          (value * 64 + (byte.val - 0x80)) minimum it
      else .fail .undef

@[rust_fun
  "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Chars<'a>, char>}::next"]
def core.str.iter.IteratorChars.next (self : core.str.iter.Chars) :
  Result (Option Char × core.str.iter.Chars) := do
  let (byte, it) ← core.slice.iter.IteratorSliceIter.next self.iter
  match byte with
  | none => .ok (none, { iter := it })
  | some byte =>
    let (char, it) ←
      if byte.val < 0x80 then
        core.str.iter.IteratorChars.decodeUtf8 0 byte.val 0 it
      else if 0xc2 ≤ byte.val ∧ byte.val < 0xe0 then
        core.str.iter.IteratorChars.decodeUtf8 1 (byte.val - 0xc0) 0x80 it
      else if 0xe0 ≤ byte.val ∧ byte.val < 0xf0 then
        core.str.iter.IteratorChars.decodeUtf8 2 (byte.val - 0xe0) 0x800 it
      else if 0xf0 ≤ byte.val ∧ byte.val < 0xf5 then
        core.str.iter.IteratorChars.decodeUtf8 3 (byte.val - 0xf0) 0x10000 it
      else .fail .undef
    .ok (some char, { iter := it })

@[rust_fun
  "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Chars<'a>, char>}::size_hint"]
def core.str.iter.IteratorChars.size_hint (self : core.str.iter.Chars) :
    Result (Usize × Option Usize) := do
  let (bytes, _) ← core.slice.iter.IteratorSliceIter.size_hint self.iter
  let lower ← UScalar.tryMk .Usize ((bytes.val + 3) / 4)
  .ok (lower, some bytes)

@[rust_fun
  "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Chars<'a>, char>}::count"]
def core.str.iter.IteratorChars.count (self : core.str.iter.Chars) :
    Result (Usize × core.str.iter.Chars) := do
  let (count, _) ← core.iter.traits.iterator.countFromNext
    core.str.iter.IteratorChars.next self 0#usize
  .ok (count, self)

@[rust_fun
  "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Chars<'a>, char>}::advance_by"]
def core.str.iter.IteratorChars.advance_by (self : core.str.iter.Chars) (n : Usize) :
    Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) × core.str.iter.Chars) :=
  core.iter.traits.iterator.advanceByFromNext core.str.iter.IteratorChars.next self n

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::str::iter::Chars<'a>, char>"]
def core.iter.traits.iterator.IteratorChars :
  core.iter.traits.iterator.Iterator core.str.iter.Chars Char := {
  next := core.str.iter.IteratorChars.next
  size_hint := core.str.iter.IteratorChars.size_hint
  count := core.str.iter.IteratorChars.count
  advance_by := core.str.iter.IteratorChars.advance_by
  fused := true
}

@[rust_fun
  "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Chars<'a>, char>}::collect"]
def core.str.iter.IteratorChars.collect
  {B : Type} (itertraitscollectFromIteratorBCharInst :
  core.iter.traits.collect.FromIterator B Char) :
  core.str.iter.Chars → Result (B × core.str.iter.Chars) :=
  core.iter.traits.iterator.Iterator.collect.default
    core.iter.traits.iterator.IteratorChars itertraitscollectFromIteratorBCharInst

@[rust_fun "core::str::{str}::chars"]
def core.str.Str.chars (s : Str) : Result core.str.iter.Chars :=
  .ok { iter := { slice := s, i := 0 } }

/-- `core::str::Lines<'a>` (core/src/str/iter.rs, rustc 1.95) is
    `Map<SplitInclusive<'a, char>, LinesMap>` over `'\n'`. The model keeps
    the split's unsearched remainder `haystack[start..end]` and its `finished`
    flag; the byte `0x0A` is exactly the encoding of `'\n'` in UTF-8. -/
@[rust_type "core::str::iter::Lines" (body := .opaque)]
structure core.str.iter.Lines where
  rest : Str
  finished : Bool

/-- `str::lines` (core/src/str/mod.rs): `Lines(self.split_inclusive('\n').map(LinesMap))`. -/
@[rust_fun "core::str::{str}::lines"]
def core.str.Str.lines (s : Str) : Result core.str.iter.Lines :=
  .ok { rest := s, finished := false }

/-- `LinesMap` (core/src/str/mod.rs): strip one trailing `'\n'`, and then, only
    if there was one, one `'\r'` before it. A lone trailing `'\r'` stays. -/
def core.str.iter.Lines.strip (line : List U8) : List U8 :=
  if line.getLast?.map (·.val) = some 0x0A then
    if line.dropLast.getLast?.map (·.val) = some 0x0D then line.dropLast.dropLast
    else line.dropLast
  else line

theorem core.str.iter.Lines.strip_length (line : List U8) :
    (core.str.iter.Lines.strip line).length ≤ line.length := by
  unfold core.str.iter.Lines.strip
  split
  · split <;> simp only [List.length_dropLast] <;> omega
  · exact Nat.le_refl _

/-- A sub-list of a string view is a string view. -/
def core.str.iter.Lines.view (s : Str) (bytes : List U8) (h : bytes.length ≤ s.val.length) :
    Str :=
  ⟨bytes, Nat.le_trans h s.property⟩

/-- `Lines::next` = `SplitInternal::next_inclusive` then `LinesMap`
    (core/src/str/iter.rs): the text up to and including the next `'\n'`;
    at the last match, `get_end` yields the unterminated remainder only if it
    is nonempty (`allow_trailing_empty` is false), and finishes. -/
@[rust_fun
  "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Lines<'a>, &'a str>}::next"]
def core.str.iter.IteratorLines.next (self : core.str.iter.Lines) :
    Result (Option Str × core.str.iter.Lines) :=
  if self.finished then .ok (none, self)
  else
    match self.rest.val.findIdx? (fun byte => byte.val = 0x0A) with
    | some index =>
      let line := self.rest.val.take (index + 1)
      .ok (some (core.str.iter.Lines.view self.rest (core.str.iter.Lines.strip line)
          (Nat.le_trans (core.str.iter.Lines.strip_length line) (List.length_take_le' _ _))),
        { rest := core.str.iter.Lines.view self.rest (self.rest.val.drop (index + 1))
            (by simp only [List.length_drop]; omega),
          finished := false })
    | none =>
      let finished := { self with finished := true }
      if self.rest.val.isEmpty then .ok (none, finished)
      else
        .ok (some (core.str.iter.Lines.view self.rest (core.str.iter.Lines.strip self.rest.val)
            (core.str.iter.Lines.strip_length self.rest.val)), finished)

/-- `Lines::size_hint` is the split's, which keeps `Iterator`'s default. -/
@[rust_fun
  "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Lines<'a>, &'a str>}::size_hint"]
def core.str.iter.IteratorLines.size_hint (_self : core.str.iter.Lines) :
    Result (Usize × Option Usize) :=
  .ok (0#usize, none)

/-- `Lines` overrides `next`, `size_hint` and `last` (as `next_back`, unmodeled);
    `fold` and the other consumers are `Iterator`'s next-driven defaults.
    `impl FusedIterator for Lines`. -/
@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::str::iter::Lines<'a>, &'a str>"]
def core.iter.traits.iterator.IteratorLines :
  core.iter.traits.iterator.Iterator core.str.iter.Lines Str := {
  next := core.str.iter.IteratorLines.next
  size_hint := core.str.iter.IteratorLines.size_hint
  fused := true
}

/-- `core::str::Split<'a, P>(SplitInternal<'a, P>)` (core/src/str/iter.rs,
    rustc 1.95): `SplitInternal { start, end, matcher, allow_trailing_empty,
    finished }`, which `str::split` builds with `start = 0`, `end = len` and
    `allow_trailing_empty = true`. The model keeps the haystack, `start`,
    `finished`, and the searcher `matcher` as the list `pending` of its
    remaining `next_match` results (`Pattern.forward_matches`). -/
@[rust_type "core::str::iter::Split" (body := .opaque)]
structure core.str.iter.Split (P : Type) where
  haystack : Str
  start : Nat
  pending : List (Nat × Nat)
  finished : Bool

/-- `haystack.get_unchecked(start..stop)`. -/
def core.str.iter.Split.piece (haystack : Str) (start stop : Nat) : Str :=
  ⟨(haystack.val.drop start).take (stop - start),
    Nat.le_trans (List.length_take_le' _ _)
      (Nat.le_trans (by simp only [List.length_drop]; omega) haystack.property)⟩

/-- `str::split` (core/src/str/mod.rs): `Split(SplitInternal { start: 0,
    end: self.len(), matcher: pat.into_searcher(self), allow_trailing_empty:
    true, finished: false })`. -/
@[rust_fun "core::str::{str}::split"]
def core.str.Str.split {P : Type} (patInst : core.str.pattern.Pattern P)
    (s : Str) (pat : P) : Result (core.str.iter.Split P) :=
  match patInst.forward_matches with
  | none => .fail .panic
  | some search => do
    let pending ← search pat s
    .ok { haystack := s, start := 0, pending, finished := false }

/-- `str::rsplit_once` (core/src/str/mod.rs): `let (start, end) =
    delimiter.into_searcher(self).next_match_back()?; Some((self[..start],
    self[end..]))`, the text around the last match of the reverse searcher. Its
    `for<'a> P::Searcher<'a>: ReverseSearcher<'a>` clause only states that the
    searcher searches backwards: the model reads that match from
    `Pattern.reverse_matches`. -/
@[rust_fun "core::str::{str}::rsplit_once" (keepTraitClauses := [true, false])]
def core.str.Str.rsplit_once {P : Type} (patInst : core.str.pattern.Pattern P)
    (s : Str) (delimiter : P) : Result (Option (Str × Str)) :=
  match patInst.reverse_matches with
  | none => .fail .panic
  | some search => do
    match ← search delimiter s with
    | [] => .ok none
    | (start, stop) :: _ =>
      .ok (some (core.str.iter.Split.piece s 0 start,
        core.str.iter.Split.piece s stop s.val.length))

/-- `str::as_bytes` (core/src/str/mod.rs): the same bytes, a `str` being modeled by its
    UTF-8 byte slice. -/
@[rust_fun "core::str::{str}::as_bytes"]
def core.str.Str.as_bytes (s : Str) : Result (Slice U8) := .ok s

/-- `str::split_once` (core/src/str/mod.rs): `let (start, end) =
    delimiter.into_searcher(self).next_match()?; Some((self[..start], self[end..]))`, the text
    around the first match of the forward searcher (`Pattern.forward_matches`). -/
@[rust_fun "core::str::{str}::split_once"]
def core.str.Str.split_once {P : Type} (patInst : core.str.pattern.Pattern P)
    (s : Str) (delimiter : P) : Result (Option (Str × Str)) :=
  match patInst.forward_matches with
  | none => .fail .panic
  | some search => do
    match ← search delimiter s with
    | [] => .ok none
    | (start, stop) :: _ =>
      .ok (some (core.str.iter.Split.piece s 0 start,
        core.str.iter.Split.piece s stop s.val.length))

/-- `str::strip_prefix` (core/src/str/mod.rs): `prefix.strip_prefix_of(self)`. `Pattern`'s
    `strip_prefix_of` takes the first step of `self.into_searcher(haystack)`: `Match(0, len)`
    gives `Some(haystack[len..])`, any other step `None`; the overrides of `&str`
    (`haystack[self.len()..]` when `is_prefix_of`) and `char` (its UTF-8 encoding as a `&str`)
    decide the same. The first step of a searcher is a match exactly when its first match
    starts at 0. -/
@[rust_fun "core::str::{str}::strip_prefix"]
def core.str.Str.strip_prefix {P : Type} (patInst : core.str.pattern.Pattern P)
    (s : Str) (pre : P) : Result (Option Str) :=
  match patInst.forward_matches with
  | none => .fail .panic
  | some search => do
    match ← search pre s with
    | (0, stop) :: _ => .ok (some (core.str.iter.Split.piece s stop s.val.length))
    | _ => .ok none

/-- `str::strip_suffix` (core/src/str/mod.rs): `suffix.strip_suffix_of(self)`, the reverse
    of `strip_prefix`: the first step of the reverse searcher is a match `(start, len)`
    exactly when its first reverse match ends at `len`, giving `Some(haystack[..start])`. -/
@[rust_fun "core::str::{str}::strip_suffix" (keepTraitClauses := [true, false])]
def core.str.Str.strip_suffix {P : Type} (patInst : core.str.pattern.Pattern P)
    (s : Str) (suf : P) : Result (Option Str) :=
  match patInst.reverse_matches with
  | none => .fail .panic
  | some search => do
    match ← search suf s with
    | (start, stop) :: _ =>
      if stop = s.val.length then .ok (some (core.str.iter.Split.piece s 0 start))
      else .ok none
    | [] => .ok none

/-- `str::ends_with` (core/src/str/mod.rs): `pat.is_suffix_of(self)`. `Pattern`'s
    `is_suffix_of` is `matches!(self.into_searcher(haystack).next_back(), Match(_, j) if
    haystack.len() == j)`; the overrides of `&str` (`haystack.as_bytes().ends_with(self)`) and
    `char` (its UTF-8 encoding as a `&str`) decide the same: whether the first match of the
    reverse searcher ends at the end of the haystack, as for `strip_suffix`. -/
@[rust_fun "core::str::{str}::ends_with" (keepTraitClauses := [true, false])]
def core.str.Str.ends_with {P : Type} (patInst : core.str.pattern.Pattern P)
    (s : Str) (pat : P) : Result Bool :=
  match patInst.reverse_matches with
  | none => .fail .panic
  | some search => do
    match ← search pat s with
    | (_, stop) :: _ => .ok (stop = s.val.length)
    | [] => .ok false

/-- `str::rfind` (core/src/str/mod.rs): `pat.into_searcher(self).next_match_back().map(|(i,
    _)| i)`, the start of the first match of the reverse searcher (`Pattern.reverse_matches`),
    a byte index of the haystack. -/
@[rust_fun "core::str::{str}::rfind" (keepTraitClauses := [true, false])]
def core.str.Str.rfind {P : Type} (patInst : core.str.pattern.Pattern P)
    (s : Str) (pat : P) : Result (Option Usize) :=
  match patInst.reverse_matches with
  | none => .fail .panic
  | some search => do
    match ← search pat s with
    | [] => .ok none
    | (start, _) :: _ => .ok (some (← UScalar.tryMk .Usize start))

/-- The end of the run of adjacent matches from `pos` on, in the searcher's order: where its
    first `Reject` step starts (`next_reject`), or the end of the haystack if there is none. -/
def core.str.pattern.forwardRunEnd : List (Nat × Nat) → Nat → Nat
  | [], pos => pos
  | (start, stop) :: rest, pos =>
    if start = pos then core.str.pattern.forwardRunEnd rest stop else pos

/-- The start of the run of adjacent reverse matches ending at `pos`: where the first
    `Reject` step of the reverse searcher ends (`next_reject_back`), or 0 if there is none. -/
def core.str.pattern.reverseRunStart : List (Nat × Nat) → Nat → Nat
  | [], pos => pos
  | (start, stop) :: rest, pos =>
    if stop = pos then core.str.pattern.reverseRunStart rest start else pos

/-- `str::trim_start_matches` (core/src/str/mod.rs): `i = self.len()`, then `i = a` for the
    first `Reject(a, _)` of `pat.into_searcher(self)`; `self[i..]`. The searcher steps
    through the haystack: its matches from 0 are adjacent until the first reject, so `i` is
    the end of the run of adjacent matches from 0 (the whole haystack without a reject). An
    empty `&str` needle matches at 0 and then rejects the first char: `i = 0`. -/
@[rust_fun "core::str::{str}::trim_start_matches"]
def core.str.Str.trim_start_matches {P : Type} (patInst : core.str.pattern.Pattern P)
    (s : Str) (pat : P) : Result Str :=
  match patInst.forward_matches with
  | none => .fail .panic
  | some search => do
    let i := core.str.pattern.forwardRunEnd (← search pat s) 0
    .ok (core.str.iter.Split.piece s i s.val.length)

/-- `str::trim_end_matches` (core/src/str/mod.rs): `j = 0`, then `j = b` for the first
    `Reject(_, b)` of the reverse searcher; `self[..j]`: the start of the run of adjacent
    reverse matches ending at the end (0 without a reject). -/
@[rust_fun "core::str::{str}::trim_end_matches" (keepTraitClauses := [true, false])]
def core.str.Str.trim_end_matches {P : Type} (patInst : core.str.pattern.Pattern P)
    (s : Str) (pat : P) : Result Str :=
  match patInst.reverse_matches with
  | none => .fail .panic
  | some search => do
    let j := core.str.pattern.reverseRunStart (← search pat s) s.val.length
    .ok (core.str.iter.Split.piece s 0 j)

/-- `char::is_whitespace` (core/src/char/methods.rs, rustc 1.95): `' '` and `'\x09'..='\x0d'`,
    or above `'\x7f'` the Unicode `White_Space` property (core/src/unicode/unicode_data.rs
    `white_space`): U+0085, U+00A0, U+1680, U+2000..=U+200A, U+2028, U+2029, U+202F, U+205F
    and U+3000. -/
def core.char.methods.Char.isWhitespace (c : Char) : Bool :=
  c.val = 0x20 || (0x09 ≤ c.val && c.val ≤ 0x0D) ||
    (0x7F < c.val &&
      (c.val = 0x85 || c.val = 0xA0 || c.val = 0x1680 || (0x2000 ≤ c.val && c.val ≤ 0x200A) ||
        c.val = 0x2028 || c.val = 0x2029 || c.val = 0x202F || c.val = 0x205F || c.val = 0x3000))

/-- `char::is_whitespace` (core/src/char/methods.rs). -/
@[rust_fun "core::char::methods::{char}::is_whitespace"]
def core.char.methods.Char.is_whitespace (c : Char) : Result Bool :=
  .ok (core.char.methods.Char.isWhitespace c)

/-- `str::trim` (core/src/str/mod.rs): `self.trim_matches(char::is_whitespace)`, whose
    `CharPredicateSearcher` steps char by char: `i` is the start of the first non-whitespace
    char (from `next_reject`), `j` the end of the last one (from `next_reject_back`), and both
    stay 0 when every char is whitespace; `self[i..j]`. -/
@[rust_fun "core::str::{str}::trim"]
def core.str.Str.trim (s : Str) : Result Str := do
  let chars := (← Str.toString s).toList
  let size (cs : List Char) := cs.foldl (fun n c => n + c.utf8Size) 0
  let lead := size (chars.takeWhile core.char.methods.Char.isWhitespace)
  let trail := size (chars.reverse.takeWhile core.char.methods.Char.isWhitespace)
  .ok (core.str.iter.Split.piece s lead (s.val.length - trail))

/-- The text of `str::replace` from the match list: the pieces between matches, each match
    replaced by `to`. -/
def alloc.str.Str.replaceFrom (s to_ : Str) : List (Nat × Nat) → Nat → String → Result String
  | [], last, acc => do
    .ok (acc ++ (← Str.toString (core.str.iter.Split.piece s last s.val.length)))
  | (start, stop) :: rest, last, acc => do
    let piece ← Str.toString (core.str.iter.Split.piece s last start)
    alloc.str.Str.replaceFrom s to_ rest stop (acc ++ piece ++ (← Str.toString to_))

/-- `str::replace` (alloc/src/str.rs, rustc 1.95): for each `(start, part)` of
    `self.match_indices(from)` (the forward searcher's matches), push `self[last_end..start]`
    then `to`, and `last_end = start + part.len()`; finally push `self[last_end..]`. The fast
    path replacing a one-byte ASCII pattern by a one-byte `to` rewrites exactly those bytes:
    the same text. The capacity (`self.len()` or 0) is not observable. -/
@[rust_fun "alloc::str::{str}::replace"]
def alloc.str.Str.replace {P : Type} (patInst : core.str.pattern.Pattern P)
    (s : Str) (from_ : P) (to_ : Str) : Result String :=
  match patInst.forward_matches with
  | none => .fail .panic
  | some search => do
    alloc.str.Str.replaceFrom s to_ (← search from_ s) 0 ""

/-! ### Indexing `str` by ranges (core/src/str/traits.rs, rustc 1.95) -/

/-- `str::is_char_boundary` (core/src/str/mod.rs): `index == 0`, or `index == len`, or
    `index < len` and the byte at `index` is not a UTF-8 continuation byte (`b as i8 >= -0x40`,
    i.e. `b < 0x80 || b >= 0xC0`); false beyond the end. -/
def core.str.Str.isCharBoundary (s : Str) (index : Nat) : Bool :=
  index == 0 || index == s.val.length ||
    (match s.val[index]? with
     | some b => b.val < 0x80 || 0xC0 ≤ b.val
     | none => false)

@[rust_fun "core::str::{str}::is_char_boundary"]
def core.str.Str.is_char_boundary (s : Str) (index : Usize) : Result Bool :=
  .ok (core.str.Str.isCharBoundary s index.val)

/-- The bytes `start..stop` of `s` given back into `s` after a mutable borrow of them. -/
def core.str.Str.setRange (s : Str) (start stop : Nat) (piece : Str) : Str :=
  if h : start + piece.val.length + (s.val.length - stop) ≤ Usize.max then
    ⟨s.val.take start ++ piece.val ++ s.val.drop stop, by
      simp only [List.length_append, List.length_take, List.length_drop]; omega⟩
  else s

/-- `impl Index<I> for str where I: SliceIndex<str>` (core/src/str/traits.rs):
    `index.index(self)`. -/
@[rust_fun "core::str::traits::{core::ops::index::Index<str, @I, @O>}::index"]
def core.str.traits.IndexStr.index {I Output : Type}
    (inst : core.slice.index.SliceIndex I Str Output) (s : Str) (i : I) : Result Output :=
  inst.index i s

/-- `impl IndexMut<I> for str` (core/src/str/traits.rs): `index.index_mut(self)`. -/
@[rust_fun "core::str::traits::{core::ops::index::IndexMut<str, @I, @O>}::index_mut"]
def core.str.traits.IndexMutStr.index_mut {I Output : Type}
    (inst : core.slice.index.SliceIndex I Str Output) (s : Str) (i : I) :
    Result (Output × (Output → Str)) :=
  inst.index_mut i s

/-- `SliceIndex<str> for RangeFrom<usize>` (core/src/str/traits.rs): `get` is `Some(&slice[start..])`
    iff `slice.is_char_boundary(start)` (false beyond the end); `index` panics
    (`slice_error_fail`) where `get` is `None`. `get_unchecked` requires what `get` checks
    (unsafe precondition): not modeled. -/
@[rust_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::RangeFrom<usize>, str, str>}::get"]
def core.str.traits.SliceIndexRangeFromUsizeStr.get (r : core.ops.range.RangeFrom Usize) (s : Str) :
    Result (Option Str) :=
  .ok (if core.str.Str.isCharBoundary s r.start.val then
    some (core.str.iter.Split.piece s r.start.val s.val.length) else none)

@[rust_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::RangeFrom<usize>, str, str>}::get_mut"]
def core.str.traits.SliceIndexRangeFromUsizeStr.get_mut (r : core.ops.range.RangeFrom Usize) (s : Str) :
    Result (Option Str × (Option Str → Str)) :=
  if core.str.Str.isCharBoundary s r.start.val then
    .ok (some (core.str.iter.Split.piece s r.start.val s.val.length), fun
      | some piece => core.str.Str.setRange s r.start.val s.val.length piece
      | none => s)
  else .ok (none, fun _ => s)

@[rust_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::RangeFrom<usize>, str, str>}::get_unchecked"]
def core.str.traits.SliceIndexRangeFromUsizeStr.get_unchecked :
    core.ops.range.RangeFrom Usize → ConstRawPtr Str → Result (ConstRawPtr Str) :=
  fun _ _ => .fail .undef

@[rust_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::RangeFrom<usize>, str, str>}::get_unchecked_mut"]
def core.str.traits.SliceIndexRangeFromUsizeStr.get_unchecked_mut :
    core.ops.range.RangeFrom Usize → MutRawPtr Str → Result (MutRawPtr Str) :=
  fun _ _ => .fail .undef

@[rust_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::RangeFrom<usize>, str, str>}::index"]
def core.str.traits.SliceIndexRangeFromUsizeStr.index (r : core.ops.range.RangeFrom Usize) (s : Str) :
    Result Str :=
  if core.str.Str.isCharBoundary s r.start.val then
    .ok (core.str.iter.Split.piece s r.start.val s.val.length)
  else .fail .panic

@[rust_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::RangeFrom<usize>, str, str>}::index_mut"]
def core.str.traits.SliceIndexRangeFromUsizeStr.index_mut (r : core.ops.range.RangeFrom Usize) (s : Str) :
    Result (Str × (Str → Str)) :=
  if core.str.Str.isCharBoundary s r.start.val then
    .ok (core.str.iter.Split.piece s r.start.val s.val.length,
      core.str.Str.setRange s r.start.val s.val.length)
  else .fail .panic

@[reducible, rust_trait_impl "core::slice::index::SliceIndex<core::ops::range::RangeFrom<usize>, str, str>"]
def core.slice.index.SliceIndexRangeFromUsizeStr :
    core.slice.index.SliceIndex (core.ops.range.RangeFrom Usize) Str Str := {
  sealedInst := core.slice.index.private_slice_index.SealedRangeFromUsize
  get := core.str.traits.SliceIndexRangeFromUsizeStr.get
  get_mut := core.str.traits.SliceIndexRangeFromUsizeStr.get_mut
  get_unchecked := core.str.traits.SliceIndexRangeFromUsizeStr.get_unchecked
  get_unchecked_mut := core.str.traits.SliceIndexRangeFromUsizeStr.get_unchecked_mut
  index := core.str.traits.SliceIndexRangeFromUsizeStr.index
  index_mut := core.str.traits.SliceIndexRangeFromUsizeStr.index_mut
}

/-- `SliceIndex<str> for RangeTo<usize>` (core/src/str/traits.rs): `Some(&slice[..end])` iff
    `slice.is_char_boundary(end)`; `index` panics where `get` is `None`. -/
@[rust_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::RangeTo<usize>, str, str>}::get"]
def core.str.traits.SliceIndexRangeToUsizeStr.get (r : core.ops.range.RangeTo Usize) (s : Str) :
    Result (Option Str) :=
  .ok (if core.str.Str.isCharBoundary s r.«end».val then
    some (core.str.iter.Split.piece s 0 r.«end».val) else none)

@[rust_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::RangeTo<usize>, str, str>}::get_mut"]
def core.str.traits.SliceIndexRangeToUsizeStr.get_mut (r : core.ops.range.RangeTo Usize) (s : Str) :
    Result (Option Str × (Option Str → Str)) :=
  if core.str.Str.isCharBoundary s r.«end».val then
    .ok (some (core.str.iter.Split.piece s 0 r.«end».val), fun
      | some piece => core.str.Str.setRange s 0 r.«end».val piece
      | none => s)
  else .ok (none, fun _ => s)

@[rust_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::RangeTo<usize>, str, str>}::get_unchecked"]
def core.str.traits.SliceIndexRangeToUsizeStr.get_unchecked :
    core.ops.range.RangeTo Usize → ConstRawPtr Str → Result (ConstRawPtr Str) :=
  fun _ _ => .fail .undef

@[rust_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::RangeTo<usize>, str, str>}::get_unchecked_mut"]
def core.str.traits.SliceIndexRangeToUsizeStr.get_unchecked_mut :
    core.ops.range.RangeTo Usize → MutRawPtr Str → Result (MutRawPtr Str) :=
  fun _ _ => .fail .undef

@[rust_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::RangeTo<usize>, str, str>}::index"]
def core.str.traits.SliceIndexRangeToUsizeStr.index (r : core.ops.range.RangeTo Usize) (s : Str) :
    Result Str :=
  if core.str.Str.isCharBoundary s r.«end».val then .ok (core.str.iter.Split.piece s 0 r.«end».val)
  else .fail .panic

@[rust_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::RangeTo<usize>, str, str>}::index_mut"]
def core.str.traits.SliceIndexRangeToUsizeStr.index_mut (r : core.ops.range.RangeTo Usize) (s : Str) :
    Result (Str × (Str → Str)) :=
  if core.str.Str.isCharBoundary s r.«end».val then
    .ok (core.str.iter.Split.piece s 0 r.«end».val, core.str.Str.setRange s 0 r.«end».val)
  else .fail .panic

@[reducible, rust_trait_impl "core::slice::index::SliceIndex<core::ops::range::RangeTo<usize>, str, str>"]
def core.slice.index.SliceIndexRangeToUsizeStr :
    core.slice.index.SliceIndex (core.ops.range.RangeTo Usize) Str Str := {
  sealedInst := core.slice.index.private_slice_index.SealedRangeToUsize
  get := core.str.traits.SliceIndexRangeToUsizeStr.get
  get_mut := core.str.traits.SliceIndexRangeToUsizeStr.get_mut
  get_unchecked := core.str.traits.SliceIndexRangeToUsizeStr.get_unchecked
  get_unchecked_mut := core.str.traits.SliceIndexRangeToUsizeStr.get_unchecked_mut
  index := core.str.traits.SliceIndexRangeToUsizeStr.index
  index_mut := core.str.traits.SliceIndexRangeToUsizeStr.index_mut
}

/-- `Split::next` = `SplitInternal::next`: the text from `start` to the next
    match, resuming after it; once the searcher has no match left, `get_end`
    yields the rest `start..end` (even when empty, as `allow_trailing_empty`
    holds) and finishes. -/
@[rust_fun
  "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Split<'a, @P>, &'a str>}::next"]
def core.str.iter.IteratorSplit.next {P : Type} (_patInst : core.str.pattern.Pattern P)
    (self : core.str.iter.Split P) : Result (Option Str × core.str.iter.Split P) :=
  if self.finished then .ok (none, self)
  else
    match self.pending with
    | (a, b) :: pending =>
      .ok (some (core.str.iter.Split.piece self.haystack self.start a),
        { self with start := b, pending })
    | [] =>
      .ok (some (core.str.iter.Split.piece self.haystack self.start self.haystack.val.length),
        { self with finished := true })

/-- The `Iterator` impl of `Split` (`generate_pattern_iterators!`) defines only
    `next`: `size_hint` is the default `(0, None)` and every consumer is
    next-driven. `impl<'a, P: Pattern> FusedIterator for Split<'a, P>`. -/
@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::str::iter::Split<'a, @P>, &'a str>"]
def core.iter.traits.iterator.IteratorSplit {P : Type} (patInst : core.str.pattern.Pattern P) :
  core.iter.traits.iterator.Iterator (core.str.iter.Split P) Str := {
  next := core.str.iter.IteratorSplit.next patInst
  fused := true
}

/-- `SplitInternal::get_end` of a split built by `str::split` (`allow_trailing_empty` holds): unless
    finished, the rest `start..end` (even when empty), finishing; `None` once finished. -/
def core.str.iter.Split.getEnd {P : Type} (self : core.str.iter.Split P) :
    Option Str × core.str.iter.Split P :=
  if self.finished then (none, self)
  else
    (some (core.str.iter.Split.piece self.haystack self.start self.haystack.val.length),
      { self with finished := true })

/-- `core::str::SplitN<'a, P>(SplitNInternal<'a, P>)` (core/src/str/iter.rs, rustc 1.95):
    `SplitNInternal { iter: SplitInternal<'a, P>, count }`, the split and the number of pieces
    left. -/
@[rust_type "core::str::iter::SplitN" (body := .opaque)]
structure core.str.iter.SplitN (P : Type) where
  iter : core.str.iter.Split P
  count : Nat

/-- `str::splitn` (core/src/str/mod.rs): `SplitN(SplitNInternal { iter: self.split(pat).0,
    count: n })`. -/
@[rust_fun "core::str::{str}::splitn"]
def core.str.Str.splitn {P : Type} (patInst : core.str.pattern.Pattern P)
    (s : Str) (n : Usize) (pat : P) : Result (core.str.iter.SplitN P) := do
  let iter ← core.str.Str.split patInst s pat
  .ok { iter, count := n.val }

/-- `SplitN::next` = `SplitNInternal::next`: `None` once `count` is 0; at 1 the rest of the split
    (`get_end`), `count` becoming 0; above, `count - 1` and the split's next piece. -/
@[rust_fun
  "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::SplitN<'a, @P>, &'a str>}::next"]
def core.str.iter.IteratorSplitN.next {P : Type} (patInst : core.str.pattern.Pattern P)
    (self : core.str.iter.SplitN P) : Result (Option Str × core.str.iter.SplitN P) :=
  match self.count with
  | 0 => .ok (none, self)
  | 1 =>
    let (piece, iter) := self.iter.getEnd
    .ok (piece, { iter, count := 0 })
  | count + 1 => do
    let (piece, iter) ← core.str.iter.IteratorSplit.next patInst self.iter
    .ok (piece, { iter, count })

/-- The `Iterator` impl of `SplitN` (`generate_pattern_iterators!`) defines only `next`: `size_hint`
    is the default `(0, None)`. `impl<'a, P: Pattern> FusedIterator for SplitN<'a, P>`. -/
@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::str::iter::SplitN<'a, @P>, &'a str>"]
def core.iter.traits.iterator.IteratorSplitN {P : Type} (patInst : core.str.pattern.Pattern P) :
  core.iter.traits.iterator.Iterator (core.str.iter.SplitN P) Str := {
  next := core.str.iter.IteratorSplitN.next patInst
  fused := true
}

/-- `core::str::Bytes<'a>(Copied<slice::Iter<'a, u8>>)` (core/src/str/iter.rs).
    Every method of its `Iterator` impl forwards to the copied slice iterator;
    `fold`/`try_fold` are the next-driven defaults. -/
@[rust_type "core::str::iter::Bytes" (body := .opaque)]
structure core.str.iter.Bytes where
  iter : core.slice.iter.Iter U8

/-- `str::bytes`: `Bytes(self.as_bytes().iter().copied())`. -/
@[rust_fun "core::str::{str}::bytes"]
def core.str.Str.bytes (s : Str) : Result core.str.iter.Bytes :=
  .ok { iter := { slice := s, i := 0 } }

@[rust_fun
  "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Bytes<'a>, u8>}::next"]
def core.str.iter.IteratorBytes.next (self : core.str.iter.Bytes) :
    Result (Option U8 × core.str.iter.Bytes) := do
  let (byte, iter) ← core.slice.iter.IteratorSliceIter.next self.iter
  .ok (byte, { iter })

@[rust_fun
  "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Bytes<'a>, u8>}::size_hint"]
def core.str.iter.IteratorBytes.size_hint (self : core.str.iter.Bytes) :
    Result (Usize × Option Usize) :=
  core.slice.iter.IteratorSliceIter.size_hint self.iter

/-- `count(self)` is the remaining length (`Copied<slice::Iter>::count`). -/
@[rust_fun
  "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Bytes<'a>, u8>}::count"]
def core.str.iter.IteratorBytes.count (self : core.str.iter.Bytes) :
    Result (Usize × core.str.iter.Bytes) := do
  let (count, _) ← core.slice.iter.IteratorSliceIter.count self.iter
  .ok (count, self)

@[rust_fun
  "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Bytes<'a>, u8>}::any"]
def core.str.iter.IteratorBytes.any {F : Type}
    (fnInst : core.ops.function.FnMut F U8 Bool) (self : core.str.iter.Bytes) (f : F) :
    Result (Bool × core.str.iter.Bytes × F) := do
  let (found, iter, f) ← core.slice.iter.IteratorSliceIter.any fnInst self.iter f
  .ok (found, { iter }, f)

@[rust_fun
  "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Bytes<'a>, u8>}::all"]
def core.str.iter.IteratorBytes.all {F : Type}
    (fnInst : core.ops.function.FnMut F U8 Bool) (self : core.str.iter.Bytes) (f : F) :
    Result (Bool × core.str.iter.Bytes × F) := do
  let (holds, iter, f) ← core.slice.iter.IteratorSliceIter.all fnInst self.iter f
  .ok (holds, { iter }, f)

/-- The predicate takes `&u8`, which is `U8` in the model. -/
@[rust_fun
  "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::Bytes<'a>, u8>}::find"]
def core.str.iter.IteratorBytes.find {P : Type}
    (fnInst : core.ops.function.FnMut P U8 Bool) (self : core.str.iter.Bytes) (predicate : P) :
    Result (Option U8 × core.str.iter.Bytes × P) := do
  let (found, iter, predicate) ← core.slice.iter.IteratorSliceIter.find fnInst self.iter predicate
  .ok (found, { iter }, predicate)

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::str::iter::Bytes<'a>, u8>"]
def core.iter.traits.iterator.IteratorBytes :
  core.iter.traits.iterator.Iterator core.str.iter.Bytes U8 := {
  next := core.str.iter.IteratorBytes.next
  size_hint := core.str.iter.IteratorBytes.size_hint
  count := core.str.iter.IteratorBytes.count
  any := core.str.iter.IteratorBytes.any
  all := core.str.iter.IteratorBytes.all
  find := core.str.iter.IteratorBytes.find
  trusted_len := true
  fused := true
}

/-- `str::get` (core/src/str/mod.rs): `i.get(self)`, through the index's `SliceIndex<str>`. -/
@[rust_fun "core::str::{str}::get"]
def core.str.Str.get {I Output : Type} (inst : core.slice.index.SliceIndex I Str Output) (s : Str)
    (i : I) : Result (Option Output) :=
  inst.get i s

/-- Whether `start..stop` delimits a substring: `start <= stop` and both are char boundaries
    (false beyond the end). -/
def core.str.Str.isRange (s : Str) (start stop : Nat) : Bool :=
  start ≤ stop && core.str.Str.isCharBoundary s start && core.str.Str.isCharBoundary s stop

/-- `SliceIndex<str> for Range<usize>` (core/src/str/traits.rs, rustc 1.95): `get` is
    `Some(&slice[start..end])` iff `start <= end` and both are char boundaries of `slice`;
    `index` panics (`slice_error_fail`) where `get` is `None`. `get_unchecked` requires what
    `get` checks (unsafe precondition): not modeled. -/
@[rust_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::Range<usize>, str, str>}::get"]
def core.str.traits.SliceIndexRangeUsizeStr.get (r : core.ops.range.Range Usize) (s : Str) :
    Result (Option Str) :=
  .ok (if core.str.Str.isRange s r.start.val r.«end».val then
    some (core.str.iter.Split.piece s r.start.val r.«end».val) else none)

@[rust_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::Range<usize>, str, str>}::get_mut"]
def core.str.traits.SliceIndexRangeUsizeStr.get_mut (r : core.ops.range.Range Usize) (s : Str) :
    Result (Option Str × (Option Str → Str)) :=
  if core.str.Str.isRange s r.start.val r.«end».val then
    .ok (some (core.str.iter.Split.piece s r.start.val r.«end».val), fun
      | some piece => core.str.Str.setRange s r.start.val r.«end».val piece
      | none => s)
  else .ok (none, fun _ => s)

@[rust_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::Range<usize>, str, str>}::get_unchecked"]
def core.str.traits.SliceIndexRangeUsizeStr.get_unchecked :
    core.ops.range.Range Usize → ConstRawPtr Str → Result (ConstRawPtr Str) :=
  fun _ _ => .fail .undef

@[rust_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::Range<usize>, str, str>}::get_unchecked_mut"]
def core.str.traits.SliceIndexRangeUsizeStr.get_unchecked_mut :
    core.ops.range.Range Usize → MutRawPtr Str → Result (MutRawPtr Str) :=
  fun _ _ => .fail .undef

@[rust_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::Range<usize>, str, str>}::index"]
def core.str.traits.SliceIndexRangeUsizeStr.index (r : core.ops.range.Range Usize) (s : Str) :
    Result Str :=
  if core.str.Str.isRange s r.start.val r.«end».val then
    .ok (core.str.iter.Split.piece s r.start.val r.«end».val)
  else .fail .panic

@[rust_fun "core::str::traits::{core::slice::index::SliceIndex<core::ops::range::Range<usize>, str, str>}::index_mut"]
def core.str.traits.SliceIndexRangeUsizeStr.index_mut (r : core.ops.range.Range Usize) (s : Str) :
    Result (Str × (Str → Str)) :=
  if core.str.Str.isRange s r.start.val r.«end».val then
    .ok (core.str.iter.Split.piece s r.start.val r.«end».val,
      core.str.Str.setRange s r.start.val r.«end».val)
  else .fail .panic

@[reducible, rust_trait_impl "core::slice::index::SliceIndex<core::ops::range::Range<usize>, str, str>"]
def core.slice.index.SliceIndexRangeUsizeStr :
    core.slice.index.SliceIndex (core.ops.range.Range Usize) Str Str := {
  sealedInst := core.slice.index.private_slice_index.SealedRangeUsize
  get := core.str.traits.SliceIndexRangeUsizeStr.get
  get_mut := core.str.traits.SliceIndexRangeUsizeStr.get_mut
  get_unchecked := core.str.traits.SliceIndexRangeUsizeStr.get_unchecked
  get_unchecked_mut := core.str.traits.SliceIndexRangeUsizeStr.get_unchecked_mut
  index := core.str.traits.SliceIndexRangeUsizeStr.index
  index_mut := core.str.traits.SliceIndexRangeUsizeStr.index_mut
}

/-- `core::str::RSplit<'a, P>(SplitInternal<'a, P>)` (core/src/str/iter.rs, rustc 1.95), which
    `str::rsplit` builds as `RSplit(self.split(pat).0)`: `SplitInternal { start: 0, end: len,
    allow_trailing_empty: true, finished: false }`. Its `next` is `SplitInternal::next_back`, so
    the model keeps the haystack, `start`, `end` (`stop`), `finished`, and the searcher as the
    list `pending` of its remaining `next_match_back` results (`Pattern.reverse_matches`). -/
@[rust_type "core::str::iter::RSplit" (body := .opaque)]
structure core.str.iter.RSplit (P : Type) where
  haystack : Str
  start : Nat
  stop : Nat
  pending : List (Nat × Nat)
  finished : Bool

/-- `str::rsplit` (core/src/str/mod.rs): `RSplit(self.split(pat).0)`, whose
    `for<'a> P::Searcher<'a>: ReverseSearcher<'a>` clause only states that the searcher searches
    backwards: the model reads its matches from `Pattern.reverse_matches`. -/
@[rust_fun "core::str::{str}::rsplit" (keepTraitClauses := [true, false])]
def core.str.Str.rsplit {P : Type} (patInst : core.str.pattern.Pattern P) (s : Str) (pat : P) :
    Result (core.str.iter.RSplit P) :=
  match patInst.reverse_matches with
  | none => .fail .panic
  | some search => do
    let pending ← search pat s
    .ok { haystack := s, start := 0, stop := s.val.length, pending, finished := false }

/-- `RSplit::next` = `SplitInternal::next_back` (with `allow_trailing_empty`): `None` once
    finished; else for the next match `(a, b)` of the reverse searcher the text `b..end`, then
    `end = a`; without a match left the rest `start..end` (even when empty), finishing. -/
@[rust_fun
  "core::str::iter::{core::iter::traits::iterator::Iterator<core::str::iter::RSplit<'a, @P>, &'a str>}::next"
  (keepTraitClauses := [true, false])]
def core.str.iter.IteratorRSplit.next {P : Type} (_patInst : core.str.pattern.Pattern P)
    (self : core.str.iter.RSplit P) : Result (Option Str × core.str.iter.RSplit P) :=
  if self.finished then .ok (none, self)
  else
    match self.pending with
    | (a, b) :: pending =>
      .ok (some (core.str.iter.Split.piece self.haystack b self.stop),
        { self with stop := a, pending })
    | [] =>
      .ok (some (core.str.iter.Split.piece self.haystack self.start self.stop),
        { self with finished := true })

/-- The `Iterator` impl of `RSplit` (`generate_pattern_iterators!`) defines only `next`; `RSplit`
    is `FusedIterator`. -/
@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::str::iter::RSplit<'a, @P>, &'a str>"
  (keepTraitClauses := [true, false])]
def core.iter.traits.iterator.IteratorRSplit {P : Type} (patInst : core.str.pattern.Pattern P) :
  core.iter.traits.iterator.Iterator (core.str.iter.RSplit P) Str := {
  next := core.str.iter.IteratorRSplit.next patInst
  fused := true
}

/-- `impl Default for &str` (core/src/str/mod.rs): `""`. -/
@[rust_fun "core::str::{core::default::Default<&'0 str>}::default"]
def core.str.DefaultSharedStr.default : Result Str :=
  .ok (Slice.new U8)

end Aeneas.Std
