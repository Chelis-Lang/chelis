import Aeneas.Std.Scalar.Ops.Rem
import Aeneas.Std.Scalar.Elab

namespace Aeneas.Std

open Result Error Arith ScalarElab WP

/-!
# Checked Remainder: Definitions
-/

/- [core::num::{T}::checked_rem] -/
def core.num.checked_rem_UScalar {ty} (x y : UScalar ty) : Option (UScalar ty) :=
  Option.ofResult (UScalar.rem x y)

uscalar def «%S».checked_rem (x y : «%S») : Option «%S» := core.num.checked_rem_UScalar x y

/- [core::num::{T}::checked_rem] -/
def core.num.checked_rem_IScalar {ty} (x y : IScalar ty) : Option (IScalar ty) :=
  Option.ofResult (IScalar.rem x y)

iscalar def «%S».checked_rem (x y : «%S») : Option «%S» := core.num.checked_rem_IScalar x y

/- [core::num::{T}::checked_rem_euclid] (core/src/num/uint_macros.rs): `None` if `rhs == 0`,
   else `Some(self.rem_euclid(rhs))`, which is `self % rhs` for unsigned integers. -/
uscalar def «%S».checked_rem_euclid (x y : «%S») : Option «%S» := core.num.checked_rem_UScalar x y

/- [core::num::{T}::checked_rem_euclid] (core/src/num/int_macros.rs, rustc 1.95): `None` if
   `rhs == 0` or `self == MIN && rhs == -1`, else `Some(self.rem_euclid(rhs))`, the remainder
   in `[0, |rhs|)` (`Int.emod`; `rem_euclid` adds `rhs.wrapping_abs()` to a negative truncated
   remainder, which is `|rhs|` also for `rhs == MIN`). -/
def core.num.checked_rem_euclid_IScalar {ty} (x y : IScalar ty) : Option (IScalar ty) :=
  if y.val = 0 ∨ (x.val = IScalar.min ty ∧ y.val = -1) then none
  else some ⟨ BitVec.ofInt _ (Int.emod x.val y.val) ⟩

iscalar def «%S».checked_rem_euclid (x y : «%S») : Option «%S» :=
  core.num.checked_rem_euclid_IScalar x y

/-!
# Checked Remainder
-/

/-!
Unsigned checked remainder
-/
theorem core.num.checked_rem_UScalar_bv_spec {ty} (x y : UScalar ty) :
  match core.num.checked_rem_UScalar x y with
  | some z => y.val ≠ 0 ∧ z.val = x.val % y.val ∧ z.bv = x.bv % y.bv
  | none => y.val = 0 := by
  simp [checked_rem_UScalar, Option.ofResult, UScalar.rem]
  split_ifs
  . zify at *
    simp_all
  . rename_i hnz
    simp
    have hnz' : y.val ≠ 0 := by zify at *; simp_all
    have : x % y = x.rem y := by rfl
    have ⟨_, hz⟩ := spec_imp_exists (UScalar.rem_bv_spec x hnz')
    simp [this, UScalar.rem, hnz] at hz
    simp [hz, hnz']

uscalar @[step_pure «%S».checked_rem x y]
theorem «%S».checked_rem_bv_spec (x y : «%S») :
  match «%S».checked_rem x y with
  | some z => y.val ≠ 0 ∧ z.val = x.val % y.val ∧ z.bv = x.bv % y.bv
  | none => y.val = 0 := by
  have := core.num.checked_rem_UScalar_bv_spec x y
  simp_all [«%S».checked_rem, «%S».bv]
  cases h: core.num.checked_rem_UScalar x y <;> (simp_all; try rfl)

/-!
Signed checked rem
-/
theorem core.num.checked_rem_IScalar_bv_spec {ty} (x y : IScalar ty) :
  match core.num.checked_rem_IScalar x y with
  | some z => y.val ≠ 0 ∧ z.val = Int.tmod x.val y.val ∧ z.bv = BitVec.srem x.bv y.bv
  | none => y.val = 0 := by
  simp [checked_rem_IScalar, Option.ofResult, IScalar.rem]
  split_ifs
  . zify at *
    simp_all
  . rename_i hnz
    simp
    have hnz' : y.val ≠ 0 := by zify at *; simp_all
    have : x % y = x.rem y := by rfl
    have ⟨ _, hz ⟩ := spec_imp_exists (@IScalar.rem_bv_spec _ x y hnz')
    simp [this, IScalar.rem, hnz] at hz
    simp [*]

iscalar @[step_pure «%S».checked_rem x y]
theorem «%S».checked_rem_bv_spec (x y : «%S») :
  match core.num.checked_rem_IScalar x y with
  | some z => y.val ≠ 0 ∧ z.val = Int.tmod x.val y.val ∧ z.bv = BitVec.srem x.bv y.bv
  | none => y.val = 0 := by
  have := core.num.checked_rem_IScalar_bv_spec x y
  simp_all only [«%S».bv]
  cases h: core.num.checked_rem_IScalar x y <;> simp_all

end Aeneas.Std
