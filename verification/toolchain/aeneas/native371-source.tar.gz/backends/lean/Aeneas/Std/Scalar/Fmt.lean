import Aeneas.Std.Scalar.Core
import Aeneas.Std.Core.Fmt

namespace Aeneas.Std

namespace core.fmt

/-- Total positional rendering; division strictly reduces positive input. -/
def digitsAux (base : Nat) (upper : Bool) : Nat → Nat → String
  | 0, _ => ""
  | fuel + 1, n =>
    let digit := n % base
    let c := Char.ofNat (if digit < 10 then 48 + digit else (if upper then 65 else 97) + digit - 10)
    (if n < base then "" else digitsAux base upper fuel (n / base)) ++ String.singleton c

def digits (n : Nat) (base : Nat := 10) (upper : Bool := false) : String :=
  digitsAux base upper (n + 1) n

def debugInteger (fmt : Formatter) (value : Int) (bits : Nat) : Outcome :=
  if fmt.options.bit 25 || fmt.options.bit 26 then
    fmt.padIntegral false "0x" (digits bits 16 (fmt.options.bit 26))
  else fmt.padIntegral (value < 0) "" (digits value.natAbs)

end core.fmt

@[rust_fun "core::fmt::num::{core::fmt::Debug<u8>}::fmt"]
def core.fmt.num.DebugU8.fmt (x : U8) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  core.fmt.debugInteger fmt x.val x.bv.toNat
@[reducible, rust_trait_impl "core::fmt::Debug<u8>"]
def core.fmt.DebugU8 : core.fmt.Debug U8 := ⟨core.fmt.num.DebugU8.fmt⟩

@[rust_fun "core::fmt::num::imp::{core::fmt::Display<u8>}::fmt"]
def core.fmt.num.DisplayU8.fmt (x : U8) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.padIntegral (x.val < 0) "" (core.fmt.digits ((x.val : Int).natAbs))
@[reducible, rust_trait_impl "core::fmt::Display<u8>"]
def core.fmt.DisplayU8 : core.fmt.Display U8 := ⟨core.fmt.num.DisplayU8.fmt⟩

@[rust_fun "core::fmt::num::{core::fmt::Debug<u16>}::fmt"]
def core.fmt.num.DebugU16.fmt (x : U16) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  core.fmt.debugInteger fmt x.val x.bv.toNat
@[reducible, rust_trait_impl "core::fmt::Debug<u16>"]
def core.fmt.DebugU16 : core.fmt.Debug U16 := ⟨core.fmt.num.DebugU16.fmt⟩

@[rust_fun "core::fmt::num::imp::{core::fmt::Display<u16>}::fmt"]
def core.fmt.num.DisplayU16.fmt (x : U16) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.padIntegral (x.val < 0) "" (core.fmt.digits ((x.val : Int).natAbs))
@[reducible, rust_trait_impl "core::fmt::Display<u16>"]
def core.fmt.DisplayU16 : core.fmt.Display U16 := ⟨core.fmt.num.DisplayU16.fmt⟩

@[rust_fun "core::fmt::num::{core::fmt::Debug<u32>}::fmt"]
def core.fmt.num.DebugU32.fmt (x : U32) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  core.fmt.debugInteger fmt x.val x.bv.toNat
@[reducible, rust_trait_impl "core::fmt::Debug<u32>"]
def core.fmt.DebugU32 : core.fmt.Debug U32 := ⟨core.fmt.num.DebugU32.fmt⟩

@[rust_fun "core::fmt::num::imp::{core::fmt::Display<u32>}::fmt"]
def core.fmt.num.DisplayU32.fmt (x : U32) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.padIntegral (x.val < 0) "" (core.fmt.digits ((x.val : Int).natAbs))
@[reducible, rust_trait_impl "core::fmt::Display<u32>"]
def core.fmt.DisplayU32 : core.fmt.Display U32 := ⟨core.fmt.num.DisplayU32.fmt⟩

@[rust_fun "core::fmt::num::{core::fmt::Debug<u64>}::fmt"]
def core.fmt.num.DebugU64.fmt (x : U64) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  core.fmt.debugInteger fmt x.val x.bv.toNat
@[reducible, rust_trait_impl "core::fmt::Debug<u64>"]
def core.fmt.DebugU64 : core.fmt.Debug U64 := ⟨core.fmt.num.DebugU64.fmt⟩

@[rust_fun "core::fmt::num::imp::{core::fmt::Display<u64>}::fmt"]
def core.fmt.num.DisplayU64.fmt (x : U64) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.padIntegral (x.val < 0) "" (core.fmt.digits ((x.val : Int).natAbs))
@[reducible, rust_trait_impl "core::fmt::Display<u64>"]
def core.fmt.DisplayU64 : core.fmt.Display U64 := ⟨core.fmt.num.DisplayU64.fmt⟩

@[rust_fun "core::fmt::num::{core::fmt::Debug<u128>}::fmt"]
def core.fmt.num.DebugU128.fmt (x : U128) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  core.fmt.debugInteger fmt x.val x.bv.toNat
@[reducible, rust_trait_impl "core::fmt::Debug<u128>"]
def core.fmt.DebugU128 : core.fmt.Debug U128 := ⟨core.fmt.num.DebugU128.fmt⟩

@[rust_fun "core::fmt::num::imp::{core::fmt::Display<u128>}::fmt"]
def core.fmt.num.DisplayU128.fmt (x : U128) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.padIntegral (x.val < 0) "" (core.fmt.digits ((x.val : Int).natAbs))
@[reducible, rust_trait_impl "core::fmt::Display<u128>"]
def core.fmt.DisplayU128 : core.fmt.Display U128 := ⟨core.fmt.num.DisplayU128.fmt⟩

@[rust_fun "core::fmt::num::{core::fmt::Debug<usize>}::fmt"]
def core.fmt.num.DebugUsize.fmt (x : Usize) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  core.fmt.debugInteger fmt x.val x.bv.toNat
@[reducible, rust_trait_impl "core::fmt::Debug<usize>"]
def core.fmt.DebugUsize : core.fmt.Debug Usize := ⟨core.fmt.num.DebugUsize.fmt⟩

@[rust_fun "core::fmt::num::imp::{core::fmt::Display<usize>}::fmt"]
def core.fmt.num.DisplayUsize.fmt (x : Usize) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.padIntegral (x.val < 0) "" (core.fmt.digits ((x.val : Int).natAbs))
@[reducible, rust_trait_impl "core::fmt::Display<usize>"]
def core.fmt.DisplayUsize : core.fmt.Display Usize := ⟨core.fmt.num.DisplayUsize.fmt⟩

@[rust_fun "core::fmt::num::{core::fmt::Debug<i8>}::fmt"]
def core.fmt.num.DebugI8.fmt (x : I8) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  core.fmt.debugInteger fmt x.val x.bv.toNat
@[reducible, rust_trait_impl "core::fmt::Debug<i8>"]
def core.fmt.DebugI8 : core.fmt.Debug I8 := ⟨core.fmt.num.DebugI8.fmt⟩

@[rust_fun "core::fmt::num::imp::{core::fmt::Display<i8>}::fmt"]
def core.fmt.num.DisplayI8.fmt (x : I8) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.padIntegral (x.val < 0) "" (core.fmt.digits (x.val.natAbs))
@[reducible, rust_trait_impl "core::fmt::Display<i8>"]
def core.fmt.DisplayI8 : core.fmt.Display I8 := ⟨core.fmt.num.DisplayI8.fmt⟩

@[rust_fun "core::fmt::num::{core::fmt::Debug<i16>}::fmt"]
def core.fmt.num.DebugI16.fmt (x : I16) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  core.fmt.debugInteger fmt x.val x.bv.toNat
@[reducible, rust_trait_impl "core::fmt::Debug<i16>"]
def core.fmt.DebugI16 : core.fmt.Debug I16 := ⟨core.fmt.num.DebugI16.fmt⟩

@[rust_fun "core::fmt::num::imp::{core::fmt::Display<i16>}::fmt"]
def core.fmt.num.DisplayI16.fmt (x : I16) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.padIntegral (x.val < 0) "" (core.fmt.digits (x.val.natAbs))
@[reducible, rust_trait_impl "core::fmt::Display<i16>"]
def core.fmt.DisplayI16 : core.fmt.Display I16 := ⟨core.fmt.num.DisplayI16.fmt⟩

@[rust_fun "core::fmt::num::{core::fmt::Debug<i32>}::fmt"]
def core.fmt.num.DebugI32.fmt (x : I32) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  core.fmt.debugInteger fmt x.val x.bv.toNat
@[reducible, rust_trait_impl "core::fmt::Debug<i32>"]
def core.fmt.DebugI32 : core.fmt.Debug I32 := ⟨core.fmt.num.DebugI32.fmt⟩

@[rust_fun "core::fmt::num::imp::{core::fmt::Display<i32>}::fmt"]
def core.fmt.num.DisplayI32.fmt (x : I32) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.padIntegral (x.val < 0) "" (core.fmt.digits (x.val.natAbs))
@[reducible, rust_trait_impl "core::fmt::Display<i32>"]
def core.fmt.DisplayI32 : core.fmt.Display I32 := ⟨core.fmt.num.DisplayI32.fmt⟩

@[rust_fun "core::fmt::num::{core::fmt::Debug<i64>}::fmt"]
def core.fmt.num.DebugI64.fmt (x : I64) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  core.fmt.debugInteger fmt x.val x.bv.toNat
@[reducible, rust_trait_impl "core::fmt::Debug<i64>"]
def core.fmt.DebugI64 : core.fmt.Debug I64 := ⟨core.fmt.num.DebugI64.fmt⟩

@[rust_fun "core::fmt::num::imp::{core::fmt::Display<i64>}::fmt"]
def core.fmt.num.DisplayI64.fmt (x : I64) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.padIntegral (x.val < 0) "" (core.fmt.digits (x.val.natAbs))
@[reducible, rust_trait_impl "core::fmt::Display<i64>"]
def core.fmt.DisplayI64 : core.fmt.Display I64 := ⟨core.fmt.num.DisplayI64.fmt⟩

@[rust_fun "core::fmt::num::{core::fmt::Debug<i128>}::fmt"]
def core.fmt.num.DebugI128.fmt (x : I128) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  core.fmt.debugInteger fmt x.val x.bv.toNat
@[reducible, rust_trait_impl "core::fmt::Debug<i128>"]
def core.fmt.DebugI128 : core.fmt.Debug I128 := ⟨core.fmt.num.DebugI128.fmt⟩

@[rust_fun "core::fmt::num::imp::{core::fmt::Display<i128>}::fmt"]
def core.fmt.num.DisplayI128.fmt (x : I128) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.padIntegral (x.val < 0) "" (core.fmt.digits (x.val.natAbs))
@[reducible, rust_trait_impl "core::fmt::Display<i128>"]
def core.fmt.DisplayI128 : core.fmt.Display I128 := ⟨core.fmt.num.DisplayI128.fmt⟩

@[rust_fun "core::fmt::num::{core::fmt::Debug<isize>}::fmt"]
def core.fmt.num.DebugIsize.fmt (x : Isize) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  core.fmt.debugInteger fmt x.val x.bv.toNat
@[reducible, rust_trait_impl "core::fmt::Debug<isize>"]
def core.fmt.DebugIsize : core.fmt.Debug Isize := ⟨core.fmt.num.DebugIsize.fmt⟩

@[rust_fun "core::fmt::num::imp::{core::fmt::Display<isize>}::fmt"]
def core.fmt.num.DisplayIsize.fmt (x : Isize) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.padIntegral (x.val < 0) "" (core.fmt.digits (x.val.natAbs))
@[reducible, rust_trait_impl "core::fmt::Display<isize>"]
def core.fmt.DisplayIsize : core.fmt.Display Isize := ⟨core.fmt.num.DisplayIsize.fmt⟩

/-- `{:x}` (core/src/fmt/num.rs `radix! { LowerHex, 16, "0x", ... 'a'..'f' }`): the base-16
    digits through `pad_integral`, with the `0x` prefix of the alternate flag. -/
@[rust_fun "core::fmt::num::{core::fmt::LowerHex<u8>}::fmt"]
def core.fmt.num.LowerHexU8.fmt (x : U8) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.padIntegral false "0x" (core.fmt.digits x.val 16)
@[reducible, rust_trait_impl "core::fmt::LowerHex<u8>"]
def core.fmt.LowerHexU8 : core.fmt.LowerHex U8 := ⟨core.fmt.num.LowerHexU8.fmt⟩

@[rust_fun "core::fmt::num::{core::fmt::LowerHex<u16>}::fmt"]
def core.fmt.num.LowerHexU16.fmt (x : U16) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.padIntegral false "0x" (core.fmt.digits x.val 16)
@[reducible, rust_trait_impl "core::fmt::LowerHex<u16>"]
def core.fmt.LowerHexU16 : core.fmt.LowerHex U16 := ⟨core.fmt.num.LowerHexU16.fmt⟩

@[rust_fun "core::fmt::num::{core::fmt::LowerHex<u32>}::fmt"]
def core.fmt.num.LowerHexU32.fmt (x : U32) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.padIntegral false "0x" (core.fmt.digits x.val 16)
@[reducible, rust_trait_impl "core::fmt::LowerHex<u32>"]
def core.fmt.LowerHexU32 : core.fmt.LowerHex U32 := ⟨core.fmt.num.LowerHexU32.fmt⟩

@[rust_fun "core::fmt::num::{core::fmt::LowerHex<u64>}::fmt"]
def core.fmt.num.LowerHexU64.fmt (x : U64) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.padIntegral false "0x" (core.fmt.digits x.val 16)
@[reducible, rust_trait_impl "core::fmt::LowerHex<u64>"]
def core.fmt.LowerHexU64 : core.fmt.LowerHex U64 := ⟨core.fmt.num.LowerHexU64.fmt⟩

/-- `{:X}` (core/src/fmt/num.rs `radix! { UpperHex, 16, "0x", ... 'A'..'F' }`): upper-case
    digits; the alternate flag's prefix is still `0x`. -/
@[rust_fun "core::fmt::num::{core::fmt::UpperHex<u8>}::fmt"]
def core.fmt.num.UpperHexU8.fmt (x : U8) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.padIntegral false "0x" (core.fmt.digits x.val 16 true)
@[reducible, rust_trait_impl "core::fmt::UpperHex<u8>"]
def core.fmt.UpperHexU8 : core.fmt.UpperHex U8 := ⟨core.fmt.num.UpperHexU8.fmt⟩

@[rust_fun "core::fmt::num::{core::fmt::UpperHex<u32>}::fmt"]
def core.fmt.num.UpperHexU32.fmt (x : U32) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.padIntegral false "0x" (core.fmt.digits x.val 16 true)
@[reducible, rust_trait_impl "core::fmt::UpperHex<u32>"]
def core.fmt.UpperHexU32 : core.fmt.UpperHex U32 := ⟨core.fmt.num.UpperHexU32.fmt⟩

end Aeneas.Std
