import Aeneas.Std.Core.Core
import Aeneas.Std.Core.Ops
import Aeneas.Std.Core.Result
import Aeneas.Std.Scalar.Core
import Aeneas.Std.Array
import Aeneas.Std.Scalar
import Aeneas.Std.Slice
import Aeneas.Std.String
import Aeneas.Std.Sha256Spec

/-!
# Chelis native primitives (trusted base)

Models of the crate-local native primitives of the Chelis semantic core. Each is
an explicit state object whose native behavior (atomics, process-global
counters, ...) is abstracted as an oracle: extracted entry points receive the
state as a parameter, so correspondence theorems quantify over every native
behavior. Native constructors (e.g. `CapacityScopeSupply::native`) are
deliberately not modeled: an extracted call to one fails closed as an unknown
external.
-/

namespace Aeneas.Std

/-- `chelis_ir::capacity_key::CapacityScopeSupply`: a handle on the process-global
    capacity-scope identity sequence. The model is an oracle of the identities the
    counter hands to this invocation: `draw n` is the `n`-th identity drawn through
    this handle, `none` when the native counter is exhausted. -/
@[rust_type "chelis_ir::capacity_key::CapacityScopeSupply" (body := .opaque)]
structure chelis_ir.capacity_key.CapacityScopeSupply where
  draw : Nat → Option U64
  taken : Nat

/-- `CapacityScopeSupply::fresh_id`: the next identity of the oracle; exhaustion
    is the native `.expect("capacity-scope identity space exhausted")` panic. -/
@[rust_fun "chelis_ir::capacity_key::{chelis_ir::capacity_key::CapacityScopeSupply}::fresh_id"]
def chelis_ir.capacity_key.CapacityScopeSupply.fresh_id
    (s : chelis_ir.capacity_key.CapacityScopeSupply) :
    Result (U64 × chelis_ir.capacity_key.CapacityScopeSupply) :=
  match s.draw s.taken with
  | some id => .ok (id, { s with taken := s.taken + 1 })
  | none => .fail .panic

/-! ## `chelis_types::native` -/

/-- `chelis_types::native::NativeServices`: the native effects of one checking
    invocation. Cancellation polls and stack-exhaustion probes are the next
    elements of oracle observation schedules (`cancel n` / `stack n` is the
    `n`-th observation; correspondence theorems assume what they need, e.g.
    monotone cancellation). `depth` is the explicit guarded-frame counter.
    Profiling marks are an oracle of `usize` values only consumed by
    `profile_phase`, which has no modeled effect. The constructors `new`,
    `with_profiling` and `with_grow_segment_bytes_for_test` are shell-only and
    deliberately unmodeled. -/
@[rust_type "chelis_types::native::NativeServices" (body := .opaque)]
structure chelis_types.native.NativeServices where
  cancel : Nat → Bool
  cancelTaken : Nat
  stack : Nat → Bool
  stackTaken : Nat
  depth : Usize
  profileMark : Nat → Usize
  profileTaken : Nat

namespace chelis_types.native.NativeServices

/-- `cancellation_observed`: the next cancellation observation. -/
@[rust_fun "chelis_types::native::{chelis_types::native::NativeServices}::cancellation_observed"]
def cancellation_observed (s : NativeServices) : Result (Bool × NativeServices) :=
  .ok (s.cancel s.cancelTaken, { s with cancelTaken := s.cancelTaken + 1 })

/-- `stack_exhausted`: the next stack-exhaustion observation. -/
@[rust_fun "chelis_types::native::{chelis_types::native::NativeServices}::stack_exhausted"]
def stack_exhausted (s : NativeServices) : Result (Bool × NativeServices) :=
  .ok (s.stack s.stackTaken, { s with stackTaken := s.stackTaken + 1 })

/-- `enter_frame`: `depth += 1`, failing on overflow like Rust's checked `+=`. -/
@[rust_fun "chelis_types::native::{chelis_types::native::NativeServices}::enter_frame"]
def enter_frame (s : NativeServices) : Result NativeServices := do
  let depth ← s.depth + 1#usize
  .ok { s with depth }

/-- `exit_frame`: `depth := depth.saturating_sub(1)`. -/
@[rust_fun "chelis_types::native::{chelis_types::native::NativeServices}::exit_frame"]
def exit_frame (s : NativeServices) : Result NativeServices :=
  .ok { s with depth := UScalar.saturating_sub s.depth 1#usize }

/-- `reset_frames`: `depth := 0`. -/
@[rust_fun "chelis_types::native::{chelis_types::native::NativeServices}::reset_frames"]
def reset_frames (s : NativeServices) : Result NativeServices :=
  .ok { s with depth := 0#usize }

/-- `profile_start`: the next oracle mark. -/
@[rust_fun "chelis_types::native::{chelis_types::native::NativeServices}::profile_start"]
def profile_start (s : NativeServices) : Result (Usize × NativeServices) :=
  .ok (s.profileMark s.profileTaken, { s with profileTaken := s.profileTaken + 1 })

/-- `profile_phase`: no modeled effect (stderr timing only). -/
@[rust_fun "chelis_types::native::{chelis_types::native::NativeServices}::profile_phase"]
def profile_phase (s : NativeServices) (_mark : Usize) (_scope _label : Str) :
    Result NativeServices :=
  .ok s

/-- `with_grown_stack`: `f self`. The fresh native stack segment is not
    observable (a failed segment allocation aborts the process, like any
    allocation failure). `F : FnOnce(&mut Self) -> R` is Charon's
    `FnOnce<(&mut NativeServices,)>` specialization: the call returns the
    closure's value and the services it was lent. -/
@[rust_fun "chelis_types::native::{chelis_types::native::NativeServices}::with_grown_stack"]
def with_grown_stack {R F : Type}
    (fnInst : core.ops.function.FnOnceMutArg F NativeServices R)
    (s : NativeServices) (f : F) : Result (R × NativeServices) :=
  fnInst.call_once f s

end chelis_types.native.NativeServices

/-- `chelis_types::native::sha256_concat`: FIPS 180-4 SHA-256 of the
    concatenated parts (`ChelisModels.Sha256.digest`). -/
@[rust_fun "chelis_types::native::sha256_concat"]
def chelis_types.native.sha256_concat (parts : Slice (Slice U8)) : Result (Array U8 32#usize) :=
  let msg := parts.val.flatMap fun part => part.val.map fun b => UInt8.ofBitVec b.bv
  let bytes := (ChelisModels.Sha256.digest msg).map fun b => (⟨b.toBitVec⟩ : U8)
  .ok ⟨bytes, by simp [bytes, ChelisModels.Sha256.digest_length]⟩

/-! ## `chelis_ir::lowering_runtime`

The trusted primitive boundary of lowering (`crates/chelis-ir/src/lowering_runtime.rs`).
Each model below implements the primitive's `/// Model:` line. The shell-only items
(`with_native_lowering_runtime`, `install_chelis_panic_hook`, the process hook, the
thread-local and process-global state) are deliberately unmodeled: an extracted
reference to one fails closed as an unknown external. -/

/-- `chelis_ir::lowering_runtime::LoweringRuntime`: the handle names this thread's
    lowering state, which the model threads explicitly.
    * `u`, `o`: the speculation and quiet-output flags.
    * `installed`: a lower bound of the process flag "the Chelis panic hook is
      installed". The function `catch_native_unwind` installs the hook before its body.
      Thus it sets the bound. No code removes the hook. Another thread can install
      it. Thus `false` does not mean "not installed".

    * `hook`: the `(u, o, installed)` values at each raise, oldest first. The process
      hook suppresses a raise iff the hook is installed and `u || o` holds. Else the
      previous hook observes the raise. The previous hook prints the same
      `Box<dyn Any>` description for both payload types. The payload type is static.
      The function `observe_raise` has exactly two monomorphic callers. They are
      `raise_unrepresentable` with `UnrepresentableDag` and `raise_lowering_diagnostic`
      with `LowerDiagnostic`.

    * `builds`: the persistent summary-probe count.
    * `nextPreflightFrame`: this thread's next tensor-helper preflight frame id.
    * `hostVar n`: the `n`-th id this thread draws from the process-global host
      inference-variable supply (other threads may draw in between);
      `hostVarsTaken` counts the draws.
    * `profileEnv n`: whether `CHELIS_PROFILE_COMPILE_CONTEXT_DETAIL` equals `1` at
      the `n`-th read (the environment is process-global and mutable);
      `profileEnvReads` counts the reads.
    * `profileMarks`: the number of profiling clocks of this thread; a mark `m`
      names a clock iff `1 ≤ m ≤ profileMarks`. Clock readings only reach stderr. -/
@[rust_type "chelis_ir::lowering_runtime::LoweringRuntime" (body := .opaque)]
structure chelis_ir.lowering_runtime.LoweringRuntime where
  u : Bool
  o : Bool
  installed : Bool
  hook : List (Bool × Bool × Bool)
  builds : U64
  nextPreflightFrame : U64
  hostVar : Nat → U32
  hostVarsTaken : Nat
  profileEnv : Nat → Bool
  profileEnvReads : Nat
  profileMarks : Usize

namespace chelis_ir.lowering_runtime

/-- `resume_native_unwind`: the unwind leaves the enclosing native entry, outside
    the modeled domain. -/
@[rust_fun "chelis_ir::lowering_runtime::resume_native_unwind"]
def resume_native_unwind {P : Type} (_anyInst : core.any.Any P) (_payload : P) :
    Result Never :=
  .fail .panic

/-- `scoped`: `let t := enter s; let r := body s; exit s t; r`. A native unwind
    out of `body` (after which `exit` also runs) is outside the modeled domain:
    the failure of `body` propagates. -/
@[rust_fun "chelis_ir::lowering_runtime::scoped"]
def «scoped» {S T R Enter Exit Body : Type}
    (enterInst : core.ops.function.FnOnceMutArg Enter S T)
    (exitInst : core.ops.function.FnOnceMutArgPair Exit S T Unit)
    (bodyInst : core.ops.function.FnOnceMutArg Body S R)
    (state : S) (enter : Enter) (exit : Exit) (body : Body) : Result (R × S) := do
  let (token, state) ← enterInst.call_once enter state
  let (result, state) ← bodyInst.call_once body state
  let ((), state) ← exitInst.call_once exit (state, token)
  .ok (result, state)

/-- `grow_stack_if_needed`: `f state`. The stack segment `f` runs on is not
    observable (a failed segment allocation aborts the process, like any
    allocation failure). -/
@[rust_fun "chelis_ir::lowering_runtime::grow_stack_if_needed"]
def grow_stack_if_needed {S R F : Type} (fInst : core.ops.function.FnOnceMutArg F S R)
    (state : S) (_redZone _stackSize : Usize) (f : F) : Result (R × S) :=
  fInst.call_once f state

namespace LoweringRuntime

/-- `unrepresentable_panic_suppressed`: read `u`. -/
@[rust_fun
  "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::unrepresentable_panic_suppressed"]
def unrepresentable_panic_suppressed (s : LoweringRuntime) : Result (Bool × LoweringRuntime) :=
  .ok (s.u, s)

/-- `set_unrepresentable_panic_suppressed`: `u := value`. -/
@[rust_fun
  "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::set_unrepresentable_panic_suppressed"]
def set_unrepresentable_panic_suppressed (s : LoweringRuntime) (value : Bool) :
    Result LoweringRuntime :=
  .ok { s with u := value }

/-- `set_output_suppressed`: `o := value`. -/
@[rust_fun
  "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::set_output_suppressed"]
def set_output_suppressed (s : LoweringRuntime) (value : Bool) : Result LoweringRuntime :=
  .ok { s with o := value }

/-- `observe_raise`: append the current `(u, o, installed)` to the hook trace. Return the
    payload. The `LoweringRuntime` comment tells why the model records no payload type. -/
@[rust_fun
  "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::observe_raise"]
def observe_raise {P : Type} (_anyInst : core.any.Any P) (s : LoweringRuntime) (payload : P) :
    Result (P × LoweringRuntime) :=
  .ok (payload, { s with hook := s.hook ++ [(s.u, s.o, s.installed)] })

/-- `catch_native_unwind`: `install the hook. o := true. let r := f self state. o := false. r`.
    The installation sets the lower bound `installed`.
    The conversions `marker` and `message` apply only to an unexpected native
    unwind, which is outside the modeled domain: the failure of `f` propagates.
    The grown stack segment is not observable. `F : FnOnce(&mut Self, &mut S)` is
    Charon's `FnOnce<(&mut LoweringRuntime, &mut S)>` specialization: the call
    returns the closure's value, the runtime and the state it was lent. -/
@[rust_fun
  "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::catch_native_unwind"]
def catch_native_unwind {S T D F Marker Message : Type} (_cloneInst : core.clone.Clone D)
    (fInst : core.ops.function.FnOnceMutArgMutArg F LoweringRuntime S (core.result.Result T D))
    (_markerInst : core.ops.function.FnOnce Marker Unit D)
    (_messageInst : core.ops.function.FnOnce Message (Option String) D)
    (s : LoweringRuntime) (state : S) (f : F) (_marker : Marker) (_message : Message) :
    Result (core.result.Result T D × LoweringRuntime × S) := do
  let (result, s, state) ← fInst.call_once f ({ s with o := true, installed := true }, state)
  .ok (result, { s with o := false }, state)

/-- `fresh_host_inference_var`: the next element of this thread's draws from the
    process-global supply. -/
@[rust_fun
  "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::fresh_host_inference_var"]
def fresh_host_inference_var (s : LoweringRuntime) : Result (U32 × LoweringRuntime) :=
  .ok (s.hostVar s.hostVarsTaken, { s with hostVarsTaken := s.hostVarsTaken + 1 })

/-- `record_summary_probe_build`: `builds := min(builds + 1, u64::MAX)`. -/
@[rust_fun
  "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::record_summary_probe_build"]
def record_summary_probe_build (s : LoweringRuntime) : Result LoweringRuntime :=
  .ok { s with builds := UScalar.saturating_add s.builds 1#u64 }

/-- `summary_probe_builds`: read `builds`. -/
@[rust_fun
  "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::summary_probe_builds"]
def summary_probe_builds (s : LoweringRuntime) : Result (U64 × LoweringRuntime) :=
  .ok (s.builds, s)

/-- `reset_summary_probe_builds`: `builds := 0`. -/
@[rust_fun
  "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::reset_summary_probe_builds"]
def reset_summary_probe_builds (s : LoweringRuntime) : Result LoweringRuntime :=
  .ok { s with builds := 0#u64 }

/-- `fresh_preflight_frame`: return the next frame id and advance it, wrapping at
    `u64::MAX`. -/
@[rust_fun
  "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::fresh_preflight_frame"]
def fresh_preflight_frame (s : LoweringRuntime) : Result (U64 × LoweringRuntime) :=
  .ok (s.nextPreflightFrame,
    { s with nextPreflightFrame := UScalar.wrapping_add s.nextPreflightFrame 1#u64 })

/-- The private `profile_mark`: push one clock and return the new clock count.
    The push fails like `Vec::push` beyond `usize::MAX` elements. -/
def profile_mark (s : LoweringRuntime) : Result (Usize × LoweringRuntime) :=
  if s.profileMarks.val < Usize.max then
    let marks := UScalar.wrapping_add s.profileMarks 1#usize
    .ok (marks, { s with profileMarks := marks })
  else .fail .maximumSizeExceeded

/-- `detail_profile_start`: read the environment; when it enables the detailed
    profile, push a clock and return its mark, otherwise return `0`. -/
@[rust_fun
  "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::detail_profile_start"]
def detail_profile_start (s : LoweringRuntime) : Result (Usize × LoweringRuntime) :=
  let enabled := s.profileEnv s.profileEnvReads
  let s := { s with profileEnvReads := s.profileEnvReads + 1 }
  if enabled then profile_mark s else .ok (0#usize, s)

/-- `detail_profile_phase`: restarts the clock `mark` names and reports it on
    stderr; neither is modeled state (the clock count does not change). -/
@[rust_fun
  "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::detail_profile_phase"]
def detail_profile_phase (s : LoweringRuntime) (_mark : Usize) (_label : Str) :
    Result LoweringRuntime :=
  .ok s

/-- `detail_profile_declaration_start`: `0` for mark `0`, otherwise push a clock and
    return its mark. -/
@[rust_fun
  "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::detail_profile_declaration_start"]
def detail_profile_declaration_start (s : LoweringRuntime) (mark : Usize) :
    Result (Usize × LoweringRuntime) :=
  if mark = 0#usize then .ok (0#usize, s) else profile_mark s

/-- `detail_profile_declaration`: when `start` names a clock of this thread
    (`profile_restart(start)` is `Some`), `*last_dag_size := dag_total`; the
    elapsed time and node counts only reach stderr. -/
@[rust_fun
  "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::detail_profile_declaration"]
def detail_profile_declaration (s : LoweringRuntime) (start lastDagSize dagTotal : Usize)
    (_name : Str) : Result (LoweringRuntime × Usize) :=
  if start ≠ 0#usize ∧ start.val ≤ s.profileMarks.val then .ok (s, dagTotal)
  else .ok (s, lastDagSize)

/-- `report_internal`: one line on stderr, which is not modeled state. -/
@[rust_fun
  "chelis_ir::lowering_runtime::{chelis_ir::lowering_runtime::LoweringRuntime}::report_internal"]
def report_internal (s : LoweringRuntime) (_line : Str) : Result LoweringRuntime :=
  .ok s

end LoweringRuntime

end chelis_ir.lowering_runtime

end Aeneas.Std
