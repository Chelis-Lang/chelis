import Aeneas.Std.Serde.Ser
import Aeneas.Std.Serde.De
import Aeneas.Std.VecIter
import Aeneas.Std.BTreeSet
import Aeneas.Std.Sync

/-!
# serde's own implementations reached by the core (serde_core 1.0.228)

Transcriptions of `serde_core::ser::impls` / `serde_core::de::impls`: `tri!` is
`match e { Ok(v) => v, Err(e) => return Err(e) }` (no conversion). The data-side dictionaries passed
at the format side's method-level bounds are wrapped by the knot (`Serialize.wrap`,
`Deserialize.wrap`, `Visitor.wrap`), as Aeneas does in extracted code.
-/

namespace Aeneas.Std

open Result

namespace serde_core.ser.impls

/-- `impl<T0: Serialize, T1: Serialize> Serialize for (T0, T1)` (ser/impls.rs `tuple_impl_body!`):
    `serialize_tuple(2)`, then `serialize_element(&self.0)`, `serialize_element(&self.1)`, `end()`. -/
@[rust_fun "serde_core::ser::impls::{serde_core::ser::Serialize<(@T0, @T1)>}::serialize"]
def SerializePair.serialize {T0 T1 S Ok Error SS ST STS STV SM SSt SSV : Type}
    (i0 : serde_core.ser.Serialize T0) (i1 : serde_core.ser.Serialize T1)
    (inst : serde_core.ser.Serializer S Ok Error SS ST STS STV SM SSt SSV)
    (self : T0 × T1) (serializer : S) : Result (core.result.Result Ok Error) := do
  match ← inst.serialize_tuple serializer 2#usize with
  | .Err e => ok (.Err e)
  | .Ok tuple =>
    let (r, tuple) ← inst.SerializeTupleInst.serialize_element (Serialize.wrap i0) tuple self.1
    match r with
    | .Err e => ok (.Err e)
    | .Ok () =>
      let (r, tuple) ← inst.SerializeTupleInst.serialize_element (Serialize.wrap i1) tuple self.2
      match r with
      | .Err e => ok (.Err e)
      | .Ok () => inst.SerializeTupleInst.«end» tuple

@[reducible, rust_trait_impl "serde_core::ser::Serialize<(@T0, @T1)>"]
def SerializePair {T0 T1 : Type} (i0 : serde_core.ser.Serialize T0)
    (i1 : serde_core.ser.Serialize T1) : serde_core.ser.Serialize (T0 × T1) :=
  { serialize := fun inst self serializer => SerializePair.serialize i0 i1 inst self serializer }

/-- `impl<'a, T: ?Sized + Serialize> Serialize for &'a T` (`deref_impl!`): `(**self).serialize(s)`. -/
@[rust_fun "serde_core::ser::impls::{serde_core::ser::Serialize<&'a @T>}::serialize"]
def SerializeShared.serialize {T S Ok Error SS ST STS STV SM SSt SSV : Type}
    (i : serde_core.ser.Serialize T)
    (inst : serde_core.ser.Serializer S Ok Error SS ST STS STV SM SSt SSV)
    (self : T) (serializer : S) : Result (core.result.Result Ok Error) :=
  i.serialize inst self serializer

@[reducible, rust_trait_impl "serde_core::ser::Serialize<&'a @T>"]
def SerializeShared {T : Type} (i : serde_core.ser.Serialize T) : serde_core.ser.Serialize T :=
  { serialize := fun inst self serializer => SerializeShared.serialize i inst self serializer }

/-- `primitive_impl!(u32, serialize_u32)`: `serializer.serialize_u32(*self)`. -/
@[rust_fun "serde_core::ser::impls::{serde_core::ser::Serialize<u32>}::serialize"]
def SerializeU32.serialize {S Ok Error SS ST STS STV SM SSt SSV : Type}
    (inst : serde_core.ser.Serializer S Ok Error SS ST STS STV SM SSt SSV)
    (self : U32) (serializer : S) : Result (core.result.Result Ok Error) :=
  inst.serialize_u32 serializer self

@[reducible, rust_trait_impl "serde_core::ser::Serialize<u32>"]
def SerializeU32 : serde_core.ser.Serialize U32 :=
  { serialize := fun inst self serializer => SerializeU32.serialize inst self serializer }

/-- `impl Serialize for String`: `serializer.serialize_str(self)`. -/
@[rust_fun "serde_core::ser::impls::{serde_core::ser::Serialize<alloc::string::String>}::serialize"]
def SerializeString.serialize {S Ok Error SS ST STS STV SM SSt SSV : Type}
    (inst : serde_core.ser.Serializer S Ok Error SS ST STS STV SM SSt SSV)
    (self : String) (serializer : S) : Result (core.result.Result Ok Error) := do
  inst.serialize_str serializer (← Str.ofString self)

@[reducible, rust_trait_impl "serde_core::ser::Serialize<alloc::string::String>"]
def SerializeString : serde_core.ser.Serialize String :=
  { serialize := fun inst self serializer => SerializeString.serialize inst self serializer }

/-! ### Collections: `Serializer::collect_seq` / `collect_map` over the shared iterator -/

/-- `seq_impl!(Vec<T>)` (ser/impls.rs): `serializer.collect_seq(self)`, with `I = &Vec<T>` (items
    `&T`, serialized through `impl Serialize for &T`). -/
@[rust_fun "serde_core::ser::impls::{serde_core::ser::Serialize<alloc::vec::Vec<@T>>}::serialize"]
def SerializeVec.serialize {T S Ok Error SS ST STS STV SM SSt SSV : Type}
    (i : serde_core.ser.Serialize T)
    (inst : serde_core.ser.Serializer S Ok Error SS ST STS STV SM SSt SSV)
    (self : alloc.vec.Vec T) (serializer : S) : Result (core.result.Result Ok Error) :=
  inst.collect_seq (core.iter.traits.collect.IntoIteratorSharedVec T)
    (Serialize.wrap (SerializeShared i)) serializer self

@[reducible, rust_trait_impl "serde_core::ser::Serialize<alloc::vec::Vec<@T>>"]
def SerializeVec {T : Type} (i : serde_core.ser.Serialize T) :
    serde_core.ser.Serialize (alloc.vec.Vec T) :=
  { serialize := fun inst self serializer => SerializeVec.serialize i inst self serializer }

/-- `seq_impl!(BTreeSet<T>)`: `serializer.collect_seq(self)`, with `I = &BTreeSet<T>` (items `&T`
    in ascending order). -/
@[rust_fun
  "serde_core::ser::impls::{serde_core::ser::Serialize<alloc::collections::btree::set::BTreeSet<@T, alloc::alloc::Global>>}::serialize"]
def SerializeBTreeSet.serialize {T S Ok Error SS ST STS STV SM SSt SSV : Type}
    (i : serde_core.ser.Serialize T)
    (inst : serde_core.ser.Serializer S Ok Error SS ST STS STV SM SSt SSV)
    (self : alloc.collections.btree.set.BTreeSet T) (serializer : S) :
    Result (core.result.Result Ok Error) :=
  inst.collect_seq (core.iter.traits.collect.IntoIteratorSharedBTreeSet T)
    (Serialize.wrap (SerializeShared i)) serializer self

@[reducible, rust_trait_impl
  "serde_core::ser::Serialize<alloc::collections::btree::set::BTreeSet<@T, alloc::alloc::Global>>"]
def SerializeBTreeSet {T : Type} (i : serde_core.ser.Serialize T) :
    serde_core.ser.Serialize (alloc.collections.btree.set.BTreeSet T) :=
  { serialize := fun inst self serializer => SerializeBTreeSet.serialize i inst self serializer }

/-- `map_impl!(BTreeMap<K: Ord, V>)`: `serializer.collect_map(self)`, with `I = &BTreeMap<K, V>`
    (entries `(&K, &V)` in ascending key order). -/
@[rust_fun
  "serde_core::ser::impls::{serde_core::ser::Serialize<alloc::collections::btree::map::BTreeMap<@K, @V, alloc::alloc::Global>>}::serialize"]
def SerializeBTreeMap.serialize {K V S Ok Error SS ST STS STV SM SSt SSV : Type}
    (ki : serde_core.ser.Serialize K) (vi : serde_core.ser.Serialize V)
    (inst : serde_core.ser.Serializer S Ok Error SS ST STS STV SM SSt SSV)
    (self : alloc.collections.btree.map.BTreeMap K V) (serializer : S) :
    Result (core.result.Result Ok Error) :=
  inst.collect_map (Serialize.wrap (SerializeShared ki)) (Serialize.wrap (SerializeShared vi))
    (core.iter.traits.collect.IntoIteratorSharedBTreeMap K V) serializer self

@[reducible, rust_trait_impl
  "serde_core::ser::Serialize<alloc::collections::btree::map::BTreeMap<@K, @V, alloc::alloc::Global>>"]
def SerializeBTreeMap {K V : Type} (ki : serde_core.ser.Serialize K)
    (vi : serde_core.ser.Serialize V) :
    serde_core.ser.Serialize (alloc.collections.btree.map.BTreeMap K V) :=
  { serialize := fun inst self serializer => SerializeBTreeMap.serialize ki vi inst self serializer }

/-! ### Primitives (`primitive_impl!`: `serializer.serialize_<ty>(*self)`), `str`, `()` -/

@[rust_fun "serde_core::ser::impls::{serde_core::ser::Serialize<bool>}::serialize"]
def SerializeBool.serialize {S Ok Error SS ST STS STV SM SSt SSV : Type}
    (inst : serde_core.ser.Serializer S Ok Error SS ST STS STV SM SSt SSV)
    (self : Bool) (serializer : S) : Result (core.result.Result Ok Error) :=
  inst.serialize_bool serializer self

@[reducible, rust_trait_impl "serde_core::ser::Serialize<bool>"]
def SerializeBool : serde_core.ser.Serialize Bool :=
  { serialize := fun inst self serializer => SerializeBool.serialize inst self serializer }

@[rust_fun "serde_core::ser::impls::{serde_core::ser::Serialize<i8>}::serialize"]
def SerializeI8.serialize {S Ok Error SS ST STS STV SM SSt SSV : Type}
    (inst : serde_core.ser.Serializer S Ok Error SS ST STS STV SM SSt SSV)
    (self : I8) (serializer : S) : Result (core.result.Result Ok Error) :=
  inst.serialize_i8 serializer self

@[reducible, rust_trait_impl "serde_core::ser::Serialize<i8>"]
def SerializeI8 : serde_core.ser.Serialize I8 :=
  { serialize := fun inst self serializer => SerializeI8.serialize inst self serializer }

@[rust_fun "serde_core::ser::impls::{serde_core::ser::Serialize<i16>}::serialize"]
def SerializeI16.serialize {S Ok Error SS ST STS STV SM SSt SSV : Type}
    (inst : serde_core.ser.Serializer S Ok Error SS ST STS STV SM SSt SSV)
    (self : I16) (serializer : S) : Result (core.result.Result Ok Error) :=
  inst.serialize_i16 serializer self

@[reducible, rust_trait_impl "serde_core::ser::Serialize<i16>"]
def SerializeI16 : serde_core.ser.Serialize I16 :=
  { serialize := fun inst self serializer => SerializeI16.serialize inst self serializer }

@[rust_fun "serde_core::ser::impls::{serde_core::ser::Serialize<i32>}::serialize"]
def SerializeI32.serialize {S Ok Error SS ST STS STV SM SSt SSV : Type}
    (inst : serde_core.ser.Serializer S Ok Error SS ST STS STV SM SSt SSV)
    (self : I32) (serializer : S) : Result (core.result.Result Ok Error) :=
  inst.serialize_i32 serializer self

@[reducible, rust_trait_impl "serde_core::ser::Serialize<i32>"]
def SerializeI32 : serde_core.ser.Serialize I32 :=
  { serialize := fun inst self serializer => SerializeI32.serialize inst self serializer }

@[rust_fun "serde_core::ser::impls::{serde_core::ser::Serialize<i64>}::serialize"]
def SerializeI64.serialize {S Ok Error SS ST STS STV SM SSt SSV : Type}
    (inst : serde_core.ser.Serializer S Ok Error SS ST STS STV SM SSt SSV)
    (self : I64) (serializer : S) : Result (core.result.Result Ok Error) :=
  inst.serialize_i64 serializer self

@[reducible, rust_trait_impl "serde_core::ser::Serialize<i64>"]
def SerializeI64 : serde_core.ser.Serialize I64 :=
  { serialize := fun inst self serializer => SerializeI64.serialize inst self serializer }

@[rust_fun "serde_core::ser::impls::{serde_core::ser::Serialize<u8>}::serialize"]
def SerializeU8.serialize {S Ok Error SS ST STS STV SM SSt SSV : Type}
    (inst : serde_core.ser.Serializer S Ok Error SS ST STS STV SM SSt SSV)
    (self : U8) (serializer : S) : Result (core.result.Result Ok Error) :=
  inst.serialize_u8 serializer self

@[reducible, rust_trait_impl "serde_core::ser::Serialize<u8>"]
def SerializeU8 : serde_core.ser.Serialize U8 :=
  { serialize := fun inst self serializer => SerializeU8.serialize inst self serializer }

@[rust_fun "serde_core::ser::impls::{serde_core::ser::Serialize<u64>}::serialize"]
def SerializeU64.serialize {S Ok Error SS ST STS STV SM SSt SSV : Type}
    (inst : serde_core.ser.Serializer S Ok Error SS ST STS STV SM SSt SSV)
    (self : U64) (serializer : S) : Result (core.result.Result Ok Error) :=
  inst.serialize_u64 serializer self

@[reducible, rust_trait_impl "serde_core::ser::Serialize<u64>"]
def SerializeU64 : serde_core.ser.Serialize U64 :=
  { serialize := fun inst self serializer => SerializeU64.serialize inst self serializer }

@[rust_fun "serde_core::ser::impls::{serde_core::ser::Serialize<f64>}::serialize"]
def SerializeF64.serialize {S Ok Error SS ST STS STV SM SSt SSV : Type}
    (inst : serde_core.ser.Serializer S Ok Error SS ST STS STV SM SSt SSV)
    (self : F64) (serializer : S) : Result (core.result.Result Ok Error) :=
  inst.serialize_f64 serializer self

@[reducible, rust_trait_impl "serde_core::ser::Serialize<f64>"]
def SerializeF64 : serde_core.ser.Serialize F64 :=
  { serialize := fun inst self serializer => SerializeF64.serialize inst self serializer }

/-- `primitive_impl!(usize, serialize_u64 as u64)`: `serializer.serialize_u64(*self as u64)`. -/
@[rust_fun "serde_core::ser::impls::{serde_core::ser::Serialize<usize>}::serialize"]
def SerializeUsize.serialize {S Ok Error SS ST STS STV SM SSt SSV : Type}
    (inst : serde_core.ser.Serializer S Ok Error SS ST STS STV SM SSt SSV)
    (self : Usize) (serializer : S) : Result (core.result.Result Ok Error) :=
  inst.serialize_u64 serializer (self.cast .U64)

@[reducible, rust_trait_impl "serde_core::ser::Serialize<usize>"]
def SerializeUsize : serde_core.ser.Serialize Usize :=
  { serialize := fun inst self serializer => SerializeUsize.serialize inst self serializer }

/-- `impl Serialize for str`: `serializer.serialize_str(self)`. -/
@[rust_fun "serde_core::ser::impls::{serde_core::ser::Serialize<str>}::serialize"]
def SerializeStr.serialize {S Ok Error SS ST STS STV SM SSt SSV : Type}
    (inst : serde_core.ser.Serializer S Ok Error SS ST STS STV SM SSt SSV)
    (self : Str) (serializer : S) : Result (core.result.Result Ok Error) :=
  inst.serialize_str serializer self

@[reducible, rust_trait_impl "serde_core::ser::Serialize<str>"]
def SerializeStr : serde_core.ser.Serialize Str :=
  { serialize := fun inst self serializer => SerializeStr.serialize inst self serializer }

/-- `impl Serialize for ()`: `serializer.serialize_unit()`. -/
@[rust_fun "serde_core::ser::impls::{serde_core::ser::Serialize<()>}::serialize"]
def SerializeUnit.serialize {S Ok Error SS ST STS STV SM SSt SSV : Type}
    (inst : serde_core.ser.Serializer S Ok Error SS ST STS STV SM SSt SSV)
    (_ : Unit) (serializer : S) : Result (core.result.Result Ok Error) :=
  inst.serialize_unit serializer

@[reducible, rust_trait_impl "serde_core::ser::Serialize<()>"]
def SerializeUnit : serde_core.ser.Serialize Unit :=
  { serialize := fun inst self serializer => SerializeUnit.serialize inst self serializer }

/-! ### `Option<T>`, `Box<T>`, `Arc<T>` -/

/-- `impl<T: Serialize> Serialize for Option<T>`: `Some(ref value) => serializer.serialize_some(value)`,
    `None => serializer.serialize_none()`. -/
@[rust_fun "serde_core::ser::impls::{serde_core::ser::Serialize<core::option::Option<@T>>}::serialize"]
def SerializeOption.serialize {T S Ok Error SS ST STS STV SM SSt SSV : Type}
    (i : serde_core.ser.Serialize T)
    (inst : serde_core.ser.Serializer S Ok Error SS ST STS STV SM SSt SSV)
    (self : Option T) (serializer : S) : Result (core.result.Result Ok Error) :=
  match self with
  | some value => inst.serialize_some (Serialize.wrap i) serializer value
  | none => inst.serialize_none serializer

@[reducible, rust_trait_impl "serde_core::ser::Serialize<core::option::Option<@T>>"]
def SerializeOption {T : Type} (i : serde_core.ser.Serialize T) :
    serde_core.ser.Serialize (Option T) :=
  { serialize := fun inst self serializer => SerializeOption.serialize i inst self serializer }

/-- `deref_impl!(<T> Serialize for Box<T>)`: `(**self).serialize(serializer)` (`Box<T>` is `T`). -/
@[rust_fun "serde_core::ser::impls::{serde_core::ser::Serialize<Box<@T>>}::serialize"]
def SerializeBox.serialize {T S Ok Error SS ST STS STV SM SSt SSV : Type}
    (i : serde_core.ser.Serialize T)
    (inst : serde_core.ser.Serializer S Ok Error SS ST STS STV SM SSt SSV)
    (self : T) (serializer : S) : Result (core.result.Result Ok Error) :=
  i.serialize inst self serializer

@[reducible, rust_trait_impl "serde_core::ser::Serialize<Box<@T>>"]
def SerializeBox {T : Type} (i : serde_core.ser.Serialize T) : serde_core.ser.Serialize T :=
  { serialize := fun inst self serializer => SerializeBox.serialize i inst self serializer }

/-- `deref_impl!(<T> Serialize for Arc<T>)` (feature `rc`): `(**self).serialize(serializer)`
    (`Arc<T>` is `T`). -/
@[rust_fun "serde_core::ser::impls::{serde_core::ser::Serialize<alloc::sync::Arc<@T>>}::serialize"]
def SerializeArc.serialize {T S Ok Error SS ST STS STV SM SSt SSV : Type}
    (i : serde_core.ser.Serialize T)
    (inst : serde_core.ser.Serializer S Ok Error SS ST STS STV SM SSt SSV)
    (self : alloc.sync.Arc T) (serializer : S) : Result (core.result.Result Ok Error) :=
  i.serialize inst self serializer

@[reducible, rust_trait_impl "serde_core::ser::Serialize<alloc::sync::Arc<@T>>"]
def SerializeArc {T : Type} (i : serde_core.ser.Serialize T) :
    serde_core.ser.Serialize (alloc.sync.Arc T) :=
  { serialize := fun inst self serializer => SerializeArc.serialize i inst self serializer }

/-! ### Arrays (`array_impls!`: one impl per length, 1 to 32) -/

/-- `for e in self { tri!(seq.serialize_element(e)); }` over `&[T; N]` (items `&T`, serialized
    through `impl Serialize for &T`): the elements in order, until the first error. -/
def serializeTupleElements {T ST Ok Error : Type}
    (tupleInst : serde_core.ser.SerializeTuple ST Ok Error) (d : serde_core.ser.SerializeΩ T) :
    List T → ST → Result (core.result.Result Unit Error × ST)
  | [], seq => ok (.Ok (), seq)
  | e :: rest, seq => do
    let (r, seq) ← tupleInst.serialize_element d seq e
    match r with
    | .Err err => ok (.Err err, seq)
    | .Ok () => serializeTupleElements tupleInst d rest seq

/-- The body of `array_impls!` for the length `N`: `let mut seq =
    tri!(serializer.serialize_tuple(N)); for e in self { tri!(seq.serialize_element(e)); }
    seq.end()`. -/
def SerializeArray.serialize {T S Ok Error SS ST STS STV SM SSt SSV : Type} {N : Usize}
    (i : serde_core.ser.Serialize T)
    (inst : serde_core.ser.Serializer S Ok Error SS ST STS STV SM SSt SSV)
    (self : Array T N) (serializer : S) : Result (core.result.Result Ok Error) := do
  match ← inst.serialize_tuple serializer N with
  | .Err e => ok (.Err e)
  | .Ok seq =>
    let (r, seq) ←
      serializeTupleElements inst.SerializeTupleInst (Serialize.wrap (SerializeShared i)) self.val seq
    match r with
    | .Err e => ok (.Err e)
    | .Ok () => inst.SerializeTupleInst.«end» seq

/-- `impl<T: Serialize> Serialize for [T; 32]`. serde's array impls are one impl per length (the
    macro's literals, no const generic), so each length is its own name pattern: the lengths the
    core uses are registered, any other one stays an unknown external (fail closed). -/
@[rust_fun "serde_core::ser::impls::{serde_core::ser::Serialize<[@T; 32]>}::serialize"]
def SerializeArray32.serialize {T S Ok Error SS ST STS STV SM SSt SSV : Type}
    (i : serde_core.ser.Serialize T)
    (inst : serde_core.ser.Serializer S Ok Error SS ST STS STV SM SSt SSV)
    (self : Array T 32#usize) (serializer : S) : Result (core.result.Result Ok Error) :=
  SerializeArray.serialize i inst self serializer

@[reducible, rust_trait_impl "serde_core::ser::Serialize<[@T; 32]>"]
def SerializeArray32 {T : Type} (i : serde_core.ser.Serialize T) :
    serde_core.ser.Serialize (Array T 32#usize) :=
  { serialize := fun inst self serializer => SerializeArray32.serialize i inst self serializer }

end serde_core.ser.impls

namespace serde_core.de.impls

/-- `concat!("a tuple of size ", 2)` (`TupleVisitor::expecting`, also its `Expected`). -/
def tuple2Expecting (_ : Unit) (formatter : core.fmt.Formatter) : core.fmt.Outcome :=
  formatter.append "a tuple of size 2"

/-- `TupleVisitor<T0, T1>` of `impl Deserialize for (T0, T1)` (de/impls.rs `tuple_impl_body!`):
    `seq.next_element()?` for each component, `Error::invalid_length(i, &self)` when missing. -/
def TupleVisitor2 {T0 T1 : Type} (i0 : serde_core.de.Deserialize T0)
    (i1 : serde_core.de.Deserialize T1) : serde_core.de.Visitor Unit (T0 × T1) :=
  { expecting := tuple2Expecting
    visit_seq := fun {A Error} (seq : serde_core.de.SeqAccess A Error) self access => do
      let (r, access) ← seq.next_element (Deserialize.wrap i0) access
      match r with
      | .Err e => ok (.Err e)
      | .Ok none =>
        ok (.Err (← seq.serde_coredeErrorInst.invalid_length 0#usize (expectedOf tuple2Expecting self)))
      | .Ok (some t0) =>
        let (r, _) ← seq.next_element (Deserialize.wrap i1) access
        match r with
        | .Err e => ok (.Err e)
        | .Ok none =>
          ok (.Err (← seq.serde_coredeErrorInst.invalid_length 1#usize (expectedOf tuple2Expecting self)))
        | .Ok (some t1) => ok (.Ok (t0, t1)) }

/-- `impl<'de, T0: Deserialize, T1: Deserialize> Deserialize<'de> for (T0, T1)`:
    `deserializer.deserialize_tuple(2, TupleVisitor { marker: PhantomData })`. -/
@[rust_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, (@T0, @T1)>}::deserialize"]
def DeserializePair.deserialize {T0 T1 D Error : Type} (i0 : serde_core.de.Deserialize T0)
    (i1 : serde_core.de.Deserialize T1) (inst : serde_core.de.Deserializer D Error)
    (deserializer : D) : Result (core.result.Result (T0 × T1) Error) :=
  inst.deserialize_tuple (Visitor.wrap (TupleVisitor2 i0 i1)) deserializer 2#usize ()

@[reducible, rust_trait_impl "serde_core::de::Deserialize<'de, (@T0, @T1)>"]
def DeserializePair {T0 T1 : Type} (i0 : serde_core.de.Deserialize T0)
    (i1 : serde_core.de.Deserialize T1) : serde_core.de.Deserialize (T0 × T1) :=
  { deserialize := fun inst deserializer => DeserializePair.deserialize i0 i1 inst deserializer }

/-- `Err(Error::invalid_value(unexp, &self))` of a visitor whose `expecting` is `text`. -/
def invalidValue {Value E : Type} (errInst : serde_core.de.Error E) (text : String)
    (unexp : serde_core.de.Unexpected) : Result (core.result.Result Value E) := do
  .ok (.Err (← errInst.invalid_value unexp (expectedOf (fun (_ : Unit) f => f.append text) ())))

def u32OfNat (n : Nat) : U32 := ⟨BitVec.ofNat _ n⟩

/-- `int_to_uint!`: `if 0 <= v { if let Ok(v) = u32::try_from(v as u64) { return Ok(v) } }
    Err(Error::invalid_value(Unexpected::Signed(v as i64), &self))`. -/
def u32OfSigned {Value E : Type} (errInst : serde_core.de.Error E) (wrapOk : U32 → Value)
    (v : Int) (signed : I64) : Result (core.result.Result Value E) :=
  if 0 ≤ v ∧ v ≤ U32.max then .ok (.Ok (wrapOk (u32OfNat v.toNat)))
  else invalidValue errInst "u32" (.Signed signed)

/-- `PrimitiveVisitor` of `impl Deserialize for u32` (de/impls.rs `impl_deserialize_num!`):
    `num_self!(u32)`, `num_as_self!(u8 u16)`, `int_to_uint!(i8 i16 i32 i64)`, `uint_to_self!(u64)`;
    `expecting` is `stringify!(u32)`. -/
def U32Visitor : serde_core.de.Visitor Unit U32 :=
  { expecting := fun _ f => f.append "u32"
    visit_u32 := fun _ _ v => .ok (.Ok v)
    visit_u8 := fun _ _ v => .ok (.Ok (v.cast .U32))
    visit_u16 := fun _ _ v => .ok (.Ok (v.cast .U32))
    visit_i8 := fun e _ v => u32OfSigned e id v.val (v.cast .I64)
    visit_i16 := fun e _ v => u32OfSigned e id v.val (v.cast .I64)
    visit_i32 := fun e _ v => u32OfSigned e id v.val (v.cast .I64)
    visit_i64 := fun e _ v => u32OfSigned e id v.val v
    visit_u64 := fun e _ v =>
      if v.val ≤ U32.max then .ok (.Ok (u32OfNat v.val))
      else invalidValue e "u32" (.Unsigned v) }

/-- `impl Deserialize for u32`: `deserializer.deserialize_u32(PrimitiveVisitor)`. -/
@[rust_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, u32>}::deserialize"]
def DeserializeU32.deserialize {D Error : Type} (inst : serde_core.de.Deserializer D Error)
    (deserializer : D) : Result (core.result.Result U32 Error) :=
  inst.deserialize_u32 (Visitor.wrap U32Visitor) deserializer ()

@[reducible, rust_trait_impl "serde_core::de::Deserialize<'de, u32>"]
def DeserializeU32 : serde_core.de.Deserialize U32 :=
  { deserialize := fun inst deserializer => DeserializeU32.deserialize inst deserializer }

/-- `str::from_utf8`. -/
def utf8? (bytes : List U8) : Option String :=
  String.fromUTF8? ⟨(bytes.map fun b => b.val.toUInt8).toArray⟩

/-- `StringVisitor` of `impl Deserialize for String` (de/impls.rs). -/
def StringVisitor : serde_core.de.Visitor Unit String :=
  { expecting := fun _ f => f.append "a string"
    visit_str := fun _ _ v => do .ok (.Ok (← Str.toString v))
    visit_string := fun _ _ v => .ok (.Ok v)
    visit_bytes := fun e _ v =>
      match utf8? v.val with
      | some s => .ok (.Ok s)
      | none => invalidValue e "a string" (.Bytes v)
    visit_byte_buf := fun e _ v =>
      match utf8? v.val with
      | some s => .ok (.Ok s)
      | none => invalidValue e "a string" (.Bytes v) }

/-- `impl Deserialize for String`: `deserializer.deserialize_string(StringVisitor)`. -/
@[rust_fun
  "serde_core::de::impls::{serde_core::de::Deserialize<'de, alloc::string::String>}::deserialize"]
def DeserializeString.deserialize {D Error : Type} (inst : serde_core.de.Deserializer D Error)
    (deserializer : D) : Result (core.result.Result String Error) :=
  inst.deserialize_string (Visitor.wrap StringVisitor) deserializer ()

@[reducible, rust_trait_impl "serde_core::de::Deserialize<'de, alloc::string::String>"]
def DeserializeString : serde_core.de.Deserialize String :=
  { deserialize := fun inst deserializer => DeserializeString.deserialize inst deserializer }

/-- `OptionVisitor<T>` of `impl Deserialize for Option<T>` (de/impls.rs): `visit_unit` and
    `visit_none` are `Ok(None)`, `visit_some` is `T::deserialize(deserializer).map(Some)`; the
    other `visit_*` are the provided ones (`invalid_type`, expecting "option"). -/
def OptionVisitor {T : Type} (i : serde_core.de.Deserialize T) :
    serde_core.de.Visitor Unit (Option T) :=
  { expecting := fun _ f => f.append "option"
    visit_unit := fun _ _ => .ok (.Ok none)
    visit_none := fun _ _ => .ok (.Ok none)
    visit_some := fun inst _ deserializer => do
      match ← i.deserialize inst deserializer with
      | .Ok v => .ok (.Ok (some v))
      | .Err e => .ok (.Err e) }

/-- `impl<'de, T: Deserialize<'de>> Deserialize<'de> for Option<T>`:
    `deserializer.deserialize_option(OptionVisitor { marker: PhantomData })`. -/
@[rust_fun
  "serde_core::de::impls::{serde_core::de::Deserialize<'de, core::option::Option<@T>>}::deserialize"]
def DeserializeOption.deserialize {T D Error : Type} (i : serde_core.de.Deserialize T)
    (inst : serde_core.de.Deserializer D Error) (deserializer : D) :
    Result (core.result.Result (Option T) Error) :=
  inst.deserialize_option (Visitor.wrap (OptionVisitor i)) deserializer ()

@[reducible, rust_trait_impl "serde_core::de::Deserialize<'de, core::option::Option<@T>>"]
def DeserializeOption {T : Type} (i : serde_core.de.Deserialize T) :
    serde_core.de.Deserialize (Option T) :=
  { deserialize := fun inst deserializer => DeserializeOption.deserialize i inst deserializer }

/-! ### Primitives (`impl_deserialize_num!`, `bool`, `()`) -/

/-- An integer from a visited value `v` given as a signed (`Signed(v as i64)`) or an unsigned
    (`Unsigned(v as u64)`) one: the value when it is within `[lo, hi]`, else
    `Err(Error::invalid_value(unexp, &self))`. -/
def intWithin {Value E : Type} (errInst : serde_core.de.Error E) (name : String) (lo hi : Int)
    (mk : Int → Value) (v : Int) (unexp : serde_core.de.Unexpected) :
    Result (core.result.Result Value E) :=
  if lo ≤ v ∧ v ≤ hi then .ok (.Ok (mk v)) else invalidValue errInst name unexp

/-- `PrimitiveVisitor` of `impl_deserialize_num!` for the integers `i8`, `i16`, `i32`, `i64`, `u8`,
    `u64` and `usize` (de/impls.rs): `expecting` is `stringify!(ty)`, and every `visit_i8` ...
    `visit_i64`, `visit_u8` ... `visit_u64` is one of `num_self!` (`Ok(v)`), `num_as_self!`
    (`Ok(v as ty)`, a widening), `int_to_int!` (`ty::try_from(v as i64)`, else
    `invalid_value(Signed(v as i64))`), `int_to_uint!` (`0 <= v` and `ty::try_from(v as u64)`, else
    `invalid_value(Signed(v as i64))`) or `uint_to_self!` (`ty::try_from(v as u64)`, else
    `invalid_value(Unsigned(v as u64))`): the value when it is within the bounds of `ty` (always
    for the first two), else the error of its sign. The other `visit_*` are the provided ones. -/
def intVisitor {T : Type} (name : String) (lo hi : Int) (mk : Int → T) :
    serde_core.de.Visitor Unit T :=
  let signed := fun {E : Type} (e : serde_core.de.Error E) (v : Int) =>
    intWithin e name lo hi mk v (.Signed ⟨BitVec.ofInt 64 v⟩)
  let unsigned := fun {E : Type} (e : serde_core.de.Error E) (v : Nat) =>
    intWithin e name lo hi mk v (.Unsigned ⟨BitVec.ofNat 64 v⟩)
  { expecting := fun _ f => f.append name
    visit_i8 := fun e _ v => signed e v.val
    visit_i16 := fun e _ v => signed e v.val
    visit_i32 := fun e _ v => signed e v.val
    visit_i64 := fun e _ v => signed e v.val
    visit_u8 := fun e _ v => unsigned e v.val
    visit_u16 := fun e _ v => unsigned e v.val
    visit_u32 := fun e _ v => unsigned e v.val
    visit_u64 := fun e _ v => unsigned e v.val }

def I8Visitor : serde_core.de.Visitor Unit I8 :=
  intVisitor "i8" I8.min I8.max fun v => ⟨BitVec.ofInt _ v⟩
def I16Visitor : serde_core.de.Visitor Unit I16 :=
  intVisitor "i16" I16.min I16.max fun v => ⟨BitVec.ofInt _ v⟩
def I32Visitor : serde_core.de.Visitor Unit I32 :=
  intVisitor "i32" I32.min I32.max fun v => ⟨BitVec.ofInt _ v⟩
def I64Visitor : serde_core.de.Visitor Unit I64 :=
  intVisitor "i64" I64.min I64.max fun v => ⟨BitVec.ofInt _ v⟩
def U8Visitor : serde_core.de.Visitor Unit U8 :=
  intVisitor "u8" 0 U8.max fun v => ⟨BitVec.ofNat _ v.toNat⟩
def U64Visitor : serde_core.de.Visitor Unit U64 :=
  intVisitor "u64" 0 U64.max fun v => ⟨BitVec.ofNat _ v.toNat⟩
def UsizeVisitor : serde_core.de.Visitor Unit Usize :=
  intVisitor "usize" 0 Usize.max fun v => ⟨BitVec.ofNat _ v.toNat⟩

/-- `impl Deserialize for i8`: `deserializer.deserialize_i8(PrimitiveVisitor)`. -/
@[rust_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, i8>}::deserialize"]
def DeserializeI8.deserialize {D Error : Type} (inst : serde_core.de.Deserializer D Error)
    (deserializer : D) : Result (core.result.Result I8 Error) :=
  inst.deserialize_i8 (Visitor.wrap I8Visitor) deserializer ()

@[reducible, rust_trait_impl "serde_core::de::Deserialize<'de, i8>"]
def DeserializeI8 : serde_core.de.Deserialize I8 :=
  { deserialize := fun inst deserializer => DeserializeI8.deserialize inst deserializer }

/-- `impl Deserialize for i16`: `deserializer.deserialize_i16(PrimitiveVisitor)`. -/
@[rust_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, i16>}::deserialize"]
def DeserializeI16.deserialize {D Error : Type} (inst : serde_core.de.Deserializer D Error)
    (deserializer : D) : Result (core.result.Result I16 Error) :=
  inst.deserialize_i16 (Visitor.wrap I16Visitor) deserializer ()

@[reducible, rust_trait_impl "serde_core::de::Deserialize<'de, i16>"]
def DeserializeI16 : serde_core.de.Deserialize I16 :=
  { deserialize := fun inst deserializer => DeserializeI16.deserialize inst deserializer }

/-- `impl Deserialize for i32`: `deserializer.deserialize_i32(PrimitiveVisitor)`. -/
@[rust_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, i32>}::deserialize"]
def DeserializeI32.deserialize {D Error : Type} (inst : serde_core.de.Deserializer D Error)
    (deserializer : D) : Result (core.result.Result I32 Error) :=
  inst.deserialize_i32 (Visitor.wrap I32Visitor) deserializer ()

@[reducible, rust_trait_impl "serde_core::de::Deserialize<'de, i32>"]
def DeserializeI32 : serde_core.de.Deserialize I32 :=
  { deserialize := fun inst deserializer => DeserializeI32.deserialize inst deserializer }

/-- `impl Deserialize for i64`: `deserializer.deserialize_i64(PrimitiveVisitor)`. -/
@[rust_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, i64>}::deserialize"]
def DeserializeI64.deserialize {D Error : Type} (inst : serde_core.de.Deserializer D Error)
    (deserializer : D) : Result (core.result.Result I64 Error) :=
  inst.deserialize_i64 (Visitor.wrap I64Visitor) deserializer ()

@[reducible, rust_trait_impl "serde_core::de::Deserialize<'de, i64>"]
def DeserializeI64 : serde_core.de.Deserialize I64 :=
  { deserialize := fun inst deserializer => DeserializeI64.deserialize inst deserializer }

/-- `impl Deserialize for u8`: `deserializer.deserialize_u8(PrimitiveVisitor)`. -/
@[rust_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, u8>}::deserialize"]
def DeserializeU8.deserialize {D Error : Type} (inst : serde_core.de.Deserializer D Error)
    (deserializer : D) : Result (core.result.Result U8 Error) :=
  inst.deserialize_u8 (Visitor.wrap U8Visitor) deserializer ()

@[reducible, rust_trait_impl "serde_core::de::Deserialize<'de, u8>"]
def DeserializeU8 : serde_core.de.Deserialize U8 :=
  { deserialize := fun inst deserializer => DeserializeU8.deserialize inst deserializer }

/-- `impl Deserialize for u64`: `deserializer.deserialize_u64(PrimitiveVisitor)`. -/
@[rust_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, u64>}::deserialize"]
def DeserializeU64.deserialize {D Error : Type} (inst : serde_core.de.Deserializer D Error)
    (deserializer : D) : Result (core.result.Result U64 Error) :=
  inst.deserialize_u64 (Visitor.wrap U64Visitor) deserializer ()

@[reducible, rust_trait_impl "serde_core::de::Deserialize<'de, u64>"]
def DeserializeU64 : serde_core.de.Deserialize U64 :=
  { deserialize := fun inst deserializer => DeserializeU64.deserialize inst deserializer }

/-- `impl Deserialize for usize`: `deserializer.deserialize_u64(PrimitiveVisitor)`. -/
@[rust_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, usize>}::deserialize"]
def DeserializeUsize.deserialize {D Error : Type} (inst : serde_core.de.Deserializer D Error)
    (deserializer : D) : Result (core.result.Result Usize Error) :=
  inst.deserialize_u64 (Visitor.wrap UsizeVisitor) deserializer ()

@[reducible, rust_trait_impl "serde_core::de::Deserialize<'de, usize>"]
def DeserializeUsize : serde_core.de.Deserialize Usize :=
  { deserialize := fun inst deserializer => DeserializeUsize.deserialize inst deserializer }

/-- `(v as f64).copysign(sign)` of `num_as_copysign_self!(f32:visit_f32)` (feature `std`): the
    conversion with the sign bit of `v`. A NaN converts to the preferred NaN (`F32.toF64`), one of
    the payloads Rust's `as` may give (the other is the input's payload, quieted). -/
def f64OfF32CopySign (v : F32) : F64 :=
  let signBit : BitVec BinaryFormat.binary64.width := BitVec.ofNat _ (2 ^ 63)
  let magnitude := (F32.toF64 v).bits &&& ~~~signBit
  ⟨if BinaryFloat.sign v then magnitude ||| signBit else magnitude⟩

/-- `PrimitiveVisitor` of `impl_deserialize_num!(f64, deserialize_f64 ..)`: `num_self!(f64)`,
    `num_as_copysign_self!(f32)`, `num_as_self!(i8 i16 i32 i64 u8 u16 u32 u64)` (`v as f64`, rounded
    to nearest). -/
def F64Visitor : serde_core.de.Visitor Unit F64 :=
  { expecting := fun _ f => f.append "f64"
    visit_f64 := fun _ _ v => .ok (.Ok v)
    visit_f32 := fun _ _ v => .ok (.Ok (f64OfF32CopySign v))
    visit_i8 := fun _ _ v => .ok (.Ok (F64.ofIScalar v))
    visit_i16 := fun _ _ v => .ok (.Ok (F64.ofIScalar v))
    visit_i32 := fun _ _ v => .ok (.Ok (F64.ofIScalar v))
    visit_i64 := fun _ _ v => .ok (.Ok (F64.ofIScalar v))
    visit_u8 := fun _ _ v => .ok (.Ok (F64.ofUScalar v))
    visit_u16 := fun _ _ v => .ok (.Ok (F64.ofUScalar v))
    visit_u32 := fun _ _ v => .ok (.Ok (F64.ofUScalar v))
    visit_u64 := fun _ _ v => .ok (.Ok (F64.ofUScalar v)) }

/-- `impl Deserialize for f64`: `deserializer.deserialize_f64(PrimitiveVisitor)`. -/
@[rust_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, f64>}::deserialize"]
def DeserializeF64.deserialize {D Error : Type} (inst : serde_core.de.Deserializer D Error)
    (deserializer : D) : Result (core.result.Result F64 Error) :=
  inst.deserialize_f64 (Visitor.wrap F64Visitor) deserializer ()

@[reducible, rust_trait_impl "serde_core::de::Deserialize<'de, f64>"]
def DeserializeF64 : serde_core.de.Deserialize F64 :=
  { deserialize := fun inst deserializer => DeserializeF64.deserialize inst deserializer }

/-- `BoolVisitor`: `expecting` is "a boolean", `visit_bool` is `Ok(v)`. -/
def BoolVisitor : serde_core.de.Visitor Unit Bool :=
  { expecting := fun _ f => f.append "a boolean"
    visit_bool := fun _ _ v => .ok (.Ok v) }

/-- `impl Deserialize for bool`: `deserializer.deserialize_bool(BoolVisitor)`. -/
@[rust_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, bool>}::deserialize"]
def DeserializeBool.deserialize {D Error : Type} (inst : serde_core.de.Deserializer D Error)
    (deserializer : D) : Result (core.result.Result Bool Error) :=
  inst.deserialize_bool (Visitor.wrap BoolVisitor) deserializer ()

@[reducible, rust_trait_impl "serde_core::de::Deserialize<'de, bool>"]
def DeserializeBool : serde_core.de.Deserialize Bool :=
  { deserialize := fun inst deserializer => DeserializeBool.deserialize inst deserializer }

/-- `UnitVisitor`: `expecting` is "unit", `visit_unit` is `Ok(())`. -/
def UnitVisitor : serde_core.de.Visitor Unit Unit :=
  { expecting := fun _ f => f.append "unit"
    visit_unit := fun _ _ => .ok (.Ok ()) }

/-- `impl Deserialize for ()`: `deserializer.deserialize_unit(UnitVisitor)`. -/
@[rust_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, ()>}::deserialize"]
def DeserializeUnit.deserialize {D Error : Type} (inst : serde_core.de.Deserializer D Error)
    (deserializer : D) : Result (core.result.Result Unit Error) :=
  inst.deserialize_unit (Visitor.wrap UnitVisitor) deserializer ()

@[reducible, rust_trait_impl "serde_core::de::Deserialize<'de, ()>"]
def DeserializeUnit : serde_core.de.Deserialize Unit :=
  { deserialize := fun inst deserializer => DeserializeUnit.deserialize inst deserializer }

/-! ### Collections (`seq_impl!`, `map_impl!`, `forwarded_impl!`, `box_forwarded_impl!`) -/

/-- `while let Some(value) = tri!(seq.next_element()) { insert(&mut values, value); }` then
    `Ok(values)`: the elements in order through `insert`, until the first error or the end. -/
def collectElements {A Error T C : Type} (seq : serde_core.de.SeqAccess A Error)
    (d : serde_core.de.DeserializeΩ T) (insert : C → T → Result C) (values : C) (access : A) :
    Result (core.result.Result C Error) := do
  let (r, access) ← seq.next_element d access
  match r with
  | .Err e => ok (.Err e)
  | .Ok none => ok (.Ok values)
  | .Ok (some value) => collectElements seq d insert (← insert values value) access
partial_fixpoint

/-- `while let Some((key, value)) = tri!(map.next_entry()) { values.insert(key, value); }` then
    `Ok(values)`. -/
def collectEntries {A Error K V C : Type} (map : serde_core.de.MapAccess A Error)
    (dk : serde_core.de.DeserializeΩ K) (dv : serde_core.de.DeserializeΩ V)
    (insert : C → K → V → Result C) (values : C) (access : A) :
    Result (core.result.Result C Error) := do
  let (r, access) ← map.next_entry dk dv access
  match r with
  | .Err e => ok (.Err e)
  | .Ok none => ok (.Ok values)
  | .Ok (some (key, value)) => collectEntries map dk dv insert (← insert values key value) access
partial_fixpoint

/-- `VecVisitor<T>` of `impl Deserialize for Vec<T>` (de/impls.rs): `expecting` is "a sequence";
    `visit_seq` reads `seq.size_hint()` (for the capacity only: `size_hint::cautious` caps it, the
    allocation has no other effect), then pushes every element. -/
def VecVisitor {T : Type} (i : serde_core.de.Deserialize T) :
    serde_core.de.Visitor Unit (alloc.vec.Vec T) :=
  { expecting := fun _ f => f.append "a sequence"
    visit_seq := fun {A Error} (seq : serde_core.de.SeqAccess A Error) _ access => do
      let _ ← seq.size_hint access
      collectElements seq (Deserialize.wrap i) (fun values value => alloc.vec.Vec.push values value)
        (alloc.vec.Vec.new T) access }

/-- `impl<'de, T: Deserialize<'de>> Deserialize<'de> for Vec<T>`:
    `deserializer.deserialize_seq(VecVisitor { marker: PhantomData })`. -/
@[rust_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, alloc::vec::Vec<@T>>}::deserialize"]
def DeserializeVec.deserialize {T D Error : Type} (i : serde_core.de.Deserialize T)
    (inst : serde_core.de.Deserializer D Error) (deserializer : D) :
    Result (core.result.Result (alloc.vec.Vec T) Error) :=
  inst.deserialize_seq (Visitor.wrap (VecVisitor i)) deserializer ()

@[reducible, rust_trait_impl "serde_core::de::Deserialize<'de, alloc::vec::Vec<@T>>"]
def DeserializeVec {T : Type} (i : serde_core.de.Deserialize T) :
    serde_core.de.Deserialize (alloc.vec.Vec T) :=
  { deserialize := fun inst deserializer => DeserializeVec.deserialize i inst deserializer }

/-- `SeqVisitor` of `seq_impl!(BTreeSet<T: Eq + Ord>, seq, BTreeSet::clear, BTreeSet::new(),
    nop_reserve, BTreeSet::insert)`: `expecting` is "a sequence"; `visit_seq` inserts every
    element (an element equal to a stored one keeps the stored one). -/
def BTreeSetVisitor {T : Type} (i : serde_core.de.Deserialize T) (ord : core.cmp.Ord T) :
    serde_core.de.Visitor Unit (alloc.collections.btree.set.BTreeSet T) :=
  { expecting := fun _ f => f.append "a sequence"
    visit_seq := fun {A Error} (seq : serde_core.de.SeqAccess A Error) _ access => do
      collectElements seq (Deserialize.wrap i)
        (fun values value => do
          let (_, values) ← alloc.collections.btree.set.BTreeSet.insert ord values value
          ok values)
        (← alloc.collections.btree.set.BTreeSet.new T) access }

/-- `impl<'de, T: Deserialize<'de> + Eq + Ord> Deserialize<'de> for BTreeSet<T>` (`seq_impl!`):
    `deserializer.deserialize_seq(SeqVisitor { marker: PhantomData })`. -/
@[rust_fun
  "serde_core::de::impls::{serde_core::de::Deserialize<'de, alloc::collections::btree::set::BTreeSet<@T, alloc::alloc::Global>>}::deserialize"]
def DeserializeBTreeSet.deserialize {T D Error : Type} (i : serde_core.de.Deserialize T)
    (_ : core.cmp.Eq T) (ord : core.cmp.Ord T) (inst : serde_core.de.Deserializer D Error)
    (deserializer : D) :
    Result (core.result.Result (alloc.collections.btree.set.BTreeSet T) Error) :=
  inst.deserialize_seq (Visitor.wrap (BTreeSetVisitor i ord)) deserializer ()

@[reducible, rust_trait_impl
  "serde_core::de::Deserialize<'de, alloc::collections::btree::set::BTreeSet<@T, alloc::alloc::Global>>"]
def DeserializeBTreeSet {T : Type} (i : serde_core.de.Deserialize T) (eq : core.cmp.Eq T)
    (ord : core.cmp.Ord T) : serde_core.de.Deserialize (alloc.collections.btree.set.BTreeSet T) :=
  { deserialize := fun inst deserializer =>
      DeserializeBTreeSet.deserialize i eq ord inst deserializer }

/-- `MapVisitor` of `map_impl!(BTreeMap<K: Ord, V>, map, BTreeMap::new())`: `expecting` is "a map";
    `visit_map` inserts every entry (`values.insert(key, value)`: a later value of an equal key
    replaces the earlier one, the stored key stays). -/
def BTreeMapVisitor {K V : Type} (ki : serde_core.de.Deserialize K) (ord : core.cmp.Ord K)
    (vi : serde_core.de.Deserialize V) :
    serde_core.de.Visitor Unit (alloc.collections.btree.map.BTreeMap K V) :=
  { expecting := fun _ f => f.append "a map"
    visit_map := fun {A Error} (map : serde_core.de.MapAccess A Error) _ access => do
      collectEntries map (Deserialize.wrap ki) (Deserialize.wrap vi)
        (fun values key value => do
          let (_, values) ← alloc.collections.btree.map.BTreeMap.insert ord values key value
          ok values)
        (← alloc.collections.btree.map.BTreeMap.new K V) access }

/-- `impl<'de, K: Deserialize<'de> + Ord, V: Deserialize<'de>> Deserialize<'de> for BTreeMap<K, V>`
    (`map_impl!`): `deserializer.deserialize_map(MapVisitor { marker: PhantomData })`. -/
@[rust_fun
  "serde_core::de::impls::{serde_core::de::Deserialize<'de, alloc::collections::btree::map::BTreeMap<@K, @V, alloc::alloc::Global>>}::deserialize"]
def DeserializeBTreeMap.deserialize {K V D Error : Type} (ki : serde_core.de.Deserialize K)
    (ord : core.cmp.Ord K) (vi : serde_core.de.Deserialize V)
    (inst : serde_core.de.Deserializer D Error) (deserializer : D) :
    Result (core.result.Result (alloc.collections.btree.map.BTreeMap K V) Error) :=
  inst.deserialize_map (Visitor.wrap (BTreeMapVisitor ki ord vi)) deserializer ()

@[reducible, rust_trait_impl
  "serde_core::de::Deserialize<'de, alloc::collections::btree::map::BTreeMap<@K, @V, alloc::alloc::Global>>"]
def DeserializeBTreeMap {K V : Type} (ki : serde_core.de.Deserialize K) (ord : core.cmp.Ord K)
    (vi : serde_core.de.Deserialize V) :
    serde_core.de.Deserialize (alloc.collections.btree.map.BTreeMap K V) :=
  { deserialize := fun inst deserializer =>
      DeserializeBTreeMap.deserialize ki ord vi inst deserializer }

/-- `forwarded_impl!((T), Box<T>, Box::new)`: `Deserialize::deserialize(deserializer).map(Box::new)`
    (`Box<T>` is `T`). -/
@[rust_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, Box<@T>>}::deserialize"]
def DeserializeBox.deserialize {T D Error : Type} (i : serde_core.de.Deserialize T)
    (inst : serde_core.de.Deserializer D Error) (deserializer : D) :
    Result (core.result.Result T Error) :=
  i.deserialize inst deserializer

@[reducible, rust_trait_impl "serde_core::de::Deserialize<'de, Box<@T>>"]
def DeserializeBox {T : Type} (i : serde_core.de.Deserialize T) : serde_core.de.Deserialize T :=
  { deserialize := fun inst deserializer => DeserializeBox.deserialize i inst deserializer }

/-- `box_forwarded_impl!(Arc)` (feature `rc`), with the clause `Box<T>: Deserialize<'de>`:
    `Box::deserialize(deserializer).map(Into::into)` (`Box<T>` and `Arc<T>` are `T`). -/
@[rust_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, alloc::sync::Arc<@T>>}::deserialize"]
def DeserializeArc.deserialize {T D Error : Type} (boxInst : serde_core.de.Deserialize T)
    (inst : serde_core.de.Deserializer D Error) (deserializer : D) :
    Result (core.result.Result (alloc.sync.Arc T) Error) :=
  boxInst.deserialize inst deserializer

@[reducible, rust_trait_impl "serde_core::de::Deserialize<'de, alloc::sync::Arc<@T>>"]
def DeserializeArc {T : Type} (boxInst : serde_core.de.Deserialize T) :
    serde_core.de.Deserialize (alloc.sync.Arc T) :=
  { deserialize := fun inst deserializer => DeserializeArc.deserialize boxInst inst deserializer }

/-! ### Arrays (`array_impls!`: one impl per length, 1 to 32) -/

/-- `concat!("an array of length ", N)` (`ArrayVisitor<[T; N]>::expecting`, also its
    `Expected`). -/
def arrayExpecting (len : Nat) (_ : Unit) (formatter : core.fmt.Formatter) : core.fmt.Outcome :=
  formatter.append s!"an array of length {len}"

/-- The elements `n`, `n + 1`, ... of `ArrayVisitor::visit_seq`'s array literal, `k` of them:
    each is `match tri!(seq.next_element()) { Some(val) => val, None => return
    Err(Error::invalid_length(n, &self)) }`, in order (the first error or the first missing element
    ends the visit; the elements read before are dropped). -/
def arrayElements {A Error T : Type} (seq : serde_core.de.SeqAccess A Error)
    (d : serde_core.de.DeserializeΩ T) (expected : serde_core.de.DynExpected) (n : Nat) :
    (k : Nat) → A → Result (core.result.Result { l : List T // l.length = k } Error)
  | 0, _ => ok (.Ok ⟨[], rfl⟩)
  | k + 1, access => do
    let (r, access) ← seq.next_element d access
    match r with
    | .Err e => ok (.Err e)
    | .Ok none =>
      ok (.Err (← seq.serde_coredeErrorInst.invalid_length ⟨BitVec.ofNat _ n⟩ expected))
    | .Ok (some v) =>
      match ← arrayElements seq d expected (n + 1) k access with
      | .Err e => ok (.Err e)
      | .Ok vs => ok (.Ok ⟨v :: vs.val, by simp [vs.property]⟩)

/-- `ArrayVisitor<[T; N]>` (de/impls.rs `array_impls!`, `N` from 1 to 32): `expecting` is
    "an array of length N"; `visit_seq` reads the `N` elements (a longer sequence is not checked
    here: the remaining elements are the deserializer's). -/
def ArrayVisitor {T : Type} (i : serde_core.de.Deserialize T) (N : Usize) :
    serde_core.de.Visitor Unit (Array T N) :=
  { expecting := arrayExpecting N.val
    visit_seq := fun {A Error} (seq : serde_core.de.SeqAccess A Error) self access => do
      match ← arrayElements seq (Deserialize.wrap i) (expectedOf (arrayExpecting N.val) self) 0
          N.val access with
      | .Err e => ok (.Err e)
      | .Ok vs => ok (.Ok ⟨vs.val, vs.property⟩) }

/-- `impl<'de, T: Deserialize<'de>> Deserialize<'de> for [T; 32]` (`array_impls!`):
    `deserializer.deserialize_tuple(32, ArrayVisitor::<[T; 32]>::new())`. One impl per length:
    the lengths the core uses are registered, any other one stays an unknown external. -/
@[rust_fun "serde_core::de::impls::{serde_core::de::Deserialize<'de, [@T; 32]>}::deserialize"]
def DeserializeArray32.deserialize {T D Error : Type} (i : serde_core.de.Deserialize T)
    (inst : serde_core.de.Deserializer D Error) (deserializer : D) :
    Result (core.result.Result (Array T 32#usize) Error) :=
  inst.deserialize_tuple (Visitor.wrap (ArrayVisitor i 32#usize)) deserializer 32#usize ()

@[reducible, rust_trait_impl "serde_core::de::Deserialize<'de, [@T; 32]>"]
def DeserializeArray32 {T : Type} (i : serde_core.de.Deserialize T) :
    serde_core.de.Deserialize (Array T 32#usize) :=
  { deserialize := fun inst deserializer => DeserializeArray32.deserialize i inst deserializer }

/-! ### `IgnoredAny` (de/ignored_any.rs)

`IgnoredAny` is a unit struct (its Lean type is `Unit`). `impl Visitor for IgnoredAny` accepts every
value and drops it: the scalars, `visit_none` and `visit_unit` are `Ok(IgnoredAny)`,
`visit_some` and `visit_newtype_struct` are `IgnoredAny::deserialize(deserializer)`, `visit_seq`
reads the elements as `IgnoredAny` until the end, `visit_map` the entries, `visit_enum` the variant
then its content as a newtype variant, each stopping at the first error. `impl Deserialize for
IgnoredAny` is `deserializer.deserialize_ignored_any(IgnoredAny)`. The visitor deserializes nested
values with itself, so its dictionaries are built level by level of the knot (`DeAt`): the visitor
at level `n + 1` reads nested values with the dictionaries at level `n`, as `Visitor.wrap` projects
a visitor of `Ω` (`proj n`). -/

/-- `while let Some(IgnoredAny) = tri!(seq.next_element()) {}` then `Ok(IgnoredAny)`. -/
def ignoredElements {X : serde_core.de.Fam} {A Error : Type}
    (seq : serde_core.de.SeqAccessF X A Error) (d : X.Deserialize Unit) (access : A) :
    Result (core.result.Result Unit Error) := do
  let (r, access) ← seq.next_element d access
  match r with
  | .Err e => ok (.Err e)
  | .Ok none => ok (.Ok ())
  | .Ok (some ()) => ignoredElements seq d access
partial_fixpoint

/-- `while let Some((IgnoredAny, IgnoredAny)) = tri!(map.next_entry()) {}` then `Ok(IgnoredAny)`. -/
def ignoredEntries {X : serde_core.de.Fam} {A Error : Type}
    (map : serde_core.de.MapAccessF X A Error) (d : X.Deserialize Unit) (access : A) :
    Result (core.result.Result Unit Error) := do
  let (r, access) ← map.next_entry d d access
  match r with
  | .Err e => ok (.Err e)
  | .Ok none => ok (.Ok ())
  | .Ok (some ((), ())) => ignoredEntries map d access
partial_fixpoint

/-- `impl Visitor for IgnoredAny` one level above the dictionaries `d` (its `Deserialize`) and
    `v` (its `Visitor`) of the knot family `X`. -/
def ignoredAnyVisitorStep {X : serde_core.de.Fam} (d : X.Deserialize Unit)
    (v : X.Visitor Unit Unit) : serde_core.de.VisitorStep X Unit Unit :=
  { expecting := fun _ f => f.append "anything at all"
    visit_bool := fun _ _ _ => ok (.Ok ())
    visit_i64 := fun _ _ _ => ok (.Ok ())
    visit_i128 := fun _ _ _ => ok (.Ok ())
    visit_u64 := fun _ _ _ => ok (.Ok ())
    visit_u128 := fun _ _ _ => ok (.Ok ())
    visit_f64 := fun _ _ _ => ok (.Ok ())
    visit_str := fun _ _ _ => ok (.Ok ())
    visit_none := fun _ _ => ok (.Ok ())
    visit_some := fun inst _ deserializer => inst.deserialize_ignored_any v deserializer ()
    visit_newtype_struct := fun inst _ deserializer =>
      inst.deserialize_ignored_any v deserializer ()
    visit_unit := fun _ _ => ok (.Ok ())
    visit_seq := fun seq _ access => ignoredElements seq d access
    visit_map := fun map _ access => ignoredEntries map d access
    visit_bytes := fun _ _ _ => ok (.Ok ())
    visit_enum := fun data _ access => do
      match ← data.variant d access with
      | .Err e => ok (.Err e)
      | .Ok ((), variant) => data.VariantAccessInst.newtype_variant d variant }

/-- The dictionaries of `IgnoredAny` at level `n` of the knot: `impl Deserialize` and
    `impl Visitor`. -/
def ignoredAnyAt : (n : Nat) →
    (serde_core.de.DeAt n).Deserialize Unit × (serde_core.de.DeAt n).Visitor Unit Unit
  | 0 => (PUnit.unit, PUnit.unit)
  | n + 1 =>
    let below := ignoredAnyAt n
    (⟨fun inst deserializer => inst.deserialize_ignored_any below.2 deserializer ()⟩,
      ignoredAnyVisitorStep below.1 below.2)

/-- `IgnoredAny` as the visitor of the Rust traits (`Ω`). -/
def IgnoredAnyVisitor : serde_core.de.VisitorΩ Unit Unit := ⟨fun n => (ignoredAnyAt n).2⟩

/-- `impl<'de> Deserialize<'de> for IgnoredAny`: `deserializer.deserialize_ignored_any(IgnoredAny)`. -/
@[rust_fun
  "serde_core::de::ignored_any::{serde_core::de::Deserialize<'de, serde_core::de::ignored_any::IgnoredAny>}::deserialize"]
def DeserializeIgnoredAny.deserialize {D Error : Type} (inst : serde_core.de.Deserializer D Error)
    (deserializer : D) : Result (core.result.Result Unit Error) :=
  inst.deserialize_ignored_any IgnoredAnyVisitor deserializer ()

@[reducible, rust_trait_impl
  "serde_core::de::Deserialize<'de, serde_core::de::ignored_any::IgnoredAny>"]
def DeserializeIgnoredAny : serde_core.de.Deserialize Unit :=
  { deserialize := fun inst deserializer => DeserializeIgnoredAny.deserialize inst deserializer }

/-- The knot is the level-wise construction: `Deserialize.wrap DeserializeIgnoredAny` is, at every
    level, the level's `impl Deserialize for IgnoredAny`. -/
theorem DeserializeIgnoredAny.wrap_level (n : Nat) :
    (serde_core.de.Deserialize.wrap DeserializeIgnoredAny).level n = (ignoredAnyAt n).1 := by
  cases n <;> rfl

end serde_core.de.impls

end Aeneas.Std
