import Aeneas.Extract
import Aeneas.Std.Primitives
import Aeneas.Std.Core.Ops

namespace Aeneas.Std

open Result

@[rust_trait "core::cmp::PartialEq" (defaultMethods := ["ne"])]
structure core.cmp.PartialEq (Self : Type) (Rhs : Type) where
  eq : Self → Rhs → Result Bool
  ne : Self → Rhs → Result Bool := fun self other => do ok (not (← eq self other))

@[rust_trait "core::cmp::Eq" (parentClauses := ["partialEqInst"])
  (defaultMethods := ["assert_receiver_is_total_eq"])]
structure core.cmp.Eq (Self : Type) where
  partialEqInst : core.cmp.PartialEq Self Self
  assert_receiver_is_total_eq (_ : Self) : Result Unit := .ok ()

@[simp]
def core.cmp.Eq.assert_receiver_is_total_eq.default
  {Self : Type} (EqInst : core.cmp.Eq Self) (x : Self) : Result Unit :=
  EqInst.assert_receiver_is_total_eq x

/- Default method -/
def core.cmp.PartialEq.ne.default {Self Rhs : Type} (eq : Self → Rhs → Result Bool)
  (self : Self) (other : Rhs) : Result Bool := do
  ok (¬ (← eq self other))

/- We model the Rust ordering with the native Lean ordering -/
attribute
  [rust_type "core::cmp::Ordering"
  (body := .enum [⟨"Less", "lt", none⟩, ⟨"Equal", "eq", none⟩, ⟨"Greater", "gt", none⟩])]
  Ordering

/- Auxiliary functions for the default implementations of `PartialOrd` methods -/
def core.cmp.PartialOrd.lt_body {Self Rhs : Type}
  (partial_cmp : Self → Rhs → Result (Option Ordering))
  (x : Self) (y : Rhs) : Result Bool := do
  let cmp ← partial_cmp x y
  ok (cmp = some .lt)

def core.cmp.PartialOrd.le_body {Self Rhs : Type}
  (partial_cmp : Self → Rhs → Result (Option Ordering))
  (x : Self) (y : Rhs) : Result Bool := do
  let cmp ← partial_cmp x y
  ok (cmp = some .lt ∨ cmp = some .eq)

def core.cmp.PartialOrd.gt_body {Self Rhs : Type}
  (partial_cmp : Self → Rhs → Result (Option Ordering))
  (x : Self) (y : Rhs) : Result Bool := do
  let cmp ← partial_cmp x y
  ok (cmp = some .gt)

def core.cmp.PartialOrd.ge_body {Self Rhs : Type}
  (partial_cmp : Self → Rhs → Result (Option Ordering))
  (x : Self) (y : Rhs) : Result Bool := do
  let cmp ← partial_cmp x y
  ok (cmp = some .gt ∨ cmp = some .eq)

def core.cmp.PartialOrd.chaining_body {Self Rhs : Type}
  (test : Ordering → Bool)
  (partial_cmp : Self → Rhs → Result (Option Ordering))
  (x : Self) (y : Rhs) : Result (core.ops.control_flow.ControlFlow Bool Unit) := do
  match ← partial_cmp x y with
  | some .eq => ok (.Continue ())
  | some ordering => ok (.Break (test ordering))
  | none => ok (.Break false)

@[rust_trait "core::cmp::PartialOrd" (parentClauses := ["partialEqInst"])
  (defaultMethods := ["lt", "le", "gt", "ge",
    "__chaining_lt", "__chaining_le", "__chaining_gt", "__chaining_ge"])]
structure core.cmp.PartialOrd (Self : Type) (Rhs : Type) where
  partialEqInst : core.cmp.PartialEq Self Rhs
  partial_cmp : Self → Rhs → Result (Option Ordering)
  lt : Self → Rhs → Result Bool := core.cmp.PartialOrd.lt_body partial_cmp
  le : Self → Rhs → Result Bool := core.cmp.PartialOrd.le_body partial_cmp
  gt : Self → Rhs → Result Bool := core.cmp.PartialOrd.gt_body partial_cmp
  ge : Self → Rhs → Result Bool := core.cmp.PartialOrd.ge_body partial_cmp
  __chaining_lt : Self → Rhs → Result (core.ops.control_flow.ControlFlow Bool Unit) :=
    core.cmp.PartialOrd.chaining_body (· == .lt) partial_cmp
  __chaining_le : Self → Rhs → Result (core.ops.control_flow.ControlFlow Bool Unit) :=
    core.cmp.PartialOrd.chaining_body (· != .gt) partial_cmp
  __chaining_gt : Self → Rhs → Result (core.ops.control_flow.ControlFlow Bool Unit) :=
    core.cmp.PartialOrd.chaining_body (· == .gt) partial_cmp
  __chaining_ge : Self → Rhs → Result (core.ops.control_flow.ControlFlow Bool Unit) :=
    core.cmp.PartialOrd.chaining_body (· != .lt) partial_cmp

/- Default method -/
def core.cmp.PartialOrd.lt.default {Self Rhs : Type}
  (partial_cmp : Self → Rhs → Result (Option Ordering))
  (x : Self) (y : Rhs) : Result Bool :=
  core.cmp.PartialOrd.lt_body partial_cmp x y

/- Default method -/
def core.cmp.PartialOrd.le.default {Self Rhs : Type}
  (partial_cmp : Self → Rhs → Result (Option Ordering))
  (x : Self) (y : Rhs) : Result Bool :=
  core.cmp.PartialOrd.le_body partial_cmp x y

/- Default method -/
def core.cmp.PartialOrd.gt.default {Self Rhs : Type}
  (partial_cmp : Self → Rhs → Result (Option Ordering))
  (x : Self) (y : Rhs) : Result Bool :=
  core.cmp.PartialOrd.gt_body partial_cmp x y

/- Default method -/
def core.cmp.PartialOrd.ge.default {Self Rhs : Type}
  (partial_cmp : Self → Rhs → Result (Option Ordering))
  (x : Self) (y : Rhs) : Result Bool :=
  core.cmp.PartialOrd.ge_body partial_cmp x y

def core.cmp.PartialOrd.__chaining_lt.default {Self Rhs : Type}
  (partial_cmp : Self → Rhs → Result (Option Ordering))
  (x : Self) (y : Rhs) : Result (core.ops.control_flow.ControlFlow Bool Unit) :=
  core.cmp.PartialOrd.chaining_body (· == .lt) partial_cmp x y

def core.cmp.PartialOrd.__chaining_le.default {Self Rhs : Type}
  (partial_cmp : Self → Rhs → Result (Option Ordering))
  (x : Self) (y : Rhs) : Result (core.ops.control_flow.ControlFlow Bool Unit) :=
  core.cmp.PartialOrd.chaining_body (· != .gt) partial_cmp x y

def core.cmp.PartialOrd.__chaining_gt.default {Self Rhs : Type}
  (partial_cmp : Self → Rhs → Result (Option Ordering))
  (x : Self) (y : Rhs) : Result (core.ops.control_flow.ControlFlow Bool Unit) :=
  core.cmp.PartialOrd.chaining_body (· == .gt) partial_cmp x y

def core.cmp.PartialOrd.__chaining_ge.default {Self Rhs : Type}
  (partial_cmp : Self → Rhs → Result (Option Ordering))
  (x : Self) (y : Rhs) : Result (core.ops.control_flow.ControlFlow Bool Unit) :=
  core.cmp.PartialOrd.chaining_body (· != .lt) partial_cmp x y

/- Auxiliary functions for the default implementations of `Ord` methods -/
def core.cmp.Ord.max_body {Self : Type} (lt : Self → Self → Result Bool)
  (x y : Self) : Result Self := do
  if ← lt y x then ok x else ok y

def core.cmp.Ord.min_body {Self : Type} (lt : Self → Self → Result Bool)
  (x y : Self) : Result Self := do
  if ← lt y x then ok y else ok x

def core.cmp.Ord.clamp_body {Self : Type} (le lt gt : Self → Self → Result Bool)
  (self min max : Self) : Result Self := do
  massert (← le min max)
  if ← lt self min then ok min
  else if ← gt self max then ok max
  else ok self

@[rust_trait "core::cmp::Ord" (parentClauses := ["eqInst", "partialOrdInst"])
  (defaultMethods := ["max", "min", "clamp"])]
structure core.cmp.Ord (Self : Type) where
  eqInst : core.cmp.Eq Self
  partialOrdInst : core.cmp.PartialOrd Self Self
  cmp : Self → Self → Result Ordering
  max : Self → Self → Result Self :=
    core.cmp.Ord.max_body partialOrdInst.lt
  min : Self → Self → Result Self :=
    core.cmp.Ord.min_body partialOrdInst.lt
  clamp : Self → Self → Self → Result Self :=
    core.cmp.Ord.clamp_body partialOrdInst.le partialOrdInst.lt partialOrdInst.gt

/- Default method -/
def core.cmp.Ord.max.default {Self : Type} (lt : Self → Self → Result Bool)
  (x y : Self) : Result Self :=
  core.cmp.Ord.max_body lt x y

/- Default method -/
def core.cmp.Ord.min.default {Self : Type} (lt : Self → Self → Result Bool)
  (x y : Self) : Result Self :=
  core.cmp.Ord.min_body lt x y

/- Default method -/
def core.cmp.Ord.clamp.default {Self : Type} (le lt gt : Self → Self → Result Bool)
  (self min max : Self) : Result Self :=
  core.cmp.Ord.clamp_body le lt gt self min max

@[simp, rust_fun "core::cmp::min"]
def core.cmp.min {T : Type} (OrdInst : core.cmp.Ord T) (x y : T) : Result T :=
  -- TODO: is this the correct model?
  OrdInst.min x y

@[simp, rust_fun "core::cmp::max"]
def core.cmp.max {T : Type} (OrdInst : core.cmp.Ord T) (x y : T) : Result T :=
  -- TODO: is this the correct model?
  OrdInst.max x y

@[simp, rust_fun "core::cmp::impls::{core::cmp::PartialEq<(), ()>}::eq"]
def core.cmp.impls.PartialEqUnit.eq (_ _ : Unit) : Result Bool := ok true

@[simp, rust_fun "core::cmp::impls::{core::cmp::PartialEq<(), ()>}::ne"]
def core.cmp.impls.PartialEqUnit.ne (_ _ : Unit) : Result Bool := ok false

@[reducible, rust_trait_impl "core::cmp::PartialEq<(), ()>"]
def core.cmp.PartialEqUnit : core.cmp.PartialEq Unit Unit := {
  eq := core.cmp.impls.PartialEqUnit.eq
  ne := core.cmp.impls.PartialEqUnit.ne
}

@[simp, rust_fun "core::cmp::impls::{core::cmp::PartialOrd<(), ()>}::partial_cmp"]
def core.cmp.impls.PartialOrdUnit.partial_cmp (_ _ : Unit) : Result (Option Ordering) :=
  ok (some .eq)

@[simp, rust_fun "core::cmp::impls::{core::cmp::Ord<()>}::cmp"]
def core.cmp.impls.OrdUnit.cmp (_ _ : Unit) : Result Ordering :=
  ok .eq

@[rust_fun "core::cmp::impls::{core::cmp::PartialEq<bool, bool>}::eq"]
def core.cmp.impls.PartialEqBool.eq (b0 b1 : Bool) : Result Bool := .ok (b0 = b1)

@[reducible, rust_trait_impl "core::cmp::PartialEq<bool, bool>"]
def core.cmp.PartialEqBool : core.cmp.PartialEq Bool Bool := {
  eq := core.cmp.impls.PartialEqBool.eq
}

/-- `Eq for Option<T>` (core/src/option.rs, derived): `assert_receiver_is_total_eq` only
    exists for the derive's compile-time check that `T: Eq`; it does nothing at run time. -/
@[rust_fun "core::option::{core::cmp::Eq<core::option::Option<@T>>}::assert_receiver_is_total_eq"]
def core.option.EqOption.assert_receiver_is_total_eq {T : Type} (_ : core.cmp.Eq T)
  (_ : Option T) : Result Unit := .ok ()

/-! `char`'s comparison impls (core/src/cmp.rs `partial_eq_impl!`, `eq_impl!` and
    `ord_impl!`): the order of the Unicode scalar values. -/

/-- `impl PartialEq for char`: `*self == *other`. -/
@[rust_fun "core::cmp::impls::{core::cmp::PartialEq<char, char>}::eq" -canFail]
def core.cmp.impls.PartialEqChar.eq (x y : Char) : Bool := x == y

/-- `impl PartialEq for char`: `*self != *other`. -/
@[rust_fun "core::cmp::impls::{core::cmp::PartialEq<char, char>}::ne" -canFail]
def core.cmp.impls.PartialEqChar.ne (x y : Char) : Bool := x != y

@[reducible, rust_trait_impl "core::cmp::PartialEq<char, char>"]
def core.cmp.PartialEqChar : core.cmp.PartialEq Char Char := {
  eq := fun x y => ok (core.cmp.impls.PartialEqChar.eq x y)
  ne := fun x y => ok (core.cmp.impls.PartialEqChar.ne x y)
}

@[reducible, rust_trait_impl "core::cmp::Eq<char>"]
def core.cmp.EqChar : core.cmp.Eq Char := {
  partialEqInst := core.cmp.PartialEqChar
}

/-- `impl Ord for char`: `three_way_compare(*self, *other)`. -/
@[rust_fun "core::cmp::impls::{core::cmp::Ord<char>}::cmp" -canFail]
def core.cmp.impls.OrdChar.cmp (x y : Char) : Ordering := compare x.val y.val

/-- `impl PartialOrd for char`: `Some(three_way_compare(*self, *other))`. -/
@[rust_fun "core::cmp::impls::{core::cmp::PartialOrd<char, char>}::partial_cmp" -canFail]
def core.cmp.impls.PartialOrdChar.partial_cmp (x y : Char) : Option Ordering :=
  some (compare x.val y.val)

/-- `partial_ord_methods_primitive_impl!`: `*self < *other` on `char`. -/
@[rust_fun "core::cmp::impls::{core::cmp::PartialOrd<char, char>}::lt" -canFail]
def core.cmp.impls.PartialOrdChar.lt (x y : Char) : Bool := decide (x.val < y.val)

@[rust_fun "core::cmp::impls::{core::cmp::PartialOrd<char, char>}::le" -canFail]
def core.cmp.impls.PartialOrdChar.le (x y : Char) : Bool := decide (x.val ≤ y.val)

@[rust_fun "core::cmp::impls::{core::cmp::PartialOrd<char, char>}::gt" -canFail]
def core.cmp.impls.PartialOrdChar.gt (x y : Char) : Bool := decide (y.val < x.val)

@[rust_fun "core::cmp::impls::{core::cmp::PartialOrd<char, char>}::ge" -canFail]
def core.cmp.impls.PartialOrdChar.ge (x y : Char) : Bool := decide (y.val ≤ x.val)

/-- `impl Ord for char` (`ord_impl!`): `const_assert!(min <= max, ..)` panics when
    `min > max`, then `if self < min { min } else if self > max { max } else { self }`. -/
@[rust_fun "core::cmp::impls::{core::cmp::Ord<char>}::clamp"]
def core.cmp.impls.OrdChar.clamp (self min max : Char) : Result Char := do
  massert (core.cmp.impls.PartialOrdChar.le min max)
  if core.cmp.impls.PartialOrdChar.lt self min then ok min
  else if core.cmp.impls.PartialOrdChar.gt self max then ok max
  else ok self

@[reducible, rust_trait_impl "core::cmp::PartialOrd<char, char>"]
def core.cmp.PartialOrdChar : core.cmp.PartialOrd Char Char := {
  partialEqInst := core.cmp.PartialEqChar
  partial_cmp := fun x y => ok (core.cmp.impls.PartialOrdChar.partial_cmp x y)
  lt := fun x y => ok (core.cmp.impls.PartialOrdChar.lt x y)
  le := fun x y => ok (core.cmp.impls.PartialOrdChar.le x y)
  gt := fun x y => ok (core.cmp.impls.PartialOrdChar.gt x y)
  ge := fun x y => ok (core.cmp.impls.PartialOrdChar.ge x y)
}

/-- `max` and `min` are `Ord`'s default methods (`if other < self { self } else { other }`
    and `if other < self { other } else { self }`). -/
@[reducible, rust_trait_impl "core::cmp::Ord<char>"]
def core.cmp.OrdChar : core.cmp.Ord Char := {
  eqInst := core.cmp.EqChar
  partialOrdInst := core.cmp.PartialOrdChar
  cmp := fun x y => ok (core.cmp.impls.OrdChar.cmp x y)
  clamp := core.cmp.impls.OrdChar.clamp
}

@[simp, rust_fun "core::cmp::impls::{core::cmp::PartialEq<&'a @A, &'b @B>}::eq"]
def core.cmp.impls.PartialEqShared.eq {A : Type} {B : Type} (PartialEqInst : core.cmp.PartialEq A B)
  (x : A) (y : B) : Result Bool :=
  PartialEqInst.eq x y

@[simp, rust_fun "core::cmp::impls::{core::cmp::PartialEq<&'a @A, &'b @B>}::ne"]
def core.cmp.impls.PartialEqShared.ne {A : Type} {B : Type} (PartialEqInst : core.cmp.PartialEq A B)
  (x : A) (y : B) : Result Bool :=
  PartialEqInst.ne x y

@[reducible, rust_trait_impl "core::cmp::PartialEq<&'a @A, &'b @B>"]
def core.cmp.PartialEqShared {A : Type} {B : Type}
  (PartialEqInst : core.cmp.PartialEq A B) : core.cmp.PartialEq A B := {
  eq := core.cmp.impls.PartialEqShared.eq PartialEqInst
  ne := core.cmp.impls.PartialEqShared.ne PartialEqInst
}

@[rust_fun "alloc::boxed::{core::cmp::PartialEq<Box<@T>, Box<@T>>}::eq" (keepParams := [true, false])]
def alloc.boxed.PartialEqBox.eq
  {T : Type} (PartialEqInst : core.cmp.PartialEq T T) (x y : T) : Result Bool :=
  PartialEqInst.eq x y

@[rust_fun "alloc::boxed::{core::cmp::PartialEq<Box<@T>, Box<@T>>}::ne" (keepParams := [true, false])]
def alloc.boxed.PartialEqBox.ne
  {T : Type} (PartialEqInst : core.cmp.PartialEq T T) (x y : T) : Result Bool :=
  PartialEqInst.ne x y

@[reducible, rust_trait_impl "core::cmp::PartialEq<Box<@T>, Box<@T>>" (keepParams := [true, false])]
def core.cmp.PartialEqBox {T : Type} (PartialEqInst : core.cmp.PartialEq T T) :
  core.cmp.PartialEq T T := {
  eq := alloc.boxed.PartialEqBox.eq PartialEqInst
  ne := alloc.boxed.PartialEqBox.ne PartialEqInst
}

@[reducible, rust_trait_impl "core::cmp::Eq<Box<@T>>" (keepParams := [true, false])]
def core.cmp.EqBox {T : Type} (EqInst : core.cmp.Eq T) : core.cmp.Eq T := {
  partialEqInst := core.cmp.PartialEqBox EqInst.partialEqInst
}

/-! `Box<T>` is modeled by `T`: its comparison impls delegate to `T`'s. -/

@[rust_fun "alloc::boxed::{core::cmp::PartialOrd<Box<@T>, Box<@T>>}::partial_cmp" (keepParams := [true, false])]
def alloc.boxed.PartialOrdBox.partial_cmp
  {T : Type} (PartialOrdInst : core.cmp.PartialOrd T T) (x y : T) : Result (Option Ordering) :=
  PartialOrdInst.partial_cmp x y

@[rust_fun "alloc::boxed::{core::cmp::PartialOrd<Box<@T>, Box<@T>>}::lt" (keepParams := [true, false])]
def alloc.boxed.PartialOrdBox.lt
  {T : Type} (PartialOrdInst : core.cmp.PartialOrd T T) (x y : T) : Result Bool :=
  PartialOrdInst.lt x y

@[rust_fun "alloc::boxed::{core::cmp::PartialOrd<Box<@T>, Box<@T>>}::le" (keepParams := [true, false])]
def alloc.boxed.PartialOrdBox.le
  {T : Type} (PartialOrdInst : core.cmp.PartialOrd T T) (x y : T) : Result Bool :=
  PartialOrdInst.le x y

@[rust_fun "alloc::boxed::{core::cmp::PartialOrd<Box<@T>, Box<@T>>}::gt" (keepParams := [true, false])]
def alloc.boxed.PartialOrdBox.gt
  {T : Type} (PartialOrdInst : core.cmp.PartialOrd T T) (x y : T) : Result Bool :=
  PartialOrdInst.gt x y

@[rust_fun "alloc::boxed::{core::cmp::PartialOrd<Box<@T>, Box<@T>>}::ge" (keepParams := [true, false])]
def alloc.boxed.PartialOrdBox.ge
  {T : Type} (PartialOrdInst : core.cmp.PartialOrd T T) (x y : T) : Result Bool :=
  PartialOrdInst.ge x y

@[reducible, rust_trait_impl "core::cmp::PartialOrd<Box<@T>, Box<@T>>" (keepParams := [true, false])]
def core.cmp.PartialOrdBox {T : Type} (PartialOrdInst : core.cmp.PartialOrd T T) :
  core.cmp.PartialOrd T T := {
  partialEqInst := core.cmp.PartialEqBox PartialOrdInst.partialEqInst
  partial_cmp := alloc.boxed.PartialOrdBox.partial_cmp PartialOrdInst
  lt := alloc.boxed.PartialOrdBox.lt PartialOrdInst
  le := alloc.boxed.PartialOrdBox.le PartialOrdInst
  gt := alloc.boxed.PartialOrdBox.gt PartialOrdInst
  ge := alloc.boxed.PartialOrdBox.ge PartialOrdInst
}

@[rust_fun "alloc::boxed::{core::cmp::Ord<Box<@T>>}::cmp" (keepParams := [true, false])]
def alloc.boxed.OrdBox.cmp {T : Type} (OrdInst : core.cmp.Ord T) (x y : T) : Result Ordering :=
  OrdInst.cmp x y

@[reducible, rust_trait_impl "core::cmp::Ord<Box<@T>>" (keepParams := [true, false])]
def core.cmp.OrdBox {T : Type} (OrdInst : core.cmp.Ord T) : core.cmp.Ord T := {
  eqInst := core.cmp.EqBox OrdInst.eqInst
  partialOrdInst := core.cmp.PartialOrdBox OrdInst.partialOrdInst
  cmp := alloc.boxed.OrdBox.cmp OrdInst
}

section PartialEqOrder

open Lean.Order

-- Only the dispatched callback must be monotone. In particular, `ne` can be
-- an explicit override rather than the negation of `eq`.
@[partial_fixpoint_monotone]
theorem core.cmp.impls.PartialEqShared.eq.monotone
    {A B : Type} {γ : Sort u} [PartialOrder γ]
    (eq ne : γ → A → B → Result Bool) (x : A) (y : B)
    (hmono : monotone eq) :
    monotone (fun f => core.cmp.impls.PartialEqShared.eq
      { eq := eq f, ne := ne f } x y) := by
  exact monotone_apply y _ (monotone_apply x _ hmono)

@[partial_fixpoint_monotone]
theorem core.cmp.impls.PartialEqShared.ne.monotone
    {A B : Type} {γ : Sort u} [PartialOrder γ]
    (eq ne : γ → A → B → Result Bool) (x : A) (y : B)
    (hmono : monotone ne) :
    monotone (fun f => core.cmp.impls.PartialEqShared.ne
      { eq := eq f, ne := ne f } x y) := by
  exact monotone_apply y _ (monotone_apply x _ hmono)

@[partial_fixpoint_monotone]
theorem alloc.boxed.PartialEqBox.eq.monotone
    {T : Type} {γ : Sort u} [PartialOrder γ]
    (eq ne : γ → T → T → Result Bool) (x y : T)
    (hmono : monotone eq) :
    monotone (fun f => alloc.boxed.PartialEqBox.eq
      { eq := eq f, ne := ne f } x y) := by
  exact monotone_apply y _ (monotone_apply x _ hmono)

@[partial_fixpoint_monotone]
theorem alloc.boxed.PartialEqBox.ne.monotone
    {T : Type} {γ : Sort u} [PartialOrder γ]
    (eq ne : γ → T → T → Result Bool) (x y : T)
    (hmono : monotone ne) :
    monotone (fun f => alloc.boxed.PartialEqBox.ne
      { eq := eq f, ne := ne f } x y) := by
  exact monotone_apply y _ (monotone_apply x _ hmono)

@[partial_fixpoint_monotone]
theorem core.cmp.impls.PartialEqShared.eq.function_monotone
    {A B : Type} {γ : Sort u} [PartialOrder γ]
    (eq ne : γ → A → B → Result Bool) (hmono : Lean.Order.monotone eq) :
    Lean.Order.monotone (fun f => core.cmp.impls.PartialEqShared.eq
      { eq := eq f, ne := ne f }) :=
  hmono

@[partial_fixpoint_monotone]
theorem core.cmp.impls.PartialEqShared.ne.function_monotone
    {A B : Type} {γ : Sort u} [PartialOrder γ]
    (eq ne : γ → A → B → Result Bool) (hmono : Lean.Order.monotone ne) :
    Lean.Order.monotone (fun f => core.cmp.impls.PartialEqShared.ne
      { eq := eq f, ne := ne f }) :=
  hmono

@[partial_fixpoint_monotone]
theorem alloc.boxed.PartialEqBox.eq.function_monotone
    {T : Type} {γ : Sort u} [PartialOrder γ]
    (eq ne : γ → T → T → Result Bool) (hmono : Lean.Order.monotone eq) :
    Lean.Order.monotone (fun f => alloc.boxed.PartialEqBox.eq
      { eq := eq f, ne := ne f }) :=
  hmono

@[partial_fixpoint_monotone]
theorem alloc.boxed.PartialEqBox.ne.function_monotone
    {T : Type} {γ : Sort u} [PartialOrder γ]
    (eq ne : γ → T → T → Result Bool) (hmono : Lean.Order.monotone ne) :
    Lean.Order.monotone (fun f => alloc.boxed.PartialEqBox.ne
      { eq := eq f, ne := ne f }) :=
  hmono

end PartialEqOrder

end Aeneas.Std
