import Aeneas.Std.Core.Borrow

namespace Aeneas.Std

@[rust_trait "alloc::slice::Join"]
structure alloc.slice.Join (Self Separator Output : Type) where
  join : Self → Separator → Result Output

@[rust_fun "alloc::slice::{[@T]}::join"]
def alloc.slice.Slice.join {T Separator Output : Type}
    (joinInst : alloc.slice.Join (Slice T) Separator Output)
    (values : Slice T) (separator : Separator) : Result Output :=
  joinInst.join values separator

private def checkedJoinLength {S : Type} (borrow : core.borrow.Borrow S Str)
    (reserved : Nat) : List S → Result Nat
  | [] => .ok reserved
  | value :: rest => do
    let part ← borrow.borrow value
    let length := reserved + part.length
    if length ≤ Usize.max then checkedJoinLength borrow length rest
    else .fail .panic

private def appendJoinedStrings {S : Type} (borrow : core.borrow.Borrow S Str)
    (separator output : String) : List S → Result String
  | [] => .ok output
  | value :: rest => do
    let part ← borrow.borrow value
    let text ← Str.toString part
    appendJoinedStrings borrow separator (output ++ separator ++ text) rest

/-- Match Rust's checked reservation pass before copying any text. Borrowing is
repeated in the copy pass, so a dictionary failure is never hidden by caching. -/
@[rust_fun "alloc::str::{alloc::slice::Join<[@S], &'a str, alloc::string::String>}::join"]
def alloc.str.JoinStr.join {S : Type} (borrow : core.borrow.Borrow S Str)
    (values : Slice S) (separator : Str) : Result String := do
  match values.val with
  | [] => .ok ""
  | first :: rest =>
    let separatorLength := separator.length * rest.length
    if separatorLength ≤ Usize.max then
      let _ ← checkedJoinLength borrow separatorLength values.val
      let first ← borrow.borrow first
      let first ← Str.toString first
      match rest with
      | [] => .ok first
      | _ :: _ =>
        let separator ← Str.toString separator
        appendJoinedStrings borrow separator first rest
    else .fail .panic

@[reducible, rust_trait_impl "alloc::slice::Join<[@S], &'a str, alloc::string::String>"]
def alloc.slice.JoinStr {S : Type} (borrow : core.borrow.Borrow S Str) :
    alloc.slice.Join (Slice S) Str String := {
  join := alloc.str.JoinStr.join borrow
}

end Aeneas.Std
