import Aeneas.Std.String
import Aeneas.Std.Core.Fmt
import Aeneas.Std.Core.FmtWithSlice
import Aeneas.Std.Float
import Aeneas.Std.Core.Result
import Aeneas.Std.Scalar.Core

namespace Aeneas.Std

open Result

/-! # `str::parse` and `FromStr` (core/src/str/traits.rs, core/src/num/mod.rs, rustc 1.95)

`FromStr` for the integer types, whose `from_str` is `from_str_radix(src, 10)`, and
`i64::from_str_radix`, with `ParseIntError` and its `IntErrorKind`, and their derived `Debug`; `FromStr` for `f32` and `f64`
(`dec2flt`) with `ParseFloatError`; the `Display` of both errors. -/

/-- `core::str::traits::FromStr`, whose associated type `Err` is lifted. -/
@[rust_trait "core::str::traits::FromStr"]
structure core.str.traits.FromStr (Self : Type) (Err : Type) where
  from_str : Str → Result (core.result.Result Self Err)

/-- `str::parse` (core/src/str/mod.rs): `FromStr::from_str(self)`. -/
@[rust_fun "core::str::{str}::parse"]
def core.str.Str.parse {F Err : Type} (fromStrInst : core.str.traits.FromStr F Err) (s : Str) :
    Result (core.result.Result F Err) :=
  fromStrInst.from_str s

/-- `core::num::IntErrorKind` (core/src/num/error.rs). -/
@[rust_type "core::num::error::IntErrorKind"]
inductive core.num.error.IntErrorKind where
  | Empty | InvalidDigit | PosOverflow | NegOverflow | Zero
  deriving DecidableEq, Repr

/-- `core::num::ParseIntError { kind: IntErrorKind }` (core/src/num/error.rs). -/
@[rust_type "core::num::error::ParseIntError"]
structure core.num.error.ParseIntError where
  kind : core.num.error.IntErrorKind
  deriving DecidableEq, Repr

/-- The value of the byte `c` as a digit of `radix` (`(c as char).to_digit(radix)`,
    core/src/char/methods.rs, rustc 1.95): `0`-`9`, then `a`-`z` or `A`-`Z` as 10 to 35, when
    below `radix`. -/
def core.num.asciiDigit (radix c : Nat) : Option Nat :=
  let d := if 48 ≤ c ∧ c ≤ 57 then some (c - 48)
    else if 97 ≤ c ∧ c ≤ 122 then some (c - 87)
    else if 65 ≤ c ∧ c ≤ 90 then some (c - 55)
    else none
  d.filter (· < radix)

/-- The digits loop of `from_ascii_radix` (core/src/num/mod.rs, rustc 1.95): for each byte,
    `result * radix` (checked), then the byte's digit value (`InvalidDigit` if it has none,
    before the overflow of that step is reported), then `+ x` (`- x` for a negative number), each
    step failing with `PosOverflow` (`NegOverflow`) outside `[min, max]`. The unchecked loop used
    when no overflow is possible computes the same. -/
def core.num.fromRadixDigits (radix : Nat) (positive : Bool) (min max : Int) :
    List U8 → Int → core.result.Result Int core.num.error.ParseIntError
  | [], acc => .Ok acc
  | c :: rest, acc =>
    match core.num.asciiDigit radix c.val with
    | some d =>
      let next := if positive then acc * radix + d else acc * radix - d
      if next < min ∨ max < next then
        .Err ⟨if positive then .PosOverflow else .NegOverflow⟩
      else core.num.fromRadixDigits radix positive min max rest next
    | none => .Err ⟨.InvalidDigit⟩

/-- `from_ascii_radix(src, radix)` (core/src/num/mod.rs, rustc 1.95) for an integer type with
    range `[min, max]` and a radix in `2..=36`: `Empty` for an empty string, `InvalidDigit` for a
    lone sign, then an optional `+` (or `-` when `min < 0`) and the digits (a `-` of an unsigned
    type is an invalid digit). -/
def core.num.fromRadix (radix : Nat) (min max : Int) (src : Str) :
    core.result.Result Int core.num.error.ParseIntError :=
  match src.val with
  | [] => .Err ⟨.Empty⟩
  | [c] =>
    if c.val = 43 ∨ c.val = 45 then .Err ⟨.InvalidDigit⟩
    else core.num.fromRadixDigits radix true min max [c] 0
  | c :: rest =>
    if c.val = 43 then core.num.fromRadixDigits radix true min max rest 0
    else if c.val = 45 ∧ min < 0 then core.num.fromRadixDigits radix false min max rest 0
    else core.num.fromRadixDigits radix true min max src.val 0

def core.num.fromStrUScalar (ty : UScalarTy) (src : Str) :
    Result (core.result.Result (UScalar ty) core.num.error.ParseIntError) :=
  match core.num.fromRadix 10 0 (UScalar.max ty) src with
  | .Ok n => do .ok (.Ok (← UScalar.tryMk ty n.toNat))
  | .Err e => .ok (.Err e)

def core.num.fromStrIScalar (ty : IScalarTy) (src : Str) :
    Result (core.result.Result (IScalar ty) core.num.error.ParseIntError) :=
  match core.num.fromRadix 10 (IScalar.min ty) (IScalar.max ty) src with
  | .Ok n => do .ok (.Ok (← IScalar.tryMk ty n))
  | .Err e => .ok (.Err e)

/-- `FromStr for usize` (core/src/num/mod.rs `from_str_int_impl!`): `from_str_radix(src, 10)`. -/
@[rust_fun "core::num::{core::str::traits::FromStr<usize, core::num::error::ParseIntError>}::from_str"]
def core.num.FromStrUsize.from_str (src : Str) :
    Result (core.result.Result Usize core.num.error.ParseIntError) :=
  core.num.fromStrUScalar .Usize src

@[reducible, rust_trait_impl "core::str::traits::FromStr<usize, core::num::error::ParseIntError>"]
def core.str.traits.FromStrUsize : core.str.traits.FromStr Usize core.num.error.ParseIntError := {
  from_str := core.num.FromStrUsize.from_str
}

/-- `FromStr for u64` (core/src/num/mod.rs `from_str_int_impl!`): `from_str_radix(src, 10)`. -/
@[rust_fun "core::num::{core::str::traits::FromStr<u64, core::num::error::ParseIntError>}::from_str"]
def core.num.FromStrU64.from_str (src : Str) :
    Result (core.result.Result U64 core.num.error.ParseIntError) :=
  core.num.fromStrUScalar .U64 src

@[reducible, rust_trait_impl "core::str::traits::FromStr<u64, core::num::error::ParseIntError>"]
def core.str.traits.FromStrU64 : core.str.traits.FromStr U64 core.num.error.ParseIntError := {
  from_str := core.num.FromStrU64.from_str
}

/-- `FromStr for i32` (core/src/num/mod.rs `from_str_int_impl!`): `from_str_radix(src, 10)`. -/
@[rust_fun "core::num::{core::str::traits::FromStr<i32, core::num::error::ParseIntError>}::from_str"]
def core.num.FromStrI32.from_str (src : Str) :
    Result (core.result.Result I32 core.num.error.ParseIntError) :=
  core.num.fromStrIScalar .I32 src

@[reducible, rust_trait_impl "core::str::traits::FromStr<i32, core::num::error::ParseIntError>"]
def core.str.traits.FromStrI32 : core.str.traits.FromStr I32 core.num.error.ParseIntError := {
  from_str := core.num.FromStrI32.from_str
}

/-- `FromStr for i64` (core/src/num/mod.rs `from_str_int_impl!`): `from_str_radix(src, 10)`. -/
@[rust_fun "core::num::{core::str::traits::FromStr<i64, core::num::error::ParseIntError>}::from_str"]
def core.num.FromStrI64.from_str (src : Str) :
    Result (core.result.Result I64 core.num.error.ParseIntError) :=
  core.num.fromStrIScalar .I64 src

@[reducible, rust_trait_impl "core::str::traits::FromStr<i64, core::num::error::ParseIntError>"]
def core.str.traits.FromStrI64 : core.str.traits.FromStr I64 core.num.error.ParseIntError := {
  from_str := core.num.FromStrI64.from_str
}

/-- `i64::from_str_radix(src, radix)` (core/src/num/mod.rs `from_str_int_impl!`):
    `from_ascii_radix(src.as_bytes(), radix)`, which panics for a radix outside `2..=36`. -/
@[rust_fun "core::num::{i64}::from_str_radix"]
def core.num.I64.from_str_radix (src : Str) (radix : U32) :
    Result (core.result.Result I64 core.num.error.ParseIntError) :=
  if radix.val < 2 ∨ 36 < radix.val then .fail .panic
  else
    match core.num.fromRadix radix.val (IScalar.min .I64) (IScalar.max .I64) src with
    | .Ok n => do .ok (.Ok (← IScalar.tryMk .I64 n))
    | .Err e => .ok (.Err e)

/-- `ParseIntError::kind` (core/src/num/error.rs): `&self.kind`. -/
@[rust_fun "core::num::error::{core::num::error::ParseIntError}::kind"]
def core.num.error.ParseIntError.kind' (self : core.num.error.ParseIntError) :
    Result core.num.error.IntErrorKind :=
  .ok self.kind

/-- `Debug for IntErrorKind` (derived): the variant's name, through `Formatter::write_str`. -/
@[rust_fun "core::num::error::{core::fmt::Debug<core::num::error::IntErrorKind>}::fmt"]
def core.num.error.DebugIntErrorKind.fmt (kind : core.num.error.IntErrorKind)
    (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.append (match kind with
    | .Empty => "Empty" | .InvalidDigit => "InvalidDigit" | .PosOverflow => "PosOverflow"
    | .NegOverflow => "NegOverflow" | .Zero => "Zero")

@[reducible, rust_trait_impl "core::fmt::Debug<core::num::error::IntErrorKind>"]
def core.fmt.DebugIntErrorKind : core.fmt.Debug core.num.error.IntErrorKind :=
  ⟨core.num.error.DebugIntErrorKind.fmt⟩

/-- `Debug for ParseIntError` (derived): `f.debug_struct_field1_finish("ParseIntError", "kind",
    &&self.kind)`. -/
@[rust_fun "core::num::error::{core::fmt::Debug<core::num::error::ParseIntError>}::fmt"]
def core.num.error.DebugParseIntError.fmt (e : core.num.error.ParseIntError)
    (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.debugStruct "ParseIntError" [("kind", ⟨_, core.fmt.DebugIntErrorKind, e.kind⟩)]

@[reducible, rust_trait_impl "core::fmt::Debug<core::num::error::ParseIntError>"]
def core.fmt.DebugParseIntError : core.fmt.Debug core.num.error.ParseIntError :=
  ⟨core.num.error.DebugParseIntError.fmt⟩

/-! ### `FromStr` for `f32` and `f64` (core/src/num/dec2flt, rustc 1.95) -/

/-- `FloatErrorKind` (core/src/num/dec2flt/mod.rs). -/
@[rust_type "core::num::dec2flt::FloatErrorKind"]
inductive core.num.dec2flt.FloatErrorKind where
  | Empty | Invalid
  deriving DecidableEq, Repr

/-- `ParseFloatError { kind: FloatErrorKind }` (core/src/num/dec2flt/mod.rs). -/
@[rust_type "core::num::dec2flt::ParseFloatError"]
structure core.num.dec2flt.ParseFloatError where
  kind : core.num.dec2flt.FloatErrorKind
  deriving DecidableEq, Repr

def core.num.dec2flt.isDigit (c : U8) : Bool := 48 ≤ c.val && c.val ≤ 57

/-- The leading decimal digits: their value from `acc` on, their count, and the rest. -/
def core.num.dec2flt.digits : List U8 → Nat → Nat → Nat × Nat × List U8
  | c :: rest, acc, n =>
    if core.num.dec2flt.isDigit c then core.num.dec2flt.digits rest (acc * 10 + (c.val - 48)) (n + 1)
    else (acc, n, c :: rest)
  | [], acc, n => (acc, n, [])

/-- The exponent digits of `parse_scientific` (core/src/num/dec2flt/parse.rs): each digit is
    accumulated only while the exponent is below `0x10000` (the same saturation as the slow
    path's `parse_decimal_seq`). -/
def core.num.dec2flt.exponentDigits : List U8 → Nat → Nat × List U8
  | c :: rest, acc =>
    if core.num.dec2flt.isDigit c then
      core.num.dec2flt.exponentDigits rest (if acc < 0x10000 then acc * 10 + (c.val - 48) else acc)
    else (acc, c :: rest)
  | [], acc => (acc, [])

/-- `parse_number` (core/src/num/dec2flt/parse.rs) on the bytes after the sign: `digits [.
    digits] [(e|E) [+|-] digits]`, with at least one mantissa digit, consuming everything: the
    decimal `mantissa × 10^exponent` it denotes. -/
def core.num.dec2flt.parseNumber (s : List U8) : Option (Nat × Int) :=
  let (intValue, intCount, rest) := core.num.dec2flt.digits s 0 0
  let (mantissa, fracCount, rest) :=
    match rest with
    | c :: r => if c.val = 46 then core.num.dec2flt.digits r intValue 0 else (intValue, 0, rest)
    | [] => (intValue, 0, [])
  if intCount + fracCount = 0 then none
  else
    match rest with
    | [] => some (mantissa, -(fracCount : Int))
    | c :: r =>
      if c.val = 101 ∨ c.val = 69 then
        let (negative, r) :=
          match r with
          | d :: r' => if d.val = 45 then (true, r') else if d.val = 43 then (false, r') else (false, r)
          | [] => (false, [])
        match r with
        | d :: _ =>
          if core.num.dec2flt.isDigit d then
            let (e, r) := core.num.dec2flt.exponentDigits r 0
            if r.isEmpty then some (mantissa, (if negative then -(e : Int) else e) - fracCount)
            else none
          else none
        | [] => none
      else none

/-- `parse_inf_nan` (core/src/num/dec2flt/parse.rs): exactly `inf`, `infinity` or `nan`, ASCII
    case-insensitively (`register & 0xDFDF..` upper-cases exactly the letters). -/
def core.num.dec2flt.infNan (s : List U8) : Option Bool :=
  let upper := s.map fun (c : U8) => if 97 ≤ c.val ∧ c.val ≤ 122 then c.val - 32 else c.val
  if upper = [73, 78, 70] ∨ upper = [73, 78, 70, 73, 78, 73, 84, 89] then some true
  else if upper = [78, 65, 78] then some false
  else none

/-- `dec2flt` (core/src/num/dec2flt/mod.rs): `Empty` for an empty string; an optional sign;
    `Invalid` if nothing follows it or it is neither a decimal literal nor `inf`/`infinity`/
    `nan`; else the decimal rounded to nearest, ties to even (the fast path, Eisel-Lemire and
    the slow `parse_long_mantissa` path all compute this correctly rounded value), negated for
    a `-`. `inf` and `nan` are `F::INFINITY` and `F::NAN` (the positive quiet NaN), negated
    for a `-`. A decimal above `10^400` is infinite and one below `10^-400` is zero in every
    format, so `round` is only applied between those bounds. -/
def core.num.dec2flt.parseFloat (f : BinaryFormat) (src : Str) :
    core.result.Result (BinaryFloat f) core.num.dec2flt.ParseFloatError :=
  match src.val with
  | [] => .Err ⟨.Empty⟩
  | c :: rest =>
    let negative := c.val = 45
    let s := if c.val = 45 ∨ c.val = 43 then rest else c :: rest
    if s.isEmpty then .Err ⟨.Invalid⟩
    else
      match core.num.dec2flt.parseNumber s with
      | some (mantissa, exponent) =>
        if mantissa = 0 then .Ok (BinaryFloat.zero f negative)
        else
          let k : Int := (Nat.toDigits 10 mantissa).length
          if exponent + k - 1 > 400 then .Ok (BinaryFloat.infinity f negative)
          else if exponent + k < -400 then .Ok (BinaryFloat.zero f negative)
          else
            .Ok (BinaryFloat.round f negative (mantissa * 10 ^ exponent.toNat)
              (10 ^ (-exponent).toNat))
      | none =>
        match core.num.dec2flt.infNan s with
        | some true => .Ok (BinaryFloat.infinity f negative)
        | some false => .Ok (BinaryFloat.nan f negative)
        | none => .Err ⟨.Invalid⟩

/-- `FromStr for f64` (core/src/num/dec2flt/mod.rs): `dec2flt(src)`. -/
@[rust_fun "core::num::dec2flt::{core::str::traits::FromStr<f64, core::num::dec2flt::ParseFloatError>}::from_str"]
def core.num.dec2flt.FromStrF64.from_str (src : Str) :
    Result (core.result.Result F64 core.num.dec2flt.ParseFloatError) :=
  .ok (core.num.dec2flt.parseFloat .binary64 src)

@[reducible, rust_trait_impl "core::str::traits::FromStr<f64, core::num::dec2flt::ParseFloatError>"]
def core.str.traits.FromStrF64 : core.str.traits.FromStr F64 core.num.dec2flt.ParseFloatError := {
  from_str := core.num.dec2flt.FromStrF64.from_str
}

/-- `FromStr for f32` (core/src/num/dec2flt/mod.rs): `dec2flt(src)`. -/
@[rust_fun "core::num::dec2flt::{core::str::traits::FromStr<f32, core::num::dec2flt::ParseFloatError>}::from_str"]
def core.num.dec2flt.FromStrF32.from_str (src : Str) :
    Result (core.result.Result F32 core.num.dec2flt.ParseFloatError) :=
  .ok (core.num.dec2flt.parseFloat .binary32 src)

@[reducible, rust_trait_impl "core::str::traits::FromStr<f32, core::num::dec2flt::ParseFloatError>"]
def core.str.traits.FromStrF32 : core.str.traits.FromStr F32 core.num.dec2flt.ParseFloatError := {
  from_str := core.num.dec2flt.FromStrF32.from_str
}

/-- `Display for ParseFloatError` (core/src/num/dec2flt/mod.rs): the description through
    `<str as Display>::fmt` (padding and precision apply). -/
@[rust_fun "core::num::dec2flt::{core::fmt::Display<core::num::dec2flt::ParseFloatError>}::fmt"]
def core.num.dec2flt.DisplayParseFloatError.fmt (e : core.num.dec2flt.ParseFloatError)
    (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  core.fmt.displayString (match e.kind with
    | .Empty => "cannot parse float from empty string"
    | .Invalid => "invalid float literal") fmt

@[reducible, rust_trait_impl "core::fmt::Display<core::num::dec2flt::ParseFloatError>"]
def core.fmt.DisplayParseFloatError : core.fmt.Display core.num.dec2flt.ParseFloatError :=
  ⟨core.num.dec2flt.DisplayParseFloatError.fmt⟩

/-- `Debug for FloatErrorKind` (derived). -/
def core.num.dec2flt.DebugFloatErrorKind.fmt (kind : core.num.dec2flt.FloatErrorKind)
    (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.append (match kind with | .Empty => "Empty" | .Invalid => "Invalid")

/-- `Debug for ParseFloatError` (derived): `f.debug_struct_field1_finish("ParseFloatError",
    "kind", &&self.kind)`. -/
@[rust_fun "core::num::dec2flt::{core::fmt::Debug<core::num::dec2flt::ParseFloatError>}::fmt"]
def core.num.dec2flt.DebugParseFloatError.fmt (e : core.num.dec2flt.ParseFloatError)
    (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.debugStruct "ParseFloatError" [("kind", ⟨_, ⟨core.num.dec2flt.DebugFloatErrorKind.fmt⟩, e.kind⟩)]

@[reducible, rust_trait_impl "core::fmt::Debug<core::num::dec2flt::ParseFloatError>"]
def core.fmt.DebugParseFloatError : core.fmt.Debug core.num.dec2flt.ParseFloatError :=
  ⟨core.num.dec2flt.DebugParseFloatError.fmt⟩

/-- `Display for ParseIntError` (core/src/num/error.rs): the description through
    `<str as Display>::fmt`. -/
@[rust_fun "core::num::error::{core::fmt::Display<core::num::error::ParseIntError>}::fmt"]
def core.num.error.DisplayParseIntError.fmt (e : core.num.error.ParseIntError)
    (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  core.fmt.displayString (match e.kind with
    | .Empty => "cannot parse integer from empty string"
    | .InvalidDigit => "invalid digit found in string"
    | .PosOverflow => "number too large to fit in target type"
    | .NegOverflow => "number too small to fit in target type"
    | .Zero => "number would be zero for non-zero type") fmt

@[reducible, rust_trait_impl "core::fmt::Display<core::num::error::ParseIntError>"]
def core.fmt.DisplayParseIntError : core.fmt.Display core.num.error.ParseIntError :=
  ⟨core.num.error.DisplayParseIntError.fmt⟩

end Aeneas.Std
