import Aeneas.Std.IteratorSources

namespace Aeneas.Std

open Result

/-! `core::ops::range::{Bound, RangeBounds}` (core/src/ops/range.rs, rustc 1.95).
The bounds are `Bound<&T>`: shared borrows are values in the translation. -/

@[rust_type "core::ops::range::Bound"]
inductive core.ops.range.Bound (T : Type) where
  | Included : T → core.ops.range.Bound T
  | Excluded : T → core.ops.range.Bound T
  | Unbounded : core.ops.range.Bound T

/-- The provided `contains` has its own generics and is not a dictionary field. -/
@[rust_trait "core::ops::range::RangeBounds"]
structure core.ops.range.RangeBounds (Self : Type) (T : Type) where
  start_bound : Self → Result (core.ops.range.Bound T)
  end_bound : Self → Result (core.ops.range.Bound T)

/-- `RangeFull` is a unit struct: its translation is `Unit`. -/
@[rust_fun "core::ops::range::{core::ops::range::RangeBounds<core::ops::range::RangeFull, @T>}::start_bound"]
def core.ops.range.RangeBoundsRangeFull.start_bound (T : Type) (_ : Unit) :
    Result (core.ops.range.Bound T) :=
  ok .Unbounded

@[rust_fun "core::ops::range::{core::ops::range::RangeBounds<core::ops::range::RangeFull, @T>}::end_bound"]
def core.ops.range.RangeBoundsRangeFull.end_bound (T : Type) (_ : Unit) :
    Result (core.ops.range.Bound T) :=
  ok .Unbounded

@[reducible, rust_trait_impl "core::ops::range::RangeBounds<core::ops::range::RangeFull, @T>"]
def core.ops.range.RangeBoundsRangeFull (T : Type) : core.ops.range.RangeBounds Unit T := {
  start_bound := core.ops.range.RangeBoundsRangeFull.start_bound T
  end_bound := core.ops.range.RangeBoundsRangeFull.end_bound T
}

@[rust_fun "core::ops::range::{core::ops::range::RangeBounds<core::ops::range::RangeFrom<@T>, @T>}::start_bound"]
def core.ops.range.RangeBoundsRangeFrom.start_bound {T : Type} (self : core.ops.range.RangeFrom T) :
    Result (core.ops.range.Bound T) :=
  ok (.Included self.start)

@[rust_fun "core::ops::range::{core::ops::range::RangeBounds<core::ops::range::RangeFrom<@T>, @T>}::end_bound"]
def core.ops.range.RangeBoundsRangeFrom.end_bound {T : Type} (_ : core.ops.range.RangeFrom T) :
    Result (core.ops.range.Bound T) :=
  ok .Unbounded

@[reducible, rust_trait_impl "core::ops::range::RangeBounds<core::ops::range::RangeFrom<@T>, @T>"]
def core.ops.range.RangeBoundsRangeFrom (T : Type) :
    core.ops.range.RangeBounds (core.ops.range.RangeFrom T) T := {
  start_bound := core.ops.range.RangeBoundsRangeFrom.start_bound
  end_bound := core.ops.range.RangeBoundsRangeFrom.end_bound
}

@[rust_fun "core::ops::range::{core::ops::range::RangeBounds<core::ops::range::RangeTo<@T>, @T>}::start_bound"]
def core.ops.range.RangeBoundsRangeTo.start_bound {T : Type} (_ : core.ops.range.RangeTo T) :
    Result (core.ops.range.Bound T) :=
  ok .Unbounded

@[rust_fun "core::ops::range::{core::ops::range::RangeBounds<core::ops::range::RangeTo<@T>, @T>}::end_bound"]
def core.ops.range.RangeBoundsRangeTo.end_bound {T : Type} (self : core.ops.range.RangeTo T) :
    Result (core.ops.range.Bound T) :=
  ok (.Excluded self.end)

@[reducible, rust_trait_impl "core::ops::range::RangeBounds<core::ops::range::RangeTo<@T>, @T>"]
def core.ops.range.RangeBoundsRangeTo (T : Type) :
    core.ops.range.RangeBounds (core.ops.range.RangeTo T) T := {
  start_bound := core.ops.range.RangeBoundsRangeTo.start_bound
  end_bound := core.ops.range.RangeBoundsRangeTo.end_bound
}

@[rust_fun "core::ops::range::{core::ops::range::RangeBounds<core::ops::range::Range<@T>, @T>}::start_bound"]
def core.ops.range.RangeBoundsRange.start_bound {T : Type} (self : core.ops.range.Range T) :
    Result (core.ops.range.Bound T) :=
  ok (.Included self.start)

@[rust_fun "core::ops::range::{core::ops::range::RangeBounds<core::ops::range::Range<@T>, @T>}::end_bound"]
def core.ops.range.RangeBoundsRange.end_bound {T : Type} (self : core.ops.range.Range T) :
    Result (core.ops.range.Bound T) :=
  ok (.Excluded self.end)

@[reducible, rust_trait_impl "core::ops::range::RangeBounds<core::ops::range::Range<@T>, @T>"]
def core.ops.range.RangeBoundsRange (T : Type) :
    core.ops.range.RangeBounds (core.ops.range.Range T) T := {
  start_bound := core.ops.range.RangeBoundsRange.start_bound
  end_bound := core.ops.range.RangeBoundsRange.end_bound
}

@[rust_fun "core::ops::range::{core::ops::range::RangeBounds<core::ops::range::RangeInclusive<@T>, @T>}::start_bound"]
def core.ops.range.RangeBoundsRangeInclusive.start_bound {T : Type}
    (self : core.ops.range.RangeInclusive T) : Result (core.ops.range.Bound T) :=
  ok (.Included self.start)

/-- An exhausted range is empty: its end is excluded. -/
@[rust_fun "core::ops::range::{core::ops::range::RangeBounds<core::ops::range::RangeInclusive<@T>, @T>}::end_bound"]
def core.ops.range.RangeBoundsRangeInclusive.end_bound {T : Type}
    (self : core.ops.range.RangeInclusive T) : Result (core.ops.range.Bound T) :=
  ok (if self.exhausted then .Excluded self.end else .Included self.end)

@[reducible, rust_trait_impl "core::ops::range::RangeBounds<core::ops::range::RangeInclusive<@T>, @T>"]
def core.ops.range.RangeBoundsRangeInclusive (T : Type) :
    core.ops.range.RangeBounds (core.ops.range.RangeInclusive T) T := {
  start_bound := core.ops.range.RangeBoundsRangeInclusive.start_bound
  end_bound := core.ops.range.RangeBoundsRangeInclusive.end_bound
}

/-- `core::slice::index::range(range, ..len)` (core/src/slice/index.rs, rustc 1.95):
`into_slice_range(len, (range.start_bound().copied(), range.end_bound().copied()))`,
the start bound read first. The end is resolved before the start; an end past `len`
or a start past the end panics (`slice_index_fail`). -/
def core.slice.index.rangeOf {R : Type} (bounds : core.ops.range.RangeBounds R Usize)
    (range : R) (len : Nat) : Result (Nat × Nat) := do
  let startBound ← bounds.start_bound range
  let endBound ← bounds.end_bound range
  let end_ ← match endBound with
    | .Included e => if e.val ≥ len then fail .panic else ok (e.val + 1)
    | .Excluded e => if e.val > len then fail .panic else ok e.val
    | .Unbounded => ok len
  let start ← match startBound with
    | .Excluded s => if s.val ≥ end_ then fail .panic else ok (s.val + 1)
    | .Included s => if s.val > end_ then fail .panic else ok s.val
    | .Unbounded => ok 0
  ok (start, end_)

/-- The resolved range lies within the slice. -/
theorem core.slice.index.rangeOf_le {R : Type} {bounds : core.ops.range.RangeBounds R Usize}
    {range : R} {len start end_ : Nat}
    (h : core.slice.index.rangeOf bounds range len = ok (start, end_)) :
    start ≤ end_ ∧ end_ ≤ len := by
  unfold core.slice.index.rangeOf at h
  cases hs : bounds.start_bound range <;> simp only [hs, bind_tc_ok, bind_tc_fail, bind_tc_div] at h <;>
    try contradiction
  cases he : bounds.end_bound range <;> simp only [he, bind_tc_ok, bind_tc_fail, bind_tc_div] at h <;>
    try contradiction
  rename_i sb eb
  cases eb <;> cases sb <;> simp only at h <;> (repeat' split at h) <;> simp_all <;> omega

end Aeneas.Std
