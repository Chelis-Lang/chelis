import Aeneas.Std.Vec
import Aeneas.Std.Core.Borrow

/-!
# `Borrow<[T]> for Vec<T>` and `ToOwned for [T]` (alloc/src/slice.rs, rustc 1.95)
-/

namespace Aeneas.Std

/-- `impl<T, A: Allocator> Borrow<[T]> for Vec<T, A>` (alloc/src/slice.rs): `&self[..]`. -/
@[rust_fun "alloc::slice::{core::borrow::Borrow<alloc::vec::Vec<@T>, [@T]>}::borrow"
  (keepParams := [true, false])]
def alloc.slice.BorrowVecSlice.borrow {T : Type} (v : alloc.vec.Vec T) : Result (Slice T) :=
  .ok ⟨v.val, v.property⟩

@[reducible, rust_trait_impl "core::borrow::Borrow<alloc::vec::Vec<@T>, [@T]>"
  (keepParams := [true, false])]
def core.borrow.BorrowVecSlice (T : Type) : core.borrow.Borrow (alloc.vec.Vec T) (Slice T) := {
  borrow := alloc.slice.BorrowVecSlice.borrow
}

/-- `impl<T: Clone> ToOwned for [T] { type Owned = Vec<T>; }` (alloc/src/slice.rs, rustc 1.95):
    `to_owned` is `self.to_vec()`, each element cloned in order. -/
@[rust_fun "alloc::slice::{alloc::borrow::ToOwned<[@T], alloc::vec::Vec<@T>>}::to_owned"]
def alloc.slice.ToOwnedSlice.to_owned {T : Type} (cloneInst : core.clone.Clone T) (s : Slice T) :
    Result (alloc.vec.Vec T) :=
  alloc.slice.Slice.to_vec cloneInst s

/-- `clone_into` is `SpecCloneIntoVec::clone_into(self, target)`: `target.truncate(self.len())`,
    then `target.clone_from_slice(init)` (`clone_from` on each kept element, in order) and
    `target.extend_from_slice(tail)` (clones of the rest, in order), for `(init, tail) =
    self.split_at(target.len())`. The `T: Copy` specialization clears the target and copies the
    elements instead, the same for the types whose `clone` is a copy. -/
@[rust_fun "alloc::slice::{alloc::borrow::ToOwned<[@T], alloc::vec::Vec<@T>>}::clone_into"]
def alloc.slice.ToOwnedSlice.clone_into {T : Type} (cloneInst : core.clone.Clone T) (s : Slice T)
    (target : alloc.vec.Vec T) : Result (alloc.vec.Vec T) := do
  let kept := target.val.take s.val.length
  let init ← (kept.zip (s.val.take kept.length)).mapM fun (a, b) => cloneInst.clone_from a b
  let tail ← (s.val.drop kept.length).mapM cloneInst.clone
  let out := init ++ tail
  if h : out.length ≤ Usize.max then .ok ⟨out, h⟩ else .fail .panic

@[reducible, rust_trait_impl "alloc::borrow::ToOwned<[@T], alloc::vec::Vec<@T>>"]
def alloc.borrow.ToOwnedSlice {T : Type} (cloneInst : core.clone.Clone T) :
    alloc.borrow.ToOwned (Slice T) (alloc.vec.Vec T) := {
  coreborrowBorrowInst := core.borrow.BorrowVecSlice T
  to_owned := alloc.slice.ToOwnedSlice.to_owned cloneInst
  clone_into := alloc.slice.ToOwnedSlice.clone_into cloneInst
}

end Aeneas.Std
