/- Vectors -/
import Lean
import Lean.Meta.Tactic.Simp
import Init.Data.List.Basic
import Aeneas.Std.Scalar
import Aeneas.Std.Slice
import Aeneas.Std.Core.Default
import Aeneas.Std.Core.Iter
import Aeneas.Tactic.Solver.ScalarTac
import Aeneas.Tactic.Step.Init

namespace Aeneas

namespace Std

open Result Error WP

namespace alloc.vec

@[rust_type "alloc::vec::Vec"]
def Vec (α : Type u) := { l : List α // l.length ≤ Usize.max }

/-- We need this to coerce vectors to lists without marking `Vec` as reducible.
    Also not that we *do not* want to mark `Vec` as reducible: it triggers issues.
-/
instance (α : Type u) : CoeOut (Vec α) (List α) where
  coe := λ v => v.val

instance [BEq α] : BEq (Vec α) := SubtypeBEq _

instance [BEq α] [LawfulBEq α] : LawfulBEq (Vec α) := SubtypeLawfulBEq _

theorem Vec.len_ineq {α : Type u} (v : Vec α) : v.val.length ≤ Usize.max := by
  cases v; simp[*]

@[simp, scalar_tac_simps, simp_scalar_safe, simp_lists_safe, grind, agrind]
abbrev Vec.length {α : Type u} (v : Vec α) : Nat := v.val.length

@[simp, scalar_tac_simps, simp_scalar_safe, simp_lists_safe, grind, agrind]
abbrev Vec.v {α : Type u} (v : Vec α) : List α := v.val

example {a: Type u} (v : Vec a) : v.length ≤ Usize.max := by
  scalar_tac

@[rust_fun "alloc::vec::{alloc::vec::Vec<@T>}::new" -canFail -lift]
abbrev Vec.new (α : Type u): Vec α := ⟨ [], by simp ⟩

@[rust_fun "alloc::vec::{alloc::vec::Vec<@T>}::is_empty"
  -canFail -lift (keepParams := [true, false])]
def Vec.is_empty {T : Type} (self : Vec T) : Bool := self.val.isEmpty

@[rust_fun "alloc::vec::{alloc::vec::Vec<@T>}::clear"
  -canFail (keepParams := [true, false])]
def Vec.clear {T : Type} (_self : Vec T) : Vec T := Vec.new T

@[rust_fun "alloc::vec::{alloc::vec::Vec<@T>}::remove"
  (keepParams := [true, false])]
def Vec.remove {T : Type} (self : Vec T) (index : Usize) : Result (T × Vec T) :=
  match self.val[index.val]? with
  | none => fail .arrayOutOfBounds
  | some item =>
    ok (item, ⟨self.val.take index.val ++ self.val.drop (index.val + 1), by
      have := self.property
      simp only [List.length_append, List.length_take, List.length_drop]
      omega⟩)

@[rust_fun "alloc::vec::{core::default::Default<alloc::vec::Vec<@T>>}::default"]
def DefaultVec.default (T : Type) : Result (Vec T) := ok (Vec.new T)

@[reducible, rust_trait_impl "core::default::Default<alloc::vec::Vec<@T>>"]
def DefaultVec (T : Type) : core.default.Default (Vec T) := {
  default := DefaultVec.default T
}

/-- Accumulate in reverse so extension traverses storage linearly. The terminal
`next` state is retained, including effects from the call that returns `None`. -/
def ExtendVec.extendLoop {T I : Type}
    (iterInst : core.iter.traits.iterator.Iterator I T)
    (reversed : Vec T) (iter : I) : Result (Vec T × I) := do
  let (item, iter) ← iterInst.next iter
  match item with
  | none => return (⟨reversed.val.reverse, by simpa using reversed.property⟩, iter)
  | some item =>
    if h : reversed.val.length + 1 ≤ Usize.max then
      ExtendVec.extendLoop iterInst ⟨item :: reversed.val, by simpa using h⟩ iter
    else fail .maximumSizeExceeded
partial_fixpoint

@[rust_fun
  "alloc::vec::{core::iter::traits::collect::Extend<alloc::vec::Vec<@T>, @T>}::extend"
  (keepParams := [true, false, true, true])]
def ExtendVec.extend {T I IntoIter : Type}
    (intoInst : core.iter.traits.collect.IntoIterator I T IntoIter)
    (self : Vec T) (input : I) : Result (Unit × Vec T × I) := do
  let (iter, recover) ← intoInst.into_iter input
  let (self, iter) ← ExtendVec.extendLoop intoInst.iteratorInst
    ⟨self.val.reverse, by simpa using self.property⟩ iter
  return ((), self, recover iter)

@[reducible, rust_trait_impl
  "core::iter::traits::collect::Extend<alloc::vec::Vec<@T>, @T>"
  (keepParams := [true, false])]
def ExtendVec (T : Type) : core.iter.traits.collect.Extend (Vec T) T := {
  extend := ExtendVec.extend
}

/-- `impl<'a, T: Copy> Extend<&'a T> for Vec<T>` (alloc/src/vec/mod.rs): `self.spec_extend(iter.into_iter())`,
    pushing a copy of each borrowed element in order: `ExtendVec.extend` on the copies (the
    `Copy` dictionary is not called). -/
@[rust_fun
  "alloc::vec::{core::iter::traits::collect::Extend<alloc::vec::Vec<@T>, &'a @T>}::extend"
  (keepParams := [true, false, true, true]) (keepTraitClauses := [false, true])]
def ExtendVecShared.extend {T I IntoIter : Type}
    (intoInst : core.iter.traits.collect.IntoIterator I T IntoIter)
    (self : Vec T) (input : I) : Result (Unit × Vec T × I) :=
  ExtendVec.extend intoInst self input

@[reducible, rust_trait_impl
  "core::iter::traits::collect::Extend<alloc::vec::Vec<@T>, &'a @T>"
  (keepParams := [true, false]) (keepTraitClauses := [false])]
def ExtendVecShared (T : Type) : core.iter.traits.collect.Extend (Vec T) T := {
  extend := ExtendVecShared.extend
}

instance (α : Type u) : Inhabited (Vec α) := by
  constructor
  apply Vec.new

@[simp, rust_fun "alloc::vec::{alloc::vec::Vec<@T>}::len" -canFail -lift (keepParams := [true,false])]
abbrev Vec.len {α : Type u} (v : Vec α) : Usize :=
  Usize.ofNatCore v.val.length (by scalar_tac)

@[simp, scalar_tac_simps]
theorem Vec.len_val {α : Type u} (v : Vec α) : (Vec.len v).val = v.length :=
  by simp

grind_pattern Vec.len_val => v.length
grind_pattern [agrind] Vec.len_val => v.length

@[reducible] instance {α : Type u} : GetElem (Vec α) Nat α (fun a i => i < a.val.length) where
  getElem a i h := getElem a.val i h

@[reducible] instance {α : Type u} : GetElem? (Vec α) Nat α (fun a i => i < a.val.length) where
  getElem? a i := getElem? a.val i
  getElem! a i := getElem! a.val i

@[simp, scalar_tac_simps, simp_lists_hyps_simps, grind =, agrind =]
theorem Vec.getElem?_Nat_eq {α : Type u} (v : Vec α) (i : Nat) : v[i]? = v.val[i]? := by rfl

@[simp, scalar_tac_simps, simp_lists_hyps_simps, grind =, agrind =]
theorem Vec.getElem!_Nat_eq {α : Type u} [Inhabited α] (v : Vec α) (i : Nat) : v[i]! = v.val[i]! := by rfl

@[reducible] instance {α : Type u} : GetElem (Vec α) Usize α (fun a i => i < a.val.length) where
  getElem a i h := getElem a.val i.val h

@[reducible] instance {α : Type u} : GetElem? (Vec α) Usize α (fun a i => i < a.val.length) where
  getElem? a i := getElem? a.val i.val
  getElem! a i := getElem! a.val i.val

@[simp, scalar_tac_simps, simp_lists_hyps_simps, grind =, agrind =] theorem Vec.getElem?_Usize_eq {α : Type u} (v : Vec α) (i : Usize) : v[i]? = v.val[i.val]? := by rfl
@[simp, scalar_tac_simps, simp_lists_hyps_simps, grind =, agrind =] theorem Vec.getElem!_Usize_eq {α : Type u} [Inhabited α] (v : Vec α) (i : Usize) : v[i]! = v.val[i.val]! := by rfl

@[simp, scalar_tac_simps, simp_lists_hyps_simps, grind, agrind] abbrev Vec.get? {α : Type u} (v : Vec α) (i : Nat) : Option α := getElem? v i
@[simp, scalar_tac_simps, simp_lists_hyps_simps, grind, agrind] abbrev Vec.get! {α : Type u} [Inhabited α] (v : Vec α) (i : Nat) : α := getElem! v i

def Vec.set {α : Type u} (v: Vec α) (i: Usize) (x: α) : Vec α :=
  ⟨ v.val.set i.val x, by have := v.property; simp [*] ⟩

def Vec.set_opt {α : Type u} (v: Vec α) (i: Usize) (x: Option α) : Vec α :=
  ⟨ v.val.set_opt i.val x, by have := v.property; simp [*] ⟩

@[simp, scalar_tac_simps, simp_lists_hyps_simps, grind =, agrind =]
theorem Vec.set_val_eq {α : Type u} (v: Vec α) (i: Usize) (x: α) :
  (v.set i x) = v.val.set i.val x := by
  simp [set]

@[simp, scalar_tac_simps, simp_lists_hyps_simps, grind =, agrind =]
theorem Vec.set_opt_val_eq {α : Type u} (v: Vec α) (i: Usize) (x: Option α) :
  (v.set_opt i x) = v.val.set_opt i.val x := by
  simp [set_opt]

@[irreducible, rust_fun "alloc::vec::{alloc::vec::Vec<@T>}::push" (keepParams := [true,false])]
def Vec.push {α : Type u} (v : Vec α) (x : α) : Result (Vec α)
  :=
  let nlen := List.length v.val + 1
  if h : nlen ≤ U32.max || nlen ≤ Usize.max then
    ok ⟨ List.concat v.val x, by simp; scalar_tac ⟩
  else
    fail maximumSizeExceeded

@[step]
theorem Vec.push_spec {α : Type u} (v : Vec α) (x : α) (h : v.val.length < Usize.max) :
  v.push x ⦃ v1 =>
  v1.val = v.val ++ [x] ⦄ := by
  unfold push; grind

/-- `Vec::pop`: removes and returns the last element, `None` on an empty vector. -/
@[rust_fun "alloc::vec::{alloc::vec::Vec<@T>}::pop" (keepParams := [true, false])]
def Vec.pop {T : Type} (v : Vec T) : Result (Option T × Vec T) :=
  match v.val.getLast? with
  | none => ok (none, v)
  | some x => ok (some x, ⟨v.val.dropLast, by have := v.property; simp only [List.length_dropLast]; omega⟩)

/-- `Vec::split_off` (vec/mod.rs): panics when `at > len`; otherwise the elements from
    `at` on move to the returned vector, and `self` keeps the first `at`. -/
@[rust_fun "alloc::vec::{alloc::vec::Vec<@T>}::split_off"
  (keepParams := [true, false]) (keepTraitClauses := [false])]
def Vec.split_off {T : Type} (v : Vec T) (at_ : Usize) : Result (Vec T × Vec T) :=
  if at_.val ≤ v.length then
    ok (⟨v.val.drop at_.val, by have := v.property; simp only [List.length_drop]; omega⟩,
      ⟨v.val.take at_.val, by have := v.property; simp only [List.length_take]; omega⟩)
  else fail .panic

/-- `Vec::into_boxed_slice` (vec/mod.rs): shrink the buffer and reinterpret it;
    the elements are unchanged. -/
@[rust_fun "alloc::vec::{alloc::vec::Vec<@T>}::into_boxed_slice" (keepParams := [true, false])]
def Vec.into_boxed_slice {T : Type} (v : Vec T) : Result (Slice T) := ok v

/-- The retained suffix of `Vec::dedup_by` after the kept element `prev`: each
    `current` is dropped iff `same_bucket(current, prev)`, else it is kept and
    becomes `prev`. -/
def Vec.dedupAfter {T : Type} (same : T → T → Result Bool) (prev : T) :
    List T → Result (List T)
  | [] => ok []
  | current :: rest => do
    if ← same current prev then Vec.dedupAfter same prev rest
    else do
      let kept ← Vec.dedupAfter same current rest
      ok (current :: kept)

theorem Vec.dedupAfter_length {T : Type} (same : T → T → Result Bool) (prev : T)
    (l l' : List T) (h : Vec.dedupAfter same prev l = ok l') : l'.length ≤ l.length := by
  induction l generalizing prev l' with
  | nil => simp [Vec.dedupAfter] at h; simp [← h]
  | cons current rest ih =>
    simp only [Vec.dedupAfter] at h
    cases hs : same current prev with
    | ok b =>
      simp only [hs, bind_tc_ok] at h
      cases b with
      | true => have := ih prev l' h; simp; omega
      | false =>
        simp only [Bool.false_eq_true, ↓reduceIte] at h
        cases hr : Vec.dedupAfter same current rest with
        | ok r =>
          simp only [hr, bind_tc_ok, ok.injEq] at h
          have := ih current r hr; simp [← h]; omega
        | fail e => simp [hr] at h
        | div => simp [hr] at h
    | fail e => simp [hs] at h
    | div => simp [hs] at h

/-- `Vec::dedup` (vec/mod.rs): `self.dedup_by(|a, b| a == b)`, which calls
    `same_bucket(current, previous_kept)` left to right and keeps the first
    element of every run. A panicking comparison propagates. -/
@[rust_fun "alloc::vec::{alloc::vec::Vec<@T>}::dedup" (keepParams := [true, false])]
def Vec.dedup {T : Type} (eqInst : core.cmp.PartialEq T T) (v : Vec T) : Result (Vec T) :=
  match h : v.val with
  | [] => ok v
  | first :: rest =>
    match hr : Vec.dedupAfter eqInst.eq first rest with
    | ok kept => ok ⟨first :: kept, by
        have := Vec.dedupAfter_length _ _ _ _ hr
        have := v.property; rw [h] at this; simp at this ⊢; omega⟩
    | fail e => fail e
    | div => div

/-- The elements `Vec::dedup_by_key` keeps from the kept element `prev` on, and the final
    key-closure state: `dedup_by(|a, b| key(a) == key(b))` calls `same_bucket(current, prev)`,
    so `key` is called on `current`, then on `prev` (both may be changed by it, and `prev` is
    kept with its changes); `current` is dropped iff the keys are equal, else it is kept and
    becomes `prev`. -/
def Vec.dedupByKeyFrom {T F K : Type} (call : F → T → Result (K × F × T))
    (eq : K → K → Result Bool) (prev : T) :
    (xs : List T) → F → Result ({ys : List T // ys.length ≤ xs.length + 1} × F)
  | [], f => ok (⟨[prev], by simp⟩, f)
  | current :: rest, f => do
    let (ka, f, current) ← call f current
    let (kb, f, prev) ← call f prev
    if ← eq ka kb then do
      let (kept, f) ← Vec.dedupByKeyFrom call eq prev rest f
      ok (⟨kept.val, by have := kept.property; simp; omega⟩, f)
    else do
      let (kept, f) ← Vec.dedupByKeyFrom call eq current rest f
      ok (⟨prev :: kept.val, by have := kept.property; simp; omega⟩, f)

/-- `Vec::dedup_by_key` (alloc/src/vec/mod.rs, rustc 1.95) given the call of its key closure:
    `self.dedup_by(|a, b| key(a) == key(b))`; `dedup_by` returns at once when `len <= 1` (no
    call), else calls `same_bucket(current, prev_kept)` left to right (see `dedupByKeyFrom`);
    the key closure's final state is returned. A partial-monomorphization instance at a closure
    capturing mutable borrows is this model applied to the `PartialEq` dictionary of the key and
    to the closure's call recovered from its region-indexed `call_mut`, which gives back the
    element (`ModelStateABI.closure_state_fun_body`). -/
def Vec.dedup_by_key_with {T F K : Type} (eqInst : core.cmp.PartialEq K K)
    (call : F → T → Result (K × F × T)) (v : alloc.vec.Vec T) (f : F) :
    Result (Unit × alloc.vec.Vec T × F) :=
  match h : v.val with
  | [] => ok ((), v, f)
  | first :: rest => do
    let (ys, f) ← Vec.dedupByKeyFrom call eqInst.eq first rest f
    ok ((), ⟨ys.val, by
      have := ys.property; have := v.property; rw [h] at this; simp at this; omega⟩, f)

/-- `Vec::dedup_by_key` (alloc/src/vec/mod.rs): see `dedup_by_key_with`. The key closure is
    called only through `call_mut`. -/
@[rust_fun "alloc::vec::{alloc::vec::Vec<@T>}::dedup_by_key" (keepParams := [true, false, true, true])]
def Vec.dedup_by_key {T F K : Type} (fnInst : core.ops.function.FnMutMutArg F T K)
    (eqInst : core.cmp.PartialEq K K) (v : alloc.vec.Vec T) (f : F) :
    Result (Unit × alloc.vec.Vec T × F) :=
  Vec.dedup_by_key_with eqInst
    (fun f x => do
      let (k, x, f) ← fnInst.call_mut f x
      ok (k, f, x))
    v f

@[rust_fun "alloc::vec::{alloc::vec::Vec<@T>}::insert" (keepParams := [true, false])]
def Vec.insert {α : Type u} (v: Vec α) (i: Usize) (x: α) : Result (Vec α) :=
  if i.val < v.length then
    ok ⟨ v.val.set i x, by have := v.property; simp [*] ⟩
  else
    fail arrayOutOfBounds

@[step]
theorem Vec.insert_spec {α : Type u} (v: Vec α) (i: Usize) (x: α)
  (hbound : i.val < v.length) :
  v.insert i x ⦃ nv => nv.val = v.val.set i x ⦄ := by
  simp [insert, *]

def Vec.index_usize {α : Type u} (v: Vec α) (i: Usize) : Result α :=
  match v[i.val]? with
  | none => fail .arrayOutOfBounds
  | some x => ok x

@[step]
theorem Vec.index_usize_spec {α : Type u} [Inhabited α] (v: Vec α) (i: Usize)
  (hbound : i.val < v.length) :
  v.index_usize i ⦃ x => x = v.val[i.val]! ⦄ := by
  simp only [index_usize]
  simp at *
  simp [*]

def Vec.update {α : Type u} (v: Vec α) (i: Usize) (x: α) : Result (Vec α) :=
  match v.val[i.val]? with
  | none => fail .arrayOutOfBounds
  | some _ =>
    ok ⟨ v.val.set i x, by have := v.property; simp [*] ⟩

@[step]
theorem Vec.update_spec {α : Type u} (v: Vec α) (i: Usize) (x : α)
  (hbound : i.val < v.length) :
  v.update i x ⦃ nv => nv = v.set i x ⦄ := by
  simp only [update, set]
  simp at *
  split <;> simp_all

@[scalar_tac_simps, grind =, agrind =]
theorem Vec.set_length {α : Type u} (v: Vec α) (i: Usize) (x: α) :
  (v.set i x).length = v.length := by simp

def Vec.index_mut_usize {α : Type u} (v: Vec α) (i: Usize) :
  Result (α × (α → Vec α)) :=
  match Vec.index_usize v i with
  | ok x =>
    ok (x, Vec.set v i)
  | fail e => fail e
  | div => div

@[step]
theorem Vec.index_mut_usize_spec {α : Type u} [Inhabited α] (v: Vec α) (i: Usize)
  (hbound : i.val < v.length) :
  v.index_mut_usize i ⦃ x y => x = v.val[i.val]! ∧ y = v.set i ⦄ := by
  simp only [index_mut_usize]
  have ⟨ x, h ⟩ := spec_imp_exists (index_usize_spec v i hbound)
  simp [h]

@[rust_fun "alloc::vec::{core::ops::index::Index<alloc::vec::Vec<@T>, @I, @O>}::index"
  (keepParams := [true,true,false, true])]
def Vec.index {T I Output : Type} (inst : core.slice.index.SliceIndex I (Slice T) Output)
  (self : Vec T) (i : I) : Result Output :=
  inst.index i self

@[rust_fun "alloc::vec::{core::ops::index::IndexMut<alloc::vec::Vec<@T>, @I, @O>}::index_mut"
  (keepParams := [true,true,false, true])]
def Vec.index_mut {T I Output : Type} (inst : core.slice.index.SliceIndex I (Slice T) Output)
  (self : Vec T) (i : I) :
  Result (Output × (Output → Vec T)) :=
  inst.index_mut i self

@[reducible,
  rust_trait_impl "core::ops::index::Index<alloc::vec::Vec<@T>, @T, @O>" (keepParams := [true, true, false, true])]
def Vec.Index {T I Output : Type}
  (inst : core.slice.index.SliceIndex I (Slice T) Output) :
  core.ops.index.Index (alloc.vec.Vec T) I Output := {
  index := Vec.index inst
}

@[reducible,
  rust_trait_impl "core::ops::index::IndexMut<alloc::vec::Vec<@T>, @T, @O>" (keepParams := [true, true, false, true])]
def Vec.IndexMut {T I Output : Type}
  (inst : core.slice.index.SliceIndex I (Slice T) Output) :
  core.ops.index.IndexMut (alloc.vec.Vec T) I Output := {
  indexInst := Vec.Index inst
  index_mut := Vec.index_mut inst
}

@[simp, step_simps]
theorem Vec.index_slice_index {α : Type} (v : Vec α) (i : Usize) :
  Vec.index (core.slice.index.SliceIndexUsizeSlice α) v i =
  Vec.index_usize v i := by
  simp [Vec.index, Vec.index_usize, Slice.index_usize]
  rfl

@[simp, step_simps]
theorem Vec.index_mut_slice_index {α : Type} (v : Vec α) (i : Usize) :
  Vec.index_mut (core.slice.index.SliceIndexUsizeSlice α) v i =
  index_mut_usize v i := by
  simp [Vec.index_mut, Vec.index_mut_usize, Slice.index_mut_usize]
  rfl

-- Vec index/index_mut with RangeTo

@[step]
theorem Vec.index_RangeTo_spec {α : Type} (v : Vec α) (r : core.ops.range.RangeTo Usize)
    (h : r.end ≤ v.length) :
    Vec.index (core.slice.index.SliceIndexRangeToUsizeSlice α) v r
    ⦃ s1 =>
      s1.val = v.val.slice 0 r.end ∧
      s1.length = r.end ⦄ := by
  simp only [Vec.index]
  have := core.slice.index.SliceIndexRangeToUsizeSlice.index.step_spec r v h
  exact this

@[step]
theorem Vec.index_mut_RangeTo_spec {α : Type} (v : Vec α) (r : core.ops.range.RangeTo Usize)
    (h : r.end ≤ v.length) :
    Vec.index_mut (core.slice.index.SliceIndexRangeToUsizeSlice α) v r
    ⦃ (s1, back) =>
      s1.val = v.val.slice 0 r.end ∧
      s1.length = r.«end» ∧
      ∀ s', (back s').val = v.val.setSlice! 0 s'.val ⦄ := by
  simp only [Vec.index_mut]
  have := core.slice.index.SliceIndexRangeToUsizeSlice.index_mut.step_spec r v h
  exact this

-- Vec index/index_mut with RangeFrom

@[step]
theorem Vec.index_RangeFrom_spec {α : Type} (v : Vec α) (r : core.ops.range.RangeFrom Usize)
    (h : r.start ≤ v.length) :
    Vec.index (core.slice.index.SliceIndexRangeFromUsizeSlice α) v r
    ⦃ s1 =>
      s1.val = v.val.drop r.start ∧
      s1.length = v.length - r.start.val ⦄ := by
  simp only [Vec.index]
  have := core.slice.index.SliceIndexRangeFromUsizeSlice.index.step_spec r v h
  exact this

@[step]
theorem Vec.index_mut_RangeFrom_spec {α : Type} (v : Vec α) (r : core.ops.range.RangeFrom Usize)
    (h : r.start ≤ v.length) :
    Vec.index_mut (core.slice.index.SliceIndexRangeFromUsizeSlice α) v r
    ⦃ (s1, back) =>
      s1.val = v.val.drop r.start ∧
      s1.length = v.length - r.start.val ∧
      ∀ s', (back s').val = v.val.setSlice! r.start.val s'.val ⦄ := by
  simp only [Vec.index_mut]
  have := core.slice.index.SliceIndexRangeFromUsizeSlice.index_mut.step_spec r v h
  exact this

-- Vec index/index_mut with Range

@[step]
theorem Vec.index_Range_spec {α : Type} (v : Vec α) (r : core.ops.range.Range Usize)
    (h0 : r.start ≤ r.end) (h1 : r.end ≤ v.length) :
    Vec.index (core.slice.index.SliceIndexRangeUsizeSlice α) v r
    ⦃ s1 =>
      s1.val = v.val.slice r.start r.end ∧
      s1.length = r.end - r.start ⦄ := by
  simp only [Vec.index]
  have := core.slice.index.SliceIndexRangeUsizeSlice.index.step_spec r v h0 h1
  exact this

@[step]
theorem Vec.index_mut_Range_spec {α : Type} (v : Vec α) (r : core.ops.range.Range Usize)
    (h0 : r.start ≤ r.end) (h1 : r.end ≤ v.length) :
    Vec.index_mut (core.slice.index.SliceIndexRangeUsizeSlice α) v r
    ⦃ (s1, back) =>
      s1.val = v.val.slice r.start r.end ∧
      s1.length = r.end - r.start ∧
      ∀ s2, back s2 = Slice.setSlice! v r.start.val s2 ⦄ := by
  simp only [Vec.index_mut]
  have := core.slice.index.SliceIndexRangeUsizeSlice.index_mut.step_spec r v h0 h1
  exact this

end alloc.vec

@[rust_fun "alloc::slice::{[@T]}::to_vec"]
def alloc.slice.Slice.to_vec
  {T : Type} (cloneInst : core.clone.Clone T) (s : Slice T) : Result (alloc.vec.Vec T) := do
  Slice.clone cloneInst.clone s

@[step]
theorem alloc.slice.Slice.to_vec_spec {T : Type} (cloneInst : core.clone.Clone T) (s : Slice T)
  (h : ∀ x ∈ s.val, cloneInst.clone x = ok x) :
  alloc.slice.Slice.to_vec cloneInst s ⦃ s' => s = s'⦄ := by
  simp only [to_vec]
  exact (Slice.clone_spec h)

@[rust_fun "alloc::slice::{[@T]}::into_vec" -canFail -lift (keepParams := [true, false])]
def alloc.slice.Slice.into_vec
  {T : Type} (s: Slice T) : (alloc.vec.Vec T) := s

@[rust_fun "alloc::vec::from_elem"]
def alloc.vec.from_elem
  {T : Type} (cloneInst : core.clone.Clone T)
  (x : T) (n : Usize) : Result (alloc.vec.Vec T) := do
  let l ← List.clone cloneInst.clone (List.replicate n.val x)
  ok ⟨ l.val, by have := l.property; scalar_tac ⟩

@[step]
theorem alloc.vec.from_elem_spec {T : Type} (cloneInst : core.clone.Clone T)
  (x : T) (n : Usize) (h : cloneInst.clone x = ok x) :
  alloc.vec.from_elem cloneInst x n ⦃ v =>
  v.val = List.replicate n.val x ∧
  v.length = n.val ⦄ := by
  unfold from_elem
  have ⟨ l, h ⟩ := spec_imp_exists (@List.clone_spec _ cloneInst.clone (List.replicate n.val x) (by intros; simp_all))
  simp [h]

@[rust_fun "alloc::vec::{alloc::vec::Vec<@T>}::with_capacity" -canFail -lift]
def alloc.vec.Vec.with_capacity (T : Type) (_ : Usize) : alloc.vec.Vec T := Vec.new T

@[rust_fun "alloc::vec::{alloc::vec::Vec<@T>}::extend_from_slice" (keepParams := [true, false])]
def alloc.vec.Vec.extend_from_slice {T : Type} (cloneInst : core.clone.Clone T)
  (v : alloc.vec.Vec T) (s : Slice T) : Result (alloc.vec.Vec T) :=
  if h : v.length + s.length ≤ Usize.max then do
    match h' : Slice.clone cloneInst.clone s with
    | ok s' =>
      ok ⟨ v.val ++ s'.val , by have := Slice.clone_length h'; scalar_tac ⟩
    | fail e => fail e
    | div => div
  else fail .panic

/-- `Vec::append` (alloc/src/vec/mod.rs): moves all the elements of `other` to the end of
    `self`, leaving `other` empty. It panics when the new capacity overflows, as the other
    growing operations of this model do past `Usize.max` elements. -/
@[rust_fun "alloc::vec::{alloc::vec::Vec<@T>}::append" (keepParams := [true, false])]
def alloc.vec.Vec.append {T : Type} (v other : alloc.vec.Vec T) :
  Result (alloc.vec.Vec T × alloc.vec.Vec T) :=
  if h : v.length + other.length ≤ Usize.max then
    ok (⟨ v.val ++ other.val, by scalar_tac ⟩, ⟨ [], by simp ⟩)
  else fail .panic

/-- The elements kept by `Vec::retain_mut` and the final closure state: `call` is
    called once on every element, in order, with the element, and the (possibly
    updated) elements for which it returns `true` are kept, in order. The
    closure state is threaded through the calls and returned. -/
def alloc.vec.Vec.retainMutList {T F : Type} (call : F → T → Result (Bool × F × T)) :
    (xs : List T) → F → Result ({ys : List T // ys.length ≤ xs.length} × F)
  | [], f => ok (⟨[], by simp⟩, f)
  | x :: xs, f => do
    let (keep, f, x) ← call f x
    let (rest, f) ← alloc.vec.Vec.retainMutList call xs f
    if keep then ok (⟨x :: rest.val, by have := rest.property; simp; omega⟩, f)
    else ok (⟨rest.val, by have := rest.property; simp; omega⟩, f)

/-- `Vec::retain_mut` (alloc/src/vec/mod.rs) given the call of its closure: the
    output, the vector and the final closure state. A partial-monomorphization
    instance at a closure capturing mutable borrows is this model applied to the
    closure's call recovered from its region-indexed `call_mut`, the final state
    giving back the captured borrows (`ModelStateABI.closure_state_fun_body`). -/
def alloc.vec.Vec.retain_mut_with {T F : Type} (call : F → T → Result (Bool × F × T))
    (v : alloc.vec.Vec T) (f : F) : Result (Unit × alloc.vec.Vec T × F) := do
  let (ys, f) ← alloc.vec.Vec.retainMutList call v.val f
  ok ((), ⟨ys.val, Nat.le_trans ys.property v.property⟩, f)

/-- `Vec::retain_mut` (alloc/src/vec/mod.rs): see `retain_mut_with`. Only
    `call_mut` is called. -/
@[rust_fun "alloc::vec::{alloc::vec::Vec<@T>}::retain_mut" (keepParams := [true, false, true])]
def alloc.vec.Vec.retain_mut {T F : Type} (fnInst : core.ops.function.FnMutMutArg F T Bool)
    (v : alloc.vec.Vec T) (f : F) : Result (Unit × alloc.vec.Vec T × F) :=
  alloc.vec.Vec.retain_mut_with
    (fun f x => do
      let (keep, x, f) ← fnInst.call_mut f x
      ok (keep, f, x))
    v f

/-- `Vec::retain` (alloc/src/vec/mod.rs) given the call of its closure: `self.retain_mut(|elem|
    f(elem))`, the closure called once on every element, in order, which it cannot change; the
    elements for which it returns `true` are kept, in order, and its final state is returned. A
    partial-monomorphization instance at a closure capturing mutable borrows is this model applied
    to the closure's call recovered from its region-indexed `call_mut`, whose argument is a shared
    borrow (`ModelStateABI.closure_state_fun_body`). -/
def alloc.vec.Vec.retain_with {T F : Type} (call : F → T → Result (Bool × F))
    (v : alloc.vec.Vec T) (f : F) : Result (Unit × alloc.vec.Vec T × F) :=
  alloc.vec.Vec.retain_mut_with
    (fun f x => do
      let (keep, f) ← call f x
      ok (keep, f, x))
    v f

/-- `Vec::retain` (alloc/src/vec/mod.rs): see `retain_with`. Only `call_mut` is called. -/
@[rust_fun "alloc::vec::{alloc::vec::Vec<@T>}::retain" (keepParams := [true, false, true])]
def alloc.vec.Vec.retain {T F : Type} (fnInst : core.ops.function.FnMut F T Bool)
    (v : alloc.vec.Vec T) (f : F) : Result (Unit × alloc.vec.Vec T × F) :=
  alloc.vec.Vec.retain_with fnInst.call_mut v f

@[rust_fun "alloc::vec::{core::ops::deref::Deref<alloc::vec::Vec<@T>, [@T]>}::deref"
           -canFail -lift (keepParams := [true, false])]
def alloc.vec.Vec.deref {T : Type} (v : alloc.vec.Vec T) : Slice T :=
  ⟨ v.val, v.property ⟩

@[rust_fun "alloc::vec::{alloc::vec::Vec<@T>}::as_slice" (keepParams := [true, false])]
def alloc.vec.Vec.as_slice {T : Type} (v : alloc.vec.Vec T) : Result (Slice T) :=
  ok (alloc.vec.Vec.deref v)

@[reducible, rust_trait_impl "core::ops::deref::Deref<alloc::vec::Vec<@T>, [@T]>" (keepParams := [true, false])]
def core.ops.deref.DerefVec (T : Type) : core.ops.deref.Deref (alloc.vec.Vec T) (Slice T) := {
  deref := fun v => ok (alloc.vec.Vec.deref v)
}

@[rust_fun "alloc::vec::{core::ops::deref::DerefMut<alloc::vec::Vec<@T>, [@T]>}::deref_mut"
           -canFail (keepParams := [true, false])]
def alloc.vec.Vec.deref_mut {T : Type} (v :  alloc.vec.Vec T) :
   (Slice T) × (Slice T → alloc.vec.Vec T) :=
   (⟨ v.val, v.property ⟩, λ s => ⟨ s.val, s.property ⟩)

@[reducible, rust_trait_impl "core::ops::deref::DerefMut<alloc::vec::Vec<@T>, [@T]>" (keepParams := [true, false])]
def core.ops.deref.DerefMutVec (T : Type) :
  core.ops.deref.DerefMut (alloc.vec.Vec T) (Slice T):= {
  derefInst := core.ops.deref.DerefVec T
  deref_mut v := ok (alloc.vec.Vec.deref_mut v)
}

/-- `Vec::as_mut_slice` (alloc/src/vec/mod.rs): `slice::from_raw_parts_mut(self.as_mut_ptr(),
    self.len)`, the whole vector as a mutable slice, as `deref_mut`: the vector given back holds
    the slice given back (a mutable slice keeps its length). -/
@[rust_fun "alloc::vec::{alloc::vec::Vec<@T>}::as_mut_slice" (keepParams := [true, false])]
def alloc.vec.Vec.as_mut_slice {T : Type} (v : alloc.vec.Vec T) :
    Result (Slice T × (Slice T → alloc.vec.Vec T)) :=
  ok (alloc.vec.Vec.deref_mut v)

@[rust_fun "alloc::vec::{alloc::vec::Vec<@T>}::resize" (keepParams := [true,false])]
def alloc.vec.Vec.resize {T : Type} (cloneInst : core.clone.Clone T)
  (v : alloc.vec.Vec T) (new_len : Usize) (value : T) : Result (alloc.vec.Vec T) := do
  if new_len.val < v.length then
    ok ⟨ v.val.resize new_len value, by scalar_tac ⟩
  else
    let value ← cloneInst.clone value
    ok ⟨ v.val.resize new_len value, by scalar_tac ⟩

@[step]
theorem alloc.vec.Vec.resize_spec {T} (cloneInst : core.clone.Clone T)
  (v : alloc.vec.Vec T) (new_len : Usize) (value : T)
  (hClone : cloneInst.clone value = ok value) :
  alloc.vec.Vec.resize cloneInst v new_len value ⦃ nv =>
    nv.val = v.val.resize new_len value ⦄ := by
  rw [resize]
  split
  . simp
  . simp [*]

@[simp, scalar_tac_simps, grind =, agrind =]
theorem alloc.vec.Vec.set_getElem!_eq α [Inhabited α] (x : alloc.vec.Vec α) (i : Usize) :
  x.set i x[i]! = x := by
  simp only [getElem!_Usize_eq]
  simp only [Vec, set_val_eq, Subtype.ext_iff, List.set_getElem!]

@[rust_fun
  "alloc::vec::{core::convert::From<alloc::vec::Vec<@T>, [@T; @N]>}::from"]
def alloc.vec.FromVecArray.from
  {T : Type} {N : Std.Usize} (a: Array T N) : Result (alloc.vec.Vec T) :=
  ok ⟨ a.val, by scalar_tac ⟩

@[reducible, rust_trait_impl
  "core::convert::From<alloc::vec::Vec<@T>, [@T; @N]>"]
def core.convert.FromVecArray (T : Type) (N : Std.Usize) : core.convert.From
  (alloc.vec.Vec T) (Array T N) := {
  from_ := alloc.vec.FromVecArray.from
}

/-- `impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N]` (alloc/src/vec/mod.rs,
    rustc 1.95): `Err(vec)` (the vector unchanged) when `vec.len() != N`, else `Ok` of the
    elements as an array. -/
@[rust_fun
  "alloc::vec::{core::convert::TryFrom<[@T; @N], alloc::vec::Vec<@T>, alloc::vec::Vec<@T>>}::try_from"
  (keepParams := [true, false])]
def alloc.vec.TryFromArrayVec.try_from {T : Type} (N : Std.Usize) (vec : alloc.vec.Vec T) :
    Result (core.result.Result (Array T N) (alloc.vec.Vec T)) :=
  if h : vec.val.length = N.val then ok (.Ok ⟨vec.val, h⟩) else ok (.Err vec)

@[reducible, rust_trait_impl
  "core::convert::TryFrom<[@T; @N], alloc::vec::Vec<@T>, alloc::vec::Vec<@T>>"
  (keepParams := [true, false])]
def core.convert.TryFromArrayVec (T : Type) (N : Std.Usize) : core.convert.TryFrom
  (Array T N) (alloc.vec.Vec T) (alloc.vec.Vec T) := {
  try_from := alloc.vec.TryFromArrayVec.try_from N
}

/- Source: '/rustc/library/alloc/src/vec/mod.rs', lines 3967:4-3967:33 -/
@[rust_fun "alloc::vec::{core::convert::From<Box<[@T]>, alloc::vec::Vec<@T>>}::from" (keepParams := [true,false])]
def alloc.vec.FromBoxSliceVec.from {T : Type} (v : alloc.vec.Vec T) : Result (Slice T) := ok v

@[step]
theorem alloc.vec.FromBoxSliceVec.from_spec {T : Type} (v : alloc.vec.Vec T) :
  alloc.vec.FromBoxSliceVec.from v ⦃ s => s.length = v.length ∧ s.val = v.val⦄ := by
  simp [alloc.vec.FromBoxSliceVec.from]

@[reducible, rust_trait_impl "core::convert::From<Box<[@T]>, alloc::vec::Vec<@T>>" (keepParams := [true, false])]
def core.convert.FromBoxSliceVec (T : Type) :
  core.convert.From (Slice T) (alloc.vec.Vec T) := {
  from_ := alloc.vec.FromBoxSliceVec.from
}

def alloc.vec.Vec.setSlice! {α : Type u} (s : alloc.vec.Vec α) (i : ℕ) (s' : List α) : alloc.vec.Vec α :=
  ⟨s.val.setSlice! i s', by scalar_tac⟩

@[simp_lists_safe, grind =, agrind =]
theorem alloc.vec.Vec.setSlice!_getElem!_prefix {α} [Inhabited α]
  (s : alloc.vec.Vec α) (s' : List α) (i j : ℕ) (h : j < i) :
  (s.setSlice! i s')[j]! = s[j]! := by
  simp only [Vec.setSlice!, Vec.getElem!_Nat_eq]
  simp_lists

@[simp_lists_safe, grind =, agrind =]
theorem alloc.vec.Vec.setSlice!_getElem!_middle {α} [Inhabited α]
  (s : alloc.vec.Vec α) (s' : List α) (i j : ℕ) (h : i ≤ j ∧ j - i < s'.length ∧ j < s.length) :
  (s.setSlice! i s')[j]! = s'[j - i]! := by
  simp only [Vec.setSlice!, Vec.getElem!_Nat_eq]
  simp_lists

theorem alloc.vec.Vec.setSlice!_getElem!_suffix {α} [Inhabited α]
  (s : alloc.vec.Vec α) (s' : List α) (i j : ℕ) (h : i + s'.length ≤ j) :
  (s.setSlice! i s')[j]! = s[j]! := by
  simp only [Vec.setSlice!, Vec.getElem!_Nat_eq]
  simp_lists

@[rust_fun "alloc::vec::{core::clone::Clone<alloc::vec::Vec<@T>>}::clone"
    (keepParams := [true, false]) (keepTraitClauses := [true, false])]
def alloc.vec.CloneVec.clone {T : Type} (cloneInst : core.clone.Clone T)
  (v : alloc.vec.Vec T) : Result (alloc.vec.Vec T) :=
  Slice.clone cloneInst.clone v

@[reducible, rust_trait_impl "core::clone::Clone<alloc::vec::Vec<@T>>"
    (keepParams := [true, false]) (keepTraitClauses := [true, false])]
def core.clone.CloneallocvecVec {T : Type} (cloneInst : core.clone.Clone T) :
  core.clone.Clone (alloc.vec.Vec T) := {
  clone := alloc.vec.CloneVec.clone cloneInst
}

/-- `Clone for Box<[T], A>` (boxed.rs): `self.to_vec_in(alloc).into_boxed_slice()`,
    cloning the elements in order. -/
@[rust_fun "alloc::boxed::{core::clone::Clone<Box<[@T]>>}::clone"
    (keepParams := [true, false]) (keepTraitClauses := [true, false])]
def alloc.boxed.CloneBoxSlice.clone {T : Type} (cloneInst : core.clone.Clone T)
  (s : Slice T) : Result (Slice T) :=
  Slice.clone cloneInst.clone s

@[reducible, rust_trait_impl "core::clone::Clone<Box<[@T]>>"
    (keepParams := [true, false]) (keepTraitClauses := [true, false])]
def core.clone.CloneBoxSlice {T : Type} (cloneInst : core.clone.Clone T) :
  core.clone.Clone (Slice T) := {
  clone := alloc.boxed.CloneBoxSlice.clone cloneInst
}

@[rust_fun
  "alloc::vec::partial_eq::{core::cmp::PartialEq<alloc::vec::Vec<@T>, alloc::vec::Vec<@U>>}::eq"
  (keepParams := [true, true, false, false])]
def alloc.vec.partial_eq.PartialEqVec.eq
  {T : Type} {U : Type} (PartialEqInst : core.cmp.PartialEq T U)
  (v0 : alloc.vec.Vec T) (v1 : alloc.vec.Vec U) : Result Bool :=
  if v0.length = v1.length then
    List.allM (fun (x0, x1) => PartialEqInst.eq x0 x1) (List.zip v0.val v1.val)
  else .ok false

@[rust_fun
  "alloc::vec::partial_eq::{core::cmp::PartialEq<alloc::vec::Vec<@T>, alloc::vec::Vec<@U>>}::ne"
  (keepParams := [true, true, false, false])]
def alloc.vec.partial_eq.PartialEqVec.ne
  {T : Type} {U : Type} (PartialEqInst : core.cmp.PartialEq T U)
  (v0 : alloc.vec.Vec T) (v1 : alloc.vec.Vec U) : Result Bool :=
  if v0.length = v1.length then
    List.anyM (fun (x0, x1) => PartialEqInst.ne x0 x1) (List.zip v0.val v1.val)
  else .ok true

@[reducible,
  rust_trait_impl
    "core::cmp::PartialEq<alloc::vec::Vec<@T>, alloc::vec::Vec<@U>>"
    (keepParams := [true, true, false, false])]
def core.cmp.PartialEqVec {T : Type} {U : Type}
 (PartialEqInst : core.cmp.PartialEq T U) :
  core.cmp.PartialEq (alloc.vec.Vec T) (alloc.vec.Vec U) := {
  eq := alloc.vec.partial_eq.PartialEqVec.eq PartialEqInst
  ne := alloc.vec.partial_eq.PartialEqVec.ne PartialEqInst
}

@[rust_fun "alloc::vec::{core::fmt::Debug<alloc::vec::Vec<@T>>}::fmt"
  (keepParams := [true, false])]
def alloc.vec.DebugVec.fmt
  {T : Type} (DebugInst : core.fmt.Debug T) (values : alloc.vec.Vec T)
  (fmt : core.fmt.Formatter) :
  Result ((core.result.Result Unit core.fmt.Error) × core.fmt.Formatter) :=
  fmt.debugList DebugInst values.val

/-- `impl<T: Debug> Debug for [T]` (core/src/fmt/mod.rs):
    `f.debug_list().entries(self.iter()).finish()`, as for `Vec`. -/
@[rust_fun "core::fmt::{core::fmt::Debug<[@T]>}::fmt"]
def core.fmt.DebugSlice.fmt {T : Type} (DebugInst : core.fmt.Debug T) (values : Slice T)
  (fmt : core.fmt.Formatter) :
  Result ((core.result.Result Unit core.fmt.Error) × core.fmt.Formatter) :=
  fmt.debugList DebugInst values.val

@[reducible, rust_trait_impl "core::fmt::Debug<[@T]>"]
def core.fmt.DebugSlice {T : Type} (DebugInst : core.fmt.Debug T) :
  core.fmt.Debug (Slice T) := {
  fmt := core.fmt.DebugSlice.fmt DebugInst
}

@[reducible,
  rust_trait_impl "core::fmt::Debug<alloc::vec::Vec<@T>>" (keepParams := [true, false])]
def core.fmt.DebugVec {T : Type} (DebugInst : core.fmt.Debug
  T) : core.fmt.Debug (alloc.vec.Vec T) := {
  fmt := alloc.vec.DebugVec.fmt DebugInst
}

namespace Tests
  example
    (α : Type)
    (slots : alloc.vec.Vec (List α))
    (n : Usize)
    (_ : ∀ i < slots.length, slots.val[i]! = .nil)
    (Hlen : (↑slots.len : ℕ) + (↑n : ℕ) ≤ Usize.max)
    (_ : 0 < (↑n : ℕ))
    (slots1 : alloc.vec.Vec (List α))
    (hEq : (↑slots1 : List (List α)) = (↑slots : List (List α)) ++ [.nil])
    (n1 : Usize)
    (_ : (↑n : ℕ) = (↑n1 : ℕ) + 1)
    (_ : ∀ i < slots1.length, slots.val[i]! = .nil) :
    (↑slots1.len : ℕ) + (↑n1 : ℕ) ≤ Usize.max
    := by
    scalar_tac

  example
    (α : Type)
    (capacity : Usize)
    (dividend divisor : Usize)
    (Hfactor : 0 < (↑dividend : ℕ) ∧
    (↑dividend : ℕ) < (↑divisor : ℕ) ∧
      (↑capacity : ℕ) * (↑dividend : ℕ) ≤ Usize.max ∧
        (↑capacity : ℕ) * (↑dividend : ℕ) ≥ (↑divisor : ℕ))
    (slots : alloc.vec.Vec (List α))
    (h2 : (↑slots.len : ℕ) = (↑(alloc.vec.Vec.new (List α)).len : ℕ) + (↑capacity : ℕ)) :
    (↑(↑divisor : ℕ) : ℤ) ≤
    (↑(↑slots : List (List α)).length : ℤ) * (↑(↑dividend : ℕ) : ℤ)
    := by
    scalar_tac

  example
    (v : alloc.vec.Vec U32)
    (i : Usize)
    (x : U32)
    (i1 : Usize)
    (h : (↑i : ℕ) < v.val.length)
    (_ : x = v[i]!)
    (_ : (↑i1 : ℕ) = (↑i : ℕ) + 1) :
    (↑i : ℕ) + 1 ≤ v.val.length
    := by
    scalar_tac

  attribute [-simp] List.getElem!_eq_getElem?_getD
  example
    (α : Type)
    (slots : alloc.vec.Vec (List α))
    (Hslots : ∀ i < slots.length, slots[i]! = [])
    (slots1 : alloc.vec.Vec (List α))
    (_ : (↑slots1 : List (List α)) = (↑slots : List (List α)) ++ [[]])
    (i : ℕ)
    (hi : i < slots.length) :
    (↑slots : List (List α))[i]! = []
    := by
    simp_lists [*]

end Tests

end Std

end Aeneas
