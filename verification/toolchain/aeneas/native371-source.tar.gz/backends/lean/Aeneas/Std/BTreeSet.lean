import Aeneas.Std.BTreeMap
import Aeneas.Std.Sort

namespace Aeneas.Std

/- Like BTreeMap, this is an ordered-sequence abstraction, not the physical
B-tree. Refinement requires total, deterministic, successful Ord/PartialEq
operations and an order-preserving Borrow. Dictionary failures are propagated,
but their tree-dependent invocation schedule is not modeled. Allocator identity,
allocation failures and destructor effects follow BTreeMap's erased abstraction. -/
@[rust_type "alloc::collections::btree::set::BTreeSet"
  (keepParams := [true, false]) (body := .opaque)]
structure alloc.collections.btree.set.BTreeSet (T : Type) where
  map : alloc.collections.btree.map.BTreeMap T Unit

/-- set.rs `IntoIter { iter: map::IntoIter<T, SetValZST, A> }`, in key order. -/
@[rust_type "alloc::collections::btree::set::IntoIter"
  (keepParams := [true, false]) (body := .opaque)]
structure alloc.collections.btree.set.IntoIter (T : Type) where
  remaining : List T

/-- set.rs `Iter<'a, T> { iter: Keys<'a, T, SetValZST> }`, in key order. -/
@[rust_type "alloc::collections::btree::set::Iter" (body := .opaque)]
structure alloc.collections.btree.set.Iter (T : Type) where
  remaining : List T

namespace alloc.collections.btree.set

def BTreeSet.Ordered {T : Type} (ord : core.cmp.Ord T) (set : BTreeSet T) : Prop :=
  alloc.collections.btree.map.BTreeMap.Ordered ord set.map

@[rust_fun "alloc::collections::btree::set::{alloc::collections::btree::set::BTreeSet<@T, @A>}::contains"
  (keepParams := [true, false, true]) (keepTraitClauses := [false, true, true, true])]
def BTreeSet.contains {T Q : Type} (borrow : core.borrow.Borrow T Q)
    (keyOrd : core.cmp.Ord T) (ord : core.cmp.Ord Q) (set : BTreeSet T)
    (query : Q) : Result Bool :=
  alloc.collections.btree.map.BTreeMap.contains_key borrow keyOrd ord set.map query

/-- `BTreeSet::is_empty` (alloc/src/collections/btree/set.rs): `self.len() == 0`. -/
@[rust_fun "alloc::collections::btree::set::{alloc::collections::btree::set::BTreeSet<@T, @A>}::is_empty"
  (keepParams := [true, false]) (keepTraitClauses := [false])]
def BTreeSet.is_empty {T : Type} (set : BTreeSet T) : Result Bool :=
  .ok set.map.entries.isEmpty

/-- `BTreeSet::len` (alloc/src/collections/btree/set.rs): `self.map.len()`. -/
@[rust_fun "alloc::collections::btree::set::{alloc::collections::btree::set::BTreeSet<@T, @A>}::len"
  (keepParams := [true, false]) (keepTraitClauses := [false])]
def BTreeSet.len {T : Type} (set : BTreeSet T) : Result Usize :=
  alloc.collections.btree.map.BTreeMap.len set.map

/-- `BTreeSet::clear` (alloc/src/collections/btree/set.rs): `self.map.clear()` (its
    `A: Clone` bound is the method's second clause). -/
@[rust_fun "alloc::collections::btree::set::{alloc::collections::btree::set::BTreeSet<@T, @A>}::clear"
  (keepParams := [true, false]) (keepTraitClauses := [false, false])]
def BTreeSet.clear {T : Type} (_set : BTreeSet T) : Result (BTreeSet T) :=
  .ok ⟨⟨[]⟩⟩

/-- `impl<T: Clone, A: Allocator + Clone> Clone for BTreeSet<T, A>` (set.rs):
    `BTreeSet { map: self.map.clone() }`, each element cloned in order. -/
@[rust_fun "alloc::collections::btree::set::{core::clone::Clone<alloc::collections::btree::set::BTreeSet<@T, @A>>}::clone"
  (keepParams := [true, false]) (keepTraitClauses := [true, false])]
def CloneBTreeSet.clone {T : Type} (cloneInst : core.clone.Clone T) (set : BTreeSet T) :
    Result (BTreeSet T) := do
  let entries ← set.map.entries.mapM fun (key, _) => do .ok (← cloneInst.clone key, ())
  .ok ⟨⟨entries⟩⟩

/-- `impl<T: PartialEq, A: Allocator + Clone> PartialEq for BTreeSet<T, A>` (set.rs):
    `self.map.eq(&other.map)`: equal lengths, then the elements pairwise in order. -/
@[rust_fun "alloc::collections::btree::set::{core::cmp::PartialEq<alloc::collections::btree::set::BTreeSet<@T, @A>, alloc::collections::btree::set::BTreeSet<@T, @A>>}::eq"
  (keepParams := [true, false]) (keepTraitClauses := [true, false])]
def PartialEqBTreeSet.eq {T : Type} (eqInst : core.cmp.PartialEq T T) (left right : BTreeSet T) :
    Result Bool :=
  alloc.collections.btree.map.PartialEqBTreeMap.eq eqInst
    { eq := fun _ _ => .ok true, ne := fun _ _ => .ok false } left.map right.map

@[reducible, rust_trait_impl "core::clone::Clone<alloc::collections::btree::set::BTreeSet<@T, @A>>"
  (keepParams := [true, false]) (keepTraitClauses := [true, false])]
def CloneBTreeSet {T : Type} (cloneInst : core.clone.Clone T) : core.clone.Clone (BTreeSet T) := {
  clone := CloneBTreeSet.clone cloneInst
}

/-- `ne` is `PartialEq`'s default, `!self.eq(other)`. -/
@[rust_fun "alloc::collections::btree::set::{core::cmp::PartialEq<alloc::collections::btree::set::BTreeSet<@T, @A>, alloc::collections::btree::set::BTreeSet<@T, @A>>}::ne"
  (keepParams := [true, false]) (keepTraitClauses := [true, false])]
def PartialEqBTreeSet.ne {T : Type} (eqInst : core.cmp.PartialEq T T) (left right : BTreeSet T) :
    Result Bool := do
  .ok (not (← PartialEqBTreeSet.eq eqInst left right))

@[reducible, rust_trait_impl "core::cmp::PartialEq<alloc::collections::btree::set::BTreeSet<@T, @A>, alloc::collections::btree::set::BTreeSet<@T, @A>>"
  (keepParams := [true, false]) (keepTraitClauses := [true, false])]
def PartialEqBTreeSet {T : Type} (eqInst : core.cmp.PartialEq T T) :
    core.cmp.PartialEq (BTreeSet T) (BTreeSet T) := {
  eq := PartialEqBTreeSet.eq eqInst
  ne := PartialEqBTreeSet.ne eqInst
}

/-- `impl<T: Debug, A: Allocator + Clone> Debug for BTreeSet<T, A>` (set.rs):
    `f.debug_set().entries(self.iter()).finish()`, the elements in order. -/
@[rust_fun "alloc::collections::btree::set::{core::fmt::Debug<alloc::collections::btree::set::BTreeSet<@T, @A>>}::fmt"
  (keepParams := [true, false]) (keepTraitClauses := [true, false])]
def DebugBTreeSet.fmt {T : Type} (debugInst : core.fmt.Debug T) (set : BTreeSet T)
    (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.debugSet debugInst (set.map.entries.map Prod.fst)

@[reducible, rust_trait_impl "core::fmt::Debug<alloc::collections::btree::set::BTreeSet<@T, @A>>"
  (keepParams := [true, false]) (keepTraitClauses := [true, false])]
def DebugBTreeSet {T : Type} (debugInst : core.fmt.Debug T) : core.fmt.Debug (BTreeSet T) :=
  ⟨DebugBTreeSet.fmt debugInst⟩

/-- set.rs: `BTreeSet { map: BTreeMap::new() }`. -/
@[rust_fun "alloc::collections::btree::set::{alloc::collections::btree::set::BTreeSet<@T, alloc::alloc::Global>}::new"]
def BTreeSet.new (T : Type) : Result (BTreeSet T) := do
  .ok ⟨← alloc.collections.btree.map.BTreeMap.new T Unit⟩

/-- set.rs `impl Default for BTreeSet<T>`: `BTreeSet::new()`. -/
@[rust_fun "alloc::collections::btree::set::{core::default::Default<alloc::collections::btree::set::BTreeSet<@T, alloc::alloc::Global>>}::default"]
def DefaultBTreeSet.default (T : Type) : Result (BTreeSet T) :=
  BTreeSet.new T

@[reducible, rust_trait_impl "core::default::Default<alloc::collections::btree::set::BTreeSet<@T, alloc::alloc::Global>>"]
def DefaultBTreeSet (T : Type) : core.default.Default (BTreeSet T) := {
  default := DefaultBTreeSet.default T
}

/-- set.rs `first`: `self.map.first_key_value().map(|(k, _)| k)`, the least element (a shared
    borrow: the element is copied into the model). -/
@[rust_fun "alloc::collections::btree::set::{alloc::collections::btree::set::BTreeSet<@T, @A>}::first"
  (keepParams := [true, false]) (keepTraitClauses := [false, false])]
def BTreeSet.first {T : Type} (set : BTreeSet T) : Result (Option T) :=
  .ok (set.map.entries.head?.map Prod.fst)

/-- The elements kept by `BTreeSet::retain` in ascending order and the final closure state:
    `call` is called once per element, in order. -/
def BTreeSet.retainList {T F : Type} (call : F → T → Result (Bool × F)) :
    List (T × Unit) → F → Result (List (T × Unit) × F)
  | [], f => .ok ([], f)
  | (x, u) :: rest, f => do
    let (keep, f) ← call f x
    let (rest, f) ← BTreeSet.retainList call rest f
    .ok (if keep then (x, u) :: rest else rest, f)

/-- `BTreeSet::retain` (set.rs, rustc 1.95) given the call of its closure:
    `self.extract_if(.., |v| !f(v)).for_each(drop)`, which visits the elements in ascending
    order, calling `f` once on each and removing those for which it is `false`. A
    partial-monomorphization instance at a closure capturing mutable borrows is this model
    applied to the `Ord` dictionary and to the closure's recovered call
    (`ModelStateABI.closure_state_models`). -/
def BTreeSet.retain_with {T F : Type} (_ord : core.cmp.Ord T) (call : F → T → Result (Bool × F))
    (set : BTreeSet T) (f : F) : Result (Unit × BTreeSet T × F) := do
  let (entries, f) ← BTreeSet.retainList call set.map.entries f
  .ok ((), ⟨⟨entries⟩⟩, f)

/-- `BTreeSet::retain` (set.rs): see `retain_with`. Only `call_mut` is called. -/
@[rust_fun "alloc::collections::btree::set::{alloc::collections::btree::set::BTreeSet<@T, @A>}::retain"
  (keepParams := [true, false, true]) (keepTraitClauses := [false, true, true])]
def BTreeSet.retain {T F : Type} (ord : core.cmp.Ord T) (fnInst : core.ops.function.FnMut F T Bool)
    (set : BTreeSet T) (f : F) : Result (Unit × BTreeSet T × F) :=
  BTreeSet.retain_with ord fnInst.call_mut set f

/-- set.rs: `self.map.insert(value, SetValZST::default()).is_none()`. An equal
stored element is kept (BTreeMap::insert replaces only the value). -/
@[rust_fun "alloc::collections::btree::set::{alloc::collections::btree::set::BTreeSet<@T, @A>}::insert"
  (keepParams := [true, false]) (keepTraitClauses := [false, true])]
def BTreeSet.insert {T : Type} (ord : core.cmp.Ord T) (set : BTreeSet T) (value : T) :
    Result (Bool × BTreeSet T) := do
  let (old, map) ← alloc.collections.btree.map.BTreeMap.insert ord set.map value ()
  .ok (old.isNone, ⟨map⟩)

/-- set.rs: `self.map.remove(value).is_some()`. -/
@[rust_fun "alloc::collections::btree::set::{alloc::collections::btree::set::BTreeSet<@T, @A>}::remove"
  (keepParams := [true, false, true]) (keepTraitClauses := [false, true, true, true])]
def BTreeSet.remove {T Q : Type} (borrow : core.borrow.Borrow T Q)
    (keyOrd : core.cmp.Ord T) (ord : core.cmp.Ord Q) (set : BTreeSet T)
    (query : Q) : Result (Bool × BTreeSet T) := do
  let (old, map) ← alloc.collections.btree.map.BTreeMap.remove borrow keyOrd ord set.map query
  .ok (old.isSome, ⟨map⟩)

/-- set.rs `Extend<T>`: `iter.into_iter().for_each(|elem| { self.insert(elem); })`,
through the dictionary's `fold` (the provided `for_each`). An Ord-equal element
keeps the stored one. -/
@[rust_fun "alloc::collections::btree::set::{core::iter::traits::collect::Extend<alloc::collections::btree::set::BTreeSet<@T, @A>, @T>}::extend"
  (keepParams := [true, false, true, true]) (keepTraitClauses := [true, false, true])]
def ExtendBTreeSet.extend {T I IntoIter : Type} (ord : core.cmp.Ord T)
    (into : core.iter.traits.collect.IntoIterator I T IntoIter)
    (self : BTreeSet T) (input : I) : Result (Unit × BTreeSet T × I) := do
  let (iter, recover) ← into.into_iter input
  let call := fun (set : BTreeSet T) (args : Unit × T) => do
    let (_, set) ← BTreeSet.insert ord set args.2
    return ((), set)
  let fnInst : core.ops.function.FnMut (BTreeSet T) (Unit × T) Unit :=
    { FnOnceInst := { call_once := call }, call_mut := call }
  let (_, iter, self) ← into.iteratorInst.fold fnInst iter () self
  return ((), self, recover iter)

/-- set.rs `BTreeSet::iter`: the elements in ascending order. -/
@[rust_fun "alloc::collections::btree::set::{alloc::collections::btree::set::BTreeSet<@T, @A>}::iter"
  (keepParams := [true, false]) (keepTraitClauses := [false])]
def BTreeSet.iter {T : Type} (set : BTreeSet T) : Result (Iter T) :=
  .ok ⟨set.map.entries.map Prod.fst⟩

/-- set.rs `Iterator for Iter`: `self.iter.next()` over the keys. -/
@[rust_fun "alloc::collections::btree::set::{core::iter::traits::iterator::Iterator<alloc::collections::btree::set::Iter<'a, @T>, &'a @T>}::next"]
def IteratorIter.next {T : Type} (it : Iter T) : Result (Option T × Iter T) :=
  match it.remaining with
  | [] => .ok (none, it)
  | item :: rest => .ok (some item, ⟨rest⟩)

@[rust_fun "alloc::collections::btree::set::{core::iter::traits::iterator::Iterator<alloc::collections::btree::set::Iter<'a, @T>, &'a @T>}::size_hint"]
def IteratorIter.size_hint {T : Type} (it : Iter T) : Result (Usize × Option Usize) := do
  let length ← UScalar.tryMk .Usize it.remaining.length
  .ok (length, some length)

/-- set.rs: `self.iter.next().map(|(k, _)| k)`. -/
@[rust_fun "alloc::collections::btree::set::{core::iter::traits::iterator::Iterator<alloc::collections::btree::set::IntoIter<@T, @A>, @T>}::next"
  (keepParams := [true, false]) (keepTraitClauses := [false])]
def IteratorIntoIter.next {T : Type} (it : IntoIter T) : Result (Option T × IntoIter T) :=
  match it.remaining with
  | [] => .ok (none, it)
  | item :: rest => .ok (some item, ⟨rest⟩)

/-- set.rs: `self.iter.size_hint()` (the exact remaining length). -/
@[rust_fun "alloc::collections::btree::set::{core::iter::traits::iterator::Iterator<alloc::collections::btree::set::IntoIter<@T, @A>, @T>}::size_hint"
  (keepParams := [true, false]) (keepTraitClauses := [false])]
def IteratorIntoIter.size_hint {T : Type} (it : IntoIter T) : Result (Usize × Option Usize) := do
  let length ← UScalar.tryMk .Usize it.remaining.length
  .ok (length, some length)

/-- set.rs `IntoIterator for BTreeSet`: `IntoIter { iter: self.map.into_iter() }`. -/
@[rust_fun "alloc::collections::btree::set::{core::iter::traits::collect::IntoIterator<alloc::collections::btree::set::BTreeSet<@T, @A>, @T, alloc::collections::btree::set::IntoIter<@T, @A>>}::into_iter"
  (keepParams := [true, false]) (keepTraitClauses := [false])]
def IntoIteratorBTreeSet.into_iter {T : Type} (set : BTreeSet T) :
    Result (IntoIter T × (IntoIter T → BTreeSet T)) :=
  .ok (⟨set.map.entries.map Prod.fst⟩,
    fun iterator => ⟨⟨iterator.remaining.map fun key => (key, ())⟩⟩)

/-- Native Rust 1.98.0 commit 88d9e12ae178fab0fb5cc050a94da85685d449ea.
Vec collection precedes stable key sorting and map bulk construction.
DedupSortedIter retains the last equivalent key and calls PartialEq.ne.
Input recovery uses the selected native consumer state.
TrustedLen and indexed consumers need no final None poll. -/
@[rust_fun "alloc::collections::btree::set::{core::iter::traits::collect::FromIterator<alloc::collections::btree::set::BTreeSet<@T, alloc::alloc::Global>, @T>}::from_iter"]
def FromIteratorBTreeSet.from_iter {T I IntoIter : Type} (ord : core.cmp.Ord T)
    (into : core.iter.traits.collect.IntoIterator I T IntoIter)
    (input : I) : Result (BTreeSet T × I) := do
  let (iterator, recover) ← into.into_iter input
  let (items, iterator) ← alloc.vec.FromIteratorVec.collectNative into.iteratorInst iterator
  let (sorted, _) ← alloc.slice.stableSort
    (fun (_ : Unit) left right => do
      return (← ord.partialOrdInst.lt left right, ())) items ()
  let sorted := sorted.val.map (fun item => (item, ()))
  match sorted with
  | [] => .ok (⟨⟨[]⟩⟩, recover iterator)
  | first :: rest =>
    let entries ← alloc.collections.btree.map.dedupSorted ord.eqInst.partialEqInst first rest
    .ok (⟨⟨entries⟩⟩, recover iterator)

/-- `impl<T: Ord, const N: usize> From<[T; N]> for BTreeSet<T>` (set.rs, rustc 1.95): the empty
    set for `N == 0`, else `arr.sort()` (stable, through `PartialOrd::lt`) and
    `BTreeSet::from_sorted_iter`, whose `DedupSortedIter` keeps the last of adjacent equal
    elements (through `PartialEq::ne`), as `from_iter` does. -/
@[rust_fun "alloc::collections::btree::set::{core::convert::From<alloc::collections::btree::set::BTreeSet<@T, alloc::alloc::Global>, [@T; @N]>}::from"]
def FromArrayBTreeSet.from_ {T : Type} {N : Usize} (ord : core.cmp.Ord T) (arr : Array T N) :
    Result (BTreeSet T) := do
  if N.val = 0 then .ok ⟨⟨[]⟩⟩
  else
    let (sorted, _) ← alloc.slice.stableSort
      (fun (_ : Unit) left right => do
        return (← ord.partialOrdInst.lt left right, ())) arr.val ()
    match sorted.val.map (fun item => (item, ())) with
    | [] => .ok ⟨⟨[]⟩⟩
    | first :: rest =>
      let entries ← alloc.collections.btree.map.dedupSorted ord.eqInst.partialEqInst first rest
      .ok ⟨⟨entries⟩⟩

end alloc.collections.btree.set

@[reducible, rust_trait_impl "core::iter::traits::collect::FromIterator<alloc::collections::btree::set::BTreeSet<@T, alloc::alloc::Global>, @T>"]
def core.iter.traits.collect.FromIteratorBTreeSet {T : Type} (ord : core.cmp.Ord T) :
    core.iter.traits.collect.FromIterator (alloc.collections.btree.set.BTreeSet T) T := {
  from_iter := alloc.collections.btree.set.FromIteratorBTreeSet.from_iter ord
}

@[reducible, rust_trait_impl "core::iter::traits::collect::Extend<alloc::collections::btree::set::BTreeSet<@T, @A>, @T>"
  (keepParams := [true, false]) (keepTraitClauses := [true, false])]
def core.iter.traits.collect.ExtendBTreeSet {T : Type} (ord : core.cmp.Ord T) :
    core.iter.traits.collect.Extend (alloc.collections.btree.set.BTreeSet T) T := {
  extend := alloc.collections.btree.set.ExtendBTreeSet.extend ord
}

/-- set.rs implements only `next` and `size_hint`: the provided `fold` and
`try_fold` are kept (see `LawfulIterator.btreeSetIntoIter`). -/
@[reducible, rust_trait_impl "core::iter::traits::iterator::Iterator<alloc::collections::btree::set::IntoIter<@T, @A>, @T>"
  (keepParams := [true, false]) (keepTraitClauses := [false])]
def core.iter.traits.iterator.IteratorBTreeSetIntoIter (T : Type) :
    core.iter.traits.iterator.Iterator (alloc.collections.btree.set.IntoIter T) T := {
  next := alloc.collections.btree.set.IteratorIntoIter.next
  size_hint := alloc.collections.btree.set.IteratorIntoIter.size_hint
  fused := true
}

@[reducible, rust_trait_impl "core::iter::traits::collect::IntoIterator<alloc::collections::btree::set::BTreeSet<@T, @A>, @T, alloc::collections::btree::set::IntoIter<@T, @A>>"
  (keepParams := [true, false]) (keepTraitClauses := [false])]
def core.iter.traits.collect.IntoIteratorBTreeSet (T : Type) :
    core.iter.traits.collect.IntoIterator (alloc.collections.btree.set.BTreeSet T) T
      (alloc.collections.btree.set.IntoIter T) := {
  iteratorInst := core.iter.traits.iterator.IteratorBTreeSetIntoIter T
  into_iter := alloc.collections.btree.set.IntoIteratorBTreeSet.into_iter
}

/-- set.rs `Iterator for Iter` overrides only `next`, `size_hint`, `last`,
and `min`/`max`: the provided `fold`/`try_fold` are kept. -/
@[reducible, rust_trait_impl "core::iter::traits::iterator::Iterator<alloc::collections::btree::set::Iter<'a, @T>, &'a @T>"]
def core.iter.traits.iterator.IteratorBTreeSetIter (T : Type) :
    core.iter.traits.iterator.Iterator (alloc.collections.btree.set.Iter T) T := {
  next := alloc.collections.btree.set.IteratorIter.next
  size_hint := alloc.collections.btree.set.IteratorIter.size_hint
  fused := true
}

/-- set.rs `impl IntoIterator for &'a BTreeSet<T, A>`: `self.iter()`. The
borrowed set is not changed: recovery returns it whatever the iterator state. -/
@[rust_fun "alloc::collections::btree::set::{core::iter::traits::collect::IntoIterator<&'a alloc::collections::btree::set::BTreeSet<@T, @A>, &'a @T, alloc::collections::btree::set::Iter<'a, @T>>}::into_iter"
  (keepParams := [true, false]) (keepTraitClauses := [false])]
def alloc.collections.btree.set.IntoIteratorSharedBTreeSet.into_iter {T : Type}
    (set : alloc.collections.btree.set.BTreeSet T) :
    Result (alloc.collections.btree.set.Iter T ×
      (alloc.collections.btree.set.Iter T → alloc.collections.btree.set.BTreeSet T)) := do
  let iterator ← alloc.collections.btree.set.BTreeSet.iter set
  .ok (iterator, fun _ => set)

@[reducible, rust_trait_impl "core::iter::traits::collect::IntoIterator<&'a alloc::collections::btree::set::BTreeSet<@T, @A>, &'a @T, alloc::collections::btree::set::Iter<'a, @T>>"
  (keepParams := [true, false]) (keepTraitClauses := [false])]
def core.iter.traits.collect.IntoIteratorSharedBTreeSet (T : Type) :
    core.iter.traits.collect.IntoIterator (alloc.collections.btree.set.BTreeSet T) T
      (alloc.collections.btree.set.Iter T) := {
  iteratorInst := core.iter.traits.iterator.IteratorBTreeSetIter T
  into_iter := alloc.collections.btree.set.IntoIteratorSharedBTreeSet.into_iter
}

end Aeneas.Std
