import Aeneas.Std.Core.Core
import Aeneas.Std.Slice
import Aeneas.Std.String
import Aeneas.Std.Scalar.Casts
import Aeneas.Data.BitVec

namespace Aeneas.Std

open Result

/-- **Platform assumption** (verification/trusted_base.json, `platform_assumptions`): native code
    runs on a little-endian target (aarch64 and x86_64 are both little-endian), so an integer's
    `to_ne_bytes` is its `to_le_bytes`. Every model that depends on the native byte order reads
    it from here, and a big-endian target would have to change this definition. -/
def Platform.littleEndian : Bool := true

/-- `to_ne_bytes` of an integer (core/src/num/mod.rs: `to_ne_bytes` is the in-memory
    representation): its bytes in the native order (`Platform.littleEndian`), as a `&[u8]`. The
    at most 16 bytes always fit in a slice. -/
def core.hash.neBytes {w : Nat} (x : BitVec w) : Result (Slice U8) :=
  let bytes := (if Platform.littleEndian then x.toLEBytes else x.toBEBytes).map (@UScalar.mk .U8)
  if h : bytes.length ≤ Usize.max then ok ⟨bytes, h⟩ else fail .panic

/-- The one-byte slice `&[i]`. -/
def core.hash.byteSlice (i : U8) : Slice U8 := ⟨[i], by scalar_tac⟩

/-- `core::hash::Hasher` (core/src/hash/mod.rs, rustc 1.95). `finish` and `write` are required;
    the other methods are provided, and a `Hasher` implementation may override any of them, so
    each is a field whose default is the provided body: `write_u8` writes `&[i]`, the other
    unsigned `write_*` write `i.to_ne_bytes()` (`core.hash.neBytes`), each signed `write_iN`
    is `write_uN(i as uN)`, `write_length_prefix` is `write_usize`, and `write_str` writes the
    bytes of the string and then `write_u8(0xff)`. -/
@[rust_trait "core::hash::Hasher"
  (defaultMethods := ["write_u8", "write_u16", "write_u32", "write_u64", "write_u128",
    "write_usize", "write_i8", "write_i16", "write_i32", "write_i64", "write_i128", "write_isize",
    "write_length_prefix", "write_str"])]
structure core.hash.Hasher (Self : Type) where
  finish : Self → Result U64
  write : Self → Slice U8 → Result Self
  write_u8 : Self → U8 → Result Self := fun self i => write self (core.hash.byteSlice i)
  write_u16 : Self → U16 → Result Self := fun self i => do write self (← core.hash.neBytes i.bv)
  write_u32 : Self → U32 → Result Self := fun self i => do write self (← core.hash.neBytes i.bv)
  write_u64 : Self → U64 → Result Self := fun self i => do write self (← core.hash.neBytes i.bv)
  write_u128 : Self → U128 → Result Self := fun self i => do write self (← core.hash.neBytes i.bv)
  write_usize : Self → Usize → Result Self := fun self i => do write self (← core.hash.neBytes i.bv)
  write_i8 : Self → I8 → Result Self := fun self i => write_u8 self (IScalar.hcast .U8 i)
  write_i16 : Self → I16 → Result Self := fun self i => write_u16 self (IScalar.hcast .U16 i)
  write_i32 : Self → I32 → Result Self := fun self i => write_u32 self (IScalar.hcast .U32 i)
  write_i64 : Self → I64 → Result Self := fun self i => write_u64 self (IScalar.hcast .U64 i)
  write_i128 : Self → I128 → Result Self := fun self i => write_u128 self (IScalar.hcast .U128 i)
  write_isize : Self → Isize → Result Self := fun self i => write_usize self (IScalar.hcast .Usize i)
  write_length_prefix : Self → Usize → Result Self := fun self len => write_usize self len
  write_str : Self → Str → Result Self := fun self s => do write_u8 (← write self s) 255#u8

/-! The provided methods of `Hasher`, called on an implementation that does not override them:
    the bodies of the field defaults above, through the implementation's dictionary. -/

def core.hash.Hasher.write_u8.default {Self : Type} (HasherInst : core.hash.Hasher Self)
    (self : Self) (i : U8) : Result Self :=
  HasherInst.write self (core.hash.byteSlice i)

def core.hash.Hasher.write_u16.default {Self : Type} (HasherInst : core.hash.Hasher Self)
    (self : Self) (i : U16) : Result Self := do
  HasherInst.write self (← core.hash.neBytes i.bv)

def core.hash.Hasher.write_u32.default {Self : Type} (HasherInst : core.hash.Hasher Self)
    (self : Self) (i : U32) : Result Self := do
  HasherInst.write self (← core.hash.neBytes i.bv)

def core.hash.Hasher.write_u64.default {Self : Type} (HasherInst : core.hash.Hasher Self)
    (self : Self) (i : U64) : Result Self := do
  HasherInst.write self (← core.hash.neBytes i.bv)

def core.hash.Hasher.write_u128.default {Self : Type} (HasherInst : core.hash.Hasher Self)
    (self : Self) (i : U128) : Result Self := do
  HasherInst.write self (← core.hash.neBytes i.bv)

def core.hash.Hasher.write_usize.default {Self : Type} (HasherInst : core.hash.Hasher Self)
    (self : Self) (i : Usize) : Result Self := do
  HasherInst.write self (← core.hash.neBytes i.bv)

def core.hash.Hasher.write_i8.default {Self : Type} (HasherInst : core.hash.Hasher Self)
    (self : Self) (i : I8) : Result Self :=
  HasherInst.write_u8 self (IScalar.hcast .U8 i)

def core.hash.Hasher.write_i16.default {Self : Type} (HasherInst : core.hash.Hasher Self)
    (self : Self) (i : I16) : Result Self :=
  HasherInst.write_u16 self (IScalar.hcast .U16 i)

def core.hash.Hasher.write_i32.default {Self : Type} (HasherInst : core.hash.Hasher Self)
    (self : Self) (i : I32) : Result Self :=
  HasherInst.write_u32 self (IScalar.hcast .U32 i)

def core.hash.Hasher.write_i64.default {Self : Type} (HasherInst : core.hash.Hasher Self)
    (self : Self) (i : I64) : Result Self :=
  HasherInst.write_u64 self (IScalar.hcast .U64 i)

def core.hash.Hasher.write_i128.default {Self : Type} (HasherInst : core.hash.Hasher Self)
    (self : Self) (i : I128) : Result Self :=
  HasherInst.write_u128 self (IScalar.hcast .U128 i)

def core.hash.Hasher.write_isize.default {Self : Type} (HasherInst : core.hash.Hasher Self)
    (self : Self) (i : Isize) : Result Self :=
  HasherInst.write_usize self (IScalar.hcast .Usize i)

def core.hash.Hasher.write_length_prefix.default {Self : Type}
    (HasherInst : core.hash.Hasher Self) (self : Self) (len : Usize) : Result Self :=
  HasherInst.write_usize self len

def core.hash.Hasher.write_str.default {Self : Type} (HasherInst : core.hash.Hasher Self)
    (self : Self) (s : Str) : Result Self := do
  HasherInst.write_u8 (← HasherInst.write self s) 255#u8

/-- `for piece in data { piece.hash(state) }`: each element hashed in order. -/
def core.hash.hashEach {Self H : Type} (hash : core.hash.Hasher H → Self → H → Result H)
    (HasherInst : core.hash.Hasher H) : List Self → H → Result H
  | [], state => ok state
  | x :: xs, state => do core.hash.hashEach hash HasherInst xs (← hash HasherInst x state)

/-- `core::hash::Hash` (core/src/hash/mod.rs, rustc 1.95): `hash` is required, and the provided
    `hash_slice` (`for piece in data { piece.hash(state) }`) is a field whose default is that
    body, since an implementation may override it (the integer types hash a slice with one
    `write` of its bytes). -/
@[rust_trait "core::hash::Hash" (defaultMethods := ["hash_slice"])]
structure core.hash.Hash (Self : Type) where
  hash : forall {H : Type}, core.hash.Hasher H → Self → H → Result H
  hash_slice : forall {H : Type}, core.hash.Hasher H → Slice Self → H → Result H :=
    fun HasherInst data state => core.hash.hashEach (fun i x s => hash i x s) HasherInst data.val state

/-- The provided `Hash::hash_slice`, called on an implementation that does not override it. -/
def core.hash.Hash.hash_slice.default {Self H : Type} (HashInst : core.hash.Hash Self)
    (HasherInst : core.hash.Hasher H) (data : Slice Self) (state : H) : Result H :=
  core.hash.hashEach (fun i x s => HashInst.hash i x s) HasherInst data.val state

/-! `Box<T>` is modeled by `T`: its `Hash` impl hashes the boxed value (`(**self).hash(state)`). -/

@[rust_fun "alloc::boxed::{core::hash::Hash<Box<@T>>}::hash" (keepParams := [true, false, true])]
def alloc.boxed.HashBox.hash {T : Type} {H : Type} (HashInst : core.hash.Hash T)
    (HasherInst : core.hash.Hasher H) (x : T) (state : H) : Result H :=
  HashInst.hash HasherInst x state

@[reducible, rust_trait_impl "core::hash::Hash<Box<@T>>" (keepParams := [true, false])]
def core.hash.HashBox {T : Type} (HashInst : core.hash.Hash T) : core.hash.Hash T := {
  hash := fun HasherInst => alloc.boxed.HashBox.hash HashInst HasherInst
}

/-! The `Hash` impls of core/src/hash/mod.rs (`mod impls`, rustc 1.95): an integer is
    `state.write_<int>(*self)` (`impl_write!`), `bool` is `write_u8(*self as u8)`, `char` is
    `write_u32(*self as u32)`, `str` is `write_str(self)`, and `&T` hashes the referenced value.
    `impl_write!` also overrides `hash_slice` for the integers: `state.write` of the slice's
    memory (`slice::from_raw_parts(data.as_ptr() as *const u8, size_of_val(data))`), i.e. one
    `write` of the elements' native-order bytes (`core.hash.neBytes`), one after the other. -/

/-- The bytes of a slice of integers in memory: each element's `to_ne_bytes`, in order. A native
    slice spans at most `isize::MAX` bytes, so the bytes always fit in a slice. -/
def core.hash.sliceNeBytes {α : Type} {w : Nat} (bv : α → BitVec w) (data : Slice α) :
    Result (Slice U8) :=
  let bytes := data.val.flatMap fun x =>
    ((if Platform.littleEndian then (bv x).toLEBytes else (bv x).toBEBytes).map (@UScalar.mk .U8))
  if h : bytes.length ≤ Usize.max then ok ⟨bytes, h⟩ else fail .panic

/-- `hash_slice` of `impl_write!`: one `write` of the slice's bytes. -/
def core.hash.impls.hashSliceBytes {α H : Type} {w : Nat} (bv : α → BitVec w)
    (HasherInst : core.hash.Hasher H) (data : Slice α) (state : H) : Result H := do
  HasherInst.write state (← core.hash.sliceNeBytes bv data)

@[rust_fun "core::hash::impls::{core::hash::Hash<u8>}::hash"]
def core.hash.impls.HashU8.hash {H : Type} (HasherInst : core.hash.Hasher H) (self : U8)
    (state : H) : Result H := HasherInst.write_u8 state self
@[rust_fun "core::hash::impls::{core::hash::Hash<u16>}::hash"]
def core.hash.impls.HashU16.hash {H : Type} (HasherInst : core.hash.Hasher H) (self : U16)
    (state : H) : Result H := HasherInst.write_u16 state self
@[rust_fun "core::hash::impls::{core::hash::Hash<u32>}::hash"]
def core.hash.impls.HashU32.hash {H : Type} (HasherInst : core.hash.Hasher H) (self : U32)
    (state : H) : Result H := HasherInst.write_u32 state self
@[rust_fun "core::hash::impls::{core::hash::Hash<u64>}::hash"]
def core.hash.impls.HashU64.hash {H : Type} (HasherInst : core.hash.Hasher H) (self : U64)
    (state : H) : Result H := HasherInst.write_u64 state self
@[rust_fun "core::hash::impls::{core::hash::Hash<u128>}::hash"]
def core.hash.impls.HashU128.hash {H : Type} (HasherInst : core.hash.Hasher H) (self : U128)
    (state : H) : Result H := HasherInst.write_u128 state self
@[rust_fun "core::hash::impls::{core::hash::Hash<usize>}::hash"]
def core.hash.impls.HashUsize.hash {H : Type} (HasherInst : core.hash.Hasher H) (self : Usize)
    (state : H) : Result H := HasherInst.write_usize state self
@[rust_fun "core::hash::impls::{core::hash::Hash<i8>}::hash"]
def core.hash.impls.HashI8.hash {H : Type} (HasherInst : core.hash.Hasher H) (self : I8)
    (state : H) : Result H := HasherInst.write_i8 state self
@[rust_fun "core::hash::impls::{core::hash::Hash<i16>}::hash"]
def core.hash.impls.HashI16.hash {H : Type} (HasherInst : core.hash.Hasher H) (self : I16)
    (state : H) : Result H := HasherInst.write_i16 state self
@[rust_fun "core::hash::impls::{core::hash::Hash<i32>}::hash"]
def core.hash.impls.HashI32.hash {H : Type} (HasherInst : core.hash.Hasher H) (self : I32)
    (state : H) : Result H := HasherInst.write_i32 state self
@[rust_fun "core::hash::impls::{core::hash::Hash<i64>}::hash"]
def core.hash.impls.HashI64.hash {H : Type} (HasherInst : core.hash.Hasher H) (self : I64)
    (state : H) : Result H := HasherInst.write_i64 state self
@[rust_fun "core::hash::impls::{core::hash::Hash<i128>}::hash"]
def core.hash.impls.HashI128.hash {H : Type} (HasherInst : core.hash.Hasher H) (self : I128)
    (state : H) : Result H := HasherInst.write_i128 state self
@[rust_fun "core::hash::impls::{core::hash::Hash<isize>}::hash"]
def core.hash.impls.HashIsize.hash {H : Type} (HasherInst : core.hash.Hasher H) (self : Isize)
    (state : H) : Result H := HasherInst.write_isize state self

@[rust_fun "core::hash::impls::{core::hash::Hash<u8>}::hash_slice"]
def core.hash.impls.HashU8.hash_slice {H : Type} (HasherInst : core.hash.Hasher H)
    (data : Slice U8) (state : H) : Result H :=
  core.hash.impls.hashSliceBytes (fun (x : U8) => x.bv) HasherInst data state
@[rust_fun "core::hash::impls::{core::hash::Hash<u16>}::hash_slice"]
def core.hash.impls.HashU16.hash_slice {H : Type} (HasherInst : core.hash.Hasher H)
    (data : Slice U16) (state : H) : Result H :=
  core.hash.impls.hashSliceBytes (fun (x : U16) => x.bv) HasherInst data state
@[rust_fun "core::hash::impls::{core::hash::Hash<u32>}::hash_slice"]
def core.hash.impls.HashU32.hash_slice {H : Type} (HasherInst : core.hash.Hasher H)
    (data : Slice U32) (state : H) : Result H :=
  core.hash.impls.hashSliceBytes (fun (x : U32) => x.bv) HasherInst data state
@[rust_fun "core::hash::impls::{core::hash::Hash<u64>}::hash_slice"]
def core.hash.impls.HashU64.hash_slice {H : Type} (HasherInst : core.hash.Hasher H)
    (data : Slice U64) (state : H) : Result H :=
  core.hash.impls.hashSliceBytes (fun (x : U64) => x.bv) HasherInst data state
@[rust_fun "core::hash::impls::{core::hash::Hash<u128>}::hash_slice"]
def core.hash.impls.HashU128.hash_slice {H : Type} (HasherInst : core.hash.Hasher H)
    (data : Slice U128) (state : H) : Result H :=
  core.hash.impls.hashSliceBytes (fun (x : U128) => x.bv) HasherInst data state
@[rust_fun "core::hash::impls::{core::hash::Hash<usize>}::hash_slice"]
def core.hash.impls.HashUsize.hash_slice {H : Type} (HasherInst : core.hash.Hasher H)
    (data : Slice Usize) (state : H) : Result H :=
  core.hash.impls.hashSliceBytes (fun (x : Usize) => x.bv) HasherInst data state
@[rust_fun "core::hash::impls::{core::hash::Hash<i8>}::hash_slice"]
def core.hash.impls.HashI8.hash_slice {H : Type} (HasherInst : core.hash.Hasher H)
    (data : Slice I8) (state : H) : Result H :=
  core.hash.impls.hashSliceBytes (fun (x : I8) => x.bv) HasherInst data state
@[rust_fun "core::hash::impls::{core::hash::Hash<i16>}::hash_slice"]
def core.hash.impls.HashI16.hash_slice {H : Type} (HasherInst : core.hash.Hasher H)
    (data : Slice I16) (state : H) : Result H :=
  core.hash.impls.hashSliceBytes (fun (x : I16) => x.bv) HasherInst data state
@[rust_fun "core::hash::impls::{core::hash::Hash<i32>}::hash_slice"]
def core.hash.impls.HashI32.hash_slice {H : Type} (HasherInst : core.hash.Hasher H)
    (data : Slice I32) (state : H) : Result H :=
  core.hash.impls.hashSliceBytes (fun (x : I32) => x.bv) HasherInst data state
@[rust_fun "core::hash::impls::{core::hash::Hash<i64>}::hash_slice"]
def core.hash.impls.HashI64.hash_slice {H : Type} (HasherInst : core.hash.Hasher H)
    (data : Slice I64) (state : H) : Result H :=
  core.hash.impls.hashSliceBytes (fun (x : I64) => x.bv) HasherInst data state
@[rust_fun "core::hash::impls::{core::hash::Hash<i128>}::hash_slice"]
def core.hash.impls.HashI128.hash_slice {H : Type} (HasherInst : core.hash.Hasher H)
    (data : Slice I128) (state : H) : Result H :=
  core.hash.impls.hashSliceBytes (fun (x : I128) => x.bv) HasherInst data state
@[rust_fun "core::hash::impls::{core::hash::Hash<isize>}::hash_slice"]
def core.hash.impls.HashIsize.hash_slice {H : Type} (HasherInst : core.hash.Hasher H)
    (data : Slice Isize) (state : H) : Result H :=
  core.hash.impls.hashSliceBytes (fun (x : Isize) => x.bv) HasherInst data state

@[rust_fun "core::hash::impls::{core::hash::Hash<bool>}::hash"]
def core.hash.impls.HashBool.hash {H : Type} (HasherInst : core.hash.Hasher H) (self : Bool)
    (state : H) : Result H := HasherInst.write_u8 state (if self then 1#u8 else 0#u8)

@[rust_fun "core::hash::impls::{core::hash::Hash<char>}::hash"]
def core.hash.impls.HashChar.hash {H : Type} (HasherInst : core.hash.Hasher H) (self : Char)
    (state : H) : Result H := HasherInst.write_u32 state ⟨BitVec.ofNat _ self.toNat⟩

@[rust_fun "core::hash::impls::{core::hash::Hash<str>}::hash"]
def core.hash.impls.HashStr.hash {H : Type} (HasherInst : core.hash.Hasher H) (self : Str)
    (state : H) : Result H := HasherInst.write_str state self

@[rust_fun "core::hash::impls::{core::hash::Hash<&'0 @T>}::hash"]
def core.hash.impls.HashShared.hash {T H : Type} (HashInst : core.hash.Hash T)
    (HasherInst : core.hash.Hasher H) (self : T) (state : H) : Result H :=
  HashInst.hash HasherInst self state

@[reducible, rust_trait_impl "core::hash::Hash<u8>"]
def core.hash.HashU8 : core.hash.Hash U8 :=
  { hash := core.hash.impls.HashU8.hash, hash_slice := core.hash.impls.HashU8.hash_slice }
@[reducible, rust_trait_impl "core::hash::Hash<u16>"]
def core.hash.HashU16 : core.hash.Hash U16 :=
  { hash := core.hash.impls.HashU16.hash, hash_slice := core.hash.impls.HashU16.hash_slice }
@[reducible, rust_trait_impl "core::hash::Hash<u32>"]
def core.hash.HashU32 : core.hash.Hash U32 :=
  { hash := core.hash.impls.HashU32.hash, hash_slice := core.hash.impls.HashU32.hash_slice }
@[reducible, rust_trait_impl "core::hash::Hash<u64>"]
def core.hash.HashU64 : core.hash.Hash U64 :=
  { hash := core.hash.impls.HashU64.hash, hash_slice := core.hash.impls.HashU64.hash_slice }
@[reducible, rust_trait_impl "core::hash::Hash<u128>"]
def core.hash.HashU128 : core.hash.Hash U128 :=
  { hash := core.hash.impls.HashU128.hash, hash_slice := core.hash.impls.HashU128.hash_slice }
@[reducible, rust_trait_impl "core::hash::Hash<usize>"]
def core.hash.HashUsize : core.hash.Hash Usize :=
  { hash := core.hash.impls.HashUsize.hash, hash_slice := core.hash.impls.HashUsize.hash_slice }
@[reducible, rust_trait_impl "core::hash::Hash<i8>"]
def core.hash.HashI8 : core.hash.Hash I8 :=
  { hash := core.hash.impls.HashI8.hash, hash_slice := core.hash.impls.HashI8.hash_slice }
@[reducible, rust_trait_impl "core::hash::Hash<i16>"]
def core.hash.HashI16 : core.hash.Hash I16 :=
  { hash := core.hash.impls.HashI16.hash, hash_slice := core.hash.impls.HashI16.hash_slice }
@[reducible, rust_trait_impl "core::hash::Hash<i32>"]
def core.hash.HashI32 : core.hash.Hash I32 :=
  { hash := core.hash.impls.HashI32.hash, hash_slice := core.hash.impls.HashI32.hash_slice }
@[reducible, rust_trait_impl "core::hash::Hash<i64>"]
def core.hash.HashI64 : core.hash.Hash I64 :=
  { hash := core.hash.impls.HashI64.hash, hash_slice := core.hash.impls.HashI64.hash_slice }
@[reducible, rust_trait_impl "core::hash::Hash<i128>"]
def core.hash.HashI128 : core.hash.Hash I128 :=
  { hash := core.hash.impls.HashI128.hash, hash_slice := core.hash.impls.HashI128.hash_slice }
@[reducible, rust_trait_impl "core::hash::Hash<isize>"]
def core.hash.HashIsize : core.hash.Hash Isize :=
  { hash := core.hash.impls.HashIsize.hash, hash_slice := core.hash.impls.HashIsize.hash_slice }
@[reducible, rust_trait_impl "core::hash::Hash<bool>"]
def core.hash.HashBool : core.hash.Hash Bool := { hash := core.hash.impls.HashBool.hash }
@[reducible, rust_trait_impl "core::hash::Hash<char>"]
def core.hash.HashChar : core.hash.Hash Char := { hash := core.hash.impls.HashChar.hash }
@[reducible, rust_trait_impl "core::hash::Hash<str>"]
def core.hash.HashStr : core.hash.Hash Str := { hash := core.hash.impls.HashStr.hash }
@[reducible, rust_trait_impl "core::hash::Hash<&'0 @T>"]
def core.hash.HashShared {T : Type} (HashInst : core.hash.Hash T) : core.hash.Hash T :=
  { hash := fun HasherInst => core.hash.impls.HashShared.hash HashInst HasherInst }

/-- `impl<T: Hash> Hash for [T]`: `state.write_length_prefix(self.len())`, then
    `Hash::hash_slice(self, state)` (the element type's, overridden by the integers). -/
@[rust_fun "core::hash::impls::{core::hash::Hash<[@T]>}::hash"]
def core.hash.impls.HashSlice.hash {T H : Type} (HashInst : core.hash.Hash T)
    (HasherInst : core.hash.Hasher H) (self : Slice T) (state : H) : Result H := do
  HashInst.hash_slice HasherInst self (← HasherInst.write_length_prefix state self.len)

@[reducible, rust_trait_impl "core::hash::Hash<[@T]>"]
def core.hash.HashSlice {T : Type} (HashInst : core.hash.Hash T) : core.hash.Hash (Slice T) :=
  { hash := fun HasherInst => core.hash.impls.HashSlice.hash HashInst HasherInst }

/-- `impl Hash for String` (alloc/src/string.rs): `(**self).hash(hasher)`, the `str` of its
    UTF-8 bytes. -/
@[rust_fun "alloc::string::{core::hash::Hash<alloc::string::String>}::hash"]
def alloc.string.HashString.hash {H : Type} (HasherInst : core.hash.Hasher H) (self : String)
    (state : H) : Result H := do
  core.hash.impls.HashStr.hash HasherInst (← Str.ofString self) state

@[reducible, rust_trait_impl "core::hash::Hash<alloc::string::String>"]
def core.hash.HashString : core.hash.Hash String := { hash := alloc.string.HashString.hash }

/-- `#[derive(Hash)]` of `Option<T>` (core/src/option.rs): the discriminant as an `isize`
    (`None` is 0, `Some` is 1) through `Hash for isize`, then the payload of `Some`. -/
@[rust_fun "core::option::{core::hash::Hash<core::option::Option<@T>>}::hash"]
def core.option.HashOption.hash {T H : Type} (HashInst : core.hash.Hash T)
    (HasherInst : core.hash.Hasher H) (self : Option T) (state : H) : Result H :=
  match self with
  | none => core.hash.impls.HashIsize.hash HasherInst 0#isize state
  | some x => do
    HashInst.hash HasherInst x (← core.hash.impls.HashIsize.hash HasherInst 1#isize state)

@[reducible, rust_trait_impl "core::hash::Hash<core::option::Option<@T>>"]
def core.hash.HashOption {T : Type} (HashInst : core.hash.Hash T) : core.hash.Hash (Option T) :=
  { hash := fun HasherInst => core.option.HashOption.hash HashInst HasherInst }

end Aeneas.Std
