import Aeneas.Std.Core.Iter
import Aeneas.Std.SliceIter
import Aeneas.Std.Vec
import Aeneas.Std.IteratorSources

namespace Aeneas.Std

open Result

@[rust_type "alloc::vec::into_iter::IntoIter" (keepParams := [true, false])]
def alloc.vec.into_iter.IntoIter (T : Type) : Type := alloc.vec.Vec T

@[rust_fun
  "alloc::vec::into_iter::{core::iter::traits::iterator::Iterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::next"
  (keepParams := [true, false])]
def alloc.vec.into_iter.IteratorIntoIter.next {T : Type} (it: alloc.vec.into_iter.IntoIter T) :
  Result ((Option T) × (alloc.vec.into_iter.IntoIter T)) :=
  match it with
  | ⟨ [], _ ⟩  => ok (none, it)
  | ⟨ hd :: tl, _ ⟩ => ok (hd, ⟨ tl, by scalar_tac ⟩ )

@[rust_fun
  "alloc::vec::into_iter::{core::iter::traits::iterator::Iterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::step_by"
  (keepParams := [true, false])]
def alloc.vec.into_iter.IteratorIntoIter.step_by {T : Type} (it: alloc.vec.into_iter.IntoIter T) (steps : Usize) :
  Result (core.iter.adapters.step_by.StepBy (alloc.vec.into_iter.IntoIter T)) :=
  if steps.val = 0 then .fail .panic
  else .ok { iter := it, step_by := steps }

@[rust_fun
  "alloc::vec::into_iter::{core::iter::traits::iterator::Iterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::enumerate"
  (keepParams := [true, false])]
def alloc.vec.into_iter.IteratorIntoIter.enumerate {T : Type} (it: alloc.vec.into_iter.IntoIter T) :
  Result (core.iter.adapters.enumerate.Enumerate (alloc.vec.into_iter.IntoIter T)) :=
  .ok { iter := it, count := 0#usize }

@[rust_fun
  "alloc::vec::into_iter::{core::iter::traits::iterator::Iterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::take"
  (keepParams := [true, false])]
def alloc.vec.into_iter.IteratorIntoIter.take {T : Type} (it: alloc.vec.into_iter.IntoIter T) (n : Usize) :
  Result (core.iter.adapters.take.Take (alloc.vec.into_iter.IntoIter T)) :=
  .ok ⟨ it, n ⟩


@[rust_fun
  "alloc::vec::into_iter::{core::iter::traits::iterator::Iterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::size_hint"
  (keepParams := [true, false])]
def alloc.vec.into_iter.IteratorIntoIter.size_hint {T : Type}
  (self : alloc.vec.into_iter.IntoIter T) : Result (Usize × Option Usize) :=
  let n := Usize.ofNatCore self.val.length (by have := self.property; scalar_tac)
  ok (n, some n)

@[rust_fun
  "alloc::vec::into_iter::{core::iter::traits::iterator::Iterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::count"
  (keepParams := [true, false])]
def alloc.vec.into_iter.IteratorIntoIter.count {T : Type}
  (self : alloc.vec.into_iter.IntoIter T) : Result (Usize × alloc.vec.into_iter.IntoIter T) :=
  ok (Usize.ofNatCore self.val.length (by have := self.property; scalar_tac), self)

@[rust_fun
  "alloc::vec::into_iter::{core::iter::traits::iterator::Iterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::advance_by"
  (keepParams := [true, false])]
def alloc.vec.into_iter.IteratorIntoIter.advance_by {T : Type}
  (self : alloc.vec.into_iter.IntoIter T) (n : Usize) :
  Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) × alloc.vec.into_iter.IntoIter T) := do
  let step := min n.val self.val.length
  let it : alloc.vec.into_iter.IntoIter T := ⟨self.val.drop step, by
    simp only [List.length_drop]
    exact Nat.le_trans (Nat.sub_le _ _) self.property⟩
  if h : n.val ≤ step then ok (.Ok (), it)
  else
    let left := Usize.ofNatCore (n.val - step) (by scalar_tac)
    let left ← core.num.nonzero.NonZero.new_unchecked left
    ok (.Err left, it)

@[rust_fun
  "alloc::vec::into_iter::{core::iter::traits::iterator::Iterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::fold"
  (keepParams := [true, false, true, true])]
def alloc.vec.into_iter.IteratorIntoIter.fold
  {T B F : Type}
  (fnInst : core.ops.function.FnMut F (B × T) B)
  (self : alloc.vec.into_iter.IntoIter T) (init : B) (f : F) :
  Result (B × alloc.vec.into_iter.IntoIter T × F) :=
  core.iter.traits.iterator.foldFromNext
    alloc.vec.into_iter.IteratorIntoIter.next fnInst self init f

@[rust_fun
  "alloc::vec::into_iter::{core::iter::traits::iterator::Iterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::try_fold"
  (keepParams := [true, false, true, true, true, true])]
def alloc.vec.into_iter.IteratorIntoIter.try_fold
  {T B F R Residual : Type}
  (fnInst : core.ops.function.FnMut F (B × T) R)
  (tryInst : core.ops.try_trait.Try R B Residual)
  (self : alloc.vec.into_iter.IntoIter T) (init : B) (f : F) :
  Result (R × alloc.vec.into_iter.IntoIter T × F) :=
  core.iter.traits.iterator.tryFoldFromNext
    alloc.vec.into_iter.IteratorIntoIter.next fnInst tryInst self init f

/-- Native NoCoerce access needs Copy evidence for the complete Rust item type.
The compiler supplies this field only after it checks that evidence.
Indexed access does not advance the owned iterator. -/
/-
```lean
-/
def alloc.vec.into_iter.IteratorIntoIter.randomAccess {T : Type} :
    core.iter.traits.iterator.RandomAccess (alloc.vec.into_iter.IntoIter T) T := {
  is_full := false
  may_have_side_effect := false
  get_unchecked self index :=
    if h : index.val < self.val.length then
      .ok (self.val[index.val]'h, self)
    else .fail .panic
}
/-
```
-/
@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>"
  (keepParams := [true, false])]
def core.iter.traits.iterator.IteratorVecIntoIter (T : Type) :
  core.iter.traits.iterator.Iterator (alloc.vec.into_iter.IntoIter T) T := {
  next := alloc.vec.into_iter.IteratorIntoIter.next
  step_by := alloc.vec.into_iter.IteratorIntoIter.step_by
  enumerate := alloc.vec.into_iter.IteratorIntoIter.enumerate
  take := alloc.vec.into_iter.IteratorIntoIter.take
  count := alloc.vec.into_iter.IteratorIntoIter.count
  advance_by := alloc.vec.into_iter.IteratorIntoIter.advance_by
  fold := alloc.vec.into_iter.IteratorIntoIter.fold
  try_fold := alloc.vec.into_iter.IteratorIntoIter.try_fold
  size_hint := alloc.vec.into_iter.IteratorIntoIter.size_hint
  trusted_len := true
  fused := true
}

/-- `DoubleEndedIterator for vec::IntoIter` (alloc vec/into_iter.rs, rustc 1.95):
    `next_back` moves the last remaining element out. -/
@[rust_fun
  "alloc::vec::into_iter::{core::iter::traits::double_ended::DoubleEndedIterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::next_back"
  (keepParams := [true, false])]
def alloc.vec.into_iter.DoubleEndedIteratorIntoIter.next_back {T : Type}
  (it : alloc.vec.into_iter.IntoIter T) :
  Result ((Option T) × (alloc.vec.into_iter.IntoIter T)) :=
  match it.val.getLast? with
  | none => ok (none, it)
  | some last => ok (some last, ⟨it.val.dropLast, by
      simp only [List.length_dropLast]
      exact Nat.le_trans (Nat.sub_le _ _) it.property⟩)

/-- `advance_back_by` drops the last `min n len` elements and returns the
    shortfall, `NonZero::new(n - step).map_or(Ok(()), Err)`. -/
@[rust_fun
  "alloc::vec::into_iter::{core::iter::traits::double_ended::DoubleEndedIterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::advance_back_by"
  (keepParams := [true, false])]
def alloc.vec.into_iter.DoubleEndedIteratorIntoIter.advance_back_by {T : Type}
  (self : alloc.vec.into_iter.IntoIter T) (n : Usize) :
  Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) × alloc.vec.into_iter.IntoIter T) := do
  let step := min n.val self.val.length
  let it : alloc.vec.into_iter.IntoIter T := ⟨self.val.take (self.val.length - step), by
    simp only [List.length_take]
    exact Nat.le_trans (Nat.min_le_right _ _) self.property⟩
  if h : n.val ≤ step then ok (.Ok (), it)
  else
    let left := Usize.ofNatCore (n.val - step) (by scalar_tac)
    let left ← core.num.nonzero.NonZero.new_unchecked left
    ok (.Err left, it)

/-- The other methods are the trait's provided ones: `nth_back` through
    `advance_back_by`, `rfold`/`try_rfold`/`rfind` repeated `next_back`. -/
@[reducible, rust_trait_impl
  "core::iter::traits::double_ended::DoubleEndedIterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>"
  (keepParams := [true, false])]
def core.iter.traits.double_ended.DoubleEndedIteratorVecIntoIter (T : Type) :
  core.iter.traits.double_ended.DoubleEndedIterator (alloc.vec.into_iter.IntoIter T) T := {
  iteratorInst := core.iter.traits.iterator.IteratorVecIntoIter T
  next_back := alloc.vec.into_iter.DoubleEndedIteratorIntoIter.next_back
  advance_back_by := alloc.vec.into_iter.DoubleEndedIteratorIntoIter.advance_back_by
}

/-- Recovery exposes only the actual unconsumed suffix. Yielded elements are
moved out, so this is not full-state recovery for contained mutable ownership;
the typed adapter must reject conversions requiring that recovery. -/
@[rust_fun
  "alloc::vec::{core::iter::traits::collect::IntoIterator<alloc::vec::Vec<@T>, @T, alloc::vec::into_iter::IntoIter<@T, @A>>}::into_iter"
  (keepParams := [true, false])]
def alloc.vec.IntoIteratorVec.into_iter {T : Type} (v : alloc.vec.Vec T) :
    Result (alloc.vec.into_iter.IntoIter T ×
      (alloc.vec.into_iter.IntoIter T → alloc.vec.Vec T)) :=
  ok (v, id)

@[reducible, rust_trait_impl
  "core::iter::traits::collect::IntoIterator<alloc::vec::Vec<@T>, @T, alloc::vec::into_iter::IntoIter<@T, @A>>"
  (keepParams := [true, false])]
def core.iter.traits.collect.IntoIteratorVec (T : Type) :
  core.iter.traits.collect.IntoIterator (alloc.vec.Vec T) T
  (alloc.vec.into_iter.IntoIter T) := {
  iteratorInst := core.iter.traits.iterator.IteratorVecIntoIter T
  into_iter := alloc.vec.IntoIteratorVec.into_iter
}

/-- `IntoIterator for Box<[I], A>` (boxed/iter.rs): `self.into_vec().into_iter()`. -/
@[rust_fun
  "alloc::boxed::iter::{core::iter::traits::collect::IntoIterator<Box<[@I]>, @I, alloc::vec::into_iter::IntoIter<@I, @A>>}::into_iter"
  (keepParams := [true, false])]
def alloc.boxed.IntoIteratorBoxSlice.into_iter {I : Type} (s : Slice I) :
    Result (alloc.vec.into_iter.IntoIter I ×
      (alloc.vec.into_iter.IntoIter I → Slice I)) :=
  ok (s, id)

@[reducible, rust_trait_impl
  "core::iter::traits::collect::IntoIterator<Box<[@I]>, @I, alloc::vec::into_iter::IntoIter<@I, @A>>"
  (keepParams := [true, false])]
def core.iter.traits.collect.IntoIteratorBoxSlice (I : Type) :
  core.iter.traits.collect.IntoIterator (Slice I) I
  (alloc.vec.into_iter.IntoIter I) := {
  iteratorInst := core.iter.traits.iterator.IteratorVecIntoIter I
  into_iter := alloc.boxed.IntoIteratorBoxSlice.into_iter
}

@[rust_fun
  "alloc::vec::{core::iter::traits::collect::IntoIterator<&'a alloc::vec::Vec<@T>, &'a @T, core::slice::iter::Iter<'a, @T>>}::into_iter"
  (keepParams := [true, false])]
def alloc.vec.IntoIteratorSharedVec.into_iter {T : Type} (v : alloc.vec.Vec T) :
    Result (core.slice.iter.Iter T × (core.slice.iter.Iter T → alloc.vec.Vec T)) := do
  let it ← core.slice.Slice.iter (alloc.vec.Vec.deref v)
  -- Recover full storage, not the unconsumed range tracked by the cursors.
  ok (it, fun it => ⟨it.slice.val, it.slice.property⟩)

@[reducible, rust_trait_impl
  "core::iter::traits::collect::IntoIterator<&'a alloc::vec::Vec<@T>, &'a @T, core::slice::iter::Iter<'a, @T>>"
  (keepParams := [true, false])]
def core.iter.traits.collect.IntoIteratorSharedVec (T : Type) :
  core.iter.traits.collect.IntoIterator (alloc.vec.Vec T) T (core.slice.iter.Iter T) := {
  iteratorInst := core.iter.traits.iterator.IteratorSliceIter T
  into_iter := alloc.vec.IntoIteratorSharedVec.into_iter
}

@[rust_fun
  "alloc::vec::{core::iter::traits::collect::IntoIterator<&'a mut alloc::vec::Vec<@T>, &'a mut @T, core::slice::iter::IterMut<'a, @T>>}::into_iter"
  (keepParams := [true, false])]
def alloc.vec.IntoIteratorMutVec.into_iter {T : Type} (v : alloc.vec.Vec T) :
    Result (core.slice.iter.IterMut T × (core.slice.iter.IterMut T → alloc.vec.Vec T)) := do
  let (slice, restoreVec) := alloc.vec.Vec.deref_mut v
  let (it, restoreSlice) ← core.slice.Slice.iter_mut slice
  -- IterMut retains the full storage. Its next giveback restores each yielded
  -- slot into that storage, including slots before the final cursor.
  ok (it, fun it => restoreVec (restoreSlice it))

/-- Iterate and collect elements into a list, retaining the terminal iterator. -/
def alloc.vec.FromIteratorVec.iterToList
    {T : Type} {IntoIter : Type}
    (iterInst : core.iter.traits.iterator.Iterator IntoIter T)
    (iter : IntoIter) (acc : List T) : Result (List T × IntoIter) := do
  let (opt, iter) ← iterInst.next iter
  match opt with
  | none => .ok (acc.reverse, iter)
  | some item => alloc.vec.FromIteratorVec.iterToList iterInst iter (item :: acc)
partial_fixpoint

/- Native Rust 1.98.0 commit 88d9e12ae178fab0fb5cc050a94da85685d449ea.
The collector keeps the existing heap abstraction. Allocation identity,
allocation failure, and destructor effects remain outside this model.
An absent TrustedLen upper bound causes a panic before a callback.
The in-place route needs an authenticated layout and source certificate. -/

/-
```lean
-/
def alloc.vec.FromIteratorVec.collectPush {T : Type}
    (acc : Usize × List T) (item : T) : Result (Usize × List T) :=
  match Usize.checked_add acc.1 1#usize with
  | none => .fail .panic
  | some length => .ok (length, item :: acc.2)

def alloc.vec.FromIteratorVec.collectByFold {T I : Type}
    (iterInst : core.iter.traits.iterator.Iterator I T) (iter : I) :
    Result (List T × I) := do
  let call := fun (_ : Unit) (args : (Usize × List T) × T) => do
    return (← alloc.vec.FromIteratorVec.collectPush args.1 args.2, ())
  let callback : core.ops.function.FnMut Unit ((Usize × List T) × T)
      (Usize × List T) := {
    FnOnceInst := { call_once := call }
    call_mut := call
  }
  let (acc, iter, _) ← iterInst.fold callback iter (0#usize, []) ()
  return (acc.2.reverse, iter)

def alloc.vec.FromIteratorVec.collectByTryFold {T I : Type}
    (iterInst : core.iter.traits.iterator.Iterator I T) (iter : I) :
    Result (List T × I) := do
  let call := fun (_ : Unit) (args : (Usize × List T) × T) => do
    let acc ← alloc.vec.FromIteratorVec.collectPush args.1 args.2
    return ((.Ok acc : core.result.Result (Usize × List T) Empty), ())
  let callback : core.ops.function.FnMut Unit ((Usize × List T) × T)
      (core.result.Result (Usize × List T) Empty) := {
    FnOnceInst := { call_once := call }
    call_mut := call
  }
  let (result, iter, _) ← iterInst.try_fold callback
    (core.result.TryResult (Usize × List T) Empty) iter (0#usize, []) ()
  match result with
  | .Ok acc => return (acc.2.reverse, iter)
  | .Err impossible => nomatch impossible

def alloc.vec.FromIteratorVec.collectIndexed {T I : Type}
    (access : core.iter.traits.iterator.RandomAccess I T)
    (iter : I) (index : Usize) (acc : Usize × List T) :
    Nat → Result (List T × I)
  | 0 => .ok (acc.2.reverse, iter)
  | remaining + 1 => do
    let (item, iter) ← access.get_unchecked iter index
    let acc ← alloc.vec.FromIteratorVec.collectPush acc item
    let index ← index + 1#usize
    alloc.vec.FromIteratorVec.collectIndexed access iter index acc remaining

/-- The dictionary selects the native consumer, not a production call-site name. -/
def alloc.vec.FromIteratorVec.collectNative {T I : Type}
    (iterInst : core.iter.traits.iterator.Iterator I T) (iter : I) :
    Result (List T × I) := do
  if iterInst.in_place_collect then
    match iterInst.random_access with
    | some access =>
      let (length, _) ← iterInst.size_hint iter
      alloc.vec.FromIteratorVec.collectIndexed access iter 0#usize (0#usize, []) length.val
    | none => alloc.vec.FromIteratorVec.collectByTryFold iterInst iter
  else if iterInst.trusted_len then
    let (_, upper) ← iterInst.size_hint iter
    let some _ := upper | .fail .panic
    alloc.vec.FromIteratorVec.collectByFold iterInst iter
  else
    alloc.vec.FromIteratorVec.iterToList iterInst iter []
/-
```
-/

@[rust_fun
  "alloc::vec::{core::iter::traits::collect::FromIterator<alloc::vec::Vec<@T>, @T>}::from_iter"]
def alloc.vec.FromIteratorVec.from_iter
  {T : Type} {I : Type} {IntoIter : Type}
  (IntoIteratorInst : core.iter.traits.collect.IntoIterator I T IntoIter) :
  I → Result (alloc.vec.Vec T × I) :=
  fun input => do
    let (iter, recover) ← IntoIteratorInst.into_iter input
    let (list, iter) ← alloc.vec.FromIteratorVec.collectNative IntoIteratorInst.iteratorInst iter
    if h : list.length ≤ Usize.max then .ok (⟨list, h⟩, recover iter)
    else .fail .panic

@[reducible, rust_trait_impl
  "core::iter::traits::collect::FromIterator<alloc::vec::Vec<@T>, @T>"]
def core.iter.traits.collect.FromIteratorVec (T : Type) :
  core.iter.traits.collect.FromIterator (alloc.vec.Vec T) T := {
  from_iter := fun {I : Type} {IntoIter : Type}
    (IntoIteratorInst : core.iter.traits.collect.IntoIterator I T IntoIter) =>
    alloc.vec.FromIteratorVec.from_iter IntoIteratorInst
}

/-- `FromIterator<char> for String` (alloc/src/string.rs, rustc 1.95): `let mut buf =
    String::new(); buf.extend(iter); buf`, and `Extend<char>` reserves the iterator's lower
    size bound (unobservable: the capacity is not part of the model, as for `Vec`) and pushes
    every char through `for_each`, i.e. the iterator's `fold`, which the collection contract
    (`CollectionContracts`) only admits on reviewed iterators whose `fold` is their `next`
    loop. The value given back is the input after `into_iter`'s final state. -/
@[rust_fun
  "alloc::string::{core::iter::traits::collect::FromIterator<alloc::string::String, char>}::from_iter"]
def alloc.string.FromIteratorStringChar.from_iter {I IntoIter : Type}
    (IntoIteratorInst : core.iter.traits.collect.IntoIterator I Char IntoIter) (input : I) :
    Result (String × I) := do
  let (iter, recover) ← IntoIteratorInst.into_iter input
  let (chars, iter) ← alloc.vec.FromIteratorVec.iterToList IntoIteratorInst.iteratorInst iter []
  .ok (String.ofList chars, recover iter)

@[reducible, rust_trait_impl
  "core::iter::traits::collect::FromIterator<alloc::string::String, char>"]
def core.iter.traits.collect.FromIteratorStringChar :
    core.iter.traits.collect.FromIterator String Char := {
  from_iter := fun {I : Type} {IntoIter : Type}
    (IntoIteratorInst : core.iter.traits.collect.IntoIterator I Char IntoIter) =>
    alloc.string.FromIteratorStringChar.from_iter IntoIteratorInst
}

@[rust_fun
  "alloc::vec::into_iter::{core::iter::traits::iterator::Iterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::map"]
def alloc.vec.into_iter.IntoIter.Insts.CoreIterTraitsIteratorIterator.map
  {T : Type} {A : Type} {F : Type}
  (_FnMutInst : core.ops.function.FnMut F T A) :
  alloc.vec.into_iter.IntoIter T → F →
  Result (core.iter.adapters.map.Map (alloc.vec.into_iter.IntoIter T) F) :=
  fun it f => .ok ⟨ it, f ⟩


/-- `Iterator::unzip` (core/src/iter/traits/iterator.rs, rustc 1.95): `FromA::default()`,
    `FromB::default()`, then `Extend<(A, B)>` of the pair (core/src/iter/traits/collect.rs,
    `impl_extend_tuple!`, `default_extend`): it reads the size hint, reserves it on both sides
    (capacity only) and calls `extend_one` of the first side and then of the second side for
    each item, through `for_each`, i.e. the iterator's own `fold`. `extend_one` is
    `extend(Some(item))` (its default; the overrides of Vec, BTreeMap and BTreeSet push or insert
    the item alike). The iterator's final state is returned (`ModelStateInputs.for_method`).
    `unzip` cannot be a field of Iterator: Extend depends on Iterator through IntoIterator.
    Generic calls use the rust_trait defaultOnlyMethods contract, as for `collect`. -/
@[rust_fun "core::iter::traits::iterator::Iterator::unzip"]
def core.iter.traits.iterator.Iterator.unzip.default {Self A B FromA FromB : Type}
    (iterInst : core.iter.traits.iterator.Iterator Self (A × B))
    (defaultA : core.default.Default FromA) (extendA : core.iter.traits.collect.Extend FromA A)
    (defaultB : core.default.Default FromB) (extendB : core.iter.traits.collect.Extend FromB B)
    (_ : core.iter.traits.iterator.Iterator Self (A × B))
    (self : Self) : Result ((FromA × FromB) × Self) := do
  let a ← defaultA.default
  let b ← defaultB.default
  let step := fun (x : (FromA × FromB) × (A × B)) => do
    let (_, a, _) ← extendA.extend (core.iter.traits.collect.IntoIteratorOption A) x.1.1
      (some x.2.1)
    let (_, b, _) ← extendB.extend (core.iter.traits.collect.IntoIteratorOption B) x.1.2
      (some x.2.2)
    ok (a, b)
  let stepInst : core.ops.function.FnMut Unit ((FromA × FromB) × (A × B)) (FromA × FromB) := {
    FnOnceInst := { call_once := fun _ x => do ok (← step x, ()) }
    call_mut := fun _ x => do ok (← step x, ())
  }
  let (r, self, _) ← iterInst.fold stepInst self (a, b) ()
  ok (r, self)

/-- `vec::IntoIter`'s inherited `Iterator::unzip`. -/
@[rust_fun
  "alloc::vec::into_iter::{core::iter::traits::iterator::Iterator<alloc::vec::into_iter::IntoIter<@T, @A>, @T>}::unzip"
  (keepParams := [true, false, true, true, true, true])]
def alloc.vec.into_iter.IteratorIntoIter.unzip {T A B FromA FromB : Type}
    (defaultA : core.default.Default FromA) (extendA : core.iter.traits.collect.Extend FromA A)
    (defaultB : core.default.Default FromB) (extendB : core.iter.traits.collect.Extend FromB B)
    (iterInst : core.iter.traits.iterator.Iterator (alloc.vec.into_iter.IntoIter T) (A × B))
    (self : alloc.vec.into_iter.IntoIter T) :
    Result ((FromA × FromB) × alloc.vec.into_iter.IntoIter T) :=
  core.iter.traits.iterator.Iterator.unzip.default iterInst defaultA extendA defaultB extendB
    iterInst self

end Aeneas.Std
