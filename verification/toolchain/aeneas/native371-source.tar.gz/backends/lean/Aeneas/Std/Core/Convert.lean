import Aeneas.Std.Core.Core
import Aeneas.Std.Core.Result

namespace Aeneas.Std

open Result

@[reducible, rust_type "core::num::error::TryFromIntError"]
def core.num.error.TryFromIntError := Unit

/-- `PartialEq for TryFromIntError` (derived on `struct TryFromIntError(())`): always equal. -/
@[rust_fun "core::num::error::{core::cmp::PartialEq<core::num::error::TryFromIntError, core::num::error::TryFromIntError>}::eq"]
def core.num.error.PartialEqTryFromIntError.eq (_ _ : core.num.error.TryFromIntError) :
  Result Bool := .ok true

@[rust_trait "core::convert::Into"]
structure core.convert.Into (Self : Type) (T : Type) where
  into : Self → Result T

@[reducible, simp, step_simps, rust_fun "core::convert::{core::convert::Into<@T, @U>}::into"]
def core.convert.IntoFrom.into {T : Type} {U : Type}
  (fromInst : core.convert.From U T) (x : T) : Result U :=
  fromInst.from_ x

@[reducible, rust_trait_impl "core::convert::Into<@Self, @T>"]
def core.convert.IntoFrom {T : Type} {U : Type} (fromInst : core.convert.From U T)
  : core.convert.Into T U := {
  into := core.convert.IntoFrom.into fromInst
}

@[rust_trait "core::convert::TryFrom"]
structure core.convert.TryFrom (Self T Error : Type) where
  try_from : T → Result (core.result.Result Self Error)

/-- The infallible blanket `impl<T, U: Into<T>> TryFrom<U> for T`
    (core/src/convert/mod.rs): `Ok(U::into(value))`. -/
@[rust_fun "core::convert::{core::convert::TryFrom<@T, @U, core::convert::Infallible>}::try_from"]
def core.convert.TryFromTUInfallible.Blanket.try_from {T U : Type}
  (IntoInst : core.convert.Into U T) (value : U) :
  Result (core.result.Result T core.convert.Infallible) := do
  let converted ← IntoInst.into value
  ok (.Ok converted)

@[reducible, rust_trait_impl "core::convert::TryFrom<@T, @U, core::convert::Infallible>"]
def core.convert.TryFromTUInfallible.Blanket {T U : Type} (IntoInst : core.convert.Into U T) :
  core.convert.TryFrom T U core.convert.Infallible := {
  try_from := core.convert.TryFromTUInfallible.Blanket.try_from IntoInst
}

@[rust_fun "core::convert::{core::convert::TryInto<@T, @U, @Error>}::try_into"]
def core.convert.TryInto.Blanket.try_into
  {T : Type} {U : Type} {Error : Type} (TryFromInst : core.convert.TryFrom U T Error) (x : T) :
  Result (core.result.Result U Error) :=
  TryFromInst.try_from x

@[rust_trait "core::convert::TryInto"]
structure core.convert.TryInto (Self T Error : Type) where
  try_into : Self → Result (core.result.Result T Error)

@[reducible, simp]
def core.convert.TryIntoFrom.try_into {T U Error : Type} (fromInst : core.convert.TryFrom U T Error)
  (x : T) : Result (core.result.Result U Error) :=
  fromInst.try_from x

@[reducible, rust_trait_impl "core::convert::{core::convert::TryInto<@T, @U>}"]
def core.convert.TryIntoFrom {T U Error : Type} (fromInst : core.convert.TryFrom U T Error) :
  core.convert.TryInto T U Error := {
  try_into := core.convert.TryIntoFrom.try_into fromInst
}

@[reducible, rust_trait_impl "core::convert::TryInto<@T, @U, @E>"]
def core.convert.TryInto.Blanket {T U E : Type}
  (TryFromInst : core.convert.TryFrom U T E) :
  core.convert.TryInto T U E := {
  try_into := core.convert.TryInto.Blanket.try_into TryFromInst
}

@[rust_trait "core::convert::AsMut"]
structure core.convert.AsMut (Self : Type) (T : Type) where
  as_mut : Self → Result (T × (T → Self))

@[reducible, rust_trait_impl "core::convert::AsMut<Box<@T>, @T>"]
def core.convert.AsMutBox (T : Type) : core.convert.AsMut T T := {
  as_mut := fun x => ok (alloc.boxed.AsMutBox.as_mut x)
}

end Aeneas.Std
