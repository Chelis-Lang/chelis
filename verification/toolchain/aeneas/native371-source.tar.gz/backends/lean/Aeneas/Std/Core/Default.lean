import Aeneas.Std.Primitives

namespace Aeneas.Std

@[rust_trait "core::default::Default"]
structure core.default.Default (Self : Type) where
  default : Result Self

@[rust_fun "core::default::{core::default::Default<bool>}::default"]
def core.default.DefaultBool.default : Result Bool := .ok false

/-- `Default for Option<T>` (core/src/option.rs): `None`. -/
@[rust_fun "core::option::{core::default::Default<core::option::Option<@T>>}::default"]
def core.option.DefaultOption.default (T : Type) : Result (Option T) := .ok none

@[reducible, rust_trait_impl "core::default::Default<core::option::Option<@T>>"]
def core.option.DefaultOption (T : Type) : core.default.Default (Option T) := {
  default := core.option.DefaultOption.default T
}

/-- `impl<T: Default> Default for Box<T>` (alloc/src/boxed.rs): a box of `T::default()`
    (a box is its contents in the model). -/
@[rust_fun "alloc::boxed::{core::default::Default<Box<@T>>}::default"]
def alloc.boxed.DefaultBox.default {T : Type} (inst : core.default.Default T) : Result T :=
  inst.default

@[reducible, rust_trait_impl "core::default::Default<Box<@T>>"]
def alloc.boxed.DefaultBox {T : Type} (inst : core.default.Default T) : core.default.Default T := {
  default := alloc.boxed.DefaultBox.default inst
}

/-- `core::mem::take` (core/src/mem/mod.rs): `replace(dest, T::default())`, i.e. the
    old value, and `T::default()` as the new value of `*dest`. -/
@[rust_fun "core::mem::take"]
def core.mem.take {T : Type} (inst : core.default.Default T) (dest : T) : Result (T × T) := do
  let fresh ← inst.default
  .ok (dest, fresh)

end Aeneas.Std
