import Aeneas.Std.Core.Ops

/-! `core::panic::AssertUnwindSafe<T>` (core/src/panic/unwind_safe.rs, rustc 1.95):
    `pub struct AssertUnwindSafe<T>(pub T)`, a marker newtype (it only adds the `UnwindSafe` and
    `RefUnwindSafe` auto-trait impls, which have no code). Aeneas represents a tuple structure of
    one field by that field (`AssertUnwindSafe(x)` is `x` and `w.0` is `w`), so the model of the
    type is the alias `T`, and its `Deref`, `DerefMut` and `FnOnce<()>` impls are those of the
    inner value. -/

namespace Aeneas.Std

open Result

@[reducible, rust_type "core::panic::unwind_safe::AssertUnwindSafe"]
def core.panic.unwind_safe.AssertUnwindSafe (T : Type) : Type := T

/-- `impl<T> Deref for AssertUnwindSafe<T>`: `&self.0`. -/
@[rust_fun
  "core::panic::unwind_safe::{core::ops::deref::Deref<core::panic::unwind_safe::AssertUnwindSafe<@T>, @T>}::deref"]
def core.panic.unwind_safe.DerefAssertUnwindSafe.deref {T : Type}
    (self : core.panic.unwind_safe.AssertUnwindSafe T) : Result T :=
  ok self

@[reducible, rust_trait_impl
  "core::ops::deref::Deref<core::panic::unwind_safe::AssertUnwindSafe<@T>, @T>"]
def core.panic.unwind_safe.DerefAssertUnwindSafe (T : Type) :
    core.ops.deref.Deref (core.panic.unwind_safe.AssertUnwindSafe T) T := {
  deref := core.panic.unwind_safe.DerefAssertUnwindSafe.deref
}

/-- `impl<T> DerefMut for AssertUnwindSafe<T>`: `&mut self.0`; the value written through the
    borrow is the new field. -/
@[rust_fun
  "core::panic::unwind_safe::{core::ops::deref::DerefMut<core::panic::unwind_safe::AssertUnwindSafe<@T>, @T>}::deref_mut"]
def core.panic.unwind_safe.DerefMutAssertUnwindSafe.deref_mut {T : Type}
    (self : core.panic.unwind_safe.AssertUnwindSafe T) :
    Result (T × (T → core.panic.unwind_safe.AssertUnwindSafe T)) :=
  ok (self, fun inner => inner)

@[reducible, rust_trait_impl
  "core::ops::deref::DerefMut<core::panic::unwind_safe::AssertUnwindSafe<@T>, @T>"]
def core.panic.unwind_safe.DerefMutAssertUnwindSafe (T : Type) :
    core.ops.deref.DerefMut (core.panic.unwind_safe.AssertUnwindSafe T) T := {
  derefInst := core.panic.unwind_safe.DerefAssertUnwindSafe T
  deref_mut := core.panic.unwind_safe.DerefMutAssertUnwindSafe.deref_mut
}

/-- `impl<R, F: FnOnce() -> R> FnOnce<()> for AssertUnwindSafe<F>`: `(self.0)()`, the inner
    closure's call; the consumed state is the inner closure's. -/
@[rust_fun
  "core::panic::unwind_safe::{core::ops::function::FnOnce<core::panic::unwind_safe::AssertUnwindSafe<@F>, (), @R>}::call_once"]
def core.panic.unwind_safe.FnOnceAssertUnwindSafe.call_once {R F : Type}
    (inst : core.ops.function.FnOnce F Unit R) (self : core.panic.unwind_safe.AssertUnwindSafe F)
    (args : Unit) : Result (R × core.panic.unwind_safe.AssertUnwindSafe F) :=
  inst.call_once self args

@[reducible, rust_trait_impl
  "core::ops::function::FnOnce<core::panic::unwind_safe::AssertUnwindSafe<@F>, (), @R>"]
def core.panic.unwind_safe.FnOnceAssertUnwindSafe {R F : Type}
    (inst : core.ops.function.FnOnce F Unit R) :
    core.ops.function.FnOnce (core.panic.unwind_safe.AssertUnwindSafe F) Unit R := {
  call_once := core.panic.unwind_safe.FnOnceAssertUnwindSafe.call_once inst
}

end Aeneas.Std
