import Aeneas.Std.Array.Array
import Aeneas.Std.Core.Iter

namespace Aeneas.Std

open Result

@[rust_type "core::array::iter::IntoIter" (body := .opaque)]
structure core.array.iter.IntoIter (T : Type) (N : Usize) where
  /-- Only the suffix starting at `i` is live. Retaining the backing storage
      also gives the consuming-conversion ABI a source view. Lending mutable
      items requires a separate ABI and is not implemented by this model. -/
  array : Array T N
  i : Nat := 0

@[rust_fun
  "core::array::iter::{core::iter::traits::iterator::Iterator<core::array::iter::IntoIter<@T, @N>, @T>}::next"]
def core.array.iter.IteratorIntoIter.next {T : Type} {N : Usize}
    (it : core.array.iter.IntoIter T N) :
    Result (Option T × core.array.iter.IntoIter T N) :=
  if h : it.i < it.array.val.length then
    ok (some it.array.val[it.i], { it with i := it.i + 1 })
  else ok (none, it)


@[rust_fun
  "core::array::iter::{core::iter::traits::iterator::Iterator<core::array::iter::IntoIter<@T, @N>, @T>}::size_hint"]
def core.array.iter.IteratorIntoIter.size_hint {T : Type} {N : Usize}
  (self : core.array.iter.IntoIter T N) : Result (Usize × Option Usize) :=
  let n := Usize.ofNatCore (N.val - self.i) (by scalar_tac)
  ok (n, some n)

@[rust_fun
  "core::array::iter::{core::iter::traits::iterator::Iterator<core::array::iter::IntoIter<@T, @N>, @T>}::advance_by"]
def core.array.iter.IteratorIntoIter.advance_by {T : Type} {N : Usize}
  (self : core.array.iter.IntoIter T N) (n : Usize) :
  Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) × core.array.iter.IntoIter T N) := do
  let step := min n.val (N.val - self.i)
  let self := { self with i := self.i + step }
  if h : n.val ≤ step then ok (.Ok (), self)
  else
    let left := Usize.ofNatCore (n.val - step) (by scalar_tac)
    let left ← core.num.nonzero.NonZero.new_unchecked left
    ok (.Err left, self)

@[rust_fun
  "core::array::iter::{core::iter::traits::iterator::Iterator<core::array::iter::IntoIter<@T, @N>, @T>}::fold"]
def core.array.iter.IteratorIntoIter.fold
  {T B F : Type} {N : Usize}
  (fnInst : core.ops.function.FnMut F (B × T) B)
  (self : core.array.iter.IntoIter T N) (init : B) (f : F) :
  Result (B × core.array.iter.IntoIter T N × F) :=
  core.iter.traits.iterator.foldFromNext
    core.array.iter.IteratorIntoIter.next fnInst self init f

@[rust_fun
  "core::array::iter::{core::iter::traits::iterator::Iterator<core::array::iter::IntoIter<@T, @N>, @T>}::try_fold"]
def core.array.iter.IteratorIntoIter.try_fold
  {T B F R Residual : Type} {N : Usize}
  (fnInst : core.ops.function.FnMut F (B × T) R)
  (tryInst : core.ops.try_trait.Try R B Residual)
  (self : core.array.iter.IntoIter T N) (init : B) (f : F) :
  Result (R × core.array.iter.IntoIter T N × F) :=
  core.iter.traits.iterator.tryFoldFromNext
    core.array.iter.IteratorIntoIter.next fnInst tryInst self init f
@[rust_fun
  "core::array::iter::{core::iter::traits::iterator::Iterator<core::array::iter::IntoIter<@T, @N>, @T>}::count"]
def core.array.iter.IteratorIntoIter.count {T : Type} {N : Usize}
    (it : core.array.iter.IntoIter T N) :
    Result (Usize × core.array.iter.IntoIter T N) :=
  ok (Usize.ofNatCore (N.val - it.i) (by scalar_tac), it)

@[rust_fun
  "core::array::iter::{core::iter::traits::iterator::Iterator<core::array::iter::IntoIter<@T, @N>, @T>}::any"]
def core.array.iter.IteratorIntoIter.any {T F : Type} {N : Usize}
    (fnInst : core.ops.function.FnMut F T Bool)
    (it : core.array.iter.IntoIter T N) (f : F) :
    Result (Bool × core.array.iter.IntoIter T N × F) :=
  core.iter.traits.iterator.anyFromNext core.array.iter.IteratorIntoIter.next fnInst it f

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::array::iter::IntoIter<@T, @N>, @T>"]
def core.iter.traits.iterator.IteratorArrayIntoIter (T : Type) (N : Usize) :
    core.iter.traits.iterator.Iterator (core.array.iter.IntoIter T N) T := {
  next := core.array.iter.IteratorIntoIter.next
  count := core.array.iter.IteratorIntoIter.count
  any := core.array.iter.IteratorIntoIter.any
  advance_by := core.array.iter.IteratorIntoIter.advance_by
  fold := core.array.iter.IteratorIntoIter.fold
  try_fold := core.array.iter.IteratorIntoIter.try_fold
  size_hint := core.array.iter.IteratorIntoIter.size_hint
  trusted_len := true
  one_shot := N.val ≤ 1
  fused := true
}

@[rust_fun
  "core::array::iter::{core::iter::traits::collect::IntoIterator<[@T; @N], @T, core::array::iter::IntoIter<@T, @N>>}::into_iter"]
def core.array.iter.IntoIteratorArray.into_iter {T : Type} {N : Usize}
    (array : Array T N) :
    Result (core.array.iter.IntoIter T N × (core.array.iter.IntoIter T N → Array T N)) :=
  ok (⟨array, 0⟩, fun it => it.array)

@[reducible, rust_trait_impl
  "core::iter::traits::collect::IntoIterator<[@T; @N], @T, core::array::iter::IntoIter<@T, @N>>"]
def core.iter.traits.collect.IntoIteratorArray (T : Type) (N : Usize) :
    core.iter.traits.collect.IntoIterator (Array T N) T (core.array.iter.IntoIter T N) := {
  iteratorInst := core.iter.traits.iterator.IteratorArrayIntoIter T N
  into_iter := core.array.iter.IntoIteratorArray.into_iter
  const_size := some N
}

end Aeneas.Std
