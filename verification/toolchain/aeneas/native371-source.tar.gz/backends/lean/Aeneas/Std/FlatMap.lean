import Aeneas.Std.Core.Iter

namespace Aeneas.Std

open Result

/-! `FlatMap<I, U, F>` and `Flatten<I>` (core flatten.rs, rustc 1.95) delegate every method to
    `FlattenCompat { iter: Fuse<..>, frontiter: Option<U>, backiter: Option<U> }`. The model keeps
    the outer iterator with its `Fuse` flag (`outerDone`), the front inner iterator (`inner`,
    active while `frontiter` is `Some`) and the back inner iterator (`back`, active while
    `backiter` is `Some`). An inactive slot retains the last inner state but is never polled.

    The `Iterator` methods pull from the front and the `DoubleEndedIterator` methods from the
    back with the same schedule, the roles of the two inner slots exchanged: the near inner
    first, then the outer (each converted outer item becomes the near inner), then the far inner
    (`next` on the back inner once the outer is exhausted, `next_back` on the front inner; the
    folds fold the front inner, the outer, the back inner, and the back folds the other way
    round). The model states this once over one end (`End`: `next`/`fold`/`try_fold`/`advance_by`
    from the front, `next_back`/`rfold`/`try_rfold`/`advance_back_by` from the back); the back
    methods run it on the state whose inner slots are exchanged (`swap`).

    `OneShot` inners (the `one_shot` flag of their `Iterator` dictionary: option and result
    iterators, `Once`, arrays of length at most one, and the adapters of these) select the
    specialization of both traits, which ignores `frontiter` and `backiter` and pulls each
    converted outer item once with `next` (also from the back). It never stores an inner, so the
    model's slots stay inactive for these inners; the shared code which drains them is then the
    identity, and the far inner is never pulled. -/

-- Charon lifts FlatMap's parameters as I, U, F, U::Item, U::IntoIter.
-- Only I, F and U::IntoIter occur in this non-lending representation.
structure core.iter.adapters.flatten.FlatMap (I F IntoIter : Type) where
  iter : I
  f : F
  outerDone : Bool
  inner : Option IntoIter
  innerActive : Bool
  back : Option IntoIter
  backActive : Bool

-- The inner iterators are non-lending and own no projected mutable state.
-- Their progress and the outer fusion flags belong to the original carrier.
def core.iter.adapters.flatten.FlatMap.recombine {I F IntoIter : Type}
    (mergeI : I → I → I) (mergeF : F → F → F)
    (original current : core.iter.adapters.flatten.FlatMap I F IntoIter) :
    core.iter.adapters.flatten.FlatMap I F IntoIter :=
  { original with iter := mergeI original.iter current.iter, f := mergeF original.f current.f }

attribute [rust_type "core::iter::adapters::flatten::FlatMap"
  (keepParams := [true, false, true, false, true]) (body := .opaque)
  (stateMerge := some ("Aeneas.Std.core.iter.adapters.flatten.FlatMap.recombine", [0, 2]))]
  core.iter.adapters.flatten.FlatMap

/-- The operations FlattenCompat applies to its outer iterator and to its inner iterators from
    one end: `next`, `fold`, `try_fold` and `advance_by` from the front, `next_back`, `rfold`,
    `try_rfold` and `advance_back_by` from the back. `fused` selects the `Fuse` specialization of
    the outer (`FusedIterator` iterators are not cleared when exhausted). -/
structure core.iter.adapters.flatten.End (I Item : Type) where
  pull : I → Result (Option Item × I)
  fold : {B G : Type} → core.ops.function.FnMut G (B × Item) B → I → B → G →
    Result (B × I × G)
  try_fold : {B G R Residual : Type} → core.ops.function.FnMut G (B × Item) R →
    core.ops.try_trait.Try R B Residual → I → B → G → Result (R × I × G)
  advance : I → Usize →
    Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) × I)
  fused : Bool

namespace core.iter.adapters.flatten.End

def front {I Item : Type} (it : core.iter.traits.iterator.Iterator I Item) :
    core.iter.adapters.flatten.End I Item := {
  pull := it.next
  fold := fun fnInst self init g => it.fold fnInst self init g
  try_fold := fun fnInst tryInst self init g => it.try_fold fnInst tryInst self init g
  advance := it.advance_by
  fused := it.fused
}

def back {I Item : Type} (it : core.iter.traits.double_ended.DoubleEndedIterator I Item) :
    core.iter.adapters.flatten.End I Item := {
  pull := it.next_back
  fold := fun fnInst self init g => it.rfold fnInst self init g
  try_fold := fun fnInst tryInst self init g => it.try_rfold fnInst tryInst self init g
  advance := it.advance_back_by
  fused := it.iteratorInst.fused
}

end core.iter.adapters.flatten.End

/-- Exchanges the front and back inner slots: the back methods are the front ones on the
    exchanged state. -/
def core.iter.adapters.flatten.FlatMap.swap {I F IntoIter : Type}
    (self : core.iter.adapters.flatten.FlatMap I F IntoIter) :
    core.iter.adapters.flatten.FlatMap I F IntoIter :=
  { self with inner := self.back, innerActive := self.backActive,
              back := self.inner, backActive := self.innerActive }

-- Retain exhausted receiver states for givebacks, but never poll them again.
-- The canonical FnMut/Iterator ABI does not admit lending mutable outputs: the
-- newly returned inner is owned and has no restoration obligation to the mapper.
def core.iter.adapters.flatten.FlatMap.advanceOuter
  {I U F OuterItem Item IntoIter : Type}
  (outer : core.iter.adapters.flatten.End I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (fnInst : core.ops.function.FnMut F OuterItem U)
  (self : core.iter.adapters.flatten.FlatMap I F IntoIter) :
  Result (core.iter.adapters.flatten.FlatMap I F IntoIter) := do
  if self.outerDone then return self
  let (item, iter) ← outer.pull self.iter
  match item with
  | none => ok { self with iter, outerDone := !outer.fused }
  | some item =>
    let (mapped, f) ← fnInst.call_mut self.f item
    let (inner, _) ← intoInst.into_iter mapped
    ok { self with iter, f, inner := some inner, innerActive := true }

/-- `and_then_or_clear(&mut far, pull)` once the outer is exhausted: the back inner for `next`,
    the front inner for `next_back`. `OneShot` returns `None` there. -/
def core.iter.adapters.flatten.FlatMap.pullFar
  {I U F Item IntoIter : Type}
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (inner : core.iter.adapters.flatten.End IntoIter Item)
  (self : core.iter.adapters.flatten.FlatMap I F IntoIter) :
  Result (Option Item × core.iter.adapters.flatten.FlatMap I F IntoIter) := do
  if intoInst.iteratorInst.one_shot then return (none, self)
  match (if self.backActive then self.back else none) with
  | none => ok (none, self)
  | some it =>
    let (item, it) ← inner.pull it
    ok (item, { self with back := some it, backActive := item.isSome })

/-- One pull of the active near inner `it`: `OneShot` inners are pulled once with `next` and
    not kept (the converted outer item is dropped after it). -/
def core.iter.adapters.flatten.FlatMap.pullNear
  {I U F Item IntoIter : Type}
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (inner : core.iter.adapters.flatten.End IntoIter Item)
  (self : core.iter.adapters.flatten.FlatMap I F IntoIter) (it : IntoIter) :
  Result (Option Item × core.iter.adapters.flatten.FlatMap I F IntoIter) := do
  let oneShot := intoInst.iteratorInst.one_shot
  let (item, it) ← if oneShot then intoInst.iteratorInst.next it else inner.pull it
  ok (item, { self with inner := some it, innerActive := !oneShot })

/-- `next` from one end: the near inner, then each converted outer item, then the far inner. -/
def core.iter.adapters.flatten.FlatMap.nextFrom
  {I U F OuterItem Item IntoIter : Type}
  (outer : core.iter.adapters.flatten.End I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (inner : core.iter.adapters.flatten.End IntoIter Item)
  (fnInst : core.ops.function.FnMut F OuterItem U)
  (self : core.iter.adapters.flatten.FlatMap I F IntoIter) :
  Result (Option Item × core.iter.adapters.flatten.FlatMap I F IntoIter) := do
  match (if self.innerActive then self.inner else none) with
  | some it =>
    let (item, self) ← core.iter.adapters.flatten.FlatMap.pullNear intoInst inner self it
    match item with
    | some item => ok (some item, self)
    | none =>
      core.iter.adapters.flatten.FlatMap.nextFrom outer intoInst inner fnInst
        { self with innerActive := false }
  | none =>
    if self.outerDone then core.iter.adapters.flatten.FlatMap.pullFar intoInst inner self
    else do
      let self ← core.iter.adapters.flatten.FlatMap.advanceOuter outer intoInst fnInst self
      if self.innerActive then
        core.iter.adapters.flatten.FlatMap.nextFrom outer intoInst inner fnInst self
      else core.iter.adapters.flatten.FlatMap.pullFar intoInst inner self
partial_fixpoint

@[rust_fun "core::iter::traits::iterator::Iterator::flat_map"]
def core.iter.traits.iterator.Iterator.flat_map.default
  {Self U F OuterItem Item IntoIter : Type}
  (_iterInst : core.iter.traits.iterator.Iterator Self OuterItem)
  (_intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (_fnInst : core.ops.function.FnMut F OuterItem U)
  (self : Self) (f : F) :
  Result (core.iter.adapters.flatten.FlatMap Self F IntoIter ×
    (core.iter.adapters.flatten.FlatMap Self F IntoIter → Self) ×
    (core.iter.adapters.flatten.FlatMap Self F IntoIter → F)) :=
  ok (⟨self, f, false, none, false, none, false⟩, (·.iter), (·.f))

@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause1_Item, @Clause1_IntoIter>, @Clause1_Item>}::next"]
def core.iter.adapters.flatten.IteratorFlatMap.next
  {I U F OuterItem Item IntoIter : Type}
  (iterInst : core.iter.traits.iterator.Iterator I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (fnInst : core.ops.function.FnMut F OuterItem U)
  (self : core.iter.adapters.flatten.FlatMap I F IntoIter) :
  Result (Option Item × core.iter.adapters.flatten.FlatMap I F IntoIter) :=
  core.iter.adapters.flatten.FlatMap.nextFrom (.front iterInst) intoInst
    (.front intoInst.iteratorInst) fnInst self

/-- Drains the far inner after the outer (`iter_fold`: the back inner of the front folds). -/
def core.iter.adapters.flatten.FlatMap.foldFar
  {I F IntoIter B G : Type}
  (innerFold : IntoIter → B → G → Result (B × IntoIter × G))
  (self : core.iter.adapters.flatten.FlatMap I F IntoIter) (acc : B) (g : G) :
  Result (B × core.iter.adapters.flatten.FlatMap I F IntoIter × G) := do
  match (if self.backActive then self.back else none) with
  | none => ok (acc, self, g)
  | some it =>
    let (acc, it, g) ← innerFold it acc g
    ok (acc, { self with back := some it, backActive := false }, g)

-- FlattenCompat's fold operates on entire inner iterators. Dispatch both the
-- outer fold (through Map/Fuse) and the selected inner operation; using next here
-- loses observable custom fold/count behavior and specialized clone/call order.
def core.iter.adapters.flatten.FlatMap.foldInners
  {I U F OuterItem Item IntoIter B G : Type}
  (outer : core.iter.adapters.flatten.End I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (fnInst : core.ops.function.FnMut F OuterItem U)
  (innerFold : IntoIter → B → G → Result (B × IntoIter × G))
  (self : core.iter.adapters.flatten.FlatMap I F IntoIter) (init : B) (g : G) :
  Result (B × core.iter.adapters.flatten.FlatMap I F IntoIter × G) := do
  let (init, self, g) ← match (if self.innerActive then self.inner else none) with
    | none => ok (init, self, g)
    | some inner => do
      let (init, inner, g) ← innerFold inner init g
      ok (init, { self with inner := some inner, innerActive := false }, g)
  if self.outerDone then
    return ← core.iter.adapters.flatten.FlatMap.foldFar innerFold self init g
  let call := fun (state : F × Option IntoIter × G) (input : B × OuterItem) => do
    let (mapped, f) ← fnInst.call_mut state.1 input.2
    let (inner, _) ← intoInst.into_iter mapped
    let (acc, inner, g) ← innerFold inner input.1 state.2.2
    ok (acc, (f, some inner, g))
  let foldInst : core.ops.function.FnMut (F × Option IntoIter × G) (B × OuterItem) B := {
    FnOnceInst := { call_once := call }
    call_mut := call
  }
  let (acc, iter, state) ← outer.fold foldInst self.iter init (self.f, self.inner, g)
  core.iter.adapters.flatten.FlatMap.foldFar innerFold
    { self with iter, f := state.1, inner := state.2.1, outerDone := !outer.fused,
                innerActive := false } acc state.2.2

-- The outer try_fold callback keeps the currently visited inner in its closure
-- state. A residual preserves that live inner; successful exhaustion clears its
-- active flag and fuses the outer, then folds the far inner, while retaining the
-- terminal receiver states.
def core.iter.adapters.flatten.FlatMap.tryFoldOuter
  {I U F OuterItem Item IntoIter B G R Residual : Type}
  (outer : core.iter.adapters.flatten.End I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (fnInst : core.ops.function.FnMut F OuterItem U)
  (tryInst : core.ops.try_trait.Try R B Residual)
  (innerFold : IntoIter → B → G → Result (R × IntoIter × G))
  (self : core.iter.adapters.flatten.FlatMap I F IntoIter) (init : B) (g : G) :
  Result (R × core.iter.adapters.flatten.FlatMap I F IntoIter × G) := do
  let finish := fun result (self : core.iter.adapters.flatten.FlatMap I F IntoIter) g => do
    -- OneShot directly returns Fuse::try_fold. The general implementation
    -- applies ? once more after Fuse's own ?, preserving both Try dispatches,
    -- then folds the far inner (`acc = fold(acc, iter)?`) and ends with `try { acc }`.
    if intoInst.iteratorInst.one_shot then return (result, self, g)
    match ← tryInst.branch result with
    | .Break residual =>
      let result ← tryInst.FromResidualInst.from_residual residual
      ok (result, self, g)
    | .Continue acc =>
      let self := { self with innerActive := false }
      match (if self.backActive then self.back else none) with
      | none =>
        let result ← tryInst.from_output acc
        ok (result, { self with backActive := false }, g)
      | some it =>
        let (result, it, g) ← innerFold it acc g
        let self := { self with back := some it }
        match ← tryInst.branch result with
        | .Break residual =>
          let result ← tryInst.FromResidualInst.from_residual residual
          ok (result, self, g)
        | .Continue acc =>
          let result ← tryInst.from_output acc
          ok (result, { self with backActive := false }, g)
  if self.outerDone then
    let result ← tryInst.from_output init
    return ← finish result self g
  let call := fun (state : F × Option IntoIter × Bool × G) (input : B × OuterItem) => do
    let (mapped, f) ← fnInst.call_mut state.1 input.2
    let (inner, _) ← intoInst.into_iter mapped
    let (result, inner, g) ← innerFold inner input.1 state.2.2.2
    ok (result, (f, some inner, !intoInst.iteratorInst.one_shot, g))
  let foldInst : core.ops.function.FnMut
      (F × Option IntoIter × Bool × G) (B × OuterItem) R := {
    FnOnceInst := { call_once := call }
    call_mut := call
  }
  let (result, iter, state) ← outer.try_fold foldInst tryInst self.iter init
    (self.f, self.inner, false, g)
  let self := { self with iter, f := state.1, inner := state.2.1, innerActive := state.2.2.1 }
  match ← tryInst.branch result with
  | .Break residual =>
    let result ← tryInst.FromResidualInst.from_residual residual
    finish result self state.2.2.2
  | .Continue acc =>
    let result ← tryInst.from_output acc
    finish result { self with outerDone := !outer.fused } state.2.2.2

def core.iter.adapters.flatten.FlatMap.tryFoldInners
  {I U F OuterItem Item IntoIter B G R Residual : Type}
  (outer : core.iter.adapters.flatten.End I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (fnInst : core.ops.function.FnMut F OuterItem U)
  (tryInst : core.ops.try_trait.Try R B Residual)
  (innerFold : IntoIter → B → G → Result (R × IntoIter × G))
  (self : core.iter.adapters.flatten.FlatMap I F IntoIter) (init : B) (g : G) :
  Result (R × core.iter.adapters.flatten.FlatMap I F IntoIter × G) := do
  match (if self.innerActive then self.inner else none) with
  | none =>
    core.iter.adapters.flatten.FlatMap.tryFoldOuter
      outer intoInst fnInst tryInst innerFold self init g
  | some inner =>
    let (result, inner, g) ← innerFold inner init g
    let self := { self with inner := some inner }
    match ← tryInst.branch result with
    | .Break residual =>
      let result ← tryInst.FromResidualInst.from_residual residual
      ok (result, self, g)
    | .Continue acc =>
      core.iter.adapters.flatten.FlatMap.tryFoldOuter outer intoInst fnInst tryInst
        innerFold { self with innerActive := false } acc g

/-- `fold` from one end: `iter_fold` with the inner fold of that end, or the `OneShot`
    `flatten_one` (one `next` per converted outer item). -/
def core.iter.adapters.flatten.FlatMap.foldFrom
  {I U F B G OuterItem Item IntoIter : Type}
  (outer : core.iter.adapters.flatten.End I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (inner : core.iter.adapters.flatten.End IntoIter Item)
  (fnInst : core.ops.function.FnMut F OuterItem U)
  (foldInst : core.ops.function.FnMut G (B × Item) B)
  (self : core.iter.adapters.flatten.FlatMap I F IntoIter) (init : B) (g : G) :
  Result (B × core.iter.adapters.flatten.FlatMap I F IntoIter × G) :=
  core.iter.adapters.flatten.FlatMap.foldInners outer intoInst fnInst
    (fun it acc g => do
      if !intoInst.iteratorInst.one_shot then
        return ← inner.fold foldInst it acc g
      let (item, it) ← intoInst.iteratorInst.next it
      match item with
      | none => ok (acc, it, g)
      | some item =>
        let (acc, g) ← foldInst.call_mut g (acc, item)
        ok (acc, it, g)) self init g

/-- `try_fold` from one end: `iter_try_fold` with the inner `try_fold` of that end, or the
    `OneShot` `try_flatten_one`. -/
def core.iter.adapters.flatten.FlatMap.tryFoldFrom
  {I U F B G R OuterItem Item IntoIter Residual : Type}
  (outer : core.iter.adapters.flatten.End I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (inner : core.iter.adapters.flatten.End IntoIter Item)
  (fnInst : core.ops.function.FnMut F OuterItem U)
  (foldInst : core.ops.function.FnMut G (B × Item) R)
  (tryInst : core.ops.try_trait.Try R B Residual)
  (self : core.iter.adapters.flatten.FlatMap I F IntoIter) (init : B) (g : G) :
  Result (R × core.iter.adapters.flatten.FlatMap I F IntoIter × G) :=
  core.iter.adapters.flatten.FlatMap.tryFoldInners outer intoInst fnInst tryInst
    (fun it acc g => do
      if !intoInst.iteratorInst.one_shot then
        return ← inner.try_fold foldInst tryInst it acc g
      let (item, it) ← intoInst.iteratorInst.next it
      match item with
      | none =>
        let result ← tryInst.from_output acc
        ok (result, it, g)
      | some item =>
        let (result, g) ← foldInst.call_mut g (acc, item)
        ok (result, it, g)) self init g

private def flatMapAdvanceTry :
  core.ops.try_trait.Try (core.ops.control_flow.ControlFlow Unit Usize) Usize Unit := {
  FromResidualInst := { from_residual := fun value => ok (.Break value) }
  from_output := fun value => ok (.Continue value)
  branch := fun value => ok value
}

/-- `advance_by` from one end: `iter_try_fold` with the inner `advance_by` of that end, or the
    `OneShot` `advance_by_one` (`advance_by(0)` delegates to `Fuse`, whose inherited default
    returns at once). -/
def core.iter.adapters.flatten.FlatMap.advanceFrom
  {I U F OuterItem Item IntoIter : Type}
  (outer : core.iter.adapters.flatten.End I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (inner : core.iter.adapters.flatten.End IntoIter Item)
  (fnInst : core.ops.function.FnMut F OuterItem U)
  (self : core.iter.adapters.flatten.FlatMap I F IntoIter) (n : Usize) :
  Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) ×
    core.iter.adapters.flatten.FlatMap I F IntoIter) := do
  if intoInst.iteratorInst.one_shot && n.val == 0 then return (.Ok (), self)
  let (result, self, _) ← core.iter.adapters.flatten.FlatMap.tryFoldInners
    outer intoInst fnInst flatMapAdvanceTry
    (fun it remaining (_ : Unit) => do
      if intoInst.iteratorInst.one_shot then
        let (item, it) ← intoInst.iteratorInst.next it
        match item with
        | none => return (.Continue remaining, it, ())
        | some _ =>
          let remaining ← remaining - 1#usize
          if remaining.val == 0 then return (.Break (), it, ())
          else return (.Continue remaining, it, ())
      let (result, it) ← inner.advance it remaining
      match result with
      | .Ok _ => ok (.Break (), it, ())
      | .Err remaining => ok (.Continue remaining.val, it, ())) self n ()
  match result with
  | .Break _ => ok (.Ok (), self)
  | .Continue remaining =>
    let remaining ← core.num.nonzero.NonZero.new remaining
    match remaining with
    | none => ok (.Ok (), self)
    | some remaining => ok (.Err remaining, self)

@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause1_Item, @Clause1_IntoIter>, @Clause1_Item>}::fold"]
def core.iter.adapters.flatten.IteratorFlatMap.fold
  {I U F B G OuterItem Item IntoIter : Type}
  (iterInst : core.iter.traits.iterator.Iterator I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (fnInst : core.ops.function.FnMut F OuterItem U)
  (foldInst : core.ops.function.FnMut G (B × Item) B)
  (self : core.iter.adapters.flatten.FlatMap I F IntoIter) (init : B) (g : G) :
  Result (B × core.iter.adapters.flatten.FlatMap I F IntoIter × G) :=
  core.iter.adapters.flatten.FlatMap.foldFrom (.front iterInst) intoInst
    (.front intoInst.iteratorInst) fnInst foldInst self init g

@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause1_Item, @Clause1_IntoIter>, @Clause1_Item>}::try_fold"]
def core.iter.adapters.flatten.IteratorFlatMap.try_fold
  {I U F B G R OuterItem Item IntoIter Residual : Type}
  (iterInst : core.iter.traits.iterator.Iterator I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (fnInst : core.ops.function.FnMut F OuterItem U)
  (foldInst : core.ops.function.FnMut G (B × Item) R)
  (tryInst : core.ops.try_trait.Try R B Residual)
  (self : core.iter.adapters.flatten.FlatMap I F IntoIter) (init : B) (g : G) :
  Result (R × core.iter.adapters.flatten.FlatMap I F IntoIter × G) :=
  core.iter.adapters.flatten.FlatMap.tryFoldFrom (.front iterInst) intoInst
    (.front intoInst.iteratorInst) fnInst foldInst tryInst self init g

@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause1_Item, @Clause1_IntoIter>, @Clause1_Item>}::count"]
def core.iter.adapters.flatten.IteratorFlatMap.count
  {I U F OuterItem Item IntoIter : Type}
  (iterInst : core.iter.traits.iterator.Iterator I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (fnInst : core.ops.function.FnMut F OuterItem U)
  (self : core.iter.adapters.flatten.FlatMap I F IntoIter) :
  Result (Usize × core.iter.adapters.flatten.FlatMap I F IntoIter) := do
  let (count, self, _) ← core.iter.adapters.flatten.FlatMap.foldInners (.front iterInst)
    intoInst fnInst
    (fun inner total (_ : Unit) => do
      let (count, inner) ← if intoInst.iteratorInst.one_shot then do
          let (item, inner) ← intoInst.iteratorInst.next inner
          ok ((if item.isSome then 1#usize else 0#usize), inner)
        else intoInst.iteratorInst.count inner
      let total ← total + count
      ok (total, inner, ())) self 0#usize ()
  ok (count, self)

@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause1_Item, @Clause1_IntoIter>, @Clause1_Item>}::any"]
def core.iter.adapters.flatten.IteratorFlatMap.any
  {I U F G OuterItem Item IntoIter : Type}
  (iterInst : core.iter.traits.iterator.Iterator I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (fnInst : core.ops.function.FnMut F OuterItem U)
  (predInst : core.ops.function.FnMut G Item Bool)
  (self : core.iter.adapters.flatten.FlatMap I F IntoIter) (predicate : G) :
  Result (Bool × core.iter.adapters.flatten.FlatMap I F IntoIter × G) :=
  core.iter.traits.iterator.anyFromTryFold
    (fun {B G R Residual} => core.iter.adapters.flatten.IteratorFlatMap.try_fold
      (B := B) (G := G) (R := R) (Residual := Residual) iterInst intoInst fnInst)
    predInst self predicate

@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause1_Item, @Clause1_IntoIter>, @Clause1_Item>}::advance_by"]
def core.iter.adapters.flatten.IteratorFlatMap.advance_by
  {I U F OuterItem Item IntoIter : Type}
  (iterInst : core.iter.traits.iterator.Iterator I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (fnInst : core.ops.function.FnMut F OuterItem U)
  (self : core.iter.adapters.flatten.FlatMap I F IntoIter) (n : Usize) :
  Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) ×
    core.iter.adapters.flatten.FlatMap I F IntoIter) :=
  core.iter.adapters.flatten.FlatMap.advanceFrom (.front iterInst) intoInst
    (.front intoInst.iteratorInst) fnInst self n

@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause1_Item, @Clause1_IntoIter>, @Clause1_Item>}::nth"]
def core.iter.adapters.flatten.IteratorFlatMap.nth
  {I U F OuterItem Item IntoIter : Type}
  (iterInst : core.iter.traits.iterator.Iterator I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (fnInst : core.ops.function.FnMut F OuterItem U)
  (self : core.iter.adapters.flatten.FlatMap I F IntoIter) (n : Usize) :
  Result (Option Item × core.iter.adapters.flatten.FlatMap I F IntoIter) := do
  let (result, self) ← core.iter.adapters.flatten.IteratorFlatMap.advance_by
    iterInst intoInst fnInst self n
  match result with
  | .Err _ => ok (none, self)
  | .Ok _ => core.iter.adapters.flatten.IteratorFlatMap.next iterInst intoInst fnInst self

private def flatMapSaturatingSize (n : Nat) : Usize :=
  Usize.ofNatCore (min n Usize.max)
    (Nat.lt_of_le_of_lt (Nat.min_le_right _ _) (by simp [Usize.max, Usize.numBits]))

/-- `size_hint`: the hints of the front and back inners and of the outer; a constant-size inner
    (`ConstSizeIntoIterator`) bounds the outer's items, otherwise the upper bound exists only once
    the outer is exhausted. `OneShot`: the outer's hint, scaled by a constant size of 0 or 1. -/
@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause1_Item, @Clause1_IntoIter>, @Clause1_Item>}::size_hint"]
def core.iter.adapters.flatten.IteratorFlatMap.size_hint
  {I U F OuterItem Item IntoIter : Type}
  (iterInst : core.iter.traits.iterator.Iterator I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (_fnInst : core.ops.function.FnMut F OuterItem U)
  (self : core.iter.adapters.flatten.FlatMap I F IntoIter) :
  Result (Usize × Option Usize) := do
  if intoInst.iteratorInst.one_shot then
    let (outerLo, outerHi) ← if self.outerDone then ok (0#usize, some 0#usize)
      else iterInst.size_hint self.iter
    match intoInst.const_size with
    | some size =>
      if size.val == 0 then return (0#usize, some 0#usize)
      if size.val == 1 then return (outerLo, outerHi)
      return (0#usize, outerHi)
    | none => return (0#usize, outerHi)
  let (frontLo, frontHi) ← match (if self.innerActive then self.inner else none) with
    | none => ok (0#usize, some 0#usize)
    | some inner => intoInst.iteratorInst.size_hint inner
  let (backLo, backHi) ← match (if self.backActive then self.back else none) with
    | none => ok (0#usize, some 0#usize)
    | some back => intoInst.iteratorInst.size_hint back
  let lo := flatMapSaturatingSize (frontLo.val + backLo.val)
  let (outerLo, outerHi) ← if self.outerDone then ok (0#usize, some 0#usize)
    else iterInst.size_hint self.iter
  match intoInst.const_size with
  | some size =>
    let lower := flatMapSaturatingSize (outerLo.val * size.val + lo.val)
    let upper := do
      let front ← frontHi
      let back ← backHi
      let inners ← Usize.checked_add front back
      let outer ← outerHi
      let outer ← Usize.checked_mul size outer
      Usize.checked_add inners outer
    ok (lower, upper)
  | none =>
    match frontHi, backHi with
    | some front, some back =>
      if outerLo.val == 0 && outerHi == some 0#usize then ok (lo, Usize.checked_add front back)
      else ok (lo, none)
    | _, _ => ok (lo, none)

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause1_Item, @Clause1_IntoIter>, @Clause1_Item>"]
def core.iter.traits.iterator.IteratorFlatMap
  {I U F OuterItem Item IntoIter : Type}
  (iterInst : core.iter.traits.iterator.Iterator I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (fnInst : core.ops.function.FnMut F OuterItem U) :
  core.iter.traits.iterator.Iterator
    (core.iter.adapters.flatten.FlatMap I F IntoIter) Item := {
  next := core.iter.adapters.flatten.IteratorFlatMap.next iterInst intoInst fnInst
  advance_by := core.iter.adapters.flatten.IteratorFlatMap.advance_by iterInst intoInst fnInst
  nth := core.iter.adapters.flatten.IteratorFlatMap.nth iterInst intoInst fnInst
  fold := core.iter.adapters.flatten.IteratorFlatMap.fold iterInst intoInst fnInst
  try_fold := core.iter.adapters.flatten.IteratorFlatMap.try_fold iterInst intoInst fnInst
  count := core.iter.adapters.flatten.IteratorFlatMap.count iterInst intoInst fnInst
  any := core.iter.adapters.flatten.IteratorFlatMap.any iterInst intoInst fnInst
  size_hint := core.iter.adapters.flatten.IteratorFlatMap.size_hint iterInst intoInst fnInst
  trusted_len := iterInst.trusted_len && intoInst.const_size.isSome
  fused := iterInst.fused
}

/-- `FlatMap`'s inherited `Iterator::max` over the flattened items. -/
@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause1_Item, @Clause1_IntoIter>, @Clause1_Item>}::max"]
def core.iter.adapters.flatten.IteratorFlatMap.max
    {I U F OuterItem Item IntoIter : Type}
    (iterInst : core.iter.traits.iterator.Iterator I OuterItem)
    (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
    (fnInst : core.ops.function.FnMut F OuterItem U) (ordInst : core.cmp.Ord Item)
    (self : core.iter.adapters.flatten.FlatMap I F IntoIter) :
    Result (Option Item × core.iter.adapters.flatten.FlatMap I F IntoIter) :=
  core.iter.traits.iterator.Iterator.max.default
    (core.iter.traits.iterator.IteratorFlatMap iterInst intoInst fnInst) ordInst self

/-! `DoubleEndedIterator for FlatMap<I, U, F>` (core flatten.rs, rustc 1.95), for
    `I: DoubleEndedIterator`, `F: FnMut(I::Item) -> U` and `U::IntoIter: DoubleEndedIterator`:
    `next_back`, `try_rfold`, `rfold` and `advance_back_by` are FlattenCompat's, the front
    methods from the back (`Map::next_back`/`rfold`/`try_rfold` map the outer's items from the
    back); `nth_back` and `rfind` are the trait's defaults. The clauses are the outer's
    `DoubleEndedIterator`, the mapper, `U: IntoIterator` and the inner's
    `DoubleEndedIterator`. -/

@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause2_Item, @Clause2_IntoIter>, @Clause2_Item>}::next_back"]
def core.iter.adapters.flatten.DoubleEndedIteratorFlatMap.next_back
  {I U F OuterItem Item IntoIter : Type}
  (iterInst : core.iter.traits.double_ended.DoubleEndedIterator I OuterItem)
  (fnInst : core.ops.function.FnMut F OuterItem U)
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (innerInst : core.iter.traits.double_ended.DoubleEndedIterator IntoIter Item)
  (self : core.iter.adapters.flatten.FlatMap I F IntoIter) :
  Result (Option Item × core.iter.adapters.flatten.FlatMap I F IntoIter) := do
  let (item, self) ← core.iter.adapters.flatten.FlatMap.nextFrom (.back iterInst) intoInst
    (.back innerInst) fnInst self.swap
  ok (item, self.swap)

@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause2_Item, @Clause2_IntoIter>, @Clause2_Item>}::rfold"]
def core.iter.adapters.flatten.DoubleEndedIteratorFlatMap.rfold
  {I U F B G OuterItem Item IntoIter : Type}
  (iterInst : core.iter.traits.double_ended.DoubleEndedIterator I OuterItem)
  (fnInst : core.ops.function.FnMut F OuterItem U)
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (innerInst : core.iter.traits.double_ended.DoubleEndedIterator IntoIter Item)
  (foldInst : core.ops.function.FnMut G (B × Item) B)
  (self : core.iter.adapters.flatten.FlatMap I F IntoIter) (init : B) (g : G) :
  Result (B × core.iter.adapters.flatten.FlatMap I F IntoIter × G) := do
  let (acc, self, g) ← core.iter.adapters.flatten.FlatMap.foldFrom (.back iterInst) intoInst
    (.back innerInst) fnInst foldInst self.swap init g
  ok (acc, self.swap, g)

@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause2_Item, @Clause2_IntoIter>, @Clause2_Item>}::try_rfold"]
def core.iter.adapters.flatten.DoubleEndedIteratorFlatMap.try_rfold
  {I U F B G R OuterItem Item IntoIter Residual : Type}
  (iterInst : core.iter.traits.double_ended.DoubleEndedIterator I OuterItem)
  (fnInst : core.ops.function.FnMut F OuterItem U)
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (innerInst : core.iter.traits.double_ended.DoubleEndedIterator IntoIter Item)
  (foldInst : core.ops.function.FnMut G (B × Item) R)
  (tryInst : core.ops.try_trait.Try R B Residual)
  (self : core.iter.adapters.flatten.FlatMap I F IntoIter) (init : B) (g : G) :
  Result (R × core.iter.adapters.flatten.FlatMap I F IntoIter × G) := do
  let (result, self, g) ← core.iter.adapters.flatten.FlatMap.tryFoldFrom (.back iterInst)
    intoInst (.back innerInst) fnInst foldInst tryInst self.swap init g
  ok (result, self.swap, g)

@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause2_Item, @Clause2_IntoIter>, @Clause2_Item>}::advance_back_by"]
def core.iter.adapters.flatten.DoubleEndedIteratorFlatMap.advance_back_by
  {I U F OuterItem Item IntoIter : Type}
  (iterInst : core.iter.traits.double_ended.DoubleEndedIterator I OuterItem)
  (fnInst : core.ops.function.FnMut F OuterItem U)
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (innerInst : core.iter.traits.double_ended.DoubleEndedIterator IntoIter Item)
  (self : core.iter.adapters.flatten.FlatMap I F IntoIter) (n : Usize) :
  Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) ×
    core.iter.adapters.flatten.FlatMap I F IntoIter) := do
  let (result, self) ← core.iter.adapters.flatten.FlatMap.advanceFrom (.back iterInst) intoInst
    (.back innerInst) fnInst self.swap n
  ok (result, self.swap)

@[reducible, rust_trait_impl
  "core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::flatten::FlatMap<@I, @U, @F, @Clause2_Item, @Clause2_IntoIter>, @Clause2_Item>"]
def core.iter.traits.double_ended.DoubleEndedIteratorFlatMap
  {I U F OuterItem Item IntoIter : Type}
  (iterInst : core.iter.traits.double_ended.DoubleEndedIterator I OuterItem)
  (fnInst : core.ops.function.FnMut F OuterItem U)
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (innerInst : core.iter.traits.double_ended.DoubleEndedIterator IntoIter Item) :
  core.iter.traits.double_ended.DoubleEndedIterator
    (core.iter.adapters.flatten.FlatMap I F IntoIter) Item := {
  iteratorInst := core.iter.traits.iterator.IteratorFlatMap iterInst.iteratorInst intoInst fnInst
  next_back :=
    core.iter.adapters.flatten.DoubleEndedIteratorFlatMap.next_back iterInst fnInst intoInst
      innerInst
  advance_back_by :=
    core.iter.adapters.flatten.DoubleEndedIteratorFlatMap.advance_back_by iterInst fnInst
      intoInst innerInst
  rfold :=
    core.iter.adapters.flatten.DoubleEndedIteratorFlatMap.rfold iterInst fnInst intoInst innerInst
  try_rfold :=
    core.iter.adapters.flatten.DoubleEndedIteratorFlatMap.try_rfold iterInst fnInst intoInst
      innerInst
}

/-! `Flatten<I> { inner: FlattenCompat<I, <I::Item as IntoIterator>::IntoIter> }`
    and `FlatMap<I, U, F> { inner: FlattenCompat<Map<I, F>, U::IntoIter> }`
    (core flatten.rs, rustc 1.95) delegate every method to the same
    FlattenCompat, whose outer is `Fuse<I>` for Flatten and `Fuse<Map<I, F>>` for
    FlatMap. FlattenCompat calls on its outer only `next`, `size_hint`, `fold`,
    `try_fold`, their back counterparts `next_back`, `rfold` and `try_rfold`, and,
    in the OneShot `advance_by(0)`/`advance_back_by(0)`, `advance_by`/`advance_back_by`,
    which neither `Fuse` nor `Map` overrides (the inherited defaults return at once
    for 0); `Map` forwards `next`, `size_hint`, `fold`, `try_fold` and the back
    ones to `I` with `f` applied to each item, and is `FusedIterator` exactly when
    `I` is. So `Flatten<I>` is observationally `FlatMap<I, I::Item, id>`: the
    model runs the FlatMap model of both traits (general and
    OneShot/ConstSizeIntoIterator specializations, including its `size_hint`)
    with an identity mapper whose state is `Unit`. -/

-- Charon lifts Flatten's parameters as I, I::Item, <I::Item as IntoIterator>::Item,
-- and the inner IntoIter. Only I and IntoIter occur in this representation.
structure core.iter.adapters.flatten.Flatten (I IntoIter : Type) where
  iter : I
  outerDone : Bool
  inner : Option IntoIter
  innerActive : Bool
  back : Option IntoIter
  backActive : Bool

def core.iter.adapters.flatten.Flatten.recombine {I IntoIter : Type}
    (mergeI : I → I → I)
    (original current : core.iter.adapters.flatten.Flatten I IntoIter) :
    core.iter.adapters.flatten.Flatten I IntoIter :=
  { original with iter := mergeI original.iter current.iter }

attribute [rust_type "core::iter::adapters::flatten::Flatten"
  (keepParams := [true, false, false, true]) (body := .opaque)
  (stateMerge := some ("Aeneas.Std.core.iter.adapters.flatten.Flatten.recombine", [0]))]
  core.iter.adapters.flatten.Flatten

namespace core.iter.adapters.flatten.Flatten

def toFlatMap {I IntoIter : Type} (self : core.iter.adapters.flatten.Flatten I IntoIter) :
    core.iter.adapters.flatten.FlatMap I Unit IntoIter :=
  ⟨self.iter, (), self.outerDone, self.inner, self.innerActive, self.back, self.backActive⟩

def ofFlatMap {I IntoIter : Type} (self : core.iter.adapters.flatten.FlatMap I Unit IntoIter) :
    core.iter.adapters.flatten.Flatten I IntoIter :=
  ⟨self.iter, self.outerDone, self.inner, self.innerActive, self.back, self.backActive⟩

/-- The mapper of `Map<I, id>`: returns its argument, no state. -/
def identity (T : Type) : core.ops.function.FnMut Unit T T := {
  FnOnceInst := { call_once := fun _ item => ok (item, ()) }
  call_mut := fun _ item => ok (item, ())
}

end core.iter.adapters.flatten.Flatten

-- Lifted Rust parameters: Self, Self::Item, and the item and iterator of its
-- IntoIterator. The outer iterator is restored from the adapter's final state.
@[rust_fun "core::iter::traits::iterator::Iterator::flatten"]
def core.iter.traits.iterator.Iterator.flatten.default
  {Self OuterItem Item IntoIter : Type}
  (_iterInst : core.iter.traits.iterator.Iterator Self OuterItem)
  (_intoInst : core.iter.traits.collect.IntoIterator OuterItem Item IntoIter)
  (self : Self) :
  Result (core.iter.adapters.flatten.Flatten Self IntoIter ×
    (core.iter.adapters.flatten.Flatten Self IntoIter → Self)) :=
  ok (⟨self, false, none, false, none, false⟩, (·.iter))

@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Item, @Clause2_Item, @U>, @Clause2_Item>}::next"]
def core.iter.adapters.flatten.IteratorFlatten.next
  {I U OuterItem Item : Type}
  (iterInst : core.iter.traits.iterator.Iterator I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator OuterItem Item U)
  (_innerInst : core.iter.traits.iterator.Iterator U Item)
  (self : core.iter.adapters.flatten.Flatten I U) :
  Result (Option Item × core.iter.adapters.flatten.Flatten I U) := do
  let (item, self) ← core.iter.adapters.flatten.IteratorFlatMap.next iterInst intoInst
    (core.iter.adapters.flatten.Flatten.identity OuterItem) self.toFlatMap
  ok (item, core.iter.adapters.flatten.Flatten.ofFlatMap self)

@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Item, @Clause2_Item, @U>, @Clause2_Item>}::size_hint"]
def core.iter.adapters.flatten.IteratorFlatten.size_hint
  {I U OuterItem Item : Type}
  (iterInst : core.iter.traits.iterator.Iterator I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator OuterItem Item U)
  (_innerInst : core.iter.traits.iterator.Iterator U Item)
  (self : core.iter.adapters.flatten.Flatten I U) :
  Result (Usize × Option Usize) :=
  core.iter.adapters.flatten.IteratorFlatMap.size_hint iterInst intoInst
    (core.iter.adapters.flatten.Flatten.identity OuterItem) self.toFlatMap

@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Item, @Clause2_Item, @U>, @Clause2_Item>}::fold"]
def core.iter.adapters.flatten.IteratorFlatten.fold
  {I U B G OuterItem Item : Type}
  (iterInst : core.iter.traits.iterator.Iterator I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator OuterItem Item U)
  (_innerInst : core.iter.traits.iterator.Iterator U Item)
  (foldInst : core.ops.function.FnMut G (B × Item) B)
  (self : core.iter.adapters.flatten.Flatten I U) (init : B) (g : G) :
  Result (B × core.iter.adapters.flatten.Flatten I U × G) := do
  let (acc, self, g) ← core.iter.adapters.flatten.IteratorFlatMap.fold iterInst intoInst
    (core.iter.adapters.flatten.Flatten.identity OuterItem) foldInst self.toFlatMap init g
  ok (acc, core.iter.adapters.flatten.Flatten.ofFlatMap self, g)

@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Item, @Clause2_Item, @U>, @Clause2_Item>}::try_fold"]
def core.iter.adapters.flatten.IteratorFlatten.try_fold
  {I U B G R OuterItem Item Residual : Type}
  (iterInst : core.iter.traits.iterator.Iterator I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator OuterItem Item U)
  (_innerInst : core.iter.traits.iterator.Iterator U Item)
  (foldInst : core.ops.function.FnMut G (B × Item) R)
  (tryInst : core.ops.try_trait.Try R B Residual)
  (self : core.iter.adapters.flatten.Flatten I U) (init : B) (g : G) :
  Result (R × core.iter.adapters.flatten.Flatten I U × G) := do
  let (result, self, g) ← core.iter.adapters.flatten.IteratorFlatMap.try_fold iterInst
    intoInst (core.iter.adapters.flatten.Flatten.identity OuterItem) foldInst tryInst
    self.toFlatMap init g
  ok (result, core.iter.adapters.flatten.Flatten.ofFlatMap self, g)

@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Item, @Clause2_Item, @U>, @Clause2_Item>}::count"]
def core.iter.adapters.flatten.IteratorFlatten.count
  {I U OuterItem Item : Type}
  (iterInst : core.iter.traits.iterator.Iterator I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator OuterItem Item U)
  (_innerInst : core.iter.traits.iterator.Iterator U Item)
  (self : core.iter.adapters.flatten.Flatten I U) :
  Result (Usize × core.iter.adapters.flatten.Flatten I U) := do
  let (count, self) ← core.iter.adapters.flatten.IteratorFlatMap.count iterInst intoInst
    (core.iter.adapters.flatten.Flatten.identity OuterItem) self.toFlatMap
  ok (count, core.iter.adapters.flatten.Flatten.ofFlatMap self)

@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Item, @Clause2_Item, @U>, @Clause2_Item>}::advance_by"]
def core.iter.adapters.flatten.IteratorFlatten.advance_by
  {I U OuterItem Item : Type}
  (iterInst : core.iter.traits.iterator.Iterator I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator OuterItem Item U)
  (_innerInst : core.iter.traits.iterator.Iterator U Item)
  (self : core.iter.adapters.flatten.Flatten I U) (n : Usize) :
  Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) ×
    core.iter.adapters.flatten.Flatten I U) := do
  let (result, self) ← core.iter.adapters.flatten.IteratorFlatMap.advance_by iterInst intoInst
    (core.iter.adapters.flatten.Flatten.identity OuterItem) self.toFlatMap n
  ok (result, core.iter.adapters.flatten.Flatten.ofFlatMap self)

@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Item, @Clause2_Item, @U>, @Clause2_Item>}::nth"]
def core.iter.adapters.flatten.IteratorFlatten.nth
  {I U OuterItem Item : Type}
  (iterInst : core.iter.traits.iterator.Iterator I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator OuterItem Item U)
  (innerInst : core.iter.traits.iterator.Iterator U Item)
  (self : core.iter.adapters.flatten.Flatten I U) (n : Usize) :
  Result (Option Item × core.iter.adapters.flatten.Flatten I U) := do
  let (result, self) ←
    core.iter.adapters.flatten.IteratorFlatten.advance_by iterInst intoInst innerInst self n
  match result with
  | .Err _ => ok (none, self)
  | .Ok _ => core.iter.adapters.flatten.IteratorFlatten.next iterInst intoInst innerInst self

@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Item, @Clause2_Item, @U>, @Clause2_Item>}::any"]
def core.iter.adapters.flatten.IteratorFlatten.any
  {I U G OuterItem Item : Type}
  (iterInst : core.iter.traits.iterator.Iterator I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator OuterItem Item U)
  (innerInst : core.iter.traits.iterator.Iterator U Item)
  (predInst : core.ops.function.FnMut G Item Bool)
  (self : core.iter.adapters.flatten.Flatten I U) (predicate : G) :
  Result (Bool × core.iter.adapters.flatten.Flatten I U × G) :=
  core.iter.traits.iterator.anyFromTryFold
    (fun {B G R Residual} => core.iter.adapters.flatten.IteratorFlatten.try_fold
      (B := B) (G := G) (R := R) (Residual := Residual) iterInst intoInst innerInst)
    predInst self predicate

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Item, @Clause2_Item, @U>, @Clause2_Item>"]
def core.iter.traits.iterator.IteratorFlatten
  {I U OuterItem Item : Type}
  (iterInst : core.iter.traits.iterator.Iterator I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator OuterItem Item U)
  (innerInst : core.iter.traits.iterator.Iterator U Item) :
  core.iter.traits.iterator.Iterator (core.iter.adapters.flatten.Flatten I U) Item := {
  next := core.iter.adapters.flatten.IteratorFlatten.next iterInst intoInst innerInst
  advance_by := core.iter.adapters.flatten.IteratorFlatten.advance_by iterInst intoInst innerInst
  nth := core.iter.adapters.flatten.IteratorFlatten.nth iterInst intoInst innerInst
  fold := core.iter.adapters.flatten.IteratorFlatten.fold iterInst intoInst innerInst
  try_fold := core.iter.adapters.flatten.IteratorFlatten.try_fold iterInst intoInst innerInst
  count := core.iter.adapters.flatten.IteratorFlatten.count iterInst intoInst innerInst
  any := core.iter.adapters.flatten.IteratorFlatten.any iterInst intoInst innerInst
  size_hint := core.iter.adapters.flatten.IteratorFlatten.size_hint iterInst intoInst innerInst
  trusted_len := iterInst.trusted_len && intoInst.const_size.isSome
  fused := iterInst.fused
}

/-! `DoubleEndedIterator for Flatten<I>` (core flatten.rs, rustc 1.95), for
    `I: DoubleEndedIterator` whose items convert into a `DoubleEndedIterator` `U`: the FlatMap
    model of the trait with the identity mapper. The clauses are the outer's
    `DoubleEndedIterator`, the outer item's `IntoIterator` and the inner's
    `DoubleEndedIterator`. -/

@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Clause0_Item, @Clause2_Clause0_Item, @U>, @Clause2_Clause0_Item>}::next_back"]
def core.iter.adapters.flatten.DoubleEndedIteratorFlatten.next_back
  {I U OuterItem Item : Type}
  (iterInst : core.iter.traits.double_ended.DoubleEndedIterator I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator OuterItem Item U)
  (innerInst : core.iter.traits.double_ended.DoubleEndedIterator U Item)
  (self : core.iter.adapters.flatten.Flatten I U) :
  Result (Option Item × core.iter.adapters.flatten.Flatten I U) := do
  let (item, self) ← core.iter.adapters.flatten.DoubleEndedIteratorFlatMap.next_back iterInst
    (core.iter.adapters.flatten.Flatten.identity OuterItem) intoInst innerInst self.toFlatMap
  ok (item, core.iter.adapters.flatten.Flatten.ofFlatMap self)

@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Clause0_Item, @Clause2_Clause0_Item, @U>, @Clause2_Clause0_Item>}::rfold"]
def core.iter.adapters.flatten.DoubleEndedIteratorFlatten.rfold
  {I U B G OuterItem Item : Type}
  (iterInst : core.iter.traits.double_ended.DoubleEndedIterator I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator OuterItem Item U)
  (innerInst : core.iter.traits.double_ended.DoubleEndedIterator U Item)
  (foldInst : core.ops.function.FnMut G (B × Item) B)
  (self : core.iter.adapters.flatten.Flatten I U) (init : B) (g : G) :
  Result (B × core.iter.adapters.flatten.Flatten I U × G) := do
  let (acc, self, g) ← core.iter.adapters.flatten.DoubleEndedIteratorFlatMap.rfold iterInst
    (core.iter.adapters.flatten.Flatten.identity OuterItem) intoInst innerInst foldInst
    self.toFlatMap init g
  ok (acc, core.iter.adapters.flatten.Flatten.ofFlatMap self, g)

@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Clause0_Item, @Clause2_Clause0_Item, @U>, @Clause2_Clause0_Item>}::try_rfold"]
def core.iter.adapters.flatten.DoubleEndedIteratorFlatten.try_rfold
  {I U B G R OuterItem Item Residual : Type}
  (iterInst : core.iter.traits.double_ended.DoubleEndedIterator I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator OuterItem Item U)
  (innerInst : core.iter.traits.double_ended.DoubleEndedIterator U Item)
  (foldInst : core.ops.function.FnMut G (B × Item) R)
  (tryInst : core.ops.try_trait.Try R B Residual)
  (self : core.iter.adapters.flatten.Flatten I U) (init : B) (g : G) :
  Result (R × core.iter.adapters.flatten.Flatten I U × G) := do
  let (result, self, g) ← core.iter.adapters.flatten.DoubleEndedIteratorFlatMap.try_rfold
    iterInst (core.iter.adapters.flatten.Flatten.identity OuterItem) intoInst innerInst foldInst
    tryInst self.toFlatMap init g
  ok (result, core.iter.adapters.flatten.Flatten.ofFlatMap self, g)

@[rust_fun
  "core::iter::adapters::flatten::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Clause0_Item, @Clause2_Clause0_Item, @U>, @Clause2_Clause0_Item>}::advance_back_by"]
def core.iter.adapters.flatten.DoubleEndedIteratorFlatten.advance_back_by
  {I U OuterItem Item : Type}
  (iterInst : core.iter.traits.double_ended.DoubleEndedIterator I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator OuterItem Item U)
  (innerInst : core.iter.traits.double_ended.DoubleEndedIterator U Item)
  (self : core.iter.adapters.flatten.Flatten I U) (n : Usize) :
  Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) ×
    core.iter.adapters.flatten.Flatten I U) := do
  let (result, self) ← core.iter.adapters.flatten.DoubleEndedIteratorFlatMap.advance_back_by
    iterInst (core.iter.adapters.flatten.Flatten.identity OuterItem) intoInst innerInst
    self.toFlatMap n
  ok (result, core.iter.adapters.flatten.Flatten.ofFlatMap self)

@[reducible, rust_trait_impl
  "core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::flatten::Flatten<@I, @Clause0_Clause0_Item, @Clause2_Clause0_Item, @U>, @Clause2_Clause0_Item>"]
def core.iter.traits.double_ended.DoubleEndedIteratorFlatten
  {I U OuterItem Item : Type}
  (iterInst : core.iter.traits.double_ended.DoubleEndedIterator I OuterItem)
  (intoInst : core.iter.traits.collect.IntoIterator OuterItem Item U)
  (innerInst : core.iter.traits.double_ended.DoubleEndedIterator U Item) :
  core.iter.traits.double_ended.DoubleEndedIterator
    (core.iter.adapters.flatten.Flatten I U) Item := {
  iteratorInst := core.iter.traits.iterator.IteratorFlatten iterInst.iteratorInst intoInst
    innerInst.iteratorInst
  next_back :=
    core.iter.adapters.flatten.DoubleEndedIteratorFlatten.next_back iterInst intoInst innerInst
  advance_back_by :=
    core.iter.adapters.flatten.DoubleEndedIteratorFlatten.advance_back_by iterInst intoInst
      innerInst
  rfold := core.iter.adapters.flatten.DoubleEndedIteratorFlatten.rfold iterInst intoInst innerInst
  try_rfold :=
    core.iter.adapters.flatten.DoubleEndedIteratorFlatten.try_rfold iterInst intoInst innerInst
}

end Aeneas.Std
