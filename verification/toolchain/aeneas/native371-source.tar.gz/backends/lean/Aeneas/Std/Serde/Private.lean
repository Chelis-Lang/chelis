import Aeneas.Std.Serde.De
import Aeneas.Std.Core.Borrow

/-!
# `serde::private` and `serde_core::private` (serde 1.0.228): helpers of the derived implementations

`#[derive(Deserialize)]` fills a missing field (no `#[serde(default)]`, no `deserialize_with`) with
`serde::__private::de::missing_field(name)?` (serde_derive `de.rs` `expr_is_missing`), and reports
an unknown field or variant name given as bytes with `from_utf8_lossy` (serde_core
`private/string.rs`).
-/

namespace Aeneas.Std

open Result

namespace serde.private.de

open serde_core.de

/-- The format types of `missing_field`'s local `MissingFieldDeserializer<E>(&'static str,
    PhantomData<E>)`: one deserializer, the name of the missing field, with error `E`; no access
    types. -/
@[reducible] def MissingFieldTypes (E : Type) : FormatTypes where
  ιD := Unit
  D := fun _ => Str
  DError := fun _ => E
  ιS := Empty
  S := fun _ => Unit
  SError := fun _ => E
  ιM := Empty
  M := fun _ => Unit
  MError := fun _ => E
  ιE := Empty
  E := fun _ => Unit
  EError := fun _ => E
  EVariant := fun _ => Unit
  ιV := Empty
  V := fun _ => Unit
  VError := fun _ => E

/-- `impl<'de, E: Error> Deserializer<'de> for MissingFieldDeserializer<E>`: `deserialize_any` is
    `Err(Error::missing_field(self.0))`, `deserialize_option` is `visitor.visit_none()`, and
    `forward_to_deserialize_any!` makes every other method (`i128` and `u128` included)
    `deserialize_any`. It never deserializes a nested value, so its encoding at nesting bound 1 is
    exact. -/
def MissingFieldFormat {E : Type} (errInst : serde_core.de.Error E) :
    FormatProgram (MissingFieldTypes E) where
  base := bottom (DeAt 0) (MissingFieldTypes E)
  step := fun X _ =>
    let any : {V Value : Type} → VisitorStep X V Value → Str → V →
        Result (core.result.Result Value E) :=
      fun _ field _ => do ok (.Err (← errInst.missing_field field))
    { des := fun _ =>
        { serde_coredeErrorInst := errInst
          deserialize_any := any
          deserialize_bool := any, deserialize_i8 := any, deserialize_i16 := any
          deserialize_i32 := any, deserialize_i64 := any, deserialize_i128 := any
          deserialize_u8 := any, deserialize_u16 := any, deserialize_u32 := any
          deserialize_u64 := any, deserialize_u128 := any, deserialize_f32 := any
          deserialize_f64 := any, deserialize_char := any, deserialize_str := any
          deserialize_string := any, deserialize_bytes := any, deserialize_byte_buf := any
          deserialize_option := fun visitor _ v => visitor.visit_none errInst v
          deserialize_unit := any
          deserialize_unit_struct := fun visitor field _ v => any visitor field v
          deserialize_newtype_struct := fun visitor field _ v => any visitor field v
          deserialize_seq := any
          deserialize_tuple := fun visitor field _ v => any visitor field v
          deserialize_tuple_struct := fun visitor field _ _ v => any visitor field v
          deserialize_map := any
          deserialize_struct := fun visitor field _ _ v => any visitor field v
          deserialize_enum := fun visitor field _ _ v => any visitor field v
          deserialize_identifier := any
          deserialize_ignored_any := any }
      seqs := fun i => nomatch i
      maps := fun i => nomatch i
      enums := fun i => nomatch i
      variants := fun i => nomatch i }

end serde.private.de

/-- `pub fn missing_field<'de, V: Deserialize<'de>, E: Error>(field: &'static str) -> Result<V, E>`
    (private/de.rs): `V::deserialize(MissingFieldDeserializer(field, PhantomData))`. A missing
    `Option<T>` field is `None`; any other type is `Err(E::missing_field(field))` (through `E`'s
    own `missing_field`). -/
@[rust_fun "serde::private::de::missing_field"]
def serde.private.de.missing_field {V E : Type} (deserializeInst : serde_core.de.Deserialize V)
    (errInst : serde_core.de.Error E) (field : Str) : Result (core.result.Result V E) :=
  deserializeInst.deserialize ((serde.private.de.MissingFieldFormat errInst).encode 1 ()) field

/-- `pub fn from_utf8_lossy(bytes: &[u8]) -> Cow<'_, str>` (serde_core private/string.rs, with the
    `std`/`alloc` features): `String::from_utf8_lossy(bytes)`. -/
@[rust_fun "serde_core::private::string::from_utf8_lossy"]
def serde_core.private.string.from_utf8_lossy (bytes : Slice U8) :
    Result (alloc.borrow.Cow Str String) :=
  alloc.string.String.from_utf8_lossy bytes

end Aeneas.Std
