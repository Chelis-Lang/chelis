import Aeneas.Std.Core.Fmt

namespace Aeneas.Std

@[rust_trait "core::error::Error" (parentClauses := ["fmtDebugInst", "fmtDisplayInst"])]
structure core.error.Error (Self : Type) where
  fmtDebugInst : core.fmt.Debug Self
  fmtDisplayInst : core.fmt.Display Self

/-- The provided `Error::source` (core error.rs): no lower-level source, `None`. An
    implementation overriding it is translated with its own body. -/
@[rust_fun "core::error::Error::source"]
def core.error.Error.source.default {Self : Type} (_ErrorInst : core.error.Error Self)
  (_self : Self) : Result (Option (Dyn (fun _dyn => core.error.Error _dyn))) :=
  .ok none

end Aeneas.Std
