import Aeneas.Std.Core.Core
import Aeneas.Std.Core.Ops
import Aeneas.Std.Core.Cmp

namespace Aeneas.Std

@[rust_type "core::result::Result"]
inductive core.result.Result (T : Type u) (E : Type v) where
| Ok : T → core.result.Result T E
| Err : E → core.result.Result T E
deriving BEq

@[simp, step_simps, rust_fun
  "core::result::{core::ops::try_trait::FromResidual<core::result::Result<@T, @F>, core::result::Result<core::convert::Infallible, @E>>}::from_residual"]
def core.result.FromResidualResult.from_residual
    (T : Type) {E F : Type} (FromInst : core.convert.From F E)
    (residual : core.result.Result core.convert.Infallible E) :
    Aeneas.Std.Result (core.result.Result T F) := do
  match residual with
  | .Ok impossible => nomatch impossible
  | .Err err => return .Err (← FromInst.from_ err)

@[reducible, rust_trait_impl
  "core::ops::try_trait::FromResidual<core::result::Result<@T, @F>, core::result::Result<core::convert::Infallible, @E>>"]
def core.result.FromResidualResult (T : Type) {E F : Type}
    (FromInst : core.convert.From F E) :
    core.ops.try_trait.FromResidual (core.result.Result T F)
      (core.result.Result core.convert.Infallible E) := {
  from_residual := core.result.FromResidualResult.from_residual T FromInst
}

@[simp, step_simps, rust_fun
  "core::result::{core::ops::try_trait::Try<core::result::Result<@T, @E>, @T, core::result::Result<core::convert::Infallible, @E>>}::from_output"]
def core.result.TryResult.from_output {T : Type} (E : Type) (output : T) :
    Aeneas.Std.Result (core.result.Result T E) :=
  .ok (.Ok output)

@[simp, step_simps, rust_fun
  "core::result::{core::ops::try_trait::Try<core::result::Result<@T, @E>, @T, core::result::Result<core::convert::Infallible, @E>>}::branch"]
def core.result.TryResult.branch {T E : Type} (self : core.result.Result T E) :
    Aeneas.Std.Result (core.ops.control_flow.ControlFlow
      (core.result.Result core.convert.Infallible E) T) :=
  match self with
  | .Ok value => .ok (.Continue value)
  | .Err err => .ok (.Break (.Err err))

@[reducible, rust_trait_impl
  "core::ops::try_trait::Try<core::result::Result<@T, @E>, @T, core::result::Result<core::convert::Infallible, @E>>"]
def core.result.TryResult (T E : Type) :
    core.ops.try_trait.Try (core.result.Result T E) T
      (core.result.Result core.convert.Infallible E) := {
  FromResidualInst := core.result.FromResidualResult T (core.convert.FromSame E)
  from_output := core.result.TryResult.from_output E
  branch := core.result.TryResult.branch
}

/-- `PartialEq for Result<T, E>` (derived, core/src/result.rs): the same variant with equal
    payloads (`T: PartialEq` for `Ok`, `E: PartialEq` for `Err`). -/
@[rust_fun "core::result::{core::cmp::PartialEq<core::result::Result<@T, @E>, core::result::Result<@T, @E>>}::eq"]
def core.result.PartialEqResult.eq {T E : Type} (okInst : core.cmp.PartialEq T T)
  (errInst : core.cmp.PartialEq E E) (x y : core.result.Result T E) : Std.Result Bool :=
  match x, y with
  | .Ok a, .Ok b => okInst.eq a b
  | .Err a, .Err b => errInst.eq a b
  | _, _ => .ok false

end Aeneas.Std
