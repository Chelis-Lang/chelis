import Aeneas.Std.Core.Iter

namespace Aeneas.Std

open Result

/-- `Range::contains` (core/src/ops/range.rs, rustc 1.95) is
    `<Self as RangeBounds<Idx>>::contains` with `start_bound = Included(start)`
    and `end_bound = Excluded(end)`: `start <= item && item < end`. The first
    comparison uses `Idx: PartialOrd<U>`, the second (only when the first holds)
    `U: PartialOrd<Idx>`. Incomparable operands (NaN) are therefore not contained.
    The impl's own `Idx: PartialOrd<Idx>` bound is not used. -/
@[rust_fun "core::ops::range::{core::ops::range::Range<@Idx>}::contains"]
def core.ops.range.Range.contains {Idx U : Type}
  (_ : core.cmp.PartialOrd Idx Idx) (idxOrdInst : core.cmp.PartialOrd Idx U)
  (itemOrdInst : core.cmp.PartialOrd U Idx) (self : core.ops.range.Range Idx) (item : U) :
  Result Bool := do
  if ← idxOrdInst.le self.start item then itemOrdInst.lt item self.end
  else ok false

@[rust_type "core::ops::range::RangeInclusive" (body := .opaque)]
structure core.ops.range.RangeInclusive (Idx : Type) where
  start : Idx
  «end» : Idx
  exhausted : Bool

@[rust_fun "core::ops::range::{core::ops::range::RangeInclusive<@Idx>}::new"]
def core.ops.range.RangeInclusive.new {Idx : Type} (start end_ : Idx) :
  Result (core.ops.range.RangeInclusive Idx) :=
  ok ⟨start, end_, false⟩

/-- `RangeInclusive::contains` (core/src/ops/range.rs, rustc 1.95) is
    `<Self as RangeBounds<Idx>>::contains` with `start_bound = Included(start)`
    and `end_bound = Included(end)`, or `Excluded(end)` once iteration has
    exhausted the range: `start <= item && item <= end` (`item < end` when
    exhausted). As for `Range::contains`, the first comparison uses
    `Idx: PartialOrd<U>` and the second (only when the first holds)
    `U: PartialOrd<Idx>`; the impl's own `Idx: PartialOrd<Idx>` is not used. -/
@[rust_fun "core::ops::range::{core::ops::range::RangeInclusive<@Idx>}::contains"]
def core.ops.range.RangeInclusive.contains {Idx U : Type}
  (_ : core.cmp.PartialOrd Idx Idx) (idxOrdInst : core.cmp.PartialOrd Idx U)
  (itemOrdInst : core.cmp.PartialOrd U Idx) (self : core.ops.range.RangeInclusive Idx)
  (item : U) : Result Bool := do
  if ← idxOrdInst.le self.start item then
    if self.exhausted then itemOrdInst.lt item self.end else itemOrdInst.le item self.end
  else ok false

-- Keep the short circuit: an exhausted range does not invoke PartialOrd again.
def core.ops.range.RangeInclusive.isEmpty {Idx : Type}
  (ordInst : core.cmp.PartialOrd Idx Idx)
  (self : core.ops.range.RangeInclusive Idx) : Result Bool := do
  if self.exhausted then ok true
  else ok (!(← ordInst.le self.start self.end))

@[rust_fun
  "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeInclusive<@A>, @A>}::next"]
def core.iter.range.IteratorRangeInclusive.next
  {A : Type} (stepInst : core.iter.range.Step A)
  (self : core.ops.range.RangeInclusive A) :
  Result (Option A × core.ops.range.RangeInclusive A) := do
  if ← self.isEmpty stepInst.partialOrdInst then ok (none, self)
  else if ← stepInst.partialOrdInst.lt self.start self.end then
    let start ← stepInst.cloneInst.clone self.start
    let next ← stepInst.forward_checked start 1#usize
    match next with
    | none => fail .panic
    | some start => ok (some self.start, { self with start })
  else
    let item ← stepInst.cloneInst.clone self.start
    ok (some item, { self with exhausted := true })

-- Rust overrides count with steps_between, not repeated next. In particular a
-- range with usize::MAX + 1 elements fails immediately. Since this by-value
-- override never advances its receiver, its recovered state is unchanged.
@[rust_fun
  "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeInclusive<@A>, @A>}::count"]
def core.iter.range.IteratorRangeInclusive.count
  {A : Type} (stepInst : core.iter.range.Step A)
  (self : core.ops.range.RangeInclusive A) :
  Result (Usize × core.ops.range.RangeInclusive A) := do
  if ← self.isEmpty stepInst.partialOrdInst then ok (0#usize, self)
  else
    let (_, upper) ← stepInst.steps_between self.start self.end
    match upper with
    | none => fail .panic
    | some count =>
      match Usize.checked_add count 1#usize with
      | none => fail .panic
      | some count => ok (count, self)

@[rust_fun
  "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeInclusive<@A>, @A>}::nth"]
def core.iter.range.IteratorRangeInclusive.nth
  {A : Type} (stepInst : core.iter.range.Step A)
  (self : core.ops.range.RangeInclusive A) (n : Usize) :
  Result (Option A × core.ops.range.RangeInclusive A) := do
  if ← self.isEmpty stepInst.partialOrdInst then return (none, self)
  let start ← stepInst.cloneInst.clone self.start
  let plusN ← stepInst.forward_checked start n
  if let some plusN := plusN then
    match ← stepInst.partialOrdInst.partial_cmp plusN self.end with
    | some .lt =>
      let start ← stepInst.cloneInst.clone plusN
      let start ← stepInst.forward start 1#usize
      return (some plusN, { self with start })
    | some .eq =>
      let start ← stepInst.cloneInst.clone plusN
      return (some plusN, { self with start, exhausted := true })
    | _ => pure ()
  let start ← stepInst.cloneInst.clone self.end
  ok (none, { self with start, exhausted := true })

-- any dispatches through RangeInclusive's try_fold override. Test emptiness
-- once, advance before invoking the predicate, and consume the final endpoint
-- without asking Step to increment it (which could overflow).
def core.iter.range.IteratorRangeInclusive.anyLoop
  {A F : Type} (stepInst : core.iter.range.Step A)
  (predInst : core.ops.function.FnMut F A Bool)
  (self : core.ops.range.RangeInclusive A) (predicate : F) :
  Result (Bool × core.ops.range.RangeInclusive A × F) := do
  if ← stepInst.partialOrdInst.lt self.start self.end then
    let start ← stepInst.cloneInst.clone self.start
    let next ← stepInst.forward_checked start 1#usize
    match next with
    | none => fail .panic
    | some start =>
      let (found, predicate) ← predInst.call_mut predicate self.start
      let self := { self with start }
      if found then ok (true, self, predicate)
      else core.iter.range.IteratorRangeInclusive.anyLoop stepInst predInst self predicate
  else
    let self := { self with exhausted := true }
    if ← stepInst.partialOrdInst.partialEqInst.eq self.start self.end then
      let item ← stepInst.cloneInst.clone self.start
      let (found, predicate) ← predInst.call_mut predicate item
      ok (found, self, predicate)
    else ok (false, self, predicate)
partial_fixpoint

@[rust_fun
  "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeInclusive<@A>, @A>}::any"]
def core.iter.range.IteratorRangeInclusive.any
  {A F : Type} (stepInst : core.iter.range.Step A)
  (predInst : core.ops.function.FnMut F A Bool)
  (self : core.ops.range.RangeInclusive A) (predicate : F) :
  Result (Bool × core.ops.range.RangeInclusive A × F) := do
  if ← self.isEmpty stepInst.partialOrdInst then ok (false, self, predicate)
  else core.iter.range.IteratorRangeInclusive.anyLoop stepInst predInst self predicate

@[rust_fun
  "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeInclusive<@A>, @A>}::enumerate"]
def core.iter.range.IteratorRangeInclusive.enumerate
  {A : Type} (_stepInst : core.iter.range.Step A)
  (self : core.ops.range.RangeInclusive A) :
  Result (core.iter.adapters.enumerate.Enumerate (core.ops.range.RangeInclusive A)) :=
  core.iter.traits.iterator.Iterator.enumerate.default self

@[rust_fun
  "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeInclusive<@A>, @A>}::size_hint"]
def core.iter.range.IteratorRangeInclusive.size_hint
  {A : Type} (stepInst : core.iter.range.Step A)
  (self : core.ops.range.RangeInclusive A) : Result (Usize × Option Usize) := do
  if ← self.isEmpty stepInst.partialOrdInst then ok (0#usize, some 0#usize)
  else
    let (lower, upper) ← stepInst.steps_between self.start self.end
    let lower := (Usize.checked_add lower 1#usize).getD core.num.Usize.MAX
    let upper := upper.bind (fun count => Usize.checked_add count 1#usize)
    ok (lower, upper)

def core.iter.range.IteratorRangeInclusive.foldLoop
  {A B F : Type} (stepInst : core.iter.range.Step A)
  (fnInst : core.ops.function.FnMut F (B × A) B)
  (self : core.ops.range.RangeInclusive A) (accum : B) (f : F) :
  Result (B × core.ops.range.RangeInclusive A × F) := do
  if ← stepInst.partialOrdInst.lt self.start self.end then
    let start ← stepInst.cloneInst.clone self.start
    let next ← stepInst.forward_checked start 1#usize
    match next with
    | none => fail .panic
    | some start =>
      let (accum, f) ← fnInst.call_mut f (accum, self.start)
      core.iter.range.IteratorRangeInclusive.foldLoop stepInst fnInst
        { self with start } accum f
  else
    let self := { self with exhausted := true }
    if ← stepInst.partialOrdInst.partialEqInst.eq self.start self.end then
      let item ← stepInst.cloneInst.clone self.start
      let (accum, f) ← fnInst.call_mut f (accum, item)
      ok (accum, self, f)
    else ok (accum, self, f)
partial_fixpoint

@[rust_fun
  "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeInclusive<@A>, @A>}::fold"]
def core.iter.range.IteratorRangeInclusive.fold
  {A B F : Type} (stepInst : core.iter.range.Step A)
  (fnInst : core.ops.function.FnMut F (B × A) B)
  (self : core.ops.range.RangeInclusive A) (accum : B) (f : F) :
  Result (B × core.ops.range.RangeInclusive A × F) := do
  if ← self.isEmpty stepInst.partialOrdInst then ok (accum, self, f)
  else core.iter.range.IteratorRangeInclusive.foldLoop stepInst fnInst self accum f

def core.iter.range.IteratorRangeInclusive.tryFoldLoop
  {A B F R Residual : Type} (stepInst : core.iter.range.Step A)
  (fnInst : core.ops.function.FnMut F (B × A) R)
  (tryInst : core.ops.try_trait.Try R B Residual)
  (self : core.ops.range.RangeInclusive A) (accum : B) (f : F) :
  Result (R × core.ops.range.RangeInclusive A × F) := do
  if ← stepInst.partialOrdInst.lt self.start self.end then
    let start ← stepInst.cloneInst.clone self.start
    let next ← stepInst.forward_checked start 1#usize
    match next with
    | none => fail .panic
    | some start =>
      let (result, f) ← fnInst.call_mut f (accum, self.start)
      let self := { self with start }
      match ← tryInst.branch result with
      | .Break residual =>
        let result ← tryInst.FromResidualInst.from_residual residual
        ok (result, self, f)
      | .Continue accum =>
        core.iter.range.IteratorRangeInclusive.tryFoldLoop stepInst fnInst tryInst self accum f
  else
    let self := { self with exhausted := true }
    if ← stepInst.partialOrdInst.partialEqInst.eq self.start self.end then
      let item ← stepInst.cloneInst.clone self.start
      let (result, f) ← fnInst.call_mut f (accum, item)
      match ← tryInst.branch result with
      | .Break residual =>
        let result ← tryInst.FromResidualInst.from_residual residual
        ok (result, self, f)
      | .Continue accum =>
        let result ← tryInst.from_output accum
        ok (result, self, f)
    else
      let result ← tryInst.from_output accum
      ok (result, self, f)
partial_fixpoint

@[rust_fun
  "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeInclusive<@A>, @A>}::try_fold"]
def core.iter.range.IteratorRangeInclusive.try_fold
  {A B F R Residual : Type} (stepInst : core.iter.range.Step A)
  (fnInst : core.ops.function.FnMut F (B × A) R)
  (tryInst : core.ops.try_trait.Try R B Residual)
  (self : core.ops.range.RangeInclusive A) (accum : B) (f : F) :
  Result (R × core.ops.range.RangeInclusive A × F) := do
  if ← self.isEmpty stepInst.partialOrdInst then
    let result ← tryInst.from_output accum
    ok (result, self, f)
  else core.iter.range.IteratorRangeInclusive.tryFoldLoop stepInst fnInst tryInst self accum f

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::ops::range::RangeInclusive<@A>, @A>"]
def core.iter.traits.iterator.IteratorRangeInclusive
  {A : Type} (stepInst : core.iter.range.Step A) :
  core.iter.traits.iterator.Iterator (core.ops.range.RangeInclusive A) A := {
  next := core.iter.range.IteratorRangeInclusive.next stepInst
  nth := core.iter.range.IteratorRangeInclusive.nth stepInst
  count := core.iter.range.IteratorRangeInclusive.count stepInst
  any := core.iter.range.IteratorRangeInclusive.any stepInst
  enumerate := core.iter.range.IteratorRangeInclusive.enumerate stepInst
  fold := core.iter.range.IteratorRangeInclusive.fold stepInst
  try_fold := core.iter.range.IteratorRangeInclusive.try_fold stepInst
  size_hint := core.iter.range.IteratorRangeInclusive.size_hint stepInst
  trusted_len := stepInst.trusted_len
  fused := true
}

@[rust_fun
  "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeInclusive<@A>, @A>}::advance_by"]
def core.iter.range.IteratorRangeInclusive.advance_by
  {A : Type} (stepInst : core.iter.range.Step A)
  (self : core.ops.range.RangeInclusive A) (n : Usize) :
  Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) ×
    core.ops.range.RangeInclusive A) :=
  core.iter.traits.iterator.Iterator.advance_by.default
    (core.iter.traits.iterator.IteratorRangeInclusive stepInst) self n

@[rust_type "core::iter::sources::once::Once" (body := .opaque)]
structure core.iter.sources.once.Once (T : Type) where
  item : Option T

@[rust_fun "core::iter::sources::once::once"]
def core.iter.sources.once.once {T : Type} (value : T) :
  Result (core.iter.sources.once.Once T) :=
  ok ⟨some value⟩

@[rust_fun
  "core::iter::sources::once::{core::iter::traits::iterator::Iterator<core::iter::sources::once::Once<@T>, @T>}::next"]
def core.iter.sources.once.IteratorOnce.next
  {T : Type} (self : core.iter.sources.once.Once T) :
  Result (Option T × core.iter.sources.once.Once T) :=
  ok (self.item, ⟨none⟩)

@[rust_fun
  "core::iter::sources::once::{core::iter::traits::iterator::Iterator<core::iter::sources::once::Once<@T>, @T>}::count"]
def core.iter.sources.once.IteratorOnce.count
  {T : Type} (self : core.iter.sources.once.Once T) :
  Result (Usize × core.iter.sources.once.Once T) :=
  ok ((if self.item.isSome then 1#usize else 0#usize), ⟨none⟩)

@[rust_fun
  "core::iter::sources::once::{core::iter::traits::iterator::Iterator<core::iter::sources::once::Once<@T>, @T>}::nth"]
def core.iter.sources.once.IteratorOnce.nth
  {T : Type} (self : core.iter.sources.once.Once T) (n : Usize) :
  Result (Option T × core.iter.sources.once.Once T) :=
  ok ((if n.val = 0 then self.item else none), ⟨none⟩)

@[rust_fun
  "core::iter::sources::once::{core::iter::traits::iterator::Iterator<core::iter::sources::once::Once<@T>, @T>}::any"]
def core.iter.sources.once.IteratorOnce.any
  {T F : Type} (predInst : core.ops.function.FnMut F T Bool)
  (self : core.iter.sources.once.Once T) (predicate : F) :
  Result (Bool × core.iter.sources.once.Once T × F) := do
  match self.item with
  | none => ok (false, ⟨none⟩, predicate)
  | some item =>
    let (found, predicate) ← predInst.call_mut predicate item
    ok (found, ⟨none⟩, predicate)

@[rust_fun
  "core::iter::sources::once::{core::iter::traits::iterator::Iterator<core::iter::sources::once::Once<@T>, @T>}::enumerate"]
def core.iter.sources.once.IteratorOnce.enumerate
  {T : Type} (self : core.iter.sources.once.Once T) :
  Result (core.iter.adapters.enumerate.Enumerate (core.iter.sources.once.Once T)) :=
  core.iter.traits.iterator.Iterator.enumerate.default self

@[rust_fun
  "core::iter::sources::once::{core::iter::traits::iterator::Iterator<core::iter::sources::once::Once<@T>, @T>}::size_hint"]
def core.iter.sources.once.IteratorOnce.size_hint
  {T : Type} (self : core.iter.sources.once.Once T) : Result (Usize × Option Usize) :=
  let count := if self.item.isSome then 1#usize else 0#usize
  ok (count, some count)

@[rust_fun
  "core::iter::sources::once::{core::iter::traits::iterator::Iterator<core::iter::sources::once::Once<@T>, @T>}::fold"]
def core.iter.sources.once.IteratorOnce.fold
  {T B F : Type} (fnInst : core.ops.function.FnMut F (B × T) B)
  (self : core.iter.sources.once.Once T) (accum : B) (f : F) :
  Result (B × core.iter.sources.once.Once T × F) :=
  core.iter.traits.iterator.foldFromNext core.iter.sources.once.IteratorOnce.next fnInst self accum f

@[rust_fun
  "core::iter::sources::once::{core::iter::traits::iterator::Iterator<core::iter::sources::once::Once<@T>, @T>}::try_fold"]
def core.iter.sources.once.IteratorOnce.try_fold
  {T B F R Residual : Type} (fnInst : core.ops.function.FnMut F (B × T) R)
  (tryInst : core.ops.try_trait.Try R B Residual)
  (self : core.iter.sources.once.Once T) (accum : B) (f : F) :
  Result (R × core.iter.sources.once.Once T × F) :=
  core.iter.traits.iterator.tryFoldFromNext
    core.iter.sources.once.IteratorOnce.next fnInst tryInst self accum f

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::iter::sources::once::Once<@T>, @T>"]
def core.iter.traits.iterator.IteratorOnce (T : Type) :
  core.iter.traits.iterator.Iterator (core.iter.sources.once.Once T) T := {
  next := core.iter.sources.once.IteratorOnce.next
  count := core.iter.sources.once.IteratorOnce.count
  any := core.iter.sources.once.IteratorOnce.any
  enumerate := core.iter.sources.once.IteratorOnce.enumerate
  nth := core.iter.sources.once.IteratorOnce.nth
  size_hint := core.iter.sources.once.IteratorOnce.size_hint
  fold := core.iter.sources.once.IteratorOnce.fold
  try_fold := core.iter.sources.once.IteratorOnce.try_fold
  trusted_len := true
  one_shot := true
  fused := true
}

@[rust_fun
  "core::iter::sources::once::{core::iter::traits::iterator::Iterator<core::iter::sources::once::Once<@T>, @T>}::advance_by"]
def core.iter.sources.once.IteratorOnce.advance_by
  {T : Type} (self : core.iter.sources.once.Once T) (n : Usize) :
  Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) ×
    core.iter.sources.once.Once T) :=
  core.iter.traits.iterator.Iterator.advance_by.default
    (core.iter.traits.iterator.IteratorOnce T) self n

/-- `RepeatWith<F> { repeater: F }` (core/src/iter/sources/repeat_with.rs, rustc 1.95). -/
structure core.iter.sources.repeat_with.RepeatWith (F : Type) where
  repeater : F

/-- The recombination of `RepeatWith` replaces the repeater, its only state. -/
def core.iter.sources.repeat_with.RepeatWith.recombine {F : Type}
    (mergeF : F → F → F) (original current : core.iter.sources.repeat_with.RepeatWith F) :
    core.iter.sources.repeat_with.RepeatWith F :=
  { original with repeater := mergeF original.repeater current.repeater }

attribute [rust_type "core::iter::sources::repeat_with::RepeatWith" (body := .opaque)
  (stateMerge := some ("Aeneas.Std.core.iter.sources.repeat_with.RepeatWith.recombine", [0]))]
  core.iter.sources.repeat_with.RepeatWith

/-- `repeat_with(repeater)`: `RepeatWith { repeater }`, a constructor with state: the second
    result reads the repeater back from a final state of the iterator. -/
@[rust_fun "core::iter::sources::repeat_with::repeat_with"]
def core.iter.sources.repeat_with.repeat_with {A F : Type}
    (_ : core.ops.function.FnMut F Unit A) (repeater : F) :
    Result (core.iter.sources.repeat_with.RepeatWith F ×
      (core.iter.sources.repeat_with.RepeatWith F → F)) :=
  ok (⟨repeater⟩, (·.repeater))

/-- `Iterator for RepeatWith<F>` (`F: FnMut() -> A`) defines `next` (`Some((self.repeater)())`),
    `size_hint` (`(usize::MAX, None)`) and `try_fold` (`loop { let item = (self.repeater)();
    init = fold(init, item)?; }`: the schedule of repeated `next`). It is `TrustedLen` and
    `FusedIterator`. -/
@[rust_fun
  "core::iter::sources::repeat_with::{core::iter::traits::iterator::Iterator<core::iter::sources::repeat_with::RepeatWith<@F>, @A>}::next"]
def core.iter.sources.repeat_with.IteratorRepeatWith.next {A F : Type}
    (fnInst : core.ops.function.FnMut F Unit A)
    (self : core.iter.sources.repeat_with.RepeatWith F) :
    Result (Option A × core.iter.sources.repeat_with.RepeatWith F) := do
  let (item, repeater) ← fnInst.call_mut self.repeater ()
  ok (some item, ⟨repeater⟩)

@[rust_fun
  "core::iter::sources::repeat_with::{core::iter::traits::iterator::Iterator<core::iter::sources::repeat_with::RepeatWith<@F>, @A>}::size_hint"]
def core.iter.sources.repeat_with.IteratorRepeatWith.size_hint {A F : Type}
    (_ : core.ops.function.FnMut F Unit A)
    (_ : core.iter.sources.repeat_with.RepeatWith F) : Result (Usize × Option Usize) :=
  ok (core.num.Usize.MAX, none)

@[rust_fun
  "core::iter::sources::repeat_with::{core::iter::traits::iterator::Iterator<core::iter::sources::repeat_with::RepeatWith<@F>, @A>}::try_fold"]
def core.iter.sources.repeat_with.IteratorRepeatWith.try_fold {A F B G R Residual : Type}
    (fnInst : core.ops.function.FnMut F Unit A)
    (foldInst : core.ops.function.FnMut G (B × A) R)
    (tryInst : core.ops.try_trait.Try R B Residual)
    (self : core.iter.sources.repeat_with.RepeatWith F) (init : B) (fold : G) :
    Result (R × core.iter.sources.repeat_with.RepeatWith F × G) :=
  core.iter.traits.iterator.tryFoldFromNext
    (core.iter.sources.repeat_with.IteratorRepeatWith.next fnInst) foldInst tryInst self init fold

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::iter::sources::repeat_with::RepeatWith<@F>, @A>"]
def core.iter.traits.iterator.IteratorRepeatWith {A F : Type}
    (fnInst : core.ops.function.FnMut F Unit A) :
    core.iter.traits.iterator.Iterator (core.iter.sources.repeat_with.RepeatWith F) A := {
  next := core.iter.sources.repeat_with.IteratorRepeatWith.next fnInst
  size_hint := core.iter.sources.repeat_with.IteratorRepeatWith.size_hint fnInst
  try_fold := core.iter.sources.repeat_with.IteratorRepeatWith.try_fold fnInst
  trusted_len := true
  fused := true
}

/-- `Empty<T>(PhantomData<fn() -> T>)` (core/src/iter/sources/empty.rs, rustc 1.95): no state. -/
@[rust_type "core::iter::sources::empty::Empty" (body := .opaque)]
structure core.iter.sources.empty.Empty (T : Type) : Type where

/-- `iter::empty()`: `Empty(PhantomData)`. -/
@[rust_fun "core::iter::sources::empty::empty"]
def core.iter.sources.empty.empty (T : Type) : Result (core.iter.sources.empty.Empty T) :=
  ok ⟨⟩

/-- `Iterator for Empty<T>` defines `next` (`None`) and `size_hint` (`(0, Some(0))`); `Empty`
    is `TrustedLen`, `FusedIterator` and flatten's `OneShot`. -/
@[rust_fun
  "core::iter::sources::empty::{core::iter::traits::iterator::Iterator<core::iter::sources::empty::Empty<@T>, @T>}::next"]
def core.iter.sources.empty.IteratorEmpty.next {T : Type} (self : core.iter.sources.empty.Empty T) :
    Result (Option T × core.iter.sources.empty.Empty T) :=
  ok (none, self)

@[rust_fun
  "core::iter::sources::empty::{core::iter::traits::iterator::Iterator<core::iter::sources::empty::Empty<@T>, @T>}::size_hint"]
def core.iter.sources.empty.IteratorEmpty.size_hint {T : Type}
    (_ : core.iter.sources.empty.Empty T) : Result (Usize × Option Usize) :=
  ok (0#usize, some 0#usize)

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::iter::sources::empty::Empty<@T>, @T>"]
def core.iter.traits.iterator.IteratorEmpty (T : Type) :
    core.iter.traits.iterator.Iterator (core.iter.sources.empty.Empty T) T := {
  next := core.iter.sources.empty.IteratorEmpty.next
  size_hint := core.iter.sources.empty.IteratorEmpty.size_hint
  trusted_len := true
  one_shot := true
  fused := true
}

/-- `option::Iter<'a, A> { inner: Item<&'a A> }` with `Item<A> { opt: Option<A> }`
    (core/src/option.rs). Its `Iterator` impl defines only `next`
    (`self.opt.take()`) and the exact `size_hint` `(len, Some(len))`; it is
    `TrustedLen`, `FusedIterator` and flatten's `OneShot`, and not
    `TrustedRandomAccess`. -/
@[rust_type "core::option::Iter" (body := .opaque)]
structure core.option.Iter (A : Type) where
  opt : Option A

/-- `Option::iter`: `Iter { inner: Item { opt: self.as_ref() } }`. -/
@[rust_fun "core::option::{core::option::Option<@T>}::iter"]
def core.option.Option.iter {T : Type} (self : Option T) : Result (core.option.Iter T) :=
  ok ⟨self⟩

@[rust_fun
  "core::option::{core::iter::traits::iterator::Iterator<core::option::Iter<'a, @A>, &'a @A>}::next"]
def core.option.IteratorIter.next {A : Type} (self : core.option.Iter A) :
  Result (Option A × core.option.Iter A) :=
  ok (self.opt, ⟨none⟩)

@[rust_fun
  "core::option::{core::iter::traits::iterator::Iterator<core::option::Iter<'a, @A>, &'a @A>}::size_hint"]
def core.option.IteratorIter.size_hint {A : Type} (self : core.option.Iter A) :
  Result (Usize × Option Usize) :=
  let len := if self.opt.isSome then 1#usize else 0#usize
  ok (len, some len)

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::option::Iter<'a, @A>, &'a @A>"]
def core.iter.traits.iterator.IteratorOptionIter (A : Type) :
  core.iter.traits.iterator.Iterator (core.option.Iter A) A := {
  next := core.option.IteratorIter.next
  size_hint := core.option.IteratorIter.size_hint
  trusted_len := true
  one_shot := true
  fused := true
}

/-- Shared `IntoIterator` calls `Option::iter`. Exhaustion does not change the borrowed option. -/
@[rust_fun
  "core::option::{core::iter::traits::collect::IntoIterator<&'a core::option::Option<@T>, &'a @T, core::option::Iter<'a, @T>>}::into_iter"]
def core.option.IntoIteratorSharedOption.into_iter {T : Type} (self : Option T) :
    -- Preserve the source.
    Result (core.option.Iter T × (core.option.Iter T → Option T)) :=
  .ok (⟨self⟩, fun _ => self)

@[reducible, rust_trait_impl
  "core::iter::traits::collect::IntoIterator<&'a core::option::Option<@T>, &'a @T, core::option::Iter<'a, @T>>"]
def core.iter.traits.collect.IntoIteratorSharedOption (T : Type) :
    core.iter.traits.collect.IntoIterator (Option T) T (core.option.Iter T) := {
  -- Shared iterator.
  iteratorInst := core.iter.traits.iterator.IteratorOptionIter T
  into_iter := core.option.IntoIteratorSharedOption.into_iter
}

/-- `option::IntoIter<A> { inner: Item<A> }` with `Item<A> { opt: Option<A> }`
    (core/src/option.rs). Like `option::Iter`, its `Iterator` impl defines only
    `next` (`self.inner.next()`, i.e. `opt.take()`) and the exact `size_hint`
    `(len, Some(len))`; it is `TrustedLen`, `FusedIterator` and flatten's
    `OneShot`, and not `TrustedRandomAccess`. -/
@[rust_type "core::option::IntoIter" (body := .opaque)]
structure core.option.IntoIter (A : Type) where
  opt : Option A

/-- `IntoIterator for Option<T>`: `IntoIter { inner: Item { opt: self } }`. The
    source is moved into the iterator; recovery returns the remaining option. -/
@[rust_fun
  "core::option::{core::iter::traits::collect::IntoIterator<core::option::Option<@T>, @T, core::option::IntoIter<@T>>}::into_iter"]
def core.option.IntoIteratorOption.into_iter {T : Type} (self : Option T) :
    Result (core.option.IntoIter T × (core.option.IntoIter T → Option T)) :=
  ok (⟨self⟩, fun it => it.opt)

@[rust_fun
  "core::option::{core::iter::traits::iterator::Iterator<core::option::IntoIter<@A>, @A>}::next"]
def core.option.IteratorIntoIter.next {A : Type} (self : core.option.IntoIter A) :
  Result (Option A × core.option.IntoIter A) :=
  ok (self.opt, ⟨none⟩)

/-- `DoubleEndedIterator for option::IntoIter` (core/src/option.rs): `self.inner.next_back()`,
    which takes the value as `next` does. -/
@[rust_fun
  "core::option::{core::iter::traits::double_ended::DoubleEndedIterator<core::option::IntoIter<@A>, @A>}::next_back"]
def core.option.DoubleEndedIteratorIntoIter.next_back {A : Type} (self : core.option.IntoIter A) :
  Result (Option A × core.option.IntoIter A) :=
  ok (self.opt, ⟨none⟩)

@[rust_fun
  "core::option::{core::iter::traits::iterator::Iterator<core::option::IntoIter<@A>, @A>}::size_hint"]
def core.option.IteratorIntoIter.size_hint {A : Type} (self : core.option.IntoIter A) :
  Result (Usize × Option Usize) :=
  let len := if self.opt.isSome then 1#usize else 0#usize
  ok (len, some len)

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::option::IntoIter<@A>, @A>"]
def core.iter.traits.iterator.IteratorOptionIntoIter (A : Type) :
  core.iter.traits.iterator.Iterator (core.option.IntoIter A) A := {
  next := core.option.IteratorIntoIter.next
  size_hint := core.option.IteratorIntoIter.size_hint
  trusted_len := true
  one_shot := true
  fused := true
}

@[reducible, rust_trait_impl
  "core::iter::traits::collect::IntoIterator<core::option::Option<@T>, @T, core::option::IntoIter<@T>>"]
def core.iter.traits.collect.IntoIteratorOption (T : Type) :
  core.iter.traits.collect.IntoIterator (Option T) T (core.option.IntoIter T) := {
  iteratorInst := core.iter.traits.iterator.IteratorOptionIntoIter T
  into_iter := core.option.IntoIteratorOption.into_iter
}

end Aeneas.Std
