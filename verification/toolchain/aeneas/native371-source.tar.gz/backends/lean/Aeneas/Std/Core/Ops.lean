import Lean
import Aeneas.Std.Alloc

namespace Aeneas

namespace Std

open Result

@[rust_trait "core::ops::index::Index"]
structure core.ops.index.Index (Self Idx Output : Type) where
  index : Self → Idx → Result Output

@[rust_trait "core::ops::index::IndexMut" (parentClauses := ["indexInst"])]
structure core.ops.index.IndexMut (Self Idx Output : Type) where
  indexInst : Index Self Idx Output
  index_mut : Self → Idx → Result (Output × (Output → Self))

@[rust_trait "core::ops::deref::Deref"]
structure core.ops.deref.Deref (Self Target : Type) where
  deref : Self → Result Target

@[rust_trait "core::ops::deref::DerefMut" (parentClauses := ["derefInst"])]
structure core.ops.deref.DerefMut (Self Target : Type) where
  derefInst : Deref Self Target
  deref_mut : Self → Result (Target × (Target → Self))

/-- Trait instance -/
@[rust_trait_impl "core::ops::deref::Deref<Box<@T>, @T>" (keepParams := [true, false])]
def core.ops.deref.DerefBoxInst (T : Type) :
  core.ops.deref.Deref T T := {
  deref x := ok (alloc.boxed.Box.deref x)
}

/-- Trait instance -/
@[rust_trait_impl "core::ops::deref::DerefMut<Box<@T>, @T>" (keepParams := [true, false])]
def core.ops.deref.DerefMutBoxInst (T : Type) :
  core.ops.deref.DerefMut T T := {
  derefInst := DerefBoxInst T
  deref_mut x := ok (alloc.boxed.Box.deref_mut x)
}

@[rust_trait "core::ops::bit::BitAnd"]
structure core.ops.bit.BitAnd (Self : Type) (Rhs : Type) (Self_Output : Type) where
  bitand : Self → Rhs → Result Self_Output

@[rust_trait "core::ops::arith::MulAssign"]
structure core.ops.arith.MulAssign (Self Rhs : Type) where
  mul_assign : Self → Rhs → Result Self

@[rust_trait "core::ops::function::FnOnce"]
structure core.ops.function.FnOnce (Self : Type u) (Args : Type v) (Output : Type w) where
  /-- Consumed closure state is retained so captured mutable borrows can be returned. -/
  call_once : Self → Args → Result (Output × Self)

/-- The specialization `FnOnce<(&'a mut T,)>` that Charon's
    `--monomorphize-mut` creates for a closure taking one mutable borrow. The
    borrowed argument is returned after the call; the consumed closure state is
    not (it cannot hold the argument's borrow). -/
@[rust_trait "core::ops::function::FnOnce<@Self, (&'a mut @T), @Output>"]
structure core.ops.function.FnOnceMutArg (Self : Type u) (T : Type v) (Output : Type w) where
  call_once : Self → T → Result (Output × T)

/-- The specialization `FnOnce<(&'a mut T, U)>` that Charon's
    `--monomorphize-mut` creates for a closure taking a mutable borrow and a
    value (e.g. the `exit` closure of a scope). The borrowed argument is
    returned after the call; the value and the consumed closure state are not. -/
@[rust_trait "core::ops::function::FnOnce<@Self, (&'a mut @T, @U), @Output>"]
structure core.ops.function.FnOnceMutArgPair (Self : Type u) (T : Type v) (U : Type w)
    (Output : Type x) where
  call_once : Self → (T × U) → Result (Output × T)

/-- The specialization `FnOnce<(&'a mut T, &'b mut U)>` that Charon's
    `--monomorphize-mut` creates for a closure taking two mutable borrows (e.g.
    the runtime and the explicit state of a catch). Both borrowed arguments are
    returned after the call; the consumed closure state is not. -/
@[rust_trait "core::ops::function::FnOnce<@Self, (&'a mut @T, &'b mut @U), @Output>"]
structure core.ops.function.FnOnceMutArgMutArg (Self : Type u) (T : Type v) (U : Type w)
    (Output : Type x) where
  call_once : Self → (T × U) → Result (Output × T × U)

/-- This callback reads a mutable borrow through a shared reference.
    The shared argument needs no restoration.
    The result retains consumed closure state for captured mutable borrows. -/
@[rust_trait "core::ops::function::FnOnce<@Self, (&'a &'b mut @T), @Output>"]
structure core.ops.function.FnOnceSharedMutArg (Self : Type u) (T : Type v)
    (Output : Type w) where
  call_once : Self → T → Result (Output × Self)

/-- The specialization `FnMut<(&'a &'b mut T,)>` (see `FnOnceSharedMutArg`):
    the call returns the closure state. -/
@[rust_trait "core::ops::function::FnMut<@Self, (&'a &'b mut @T), @Output>"
  (parentClauses := ["FnOnceInst"])]
structure core.ops.function.FnMutSharedMutArg (Self : Type u) (T : Type v)
    (Output : Type w) where
  FnOnceInst : core.ops.function.FnOnceSharedMutArg Self T Output
  call_mut : Self → T → Result (Output × Self)

/-- The specialization `FnMut<(&'a mut T,)>` that Charon's `--monomorphize-mut`
    creates for a closure taking one mutable borrow (e.g. the predicate of
    `Vec::retain_mut`), when the closure type is a parameter: the call returns
    the output, the borrowed argument and the closure state (the argument's
    region is a parameter of the trait, the region of `&mut self` one of the
    method). (For a closure capturing mutable borrows the specialization is
    specific to the closure; such a bound is not this schema, see
    `ModelStateABI.closure_state_instance`.) -/
@[rust_trait "core::ops::function::FnMut<@Self, (&'a mut @T), @Output>"
  (parentClauses := ["FnOnceInst"])]
structure core.ops.function.FnMutMutArg (Self : Type u) (T : Type v) (Output : Type w) where
  FnOnceInst : core.ops.function.FnOnceMutArg Self T Output
  call_mut : Self → T → Result (Output × T × Self)

/-! ### Closure specializations at borrowing states

A partial-monomorphization instance of a modeled function which threads a state
`S` through closures (e.g. `scoped::<HostCx<'a>, ..>`, whose state holds mutable
borrows) receives closure specializations such as `FnOnce<(&'b mut HostCx<'a>,)>`
whose call also returns `k : K`, the backward function of the inner borrows of
the state: given the values the caller gives back to the borrows of the returned
state, the values of the borrows of the lent state. A model is parametric in its
state, so the instance runs it at the state `S × K`: `thread` turns such a
closure into a dictionary of the model which composes the backward functions of
successive calls (`BackCompose.comp k b` applies `b`, the backward function of
the call, then `k`, that of the calls before). The instance starts from
`BackCompose.id` and returns the final state and its backward function. -/

/-- The backward functions of the inner borrows of a state: one function per
    region, composed call after call. -/
class BackCompose (K : Type u) where
  id : K
  comp : K → K → K

instance BackCompose.fn {A : Type u} : BackCompose (A → A) where
  id := fun a => a
  comp k b := fun a => k (b a)

instance BackCompose.prod {A B : Type u} [BackCompose A] [BackCompose B] :
    BackCompose (A × B) where
  id := (BackCompose.id, BackCompose.id)
  comp k b := (BackCompose.comp k.1 b.1, BackCompose.comp k.2 b.2)

/-- A closure `FnOnce<(&'a mut T,)>` at a borrowing state `T` as a dictionary of
    the model at the state `T × K`. -/
def core.ops.function.FnOnceMutArg.thread {Self : Type u} {T K : Type v} {Output : Type w}
    [BackCompose K] (call : Self → T → Result (Output × T × K)) :
    core.ops.function.FnOnceMutArg Self (T × K) Output where
  call_once f s := do
    let (o, t, b) ← call f s.1
    .ok (o, t, BackCompose.comp s.2 b)

/-- A closure `FnOnce<(&'a mut T, U)>` at a borrowing state `T` as a dictionary
    of the model at the state `T × K`. -/
def core.ops.function.FnOnceMutArgPair.thread {Self : Type u} {T K : Type v} {U : Type w}
    {Output : Type x} [BackCompose K] (call : Self → (T × U) → Result (Output × T × K)) :
    core.ops.function.FnOnceMutArgPair Self (T × K) U Output where
  call_once f a := do
    let (o, t, b) ← call f (a.1.1, a.2)
    .ok (o, t, BackCompose.comp a.1.2 b)

/-- A closure `FnOnce<(&'a mut T, &'b mut U)>` at a borrowing state `U` (the
    second argument) as a dictionary of the model at the state `U × K`. -/
def core.ops.function.FnOnceMutArgMutArg.threadSnd {Self : Type u} {T : Type v}
    {U K : Type w} {Output : Type x} [BackCompose K]
    (call : Self → (T × U) → Result (Output × T × U × K)) :
    core.ops.function.FnOnceMutArgMutArg Self T (U × K) Output where
  call_once f a := do
    let (o, t, u, b) ← call f (a.1, a.2.1)
    .ok (o, t, u, BackCompose.comp a.2.2 b)

@[rust_trait "core::ops::function::FnMut" (parentClauses := ["FnOnceInst"])]
structure core.ops.function.FnMut (Self : Type u) (Args : Type v) (Output : Type w) where
  FnOnceInst : core.ops.function.FnOnce Self Args Output
  call_mut : Self → Args → Result (Output × Self)

@[rust_trait "core::ops::function::Fn" (parentClauses := ["FnMutInst"])]
structure core.ops.function.Fn (Self : Type u) (Args : Type v) (Output : Type w) where
  FnMutInst : core.ops.function.FnMut Self Args Output
  call : Self → Args → Result Output

def BuiltinFnOnce (Inputs : Type u) (Outputs : Type v) : core.ops.function.FnOnce (Inputs → Result Outputs) Inputs Outputs := {
  call_once f x :=
    match f x with
    | ok y => ok (y, f)
    | fail e => fail e
    | div => div
}

def BuiltinFnMut (Inputs : Type u) (Outputs : Type v) : core.ops.function.FnMut (Inputs → Result Outputs) Inputs Outputs := {
  FnOnceInst := BuiltinFnOnce Inputs Outputs
  call_mut f x :=
    match f x with
    | ok y => ok (y, f)
    | fail e => fail e
    | div => div
}

def BuiltinFn (Inputs : Type u) (Outputs : Type v) : core.ops.function.Fn (Inputs → Result Outputs) Inputs Outputs := {
  FnMutInst := BuiltinFnMut Inputs Outputs
  call f x := f x
}

/-- `impl<A: Tuple, F: ?Sized + FnMut<A>> FnOnce<A> for &mut F` (core/src/ops/function.rs):
    `(*self).call_mut(args)`. The borrowed closure is a value: its updated state is what
    the consumed reference gives back. -/
@[rust_fun "core::ops::function::impls::{core::ops::function::FnOnce<&'0 mut @F, @A, @Clause0_Clause0_Output>}::call_once"]
def core.ops.function.FnOnceMutRef.call_once {F : Type u} {A : Type v} {Output : Type w}
    (inst : core.ops.function.FnMut F A Output) (f : F) (args : A) : Result (Output × F) :=
  inst.call_mut f args

@[reducible, rust_trait_impl "core::ops::function::FnOnce<&'0 mut @F, @A, @Clause0_Clause0_Output>"]
def core.ops.function.FnOnceMutRef {F : Type u} {A : Type v} {Output : Type w}
    (inst : core.ops.function.FnMut F A Output) : core.ops.function.FnOnce F A Output := {
  call_once := core.ops.function.FnOnceMutRef.call_once inst
}

/-- `impl<A: Tuple, F: ?Sized + FnMut<A>> FnMut<A> for &mut F`: `(**self).call_mut(args)`. -/
@[rust_fun "core::ops::function::impls::{core::ops::function::FnMut<&'0 mut @F, @A, @Clause0_Clause0_Output>}::call_mut"]
def core.ops.function.FnMutMutRef.call_mut {F : Type u} {A : Type v} {Output : Type w}
    (inst : core.ops.function.FnMut F A Output) (f : F) (args : A) : Result (Output × F) :=
  inst.call_mut f args

@[reducible, rust_trait_impl "core::ops::function::FnMut<&'0 mut @F, @A, @Clause0_Clause0_Output>"]
def core.ops.function.FnMutMutRef {F : Type u} {A : Type v} {Output : Type w}
    (inst : core.ops.function.FnMut F A Output) : core.ops.function.FnMut F A Output := {
  FnOnceInst := core.ops.function.FnOnceMutRef inst
  call_mut := core.ops.function.FnMutMutRef.call_mut inst
}

@[rust_trait "core::ops::try_trait::FromResidual"]
structure core.ops.try_trait.FromResidual (Self : Type u) (R : Type v) where
  from_residual : R → Result Self

@[rust_type "core::ops::control_flow::ControlFlow"]
inductive core.ops.control_flow.ControlFlow (B : Type) (C : Type) where
| Continue : C → core.ops.control_flow.ControlFlow B C
| Break : B → core.ops.control_flow.ControlFlow B C

@[rust_trait "core::ops::try_trait::Try" (parentClauses := ["FromResidualInst"])]
structure core.ops.try_trait.Try (Self Output Residual : Type) where
  FromResidualInst : core.ops.try_trait.FromResidual Self Residual
  from_output : Output → Result Self
  branch : Self → Result (core.ops.control_flow.ControlFlow Residual Output)

@[rust_trait "core::ops::try_trait::Residual" (parentClauses := ["TryInst"])]
structure core.ops.try_trait.Residual (Self O TryType: Type) where
  TryInst : core.ops.try_trait.Try TryType O Self

/-- `bool::then` (core/src/bool.rs): `if self { Some(f()) } else { None }`. The closure
    is called once when the condition holds, else dropped without being called. The model
    returns the closure's final state (the canonical state ABI of its input 1,
    `ModelStateABI.modeled_fun_abi`): its state after the call, or the closure unchanged when
    it is not called. A partial-monomorphization instance of `then` at a closure capturing
    mutable borrows gives back to them the values in this state. -/
@[rust_fun "core::bool::{bool}::then"]
def core.bool.Bool.then {T F : Type} (fnInst : core.ops.function.FnOnce F Unit T)
    (condition : Bool) (f : F) : Result (Option T × F) :=
  if condition then do
    let (value, f) ← fnInst.call_once f ()
    ok (some value, f)
  else ok (none, f)

namespace Std

namespace Aeneas
