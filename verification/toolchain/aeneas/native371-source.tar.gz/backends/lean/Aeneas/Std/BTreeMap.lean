import Aeneas.Std.Core.Borrow
import Aeneas.Std.Core.Iter
import Aeneas.Std.VecIter

namespace Aeneas.Std

/- This is an ordered-sequence abstraction, not Rust's physical B-tree shape.
Its refinement requires a total, deterministic, successful comparator consistent
with Eq/PartialEq; Borrow must preserve that order. No such laws follow from the
Ord/Borrow dictionaries themselves. All dictionary calls below remain effectful.
For unlawful, failing, or state-sensitive dictionaries, this executable model
makes no equivalence claim about Rust's tree-dependent comparison schedule.
Allocator identity, allocation failure and destructor effects are outside the
existing allocator-erased Aeneas collection abstraction. -/

@[rust_type "alloc::collections::btree::map::BTreeMap"
  (keepParams := [true, true, false]) (body := .opaque)]
structure alloc.collections.btree.map.BTreeMap (K V : Type) where
  entries : List (K × V)

@[rust_type "alloc::collections::btree::map::Iter" (body := .opaque)]
structure alloc.collections.btree.map.Iter (K V : Type) where
  remaining : List (K × V)

/-- `btree_map::Keys<'a, K, V>` is `{ inner: Iter<'a, K, V> }` (alloc
    collections/btree/map.rs, rustc 1.95). -/
@[rust_type "alloc::collections::btree::map::Keys" (body := .opaque)]
structure alloc.collections.btree.map.Keys (K V : Type) where
  inner : alloc.collections.btree.map.Iter K V

/-- `btree_map::Values<'a, K, V>` is `{ inner: Iter<'a, K, V> }`. -/
@[rust_type "alloc::collections::btree::map::Values" (body := .opaque)]
structure alloc.collections.btree.map.Values (K V : Type) where
  inner : alloc.collections.btree.map.Iter K V

/-- `btree_map::ValuesMut<'a, K, V>` is `{ inner: IterMut<'a, K, V> }` (map.rs, rustc 1.95): a
    lending iterator over the values in key order. Like the slice `IterMut`, the model retains
    the complete borrowed storage and the position of the next entry: `next` lends the value at
    that position, and its lens writes the value given back at the same position of a later
    state; `values_mut`'s restoration lens reads the map back from the final state. -/
@[rust_type "alloc::collections::btree::map::ValuesMut" (mutRegions := #[0]) (body := .opaque)]
structure alloc.collections.btree.map.ValuesMut (K V : Type) where
  entries : List (K × V)
  i : Nat := 0

@[rust_type "alloc::collections::btree::map::IntoIter"
  (keepParams := [true, true, false]) (body := .opaque)]
structure alloc.collections.btree.map.IntoIter (K V : Type) where
  remaining : List (K × V)

/-- `btree_map::IntoValues<K, V, A> { inner: IntoIter<K, V, A> }` (map.rs, rustc 1.95). -/
@[rust_type "alloc::collections::btree::map::IntoValues"
  (keepParams := [true, true, false]) (body := .opaque)]
structure alloc.collections.btree.map.IntoValues (K V : Type) where
  inner : alloc.collections.btree.map.IntoIter K V

/-- `removed` records that `remove`/`remove_entry` consumed the entry: ending the
map borrow then drops the pair instead of storing `value` back. -/
@[rust_type "alloc::collections::btree::map::entry::OccupiedEntry"
  (keepParams := [true, true, false]) (mutRegions := #[0]) (body := .opaque)]
structure alloc.collections.btree.map.entry.OccupiedEntry (K V : Type) where
  before : List (K × V)
  key : K
  value : V
  after : List (K × V)
  removed : Bool

/-- `value = none` is an uninserted entry. The backward result of insert carries
`some finalValue`, so ending the borrow installs the new entry exactly once. -/
@[rust_type "alloc::collections::btree::map::entry::VacantEntry"
  (keepParams := [true, true, false]) (mutRegions := #[0]) (body := .opaque)]
structure alloc.collections.btree.map.entry.VacantEntry (K V : Type) where
  before : List (K × V)
  key : K
  value : Option V
  after : List (K × V)

@[rust_type "alloc::collections::btree::map::entry::Entry"
  (keepParams := [true, true, false]) (mutRegions := #[0])]
inductive alloc.collections.btree.map.entry.Entry (K V : Type) where
  | Vacant : alloc.collections.btree.map.entry.VacantEntry K V → Entry K V
  | Occupied : alloc.collections.btree.map.entry.OccupiedEntry K V → Entry K V

namespace alloc.collections.btree.map

/-- The representation invariant, stated rather than forged for arbitrary Ord.
Clients proving refinement must establish it for maps they construct directly. -/
def BTreeMap.Ordered {K V : Type} (ord : core.cmp.Ord K) (map : BTreeMap K V) : Prop :=
  map.entries.Pairwise (fun left right => ord.cmp left.1 right.1 = .ok .lt)

@[rust_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, alloc::alloc::Global>}::new"]
def BTreeMap.new (K V : Type) : Result (BTreeMap K V) := .ok ⟨[]⟩

/-- `impl<K, V> Default for BTreeMap<K, V>` (btree/map.rs): `BTreeMap::new()`. -/
@[rust_fun "alloc::collections::btree::map::{core::default::Default<alloc::collections::btree::map::BTreeMap<@K, @V, alloc::alloc::Global>>}::default"]
def DefaultBTreeMap.default (K V : Type) : Result (BTreeMap K V) := .ok ⟨[]⟩

@[reducible, rust_trait_impl "core::default::Default<alloc::collections::btree::map::BTreeMap<@K, @V, alloc::alloc::Global>>"]
def DefaultBTreeMap (K V : Type) : core.default.Default (BTreeMap K V) := {
  default := DefaultBTreeMap.default K V
}

def insertList {K V : Type} (ord : core.cmp.Ord K) (key : K) (value : V) :
    List (K × V) → Result (Option V × List (K × V))
  | [] => .ok (none, [(key, value)])
  | (stored, old) :: rest => do
    match ← ord.cmp key stored with
    | .lt => .ok (none, (key, value) :: (stored, old) :: rest)
    | .eq => .ok (some old, (stored, value) :: rest)
    | .gt =>
      let (previous, rest) ← insertList ord key value rest
      .ok (previous, (stored, old) :: rest)

@[rust_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::insert"
  (keepParams := [true, true, false]) (keepTraitClauses := [false, true])]
def BTreeMap.insert {K V : Type} (ord : core.cmp.Ord K)
    (map : BTreeMap K V) (key : K) (value : V) : Result (Option V × BTreeMap K V) := do
  let (old, entries) ← insertList ord key value map.entries
  .ok (old, ⟨entries⟩)

/-- `BTreeMap::len` (btree/map.rs): the number of entries. Every native entry occupies
    memory, so a native map never exceeds `usize::MAX` entries; past that bound, which the
    model's unbounded list could reach, the model fails as the other size-bounded models do. -/
@[rust_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::len"
  (keepParams := [true, true, false]) (keepTraitClauses := [false])]
def BTreeMap.len {K V : Type} (map : BTreeMap K V) : Result Usize :=
  if h : map.entries.length < 2 ^ UScalarTy.Usize.numBits then
    .ok (Usize.ofNatCore map.entries.length h)
  else .fail .panic

/-- `Clone for BTreeMap<K, V, A>` (btree/map.rs `clone_subtree`): the same entries, each
    key cloned and then its value, in key order (the in-order traversal of the tree). -/
@[rust_fun "alloc::collections::btree::map::{core::clone::Clone<alloc::collections::btree::map::BTreeMap<@K, @V, @A>>}::clone"
  (keepParams := [true, true, false]) (keepTraitClauses := [true, true, false])]
def BTreeMap.clone {K V : Type} (keyClone : core.clone.Clone K) (valueClone : core.clone.Clone V)
    (map : BTreeMap K V) : Result (BTreeMap K V) := do
  let entries ← map.entries.mapM fun (key, value) => do
    let key ← keyClone.clone key
    .ok (key, ← valueClone.clone value)
  .ok ⟨entries⟩

def getList {K V Q : Type} (borrow : core.borrow.Borrow K Q) (ord : core.cmp.Ord Q)
    (query : Q) : List (K × V) → Result (Option V)
  | [] => .ok none
  | (key, value) :: rest => do
    match ← ord.cmp query (← borrow.borrow key) with
    | .lt => .ok none
    | .eq => .ok (some value)
    | .gt => getList borrow ord query rest

@[rust_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::get"
  (keepParams := [true, true, false, true]) (keepTraitClauses := [false, true, true, true])]
def BTreeMap.get {K V Q : Type} (borrow : core.borrow.Borrow K Q)
    (_keyOrd : core.cmp.Ord K) (ord : core.cmp.Ord Q) (map : BTreeMap K V)
    (query : Q) : Result (Option V) := getList borrow ord query map.entries

def getKeyValueList {K V Q : Type} (borrow : core.borrow.Borrow K Q) (ord : core.cmp.Ord Q)
    (query : Q) : List (K × V) → Result (Option (K × V))
  | [] => .ok none
  | (key, value) :: rest => do
    match ← ord.cmp query (← borrow.borrow key) with
    | .lt => .ok none
    | .eq => .ok (some (key, value))
    | .gt => getKeyValueList borrow ord query rest

/-- `BTreeMap::get_key_value` (btree/map.rs): `search_tree` as for `get`; the stored key
    and the value of the found entry. -/
@[rust_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::get_key_value"
  (keepParams := [true, true, false, true]) (keepTraitClauses := [false, true, true, true])]
def BTreeMap.get_key_value {K V Q : Type} (borrow : core.borrow.Borrow K Q)
    (_keyOrd : core.cmp.Ord K) (ord : core.cmp.Ord Q) (map : BTreeMap K V)
    (query : Q) : Result (Option (K × V)) := getKeyValueList borrow ord query map.entries

/-- `BTreeMap::clear` (btree/map.rs): the map is replaced by an empty one. -/
@[rust_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::clear"
  (keepParams := [true, true, false]) (keepTraitClauses := [false])]
def BTreeMap.clear {K V : Type} (_map : BTreeMap K V) : Result (BTreeMap K V) :=
  .ok ⟨[]⟩

/-- The entries around the value selected by `get`'s search: the entries before it
    (in order), its key and value, and the entries after it. -/
def getMutList {K V Q : Type} (borrow : core.borrow.Borrow K Q) (ord : core.cmp.Ord Q)
    (query : Q) (beforeRev : List (K × V)) :
    List (K × V) → Result (Option (List (K × V) × K × V × List (K × V)))
  | [] => .ok none
  | (key, value) :: rest => do
    match ← ord.cmp query (← borrow.borrow key) with
    | .lt => .ok none
    | .eq => .ok (some (beforeRev.reverse, key, value, rest))
    | .gt => getMutList borrow ord query ((key, value) :: beforeRev) rest

/-- `BTreeMap::get_mut` (btree/map.rs): `search_tree` as for `get`; the value of the
    found entry, borrowed mutably. The backward function writes the final value of
    that borrow in place, keeping the stored key and every other entry. -/
@[rust_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::get_mut"
  (keepParams := [true, true, false, true]) (keepTraitClauses := [false, true, true, true])]
def BTreeMap.get_mut {K V Q : Type} (borrow : core.borrow.Borrow K Q)
    (_keyOrd : core.cmp.Ord K) (ord : core.cmp.Ord Q) (map : BTreeMap K V)
    (query : Q) : Result (Option V × (Option V → BTreeMap K V)) := do
  match ← getMutList borrow ord query [] map.entries with
  | none => .ok (none, fun _ => map)
  | some (before, key, value, after) =>
    .ok (some value, fun
      | some value => ⟨before ++ (key, value) :: after⟩
      | none => map)

@[rust_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::contains_key"
  (keepParams := [true, true, false, true]) (keepTraitClauses := [false, true, true, true])]
def BTreeMap.contains_key {K V Q : Type} (borrow : core.borrow.Borrow K Q)
    (keyOrd : core.cmp.Ord K) (ord : core.cmp.Ord Q) (map : BTreeMap K V)
    (query : Q) : Result Bool := do
  .ok (← BTreeMap.get borrow keyOrd ord map query).isSome

def removeList {K V Q : Type} (borrow : core.borrow.Borrow K Q) (ord : core.cmp.Ord Q)
    (query : Q) : List (K × V) → Result (Option V × List (K × V))
  | [] => .ok (none, [])
  | (key, value) :: rest => do
    match ← ord.cmp query (← borrow.borrow key) with
    | .lt => .ok (none, (key, value) :: rest)
    | .eq => .ok (some value, rest)
    | .gt =>
      let (old, rest) ← removeList borrow ord query rest
      .ok (old, (key, value) :: rest)

@[rust_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::remove"
  (keepParams := [true, true, false, true]) (keepTraitClauses := [false, true, true, true])]
def BTreeMap.remove {K V Q : Type} (borrow : core.borrow.Borrow K Q)
    (_keyOrd : core.cmp.Ord K) (ord : core.cmp.Ord Q) (map : BTreeMap K V)
    (query : Q) : Result (Option V × BTreeMap K V) := do
  let (old, entries) ← removeList borrow ord query map.entries
  .ok (old, ⟨entries⟩)

/-- map.rs `Extend<(K, V)>`: `iter.into_iter().for_each(|(k, v)| { self.insert(k, v); })`.
`for_each` is Iterator's provided method, `self.fold((), call(f))`; the model
consumes through the dictionary's `fold`, so an Ord-equal key keeps the stored
key object and takes the new value, in iteration order. -/
@[rust_fun "alloc::collections::btree::map::{core::iter::traits::collect::Extend<alloc::collections::btree::map::BTreeMap<@K, @V, @A>, (@K, @V)>}::extend"
  (keepParams := [true, true, false, true, true]) (keepTraitClauses := [true, false, true])]
def ExtendBTreeMap.extend {K V T IntoIter : Type} (ord : core.cmp.Ord K)
    (into : core.iter.traits.collect.IntoIterator T (K × V) IntoIter)
    (self : BTreeMap K V) (input : T) : Result (Unit × BTreeMap K V × T) := do
  let (iter, recover) ← into.into_iter input
  let call := fun (map : BTreeMap K V) (args : Unit × (K × V)) => do
    let (_, map) ← BTreeMap.insert ord map args.2.1 args.2.2
    return ((), map)
  let fnInst : core.ops.function.FnMut (BTreeMap K V) (Unit × (K × V)) Unit :=
    { FnOnceInst := { call_once := call }, call_mut := call }
  let (_, iter, self) ← into.iteratorInst.fold fnInst iter () self
  return ((), self, recover iter)

@[rust_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::is_empty"
  (keepParams := [true, true, false]) (keepTraitClauses := [false])]
def BTreeMap.is_empty {K V : Type} (map : BTreeMap K V) : Result Bool :=
  .ok map.entries.isEmpty

@[rust_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::iter"
  (keepParams := [true, true, false]) (keepTraitClauses := [false])]
def BTreeMap.iter {K V : Type} (map : BTreeMap K V) : Result (Iter K V) :=
  .ok ⟨map.entries⟩

/-- `BTreeMap::keys`: `Keys { inner: self.iter() }`. -/
@[rust_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::keys"
  (keepParams := [true, true, false]) (keepTraitClauses := [false])]
def BTreeMap.keys {K V : Type} (map : BTreeMap K V) : Result (Keys K V) :=
  .ok ⟨⟨map.entries⟩⟩

/-- `BTreeMap::values`: `Values { inner: self.iter() }`. -/
@[rust_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::values"
  (keepParams := [true, true, false]) (keepTraitClauses := [false])]
def BTreeMap.values {K V : Type} (map : BTreeMap K V) : Result (Values K V) :=
  .ok ⟨⟨map.entries⟩⟩

/-- `BTreeMap::values_mut`: `ValuesMut { inner: self.iter_mut() }`, positioned before the first
    entry. The restoration lens gives back the map from the final iterator state. -/
@[rust_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::values_mut"
  (keepParams := [true, true, false]) (keepTraitClauses := [false])]
def BTreeMap.values_mut {K V : Type} (map : BTreeMap K V) :
    Result (ValuesMut K V × (ValuesMut K V → BTreeMap K V)) :=
  .ok ({ entries := map.entries }, fun it => ⟨it.entries⟩)

/-- The entry-wise comparison of `BTreeMap`'s `PartialEq::eq` after its length
    check: `self.iter().zip(other).all(|(a, b)| a == b)`, where the pair
    comparison is `a.0 == b.0 && a.1 == b.1` (core tuple `PartialEq`). -/
def eqEntries {K V : Type} (keyEq : core.cmp.PartialEq K K) (valueEq : core.cmp.PartialEq V V) :
    List (K × V) → List (K × V) → Result Bool
  | (k₁, v₁) :: left, (k₂, v₂) :: right => do
    if ← keyEq.eq k₁ k₂ then
      if ← valueEq.eq v₁ v₂ then eqEntries keyEq valueEq left right else .ok false
    else .ok false
  | _, _ => .ok true

/-- `impl PartialEq for BTreeMap` (alloc collections/btree/map.rs): equal lengths,
    then the entries pairwise in key order, stopping at the first unequal key or
    value. -/
@[rust_fun "alloc::collections::btree::map::{core::cmp::PartialEq<alloc::collections::btree::map::BTreeMap<@K, @V, @A>, alloc::collections::btree::map::BTreeMap<@K, @V, @A>>}::eq"
  (keepParams := [true, true, false]) (keepTraitClauses := [true, true, false])]
def PartialEqBTreeMap.eq {K V : Type} (keyEq : core.cmp.PartialEq K K)
    (valueEq : core.cmp.PartialEq V V) (left right : BTreeMap K V) : Result Bool :=
  if left.entries.length = right.entries.length then
    eqEntries keyEq valueEq left.entries right.entries
  else .ok false

/-- `ne` is `PartialEq`'s default, `!self.eq(other)`. -/
@[rust_fun "alloc::collections::btree::map::{core::cmp::PartialEq<alloc::collections::btree::map::BTreeMap<@K, @V, @A>, alloc::collections::btree::map::BTreeMap<@K, @V, @A>>}::ne"
  (keepParams := [true, true, false]) (keepTraitClauses := [true, true, false])]
def PartialEqBTreeMap.ne {K V : Type} (keyEq : core.cmp.PartialEq K K)
    (valueEq : core.cmp.PartialEq V V) (left right : BTreeMap K V) : Result Bool := do
  .ok (not (← PartialEqBTreeMap.eq keyEq valueEq left right))

/-- `impl<K: PartialEq, V: PartialEq, A: Allocator + Clone> PartialEq for BTreeMap<K, V, A>`. -/
@[reducible, rust_trait_impl "core::cmp::PartialEq<alloc::collections::btree::map::BTreeMap<@K, @V, @A>, alloc::collections::btree::map::BTreeMap<@K, @V, @A>>"
  (keepParams := [true, true, false]) (keepTraitClauses := [true, true, false])]
def PartialEqBTreeMap {K V : Type} (keyEq : core.cmp.PartialEq K K)
    (valueEq : core.cmp.PartialEq V V) : core.cmp.PartialEq (BTreeMap K V) (BTreeMap K V) := {
  eq := PartialEqBTreeMap.eq keyEq valueEq
  ne := PartialEqBTreeMap.ne keyEq valueEq
}

/-- `impl<K: Debug, V: Debug, A: Allocator + Clone> Debug for BTreeMap<K, V, A>`
    (alloc collections/btree/map.rs): `f.debug_map().entries(self.iter()).finish()`,
    the entries in key order. -/
@[rust_fun "alloc::collections::btree::map::{core::fmt::Debug<alloc::collections::btree::map::BTreeMap<@K, @V, @A>>}::fmt"
  (keepParams := [true, true, false]) (keepTraitClauses := [true, true, false])]
def DebugBTreeMap.fmt {K V : Type} (keyDebug : core.fmt.Debug K) (valueDebug : core.fmt.Debug V)
    (map : BTreeMap K V) (fmt : core.fmt.Formatter) : core.fmt.Outcome :=
  fmt.debugMap keyDebug valueDebug map.entries

@[reducible, rust_trait_impl "core::fmt::Debug<alloc::collections::btree::map::BTreeMap<@K, @V, @A>>"
  (keepParams := [true, true, false]) (keepTraitClauses := [true, true, false])]
def DebugBTreeMap {K V : Type} (keyDebug : core.fmt.Debug K) (valueDebug : core.fmt.Debug V) :
    core.fmt.Debug (BTreeMap K V) :=
  ⟨DebugBTreeMap.fmt keyDebug valueDebug⟩

def entry.Entry.restore {K V : Type} : entry.Entry K V → BTreeMap K V
  | .Occupied e => ⟨e.before ++ (if e.removed then e.after else (e.key, e.value) :: e.after)⟩
  | .Vacant e => ⟨e.before ++ (match e.value with
      | none => e.after
      | some value => (e.key, value) :: e.after)⟩

def entryList {K V : Type} (ord : core.cmp.Ord K) (key : K)
    (beforeRev : List (K × V)) : List (K × V) → Result (entry.Entry K V)
  | [] => .ok (.Vacant ⟨beforeRev.reverse, key, none, []⟩)
  | (stored, value) :: rest => do
    match ← ord.cmp key stored with
    | .lt => .ok (.Vacant ⟨beforeRev.reverse, key, none, (stored, value) :: rest⟩)
    | .eq => .ok (.Occupied ⟨beforeRev.reverse, stored, value, rest, false⟩)
    | .gt => entryList ord key ((stored, value) :: beforeRev) rest

@[rust_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::entry"
  (keepParams := [true, true, false]) (keepTraitClauses := [false, true])]
def BTreeMap.entry {K V : Type} (ord : core.cmp.Ord K) (map : BTreeMap K V)
    (key : K) : Result (entry.Entry K V × (entry.Entry K V → BTreeMap K V)) := do
  let selected ← entryList ord key [] map.entries
  .ok (selected, entry.Entry.restore)

@[rust_fun "alloc::collections::btree::map::entry::{alloc::collections::btree::map::entry::OccupiedEntry<'a, @K, @V, @A>}::into_mut"
  (keepParams := [true, true, false]) (keepTraitClauses := [true, false])]
def entry.OccupiedEntry.into_mut {K V : Type} (_ord : core.cmp.Ord K)
    (e : entry.OccupiedEntry K V) : Result (V × (V → entry.OccupiedEntry K V)) :=
  .ok (e.value, fun value => { e with value })

@[rust_fun "alloc::collections::btree::map::entry::{alloc::collections::btree::map::entry::VacantEntry<'a, @K, @V, @A>}::insert"
  (keepParams := [true, true, false]) (keepTraitClauses := [true, false])]
def entry.VacantEntry.insert {K V : Type} (_ord : core.cmp.Ord K)
    (e : entry.VacantEntry K V) (value : V) : Result (V × (V → entry.VacantEntry K V)) :=
  .ok (value, fun finalValue => { e with value := some finalValue })

/-- `Entry::key` (btree/map/entry.rs): the stored key of an occupied entry, the
probe of a vacant one. The other `Entry` methods that production code calls
(`or_insert`, `or_insert_with`, `or_default`, `insert_entry`) are translated from
std's bodies (Charon `--include` of the `Entry` impl), which call the entry
operations modeled here. std's exported bodies of `key`, `and_modify` and
`or_insert_with_key` inline the B-tree handle internals: `key` is modeled here;
the other two take closures and are not supported (their translation stops at
the node types). -/
@[rust_fun "alloc::collections::btree::map::entry::{alloc::collections::btree::map::entry::Entry<'a, @K, @V, @A>}::key"
  (keepParams := [true, true, false]) (keepTraitClauses := [true, false])]
def entry.Entry.key {K V : Type} (_ord : core.cmp.Ord K) (e : entry.Entry K V) : Result K :=
  match e with
  | .Occupied occupied => .ok occupied.key
  | .Vacant vacant => .ok vacant.key

/-- `VacantEntry::insert_entry` (btree/map/entry.rs): the occupied entry of the
inserted pair. Ending it stores its final value into the vacant carrier, or
nothing if it was removed meanwhile. -/
@[rust_fun "alloc::collections::btree::map::entry::{alloc::collections::btree::map::entry::VacantEntry<'a, @K, @V, @A>}::insert_entry"
  (keepParams := [true, true, false]) (keepTraitClauses := [true, false])]
def entry.VacantEntry.insert_entry {K V : Type} (_ord : core.cmp.Ord K)
    (e : entry.VacantEntry K V) (value : V) :
    Result (entry.OccupiedEntry K V × (entry.OccupiedEntry K V → entry.VacantEntry K V)) :=
  .ok (⟨e.before, e.key, value, e.after, false⟩,
    fun occupied => { e with value := if occupied.removed then none else some occupied.value })

/-- `VacantEntry::key`: the key given to `BTreeMap::entry`. -/
@[rust_fun "alloc::collections::btree::map::entry::{alloc::collections::btree::map::entry::VacantEntry<'a, @K, @V, @A>}::key"
  (keepParams := [true, true, false]) (keepTraitClauses := [true, false])]
def entry.VacantEntry.key_ {K V : Type} (_ord : core.cmp.Ord K) (e : entry.VacantEntry K V) :
    Result K :=
  .ok e.key

/-- `VacantEntry::into_key`: takes the key back; the map is unchanged. -/
@[rust_fun "alloc::collections::btree::map::entry::{alloc::collections::btree::map::entry::VacantEntry<'a, @K, @V, @A>}::into_key"
  (keepParams := [true, true, false]) (keepTraitClauses := [true, false])]
def entry.VacantEntry.into_key {K V : Type} (_ord : core.cmp.Ord K) (e : entry.VacantEntry K V) :
    Result (K × entry.VacantEntry K V) :=
  .ok (e.key, e)

/-- `OccupiedEntry::key`: the stored key, not the one given to `BTreeMap::entry`. -/
@[rust_fun "alloc::collections::btree::map::entry::{alloc::collections::btree::map::entry::OccupiedEntry<'a, @K, @V, @A>}::key"
  (keepParams := [true, true, false]) (keepTraitClauses := [true, false])]
def entry.OccupiedEntry.key_ {K V : Type} (_ord : core.cmp.Ord K) (e : entry.OccupiedEntry K V) :
    Result K :=
  .ok e.key

@[rust_fun "alloc::collections::btree::map::entry::{alloc::collections::btree::map::entry::OccupiedEntry<'a, @K, @V, @A>}::get"
  (keepParams := [true, true, false]) (keepTraitClauses := [true, false])]
def entry.OccupiedEntry.get {K V : Type} (_ord : core.cmp.Ord K) (e : entry.OccupiedEntry K V) :
    Result V :=
  .ok e.value

/-- `OccupiedEntry::get_mut`: the value borrow writes back into the entry; the
entry's own borrow of the map is unchanged. -/
@[rust_fun "alloc::collections::btree::map::entry::{alloc::collections::btree::map::entry::OccupiedEntry<'a, @K, @V, @A>}::get_mut"
  (keepParams := [true, true, false]) (keepTraitClauses := [true, false])]
def entry.OccupiedEntry.get_mut {K V : Type} (_ord : core.cmp.Ord K) (e : entry.OccupiedEntry K V) :
    Result (V × (V → entry.OccupiedEntry K V) × (entry.OccupiedEntry K V → entry.OccupiedEntry K V)) :=
  .ok (e.value, fun value => { e with value }, fun e => e)

/-- `OccupiedEntry::insert`: `mem::replace(self.get_mut(), value)`, the previous
value; the stored key stays. -/
@[rust_fun "alloc::collections::btree::map::entry::{alloc::collections::btree::map::entry::OccupiedEntry<'a, @K, @V, @A>}::insert"
  (keepParams := [true, true, false]) (keepTraitClauses := [true, false])]
def entry.OccupiedEntry.insert {K V : Type} (_ord : core.cmp.Ord K) (e : entry.OccupiedEntry K V)
    (value : V) :
    Result (V × entry.OccupiedEntry K V × (entry.OccupiedEntry K V → entry.OccupiedEntry K V)) :=
  .ok (e.value, { e with value }, fun e => e)

/-- `OccupiedEntry::remove`: `self.remove_kv().1`; ending the map borrow drops the pair. -/
@[rust_fun "alloc::collections::btree::map::entry::{alloc::collections::btree::map::entry::OccupiedEntry<'a, @K, @V, @A>}::remove"
  (keepParams := [true, true, false]) (keepTraitClauses := [true, false])]
def entry.OccupiedEntry.remove {K V : Type} (_ord : core.cmp.Ord K) (e : entry.OccupiedEntry K V) :
    Result (V × entry.OccupiedEntry K V) :=
  .ok (e.value, { e with removed := true })

/-- `OccupiedEntry::remove_entry`: `self.remove_kv()`, the stored key and the value. -/
@[rust_fun "alloc::collections::btree::map::entry::{alloc::collections::btree::map::entry::OccupiedEntry<'a, @K, @V, @A>}::remove_entry"
  (keepParams := [true, true, false]) (keepTraitClauses := [true, false])]
def entry.OccupiedEntry.remove_entry {K V : Type} (_ord : core.cmp.Ord K)
    (e : entry.OccupiedEntry K V) : Result ((K × V) × entry.OccupiedEntry K V) :=
  .ok ((e.key, e.value), { e with removed := true })

/-- Ending an occupied borrow preserves both surrounding segments and stored key. -/
theorem entry.restore_occupied {K V : Type} (e : entry.OccupiedEntry K V) (value : V) :
    (entry.Entry.restore (.Occupied {e with value, removed := false})).entries =
      e.before ++ (e.key, value) :: e.after := rfl

/-- A removed entry leaves exactly the surrounding segments. -/
theorem entry.restore_removed {K V : Type} (e : entry.OccupiedEntry K V) :
    (entry.Entry.restore (.Occupied {e with removed := true})).entries =
      e.before ++ e.after := rfl

/-- The vacant carrier returned backwards contains the insertion, including edits
through the returned mutable reference, without duplicating the captured key. -/
theorem entry.restore_inserted {K V : Type} (e : entry.VacantEntry K V) (value : V) :
    (entry.Entry.restore (.Vacant {e with value := some value})).entries =
      e.before ++ (e.key, value) :: e.after := rfl

theorem entry.restore_uninserted {K V : Type} (before after : List (K × V)) (key : K) :
    (entry.Entry.restore (.Vacant ⟨before, key, none, after⟩)).entries = before ++ after := rfl

@[rust_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Iter<'a, @K, @V>, (&'a @K, &'a @V)>}::next"]
def IteratorIter.next {K V : Type} (it : Iter K V) : Result (Option (K × V) × Iter K V) :=
  match it.remaining with
  | [] => .ok (none, it)
  | item :: rest => .ok (some item, ⟨rest⟩)

@[rust_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::IntoIter<@K, @V, @A>, (@K, @V)>}::next"
  (keepParams := [true, true, false]) (keepTraitClauses := [false])]
def IteratorIntoIter.next {K V : Type} (it : IntoIter K V) :
    Result (Option (K × V) × IntoIter K V) :=
  match it.remaining with
  | [] => .ok (none, it)
  | item :: rest => .ok (some item, ⟨rest⟩)

@[rust_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Iter<'a, @K, @V>, (&'a @K, &'a @V)>}::size_hint"]
def IteratorIter.size_hint {K V : Type} (it : Iter K V) :
    Result (Usize × Option Usize) := do
  let length ← UScalar.tryMk .Usize it.remaining.length
  .ok (length, some length)

@[rust_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::IntoIter<@K, @V, @A>, (@K, @V)>}::size_hint"
  (keepParams := [true, true, false]) (keepTraitClauses := [false])]
def IteratorIntoIter.size_hint {K V : Type} (it : IntoIter K V) :
    Result (Usize × Option Usize) := do
  let length ← UScalar.tryMk .Usize it.remaining.length
  .ok (length, some length)

/-- `BTreeMap::into_values` (map.rs, rustc 1.95): `IntoValues { inner: self.into_iter() }`, the
    values in key order. -/
@[rust_fun "alloc::collections::btree::map::{alloc::collections::btree::map::BTreeMap<@K, @V, @A>}::into_values"
  (keepParams := [true, true, false]) (keepTraitClauses := [false])]
def BTreeMap.into_values {K V : Type} (map : BTreeMap K V) : Result (IntoValues K V) :=
  .ok ⟨⟨map.entries⟩⟩

/-- `Iterator for IntoValues` (map.rs): `next` is `self.inner.next().map(|(_, v)| v)`. -/
@[rust_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::IntoValues<@K, @V, @A>, @V>}::next"
  (keepParams := [true, true, false]) (keepTraitClauses := [false])]
def IteratorIntoValues.next {K V : Type} (it : IntoValues K V) :
    Result (Option V × IntoValues K V) := do
  let (item, inner) ← IteratorIntoIter.next it.inner
  .ok (item.map Prod.snd, ⟨inner⟩)

/-- `size_hint` is `self.inner.size_hint()`. -/
@[rust_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::IntoValues<@K, @V, @A>, @V>}::size_hint"
  (keepParams := [true, true, false]) (keepTraitClauses := [false])]
def IteratorIntoValues.size_hint {K V : Type} (it : IntoValues K V) :
    Result (Usize × Option Usize) :=
  IteratorIntoIter.size_hint it.inner

/-- `Keys::next`: `self.inner.next().map(|(k, _)| k)`. -/
@[rust_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Keys<'a, @K, @V>, &'a @K>}::next"]
def IteratorKeys.next {K V : Type} (it : Keys K V) : Result (Option K × Keys K V) := do
  let (item, inner) ← IteratorIter.next it.inner
  .ok (item.map (·.1), ⟨inner⟩)

/-- `Keys::size_hint`: `self.inner.size_hint()`. -/
@[rust_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Keys<'a, @K, @V>, &'a @K>}::size_hint"]
def IteratorKeys.size_hint {K V : Type} (it : Keys K V) : Result (Usize × Option Usize) :=
  IteratorIter.size_hint it.inner

/-- `Values::next`: `self.inner.next().map(|(_, v)| v)`. -/
@[rust_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Values<'a, @K, @V>, &'a @V>}::next"]
def IteratorValues.next {K V : Type} (it : Values K V) : Result (Option V × Values K V) := do
  let (item, inner) ← IteratorIter.next it.inner
  .ok (item.map (·.2), ⟨inner⟩)

/-- `ValuesMut::next`: `self.inner.next().map(|(_, v)| v)`, lending the value of the entry at
    the iterator's position. The lens writes the value given back (if any) at that position of a
    later state, keeping its key; an exhausted iterator gives nothing back. -/
@[rust_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::ValuesMut<'a, @K, @V>, &'a mut @V>}::next"]
def IteratorValuesMut.next {K V : Type} (it : ValuesMut K V) :
    Result (Option V × ValuesMut K V × (ValuesMut K V → Option V → ValuesMut K V)) :=
  match it.entries[it.i]? with
  | none => .ok (none, it, fun it _ => it)
  | some (_, v) =>
    let i := it.i
    let back (it' : ValuesMut K V) (x : Option V) : ValuesMut K V :=
      match x with
      | none => it'
      | some x => { it' with entries := it'.entries.modify i (fun (k, _) => (k, x)) }
    .ok (some v, { it with i := i + 1 }, back)

/-- `Values::size_hint`: `self.inner.size_hint()`. -/
@[rust_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Values<'a, @K, @V>, &'a @V>}::size_hint"]
def IteratorValues.size_hint {K V : Type} (it : Values K V) : Result (Usize × Option Usize) :=
  IteratorIter.size_hint it.inner

@[rust_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Iter<'a, @K, @V>, (&'a @K, &'a @V)>}::step_by"]
def IteratorIter.step_by {K V : Type} (it : Iter K V) (n : Usize) :
    Result (core.iter.adapters.step_by.StepBy (Iter K V)) :=
  core.iter.traits.iterator.Iterator.step_by.default it n

@[rust_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Iter<'a, @K, @V>, (&'a @K, &'a @V)>}::enumerate"]
def IteratorIter.enumerate {K V : Type} (it : Iter K V) :
    Result (core.iter.adapters.enumerate.Enumerate (Iter K V)) := .ok ⟨it, 0#usize⟩

@[rust_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Iter<'a, @K, @V>, (&'a @K, &'a @V)>}::take"]
def IteratorIter.take {K V : Type} (it : Iter K V) (n : Usize) :
    Result (core.iter.adapters.take.Take (Iter K V)) := .ok ⟨it, n⟩

@[rust_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::IntoIter<@K, @V, @A>, (@K, @V)>}::step_by"
  (keepParams := [true, true, false]) (keepTraitClauses := [false])]
def IteratorIntoIter.step_by {K V : Type} (it : IntoIter K V) (n : Usize) :
    Result (core.iter.adapters.step_by.StepBy (IntoIter K V)) :=
  core.iter.traits.iterator.Iterator.step_by.default it n

@[rust_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::IntoIter<@K, @V, @A>, (@K, @V)>}::enumerate"
  (keepParams := [true, true, false]) (keepTraitClauses := [false])]
def IteratorIntoIter.enumerate {K V : Type} (it : IntoIter K V) :
    Result (core.iter.adapters.enumerate.Enumerate (IntoIter K V)) := .ok ⟨it, 0#usize⟩

@[rust_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::IntoIter<@K, @V, @A>, (@K, @V)>}::take"
  (keepParams := [true, true, false]) (keepTraitClauses := [false])]
def IteratorIntoIter.take {K V : Type} (it : IntoIter K V) (n : Usize) :
    Result (core.iter.adapters.take.Take (IntoIter K V)) := .ok ⟨it, n⟩

end alloc.collections.btree.map

open alloc.collections.btree.map

@[reducible, rust_trait_impl "core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Iter<'a, @K, @V>, (&'a @K, &'a @V)>"]
def core.iter.traits.iterator.IteratorBTreeIter (K V : Type) :
    core.iter.traits.iterator.Iterator (Iter K V) (K × V) := {
  next := IteratorIter.next
  size_hint := IteratorIter.size_hint
  trusted_len := true
  fused := true
  step_by := IteratorIter.step_by
  enumerate := IteratorIter.enumerate
  take := IteratorIter.take
}

@[reducible, rust_trait_impl "core::iter::traits::iterator::Iterator<alloc::collections::btree::map::IntoIter<@K, @V, @A>, (@K, @V)>"
  (keepParams := [true, true, false]) (keepTraitClauses := [false])]
def core.iter.traits.iterator.IteratorBTreeIntoIter (K V : Type) :
    core.iter.traits.iterator.Iterator (IntoIter K V) (K × V) := {
  next := IteratorIntoIter.next
  size_hint := IteratorIntoIter.size_hint
  trusted_len := true
  fused := true
  step_by := IteratorIntoIter.step_by
  enumerate := IteratorIntoIter.enumerate
  take := IteratorIntoIter.take
}

/-- `impl Iterator for IntoValues` defines `next`, `size_hint` and `last` (`self.next_back()`,
    unmodeled); `IntoValues` is `TrustedLen` and `FusedIterator`. -/
@[reducible, rust_trait_impl "core::iter::traits::iterator::Iterator<alloc::collections::btree::map::IntoValues<@K, @V, @A>, @V>"
  (keepParams := [true, true, false]) (keepTraitClauses := [false])]
def core.iter.traits.iterator.IteratorBTreeIntoValues (K V : Type) :
    core.iter.traits.iterator.Iterator (IntoValues K V) V := {
  next := IteratorIntoValues.next
  size_hint := IteratorIntoValues.size_hint
  trusted_len := true
  fused := true
}

/-- `impl Iterator for Keys` overrides `next`, `size_hint`, `last`, `min` and
    `max` (the last three unmodeled); `Keys` is `TrustedLen` and `FusedIterator`. -/
@[reducible, rust_trait_impl "core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Keys<'a, @K, @V>, &'a @K>"]
def core.iter.traits.iterator.IteratorBTreeKeys (K V : Type) :
    core.iter.traits.iterator.Iterator (Keys K V) K := {
  next := IteratorKeys.next
  size_hint := IteratorKeys.size_hint
  trusted_len := true
  fused := true
}

/-- `impl Iterator for Values` overrides `next`, `size_hint` and `last` (unmodeled);
    `Values` is `TrustedLen` and `FusedIterator`. -/
@[reducible, rust_trait_impl "core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Values<'a, @K, @V>, &'a @V>"]
def core.iter.traits.iterator.IteratorBTreeValues (K V : Type) :
    core.iter.traits.iterator.Iterator (Values K V) V := {
  next := IteratorValues.next
  size_hint := IteratorValues.size_hint
  trusted_len := true
  fused := true
}

namespace alloc.collections.btree.map

@[rust_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::Iter<'a, @K, @V>, (&'a @K, &'a @V)>}::collect"]
def IteratorIter.collect {K V B : Type} (collect : core.iter.traits.collect.FromIterator B (K × V))
    (it : Iter K V) : Result (B × Iter K V) :=
  core.iter.traits.iterator.Iterator.collect.default
    (core.iter.traits.iterator.IteratorBTreeIter K V) collect it

@[rust_fun "alloc::collections::btree::map::{core::iter::traits::iterator::Iterator<alloc::collections::btree::map::IntoIter<@K, @V, @A>, (@K, @V)>}::collect"
  (keepParams := [true, true, false, true]) (keepTraitClauses := [false, true])]
def IteratorIntoIter.collect {K V B : Type} (collect : core.iter.traits.collect.FromIterator B (K × V))
    (it : IntoIter K V) : Result (B × IntoIter K V) :=
  core.iter.traits.iterator.Iterator.collect.default
    (core.iter.traits.iterator.IteratorBTreeIntoIter K V) collect it

/-- Recovery reconstructs the map of actual unconsumed entries, not the moved
entries already yielded. The typed adapter must reject conversions requiring
full-state recovery of mutable ownership contained in keys or values. -/
@[rust_fun "alloc::collections::btree::map::{core::iter::traits::collect::IntoIterator<alloc::collections::btree::map::BTreeMap<@K, @V, @A>, (@K, @V), alloc::collections::btree::map::IntoIter<@K, @V, @A>>}::into_iter"
  (keepParams := [true, true, false]) (keepTraitClauses := [false])]
def IntoIteratorBTreeMap.into_iter {K V : Type} (map : BTreeMap K V) :
    Result (IntoIter K V × (IntoIter K V → BTreeMap K V)) :=
  .ok (⟨map.entries⟩, fun iterator => ⟨iterator.remaining⟩)

/-- `impl IntoIterator for &'a BTreeMap<K, V, A>` (map.rs:1564-1571): `self.iter()`.
The borrowed map is not changed: recovery returns it whatever the iterator state. -/
@[rust_fun "alloc::collections::btree::map::{core::iter::traits::collect::IntoIterator<&'a alloc::collections::btree::map::BTreeMap<@K, @V, @A>, (&'a @K, &'a @V), alloc::collections::btree::map::Iter<'a, @K, @V>>}::into_iter"
  (keepParams := [true, true, false]) (keepTraitClauses := [false])]
def IntoIteratorSharedBTreeMap.into_iter {K V : Type} (map : BTreeMap K V) :
    Result (Iter K V × (Iter K V → BTreeMap K V)) := do
  let iterator ← BTreeMap.iter map
  .ok (iterator, fun _ => map)

/-- Stable insertion into an already sorted sequence: later equivalent keys go
AFTER earlier keys. This is intentionally not map insert, which retains a key. -/
def stableInsert {K V : Type} (ord : core.cmp.Ord K) (item : K × V) :
    List (K × V) → Result (List (K × V))
  | [] => .ok [item]
  | next :: rest => do
    match ← ord.cmp item.1 next.1 with
    | .lt => .ok (item :: next :: rest)
    | _ => return next :: (← stableInsert ord item rest)

def stableSort {K V : Type} (ord : core.cmp.Ord K) :
    List (K × V) → List (K × V) → Result (List (K × V))
  | [], sorted => .ok sorted
  | item :: rest, sorted => do
    stableSort ord rest (← stableInsert ord item sorted)

/-- Native Rust 1.98.0 commit 88d9e12ae178fab0fb5cc050a94da85685d449ea.
Vec collection precedes stable key sorting and bulk construction.
DedupSortedIter retains the last complete pair of each equal-key run.
Comparator schedules retain the existing schedule-independence boundary. -/
def dedupSorted {K V : Type} (eq : core.cmp.PartialEq K K) (current : K × V) :
    List (K × V) → Result (List (K × V))
  | [] => .ok [current]
  | next :: rest => do
    if ← eq.ne current.1 next.1 then
      return current :: (← dedupSorted eq next rest)
    else dedupSorted eq next rest

@[rust_fun "alloc::collections::btree::map::{core::iter::traits::collect::FromIterator<alloc::collections::btree::map::BTreeMap<@K, @V, alloc::alloc::Global>, (@K, @V)>}::from_iter"]
def FromIteratorBTreeMap.from_iter {K V T IntoIter : Type} (ord : core.cmp.Ord K)
    (into : core.iter.traits.collect.IntoIterator T (K × V) IntoIter)
    (input : T) : Result (BTreeMap K V × T) := do
  let (iterator, recover) ← into.into_iter input
  let (items, iterator) ← alloc.vec.FromIteratorVec.collectNative into.iteratorInst iterator
  let sorted ← stableSort ord items []
  match sorted with
  | [] => .ok (⟨[]⟩, recover iterator)
  | first :: rest =>
    let entries ← dedupSorted ord.eqInst.partialEqInst first rest
    .ok (⟨entries⟩, recover iterator)

/-- `impl<K: Ord, V, const N: usize> From<[(K, V); N]> for BTreeMap<K, V>` (map.rs 2497-2518):
    `if N == 0 { return BTreeMap::new(); }`, then `arr.sort_by(|a, b| a.0.cmp(&b.0))` (stable) and
    `bulk_build_from_sorted_iter`, whose `DedupSortedIter` keeps the last whole pair of each run of
    equal keys (as `FromIteratorBTreeMap.from_iter`). -/
@[rust_fun "alloc::collections::btree::map::{core::convert::From<alloc::collections::btree::map::BTreeMap<@K, @V, alloc::alloc::Global>, [(@K, @V); @N]>}::from"]
def FromBTreeMapArray.from_ {K V : Type} {N : Usize} (ord : core.cmp.Ord K)
    (arr : Array (K × V) N) : Result (BTreeMap K V) := do
  if N.val = 0 then return ⟨[]⟩
  match ← stableSort ord arr.val [] with
  | [] => .ok ⟨[]⟩
  | first :: rest => .ok ⟨← dedupSorted ord.eqInst.partialEqInst first rest⟩

end alloc.collections.btree.map

@[reducible, rust_trait_impl "core::convert::From<alloc::collections::btree::map::BTreeMap<@K, @V, alloc::alloc::Global>, [(@K, @V); @N]>"]
def core.convert.FromBTreeMapArray {K : Type} (V : Type) (N : Usize) (ord : core.cmp.Ord K) :
    core.convert.From (BTreeMap K V) (Array (K × V) N) := {
  from_ := alloc.collections.btree.map.FromBTreeMapArray.from_ ord
}

@[reducible, rust_trait_impl "core::iter::traits::collect::IntoIterator<alloc::collections::btree::map::BTreeMap<@K, @V, @A>, (@K, @V), alloc::collections::btree::map::IntoIter<@K, @V, @A>>"
  (keepParams := [true, true, false]) (keepTraitClauses := [false])]
def core.iter.traits.collect.IntoIteratorBTreeMap (K V : Type) :
    core.iter.traits.collect.IntoIterator (BTreeMap K V) (K × V) (IntoIter K V) := {
  iteratorInst := core.iter.traits.iterator.IteratorBTreeIntoIter K V
  into_iter := alloc.collections.btree.map.IntoIteratorBTreeMap.into_iter
}

@[reducible, rust_trait_impl "core::iter::traits::collect::IntoIterator<&'a alloc::collections::btree::map::BTreeMap<@K, @V, @A>, (&'a @K, &'a @V), alloc::collections::btree::map::Iter<'a, @K, @V>>"
  (keepParams := [true, true, false]) (keepTraitClauses := [false])]
def core.iter.traits.collect.IntoIteratorSharedBTreeMap (K V : Type) :
    core.iter.traits.collect.IntoIterator (BTreeMap K V) (K × V) (Iter K V) := {
  iteratorInst := core.iter.traits.iterator.IteratorBTreeIter K V
  into_iter := alloc.collections.btree.map.IntoIteratorSharedBTreeMap.into_iter
}

@[reducible, rust_trait_impl "core::iter::traits::collect::FromIterator<alloc::collections::btree::map::BTreeMap<@K, @V, alloc::alloc::Global>, (@K, @V)>"]
def core.iter.traits.collect.FromIteratorBTreeMap {K : Type} (V : Type) (ord : core.cmp.Ord K) :
    core.iter.traits.collect.FromIterator (BTreeMap K V) (K × V) := {
  from_iter := alloc.collections.btree.map.FromIteratorBTreeMap.from_iter ord
}

@[reducible, rust_trait_impl "core::iter::traits::collect::Extend<alloc::collections::btree::map::BTreeMap<@K, @V, @A>, (@K, @V)>"
  (keepParams := [true, true, false]) (keepTraitClauses := [true, false])]
def core.iter.traits.collect.ExtendBTreeMap {K : Type} (V : Type) (ord : core.cmp.Ord K) :
    core.iter.traits.collect.Extend (alloc.collections.btree.map.BTreeMap K V) (K × V) := {
  extend := alloc.collections.btree.map.ExtendBTreeMap.extend ord
}


/-- map.rs `impl Index<&Q> for BTreeMap<K, V, A>` (`K: Borrow<Q> + Ord, Q: Ord`,
`A: Allocator + Clone`): `self.get(key).expect("no entry found for key")`, a panic
when the key is missing. -/
@[rust_fun "alloc::collections::btree::map::{core::ops::index::Index<alloc::collections::btree::map::BTreeMap<@K, @V, @A>, &'0 @Q, @V>}::index"
  (keepParams := [true, true, true, false]) (keepTraitClauses := [false, true, true, true])]
def alloc.collections.btree.map.IndexBTreeMap.index {K Q V : Type}
    (borrow : core.borrow.Borrow K Q) (keyOrd : core.cmp.Ord K) (ord : core.cmp.Ord Q)
    (map : alloc.collections.btree.map.BTreeMap K V) (key : Q) : Result V := do
  match ← alloc.collections.btree.map.BTreeMap.get borrow keyOrd ord map key with
  | some value => .ok value
  | none => .fail .panic

@[reducible, rust_trait_impl "core::ops::index::Index<alloc::collections::btree::map::BTreeMap<@K, @V, @A>, &'0 @Q, @V>"
  (keepParams := [true, true, true, false]) (keepTraitClauses := [false, true, true, true])]
def core.ops.index.IndexBTreeMap {K Q : Type} (V : Type)
    (borrow : core.borrow.Borrow K Q) (keyOrd : core.cmp.Ord K) (ord : core.cmp.Ord Q) :
    core.ops.index.Index (alloc.collections.btree.map.BTreeMap K V) Q V := {
  index := alloc.collections.btree.map.IndexBTreeMap.index borrow keyOrd ord
}

end Aeneas.Std
