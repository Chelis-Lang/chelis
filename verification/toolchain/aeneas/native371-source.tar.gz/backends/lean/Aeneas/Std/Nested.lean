/- Carriers for collections nested in recursive types -/
import Aeneas.Std.Vec
import Aeneas.Std.Array.Array

/-!
# Nested collection carriers

`alloc.vec.Vec`, `Slice` and `Array` are subtypes of `List` whose invariant
mentions the element type (`{ l : List α // l.length ≤ Usize.max }`). Lean's
nested-inductive elaboration rejects such types as containers of the types
being declared, so a Rust type which is recursive through `Vec<Self>`,
`Box<[Self]>` or `[Self; N]` cannot be translated to an inductive using those
types directly.

The carriers below have the same values, but store the elements in a
length-indexed list, so their invariant only mentions the length index. The
extraction uses them in the fields of recursive types (and only there), and
inserts the conversions below wherever a value enters or leaves such a field.
The conversions are mutually inverse, and the `@[simp]` lemmas erase them.
-/

namespace Aeneas.Std

/-- A list indexed by its length. -/
inductive LenList (α : Type u) : Nat → Type u where
  | nil : LenList α 0
  | cons {n : Nat} (hd : α) (tl : LenList α n) : LenList α (n + 1)

namespace LenList

variable {α : Type u} {β : Type v} {γ : Type w}

/-- Convert a list of known length. -/
def ofList : (l : List α) → (n : Nat) → l.length = n → LenList α n
  | [], 0, _ => .nil
  | x :: xs, n + 1, h => .cons x (ofList xs n (by simpa using h))
  | [], _ + 1, h => absurd h (by simp)
  | _ :: _, 0, h => absurd h (by simp)

def toList : {n : Nat} → LenList α n → List α
  | _, .nil => []
  | _, .cons x xs => x :: toList xs

def map (f : α → β) : {n : Nat} → LenList α n → LenList β n
  | _, .nil => .nil
  | _, .cons x xs => .cons (f x) (map f xs)

@[simp] theorem toList_nil : (nil : LenList α 0).toList = [] := rfl

@[simp] theorem toList_cons {n : Nat} (x : α) (xs : LenList α n) :
    (cons x xs).toList = x :: xs.toList := rfl

@[simp] theorem length_toList {n : Nat} (x : LenList α n) : x.toList.length = n := by
  induction x <;> simp [*]

@[simp] theorem toList_ofList (l : List α) (n : Nat) (h : l.length = n) :
    (ofList l n h).toList = l := by
  induction l generalizing n with
  | nil =>
    cases n with
    | zero => rfl
    | succ n => simp at h
  | cons x xs ih =>
    cases n with
    | zero => simp at h
    | succ n => simp [ofList, ih]

theorem eq_of_toList_eq {n : Nat} {x y : LenList α n} (h : x.toList = y.toList) : x = y := by
  induction x with
  | nil => cases y; rfl
  | cons a xs ih =>
    cases y with
    | cons b ys =>
      simp only [toList_cons, List.cons.injEq] at h
      rw [h.1, ih h.2]

theorem toList_inj {n : Nat} {x y : LenList α n} : x.toList = y.toList ↔ x = y :=
  ⟨eq_of_toList_eq, fun h => h ▸ rfl⟩

@[simp] theorem ofList_toList {n : Nat} (x : LenList α n) (h : x.toList.length = n) :
    ofList x.toList n h = x :=
  eq_of_toList_eq (by simp)

@[simp] theorem toList_map (f : α → β) {n : Nat} (x : LenList α n) :
    (x.map f).toList = x.toList.map f := by
  induction x <;> simp [map, *]

@[simp] theorem map_id {n : Nat} (x : LenList α n) : x.map id = x :=
  eq_of_toList_eq (by simp)

@[simp] theorem map_map (f : α → β) (g : β → γ) {n : Nat} (x : LenList α n) :
    (x.map f).map g = x.map (g ∘ f) :=
  eq_of_toList_eq (by simp)

end LenList

/-! ## Vectors -/

/-- Carrier for `alloc.vec.Vec α` in the fields of recursive types. -/
structure NestedVec (α : Type u) where
  len : Nat
  elems : LenList α len
  len_le : len ≤ Usize.max

namespace NestedVec

variable {α : Type u} {β : Type v} {γ : Type w}

theorem ext_toList {x y : NestedVec α} (h : x.elems.toList = y.elems.toList) : x = y := by
  cases x with
  | mk n xs hx =>
    cases y with
    | mk m ys hy =>
      have hnm : n = m := by
        rw [← LenList.length_toList xs, ← LenList.length_toList ys]
        exact congrArg List.length h
      subst hnm
      cases LenList.eq_of_toList_eq h
      rfl

def toVec (x : NestedVec α) : alloc.vec.Vec α :=
  ⟨x.elems.toList, by simpa using x.len_le⟩

/-- Map the elements (used to convert the elements of nested carriers). -/
def map (f : α → β) (x : NestedVec α) : NestedVec β :=
  ⟨x.len, x.elems.map f, x.len_le⟩

@[simp] theorem toVec_val (x : NestedVec α) : x.toVec.val = x.elems.toList := rfl

@[simp] theorem toVec_length (x : NestedVec α) : x.toVec.length = x.len := by
  simp [toVec]

@[simp] theorem map_elems_toList (f : α → β) (x : NestedVec α) :
    (x.map f).elems.toList = x.elems.toList.map f := by
  simp [map]

@[simp] theorem map_id (x : NestedVec α) : x.map id = x :=
  ext_toList (by simp)

@[simp] theorem map_map (f : α → β) (g : β → γ) (x : NestedVec α) :
    (x.map f).map g = x.map (g ∘ f) :=
  ext_toList (by simp)

end NestedVec

namespace alloc.vec.Vec

variable {α : Type u}

def toNested (v : alloc.vec.Vec α) : NestedVec α :=
  ⟨v.val.length, LenList.ofList v.val v.val.length rfl, v.property⟩

@[simp] theorem toNested_elems_toList (v : alloc.vec.Vec α) :
    v.toNested.elems.toList = v.val :=
  LenList.toList_ofList _ _ _

@[simp] theorem toNested_len (v : alloc.vec.Vec α) : v.toNested.len = v.length := rfl

@[simp] theorem toVec_toNested (v : alloc.vec.Vec α) : v.toNested.toVec = v :=
  Subtype.ext (toNested_elems_toList v)

end alloc.vec.Vec

@[simp] theorem NestedVec.toNested_toVec {α : Type u} (x : NestedVec α) :
    x.toVec.toNested = x :=
  NestedVec.ext_toList (LenList.toList_ofList _ _ _)

theorem NestedVec.toVec_injective {α : Type u} : Function.Injective (@NestedVec.toVec α) :=
  fun x y h => by rw [← NestedVec.toNested_toVec x, h, NestedVec.toNested_toVec]

theorem alloc.vec.Vec.toNested_injective {α : Type u} :
    Function.Injective (@alloc.vec.Vec.toNested α) :=
  fun x y h => by rw [← alloc.vec.Vec.toVec_toNested x, h, alloc.vec.Vec.toVec_toNested]

/-! ## Slices -/

/-- Carrier for `Slice α` (e.g. `Box<[T]>`) in the fields of recursive types. -/
structure NestedSlice (α : Type u) where
  len : Nat
  elems : LenList α len
  len_le : len ≤ Usize.max

namespace NestedSlice

variable {α : Type u} {β : Type v} {γ : Type w}

theorem ext_toList {x y : NestedSlice α} (h : x.elems.toList = y.elems.toList) : x = y := by
  cases x with
  | mk n xs hx =>
    cases y with
    | mk m ys hy =>
      have hnm : n = m := by
        rw [← LenList.length_toList xs, ← LenList.length_toList ys]
        exact congrArg List.length h
      subst hnm
      cases LenList.eq_of_toList_eq h
      rfl

def toSlice (x : NestedSlice α) : Slice α :=
  ⟨x.elems.toList, by simpa using x.len_le⟩

def map (f : α → β) (x : NestedSlice α) : NestedSlice β :=
  ⟨x.len, x.elems.map f, x.len_le⟩

@[simp] theorem toSlice_val (x : NestedSlice α) : x.toSlice.val = x.elems.toList := rfl

@[simp] theorem toSlice_length (x : NestedSlice α) : x.toSlice.length = x.len := by
  simp [toSlice]

@[simp] theorem map_elems_toList (f : α → β) (x : NestedSlice α) :
    (x.map f).elems.toList = x.elems.toList.map f := by
  simp [map]

@[simp] theorem map_id (x : NestedSlice α) : x.map id = x :=
  ext_toList (by simp)

@[simp] theorem map_map (f : α → β) (g : β → γ) (x : NestedSlice α) :
    (x.map f).map g = x.map (g ∘ f) :=
  ext_toList (by simp)

end NestedSlice

namespace Slice

variable {α : Type u}

def toNested (s : Slice α) : NestedSlice α :=
  ⟨s.val.length, LenList.ofList s.val s.val.length rfl, s.property⟩

@[simp] theorem toNested_elems_toList (s : Slice α) : s.toNested.elems.toList = s.val :=
  LenList.toList_ofList _ _ _

@[simp] theorem toNested_len (s : Slice α) : s.toNested.len = s.length := rfl

@[simp] theorem toSlice_toNested (s : Slice α) : s.toNested.toSlice = s :=
  Subtype.ext (toNested_elems_toList s)

end Slice

@[simp] theorem NestedSlice.toNested_toSlice {α : Type u} (x : NestedSlice α) :
    x.toSlice.toNested = x :=
  NestedSlice.ext_toList (LenList.toList_ofList _ _ _)

theorem NestedSlice.toSlice_injective {α : Type u} :
    Function.Injective (@NestedSlice.toSlice α) :=
  fun x y h => by rw [← NestedSlice.toNested_toSlice x, h, NestedSlice.toNested_toSlice]

theorem Slice.toNested_injective {α : Type u} : Function.Injective (@Slice.toNested α) :=
  fun x y h => by rw [← Slice.toSlice_toNested x, h, Slice.toSlice_toNested]

/-! ## Arrays -/

/-- Carrier for `Array α n` in the fields of recursive types. The length is
    the index `n.val`, so no further invariant is needed. -/
structure NestedArray (α : Type u) (n : Usize) where
  elems : LenList α n.val

namespace NestedArray

variable {α : Type u} {β : Type v} {γ : Type w} {n : Usize}

theorem ext_toList {x y : NestedArray α n} (h : x.elems.toList = y.elems.toList) : x = y := by
  cases x; cases y; cases LenList.eq_of_toList_eq h; rfl

def toArray (x : NestedArray α n) : Array α n :=
  ⟨x.elems.toList, by simp⟩

def map (f : α → β) (x : NestedArray α n) : NestedArray β n :=
  ⟨x.elems.map f⟩

@[simp] theorem toArray_val (x : NestedArray α n) : x.toArray.val = x.elems.toList := rfl

@[simp] theorem map_elems_toList (f : α → β) (x : NestedArray α n) :
    (x.map f).elems.toList = x.elems.toList.map f := by
  simp [map]

@[simp] theorem map_id (x : NestedArray α n) : x.map id = x :=
  ext_toList (by simp)

@[simp] theorem map_map (f : α → β) (g : β → γ) (x : NestedArray α n) :
    (x.map f).map g = x.map (g ∘ f) :=
  ext_toList (by simp)

end NestedArray

namespace Array

variable {α : Type u} {n : Usize}

def toNested (a : Array α n) : NestedArray α n :=
  ⟨LenList.ofList a.val n.val a.property⟩

@[simp] theorem toNested_elems_toList (a : Array α n) : a.toNested.elems.toList = a.val :=
  LenList.toList_ofList _ _ _

@[simp] theorem toArray_toNested (a : Array α n) : a.toNested.toArray = a :=
  Subtype.ext (toNested_elems_toList a)

end Array

@[simp] theorem NestedArray.toNested_toArray {α : Type u} {n : Usize} (x : NestedArray α n) :
    x.toArray.toNested = x :=
  NestedArray.ext_toList (LenList.toList_ofList _ _ _)

theorem NestedArray.toArray_injective {α : Type u} {n : Usize} :
    Function.Injective (@NestedArray.toArray α n) :=
  fun x y h => by rw [← NestedArray.toNested_toArray x, h, NestedArray.toNested_toArray]

theorem Array.toNested_injective {α : Type u} {n : Usize} :
    Function.Injective (@Array.toNested α n) :=
  fun x y h => by rw [← Array.toArray_toNested x, h, Array.toArray_toNested]

end Aeneas.Std
