import Aeneas.Std.Serde.De
import Aeneas.Std.Serde.Impls

/-!
# `serde::__private::de::content` (serde 1.0.228, `private/de.rs`): the buffered content of untagged
and internally tagged enums

`#[derive(Deserialize)]` with `#[serde(tag = "..")]` buffers its input as a
`serde_core::private::content::Content` (`Serde/De.lean`) with `TaggedContentVisitor`, then
deserializes the variant from the buffer with `ContentDeserializer`.

`ContentVisitor` deserializes nested values with itself (`visit_some`, `visit_newtype_struct` through
its `DeserializeSeed`, the elements and entries through `next_element_seed`/`next_entry_seed`), so its
dictionaries are built level by level of the knot (`DeAt`), as `IgnoredAny`'s.
-/

namespace Aeneas.Std

open Result

namespace serde_core.private.size_hint

/-- `pub fn cautious<Element>(hint: Option<usize>) -> usize` (serde_core `private/size_hint.rs`,
    with `std`/`alloc`), `size` being `mem::size_of::<Element>()`: `0` for a zero-sized element,
    else `min(hint.unwrap_or(0), 1024 * 1024 / size)`. Callers only use it as a capacity. -/
def cautious (size : Nat) (hint : Option Usize) : Usize :=
  if size = 0 then ⟨BitVec.ofNat _ 0⟩
  else ⟨BitVec.ofNat _ (min ((hint.map (·.val)).getD 0) (1024 * 1024 / size))⟩

end serde_core.private.size_hint

/-- `mem::size_of::<Content<'de>>()` on the 64-bit targets: the largest variants (`String`,
    `ByteBuf`, `Seq`, `Map`) hold 24 bytes, with the discriminant 32. -/
def serde_core.private.content.Content.size : Nat := 32

namespace serde.private.de.content

open serde_core.de serde_core.private.content

/-- `pub struct ContentVisitor<'de> { value: PhantomData<Content<'de>> }` -/
@[rust_type "serde::private::de::content::ContentVisitor" (body := .opaque)]
structure ContentVisitor where

/-- `ContentVisitor::new()`: `ContentVisitor { value: PhantomData }`. -/
@[rust_fun "serde::private::de::content::{serde::private::de::content::ContentVisitor<'de>}::new"]
def ContentVisitor.new : Result ContentVisitor := ok ⟨⟩

/-- `impl DeserializeSeed for ContentVisitor` one level above the visitor `v` of the knot family
    `X`: `deserializer.__deserialize_content_v1(self)`. -/
def contentSeedStep {X : Fam} (v : X.Visitor ContentVisitor Content) :
    SeedStep X ContentVisitor Content :=
  ⟨fun inst self de => inst.__deserialize_content_v1 v de self⟩

/-- `while let Some(e) = tri!(visitor.next_element_seed(ContentVisitor::new())) { vec.push(e); }`,
    then `vec`. -/
def contentElements {X : Fam} {A Error : Type} (seq : SeqAccessF X A Error)
    (seed : X.Seed ContentVisitor Content) (vec : alloc.vec.Vec Content) (access : A) :
    Result (core.result.Result (alloc.vec.Vec Content) Error) := do
  let (r, access) ← seq.next_element_seed seed access ⟨⟩
  match r with
  | .Err e => ok (.Err e)
  | .Ok none => ok (.Ok vec)
  | .Ok (some e) => contentElements seq seed (← alloc.vec.Vec.push vec e) access
partial_fixpoint

/-- `while let Some(kv) = tri!(visitor.next_entry_seed(ContentVisitor::new(),
    ContentVisitor::new())) { vec.push(kv); }`, then `vec`. -/
def contentEntries {X : Fam} {A Error : Type} (map : MapAccessF X A Error)
    (seed : X.Seed ContentVisitor Content) (vec : alloc.vec.Vec (Content × Content)) (access : A) :
    Result (core.result.Result (alloc.vec.Vec (Content × Content)) Error) := do
  let (r, access) ← map.next_entry_seed seed seed access ⟨⟩ ⟨⟩
  match r with
  | .Err e => ok (.Err e)
  | .Ok none => ok (.Ok vec)
  | .Ok (some kv) => contentEntries map seed (← alloc.vec.Vec.push vec kv) access
partial_fixpoint

/-- `Err(de::Error::custom("untagged and internally tagged enums do not support enum input"))` -/
def enumInputError {Value E : Type} (errInst : serde_core.de.Error E) :
    Result (core.result.Result Value E) := do
  ok (.Err (← errInst.custom core.fmt.DisplayStr
    (← Str.ofString "untagged and internally tagged enums do not support enum input")))

/-- `impl Visitor for ContentVisitor` (`expecting` is "any value") one level above the seed `seed`
    and the visitor `v` of the knot family `X`: every `visit_*` is `Ok` of its `Content` variant
    (`visit_str` and `visit_bytes` own their value: `String`, `ByteBuf`; the borrowed ones keep the
    borrow: `Str`, `Bytes`), `visit_some` and `visit_newtype_struct` buffer the inner value with
    `ContentVisitor::new().deserialize(deserializer)`, `visit_seq` and `visit_map` read the
    access's `size_hint` for the capacity (`size_hint::cautious`) then every element or entry until
    the end or the first error, and `visit_enum` is the error `enumInputError`. `visit_i128` and
    `visit_u128` are the provided ones. -/
def contentVisitorStep {X : Fam} (seed : X.Seed ContentVisitor Content)
    (v : X.Visitor ContentVisitor Content) : VisitorStep X ContentVisitor Content :=
  { expecting := fun _ f => f.append "any value"
    visit_bool := fun _ _ x => ok (.Ok (.Bool x))
    visit_i8 := fun _ _ x => ok (.Ok (.I8 x))
    visit_i16 := fun _ _ x => ok (.Ok (.I16 x))
    visit_i32 := fun _ _ x => ok (.Ok (.I32 x))
    visit_i64 := fun _ _ x => ok (.Ok (.I64 x))
    visit_u8 := fun _ _ x => ok (.Ok (.U8 x))
    visit_u16 := fun _ _ x => ok (.Ok (.U16 x))
    visit_u32 := fun _ _ x => ok (.Ok (.U32 x))
    visit_u64 := fun _ _ x => ok (.Ok (.U64 x))
    visit_f32 := fun _ _ x => ok (.Ok (.F32 x))
    visit_f64 := fun _ _ x => ok (.Ok (.F64 x))
    visit_char := fun _ _ x => ok (.Ok (.Char x))
    visit_str := fun _ _ x => do ok (.Ok (.String (← Str.toString x)))
    visit_borrowed_str := fun _ _ x => ok (.Ok (.Str x))
    visit_string := fun _ _ x => ok (.Ok (.String x))
    visit_bytes := fun _ _ x => ok (.Ok (.ByteBuf (alloc.slice.Slice.into_vec x)))
    visit_borrowed_bytes := fun _ _ x => ok (.Ok (.Bytes x))
    visit_byte_buf := fun _ _ x => ok (.Ok (.ByteBuf x))
    visit_unit := fun _ _ => ok (.Ok .Unit)
    visit_none := fun _ _ => ok (.Ok .None)
    visit_some := fun inst _ de => do
      match ← (contentSeedStep v).deserialize inst ⟨⟩ de with
      | .Err e => ok (.Err e)
      | .Ok c => ok (.Ok (.Some c))
    visit_newtype_struct := fun inst _ de => do
      match ← (contentSeedStep v).deserialize inst ⟨⟩ de with
      | .Err e => ok (.Err e)
      | .Ok c => ok (.Ok (.Newtype c))
    visit_seq := fun seq _ access => do
      let hint ← seq.size_hint access
      let vec := alloc.vec.Vec.with_capacity Content
        (serde_core.private.size_hint.cautious Content.size hint)
      match ← contentElements seq seed vec access with
      | .Err e => ok (.Err e)
      | .Ok vec => ok (.Ok (.Seq vec.toNested))
    visit_map := fun map _ access => do
      let hint ← map.size_hint access
      let vec := alloc.vec.Vec.with_capacity (Content × Content)
        (serde_core.private.size_hint.cautious (2 * Content.size) hint)
      match ← contentEntries map seed vec access with
      | .Err e => ok (.Err e)
      | .Ok vec => ok (.Ok (.Map vec.toNested))
    visit_enum := fun data _ _ => enumInputError data.serde_coredeErrorInst }

/-- The dictionaries of `ContentVisitor` at level `n` of the knot: `impl DeserializeSeed` and
    `impl Visitor`. -/
def contentAt : (n : Nat) →
    (DeAt n).Seed ContentVisitor Content × (DeAt n).Visitor ContentVisitor Content
  | 0 => (PUnit.unit, PUnit.unit)
  | n + 1 =>
    let below := contentAt n
    (contentSeedStep below.2, contentVisitorStep below.1 below.2)

/-- `ContentVisitor` as the seed and the visitor of the Rust traits (`Ω`). -/
def ContentSeedΩ : SeedΩ ContentVisitor Content := ⟨fun n => (contentAt n).1⟩
def ContentVisitorΩ : VisitorΩ ContentVisitor Content := ⟨fun n => (contentAt n).2⟩

/-- `impl<'de> Visitor<'de> for ContentVisitor<'de>` -/
@[reducible, rust_trait_impl
  "serde_core::de::Visitor<'de, serde::private::de::content::ContentVisitor<'de>, serde_core::private::content::Content<'de>>"]
def VisitorContentVisitor : serde_core.de.Visitor ContentVisitor Content :=
  contentVisitorStep (X := Ω) ContentSeedΩ ContentVisitorΩ

/-- `impl<'de> DeserializeSeed<'de> for ContentVisitor<'de>`:
    `deserializer.__deserialize_content_v1(self)`. -/
@[rust_fun
  "serde::private::de::content::{serde_core::de::DeserializeSeed<'de, serde::private::de::content::ContentVisitor<'de>, serde_core::private::content::Content<'de>>}::deserialize"]
def DeserializeSeedContentVisitor.deserialize {D Error : Type}
    (inst : serde_core.de.Deserializer D Error) (self : ContentVisitor) (deserializer : D) :
    Result (core.result.Result Content Error) :=
  inst.__deserialize_content_v1 ContentVisitorΩ deserializer self

@[reducible, rust_trait_impl
  "serde_core::de::DeserializeSeed<'de, serde::private::de::content::ContentVisitor<'de>, serde_core::private::content::Content<'de>>"]
def DeserializeSeedContentVisitor : serde_core.de.DeserializeSeed ContentVisitor Content :=
  { deserialize := fun inst self deserializer =>
      DeserializeSeedContentVisitor.deserialize inst self deserializer }

/-- The knots of `ContentVisitor` are its level-wise construction. -/
theorem DeserializeSeedContentVisitor.wrap_level (n : Nat) :
    (DeserializeSeed.wrap DeserializeSeedContentVisitor).level n = (contentAt n).1 := by
  cases n <;> rfl

end serde.private.de.content

namespace serde_core.de.value

open serde_core.de

/-- `pub struct SeqAccessDeserializer<A> { seq: A }` (serde_core `de/value.rs`): a deserializer
    holding a `SeqAccess`. -/
@[rust_type "serde_core::de::value::SeqAccessDeserializer" (body := .opaque)]
structure SeqAccessDeserializer (A : Type) where
  seq : A

/-- `SeqAccessDeserializer::new(seq)`: `SeqAccessDeserializer { seq }`. -/
@[rust_fun "serde_core::de::value::{serde_core::de::value::SeqAccessDeserializer<@A>}::new"]
def SeqAccessDeserializer.new {A : Type} (seq : A) : Result (SeqAccessDeserializer A) := ok ⟨seq⟩

/-- `impl<'de, A: SeqAccess<'de>> Deserializer<'de> for SeqAccessDeserializer<A>`:
    `deserialize_any` is `visitor.visit_seq(self.seq)` and `forward_to_deserialize_any!` makes every
    other method (`i128` and `u128` included) `deserialize_any`; `is_human_readable` and
    `__deserialize_content_v1` are the provided ones. The access is a Rust trait dictionary, with no
    nesting bound of its own: a received visitor runs at the first level of the knot with a result
    (`limitFrom`), with the access at that level (`embed`). -/
@[reducible, rust_trait_impl
  "serde_core::de::Deserializer<'de, serde_core::de::value::SeqAccessDeserializer<@A>, @Clause0_Error>"]
def DeserializerSeqAccessDeserializer {A Error : Type} (seqInst : serde_core.de.SeqAccess A Error) :
    serde_core.de.Deserializer (SeqAccessDeserializer A) Error :=
  let any : {V Value : Type} → VisitorΩ V Value → SeqAccessDeserializer A → V →
      Result (core.result.Result Value Error) :=
    fun vis self v => limitFrom (fun m => (vis.level (m + 1)).visit_seq (seqInst.map (embed m)) v self.seq) 0
  { serde_coredeErrorInst := seqInst.serde_coredeErrorInst
    deserialize_any := any
    deserialize_bool := any, deserialize_i8 := any, deserialize_i16 := any
    deserialize_i32 := any, deserialize_i64 := any, deserialize_i128 := any
    deserialize_u8 := any, deserialize_u16 := any, deserialize_u32 := any
    deserialize_u64 := any, deserialize_u128 := any, deserialize_f32 := any
    deserialize_f64 := any, deserialize_char := any, deserialize_str := any
    deserialize_string := any, deserialize_bytes := any, deserialize_byte_buf := any
    deserialize_option := any, deserialize_unit := any
    deserialize_unit_struct := fun vis self _ v => any vis self v
    deserialize_newtype_struct := fun vis self _ v => any vis self v
    deserialize_seq := any
    deserialize_tuple := fun vis self _ v => any vis self v
    deserialize_tuple_struct := fun vis self _ _ v => any vis self v
    deserialize_map := any
    deserialize_struct := fun vis self _ _ v => any vis self v
    deserialize_enum := fun vis self _ _ v => any vis self v
    deserialize_identifier := any
    deserialize_ignored_any := any }

end serde_core.de.value


namespace serde.private.de.content

open serde_core.de serde_core.private serde_core.private.content

/-! ### `TagOrContentVisitor` and `TaggedContentVisitor` -/

/-- `pub enum TagOrContent<'de> { Tag, Content(Content<'de>) }`: a map key of an internally tagged
    enum. -/
inductive TagOrContent where
  | Tag
  | Content (c : serde_core.private.content.Content)

/-- `ContentVisitor::new().visit_*(value).map(TagOrContent::Content)` -/
def asContent {E : Type} (r : Result (core.result.Result Content E)) :
    Result (core.result.Result TagOrContent E) := do
  match ← r with
  | .Ok c => ok (.Ok (.Content c))
  | .Err e => ok (.Err e)

/-- `impl Visitor for TagOrContentVisitor` (its value is the tag name `self.name`) one level above
    the dictionaries of `ContentVisitor` of the knot family `X`: a string or bytes equal to the name
    is `TagOrContent::Tag`; every other value is `ContentVisitor::new().visit_*(value)` of the same
    level, as `TagOrContent::Content`. `expecting` is ``a type tag `{name}` or any other value``;
    `visit_i128`/`visit_u128` are the provided ones. -/
def tagOrContentVisitorStep {X : Fam} (seed : X.Seed ContentVisitor Content)
    (v : X.Visitor ContentVisitor Content) : VisitorStep X Str TagOrContent :=
  let cv := contentVisitorStep seed v
  { expecting := fun name f =>
      writeArgs f (cat [lit "a type tag `", strArg name, lit "` or any other value"])
    visit_bool := fun e _ x => asContent (cv.visit_bool e ⟨⟩ x)
    visit_i8 := fun e _ x => asContent (cv.visit_i8 e ⟨⟩ x)
    visit_i16 := fun e _ x => asContent (cv.visit_i16 e ⟨⟩ x)
    visit_i32 := fun e _ x => asContent (cv.visit_i32 e ⟨⟩ x)
    visit_i64 := fun e _ x => asContent (cv.visit_i64 e ⟨⟩ x)
    visit_u8 := fun e _ x => asContent (cv.visit_u8 e ⟨⟩ x)
    visit_u16 := fun e _ x => asContent (cv.visit_u16 e ⟨⟩ x)
    visit_u32 := fun e _ x => asContent (cv.visit_u32 e ⟨⟩ x)
    visit_u64 := fun e _ x => asContent (cv.visit_u64 e ⟨⟩ x)
    visit_f32 := fun e _ x => asContent (cv.visit_f32 e ⟨⟩ x)
    visit_f64 := fun e _ x => asContent (cv.visit_f64 e ⟨⟩ x)
    visit_char := fun e _ x => asContent (cv.visit_char e ⟨⟩ x)
    visit_str := fun e name x =>
      if x.val == name.val then ok (.Ok .Tag) else asContent (cv.visit_str e ⟨⟩ x)
    visit_borrowed_str := fun e name x =>
      if x.val == name.val then ok (.Ok .Tag) else asContent (cv.visit_borrowed_str e ⟨⟩ x)
    visit_string := fun e name x => do
      if (← Str.ofString x).val == name.val then ok (.Ok .Tag)
      else asContent (cv.visit_string e ⟨⟩ x)
    visit_bytes := fun e name x =>
      if x.val == name.val then ok (.Ok .Tag) else asContent (cv.visit_bytes e ⟨⟩ x)
    visit_borrowed_bytes := fun e name x =>
      if x.val == name.val then ok (.Ok .Tag) else asContent (cv.visit_borrowed_bytes e ⟨⟩ x)
    visit_byte_buf := fun e name x =>
      if x.val == name.val then ok (.Ok .Tag) else asContent (cv.visit_byte_buf e ⟨⟩ x)
    visit_unit := fun e _ => asContent (cv.visit_unit e ⟨⟩)
    visit_none := fun e _ => asContent (cv.visit_none e ⟨⟩)
    visit_some := fun inst _ de => asContent (cv.visit_some inst ⟨⟩ de)
    visit_newtype_struct := fun inst _ de => asContent (cv.visit_newtype_struct inst ⟨⟩ de)
    visit_seq := fun seq _ access => asContent (cv.visit_seq seq ⟨⟩ access)
    visit_map := fun map _ access => asContent (cv.visit_map map ⟨⟩ access)
    visit_enum := fun data _ access => asContent (cv.visit_enum data ⟨⟩ access) }

/-- The dictionaries of `TagOrContentVisitor` at level `n` of the knot: `impl DeserializeSeed`
    (`deserializer.deserialize_any(self)`: internally tagged enums need a self-describing format)
    and `impl Visitor`. -/
def tagOrContentAt : (n : Nat) → (DeAt n).Seed Str TagOrContent × (DeAt n).Visitor Str TagOrContent
  | 0 => (PUnit.unit, PUnit.unit)
  | n + 1 =>
    let below := tagOrContentAt n
    (⟨fun inst name de => inst.deserialize_any below.2 de name⟩,
      tagOrContentVisitorStep (contentAt n).1 (contentAt n).2)

/-- `TagOrContentVisitor::new(name)` as a seed of the Rust traits (`Ω`); its value is the name. -/
def TagOrContentSeedΩ : SeedΩ Str TagOrContent := ⟨fun n => (tagOrContentAt n).1⟩

/-- `pub struct TaggedContentVisitor<T> { tag_name, expecting, value: PhantomData<T> }` -/
@[rust_type "serde::private::de::content::TaggedContentVisitor" (body := .opaque)]
structure TaggedContentVisitor (T : Type) where
  tag_name : Str
  expecting : Str

/-- `TaggedContentVisitor::new(name, expecting)` -/
@[rust_fun
  "serde::private::de::content::{serde::private::de::content::TaggedContentVisitor<@T>}::new"]
def TaggedContentVisitor.new (T : Type) (name expecting : Str) :
    Result (TaggedContentVisitor T) :=
  ok ⟨name, expecting⟩

/-- The `while let Some(k) = tri!(map.next_key_seed(TagOrContentVisitor::new(self.tag_name)))`
    loop of `TaggedContentVisitor::visit_map`: the tag (a second one is
    `Error::duplicate_field(tag_name)`, before its value is read) is `map.next_value()`, every other
    entry is buffered (`map.next_value_seed(ContentVisitor::new())`, pushed with its key), until the
    end or the first error. -/
def taggedEntries {T M Error : Type} (tInst : serde_core.de.Deserialize T)
    (map : serde_core.de.MapAccess M Error) (name : Str) (tag : Option T)
    (vec : alloc.vec.Vec (Content × Content)) (access : M) :
    Result (core.result.Result (Option T × alloc.vec.Vec (Content × Content)) Error) := do
  let (r, access) ← map.next_key_seed TagOrContentSeedΩ access name
  match r with
  | .Err e => ok (.Err e)
  | .Ok none => ok (.Ok (tag, vec))
  | .Ok (some .Tag) =>
    if tag.isSome then ok (.Err (← map.serde_coredeErrorInst.duplicate_field name))
    else
      let (r, access) ← map.next_value (Deserialize.wrap tInst) access
      match r with
      | .Err e => ok (.Err e)
      | .Ok t => taggedEntries tInst map name (some t) vec access
  | .Ok (some (.Content k)) =>
    let (r, access) ← map.next_value_seed ContentSeedΩ access ⟨⟩
    match r with
    | .Err e => ok (.Err e)
    | .Ok v => taggedEntries tInst map name tag (← alloc.vec.Vec.push vec (k, v)) access
partial_fixpoint

/-- `TaggedContentVisitor::visit_map`: the tag and the other entries (`taggedEntries`, the buffer's
    capacity from `size_hint::cautious`); no tag is `Error::missing_field(tag_name)`, else
    `(tag, Content::Map(entries))`. -/
@[rust_fun
  "serde::private::de::content::{serde_core::de::Visitor<'de, serde::private::de::content::TaggedContentVisitor<@T>, (@T, serde_core::private::content::Content<'de>)>}::visit_map"]
def VisitorTaggedContentVisitor.visit_map {T M Error : Type}
    (tInst : serde_core.de.Deserialize T) (map : serde_core.de.MapAccess M Error)
    (self : TaggedContentVisitor T) (access : M) :
    Result (core.result.Result (T × Content) Error) := do
  let hint ← map.size_hint access
  let vec := alloc.vec.Vec.with_capacity (Content × Content)
    (serde_core.private.size_hint.cautious (2 * Content.size) hint)
  match ← taggedEntries tInst map self.tag_name none vec access with
  | .Err e => ok (.Err e)
  | .Ok (none, _) => ok (.Err (← map.serde_coredeErrorInst.missing_field self.tag_name))
  | .Ok (some tag, vec) => ok (.Ok (tag, .Map vec.toNested))

/-- `TaggedContentVisitor::visit_seq`: the tag is the first element (`seq.next_element()`; none is
    `Error::missing_field(tag_name)`), the rest of the sequence is buffered through
    `ContentVisitor::new().deserialize(SeqAccessDeserializer::new(seq))` (a `Content::Seq`). -/
@[rust_fun
  "serde::private::de::content::{serde_core::de::Visitor<'de, serde::private::de::content::TaggedContentVisitor<@T>, (@T, serde_core::private::content::Content<'de>)>}::visit_seq"]
def VisitorTaggedContentVisitor.visit_seq {T S Error : Type}
    (tInst : serde_core.de.Deserialize T) (seq : serde_core.de.SeqAccess S Error)
    (self : TaggedContentVisitor T) (access : S) :
    Result (core.result.Result (T × Content) Error) := do
  let (r, access) ← seq.next_element (Deserialize.wrap tInst) access
  match r with
  | .Err e => ok (.Err e)
  | .Ok none => ok (.Err (← seq.serde_coredeErrorInst.missing_field self.tag_name))
  | .Ok (some tag) =>
    let rest ← serde_core.de.value.SeqAccessDeserializer.new access
    match ← DeserializeSeedContentVisitor.deserialize
        (serde_core.de.value.DeserializerSeqAccessDeserializer seq) ⟨⟩ rest with
    | .Err e => ok (.Err e)
    | .Ok c => ok (.Ok (tag, c))

/-- `TaggedContentVisitor::expecting`: `fmt.write_str(self.expecting)`. -/
@[rust_fun
  "serde::private::de::content::{serde_core::de::Visitor<'de, serde::private::de::content::TaggedContentVisitor<@T>, (@T, serde_core::private::content::Content<'de>)>}::expecting"]
def VisitorTaggedContentVisitor.expecting {T : Type} (_ : serde_core.de.Deserialize T)
    (self : TaggedContentVisitor T) (formatter : core.fmt.Formatter) : core.fmt.Outcome :=
  core.fmt.Formatter.write_str formatter self.expecting

/-- `impl<'de, T: Deserialize<'de>> Visitor<'de> for TaggedContentVisitor<T>` (its value is
    `(T, Content)`): `visit_seq`, `visit_map` and `expecting`; every other `visit_*` is the provided
    one (`Error::invalid_type` with `expecting`). -/
@[reducible, rust_trait_impl
  "serde_core::de::Visitor<'de, serde::private::de::content::TaggedContentVisitor<@T>, (@T, serde_core::private::content::Content<'de>)>"]
def VisitorTaggedContentVisitor {T : Type} (tInst : serde_core.de.Deserialize T) :
    serde_core.de.Visitor (TaggedContentVisitor T) (T × Content) :=
  { expecting := VisitorTaggedContentVisitor.expecting tInst
    visit_seq := fun seq self access => VisitorTaggedContentVisitor.visit_seq tInst seq self access
    visit_map := fun map self access => VisitorTaggedContentVisitor.visit_map tInst map self access }

end serde.private.de.content

namespace serde.private.de.content

open serde_core.de serde_core.private serde_core.private.content

/-! ### `ContentDeserializer` and its access types -/

/-- `pub struct ContentDeserializer<'de, E> { content: Content<'de>, err: PhantomData<E> }` -/
@[rust_type "serde::private::de::content::ContentDeserializer" (body := .opaque)]
structure ContentDeserializer (E : Type) where
  content : Content

/-- `ContentDeserializer::new(content)` -/
@[rust_fun "serde::private::de::content::{serde::private::de::content::ContentDeserializer<'de, @E>}::new"]
def ContentDeserializer.new (E : Type) (content : Content) : Result (ContentDeserializer E) :=
  ok ⟨content⟩

/-- `content_unexpected(&content)`: the `Unexpected` of a content (`as u64`/`as i64`/`as f64`
    widenings; an option is `Option`). -/
def contentUnexpected : Content → Result serde_core.de.Unexpected
  | .Bool b => ok (.Bool b)
  | .U8 n => ok (.Unsigned (n.cast .U64))
  | .U16 n => ok (.Unsigned (n.cast .U64))
  | .U32 n => ok (.Unsigned (n.cast .U64))
  | .U64 n => ok (.Unsigned n)
  | .I8 n => ok (.Signed (n.cast .I64))
  | .I16 n => ok (.Signed (n.cast .I64))
  | .I32 n => ok (.Signed (n.cast .I64))
  | .I64 n => ok (.Signed n)
  | .F32 f => ok (.Float (F32.toF64 f))
  | .F64 f => ok (.Float f)
  | .Char c => ok (.Char c)
  | .String s => do ok (.Str (← Str.ofString s))
  | .Str s => ok (.Str s)
  | .ByteBuf b => ok (.Bytes b)
  | .Bytes b => ok (.Bytes b)
  | .None | .Some _ => ok .Option
  | .Unit => ok .Unit
  | .Newtype _ => ok .NewtypeStruct
  | .Seq _ => ok .Seq
  | .Map _ => ok .Map

/-- `&"..."` as a `&dyn Expected` (`impl Expected for &str`: `formatter.write_str(self)`). -/
def expectedStr (s : String) : DynExpected := expectedOf (fun (_ : Unit) f => f.append s) ()

/-- `struct ExpectedInSeq(usize)` / `ExpectedInMap(usize)` and their `Expected`: "1 element in
    {what}", else "{n} elements in {what}". -/
def expectedIn (what : String) (n : Nat) : DynExpected :=
  ⟨Nat, ⟨fun n f =>
    if n = 1 then f.append ("1 element in " ++ what)
    else writeArgs f (cat [core.fmt.num.DisplayUsize.fmt ⟨BitVec.ofNat _ n⟩,
      lit (" elements in " ++ what)])⟩, n⟩

/-- `Err(Error::invalid_type(unexp, exp))` -/
def invalidTypeErr {Value E : Type} (errInst : serde_core.de.Error E) (unexp : serde_core.de.Unexpected)
    (exp : DynExpected) : Result (core.result.Result Value E) := do
  ok (.Err (← errInst.invalid_type unexp exp))

/-- A visit through a `&mut` access (`visitor.visit_seq(&mut seq_visitor)`, then
    `seq_visitor.end()`): the visitor consumes the access, the caller reads its final state. The
    access of `run k` gives at most `k` elements and diverges when asked for one more while elements
    remain; the visitor is a function of what the access gives it, so `run k` is the Rust run when it
    asks for at most `k` elements and diverges otherwise. The least `k ≤ len` whose run has a result
    is the number of elements the Rust visit took: its result is the Rust result, and `len - k`
    elements remain (`end`). No such `k` is the Rust divergence, or the nesting cutoff of the
    enclosing level, which the enclosing `limitFrom` resolves. The search relies on the
    cut-monotonicity invariant (`Serde/De.lean`): `consumedRun_ok`, `consumedRun_of_chain` and
    `consumedRun_count` below give its consequences. -/
def consumedRun {α : Type} (run : Nat → Result α) (k : Nat) : (fuel : Nat) → Result (α × Nat)
  | 0 => do ok (← run k, k)
  | fuel + 1 =>
    match run k with
    | .div => consumedRun run (k + 1) fuel
    | .ok a => ok (a, k)
    | .fail e => .fail e

/-- A result `(a, j)` comes from the run with budget `j`. -/
theorem consumedRun_ok {α : Type} {run : Nat → Result α} {k fuel : Nat} {a : α}
    -- The result.
    {j : Nat} (h : consumedRun run k fuel = ok (a, j)) :
    -- The run with budget `j` gives `a`.
    run j = ok a ∧ k ≤ j ∧ j ≤ k + fuel ∧
    -- Every smaller budget diverges.
    ∀ i, k ≤ i → i < j → run i = .div := by
  -- Induction on the fuel.
  induction fuel generalizing k with

  | zero =>
    simp only [consumedRun] at h
    -- The last budget.
    cases hr : run k with
    | ok b =>
      rw [hr] at h
      cases h
      -- The run with budget `k`.
      exact ⟨hr, Nat.le_refl _, by omega, fun i h1 h2 => absurd h2 (by omega)⟩
    -- No result.
    | fail e =>
      rw [hr] at h
      cases h
    -- No result.
    | div =>
      rw [hr] at h
      cases h

  | succ fuel ih =>
    simp only [consumedRun] at h
    split at h
    -- The budget `k` diverges.
    · rename_i hr
      rcases ih h with ⟨h1, h2, h3, h4⟩
      -- The bounds.
      refine ⟨h1, by omega, by omega, ?_⟩
      intro i hi hij
      -- The budget `k` or a larger one.
      by_cases hik : i = k
      · rw [hik]
        exact hr
      · exact h4 i (by omega) hij

    -- The budget `k` gives a value.
    · rename_i b hr
      cases h
      -- The run with budget `k`.
      exact ⟨hr, Nat.le_refl _, by omega, fun i h1 h2 => absurd h2 (by omega)⟩
    -- The budget `k` fails.
    · cases h

/-- On a chain, a defined run within the fuel gives a result. -/
theorem consumedRun_of_chain {α : Type} {run : Nat → Result α} (hc : IsChain run)
    -- The budget `n` is in the range.
    {k fuel n : Nat} (hkn : k ≤ n) (hn : n ≤ k + fuel)
    -- Its run gives `a`.
    {a : α} (h : run n = ok a) :
    -- The result.
    ∃ j, j ≤ n ∧ consumedRun run k fuel = ok (a, j) := by
  -- Induction on the fuel.
  induction fuel generalizing k with

  | zero =>
    -- The last budget.
    rw [show k = n by omega]
    exact ⟨n, Nat.le_refl _, by simp [consumedRun, h]⟩

  | succ fuel ih =>
    simp only [consumedRun]
    -- The budget `k` diverges, gives a value or fails.
    cases hr : run k with
    | div =>
      have hk : k ≠ n := by
        -- The budget `n` gives a value.
        intro e
        rw [e, h] at hr
        cases hr
      -- The next budget.
      exact ih (k := k + 1) (by omega) (by omega)

    | ok b =>
      rcases hc k n hkn with h' | h'
      · rw [hr] at h'
        cases h'
      -- The chain gives the value.
      · rw [hr, h] at h'
        cases h'
        exact ⟨k, hkn, rfl⟩

    | fail e =>
      rcases hc k n hkn with h' | h'
      · rw [hr] at h'
        cases h'
      -- A failure is not a value.
      · rw [hr, h] at h'
        cases h'

/-- The budget invariant of an access gives the count `c` of the elements of the visit. -/
theorem consumedRun_count {α : Type} {run : Nat → Result α} {c len : Nat} {a : α}
    -- The budgets below `c` diverge.
    (hlt : ∀ i, i < c → run i = .div)

    -- The budgets from `c` give `a`.
    (hge : ∀ i, c ≤ i → run i = ok a) (hc : c ≤ len) :
    -- The result.
    consumedRun run 0 len = ok (a, c) := by
  -- The runs form a chain.
  have hchain : IsChain run := by
    intro m n hmn
    -- The budget `m` is below `c` or not.
    by_cases hm : m < c
    · exact Or.inl (hlt m hm)
    -- Both budgets are from `c`.
    · exact Or.inr (by rw [hge m (by omega), hge n (by omega)])

  -- A result exists.
  rcases consumedRun_of_chain hchain (fuel := len) (Nat.zero_le c) (by omega)
    (hge c (Nat.le_refl c)) with ⟨j, _, h⟩
  -- Its properties.
  rcases consumedRun_ok h with ⟨h1, _, _, _⟩

  -- Its budget is `c`.
  have hj : j = c := by
    by_cases hjc : j < c
    -- A smaller budget diverges.
    · rw [hlt j hjc] at h1
      cases h1
    · omega
  -- The result.
  rw [hj] at h
  exact h

/-- The format types of `ContentDeserializer<E>`: the deserializer (its content), the
    `SeqDeserializer` and `MapDeserializer` a visitor borrows mutably (the remaining elements or
    entries, the pending value, and the budget of `consumedRun`), `EnumDeserializer` (the variant and
    its value) and `VariantDeserializer` (the value), all with error `E`. -/
@[reducible] def ContentTypes (E : Type) : FormatTypes where
  ιD := Unit
  D := fun _ => ContentDeserializer E
  DError := fun _ => E
  ιS := Unit
  S := fun _ => List Content × Nat
  SError := fun _ => E
  ιM := Unit
  M := fun _ => List (Content × Content) × Option Content × Nat
  MError := fun _ => E
  ιE := Unit
  E := fun _ => Content × Option Content
  EError := fun _ => E
  EVariant := fun _ => Option Content
  ιV := Unit
  V := fun _ => Option Content
  VError := fun _ => E

/-- `visit_content_seq(content, visitor)` (and `SeqDeserializer::deserialize_any`):
    `visitor.visit_seq(&mut SeqDeserializer::new(content))?`, then `end()`: the remaining elements
    are `Error::invalid_length(count + remaining, &ExpectedInSeq(count))`. -/
def visitContentSeq {X : Fam} {E : Type} (errInst : serde_core.de.Error E) (sub : (ContentTypes E).Dicts X) {V Value : Type} (vis : VisitorStep X V Value) (v : V) (xs : List Content) :
    Result (core.result.Result Value E) := do
  let (r, count) ← consumedRun (fun k => vis.visit_seq (sub.seqs ()) v (xs, k)) 0 xs.length
  match r with
  | .Err e => ok (.Err e)
  | .Ok value =>
    if count = xs.length then ok (.Ok value)
    else ok (.Err (← errInst.invalid_length ⟨BitVec.ofNat _ xs.length⟩ (expectedIn "sequence" count)))

/-- `visit_content_map(content, visitor)` (and `MapDeserializer::deserialize_any`):
    `visitor.visit_map(&mut MapDeserializer::new(content))?`, then `end()`: the remaining entries
    are `Error::invalid_length(count + remaining, &ExpectedInMap(count))`. -/
def visitContentMap {X : Fam} {E : Type} (errInst : serde_core.de.Error E) (sub : (ContentTypes E).Dicts X) {V Value : Type} (vis : VisitorStep X V Value) (v : V)
    (kvs : List (Content × Content)) : Result (core.result.Result Value E) := do
  let (r, count) ← consumedRun (fun k => vis.visit_map (sub.maps ()) v (kvs, none, k)) 0 kvs.length
  match r with
  | .Err e => ok (.Err e)
  | .Ok value =>
    if count = kvs.length then ok (.Ok value)
    else ok (.Err (← errInst.invalid_length ⟨BitVec.ofNat _ kvs.length⟩ (expectedIn "map" count)))

/-- `self.invalid_type(&visitor)`: `Error::invalid_type(content_unexpected(&self.content), &visitor)`. -/
def invalidTypeOf {X : Fam} {E : Type} (errInst : serde_core.de.Error E) {V Value : Type} (vis : VisitorStep X V Value) (v : V) (c : Content) :
    Result (core.result.Result Value E) := do
  invalidTypeErr errInst (← contentUnexpected c) (expectedOf vis.expecting v)

/-- `ContentDeserializer::deserialize_integer` -/
def deserializeInteger {X : Fam} {E : Type} (errInst : serde_core.de.Error E) {V Value : Type} (vis : VisitorStep X V Value) (c : Content) (v : V) :
    Result (core.result.Result Value E) :=
  match c with
  | .U8 x => vis.visit_u8 errInst v x
  | .U16 x => vis.visit_u16 errInst v x
  | .U32 x => vis.visit_u32 errInst v x
  | .U64 x => vis.visit_u64 errInst v x
  | .I8 x => vis.visit_i8 errInst v x
  | .I16 x => vis.visit_i16 errInst v x
  | .I32 x => vis.visit_i32 errInst v x
  | .I64 x => vis.visit_i64 errInst v x
  | _ => invalidTypeOf errInst vis v c

/-- `ContentDeserializer::deserialize_float` -/
def deserializeFloat {X : Fam} {E : Type} (errInst : serde_core.de.Error E) {V Value : Type} (vis : VisitorStep X V Value) (c : Content) (v : V) :
    Result (core.result.Result Value E) :=
  match c with
  | .F32 x => vis.visit_f32 errInst v x
  | .F64 x => vis.visit_f64 errInst v x
  | _ => deserializeInteger errInst vis c v

/-- `ContentDeserializer::deserialize_any` -/
def deserializeAny {X : Fam} {E : Type} (errInst : serde_core.de.Error E) (sub : (ContentTypes E).Dicts X) {V Value : Type} (vis : VisitorStep X V Value) (c : Content) (v : V) :
    Result (core.result.Result Value E) :=
  match c with
  | .Bool x => vis.visit_bool errInst v x
  | .F32 x => vis.visit_f32 errInst v x
  | .F64 x => vis.visit_f64 errInst v x
  | .Char x => vis.visit_char errInst v x
  | .String x => vis.visit_string errInst v x
  | .Str x => vis.visit_borrowed_str errInst v x
  | .ByteBuf x => vis.visit_byte_buf errInst v x
  | .Bytes x => vis.visit_borrowed_bytes errInst v x
  | .Unit => vis.visit_unit errInst v
  | .None => vis.visit_none errInst v
  | .Some x => vis.visit_some (sub.des ()) v ⟨x⟩
  | .Newtype x => vis.visit_newtype_struct (sub.des ()) v ⟨x⟩
  | .Seq x => visitContentSeq errInst sub vis v x.elems.toList
  | .Map x => visitContentMap errInst sub vis v x.elems.toList
  | _ => deserializeInteger errInst vis c v

/-- `impl<'de, E: Error> Deserializer<'de> for ContentDeserializer<'de, E>` one level above `sub`
    (serde's methods; `deserialize_i128`/`deserialize_u128` and `is_human_readable` are the
    provided ones). -/
def contentDeserializerStep {X : Fam} {E : Type} (errInst : serde_core.de.Error E) (sub : (ContentTypes E).Dicts X) : DeserializerF (Step X) (ContentDeserializer E) E :=
  let str : {V Value : Type} → VisitorStep X V Value → ContentDeserializer E → V →
      Result (core.result.Result Value E) := fun vis self v =>
    match self.content with
    | .String x => vis.visit_string errInst v x
    | .Str x => vis.visit_borrowed_str errInst v x
    | .ByteBuf x => vis.visit_byte_buf errInst v x
    | .Bytes x => vis.visit_borrowed_bytes errInst v x
    | c => invalidTypeOf errInst vis v c
  let bytes : {V Value : Type} → VisitorStep X V Value → ContentDeserializer E → V →
      Result (core.result.Result Value E) := fun vis self v =>
    match self.content with
    | .Seq x => visitContentSeq errInst sub vis v x.elems.toList
    | _ => str vis self v
  let seq : {V Value : Type} → VisitorStep X V Value → ContentDeserializer E → V →
      Result (core.result.Result Value E) := fun vis self v =>
    match self.content with
    | .Seq x => visitContentSeq errInst sub vis v x.elems.toList
    | c => invalidTypeOf errInst vis v c
  let int : {V Value : Type} → VisitorStep X V Value → ContentDeserializer E → V →
      Result (core.result.Result Value E) := fun vis self v => deserializeInteger errInst vis self.content v
  let float : {V Value : Type} → VisitorStep X V Value → ContentDeserializer E → V →
      Result (core.result.Result Value E) := fun vis self v => deserializeFloat errInst vis self.content v
  let any : {V Value : Type} → VisitorStep X V Value → ContentDeserializer E → V →
      Result (core.result.Result Value E) := fun vis self v => deserializeAny errInst sub vis self.content v
  { serde_coredeErrorInst := errInst
    deserialize_any := any
    deserialize_bool := fun vis self v =>
      match self.content with
      | .Bool x => vis.visit_bool errInst v x
      | c => invalidTypeOf errInst vis v c
    deserialize_i8 := int, deserialize_i16 := int, deserialize_i32 := int, deserialize_i64 := int
    deserialize_u8 := int, deserialize_u16 := int, deserialize_u32 := int, deserialize_u64 := int
    deserialize_f32 := float, deserialize_f64 := float
    deserialize_char := fun vis self v =>
      match self.content with
      | .Char x => vis.visit_char errInst v x
      | .String x => vis.visit_string errInst v x
      | .Str x => vis.visit_borrowed_str errInst v x
      | c => invalidTypeOf errInst vis v c
    deserialize_str := str, deserialize_string := str
    deserialize_bytes := bytes, deserialize_byte_buf := bytes
    deserialize_option := fun vis self v =>
      match self.content with
      | .None => vis.visit_none errInst v
      | .Some x => vis.visit_some (sub.des ()) v ⟨x⟩
      | .Unit => vis.visit_unit errInst v
      | _ => vis.visit_some (sub.des ()) v self
    deserialize_unit := fun vis self v =>
      match self.content with
      | .Unit => vis.visit_unit errInst v
      | .Map x => if x.len = 0 then vis.visit_unit errInst v else invalidTypeOf errInst vis v self.content
      | c => invalidTypeOf errInst vis v c
    deserialize_unit_struct := fun vis self _ v =>
      match self.content with
      | .Map x => if x.len = 0 then vis.visit_unit errInst v else any vis self v
      | .Seq x => if x.len = 0 then vis.visit_unit errInst v else any vis self v
      | _ => any vis self v
    deserialize_newtype_struct := fun vis self _ v =>
      match self.content with
      | .Newtype x => vis.visit_newtype_struct (sub.des ()) v ⟨x⟩
      | _ => vis.visit_newtype_struct (sub.des ()) v self
    deserialize_seq := seq
    deserialize_tuple := fun vis self _ v => seq vis self v
    deserialize_tuple_struct := fun vis self _ _ v => seq vis self v
    deserialize_map := fun vis self v =>
      match self.content with
      | .Map x => visitContentMap errInst sub vis v x.elems.toList
      | c => invalidTypeOf errInst vis v c
    deserialize_struct := fun vis self _ _ v =>
      match self.content with
      | .Seq x => visitContentSeq errInst sub vis v x.elems.toList
      | .Map x => visitContentMap errInst sub vis v x.elems.toList
      | c => invalidTypeOf errInst vis v c
    deserialize_enum := fun vis self _ _ v => do
      match self.content with
      | .Map x =>
        match x.elems.toList with
        | [(variant, value)] => vis.visit_enum (sub.enums ()) v (variant, some value)
        | _ => ok (.Err (← errInst.invalid_value .Map (expectedStr "map with a single key")))
      | .String s => vis.visit_enum (sub.enums ()) v (.String s, none)
      | .Str s => vis.visit_enum (sub.enums ()) v (.Str s, none)
      | c => invalidTypeErr errInst (← contentUnexpected c) (expectedStr "string or map")
    deserialize_identifier := fun vis self v =>
      match self.content with
      | .String x => vis.visit_string errInst v x
      | .Str x => vis.visit_borrowed_str errInst v x
      | .ByteBuf x => vis.visit_byte_buf errInst v x
      | .Bytes x => vis.visit_borrowed_bytes errInst v x
      | .U8 x => vis.visit_u8 errInst v x
      | .U64 x => vis.visit_u64 errInst v x
      | c => invalidTypeOf errInst vis v c
    deserialize_ignored_any := fun vis _ v => vis.visit_unit errInst v
    __deserialize_content_v1 := fun _ self _ => ok (.Ok self.content) }

/-- `impl SeqAccess for SeqDeserializer` (through `&mut`): the next element through
    `seed.deserialize(ContentDeserializer::new(value))`; `size_hint` is the exact remaining length. -/
def contentSeqStep {X : Fam} {E : Type} (errInst : serde_core.de.Error E) (sub : (ContentTypes E).Dicts X) : SeqAccessF (Step X) (List Content × Nat) E :=
  { serde_coredeErrorInst := errInst
    next_element_seed := fun seed st t =>
      match st with
      | ([], _) => ok (.Ok none, st)
      | (_ :: _, 0) => .div
      | (c :: rest, budget + 1) => do
        match ← seed.deserialize (sub.des ()) t ⟨c⟩ with
        | .Ok x => ok (.Ok (some x), (rest, budget))
        | .Err e => ok (.Err e, (rest, budget))
    size_hint := fun st => ok (some ⟨BitVec.ofNat _ st.1.length⟩) }

/-- `impl MapAccess for MapDeserializer` (through `&mut`): `next_key_seed` keeps the entry's value
    for `next_value_seed` (which panics without one: "MapAccess::next_value called before
    next_key"), `next_entry_seed` deserializes the key then the value; `size_hint` is the exact
    number of remaining entries. -/
def contentMapStep {X : Fam} {E : Type} (errInst : serde_core.de.Error E) (sub : (ContentTypes E).Dicts X) : MapAccessF (Step X) (List (Content × Content) × Option Content × Nat) E :=
  { serde_coredeErrorInst := errInst
    next_key_seed := fun seed st k =>
      match st with
      | ([], _, _) => ok (.Ok none, st)
      | (_ :: _, _, 0) => .div
      | ((key, value) :: rest, _, budget + 1) => do
        match ← seed.deserialize (sub.des ()) k ⟨key⟩ with
        | .Ok x => ok (.Ok (some x), (rest, some value, budget))
        | .Err e => ok (.Err e, (rest, some value, budget))
    next_value_seed := fun seed st v =>
      match st with
      | (_, none, _) => .fail .panic
      | (rest, some value, budget) => do
        let r ← seed.deserialize (sub.des ()) v ⟨value⟩
        ok (r, (rest, none, budget))
    next_entry_seed := fun kseed vseed st k v =>
      match st with
      | ([], _, _) => ok (.Ok none, st)
      | (_ :: _, _, 0) => .div
      | ((key, value) :: rest, pending, budget + 1) => do
        match ← kseed.deserialize (sub.des ()) k ⟨key⟩ with
        | .Err e => ok (.Err e, (rest, pending, budget))
        | .Ok key =>
          match ← vseed.deserialize (sub.des ()) v ⟨value⟩ with
          | .Err e => ok (.Err e, (rest, pending, budget))
          | .Ok value => ok (.Ok (some (key, value)), (rest, pending, budget))
    size_hint := fun st => ok (some ⟨BitVec.ofNat _ st.1.length⟩) }

/-- `impl VariantAccess for VariantDeserializer`, `unitDe` being `impl Deserialize for ()` one level
    above `sub`. -/
def contentVariantStep {X : Fam} {E : Type} (errInst : serde_core.de.Error E) (sub : (ContentTypes E).Dicts X) (unitDe : (Step X).Deserialize Unit) :
    VariantAccessF (Step X) (Option Content) E :=
  { serde_coredeErrorInst := errInst
    unit_variant := fun st =>
      match st with
      | some value => unitDe.deserialize (sub.des ()) ⟨value⟩
      | none => ok (.Ok ())
    newtype_variant_seed := fun seed st t => do
      match st with
      | some value => seed.deserialize (sub.des ()) t ⟨value⟩
      | none => invalidTypeErr errInst .UnitVariant (expectedStr "newtype variant")
    tuple_variant := fun vis st _ v => do
      match st with
      | some (.Seq x) => visitContentSeq errInst sub vis v x.elems.toList
      | some other => invalidTypeErr errInst (← contentUnexpected other) (expectedStr "tuple variant")
      | none => invalidTypeErr errInst .UnitVariant (expectedStr "tuple variant")
    struct_variant := fun vis st _ v => do
      match st with
      | some (.Map x) => visitContentMap errInst sub vis v x.elems.toList
      | some (.Seq x) => visitContentSeq errInst sub vis v x.elems.toList
      | some other =>
        invalidTypeErr errInst (← contentUnexpected other) (expectedStr "struct variant")
      | none => invalidTypeErr errInst .UnitVariant (expectedStr "struct variant") }

/-- `impl EnumAccess for EnumDeserializer`: `seed.deserialize(ContentDeserializer::new(variant))`,
    with the variant's value in the `VariantDeserializer`. -/
def contentEnumStep {X : Fam} {E : Type} (errInst : serde_core.de.Error E) (sub : (ContentTypes E).Dicts X) (unitDe : (Step X).Deserialize Unit) :
    EnumAccessF (Step X) (Content × Option Content) E (Option Content) :=
  { serde_coredeErrorInst := errInst
    VariantAccessInst := contentVariantStep errInst sub unitDe
    variant_seed := fun seed st v => do
      match ← seed.deserialize (sub.des ()) v ⟨st.1⟩ with
      | .Ok x => ok (.Ok (x, st.2))
      | .Err e => ok (.Err e) }

/-- The dictionaries of `ContentDeserializer<E>` and its access types at level `n` of the knot
    (`unit_variant` calls `impl Deserialize for ()`, so they are built level by level). -/
def contentDeAt {E : Type} (errInst : serde_core.de.Error E) : (n : Nat) → (ContentTypes E).Dicts (DeAt n)
  | 0 => bottom (DeAt 0) (ContentTypes E)
  | n + 1 =>
    let sub := contentDeAt errInst n
    let unitDe := (Deserialize.wrap serde_core.de.impls.DeserializeUnit).level (n + 1)
    { des := fun _ => contentDeserializerStep errInst sub
      seqs := fun _ => contentSeqStep errInst sub
      maps := fun _ => contentMapStep errInst sub
      enums := fun _ => contentEnumStep errInst sub unitDe
      variants := fun _ => contentVariantStep errInst sub unitDe }

/-- `impl<'de, E: Error> Deserializer<'de> for ContentDeserializer<'de, E>` as a Rust trait
    dictionary: a content has no nesting bound, each method runs at the first level with a result. -/
@[reducible, rust_trait_impl
  "serde_core::de::Deserializer<'de, serde::private::de::content::ContentDeserializer<'de, @E>, @E>"]
def DeserializerContentDeserializer {E : Type} (errInst : serde_core.de.Error E) : serde_core.de.Deserializer (ContentDeserializer E) E :=
  FormatLevels.limit (contentDeAt errInst) () errInst

/-- `ContentDeserializer::deserialize_any(self, visitor)` called directly (the derive's struct
    variants): the dictionary's method with the wrapped visitor. -/
@[rust_fun
  "serde::private::de::content::{serde_core::de::Deserializer<'de, serde::private::de::content::ContentDeserializer<'de, @E>, @E>}::deserialize_any"]
def DeserializerContentDeserializer.deserialize_any {E : Type} (errInst : serde_core.de.Error E) {V Value : Type}
    (visInst : serde_core.de.Visitor V Value) (self : ContentDeserializer E) (visitor : V) :
    Result (core.result.Result Value E) :=
  (DeserializerContentDeserializer errInst).deserialize_any (Visitor.wrap visInst) self visitor

end serde.private.de.content

end Aeneas.Std
