import Aeneas.Std.Core.Cmp

namespace Aeneas.Std

open Result

@[rust_fun "core::tuple::{core::cmp::PartialEq<(@U, @T), (@U, @T)>}::eq"]
def core.tuple.PartialEqPair.eq {U T : Type}
    (first : core.cmp.PartialEq U U) (second : core.cmp.PartialEq T T)
    (x y : U × T) : Result Bool := do
  if ← first.eq x.1 y.1 then second.eq x.2 y.2 else ok false

-- Rust's tuple `ne` uses each component's `ne`, not the negation of tuple `eq`.
@[rust_fun "core::tuple::{core::cmp::PartialEq<(@U, @T), (@U, @T)>}::ne"]
def core.tuple.PartialEqPair.ne {U T : Type}
    (first : core.cmp.PartialEq U U) (second : core.cmp.PartialEq T T)
    (x y : U × T) : Result Bool := do
  if ← first.ne x.1 y.1 then ok true else second.ne x.2 y.2

/-- `PartialEq for (V, U, T)` (core/src/tuple.rs): the components compared in order with
    `&&`, so a later component is only compared when the earlier ones are equal. -/
@[rust_fun "core::tuple::{core::cmp::PartialEq<(@V, @U, @T), (@V, @U, @T)>}::eq"]
def core.tuple.PartialEqTriple.eq {V U T : Type}
    (first : core.cmp.PartialEq V V) (second : core.cmp.PartialEq U U)
    (third : core.cmp.PartialEq T T) (x y : V × U × T) : Result Bool := do
  if ← first.eq x.1 y.1 then
    if ← second.eq x.2.1 y.2.1 then third.eq x.2.2 y.2.2 else ok false
  else ok false

/-- `PartialEq for (W, V, U, T)` (core/src/tuple.rs): the components compared in order with
    `&&`, so a later component is only compared when the earlier ones are equal. -/
@[rust_fun "core::tuple::{core::cmp::PartialEq<(@W, @V, @U, @T), (@W, @V, @U, @T)>}::eq"]
def core.tuple.PartialEqQuad.eq {W V U T : Type}
    (first : core.cmp.PartialEq W W) (second : core.cmp.PartialEq V V)
    (third : core.cmp.PartialEq U U) (fourth : core.cmp.PartialEq T T)
    (x y : W × V × U × T) : Result Bool := do
  if ← first.eq x.1 y.1 then
    if ← second.eq x.2.1 y.2.1 then
      if ← third.eq x.2.2.1 y.2.2.1 then fourth.eq x.2.2.2 y.2.2.2 else ok false
    else ok false
  else ok false

@[reducible, rust_trait_impl "core::cmp::PartialEq<(@U, @T), (@U, @T)>"]
def core.cmp.PartialEqPair {U T : Type}
    (first : core.cmp.PartialEq U U) (second : core.cmp.PartialEq T T) :
    core.cmp.PartialEq (U × T) (U × T) := {
  eq := core.tuple.PartialEqPair.eq first second
  ne := core.tuple.PartialEqPair.ne first second
}

@[reducible, rust_trait_impl "core::cmp::Eq<(@U, @T)>"]
def core.cmp.EqPair {U T : Type} (first : core.cmp.Eq U) (second : core.cmp.Eq T) :
    core.cmp.Eq (U × T) := {
  partialEqInst := core.cmp.PartialEqPair first.partialEqInst second.partialEqInst
}

@[rust_fun "core::tuple::{core::cmp::PartialOrd<(@U, @T), (@U, @T)>}::partial_cmp"]
def core.tuple.PartialOrdPair.partial_cmp {U T : Type}
    (first : core.cmp.PartialOrd U U) (second : core.cmp.PartialOrd T T)
    (x y : U × T) : Result (Option Ordering) := do
  match ← first.partial_cmp x.1 y.1 with
  | some .eq => second.partial_cmp x.2 y.2
  | ordering => ok ordering

-- `lexical_ord!` preserves the prefix's chaining override and calls the last
-- component's relational method only when that override returns Continue.
@[rust_fun "core::tuple::{core::cmp::PartialOrd<(@U, @T), (@U, @T)>}::lt"]
def core.tuple.PartialOrdPair.lt {U T : Type}
    (first : core.cmp.PartialOrd U U) (second : core.cmp.PartialOrd T T)
    (x y : U × T) : Result Bool := do
  match ← first.__chaining_lt x.1 y.1 with
  | .Continue () => second.lt x.2 y.2
  | .Break answer => ok answer

@[rust_fun "core::tuple::{core::cmp::PartialOrd<(@U, @T), (@U, @T)>}::le"]
def core.tuple.PartialOrdPair.le {U T : Type}
    (first : core.cmp.PartialOrd U U) (second : core.cmp.PartialOrd T T)
    (x y : U × T) : Result Bool := do
  match ← first.__chaining_le x.1 y.1 with
  | .Continue () => second.le x.2 y.2
  | .Break answer => ok answer

@[rust_fun "core::tuple::{core::cmp::PartialOrd<(@U, @T), (@U, @T)>}::gt"]
def core.tuple.PartialOrdPair.gt {U T : Type}
    (first : core.cmp.PartialOrd U U) (second : core.cmp.PartialOrd T T)
    (x y : U × T) : Result Bool := do
  match ← first.__chaining_gt x.1 y.1 with
  | .Continue () => second.gt x.2 y.2
  | .Break answer => ok answer

@[rust_fun "core::tuple::{core::cmp::PartialOrd<(@U, @T), (@U, @T)>}::ge"]
def core.tuple.PartialOrdPair.ge {U T : Type}
    (first : core.cmp.PartialOrd U U) (second : core.cmp.PartialOrd T T)
    (x y : U × T) : Result Bool := do
  match ← first.__chaining_ge x.1 y.1 with
  | .Continue () => second.ge x.2 y.2
  | .Break answer => ok answer

@[reducible, rust_trait_impl "core::cmp::PartialOrd<(@U, @T), (@U, @T)>"]
def core.cmp.PartialOrdPair {U T : Type}
    (first : core.cmp.PartialOrd U U) (second : core.cmp.PartialOrd T T) :
    core.cmp.PartialOrd (U × T) (U × T) := {
  partialEqInst := core.cmp.PartialEqPair first.partialEqInst second.partialEqInst
  partial_cmp := core.tuple.PartialOrdPair.partial_cmp first second
  lt := core.tuple.PartialOrdPair.lt first second
  le := core.tuple.PartialOrdPair.le first second
  gt := core.tuple.PartialOrdPair.gt first second
  ge := core.tuple.PartialOrdPair.ge first second
}

@[rust_fun "core::tuple::{core::cmp::Ord<(@U, @T)>}::cmp"]
def core.tuple.OrdPair.cmp {U T : Type}
    (first : core.cmp.Ord U) (second : core.cmp.Ord T)
    (x y : U × T) : Result Ordering := do
  match ← first.cmp x.1 y.1 with
  | .eq => second.cmp x.2 y.2
  | ordering => ok ordering

@[reducible, rust_trait_impl "core::cmp::Ord<(@U, @T)>"]
def core.cmp.OrdPair {U T : Type} (first : core.cmp.Ord U) (second : core.cmp.Ord T) :
    core.cmp.Ord (U × T) := {
  eqInst := core.cmp.EqPair first.eqInst second.eqInst
  partialOrdInst := core.cmp.PartialOrdPair first.partialOrdInst second.partialOrdInst
  cmp := core.tuple.OrdPair.cmp first second
}

end Aeneas.Std
