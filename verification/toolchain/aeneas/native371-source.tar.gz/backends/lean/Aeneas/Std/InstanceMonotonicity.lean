import Aeneas.Std.Array
import Aeneas.Std.BTreeMap
import Aeneas.Std.BTreeSet
import Aeneas.Std.Core
import Aeneas.Std.SliceCmp
import Aeneas.Std.Sync
import Aeneas.Std.Tuple
import Aeneas.Std.Vec
import Aeneas.Std.VecIter
import Aeneas.Std.SliceIter
import Aeneas.Std.ResultIter

/-!
# Monotonicity of the models in their trait instances

The methods of a type which is recursive through a collection (`Vec<Self>`,
`Option<Box<Self>>`, `BTreeMap<K, Self>`, ...) call the model of the
collection's trait implementation with an instance built from the method being
defined, e.g. the derived `Clone` of `enum T { Node(Vec<T>) }` is

```
def T.clone (self : T) : Result T := do
  match self with
  | .Node v => ... alloc.vec.CloneVec.clone { clone := T.clone } v ...
partial_fixpoint
```

`partial_fixpoint` needs the body to be monotone in the recursive function,
so the monotonicity prover needs to know that every such model is monotone in
the methods of its instance arguments. The lemmas below state this for the
models of the implementations of the derivable traits (`Clone`, `PartialEq`,
`PartialOrd`, `Ord`, `Debug`) on containers. Each instance argument is a structure literal whose
fields all depend on the recursive function `g`; the hypotheses only concern
the fields the model calls (e.g. `PartialEq for [T]` compares with `ne`).
Each lemma comes in the forms the derived code produces: the model applied to
its instances only (when it is itself a field of an enclosing instance, e.g.
`PartialEqShared (PartialEqVec {..})`) and fully applied (the discrimination
tree keys of the monotonicity lemmas include the number of arguments).

Collection uses next, fold, try_fold, or indexed access through collectNative.
The proofs retain each selected method and its terminal iterator state.
Function-item collection uses separate fold and try_fold state laws.

An actual next-based try_fold method establishes its residual law.
The proof covers both values of the in_place_collect flag.
The flag does not establish a method law or a native layout certificate.
Section AdapterMono replaces function-item state with a stateless closure.
-/

namespace Aeneas.Std

open Lean.Order

section CloneMono

variable {γ : Type w} [Lean.Order.PartialOrder γ]

/-- `List.clone` is the element-wise fallible map; its length proof is carried by
    the result. -/
theorem List.clone_eq_bind {α : Type u} (c : α → Result α) (l : List α) :
    List.clone c l = (List.mapM c l >>= fun v =>
      if h : v.length = l.length then .ok ⟨v, h⟩ else .div) := by
  unfold List.clone
  split
  · rename_i v h
    simp [h, List.mapM_Result_length h]
  · rename_i h; simp [h]
  · rename_i h; simp [h]

@[partial_fixpoint_monotone]
theorem List.clone.monotone {α : Type u} (c : γ → α → Result α) (l : List α)
    (hmono : Lean.Order.monotone c) : Lean.Order.monotone (fun g => List.clone (c g) l) := by
  simp only [List.clone_eq_bind]
  exact monotone_bind Result _ _ (List.monotone_mapM c l hmono) (monotone_const _)

@[partial_fixpoint_monotone]
theorem Slice.clone.monotone {α : Type} (c : γ → α → Result α) (s : Slice α)
    (hmono : Lean.Order.monotone c) : Lean.Order.monotone (fun g => Slice.clone (c g) s) :=
  monotone_bind Result _ _ (List.clone.monotone c s.val hmono) (monotone_const _)

@[partial_fixpoint_monotone]
theorem Array.clone.monotone {α : Type u} {n : Usize} (c : γ → α → Result α) (s : Array α n)
    (hmono : Lean.Order.monotone c) : Lean.Order.monotone (fun g => Array.clone (c g) s) :=
  monotone_bind Result _ _ (List.clone.monotone c s.val hmono) (monotone_const _)

@[partial_fixpoint_monotone]
theorem core.alloc.boxed.CloneBox.clone.monotone {T : Type}
    (clone : γ → T → Result T) (clone_from : γ → T → T → Result T) (hmono : Lean.Order.monotone clone) :
    Lean.Order.monotone (fun g => core.alloc.boxed.CloneBox.clone { clone := clone g, clone_from := clone_from g }) :=
  hmono

@[partial_fixpoint_monotone]
theorem core.alloc.boxed.CloneBox.clone.apply_monotone {T : Type}
    (clone : γ → T → Result T) (clone_from : γ → T → T → Result T) (x : T)
    (hmono : Lean.Order.monotone clone) :
    Lean.Order.monotone (fun g => core.alloc.boxed.CloneBox.clone
      { clone := clone g, clone_from := clone_from g } x) :=
  monotone_apply x _ hmono

@[partial_fixpoint_monotone]
theorem alloc.vec.CloneVec.clone.monotone {T : Type}
    (clone : γ → T → Result T) (clone_from : γ → T → T → Result T) (hmono : Lean.Order.monotone clone) :
    Lean.Order.monotone (fun g => alloc.vec.CloneVec.clone { clone := clone g, clone_from := clone_from g }) :=
  monotone_of_monotone_apply _ fun v => Slice.clone.monotone clone v hmono

@[partial_fixpoint_monotone]
theorem alloc.vec.CloneVec.clone.apply_monotone {T : Type}
    (clone : γ → T → Result T) (clone_from : γ → T → T → Result T) (v : alloc.vec.Vec T)
    (hmono : Lean.Order.monotone clone) :
    Lean.Order.monotone (fun g => alloc.vec.CloneVec.clone
      { clone := clone g, clone_from := clone_from g } v) :=
  Slice.clone.monotone clone v hmono

@[partial_fixpoint_monotone]
theorem alloc.boxed.CloneBoxSlice.clone.monotone {T : Type}
    (clone : γ → T → Result T) (clone_from : γ → T → T → Result T) (hmono : Lean.Order.monotone clone) :
    Lean.Order.monotone (fun g => alloc.boxed.CloneBoxSlice.clone
      { clone := clone g, clone_from := clone_from g }) :=
  monotone_of_monotone_apply _ fun s => Slice.clone.monotone clone s hmono

@[partial_fixpoint_monotone]
theorem alloc.boxed.CloneBoxSlice.clone.apply_monotone {T : Type}
    (clone : γ → T → Result T) (clone_from : γ → T → T → Result T) (s : Slice T)
    (hmono : Lean.Order.monotone clone) :
    Lean.Order.monotone (fun g => alloc.boxed.CloneBoxSlice.clone
      { clone := clone g, clone_from := clone_from g } s) :=
  Slice.clone.monotone clone s hmono

@[partial_fixpoint_monotone]
theorem core.array.CloneArray.clone.monotone {T : Type} {N : Usize}
    (clone : γ → T → Result T) (clone_from : γ → T → T → Result T) (hmono : Lean.Order.monotone clone) :
    Lean.Order.monotone (fun g => core.array.CloneArray.clone (N := N)
      { clone := clone g, clone_from := clone_from g }) :=
  monotone_of_monotone_apply _ fun a => Array.clone.monotone clone a hmono

@[partial_fixpoint_monotone]
theorem core.array.CloneArray.clone.apply_monotone {T : Type} {N : Usize}
    (clone : γ → T → Result T) (clone_from : γ → T → T → Result T) (a : Array T N)
    (hmono : Lean.Order.monotone clone) :
    Lean.Order.monotone (fun g => core.array.CloneArray.clone
      { clone := clone g, clone_from := clone_from g } a) :=
  Array.clone.monotone clone a hmono

@[partial_fixpoint_monotone]
theorem core.option.Option.Clone.clone.apply_monotone {T : Type}
    (clone : γ → T → Result T) (clone_from : γ → T → T → Result T) (x : Option T)
    (hmono : Lean.Order.monotone clone) :
    Lean.Order.monotone (fun g => core.option.Option.Clone.clone
      { clone := clone g, clone_from := clone_from g } x) := by
  cases x with
  | none => exact monotone_const _
  | some v => exact monotone_bind Result _ _ (monotone_apply v _ hmono) (monotone_const _)

@[partial_fixpoint_monotone]
theorem core.option.Option.Clone.clone.monotone {T : Type}
    (clone : γ → T → Result T) (clone_from : γ → T → T → Result T) (hmono : Lean.Order.monotone clone) :
    Lean.Order.monotone (fun g => core.option.Option.Clone.clone
      { clone := clone g, clone_from := clone_from g }) :=
  monotone_of_monotone_apply _ fun x =>
    core.option.Option.Clone.clone.apply_monotone clone clone_from x hmono

@[partial_fixpoint_monotone]
theorem alloc.collections.btree.map.BTreeMap.clone.apply_monotone {K V : Type}
    (kclone : γ → K → Result K) (kclone_from : γ → K → K → Result K)
    (vclone : γ → V → Result V) (vclone_from : γ → V → V → Result V)
    (map : alloc.collections.btree.map.BTreeMap K V)
    (hk : Lean.Order.monotone kclone) (hv : Lean.Order.monotone vclone) :
    Lean.Order.monotone (fun g => alloc.collections.btree.map.BTreeMap.clone
      { clone := kclone g, clone_from := kclone_from g }
      { clone := vclone g, clone_from := vclone_from g } map) := by
  simp only [alloc.collections.btree.map.BTreeMap.clone]
  repeat' first
    | exact monotone_apply _ _ hk
    | exact monotone_apply _ _ hv
    | monotonicity

@[partial_fixpoint_monotone]
theorem alloc.collections.btree.map.BTreeMap.clone.monotone {K V : Type}
    (kclone : γ → K → Result K) (kclone_from : γ → K → K → Result K)
    (vclone : γ → V → Result V) (vclone_from : γ → V → V → Result V)
    (hk : Lean.Order.monotone kclone) (hv : Lean.Order.monotone vclone) :
    Lean.Order.monotone (fun g => alloc.collections.btree.map.BTreeMap.clone
      { clone := kclone g, clone_from := kclone_from g }
      { clone := vclone g, clone_from := vclone_from g }) :=
  monotone_of_monotone_apply _ fun map =>
    alloc.collections.btree.map.BTreeMap.clone.apply_monotone
      kclone kclone_from vclone vclone_from map hk hv

end CloneMono

section PartialEqMono

variable {γ : Type w} [Lean.Order.PartialOrder γ]

@[partial_fixpoint_monotone]
theorem alloc.vec.partial_eq.PartialEqVec.eq.apply_monotone {T U : Type}
    (eq ne : γ → T → U → Result Bool) (v0 : alloc.vec.Vec T) (v1 : alloc.vec.Vec U)
    (hmono : Lean.Order.monotone eq) :
    Lean.Order.monotone (fun g => alloc.vec.partial_eq.PartialEqVec.eq
      { eq := eq g, ne := ne g } v0 v1) := by
  simp only [alloc.vec.partial_eq.PartialEqVec.eq]
  repeat' first
    | exact monotone_apply _ _ (monotone_apply _ _ hmono)
    | monotonicity

@[partial_fixpoint_monotone]
theorem alloc.vec.partial_eq.PartialEqVec.eq.monotone {T U : Type}
    (eq ne : γ → T → U → Result Bool) (hmono : Lean.Order.monotone eq) :
    Lean.Order.monotone (fun g => alloc.vec.partial_eq.PartialEqVec.eq { eq := eq g, ne := ne g }) :=
  monotone_of_monotone_apply _ fun v0 => monotone_of_monotone_apply _ fun v1 =>
    alloc.vec.partial_eq.PartialEqVec.eq.apply_monotone eq ne v0 v1 hmono

@[partial_fixpoint_monotone]
theorem alloc.vec.partial_eq.PartialEqVec.ne.apply_monotone {T U : Type}
    (eq ne : γ → T → U → Result Bool) (v0 : alloc.vec.Vec T) (v1 : alloc.vec.Vec U)
    (hmono : Lean.Order.monotone ne) :
    Lean.Order.monotone (fun g => alloc.vec.partial_eq.PartialEqVec.ne
      { eq := eq g, ne := ne g } v0 v1) := by
  simp only [alloc.vec.partial_eq.PartialEqVec.ne]
  repeat' first
    | exact monotone_apply _ _ (monotone_apply _ _ hmono)
    | monotonicity

@[partial_fixpoint_monotone]
theorem alloc.vec.partial_eq.PartialEqVec.ne.monotone {T U : Type}
    (eq ne : γ → T → U → Result Bool) (hmono : Lean.Order.monotone ne) :
    Lean.Order.monotone (fun g => alloc.vec.partial_eq.PartialEqVec.ne { eq := eq g, ne := ne g }) :=
  monotone_of_monotone_apply _ fun v0 => monotone_of_monotone_apply _ fun v1 =>
    alloc.vec.partial_eq.PartialEqVec.ne.apply_monotone eq ne v0 v1 hmono

@[partial_fixpoint_monotone]
theorem core.slice.cmp.eqList.monotone {T U : Type} (ne : γ → T → U → Result Bool)
    (xs : List T) (ys : List U) (hmono : Lean.Order.monotone ne) :
    Lean.Order.monotone (fun g => core.slice.cmp.eqList (ne g) xs ys) := by
  induction xs generalizing ys with
  | nil => exact monotone_const _
  | cons x xs ih =>
    cases ys with
    | nil => exact monotone_const _
    | cons y ys =>
      simp only [core.slice.cmp.eqList]
      repeat' first
        | exact ih _
        | exact monotone_apply _ _ (monotone_apply _ _ hmono)
        | monotonicity

@[partial_fixpoint_monotone]
theorem core.slice.cmp.PartialEqSlice.eq.apply_monotone {T U : Type}
    (eq ne : γ → T → U → Result Bool) (x : Slice T) (y : Slice U) (hmono : Lean.Order.monotone ne) :
    Lean.Order.monotone (fun g => core.slice.cmp.PartialEqSlice.eq { eq := eq g, ne := ne g } x y) := by
  simp only [core.slice.cmp.PartialEqSlice.eq]
  repeat' first
    | exact core.slice.cmp.eqList.monotone ne _ _ hmono
    | monotonicity

@[partial_fixpoint_monotone]
theorem core.slice.cmp.PartialEqSlice.eq.monotone {T U : Type}
    (eq ne : γ → T → U → Result Bool) (hmono : Lean.Order.monotone ne) :
    Lean.Order.monotone (fun g => core.slice.cmp.PartialEqSlice.eq { eq := eq g, ne := ne g }) :=
  monotone_of_monotone_apply _ fun x => monotone_of_monotone_apply _ fun y =>
    core.slice.cmp.PartialEqSlice.eq.apply_monotone eq ne x y hmono

@[partial_fixpoint_monotone]
theorem core.slice.cmp.PartialEqSlice.ne.apply_monotone {T U : Type}
    (eq ne : γ → T → U → Result Bool) (x : Slice T) (y : Slice U) (hmono : Lean.Order.monotone ne) :
    Lean.Order.monotone (fun g => core.slice.cmp.PartialEqSlice.ne { eq := eq g, ne := ne g } x y) :=
  monotone_bind Result _ _
    (core.slice.cmp.PartialEqSlice.eq.apply_monotone eq ne x y hmono) (monotone_const _)

@[partial_fixpoint_monotone]
theorem core.slice.cmp.PartialEqSlice.ne.monotone {T U : Type}
    (eq ne : γ → T → U → Result Bool) (hmono : Lean.Order.monotone ne) :
    Lean.Order.monotone (fun g => core.slice.cmp.PartialEqSlice.ne { eq := eq g, ne := ne g }) :=
  monotone_of_monotone_apply _ fun x => monotone_of_monotone_apply _ fun y =>
    core.slice.cmp.PartialEqSlice.ne.apply_monotone eq ne x y hmono

@[partial_fixpoint_monotone]
theorem core.option.Option.Insts.CoreCmpPartialEqOption.eq.apply_monotone {T : Type}
    (eq ne : γ → T → T → Result Bool) (x y : Option T) (hmono : Lean.Order.monotone eq) :
    Lean.Order.monotone (fun g => core.option.Option.Insts.CoreCmpPartialEqOption.eq
      { eq := eq g, ne := ne g } x y) := by
  cases x <;> cases y <;> simp only [core.option.Option.Insts.CoreCmpPartialEqOption.eq] <;>
    first
      | exact monotone_const _
      | exact monotone_apply _ _ (monotone_apply _ _ hmono)

@[partial_fixpoint_monotone]
theorem core.option.Option.Insts.CoreCmpPartialEqOption.eq.monotone {T : Type}
    (eq ne : γ → T → T → Result Bool) (hmono : Lean.Order.monotone eq) :
    Lean.Order.monotone (fun g => core.option.Option.Insts.CoreCmpPartialEqOption.eq
      { eq := eq g, ne := ne g }) :=
  monotone_of_monotone_apply _ fun x => monotone_of_monotone_apply _ fun y =>
    core.option.Option.Insts.CoreCmpPartialEqOption.eq.apply_monotone eq ne x y hmono

@[partial_fixpoint_monotone]
theorem core.tuple.PartialEqPair.eq.apply_monotone {U T : Type}
    (eq₁ ne₁ : γ → U → U → Result Bool) (eq₂ ne₂ : γ → T → T → Result Bool) (x y : U × T)
    (h₁ : Lean.Order.monotone eq₁) (h₂ : Lean.Order.monotone eq₂) :
    Lean.Order.monotone (fun g => core.tuple.PartialEqPair.eq
      { eq := eq₁ g, ne := ne₁ g } { eq := eq₂ g, ne := ne₂ g } x y) := by
  simp only [core.tuple.PartialEqPair.eq]
  repeat' first
    | exact monotone_apply _ _ (monotone_apply _ _ h₁)
    | exact monotone_apply _ _ (monotone_apply _ _ h₂)
    | monotonicity

@[partial_fixpoint_monotone]
theorem core.tuple.PartialEqPair.eq.monotone {U T : Type}
    (eq₁ ne₁ : γ → U → U → Result Bool) (eq₂ ne₂ : γ → T → T → Result Bool)
    (h₁ : Lean.Order.monotone eq₁) (h₂ : Lean.Order.monotone eq₂) :
    Lean.Order.monotone (fun g => core.tuple.PartialEqPair.eq
      { eq := eq₁ g, ne := ne₁ g } { eq := eq₂ g, ne := ne₂ g }) :=
  monotone_of_monotone_apply _ fun x => monotone_of_monotone_apply _ fun y =>
    core.tuple.PartialEqPair.eq.apply_monotone eq₁ ne₁ eq₂ ne₂ x y h₁ h₂

@[partial_fixpoint_monotone]
theorem core.tuple.PartialEqPair.ne.apply_monotone {U T : Type}
    (eq₁ ne₁ : γ → U → U → Result Bool) (eq₂ ne₂ : γ → T → T → Result Bool) (x y : U × T)
    (h₁ : Lean.Order.monotone ne₁) (h₂ : Lean.Order.monotone ne₂) :
    Lean.Order.monotone (fun g => core.tuple.PartialEqPair.ne
      { eq := eq₁ g, ne := ne₁ g } { eq := eq₂ g, ne := ne₂ g } x y) := by
  simp only [core.tuple.PartialEqPair.ne]
  repeat' first
    | exact monotone_apply _ _ (monotone_apply _ _ h₁)
    | exact monotone_apply _ _ (monotone_apply _ _ h₂)
    | monotonicity

@[partial_fixpoint_monotone]
theorem core.tuple.PartialEqPair.ne.monotone {U T : Type}
    (eq₁ ne₁ : γ → U → U → Result Bool) (eq₂ ne₂ : γ → T → T → Result Bool)
    (h₁ : Lean.Order.monotone ne₁) (h₂ : Lean.Order.monotone ne₂) :
    Lean.Order.monotone (fun g => core.tuple.PartialEqPair.ne
      { eq := eq₁ g, ne := ne₁ g } { eq := eq₂ g, ne := ne₂ g }) :=
  monotone_of_monotone_apply _ fun x => monotone_of_monotone_apply _ fun y =>
    core.tuple.PartialEqPair.ne.apply_monotone eq₁ ne₁ eq₂ ne₂ x y h₁ h₂

@[partial_fixpoint_monotone]
theorem alloc.collections.btree.map.eqEntries.monotone {K V : Type}
    (keq kne : γ → K → K → Result Bool) (veq vne : γ → V → V → Result Bool)
    (l r : List (K × V)) (hk : Lean.Order.monotone keq) (hv : Lean.Order.monotone veq) :
    Lean.Order.monotone (fun g => alloc.collections.btree.map.eqEntries
      { eq := keq g, ne := kne g } { eq := veq g, ne := vne g } l r) := by
  induction l generalizing r with
  | nil => exact monotone_const _
  | cons e l ih =>
    cases r with
    | nil => exact monotone_const _
    | cons e' r =>
      simp only [alloc.collections.btree.map.eqEntries]
      repeat' first
        | exact ih _
        | exact monotone_apply _ _ (monotone_apply _ _ hk)
        | exact monotone_apply _ _ (monotone_apply _ _ hv)
        | monotonicity

@[partial_fixpoint_monotone]
theorem alloc.collections.btree.map.PartialEqBTreeMap.eq.apply_monotone {K V : Type}
    (keq kne : γ → K → K → Result Bool) (veq vne : γ → V → V → Result Bool)
    (l r : alloc.collections.btree.map.BTreeMap K V) (hk : Lean.Order.monotone keq) (hv : Lean.Order.monotone veq) :
    Lean.Order.monotone (fun g => alloc.collections.btree.map.PartialEqBTreeMap.eq
      { eq := keq g, ne := kne g } { eq := veq g, ne := vne g } l r) := by
  simp only [alloc.collections.btree.map.PartialEqBTreeMap.eq]
  repeat' first
    | exact alloc.collections.btree.map.eqEntries.monotone keq kne veq vne _ _ hk hv
    | monotonicity

@[partial_fixpoint_monotone]
theorem alloc.collections.btree.map.PartialEqBTreeMap.eq.monotone {K V : Type}
    (keq kne : γ → K → K → Result Bool) (veq vne : γ → V → V → Result Bool)
    (hk : Lean.Order.monotone keq) (hv : Lean.Order.monotone veq) :
    Lean.Order.monotone (fun g => alloc.collections.btree.map.PartialEqBTreeMap.eq
      { eq := keq g, ne := kne g } { eq := veq g, ne := vne g }) :=
  monotone_of_monotone_apply _ fun l => monotone_of_monotone_apply _ fun r =>
    alloc.collections.btree.map.PartialEqBTreeMap.eq.apply_monotone keq kne veq vne l r hk hv

@[partial_fixpoint_monotone]
theorem alloc.collections.btree.map.PartialEqBTreeMap.ne.apply_monotone {K V : Type}
    (keq kne : γ → K → K → Result Bool) (veq vne : γ → V → V → Result Bool)
    (l r : alloc.collections.btree.map.BTreeMap K V) (hk : Lean.Order.monotone keq) (hv : Lean.Order.monotone veq) :
    Lean.Order.monotone (fun g => alloc.collections.btree.map.PartialEqBTreeMap.ne
      { eq := keq g, ne := kne g } { eq := veq g, ne := vne g } l r) :=
  monotone_bind Result _ _
    (alloc.collections.btree.map.PartialEqBTreeMap.eq.apply_monotone keq kne veq vne l r hk hv)
    (monotone_const _)

@[partial_fixpoint_monotone]
theorem alloc.collections.btree.map.PartialEqBTreeMap.ne.monotone {K V : Type}
    (keq kne : γ → K → K → Result Bool) (veq vne : γ → V → V → Result Bool)
    (hk : Lean.Order.monotone keq) (hv : Lean.Order.monotone veq) :
    Lean.Order.monotone (fun g => alloc.collections.btree.map.PartialEqBTreeMap.ne
      { eq := keq g, ne := kne g } { eq := veq g, ne := vne g }) :=
  monotone_of_monotone_apply _ fun l => monotone_of_monotone_apply _ fun r =>
    alloc.collections.btree.map.PartialEqBTreeMap.ne.apply_monotone keq kne veq vne l r hk hv

@[partial_fixpoint_monotone]
theorem core.tuple.PartialEqQuad.eq.apply_monotone {W V U T : Type}
    (eq₁ ne₁ : γ → W → W → Result Bool) (eq₂ ne₂ : γ → V → V → Result Bool)
    (eq₃ ne₃ : γ → U → U → Result Bool) (eq₄ ne₄ : γ → T → T → Result Bool)
    (x y : W × V × U × T) (h₁ : Lean.Order.monotone eq₁) (h₂ : Lean.Order.monotone eq₂)
    (h₃ : Lean.Order.monotone eq₃) (h₄ : Lean.Order.monotone eq₄) :
    Lean.Order.monotone (fun g => core.tuple.PartialEqQuad.eq
      { eq := eq₁ g, ne := ne₁ g } { eq := eq₂ g, ne := ne₂ g }
      { eq := eq₃ g, ne := ne₃ g } { eq := eq₄ g, ne := ne₄ g } x y) := by
  simp only [core.tuple.PartialEqQuad.eq]
  repeat' first
    | exact monotone_apply _ _ (monotone_apply _ _ h₁)
    | exact monotone_apply _ _ (monotone_apply _ _ h₂)
    | exact monotone_apply _ _ (monotone_apply _ _ h₃)
    | exact monotone_apply _ _ (monotone_apply _ _ h₄)
    | monotonicity

@[partial_fixpoint_monotone]
theorem core.tuple.PartialEqQuad.eq.monotone {W V U T : Type}
    (eq₁ ne₁ : γ → W → W → Result Bool) (eq₂ ne₂ : γ → V → V → Result Bool)
    (eq₃ ne₃ : γ → U → U → Result Bool) (eq₄ ne₄ : γ → T → T → Result Bool)
    (h₁ : Lean.Order.monotone eq₁) (h₂ : Lean.Order.monotone eq₂)
    (h₃ : Lean.Order.monotone eq₃) (h₄ : Lean.Order.monotone eq₄) :
    Lean.Order.monotone (fun g => core.tuple.PartialEqQuad.eq
      { eq := eq₁ g, ne := ne₁ g } { eq := eq₂ g, ne := ne₂ g }
      { eq := eq₃ g, ne := ne₃ g } { eq := eq₄ g, ne := ne₄ g }) :=
  monotone_of_monotone_apply _ fun x => monotone_of_monotone_apply _ fun y =>
    core.tuple.PartialEqQuad.eq.apply_monotone eq₁ ne₁ eq₂ ne₂ eq₃ ne₃ eq₄ ne₄ x y h₁ h₂ h₃ h₄

@[partial_fixpoint_monotone]
theorem core.result.PartialEqResult.eq.apply_monotone {T E : Type}
    (eq₁ ne₁ : γ → T → T → Aeneas.Std.Result Bool) (eq₂ ne₂ : γ → E → E → Aeneas.Std.Result Bool)
    (x y : core.result.Result T E) (h₁ : Lean.Order.monotone eq₁)
    (h₂ : Lean.Order.monotone eq₂) :
    Lean.Order.monotone (fun g => core.result.PartialEqResult.eq
      { eq := eq₁ g, ne := ne₁ g } { eq := eq₂ g, ne := ne₂ g } x y) := by
  cases x <;> cases y <;> simp only [core.result.PartialEqResult.eq] <;>
    first
      | exact monotone_const _
      | exact monotone_apply _ _ (monotone_apply _ _ h₁)
      | exact monotone_apply _ _ (monotone_apply _ _ h₂)

@[partial_fixpoint_monotone]
theorem core.result.PartialEqResult.eq.monotone {T E : Type}
    (eq₁ ne₁ : γ → T → T → Aeneas.Std.Result Bool) (eq₂ ne₂ : γ → E → E → Aeneas.Std.Result Bool)
    (h₁ : Lean.Order.monotone eq₁) (h₂ : Lean.Order.monotone eq₂) :
    Lean.Order.monotone (fun g => core.result.PartialEqResult.eq
      { eq := eq₁ g, ne := ne₁ g } { eq := eq₂ g, ne := ne₂ g }) :=
  monotone_of_monotone_apply _ fun x => monotone_of_monotone_apply _ fun y =>
    core.result.PartialEqResult.eq.apply_monotone eq₁ ne₁ eq₂ ne₂ x y h₁ h₂

@[partial_fixpoint_monotone]
theorem core.array.equality.PartialEqArray.eq.apply_monotone {T U : Type} {N : Usize}
    (eq ne : γ → T → U → Result Bool) (a0 : Array T N) (a1 : Array U N)
    (hmono : Lean.Order.monotone eq) :
    Lean.Order.monotone (fun g => core.array.equality.PartialEqArray.eq
      { eq := eq g, ne := ne g } a0 a1) := by
  simp only [core.array.equality.PartialEqArray.eq]
  repeat' first
    | exact monotone_apply _ _ (monotone_apply _ _ hmono)
    | monotonicity

@[partial_fixpoint_monotone]
theorem core.array.equality.PartialEqArray.eq.monotone {T U : Type} {N : Usize}
    (eq ne : γ → T → U → Result Bool) (hmono : Lean.Order.monotone eq) :
    Lean.Order.monotone (fun g => core.array.equality.PartialEqArray.eq (N := N)
      { eq := eq g, ne := ne g }) :=
  monotone_of_monotone_apply _ fun a0 => monotone_of_monotone_apply _ fun a1 =>
    core.array.equality.PartialEqArray.eq.apply_monotone eq ne a0 a1 hmono

@[partial_fixpoint_monotone]
theorem core.array.equality.PartialEqArray.ne.apply_monotone {T U : Type} {N : Usize}
    (eq ne : γ → T → U → Result Bool) (a0 : Array T N) (a1 : Array U N)
    (hmono : Lean.Order.monotone ne) :
    Lean.Order.monotone (fun g => core.array.equality.PartialEqArray.ne
      { eq := eq g, ne := ne g } a0 a1) := by
  simp only [core.array.equality.PartialEqArray.ne]
  repeat' first
    | exact monotone_apply _ _ (monotone_apply _ _ hmono)
    | monotonicity

@[partial_fixpoint_monotone]
theorem core.array.equality.PartialEqArray.ne.monotone {T U : Type} {N : Usize}
    (eq ne : γ → T → U → Result Bool) (hmono : Lean.Order.monotone ne) :
    Lean.Order.monotone (fun g => core.array.equality.PartialEqArray.ne (N := N)
      { eq := eq g, ne := ne g }) :=
  monotone_of_monotone_apply _ fun a0 => monotone_of_monotone_apply _ fun a1 =>
    core.array.equality.PartialEqArray.ne.apply_monotone eq ne a0 a1 hmono

@[partial_fixpoint_monotone]
theorem core.array.equality.PartialEqSliceArray.eq.apply_monotone {T U : Type} {N : Usize}
    (eq ne : γ → T → U → Result Bool) (s : Slice T) (a : Array U N)
    (hmono : Lean.Order.monotone eq) :
    Lean.Order.monotone (fun g => core.array.equality.PartialEqSliceArray.eq
      { eq := eq g, ne := ne g } s a) := by
  unfold core.array.equality.PartialEqSliceArray.eq
  split
  · exact core.array.equality.PartialEqArray.eq.apply_monotone eq ne _ a hmono
  · exact monotone_const _

@[partial_fixpoint_monotone]
theorem core.array.equality.PartialEqSliceArray.eq.monotone {T U : Type} {N : Usize}
    (eq ne : γ → T → U → Result Bool) (hmono : Lean.Order.monotone eq) :
    Lean.Order.monotone (fun g => core.array.equality.PartialEqSliceArray.eq (N := N)
      { eq := eq g, ne := ne g }) :=
  monotone_of_monotone_apply _ fun s => monotone_of_monotone_apply _ fun a =>
    core.array.equality.PartialEqSliceArray.eq.apply_monotone eq ne s a hmono

@[partial_fixpoint_monotone]
theorem core.array.equality.PartialEqSliceArray.ne.apply_monotone {T U : Type} {N : Usize}
    (eq ne : γ → T → U → Result Bool) (s : Slice T) (a : Array U N)
    (hmono : Lean.Order.monotone ne) :
    Lean.Order.monotone (fun g => core.array.equality.PartialEqSliceArray.ne
      { eq := eq g, ne := ne g } s a) := by
  unfold core.array.equality.PartialEqSliceArray.ne
  split
  · exact core.array.equality.PartialEqArray.ne.apply_monotone eq ne _ a hmono
  · exact monotone_const _

@[partial_fixpoint_monotone]
theorem core.array.equality.PartialEqSliceArray.ne.monotone {T U : Type} {N : Usize}
    (eq ne : γ → T → U → Result Bool) (hmono : Lean.Order.monotone ne) :
    Lean.Order.monotone (fun g => core.array.equality.PartialEqSliceArray.ne (N := N)
      { eq := eq g, ne := ne g }) :=
  monotone_of_monotone_apply _ fun s => monotone_of_monotone_apply _ fun a =>
    core.array.equality.PartialEqSliceArray.ne.apply_monotone eq ne s a hmono

end PartialEqMono

section OrdMono

variable {γ : Type w} [Lean.Order.PartialOrder γ]

/-! The comparisons of `[T]` and `Box<T>` (the derived `PartialOrd`/`Ord` of a type recursive
    through `Box<[Self]>` or `Box<Self>`): the instance literals carry the fields `PartialOrd`/`Ord`
    fills in by default (`lt`, ..., `max`, ...); the models only call `partial_cmp`/`cmp`. -/

/-- The element step of `chaining` depends monotonically on `g`. -/
@[partial_fixpoint_monotone]
theorem core.slice.cmp.chaining.monotone {T B C : Type}
    (elem : γ → T → T → Result (core.ops.control_flow.ControlFlow B Unit))
    (len : Nat → Nat → core.ops.control_flow.ControlFlow B C) (xs ys : List T)
    (hmono : Lean.Order.monotone elem) :
    Lean.Order.monotone (fun g => core.slice.cmp.chaining (elem g) len xs ys) := by
  induction xs generalizing ys with
  | nil => exact monotone_const _
  | cons x xs ih =>
    cases ys with
    | nil => exact monotone_const _
    | cons y ys =>
      simp only [core.slice.cmp.chaining]
      repeat' first
        | exact ih _
        | exact monotone_apply _ _ (monotone_apply _ _ hmono)
        | monotonicity

@[partial_fixpoint_monotone]
theorem core.slice.cmp.PartialOrdSlice.partial_cmp.apply_monotone {T : Type}
    (pe : γ → core.cmp.PartialEq T T) (pc : γ → T → T → Result (Option Ordering))
    (lt le gt ge : γ → T → T → Result Bool)
    (clt cle cgt cge : γ → T → T → Result (core.ops.control_flow.ControlFlow Bool Unit))
    (x y : Slice T) (hmono : Lean.Order.monotone pc) :
    Lean.Order.monotone (fun g => core.slice.cmp.PartialOrdSlice.partial_cmp
      { partialEqInst := pe g, partial_cmp := pc g, lt := lt g, le := le g, gt := gt g, ge := ge g,
        __chaining_lt := clt g, __chaining_le := cle g, __chaining_gt := cgt g,
        __chaining_ge := cge g } x y) := by
  simp only [core.slice.cmp.PartialOrdSlice.partial_cmp]
  repeat' first
    | exact monotone_apply _ _ (monotone_apply _ _ hmono)
    | monotonicity

@[partial_fixpoint_monotone]
theorem core.slice.cmp.PartialOrdSlice.partial_cmp.monotone {T : Type}
    (pe : γ → core.cmp.PartialEq T T) (pc : γ → T → T → Result (Option Ordering))
    (lt le gt ge : γ → T → T → Result Bool)
    (clt cle cgt cge : γ → T → T → Result (core.ops.control_flow.ControlFlow Bool Unit))
    (hmono : Lean.Order.monotone pc) :
    Lean.Order.monotone (fun g => core.slice.cmp.PartialOrdSlice.partial_cmp
      { partialEqInst := pe g, partial_cmp := pc g, lt := lt g, le := le g, gt := gt g, ge := ge g,
        __chaining_lt := clt g, __chaining_le := cle g, __chaining_gt := cgt g,
        __chaining_ge := cge g }) :=
  monotone_of_monotone_apply _ fun x => monotone_of_monotone_apply _ fun y =>
    core.slice.cmp.PartialOrdSlice.partial_cmp.apply_monotone pe pc lt le gt ge clt cle cgt cge x y
      hmono

@[partial_fixpoint_monotone]
theorem core.slice.cmp.OrdSlice.cmp.apply_monotone {T : Type}
    (eqi : γ → core.cmp.Eq T) (poi : γ → core.cmp.PartialOrd T T) (c : γ → T → T → Result Ordering)
    (mx mn : γ → T → T → Result T) (cl : γ → T → T → T → Result T)
    (x y : Slice T) (hmono : Lean.Order.monotone c) :
    Lean.Order.monotone (fun g => core.slice.cmp.OrdSlice.cmp
      { eqInst := eqi g, partialOrdInst := poi g, cmp := c g, max := mx g, min := mn g,
        clamp := cl g } x y) := by
  simp only [core.slice.cmp.OrdSlice.cmp]
  repeat' first
    | exact monotone_apply _ _ (monotone_apply _ _ hmono)
    | monotonicity

@[partial_fixpoint_monotone]
theorem core.slice.cmp.OrdSlice.cmp.monotone {T : Type}
    (eqi : γ → core.cmp.Eq T) (poi : γ → core.cmp.PartialOrd T T) (c : γ → T → T → Result Ordering)
    (mx mn : γ → T → T → Result T) (cl : γ → T → T → T → Result T)
    (hmono : Lean.Order.monotone c) :
    Lean.Order.monotone (fun g => core.slice.cmp.OrdSlice.cmp
      { eqInst := eqi g, partialOrdInst := poi g, cmp := c g, max := mx g, min := mn g,
        clamp := cl g }) :=
  monotone_of_monotone_apply _ fun x => monotone_of_monotone_apply _ fun y =>
    core.slice.cmp.OrdSlice.cmp.apply_monotone eqi poi c mx mn cl x y hmono

@[partial_fixpoint_monotone]
theorem alloc.boxed.PartialOrdBox.partial_cmp.apply_monotone {T : Type}
    (pe : γ → core.cmp.PartialEq T T) (pc : γ → T → T → Result (Option Ordering))
    (lt le gt ge : γ → T → T → Result Bool)
    (clt cle cgt cge : γ → T → T → Result (core.ops.control_flow.ControlFlow Bool Unit))
    (x y : T) (hmono : Lean.Order.monotone pc) :
    Lean.Order.monotone (fun g => alloc.boxed.PartialOrdBox.partial_cmp
      { partialEqInst := pe g, partial_cmp := pc g, lt := lt g, le := le g, gt := gt g, ge := ge g,
        __chaining_lt := clt g, __chaining_le := cle g, __chaining_gt := cgt g,
        __chaining_ge := cge g } x y) :=
  monotone_apply y _ (monotone_apply x _ hmono)

@[partial_fixpoint_monotone]
theorem alloc.boxed.PartialOrdBox.partial_cmp.monotone {T : Type}
    (pe : γ → core.cmp.PartialEq T T) (pc : γ → T → T → Result (Option Ordering))
    (lt le gt ge : γ → T → T → Result Bool)
    (clt cle cgt cge : γ → T → T → Result (core.ops.control_flow.ControlFlow Bool Unit))
    (hmono : Lean.Order.monotone pc) :
    Lean.Order.monotone (fun g => alloc.boxed.PartialOrdBox.partial_cmp
      { partialEqInst := pe g, partial_cmp := pc g, lt := lt g, le := le g, gt := gt g, ge := ge g,
        __chaining_lt := clt g, __chaining_le := cle g, __chaining_gt := cgt g,
        __chaining_ge := cge g }) :=
  hmono

@[partial_fixpoint_monotone]
theorem alloc.boxed.OrdBox.cmp.apply_monotone {T : Type}
    (eqi : γ → core.cmp.Eq T) (poi : γ → core.cmp.PartialOrd T T) (c : γ → T → T → Result Ordering)
    (mx mn : γ → T → T → Result T) (cl : γ → T → T → T → Result T)
    (x y : T) (hmono : Lean.Order.monotone c) :
    Lean.Order.monotone (fun g => alloc.boxed.OrdBox.cmp
      { eqInst := eqi g, partialOrdInst := poi g, cmp := c g, max := mx g, min := mn g,
        clamp := cl g } x y) :=
  monotone_apply y _ (monotone_apply x _ hmono)

@[partial_fixpoint_monotone]
theorem alloc.boxed.OrdBox.cmp.monotone {T : Type}
    (eqi : γ → core.cmp.Eq T) (poi : γ → core.cmp.PartialOrd T T) (c : γ → T → T → Result Ordering)
    (mx mn : γ → T → T → Result T) (cl : γ → T → T → T → Result T)
    (hmono : Lean.Order.monotone c) :
    Lean.Order.monotone (fun g => alloc.boxed.OrdBox.cmp
      { eqInst := eqi g, partialOrdInst := poi g, cmp := c g, max := mx g, min := mn g,
        clamp := cl g }) :=
  hmono

end OrdMono

section HashMono

variable {γ : Type w} [Lean.Order.PartialOrder γ]

/-- The `Hash` of `Box<T>` (a `Hash` impl recursive through `Box<Self>`, e.g. derived on
    `enum E { Mul(Box<E>, Box<E>), .. }`): the instance literal's `hash` is generic in the
    hasher. -/
@[partial_fixpoint_monotone]
theorem alloc.boxed.HashBox.hash.apply_monotone {T H : Type}
    (hash : γ → ∀ {H : Type}, core.hash.Hasher H → T → H → Result H)
    (hasher : core.hash.Hasher H) (x : T) (state : H) (hmono : Lean.Order.monotone hash) :
    Lean.Order.monotone (fun g => alloc.boxed.HashBox.hash
      ({ hash := fun {H'} (hasher' : core.hash.Hasher H') => hash g hasher' } : core.hash.Hash T)
      hasher x state) :=
  monotone_apply state _ (monotone_apply x _ (monotone_apply hasher _ (monotone_apply H _ hmono)))

/-- The provided `Hash::hash_slice` (`core.hash.hashEach`, the default of an instance literal's
    `hash_slice` field, e.g. the element instance of `Hash for [T]` in the derived `Hash` of
    `enum E { Product(Box<[E]>), .. }`): each element hashed by a `hash` which depends
    monotonically on `g`. -/
@[partial_fixpoint_monotone]
theorem core.hash.hashEach.monotone {T H : Type}
    (hash : γ → core.hash.Hasher H → T → H → Result H) (hasher : core.hash.Hasher H)
    (xs : List T) (state : H) (hmono : Lean.Order.monotone hash) :
    Lean.Order.monotone (fun g => core.hash.hashEach (hash g) hasher xs state) := by
  induction xs generalizing state with
  | nil => exact monotone_const _
  | cons x xs ih =>
    simp only [core.hash.hashEach]
    repeat' first
      | exact ih _
      | exact monotone_apply _ _ (monotone_apply _ _ (monotone_apply _ _ hmono))
      | monotonicity

end HashMono

section DebugMono

open core.fmt

variable {γ : Type w} [Lean.Order.PartialOrder γ]

/-- The entries of a list rendered by a callback which depends monotonically on `g`. -/
@[partial_fixpoint_monotone]
theorem core.fmt.debugEntries.render_monotone {T : Type u} (pretty : Bool)
    (render : γ → T → Callback) (l : List T) (hmono : Lean.Order.monotone render) :
    Lean.Order.monotone (fun g => debugEntries pretty (render g) l) := by
  induction l with
  | nil => exact monotone_const _
  | cons v rest ih =>
    apply monotone_of_monotone_apply
    intro fmt
    simp only [debugEntries]
    repeat' first
      | exact ih
      | exact monotone_apply _ _ (monotone_apply _ _ hmono)
      | monotonicity

/-- The entries of a list whose elements depend monotonically on `g`. -/
theorem core.fmt.debugEntries.values_monotone {α : Type v} {T : Type u} (pretty : Bool)
    (render : T → Callback) (elem : γ → α → T) (vs : List α)
    (hmono : ∀ v ∈ vs, Lean.Order.monotone (fun g => render (elem g v))) :
    Lean.Order.monotone (fun g => debugEntries pretty render (vs.map (elem g))) := by
  induction vs with
  | nil => exact monotone_const _
  | cons v vs ih =>
    have hv := hmono v List.mem_cons_self
    have ih := ih (fun w hw => hmono w (List.mem_cons_of_mem _ hw))
    apply monotone_of_monotone_apply
    intro fmt
    simp only [List.map_cons, debugEntries, List.isEmpty_map]
    repeat' first
      | exact ih
      | exact monotone_apply _ _ hv
      | monotonicity

theorem core.fmt.Formatter.debugTuple.values_monotone {α : Type v} (fmt : Formatter)
    (nm : String) (elem : γ → α → DebugValue) (vs : List α)
    (hmono : ∀ v ∈ vs, Lean.Order.monotone (fun g => debugValue (elem g v))) :
    Lean.Order.monotone (fun g => fmt.debugTuple nm (vs.map (elem g))) := by
  simp only [Formatter.debugTuple, List.isEmpty_map, List.length_map]
  repeat' first
    | exact debugEntries.values_monotone _ debugValue elem vs hmono
    | monotonicity

theorem core.fmt.Formatter.debugStruct.values_monotone (fmt : Formatter) (nm : String)
    (fields : List (String × (γ → DebugValue)))
    (hmono : ∀ p ∈ fields, Lean.Order.monotone (fun g => debugValue (p.2 g))) :
    Lean.Order.monotone (fun g => fmt.debugStruct nm (fields.map (fun p => (p.1, p.2 g)))) := by
  have hfields : ∀ p ∈ fields, Lean.Order.monotone (fun g =>
      (fun (x : String × DebugValue) (fmt : Formatter) =>
        thenFormat (fmt.append (x.1 ++ ": ")) (debugValue x.2)) (p.1, p.2 g)) := by
    intro p hp
    dsimp only
    apply monotone_of_monotone_apply
    intro fmt'
    exact thenFormat.monotone _ _ (monotone_const _) (hmono p hp)
  simp only [Formatter.debugStruct, debugFields, List.isEmpty_map]
  repeat' first
    | exact debugEntries.values_monotone _ _ (fun g (p : String × (γ → DebugValue)) => (p.1, p.2 g))
        fields hfields
    | monotonicity

@[partial_fixpoint_monotone]
theorem core.fmt.Formatter.debugList.monotone {T : Type} (fmt : Formatter)
    (callback : γ → T → Callback) (values : List T) (hmono : Lean.Order.monotone callback) :
    Lean.Order.monotone (fun g => fmt.debugList ⟨callback g⟩ values) := by
  simp only [Formatter.debugList]
  repeat' first
    | exact debugEntries.render_monotone _ callback values hmono
    | monotonicity

@[partial_fixpoint_monotone]
theorem alloc.vec.DebugVec.fmt.monotone {T : Type} (callback : γ → T → Callback)
    (hmono : Lean.Order.monotone callback) :
    Lean.Order.monotone (fun g => alloc.vec.DebugVec.fmt ⟨callback g⟩) :=
  monotone_of_monotone_apply _ fun v => monotone_of_monotone_apply _ fun fmt =>
    Formatter.debugList.monotone fmt callback v.val hmono

@[partial_fixpoint_monotone]
theorem alloc.vec.DebugVec.fmt.apply_monotone {T : Type} (callback : γ → T → Callback)
    (v : alloc.vec.Vec T) (hmono : Lean.Order.monotone callback) :
    Lean.Order.monotone (fun g => alloc.vec.DebugVec.fmt ⟨callback g⟩ v) :=
  monotone_of_monotone_apply _ fun fmt => Formatter.debugList.monotone fmt callback v.val hmono

@[partial_fixpoint_monotone]
theorem alloc.vec.DebugVec.fmt.apply_fmt_monotone {T : Type} (callback : γ → T → Callback)
    (v : alloc.vec.Vec T) (fmt : Formatter) (hmono : Lean.Order.monotone callback) :
    Lean.Order.monotone (fun g => alloc.vec.DebugVec.fmt ⟨callback g⟩ v fmt) :=
  Formatter.debugList.monotone fmt callback v.val hmono

@[partial_fixpoint_monotone]
theorem core.fmt.DebugOption.fmt.apply_fmt_monotone {T : Type} (callback : γ → T → Callback)
    (x : Option T) (fmt : Formatter) (hmono : Lean.Order.monotone callback) :
    Lean.Order.monotone (fun g => DebugOption.fmt ⟨callback g⟩ x fmt) := by
  cases x with
  | none => exact monotone_const _
  | some v =>
    exact Formatter.debugTuple.values_monotone fmt "Some"
      (fun g (_ : Unit) => (⟨T, ⟨callback g⟩, v⟩ : DebugValue)) [()]
      (fun _ _ => monotone_apply v _ hmono)

@[partial_fixpoint_monotone]
theorem core.fmt.DebugOption.fmt.apply_monotone {T : Type} (callback : γ → T → Callback)
    (x : Option T) (hmono : Lean.Order.monotone callback) :
    Lean.Order.monotone (fun g => DebugOption.fmt ⟨callback g⟩ x) :=
  monotone_of_monotone_apply _ fun fmt => DebugOption.fmt.apply_fmt_monotone callback x fmt hmono

@[partial_fixpoint_monotone]
theorem core.fmt.DebugOption.fmt.monotone {T : Type} (callback : γ → T → Callback)
    (hmono : Lean.Order.monotone callback) :
    Lean.Order.monotone (fun g => DebugOption.fmt ⟨callback g⟩) :=
  monotone_of_monotone_apply _ fun x => DebugOption.fmt.apply_monotone callback x hmono

@[partial_fixpoint_monotone]
theorem core.fmt.DebugPair.fmt.apply_fmt_monotone {A B : Type} (ca : γ → A → Callback)
    (cb : γ → B → Callback) (x : A × B) (fmt : Formatter)
    (ha : Lean.Order.monotone ca) (hb : Lean.Order.monotone cb) :
    Lean.Order.monotone (fun g => DebugPair.fmt ⟨ca g⟩ ⟨cb g⟩ x fmt) := by
  refine Formatter.debugTuple.values_monotone fmt ""
    (fun g (b : Bool) => if b then (⟨A, ⟨ca g⟩, x.1⟩ : DebugValue) else ⟨B, ⟨cb g⟩, x.2⟩)
    [true, false] ?_
  intro b _
  cases b
  · exact monotone_apply x.2 _ hb
  · exact monotone_apply x.1 _ ha

@[partial_fixpoint_monotone]
theorem core.fmt.DebugPair.fmt.apply_monotone {A B : Type} (ca : γ → A → Callback)
    (cb : γ → B → Callback) (x : A × B)
    (ha : Lean.Order.monotone ca) (hb : Lean.Order.monotone cb) :
    Lean.Order.monotone (fun g => DebugPair.fmt ⟨ca g⟩ ⟨cb g⟩ x) :=
  monotone_of_monotone_apply _ fun fmt => DebugPair.fmt.apply_fmt_monotone ca cb x fmt ha hb

@[partial_fixpoint_monotone]
theorem core.fmt.DebugPair.fmt.monotone {A B : Type} (ca : γ → A → Callback)
    (cb : γ → B → Callback) (ha : Lean.Order.monotone ca) (hb : Lean.Order.monotone cb) :
    Lean.Order.monotone (fun g => DebugPair.fmt ⟨ca g⟩ ⟨cb g⟩) :=
  monotone_of_monotone_apply _ fun x => DebugPair.fmt.apply_monotone ca cb x ha hb

@[partial_fixpoint_monotone]
theorem alloc.sync.DebugArc.fmt.monotone {T : Type} (callback : γ → T → Callback)
    (hmono : Lean.Order.monotone callback) :
    Lean.Order.monotone (fun g => alloc.sync.DebugArc.fmt ⟨callback g⟩) :=
  hmono

@[partial_fixpoint_monotone]
theorem alloc.sync.DebugArc.fmt.apply_fmt_monotone {T : Type} (callback : γ → T → Callback)
    (x : alloc.sync.Arc T) (fmt : Formatter) (hmono : Lean.Order.monotone callback) :
    Lean.Order.monotone (fun g => alloc.sync.DebugArc.fmt ⟨callback g⟩ x fmt) :=
  monotone_apply fmt _ (monotone_apply x _ hmono)

@[partial_fixpoint_monotone]
theorem core.fmt.Formatter.debug_struct_field1_finish.monotone (fmt : Formatter)
    (nm n0 : Str) (v₀ : γ → DebugValue)
    (h₀ : Lean.Order.monotone (fun g => debugValue (v₀ g))) :
    Lean.Order.monotone (fun g => fmt.debug_struct_field1_finish nm n0 (v₀ g)) := by
  simp only [Formatter.debug_struct_field1_finish]
  repeat' first
    | exact Formatter.debugStruct.values_monotone fmt _ [(_, v₀)]
        (fun p hp => by simp only [List.mem_cons, List.not_mem_nil, or_false] at hp; subst hp; exact h₀)
    | monotonicity

@[partial_fixpoint_monotone]
theorem core.fmt.Formatter.debug_struct_field2_finish.monotone (fmt : Formatter)
    (nm n0 : Str) (v₀ : γ → DebugValue) (n1 : Str) (v₁ : γ → DebugValue)
    (h₀ : Lean.Order.monotone (fun g => debugValue (v₀ g)))
    (h₁ : Lean.Order.monotone (fun g => debugValue (v₁ g))) :
    Lean.Order.monotone (fun g => fmt.debug_struct_field2_finish nm n0 (v₀ g) n1 (v₁ g)) := by
  simp only [Formatter.debug_struct_field2_finish]
  repeat' first
    | exact Formatter.debugStruct.values_monotone fmt _ [(_, v₀), (_, v₁)]
        (fun p hp => by
          simp only [List.mem_cons, List.not_mem_nil, or_false] at hp
          rcases hp with rfl | rfl <;> assumption)
    | monotonicity

@[partial_fixpoint_monotone]
theorem core.fmt.Formatter.debug_struct_field3_finish.monotone (fmt : Formatter)
    (nm n0 : Str) (v₀ : γ → DebugValue) (n1 : Str) (v₁ : γ → DebugValue)
    (n2 : Str) (v₂ : γ → DebugValue)
    (h₀ : Lean.Order.monotone (fun g => debugValue (v₀ g)))
    (h₁ : Lean.Order.monotone (fun g => debugValue (v₁ g)))
    (h₂ : Lean.Order.monotone (fun g => debugValue (v₂ g))) :
    Lean.Order.monotone (fun g =>
      fmt.debug_struct_field3_finish nm n0 (v₀ g) n1 (v₁ g) n2 (v₂ g)) := by
  simp only [Formatter.debug_struct_field3_finish]
  repeat' first
    | exact Formatter.debugStruct.values_monotone fmt _ [(_, v₀), (_, v₁), (_, v₂)]
        (fun p hp => by
          simp only [List.mem_cons, List.not_mem_nil, or_false] at hp
          rcases hp with rfl | rfl | rfl <;> assumption)
    | monotonicity

@[partial_fixpoint_monotone]
theorem core.fmt.Formatter.debug_struct_field4_finish.monotone (fmt : Formatter)
    (nm n0 : Str) (v₀ : γ → DebugValue) (n1 : Str) (v₁ : γ → DebugValue)
    (n2 : Str) (v₂ : γ → DebugValue) (n3 : Str) (v₃ : γ → DebugValue)
    (h₀ : Lean.Order.monotone (fun g => debugValue (v₀ g)))
    (h₁ : Lean.Order.monotone (fun g => debugValue (v₁ g)))
    (h₂ : Lean.Order.monotone (fun g => debugValue (v₂ g)))
    (h₃ : Lean.Order.monotone (fun g => debugValue (v₃ g))) :
    Lean.Order.monotone (fun g =>
      fmt.debug_struct_field4_finish nm n0 (v₀ g) n1 (v₁ g) n2 (v₂ g) n3 (v₃ g)) := by
  simp only [Formatter.debug_struct_field4_finish]
  repeat' first
    | exact Formatter.debugStruct.values_monotone fmt _ [(_, v₀), (_, v₁), (_, v₂), (_, v₃)]
        (fun p hp => by
          simp only [List.mem_cons, List.not_mem_nil, or_false] at hp
          rcases hp with rfl | rfl | rfl | rfl <;> assumption)
    | monotonicity

@[partial_fixpoint_monotone]
theorem core.fmt.Formatter.debug_struct_field5_finish.monotone (fmt : Formatter)
    (nm n0 : Str) (v₀ : γ → DebugValue) (n1 : Str) (v₁ : γ → DebugValue)
    (n2 : Str) (v₂ : γ → DebugValue) (n3 : Str) (v₃ : γ → DebugValue)
    (n4 : Str) (v₄ : γ → DebugValue)
    (h₀ : Lean.Order.monotone (fun g => debugValue (v₀ g)))
    (h₁ : Lean.Order.monotone (fun g => debugValue (v₁ g)))
    (h₂ : Lean.Order.monotone (fun g => debugValue (v₂ g)))
    (h₃ : Lean.Order.monotone (fun g => debugValue (v₃ g)))
    (h₄ : Lean.Order.monotone (fun g => debugValue (v₄ g))) :
    Lean.Order.monotone (fun g =>
      fmt.debug_struct_field5_finish nm n0 (v₀ g) n1 (v₁ g) n2 (v₂ g) n3 (v₃ g) n4 (v₄ g)) := by
  simp only [Formatter.debug_struct_field5_finish]
  repeat' first
    | exact Formatter.debugStruct.values_monotone fmt _
        [(_, v₀), (_, v₁), (_, v₂), (_, v₃), (_, v₄)]
        (fun p hp => by
          simp only [List.mem_cons, List.not_mem_nil, or_false] at hp
          rcases hp with rfl | rfl | rfl | rfl | rfl <;> assumption)
    | monotonicity

/-- The model of `Debug for [T; N]` does not call the element instance. -/
@[partial_fixpoint_monotone]
theorem core.array.DebugArray.fmt.monotone {T : Type} {N : Usize} (callback : γ → T → Callback) :
    Lean.Order.monotone (fun g => core.array.DebugArray.fmt (N := N) ⟨callback g⟩) :=
  monotone_const _

@[partial_fixpoint_monotone]
theorem core.array.DebugArray.fmt.apply_fmt_monotone {T : Type} {N : Usize}
    (callback : γ → T → Callback) (a : Array T N) (fmt : Formatter) :
    Lean.Order.monotone (fun g => core.array.DebugArray.fmt ⟨callback g⟩ a fmt) :=
  monotone_const _

@[partial_fixpoint_monotone]
theorem core.fmt.DebugSlice.fmt.monotone {T : Type} (callback : γ → T → Callback)
    (hmono : Lean.Order.monotone callback) :
    Lean.Order.monotone (fun g => core.fmt.DebugSlice.fmt ⟨callback g⟩) :=
  monotone_of_monotone_apply _ fun s => monotone_of_monotone_apply _ fun fmt =>
    Formatter.debugList.monotone fmt callback s.val hmono

@[partial_fixpoint_monotone]
theorem core.fmt.DebugSlice.fmt.apply_fmt_monotone {T : Type} (callback : γ → T → Callback)
    (s : Slice T) (fmt : Formatter) (hmono : Lean.Order.monotone callback) :
    Lean.Order.monotone (fun g => core.fmt.DebugSlice.fmt ⟨callback g⟩ s fmt) :=
  Formatter.debugList.monotone fmt callback s.val hmono

@[partial_fixpoint_monotone]
theorem core.fmt.Formatter.debugMap.monotone {K V : Type} (fmt : Formatter)
    (kcb : γ → K → Callback) (vcb : γ → V → Callback) (entries : List (K × V))
    (hk : Lean.Order.monotone kcb) (hv : Lean.Order.monotone vcb) :
    Lean.Order.monotone (fun g => fmt.debugMap ⟨kcb g⟩ ⟨vcb g⟩ entries) := by
  have hrender : Lean.Order.monotone (fun g (e : K × V) (fmt : Formatter) =>
      thenFormat (kcb g e.1 fmt) (fun fmt => thenFormat (fmt.append ": ") (vcb g e.2))) := by
    apply monotone_of_monotone_apply; intro e
    apply monotone_of_monotone_apply; intro fmt
    repeat' first
      | exact monotone_apply _ _ (monotone_apply _ _ hk)
      | exact monotone_apply _ _ hv
      | monotonicity
  simp only [Formatter.debugMap]
  repeat' first
    | exact debugEntries.render_monotone _ _ entries hrender
    | monotonicity

@[partial_fixpoint_monotone]
theorem alloc.collections.btree.map.DebugBTreeMap.fmt.monotone {K V : Type}
    (kcb : γ → K → Callback) (vcb : γ → V → Callback)
    (hk : Lean.Order.monotone kcb) (hv : Lean.Order.monotone vcb) :
    Lean.Order.monotone (fun g =>
      alloc.collections.btree.map.DebugBTreeMap.fmt ⟨kcb g⟩ ⟨vcb g⟩) :=
  monotone_of_monotone_apply _ fun map => monotone_of_monotone_apply _ fun fmt =>
    Formatter.debugMap.monotone fmt kcb vcb map.entries hk hv

@[partial_fixpoint_monotone]
theorem alloc.collections.btree.map.DebugBTreeMap.fmt.apply_fmt_monotone {K V : Type}
    (kcb : γ → K → Callback) (vcb : γ → V → Callback)
    (map : alloc.collections.btree.map.BTreeMap K V) (fmt : Formatter)
    (hk : Lean.Order.monotone kcb) (hv : Lean.Order.monotone vcb) :
    Lean.Order.monotone (fun g =>
      alloc.collections.btree.map.DebugBTreeMap.fmt ⟨kcb g⟩ ⟨vcb g⟩ map fmt) :=
  Formatter.debugMap.monotone fmt kcb vcb map.entries hk hv

@[partial_fixpoint_monotone]
theorem core.fmt.Formatter.debugSet.monotone {T : Type} (fmt : Formatter)
    (callback : γ → T → Callback) (values : List T) (hmono : Lean.Order.monotone callback) :
    Lean.Order.monotone (fun g => fmt.debugSet ⟨callback g⟩ values) := by
  simp only [Formatter.debugSet]
  repeat' first
    | exact debugEntries.render_monotone _ callback values hmono
    | monotonicity

@[partial_fixpoint_monotone]
theorem alloc.collections.btree.set.DebugBTreeSet.fmt.monotone {T : Type}
    (callback : γ → T → Callback) (hmono : Lean.Order.monotone callback) :
    Lean.Order.monotone (fun g => alloc.collections.btree.set.DebugBTreeSet.fmt ⟨callback g⟩) :=
  monotone_of_monotone_apply _ fun (s : alloc.collections.btree.set.BTreeSet T) =>
    monotone_of_monotone_apply _ fun fmt =>
      Formatter.debugSet.monotone fmt callback (s.map.entries.map Prod.fst) hmono

@[partial_fixpoint_monotone]
theorem alloc.collections.btree.set.DebugBTreeSet.fmt.apply_fmt_monotone {T : Type}
    (callback : γ → T → Callback) (s : alloc.collections.btree.set.BTreeSet T)
    (fmt : Formatter) (hmono : Lean.Order.monotone callback) :
    Lean.Order.monotone (fun g => alloc.collections.btree.set.DebugBTreeSet.fmt ⟨callback g⟩ s fmt) :=
  Formatter.debugSet.monotone fmt callback (s.map.entries.map Prod.fst) hmono

end DebugMono

section AdapterMono

/-! A function item used as a closure (`iter.map(f)`, with the instance `BuiltinFnMut`) is the
state of the adapter (`Map { iter, f }`), and the consumers of the adapter give their final
state back, so a recursive function passed that way would be a value in the flat order of
`Result`, where it is not monotone. The consumers below are the same as the consumers of a
stateless closure which calls the function, whose instance (not state) depends on it; the
`aeneas_monotonicity` tactic rewrites them so, and `aeneas_fix_monotone` shows the fixpoints of
the consumers (`iterToList`, `foldFromNext`, `extendLoop`, `tryFoldFromNext`) monotone in the
instance. The consumers are `collect` into a `Vec` or into a `Result` of a `Vec`, `Vec::extend`
and `sum`. The equations are proved by fixpoint induction from maps of the states which commute
with the steps of the fixpoints. -/

open Result

/-- In the flat order of `Result`, a pointwise property of a two-argument function which
    holds at `div` is admissible (a chain has at most one value besides `div`). -/
theorem admissible_result_apply₂ {A : Sort u} {B : Sort v} {γ : Type w}
    (P : A → B → Result γ → Prop) (hdiv : ∀ a b, P a b .div) :
    admissible (fun (f : A → B → Result γ) => ∀ a b, P a b (f a b)) :=
  admissible_pi_apply (fun a (g : B → Result γ) => ∀ b, P a b (g b)) fun a =>
    admissible_pi_apply (fun b (v : Result γ) => P a b v) fun b =>
      admissible_flatOrder (P a b) (hdiv a b)

/-- In the flat order of `Result`, a pointwise property of a three-argument function which
    holds at `div` is admissible. -/
theorem admissible_result_apply₃ {A : Sort u} {B : Sort v} {C : Sort w} {γ : Type w'}
    (P : A → B → C → Result γ → Prop) (hdiv : ∀ a b c, P a b c .div) :
    admissible (fun (f : A → B → C → Result γ) => ∀ a b c, P a b c (f a b c)) :=
  admissible_pi_apply (fun a (g : B → C → Result γ) => ∀ b c, P a b c (g b c)) fun a =>
    admissible_result_apply₂ (P a) (hdiv a)

/-- `iter.map(f)`: the function is the state of the `Map`. -/
theorem core.iter.traits.iterator.Iterator.map.default_builtin {I A B : Type}
    (iterInst : core.iter.traits.iterator.Iterator I A) (s : I) (f : A → Result B) :
    core.iter.traits.iterator.Iterator.map.default iterInst (BuiltinFnMut A B) s f = ok ⟨s, f⟩ := rfl

/-- A step of `Map` with a function item is a step of `Map` with a stateless closure calling the
    function, the function put back as the state. -/
theorem core.iter.adapters.map.IteratorMap.next_builtin {I A B : Type}
    (iterInst : core.iter.traits.iterator.Iterator I A) (f : A → Result B)
    (st : core.iter.adapters.map.Map I Unit) :
    core.iter.adapters.map.IteratorMap.next iterInst (BuiltinFnMut A B) ⟨st.iter, f⟩ =
      (do let r ← core.iter.adapters.map.IteratorMap.next iterInst
            ({ FnOnceInst := { call_once := fun _ a => do let b ← f a; ok (b, ()) },
               call_mut := fun _ a => do let b ← f a; ok (b, ()) } : core.ops.function.FnMut Unit A B) st
          ok (r.1, ⟨r.2.iter, f⟩)) := by
  obtain ⟨s, ⟨⟩⟩ := st
  simp only [core.iter.adapters.map.IteratorMap.next, BuiltinFnMut]
  cases iterInst.next s with
  | ok r =>
    obtain ⟨item, it⟩ := r
    cases item with
    | none => simp only [bind_tc_ok]
    | some a =>
      simp only [bind_tc_ok]
      cases f a <;> simp only [bind_tc_ok, bind_tc_fail, bind_tc_div]
  | fail e => simp only [bind_tc_fail]
  | div => simp only [bind_tc_div]

/-- `iterToList` commutes with a map `φ` of iterator states that commutes with `next`. -/
theorem alloc.vec.FromIteratorVec.iterToList_state_map {T S₁ S₂ : Type}
    (inst₁ : core.iter.traits.iterator.Iterator S₁ T)
    (inst₂ : core.iter.traits.iterator.Iterator S₂ T) (φ : S₂ → S₁)
    (hnext : ∀ s, inst₁.next (φ s) = (do let r ← inst₂.next s; ok (r.1, φ r.2)))
    (s : S₂) (acc : List T) :
    alloc.vec.FromIteratorVec.iterToList inst₁ (φ s) acc =
      (do let r ← alloc.vec.FromIteratorVec.iterToList inst₂ s acc; ok (r.1, φ r.2)) := by
  apply PartialOrder.rel_antisymm
  · -- the left fixpoint below the right-hand side
    have hadm := admissible_result_apply₂ (fun st acc v => ∀ s, st = φ s → v ⊑
        (do let r ← alloc.vec.FromIteratorVec.iterToList inst₂ s acc; ok (r.1, φ r.2)))
      fun _ _ _ _ => FlatOrder.rel.bot
    refine alloc.vec.FromIteratorVec.iterToList.fixpoint_induct inst₁ _ hadm ?_ (φ s) acc s rfl
    intro recur ih st acc s hst
    subst hst
    dsimp only
    rw [hnext s, alloc.vec.FromIteratorVec.iterToList.eq_def inst₂ s acc]
    cases inst₂.next s with
    | ok r =>
      obtain ⟨opt, it⟩ := r
      cases opt with
      | none => simp only [bind_tc_ok]; exact FlatOrder.rel.refl
      | some item => simp only [bind_tc_ok]; exact ih (φ it) (item :: acc) it rfl
    | fail e => simp only [bind_tc_fail]; exact FlatOrder.rel.refl
    | div => simp only [bind_tc_div]; exact FlatOrder.rel.refl
  · -- the right fixpoint, mapped, below the left-hand side
    have hadm := admissible_result_apply₂ (fun s acc (v : Result (List T × S₂)) =>
        (do let r ← v; ok (r.1, φ r.2)) ⊑
        alloc.vec.FromIteratorVec.iterToList inst₁ (φ s) acc) fun _ _ => FlatOrder.rel.bot
    refine alloc.vec.FromIteratorVec.iterToList.fixpoint_induct inst₂ _ hadm ?_ s acc
    intro recur ih s acc
    dsimp only
    rw [alloc.vec.FromIteratorVec.iterToList.eq_def inst₁ (φ s) acc, hnext s]
    cases inst₂.next s with
    | ok r =>
      obtain ⟨opt, it⟩ := r
      cases opt with
      | none => simp only [bind_tc_ok]; exact FlatOrder.rel.refl
      | some item => simp only [bind_tc_ok]; exact ih it (item :: acc)
    | fail e => simp only [bind_tc_fail]; exact FlatOrder.rel.refl
    | div => simp only [bind_tc_div]; exact FlatOrder.rel.bot


/-- `foldFromNext` commutes with a map `ψ` of closure states that commutes with the closure's
    `call_mut`. -/
theorem core.iter.traits.iterator.foldFromNext_state_map {Self Item B F₁ F₂ : Type}
    (next : Self → Result (Option Item × Self))
    (inst₁ : core.ops.function.FnMut F₁ (B × Item) B)
    (inst₂ : core.ops.function.FnMut F₂ (B × Item) B) (ψ : F₂ → F₁)
    (hcall : ∀ st args, inst₁.call_mut (ψ st) args =
      (do let r ← inst₂.call_mut st args; ok (r.1, ψ r.2)))
    (self : Self) (init : B) (st : F₂) :
    core.iter.traits.iterator.foldFromNext next inst₁ self init (ψ st) =
      (do let r ← core.iter.traits.iterator.foldFromNext next inst₂ self init st
          ok (r.1, r.2.1, ψ r.2.2)) := by
  apply PartialOrder.rel_antisymm
  · have hadm := admissible_result_apply₃ (fun self init st₁ v => ∀ st, st₁ = ψ st → v ⊑
        (do let r ← core.iter.traits.iterator.foldFromNext next inst₂ self init st
            ok (r.1, r.2.1, ψ r.2.2)))
      fun _ _ _ _ _ => FlatOrder.rel.bot
    refine core.iter.traits.iterator.foldFromNext.fixpoint_induct next inst₁ _ hadm ?_
      self init (ψ st) st rfl
    intro recur ih self init st₁ st hst
    subst hst
    dsimp only
    rw [core.iter.traits.iterator.foldFromNext.eq_def next inst₂ self init st]
    cases next self with
    | ok r =>
      obtain ⟨item, it⟩ := r
      cases item with
      | none => simp only [bind_tc_ok, pure]; exact FlatOrder.rel.refl
      | some item =>
        simp only [bind_tc_ok, hcall, bind_assoc_eq]
        cases inst₂.call_mut st (init, item) with
        | ok r =>
          obtain ⟨acc, st'⟩ := r
          simp only [bind_tc_ok]
          exact ih it acc (ψ st') st' rfl
        | fail e => simp only [bind_tc_fail]; exact FlatOrder.rel.refl
        | div => simp only [bind_tc_div]; exact FlatOrder.rel.refl
    | fail e => simp only [bind_tc_fail]; exact FlatOrder.rel.refl
    | div => simp only [bind_tc_div]; exact FlatOrder.rel.refl
  · have hadm := admissible_result_apply₃ (fun self init st (v : Result (B × Self × F₂)) =>
        (do let r ← v; ok (r.1, r.2.1, ψ r.2.2)) ⊑
          core.iter.traits.iterator.foldFromNext next inst₁ self init (ψ st))
      fun _ _ _ => FlatOrder.rel.bot
    refine core.iter.traits.iterator.foldFromNext.fixpoint_induct next inst₂ _ hadm ?_ self init st
    intro recur ih self init st
    dsimp only
    rw [core.iter.traits.iterator.foldFromNext.eq_def next inst₁ self init (ψ st)]
    cases next self with
    | ok r =>
      obtain ⟨item, it⟩ := r
      cases item with
      | none => simp only [bind_tc_ok, pure]; exact FlatOrder.rel.refl
      | some item =>
        simp only [bind_tc_ok, hcall, bind_assoc_eq]
        cases inst₂.call_mut st (init, item) with
        | ok r =>
          obtain ⟨acc, st'⟩ := r
          simp only [bind_tc_ok]
          exact ih it acc st'
        | fail e => simp only [bind_tc_fail]; exact FlatOrder.rel.refl
        | div => simp only [bind_tc_div]; exact FlatOrder.rel.bot
    | fail e => simp only [bind_tc_fail]; exact FlatOrder.rel.refl
    | div => simp only [bind_tc_div]; exact FlatOrder.rel.bot

/-- A proved fold state relation preserves the function-item state relation. -/
/-
```lean
-/
def core.iter.traits.iterator.Iterator.foldStateMap {I A : Type}
    (iterInst : core.iter.traits.iterator.Iterator I A) : Prop :=
  ∀ {Acc F₁ F₂ : Type} (inst₁ : core.ops.function.FnMut F₁ (Acc × A) Acc)
    (inst₂ : core.ops.function.FnMut F₂ (Acc × A) Acc) (φ : F₂ → F₁),
    (∀ st args, inst₁.call_mut (φ st) args =
      (do let r ← inst₂.call_mut st args; ok (r.1, φ r.2))) →
    ∀ (self : I) (init : Acc) (st : F₂),
      iterInst.fold inst₁ self init (φ st) =
      (do let r ← iterInst.fold inst₂ self init st
          ok (r.1, r.2.1, φ r.2.2))

/- 
```lean
-/
def core.iter.traits.iterator.Iterator.tryFoldStateMap {I A : Type}
    (iterInst : core.iter.traits.iterator.Iterator I A) : Prop :=
  ∀ {Acc F₁ F₂ R Residual : Type}
    (inst₁ : core.ops.function.FnMut F₁ (Acc × A) R)
    (inst₂ : core.ops.function.FnMut F₂ (Acc × A) R)
    (tryInst : core.ops.try_trait.Try R Acc Residual) (φ : F₂ → F₁),
    (∀ st args, inst₁.call_mut (φ st) args =
      (do let r ← inst₂.call_mut st args; ok (r.1, φ r.2))) →
    ∀ (self : I) (init : Acc) (st : F₂),
      iterInst.try_fold inst₁ tryInst self init (φ st) =
      (do let r ← iterInst.try_fold inst₂ tryInst self init st
          ok (r.1, r.2.1, φ r.2.2))
/-
```
-/

theorem core.iter.adapters.map.IteratorMap.fold_builtin {I A B Acc G : Type}
    (iterInst : core.iter.traits.iterator.Iterator I A)
    (hf : core.iter.traits.iterator.Iterator.foldStateMap iterInst)
    (f : A → Result B) (foldInst : core.ops.function.FnMut G (Acc × B) Acc)
    (s : I) (init : Acc) (g : G) :
    core.iter.adapters.map.IteratorMap.fold iterInst (BuiltinFnMut A B) foldInst
      ⟨s, f⟩ init g =
    (do let r ← core.iter.adapters.map.IteratorMap.fold iterInst
          ({ FnOnceInst := { call_once := fun _ a => do let b ← f a; ok (b, ()) },
             call_mut := fun _ a => do let b ← f a; ok (b, ()) } : core.ops.function.FnMut Unit A B)
          foldInst ⟨s, ()⟩ init g
        ok (r.1, ⟨r.2.1.iter, f⟩, r.2.2)) := by
  simp only [core.iter.adapters.map.IteratorMap.fold, bind_assoc_eq, bind_tc_ok]
  have key : ∀ (c₁ : (A → Result B) × G → Acc × A → Result (Acc × (A → Result B) × G))
      (c₂ : Unit × G → Acc × A → Result (Acc × Unit × G)),
      (∀ st args, c₁ (f, st.2) args = (do let r ← c₂ st args; ok (r.1, (f, r.2.2)))) →
      ∀ (K : Acc × I × (A → Result B) × G →
        Result (Acc × core.iter.adapters.map.Map I (A → Result B) × G)),
      (do
        let x ← iterInst.fold
          { FnOnceInst := { call_once := c₁ }, call_mut := c₁ } s init (f, g)
        K x) =
      (do
        let x ← iterInst.fold
          { FnOnceInst := { call_once := c₂ }, call_mut := c₂ } s init ((), g)
        K (x.1, x.2.1, (f, x.2.2.2))) := by
    intro c₁ c₂ hcall K
    rw [show ((f, g) : (A → Result B) × G) = (fun st : Unit × G => (f, st.2)) ((), g) from rfl,
      hf
        { FnOnceInst := { call_once := c₁ }, call_mut := c₁ }
        { FnOnceInst := { call_once := c₂ }, call_mut := c₂ }
        (fun (st : Unit × G) => (f, st.2)) hcall]
    simp only [bind_assoc_eq, bind_tc_ok]
  apply key
  intro st args
  simp only [BuiltinFnMut, bind_assoc_eq]
  cases f args.2 with
  | ok b => simp only [bind_tc_ok]
  | fail e => simp only [bind_tc_fail]
  | div => simp only [bind_tc_div]


/-- `iter.map(f).sum::<usize>()` over a slice iterator for a function item `f`: as with a
    stateless closure calling `f` (the closure's state goes through the slice iterator's `fold`,
    `foldFromNext`). -/
theorem core.iter.traits.iterator.Iterator.sum.default_map_builtin_slice {T C : Type}
    (f : T → Result Usize) (s : core.slice.iter.Iter T)
    (k : Usize × core.iter.adapters.map.Map (core.slice.iter.Iter T) (T → Result Usize) → Result C) :
    (do let r ← core.iter.traits.iterator.Iterator.sum.default
          (core.iter.traits.iterator.IteratorMap (core.iter.traits.iterator.IteratorSliceIter T)
            (BuiltinFnMut T Usize))
          core.iter.traits.accum.SumUsizeUsize ⟨s, f⟩
        k r) =
    (do let r ← core.iter.traits.iterator.Iterator.sum.default
          (core.iter.traits.iterator.IteratorMap (core.iter.traits.iterator.IteratorSliceIter T)
            ({ FnOnceInst := { call_once := fun _ a => do let b ← f a; ok (b, ()) },
               call_mut := fun _ a => do let b ← f a; ok (b, ()) } : core.ops.function.FnMut Unit T Usize))
          core.iter.traits.accum.SumUsizeUsize ⟨s, ()⟩
        k (r.1, ⟨r.2.iter, f⟩)) := by
  simp only [core.iter.traits.iterator.Iterator.sum.default, core.iter.traits.accum.SumUsizeUsize.sum,
    core.iter.adapters.map.IteratorMap.fold, core.slice.iter.IteratorSliceIter.fold,
    bind_assoc_eq, bind_tc_ok]
  have key : ∀ (c₁ : (T → Result Usize) × Unit → Usize × T → Result (Usize × (T → Result Usize) × Unit))
      (c₂ : Unit × Unit → Usize × T → Result (Usize × Unit × Unit)),
      (∀ st args, c₁ (f, st.2) args = (do let r ← c₂ st args; ok (r.1, (f, r.2.2)))) →
      ∀ (K : Usize × core.slice.iter.Iter T × (T → Result Usize) × Unit → Result C),
      (do
        let x ← core.iter.traits.iterator.foldFromNext core.slice.iter.IteratorSliceIter.next
          { FnOnceInst := { call_once := c₁ }, call_mut := c₁ } s 0#usize (f, ())
        K x) =
      (do
        let x ← core.iter.traits.iterator.foldFromNext core.slice.iter.IteratorSliceIter.next
          { FnOnceInst := { call_once := c₂ }, call_mut := c₂ } s 0#usize ((), ())
        K (x.1, x.2.1, (f, x.2.2.2))) := by
    intro c₁ c₂ hcall K
    rw [show ((f, ()) : (T → Result Usize) × Unit) = (fun st : Unit × Unit => (f, st.2)) ((), ()) from rfl,
      core.iter.traits.iterator.foldFromNext_state_map _
        { FnOnceInst := { call_once := c₁ }, call_mut := c₁ }
        { FnOnceInst := { call_once := c₂ }, call_mut := c₂ } (fun (st : Unit × Unit) => (f, st.2)) hcall]
    simp only [bind_assoc_eq, bind_tc_ok]
  apply key
  intro st args
  simp only [BuiltinFnMut, bind_assoc_eq]
  cases f args.2 with
  | ok b => simp only [bind_tc_ok, pure]
  | fail e => simp only [bind_tc_fail]
  | div => simp only [bind_tc_div]

/-- `extendLoop` commutes with a map `φ` of iterator states that commutes with `next`. -/
theorem alloc.vec.ExtendVec.extendLoop_state_map {T S₁ S₂ : Type}
    (inst₁ : core.iter.traits.iterator.Iterator S₁ T)
    (inst₂ : core.iter.traits.iterator.Iterator S₂ T) (φ : S₂ → S₁)
    (hnext : ∀ s, inst₁.next (φ s) = (do let r ← inst₂.next s; ok (r.1, φ r.2)))
    (rev : alloc.vec.Vec T) (s : S₂) :
    alloc.vec.ExtendVec.extendLoop inst₁ rev (φ s) =
      (do let r ← alloc.vec.ExtendVec.extendLoop inst₂ rev s; ok (r.1, φ r.2)) := by
  apply PartialOrder.rel_antisymm
  · have hadm := admissible_result_apply₂ (fun rev st v => ∀ s, st = φ s → v ⊑
        (do let r ← alloc.vec.ExtendVec.extendLoop inst₂ rev s; ok (r.1, φ r.2)))
      fun _ _ _ _ => FlatOrder.rel.bot
    refine alloc.vec.ExtendVec.extendLoop.fixpoint_induct inst₁ _ hadm ?_ rev (φ s) s rfl
    intro recur ih rev st s hst
    subst hst
    dsimp only
    rw [hnext s, alloc.vec.ExtendVec.extendLoop.eq_def inst₂ rev s]
    cases inst₂.next s with
    | ok r =>
      obtain ⟨opt, it⟩ := r
      cases opt with
      | none => simp only [bind_tc_ok, pure]; exact FlatOrder.rel.refl
      | some item =>
        simp only [bind_tc_ok]
        split
        · exact ih _ (φ it) it rfl
        · simp only [bind_tc_fail]; exact FlatOrder.rel.refl
    | fail e => simp only [bind_tc_fail]; exact FlatOrder.rel.refl
    | div => simp only [bind_tc_div]; exact FlatOrder.rel.refl
  · have hadm := admissible_result_apply₂ (fun rev s (v : Result (alloc.vec.Vec T × S₂)) =>
        (do let r ← v; ok (r.1, φ r.2)) ⊑
        alloc.vec.ExtendVec.extendLoop inst₁ rev (φ s)) fun _ _ => FlatOrder.rel.bot
    refine alloc.vec.ExtendVec.extendLoop.fixpoint_induct inst₂ _ hadm ?_ rev s
    intro recur ih rev s
    dsimp only
    rw [alloc.vec.ExtendVec.extendLoop.eq_def inst₁ rev (φ s), hnext s]
    cases inst₂.next s with
    | ok r =>
      obtain ⟨opt, it⟩ := r
      cases opt with
      | none => simp only [bind_tc_ok, pure]; exact FlatOrder.rel.refl
      | some item =>
        simp only [bind_tc_ok]
        split
        · exact ih _ it
        · simp only [bind_tc_fail]; exact FlatOrder.rel.refl
    | fail e => simp only [bind_tc_fail]; exact FlatOrder.rel.refl
    | div => simp only [bind_tc_div]; exact FlatOrder.rel.bot

/-- `vec.extend(iter.map(f))` for a function item `f`: as with a stateless closure calling `f`. -/
theorem alloc.vec.ExtendVec.extend_map_builtin {I A B C : Type}
    (iterInst : core.iter.traits.iterator.Iterator I A) (f : A → Result B)
    (self : alloc.vec.Vec B) (s : I)
    (k : Unit × alloc.vec.Vec B × core.iter.adapters.map.Map I (A → Result B) → Result C) :
    (do let r ← alloc.vec.ExtendVec.extend
          (core.iter.traits.collect.IntoIterator.Blanket
            (core.iter.traits.iterator.IteratorMap iterInst (BuiltinFnMut A B))) self ⟨s, f⟩
        k r) =
    (do let r ← alloc.vec.ExtendVec.extend
          (core.iter.traits.collect.IntoIterator.Blanket
            (core.iter.traits.iterator.IteratorMap iterInst
              ({ FnOnceInst := { call_once := fun _ a => do let b ← f a; ok (b, ()) },
                 call_mut := fun _ a => do let b ← f a; ok (b, ()) } :
                core.ops.function.FnMut Unit A B))) self ⟨s, ()⟩
        k (r.1, r.2.1, ⟨r.2.2.iter, f⟩)) := by
  have h := alloc.vec.ExtendVec.extendLoop_state_map
    (core.iter.traits.iterator.IteratorMap iterInst (BuiltinFnMut A B))
    (core.iter.traits.iterator.IteratorMap iterInst
      ({ FnOnceInst := { call_once := fun _ a => do let b ← f a; ok (b, ()) },
         call_mut := fun _ a => do let b ← f a; ok (b, ()) } : core.ops.function.FnMut Unit A B))
    (fun st => ⟨st.iter, f⟩) (core.iter.adapters.map.IteratorMap.next_builtin iterInst f)
  simp only [alloc.vec.ExtendVec.extend,
    core.iter.traits.collect.IntoIterator.Blanket.into_iter, bind_tc_ok, bind_assoc_eq] at h ⊢
  rw [show (⟨s, f⟩ : core.iter.adapters.map.Map I (A → Result B)) =
    (fun st : core.iter.adapters.map.Map I Unit => ⟨st.iter, f⟩) ⟨s, ()⟩ from rfl, h]
  simp only [bind_assoc_eq, bind_tc_ok, pure, id]

/-- `tryFoldFromNext` commutes with a map `ψ` of closure states that commutes with the closure's
    `call_mut`. -/
theorem core.iter.traits.iterator.tryFoldFromNext_state_map {Self Item B F₁ F₂ R Residual : Type}
    (next : Self → Result (Option Item × Self))
    (inst₁ : core.ops.function.FnMut F₁ (B × Item) R)
    (inst₂ : core.ops.function.FnMut F₂ (B × Item) R)
    (tryInst : core.ops.try_trait.Try R B Residual) (ψ : F₂ → F₁)
    (hcall : ∀ st args, inst₁.call_mut (ψ st) args =
      (do let r ← inst₂.call_mut st args; ok (r.1, ψ r.2)))
    (self : Self) (init : B) (st : F₂) :
    core.iter.traits.iterator.tryFoldFromNext next inst₁ tryInst self init (ψ st) =
      (do let r ← core.iter.traits.iterator.tryFoldFromNext next inst₂ tryInst self init st
          ok (r.1, r.2.1, ψ r.2.2)) := by
  apply PartialOrder.rel_antisymm
  · have hadm := admissible_result_apply₃ (fun self init st₁ v => ∀ st, st₁ = ψ st → v ⊑
        (do let r ← core.iter.traits.iterator.tryFoldFromNext next inst₂ tryInst self init st
            ok (r.1, r.2.1, ψ r.2.2)))
      fun _ _ _ _ _ => FlatOrder.rel.bot
    refine core.iter.traits.iterator.tryFoldFromNext.fixpoint_induct next inst₁ tryInst _ hadm ?_
      self init (ψ st) st rfl
    intro recur ih self init st₁ st hst
    subst hst
    dsimp only
    rw [core.iter.traits.iterator.tryFoldFromNext.eq_def next inst₂ tryInst self init st]
    cases next self with
    | ok r =>
      obtain ⟨item, it⟩ := r
      cases item with
      | none =>
        simp only [bind_tc_ok, pure, bind_assoc_eq]
        cases tryInst.from_output init <;> simp only [bind_tc_ok, bind_tc_fail, bind_tc_div] <;>
          exact FlatOrder.rel.refl
      | some item =>
        simp only [bind_tc_ok, hcall, bind_assoc_eq]
        cases inst₂.call_mut st (init, item) with
        | ok r =>
          obtain ⟨res, st'⟩ := r
          simp only [bind_tc_ok]
          cases tryInst.branch res with
          | ok c =>
            cases c with
            | Break residual =>
              simp only [bind_tc_ok, pure, bind_assoc_eq]
              cases tryInst.FromResidualInst.from_residual residual <;>
                simp only [bind_tc_ok, bind_tc_fail, bind_tc_div] <;> exact FlatOrder.rel.refl
            | Continue acc => simp only [bind_tc_ok]; exact ih it acc (ψ st') st' rfl
          | fail e => simp only [bind_tc_fail]; exact FlatOrder.rel.refl
          | div => simp only [bind_tc_div]; exact FlatOrder.rel.refl
        | fail e => simp only [bind_tc_fail]; exact FlatOrder.rel.refl
        | div => simp only [bind_tc_div]; exact FlatOrder.rel.refl
    | fail e => simp only [bind_tc_fail]; exact FlatOrder.rel.refl
    | div => simp only [bind_tc_div]; exact FlatOrder.rel.refl
  · have hadm := admissible_result_apply₃ (fun self init st (v : Result (R × Self × F₂)) =>
        (do let r ← v; ok (r.1, r.2.1, ψ r.2.2)) ⊑
          core.iter.traits.iterator.tryFoldFromNext next inst₁ tryInst self init (ψ st))
      fun _ _ _ => FlatOrder.rel.bot
    refine core.iter.traits.iterator.tryFoldFromNext.fixpoint_induct next inst₂ tryInst _ hadm ?_
      self init st
    intro recur ih self init st
    dsimp only
    rw [core.iter.traits.iterator.tryFoldFromNext.eq_def next inst₁ tryInst self init (ψ st)]
    cases next self with
    | ok r =>
      obtain ⟨item, it⟩ := r
      cases item with
      | none =>
        simp only [bind_tc_ok, pure, bind_assoc_eq]
        cases tryInst.from_output init <;> simp only [bind_tc_ok, bind_tc_fail, bind_tc_div] <;>
          exact FlatOrder.rel.refl
      | some item =>
        simp only [bind_tc_ok, hcall, bind_assoc_eq]
        cases inst₂.call_mut st (init, item) with
        | ok r =>
          obtain ⟨res, st'⟩ := r
          simp only [bind_tc_ok]
          cases tryInst.branch res with
          | ok c =>
            cases c with
            | Break residual =>
              simp only [bind_tc_ok, pure, bind_assoc_eq]
              cases tryInst.FromResidualInst.from_residual residual <;>
                simp only [bind_tc_ok, bind_tc_fail, bind_tc_div] <;>
                exact FlatOrder.rel.refl
            | Continue acc => simp only [bind_tc_ok]; exact ih it acc st'
          | fail e => simp only [bind_tc_fail]; exact FlatOrder.rel.refl
          | div => simp only [bind_tc_div]; exact FlatOrder.rel.bot
        | fail e => simp only [bind_tc_fail]; exact FlatOrder.rel.refl
        | div => simp only [bind_tc_div]; exact FlatOrder.rel.bot
    | fail e => simp only [bind_tc_fail]; exact FlatOrder.rel.refl
    | div => simp only [bind_tc_div]; exact FlatOrder.rel.bot

/-- An actual next-based method establishes its own try_fold state law. -/
/-
```lean
-/
theorem core.iter.traits.iterator.Iterator.tryFoldStateMap_of_next {I A : Type}
    (iterInst : core.iter.traits.iterator.Iterator I A)
    (htf : ∀ {Acc F R Residual : Type}
      (fnInst : core.ops.function.FnMut F (Acc × A) R)
      (tryInst : core.ops.try_trait.Try R Acc Residual) (s : I) (init : Acc) (f : F),
      iterInst.try_fold fnInst tryInst s init f =
        core.iter.traits.iterator.tryFoldFromNext iterInst.next fnInst tryInst s init f) :
    core.iter.traits.iterator.Iterator.tryFoldStateMap iterInst := by
  intro Acc F₁ F₂ R Residual inst₁ inst₂ tryInst φ hcall self init st
  simp only [htf]
  exact core.iter.traits.iterator.tryFoldFromNext_state_map
    _ inst₁ inst₂ tryInst φ hcall self init st
/-
```
-/


/-- A proved try_fold state relation preserves every residual and callback state. -/
/-
```lean
-/
theorem core.iter.adapters.map.IteratorMap.try_fold_builtin {I A B Acc G R Residual : Type}
    (iterInst : core.iter.traits.iterator.Iterator I A)
    (htf : core.iter.traits.iterator.Iterator.tryFoldStateMap iterInst)
    (f : A → Result B) (foldInst : core.ops.function.FnMut G (Acc × B) R)
    (tryInst : core.ops.try_trait.Try R Acc Residual) (s : I) (init : Acc) (g : G) :
    core.iter.adapters.map.IteratorMap.try_fold iterInst (BuiltinFnMut A B) foldInst tryInst
      ⟨s, f⟩ init g =
    (do let r ← core.iter.adapters.map.IteratorMap.try_fold iterInst
          ({ FnOnceInst := { call_once := fun _ a => do let b ← f a; ok (b, ()) },
             call_mut := fun _ a => do let b ← f a; ok (b, ()) } : core.ops.function.FnMut Unit A B)
          foldInst tryInst ⟨s, ()⟩ init g
        ok (r.1, ⟨r.2.1.iter, f⟩, r.2.2)) := by
  simp only [core.iter.adapters.map.IteratorMap.try_fold, bind_assoc_eq, bind_tc_ok]
  have key : ∀ (c₁ : (A → Result B) × G → Acc × A → Result (R × (A → Result B) × G))
      (c₂ : Unit × G → Acc × A → Result (R × Unit × G)),
      (∀ st args, c₁ (f, st.2) args = (do let r ← c₂ st args; ok (r.1, (f, r.2.2)))) →
      ∀ (K : R × I × (A → Result B) × G →
        Result (R × core.iter.adapters.map.Map I (A → Result B) × G)),
      (do
        let x ← iterInst.try_fold
          { FnOnceInst := { call_once := c₁ }, call_mut := c₁ } tryInst s init (f, g)
        K x) =
      (do
        let x ← iterInst.try_fold
          { FnOnceInst := { call_once := c₂ }, call_mut := c₂ } tryInst s init ((), g)
        K (x.1, x.2.1, (f, x.2.2.2))) := by
    intro c₁ c₂ hcall K
    rw [show ((f, g) : (A → Result B) × G) = (fun st : Unit × G => (f, st.2)) ((), g) from rfl,
      htf
        { FnOnceInst := { call_once := c₁ }, call_mut := c₁ }
        { FnOnceInst := { call_once := c₂ }, call_mut := c₂ } tryInst
        (fun (st : Unit × G) => (f, st.2)) hcall]
    simp only [bind_assoc_eq, bind_tc_ok]
  apply key
  intro st args
  simp only [BuiltinFnMut, bind_assoc_eq]
  cases f args.2 with
  | ok b => simp only [bind_tc_ok]
  | fail e => simp only [bind_tc_fail]
  | div => simp only [bind_tc_div]
/-
```
-/
/-
```lean
-/
/-- Indexed collection preserves monotonicity of each fallible access operation. -/
/-
```lean
-/
@[partial_fixpoint_monotone]
theorem alloc.vec.FromIteratorVec.collectIndexed.monotone
    {γ : Type w} [Lean.Order.PartialOrder γ] {T I : Type}
    (access : γ → core.iter.traits.iterator.RandomAccess I T)
    (iter : I) (index : Usize) (acc : Usize × List T) (remaining : Nat)
    (haccess : ∀ iter index, Lean.Order.monotone
      (fun g => (access g).get_unchecked iter index)) :
    Lean.Order.monotone (fun g =>
      alloc.vec.FromIteratorVec.collectIndexed (access g) iter index acc remaining) := by
  induction remaining generalizing iter index acc with
  | zero => exact monotone_const _
  | succ remaining ih =>
    simp only [alloc.vec.FromIteratorVec.collectIndexed]
    repeat' first
      | exact haccess _ _
      | exact ih _ _ _
      | monotonicity
/-
```
-/

/-- Collection preserves state for all consumers under their separate method laws. -/
/-
```lean
-/
theorem alloc.vec.FromIteratorVec.collectIndexed_state_map {T S₁ S₂ : Type}
    (access₁ : core.iter.traits.iterator.RandomAccess S₁ T)
    (access₂ : core.iter.traits.iterator.RandomAccess S₂ T) (φ : S₂ → S₁)
    (haccess : ∀ s index, access₁.get_unchecked (φ s) index =
      (do let r ← access₂.get_unchecked s index; ok (r.1, φ r.2)))
    (s : S₂) (index : Usize) (acc : Usize × List T) (remaining : Nat) :
    alloc.vec.FromIteratorVec.collectIndexed access₁ (φ s) index acc remaining =
      (do let r ← alloc.vec.FromIteratorVec.collectIndexed access₂ s index acc remaining
          ok (r.1, φ r.2)) := by
  induction remaining generalizing s index acc with
  | zero => rfl
  | succ remaining ih =>
    simp only [alloc.vec.FromIteratorVec.collectIndexed, haccess, bind_assoc_eq, bind_tc_ok]
    simp_rw [ih]

theorem core.iter.traits.iterator.Iterator.collect.default_map_builtin_vec {I A B C : Type}
    (iterInst : core.iter.traits.iterator.Iterator I A) (f : A → Result B) (s : I)
    (hf : core.iter.traits.iterator.Iterator.foldStateMap iterInst)
    (htf : core.iter.traits.iterator.Iterator.tryFoldStateMap iterInst)
    (reuse : Bool)
    (k : alloc.vec.Vec B × core.iter.adapters.map.Map I (A → Result B) → Result C) :
    (do let r ← core.iter.traits.iterator.Iterator.collect.default
          { core.iter.traits.iterator.IteratorMap iterInst (BuiltinFnMut A B)
            with in_place_collect := reuse }
          (core.iter.traits.collect.FromIteratorVec B) ⟨s, f⟩
        k r) =
    (do let r ← core.iter.traits.iterator.Iterator.collect.default
          { core.iter.traits.iterator.IteratorMap iterInst
            ({ FnOnceInst := { call_once := fun _ a => do let b ← f a; ok (b, ()) },
               call_mut := fun _ a => do let b ← f a; ok (b, ()) } : core.ops.function.FnMut Unit A B)
            with in_place_collect := reuse }
          (core.iter.traits.collect.FromIteratorVec B) ⟨s, ()⟩
        k (r.1, ⟨r.2.iter, f⟩)) := by
  let stateless : core.ops.function.FnMut Unit A B := {
    FnOnceInst := { call_once := fun _ a => do let b ← f a; ok (b, ()) }
    call_mut := fun _ a => do let b ← f a; ok (b, ())
  }
  have hnext := alloc.vec.FromIteratorVec.iterToList_state_map
    (core.iter.traits.iterator.IteratorMap iterInst (BuiltinFnMut A B))
    (core.iter.traits.iterator.IteratorMap iterInst stateless)
    (fun st => ⟨st.iter, f⟩) (core.iter.adapters.map.IteratorMap.next_builtin iterInst f) ⟨s, ()⟩ []
  have hfold :
      alloc.vec.FromIteratorVec.collectByFold
        (core.iter.traits.iterator.IteratorMap iterInst (BuiltinFnMut A B)) ⟨s, f⟩ =
      (do let r ← alloc.vec.FromIteratorVec.collectByFold
            (core.iter.traits.iterator.IteratorMap iterInst stateless) ⟨s, ()⟩
          ok (r.1, ⟨r.2.iter, f⟩)) := by
    simp only [alloc.vec.FromIteratorVec.collectByFold]
    rw [core.iter.adapters.map.IteratorMap.fold_builtin iterInst hf]
    simp only [bind_assoc_eq, bind_tc_ok, stateless, pure]
  have htry :
      alloc.vec.FromIteratorVec.collectByTryFold
        (core.iter.traits.iterator.IteratorMap iterInst (BuiltinFnMut A B)) ⟨s, f⟩ =
      (do let r ← alloc.vec.FromIteratorVec.collectByTryFold
            (core.iter.traits.iterator.IteratorMap iterInst stateless) ⟨s, ()⟩
          ok (r.1, ⟨r.2.iter, f⟩)) := by
    simp only [alloc.vec.FromIteratorVec.collectByTryFold]
    rw [core.iter.adapters.map.IteratorMap.try_fold_builtin iterInst htf]
    simp only [bind_assoc_eq, bind_tc_ok, stateless, pure]
    congr 1
    funext r
    cases r.1 with
    | Ok acc => rfl
    | Err impossible => nomatch impossible
  have hnative :
      alloc.vec.FromIteratorVec.collectNative
        { core.iter.traits.iterator.IteratorMap iterInst (BuiltinFnMut A B)
          with in_place_collect := reuse } ⟨s, f⟩ =
      (do let r ← alloc.vec.FromIteratorVec.collectNative
            { core.iter.traits.iterator.IteratorMap iterInst stateless
              with in_place_collect := reuse } ⟨s, ()⟩
          ok (r.1, ⟨r.2.iter, f⟩)) := by
    cases reuse with
    | false =>
      simp only [alloc.vec.FromIteratorVec.collectNative,
        core.iter.adapters.map.IteratorMap.size_hint, Bool.false_eq_true, ↓reduceIte]
      split
      · simp only [bind_assoc_eq]
        congr 1
        funext bound
        rcases bound with ⟨lower, upper⟩
        cases upper
        · simp only [bind_tc_fail]
        · simpa only [bind_tc_ok] using hfold
      · exact hnext
    | true =>
      simp only [alloc.vec.FromIteratorVec.collectNative,
        core.iter.adapters.map.IteratorMap.size_hint, ↓reduceIte]
      cases access_eq : iterInst.random_access with
      | none => simpa only [access_eq, Option.map_none] using htry
      | some access =>
        simp only [Option.map_some, bind_assoc_eq]
        congr 1
        funext bound
        /-
        ```lean
        -/
        refine alloc.vec.FromIteratorVec.collectIndexed_state_map _ _
          /-
          ```lean
          -/
          (fun st : core.iter.adapters.map.Map I Unit =>
            (⟨st.iter, f⟩ : core.iter.adapters.map.Map I (A → Result B)))
          /-
          ```
          -/
          ?_ ⟨s, ()⟩ _ _ _
        /-
        ```
        -/
        intro st index
        simp only [bind_assoc_eq, BuiltinFnMut, stateless]
        cases access.get_unchecked st.iter index with
        | ok r =>
          simp only [bind_tc_ok]
          cases f r.1 <;> simp only [bind_tc_ok, bind_tc_fail, bind_tc_div]
        | fail e => simp only [bind_tc_fail]
        | div => simp only [bind_tc_div]
  simp only [core.iter.traits.iterator.Iterator.collect.default,
    alloc.vec.FromIteratorVec.from_iter, core.iter.traits.collect.IntoIterator.Blanket.into_iter,
    bind_tc_ok, bind_assoc_eq]
  rw [hnative]
  simp only [bind_assoc_eq, bind_tc_ok, stateless]
  congr 1
  funext r
  split <;> simp only [bind_tc_ok, bind_tc_fail, id]
/-
```
-/

/-- Dictionary equality preserves every field and the authenticated certificate flag. -/
/-
```lean
-/
theorem core.iter.traits.iterator.Iterator.collect.default_map_builtin_vec_into_iter
    {T V C : Type}
    (mapped : core.iter.traits.iterator.Iterator
      (core.iter.adapters.map.Map (alloc.vec.into_iter.IntoIter T) (T → Result V)) V)
    (hmapped : mapped =
      { core.iter.traits.iterator.IteratorMap (core.iter.traits.iterator.IteratorVecIntoIter T)
        (BuiltinFnMut T V) with in_place_collect := mapped.in_place_collect })
    (f : T → Result V) (s : alloc.vec.into_iter.IntoIter T)
    (k : alloc.vec.Vec V × core.iter.adapters.map.Map (alloc.vec.into_iter.IntoIter T)
      (T → Result V) → Result C) :
    (do let r ← core.iter.traits.iterator.Iterator.collect.default mapped
          (core.iter.traits.collect.FromIteratorVec V) ⟨s, f⟩
        k r) =
    (do let r ← core.iter.traits.iterator.Iterator.collect.default
          { core.iter.traits.iterator.IteratorMap (core.iter.traits.iterator.IteratorVecIntoIter T)
            ({ FnOnceInst := { call_once := fun _ a => do let b ← f a; ok (b, ()) },
               call_mut := fun _ a => do let b ← f a; ok (b, ()) } :
              core.ops.function.FnMut Unit T V)
            with in_place_collect := mapped.in_place_collect }
          (core.iter.traits.collect.FromIteratorVec V) ⟨s, ()⟩
        k (r.1, ⟨r.2.iter, f⟩)) := by
  have hcollect := congrArg (fun inst =>
    core.iter.traits.iterator.Iterator.collect.default inst
      (core.iter.traits.collect.FromIteratorVec V) ⟨s, f⟩) hmapped
  dsimp only at hcollect
  rw [hcollect]
  exact core.iter.traits.iterator.Iterator.collect.default_map_builtin_vec _ f s
    (fun inst₁ inst₂ φ hcall self init st =>
      core.iter.traits.iterator.foldFromNext_state_map _ inst₁ inst₂ φ hcall self init st)
    (core.iter.traits.iterator.Iterator.tryFoldStateMap_of_next _ (fun _ _ _ _ _ => rfl))
    mapped.in_place_collect k

theorem core.iter.traits.iterator.Iterator.collect.default_map_builtin_vec_slice
    {T V C : Type}
    (mapped : core.iter.traits.iterator.Iterator
      (core.iter.adapters.map.Map (core.slice.iter.Iter T) (T → Result V)) V)
    (hmapped : mapped =
      { core.iter.traits.iterator.IteratorMap (core.iter.traits.iterator.IteratorSliceIter T)
        (BuiltinFnMut T V) with in_place_collect := mapped.in_place_collect })
    (f : T → Result V) (s : core.slice.iter.Iter T)
    (k : alloc.vec.Vec V × core.iter.adapters.map.Map (core.slice.iter.Iter T)
      (T → Result V) → Result C) :
    (do let r ← core.iter.traits.iterator.Iterator.collect.default mapped
          (core.iter.traits.collect.FromIteratorVec V) ⟨s, f⟩
        k r) =
    (do let r ← core.iter.traits.iterator.Iterator.collect.default
          { core.iter.traits.iterator.IteratorMap (core.iter.traits.iterator.IteratorSliceIter T)
            ({ FnOnceInst := { call_once := fun _ a => do let b ← f a; ok (b, ()) },
               call_mut := fun _ a => do let b ← f a; ok (b, ()) } :
              core.ops.function.FnMut Unit T V)
            with in_place_collect := mapped.in_place_collect }
          (core.iter.traits.collect.FromIteratorVec V) ⟨s, ()⟩
        k (r.1, ⟨r.2.iter, f⟩)) := by
  have hcollect := congrArg (fun inst =>
    core.iter.traits.iterator.Iterator.collect.default inst
      (core.iter.traits.collect.FromIteratorVec V) ⟨s, f⟩) hmapped
  dsimp only at hcollect
  rw [hcollect]
  exact core.iter.traits.iterator.Iterator.collect.default_map_builtin_vec _ f s
    (fun inst₁ inst₂ φ hcall self init st => by
      simp only [core.slice.iter.IteratorSliceIter.fold]
      rw [core.iter.traits.iterator.foldFromNext_state_map _ inst₁ inst₂ φ hcall]
      simp only [bind_assoc_eq, bind_tc_ok])
    (core.iter.traits.iterator.Iterator.tryFoldStateMap_of_next _ (fun _ _ _ _ _ => rfl))
    mapped.in_place_collect k
/-
```
-/

/-- The `GenericShunt` over `iter.map(f)` for a function item `f`: its `next` is the `next` of the
    shunt over a stateless closure calling `f`, the function put back as the state. -/
theorem core.iter.adapters.GenericShunt.next_map_builtin {I A B Res V : Type}
    (iterInst : core.iter.traits.iterator.Iterator I A)
    (htf : core.iter.traits.iterator.Iterator.tryFoldStateMap iterInst)
    (branch : B → core.ops.control_flow.ControlFlow Res V) (f : A → Result B)
    (sh : core.iter.adapters.GenericShunt.Shunt (core.iter.adapters.map.Map I Unit) Res) :
    core.iter.adapters.GenericShunt.next branch
      (core.iter.traits.iterator.IteratorMap iterInst (BuiltinFnMut A B))
      ⟨⟨sh.iter.iter, f⟩, sh.residual⟩ =
    (do let r ← core.iter.adapters.GenericShunt.next branch
          (core.iter.traits.iterator.IteratorMap iterInst
            ({ FnOnceInst := { call_once := fun _ a => do let b ← f a; ok (b, ()) },
               call_mut := fun _ a => do let b ← f a; ok (b, ()) } :
              core.ops.function.FnMut Unit A B)) sh
        ok (r.1, ⟨⟨r.2.iter.iter, f⟩, r.2.residual⟩)) := by
  simp only [core.iter.adapters.GenericShunt.next, core.iter.adapters.GenericShunt.tryFold,
    core.iter.adapters.map.IteratorMap.try_fold_builtin iterInst htf, bind_assoc_eq, bind_tc_ok]
  congr 1
  funext x
  split
  · cases (core.iter.traits.iterator.controlFlowTry V Unit).from_output _ <;>
      simp only [bind_tc_ok, bind_tc_fail, bind_tc_div, pure]
  · simp only [bind_tc_ok, pure]


/-- Result collection preserves the residual and iterator under the proved try_fold state law. -/
theorem core.iter.traits.iterator.Iterator.collect.default_map_builtin_result_vec
    {I A V E C : Type} (iterInst : core.iter.traits.iterator.Iterator I A)
    (htf : core.iter.traits.iterator.Iterator.tryFoldStateMap iterInst)
    (f : A → Result (core.result.Result V E)) (s : I)
    (k : core.result.Result (alloc.vec.Vec V) E ×
      core.iter.adapters.map.Map I (A → Result (core.result.Result V E)) → Result C) :
    (do let r ← core.iter.traits.iterator.Iterator.collect.default
          (core.iter.traits.iterator.IteratorMap iterInst
            (BuiltinFnMut A (core.result.Result V E)))
          (core.iter.traits.collect.FromIteratorResult E
            (core.iter.traits.collect.FromIteratorVec V)) ⟨s, f⟩
        k r) =
    (do let r ← core.iter.traits.iterator.Iterator.collect.default
          (core.iter.traits.iterator.IteratorMap iterInst
            ({ FnOnceInst := { call_once := fun _ a => do let b ← f a; ok (b, ()) },
               call_mut := fun _ a => do let b ← f a; ok (b, ()) } :
              core.ops.function.FnMut Unit A (core.result.Result V E)))
          (core.iter.traits.collect.FromIteratorResult E
            (core.iter.traits.collect.FromIteratorVec V)) ⟨s, ()⟩
        k (r.1, ⟨r.2.iter, f⟩)) := by
  have h := alloc.vec.FromIteratorVec.iterToList_state_map
    (core.iter.adapters.GenericShunt.iterator core.result.FromIteratorResult.branch
      (core.iter.traits.iterator.IteratorMap iterInst (BuiltinFnMut A (core.result.Result V E))))
    (core.iter.adapters.GenericShunt.iterator core.result.FromIteratorResult.branch
      (core.iter.traits.iterator.IteratorMap iterInst
        ({ FnOnceInst := { call_once := fun _ a => do let b ← f a; ok (b, ()) },
           call_mut := fun _ a => do let b ← f a; ok (b, ()) } :
          core.ops.function.FnMut Unit A (core.result.Result V E))))
    (fun sh => ⟨⟨sh.iter.iter, f⟩, sh.residual⟩)
    (fun sh => core.iter.adapters.GenericShunt.next_map_builtin iterInst htf
      core.result.FromIteratorResult.branch f sh) ⟨⟨s, ()⟩, none⟩ []
  simp only [core.iter.traits.iterator.Iterator.collect.default,
    core.result.FromIteratorResult.from_iter, core.iter.adapters.GenericShunt.tryProcess,
    alloc.vec.FromIteratorVec.from_iter, core.iter.traits.collect.IntoIterator.Blanket.into_iter,
    alloc.vec.FromIteratorVec.collectNative, core.iter.adapters.GenericShunt.iterator,
    bind_tc_ok, bind_assoc_eq, Bool.false_eq_true, ↓reduceIte] at h ⊢
  rw [h]
  simp only [bind_assoc_eq, bind_tc_ok]
  congr 1
  funext r
  split <;> simp only [bind_tc_ok, bind_tc_fail, pure, id]

theorem core.iter.traits.iterator.Iterator.collect.default_map_builtin_result_vec_into_iter
    {T V E C : Type} (f : T → Result (core.result.Result V E)) (s : alloc.vec.into_iter.IntoIter T)
    (k : core.result.Result (alloc.vec.Vec V) E ×
      core.iter.adapters.map.Map (alloc.vec.into_iter.IntoIter T)
        (T → Result (core.result.Result V E)) → Result C) :
    (do let r ← core.iter.traits.iterator.Iterator.collect.default
          (core.iter.traits.iterator.IteratorMap (core.iter.traits.iterator.IteratorVecIntoIter T)
            (BuiltinFnMut T (core.result.Result V E)))
          (core.iter.traits.collect.FromIteratorResult E
            (core.iter.traits.collect.FromIteratorVec V)) ⟨s, f⟩
        k r) =
    (do let r ← core.iter.traits.iterator.Iterator.collect.default
          (core.iter.traits.iterator.IteratorMap (core.iter.traits.iterator.IteratorVecIntoIter T)
            ({ FnOnceInst := { call_once := fun _ a => do let b ← f a; ok (b, ()) },
               call_mut := fun _ a => do let b ← f a; ok (b, ()) } :
              core.ops.function.FnMut Unit T (core.result.Result V E)))
          (core.iter.traits.collect.FromIteratorResult E
            (core.iter.traits.collect.FromIteratorVec V)) ⟨s, ()⟩
        k (r.1, ⟨r.2.iter, f⟩)) :=
  core.iter.traits.iterator.Iterator.collect.default_map_builtin_result_vec _
    /-
    ```lean
    -/
    (core.iter.traits.iterator.Iterator.tryFoldStateMap_of_next _ (fun _ _ _ _ _ => rfl)) f s k
    /-
    ```
    -/

theorem core.iter.traits.iterator.Iterator.collect.default_map_builtin_result_vec_slice
    {T V E C : Type} (f : T → Result (core.result.Result V E)) (s : core.slice.iter.Iter T)
    (k : core.result.Result (alloc.vec.Vec V) E ×
      core.iter.adapters.map.Map (core.slice.iter.Iter T)
        (T → Result (core.result.Result V E)) → Result C) :
    (do let r ← core.iter.traits.iterator.Iterator.collect.default
          (core.iter.traits.iterator.IteratorMap (core.iter.traits.iterator.IteratorSliceIter T)
            (BuiltinFnMut T (core.result.Result V E)))
          (core.iter.traits.collect.FromIteratorResult E
            (core.iter.traits.collect.FromIteratorVec V)) ⟨s, f⟩
        k r) =
    (do let r ← core.iter.traits.iterator.Iterator.collect.default
          (core.iter.traits.iterator.IteratorMap (core.iter.traits.iterator.IteratorSliceIter T)
            ({ FnOnceInst := { call_once := fun _ a => do let b ← f a; ok (b, ()) },
               call_mut := fun _ a => do let b ← f a; ok (b, ()) } :
              core.ops.function.FnMut Unit T (core.result.Result V E)))
          (core.iter.traits.collect.FromIteratorResult E
            (core.iter.traits.collect.FromIteratorVec V)) ⟨s, ()⟩
        k (r.1, ⟨r.2.iter, f⟩)) :=
  core.iter.traits.iterator.Iterator.collect.default_map_builtin_result_vec _
    /-
    ```lean
    -/
    (core.iter.traits.iterator.Iterator.tryFoldStateMap_of_next _ (fun _ _ _ _ _ => rfl)) f s k
    /-
    ```
    -/

end AdapterMono

end Aeneas.Std

open Lean Meta Elab Tactic in
/-- Step of `aeneas_monotonicity` for a goal `monotone (fun g => fun y => e)`: reduce it to
    `∀ y, monotone (fun g => e)` (`monotone_of_monotone_apply`), with the types and order
    instances taken from the goal. `monotonicity` applies the same lemma by unification, which
    fails when the type of `e` mentions `g` through a type which does not use it (the result
    type of the loop body of a visitor specialized to an instance built from `g`, e.g.
    `ControlFlow (... closure_specialized inst ...)`): the function is unified first and its
    inferred type then depends on `g`. Fails on other goals, so repeating it terminates. -/
elab "aeneas_lambda_monotone" : tactic => do
  let goal ← getMainGoal
  let goal' ← goal.withContext do
    let type ← instantiateMVars (← goal.getType)
    let_expr Lean.Order.monotone γ instγ _ instβ f := type
      | throwError "aeneas_lambda_monotone: not a monotonicity goal"
    let f := f.headBeta
    unless f.isLambda && f.bindingBody!.isLambda do
      throwError "aeneas_lambda_monotone: not a function of two arguments"
    let some inst ← whnfUntil instβ ``Lean.Order.instOrderPi
      | throwError "aeneas_lambda_monotone: not a function order"
    let_expr Lean.Order.instOrderPi α βf instβf ← inst
      | throwError "aeneas_lambda_monotone: not a function order"
    let lem ← mkAppOptM ``Lean.Order.monotone_of_monotone_apply #[α, βf, γ, instγ, instβf, f]
    let .forallE _ hTy _ _ ← whnfR (← inferType lem)
      | throwError "aeneas_lambda_monotone: unexpected lemma type"
    let h ← mkFreshExprSyntheticOpaqueMVar (← Core.betaReduce (← instantiateMVars hTy))
    goal.assign (mkApp lem h)
    let (_, g') ← h.mvarId!.intro1
    pure g'
  replaceMainGoal [goal']

open Aeneas.Std Lean.Order in
/-- Normalize callback containers before monadic monotonicity: `Result.ok` has
    flat equality, so its callback payload must be consumed before comparing it.
    A function item used as a closure (`iter.map(f)`, instance `BuiltinFnMut`) is the
    state of the adapter, so the recursive function would be a value in the flat order:
    the consumers of such adapters (`collect` into a `Vec` or a `Result` of a `Vec`,
    `Vec::extend`, `sum`) are rewritten to the same consumers of a stateless closure calling
    the function, whose instance, not state, depends on it. Goals no monotonicity lemma
    applies to go through `aeneas_phantom_monotone` (types which mention the recursive
    function without using it, e.g. the state type of a closure specialized to an instance
    built from it), then `aeneas_lambda_monotone` (above), then `aeneas_unfold_monotone`,
    then `aeneas_fix_monotone` (the other three in
    `Aeneas.Std.Core.FmtWithSlice`); the monotonicity lemmas of the models taking trait
    instances and those rewritings are above. -/
macro "aeneas_monotonicity" : tactic =>
  `(tactic| (
    simp (config := { failIfUnchanged := false }) (disch := rfl) only
      [core.fmt.rt.Argument.new_display, core.fmt.rt.Argument.new_debug,
      core.fmt.rt.Argument.new_lower_hex, core.fmt.rt.Argument.new_lower_exp,
      core.fmt.rt.Argument.new_debug_noop,
      core.fmt.Arguments.new, Aeneas.Std.Array.make, bind_tc_ok,
      core.iter.traits.iterator.Iterator.map.default_builtin,
      core.iter.traits.iterator.Iterator.collect.default_map_builtin_vec_into_iter,
      core.iter.traits.iterator.Iterator.collect.default_map_builtin_vec_slice,
      core.iter.traits.iterator.Iterator.sum.default_map_builtin_slice,
      core.iter.traits.iterator.Iterator.collect.default_map_builtin_result_vec_into_iter,
      core.iter.traits.iterator.Iterator.collect.default_map_builtin_result_vec_slice,
      alloc.vec.ExtendVec.extend_map_builtin,
      Function.uncurry_apply_pair]
    repeat' (first
      | simp only [Bool.false_eq_true, Bool.true_eq_false, ↓reduceIte,
          Option.map_none, Option.map_some]
      | monotonicity | aeneas_phantom_monotone | aeneas_lambda_monotone
      | aeneas_unfold_monotone | aeneas_fix_monotone)))
