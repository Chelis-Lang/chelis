import Aeneas.Std.Scalar.Ops.Neg

namespace Aeneas.Std

open Result

/-!
# Checked negation and absolute value of signed scalars

`checked_neg` (core/src/num/int_macros.rs, via `overflowing_neg`) is `None` on
overflow, and `checked_abs` is `if self.is_negative() { self.checked_neg() } else
{ Some(self) }`: both are `None` exactly on the minimum value.
-/

/- [core::num::{T}::checked_neg] -/
def core.num.checked_neg_IScalar {ty} (x : IScalar ty) : Option (IScalar ty) :=
  Option.ofResult (IScalar.neg x)

/- [core::num::{T}::checked_abs] -/
def core.num.checked_abs_IScalar {ty} (x : IScalar ty) : Option (IScalar ty) :=
  if x.val < 0 then core.num.checked_neg_IScalar x else some x

@[rust_fun "core::num::{i8}::checked_neg" -canFail]
def core.num.I8.checked_neg (x : I8) : Option I8 := core.num.checked_neg_IScalar x
@[rust_fun "core::num::{i16}::checked_neg" -canFail]
def core.num.I16.checked_neg (x : I16) : Option I16 := core.num.checked_neg_IScalar x
@[rust_fun "core::num::{i32}::checked_neg" -canFail]
def core.num.I32.checked_neg (x : I32) : Option I32 := core.num.checked_neg_IScalar x
@[rust_fun "core::num::{i64}::checked_neg" -canFail]
def core.num.I64.checked_neg (x : I64) : Option I64 := core.num.checked_neg_IScalar x

@[rust_fun "core::num::{i8}::checked_abs" -canFail]
def core.num.I8.checked_abs (x : I8) : Option I8 := core.num.checked_abs_IScalar x
@[rust_fun "core::num::{i16}::checked_abs" -canFail]
def core.num.I16.checked_abs (x : I16) : Option I16 := core.num.checked_abs_IScalar x
@[rust_fun "core::num::{i32}::checked_abs" -canFail]
def core.num.I32.checked_abs (x : I32) : Option I32 := core.num.checked_abs_IScalar x
@[rust_fun "core::num::{i64}::checked_abs" -canFail]
def core.num.I64.checked_abs (x : I64) : Option I64 := core.num.checked_abs_IScalar x

end Aeneas.Std
