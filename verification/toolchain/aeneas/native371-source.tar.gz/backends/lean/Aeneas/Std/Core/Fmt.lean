import Aeneas.Std.Core.Core
import Aeneas.Std.Core.Result
import Aeneas.Std.Array.Array
import Aeneas.Std.String

namespace Aeneas.Std

@[reducible, rust_type "core::fmt::Error"]
def core.fmt.Error := Unit

namespace core.fmt

/-- The pinned Rust FormattingOptions bit layout. -/
structure Options where
  flags : Nat := 0x60000020
  width : Nat := 0
  precision : Nat := 0
  deriving Repr, DecidableEq

def Options.bit (o : Options) (n : Nat) : Bool := o.flags / 2 ^ n % 2 == 1

def repeatChar (c : Char) (n : Nat) : String := String.ofList (List.replicate n c)

/-- UTF-8 decoding is checked rather than replacing malformed bytes. -/
def decode (bytes : List U8) : Result String :=
  if h : bytes.length ≤ Usize.max then Str.toString ⟨bytes, h⟩ else .fail .panic

/-- A writer is explicit so a callback's Rust fmt::Error and an extraction failure
    remain distinct. `output` is the observable writer state. This callback models
    `write_str` with the default UTF-8 `write_char`; custom `fmt::Write` trait
    implementations (including `write_char` overrides) have no extraction mapping. -/
@[rust_type "core::fmt::Formatter"]
structure Formatter where
  output : String := ""
  options : Options := {}
  write : String → String → Result (core.result.Result Unit Error × String) :=
    fun output text => .ok (.Ok (), output ++ text)
  indent : Nat := 0
  lineStart : Bool := false

abbrev Outcome := Result (core.result.Result Unit Error × Formatter)
abbrev Callback := Formatter → Outcome

/-- Compose writes without swallowing either kind of failure. -/
def thenFormat (r : Outcome) (k : Callback) : Outcome := do
  let (status, fmt) ← r
  match status with
  | .Err e => .ok (.Err e, fmt)
  | .Ok () => k fmt

def Formatter.append (fmt : Formatter) (s : String) : Outcome := do
  let (text, lineStart) := if fmt.indent == 0 then
      (s, if s.isEmpty then fmt.lineStart else s.endsWith "\n")
    else s.toList.foldl (fun (acc, start) c =>
      ((acc ++ (if start then repeatChar ' ' fmt.indent else "")).push c,
        c == '\n')) ("", fmt.lineStart)
  let (status, output) ← fmt.write fmt.output text
  .ok (status, { fmt with output, lineStart })

/-- Rust's default `Write::write_char` makes one UTF-8 `write_str` call.
    Padding must keep those calls separate, including when a writer fails. -/
def writeRepeated (text : String) : Nat → Formatter → Outcome
  | 0, fmt => .ok (.Ok (), fmt)
  | n + 1, fmt => thenFormat (fmt.append text) (writeRepeated text n)

def writeFill (fill : Char) (n : Nat) : Callback :=
  writeRepeated (String.singleton fill) n

def Formatter.padWith (fmt : Formatter) (padding : Nat) (numeric : Bool)
    (content : Callback) : Outcome :=
  let o := fmt.options
  let alignment := o.flags / 2 ^ 29 % 4
  let left := if alignment == 0 then 0 else if alignment == 1 then padding
    else if alignment == 2 then padding / 2 else if numeric then padding else 0
  let fill := Char.ofNat (o.flags % 2 ^ 21)
  thenFormat (writeFill fill left fmt) (fun fmt =>
    thenFormat (content fmt) (writeFill fill (padding - left)))

def Formatter.pad (fmt : Formatter) (s : String) (numeric : Bool := false) : Outcome :=
  let width := if fmt.options.bit 27 then fmt.options.width else 0
  fmt.padWith (width - s.length) numeric (fun fmt => fmt.append s)

def Options.zeroPadded (o : Options) : Options :=
  let flags := o.flags - o.flags % 2 ^ 21 - (o.flags / 2 ^ 29 % 4) * 2 ^ 29 +
    '0'.toNat + 2 ^ 29
  { o with flags }

/-- `pad_integral` writes sign, optional prefix (even an empty one), and the
    complete digit buffer separately. Zero-fill moves sign/prefix before padding;
    ordinary alignment puts them after pre-padding and before post-padding. -/
def Formatter.padIntegral (fmt : Formatter) (negative : Bool) (basePrefix digits : String) : Outcome :=
  let o := fmt.options
  let sign : Option Char := if negative then some '-' else if o.bit 21 then some '+' else none
  let writePrefix : Callback := fun fmt =>
    thenFormat (match sign with
      | none => .ok (.Ok (), fmt)
      | some c => fmt.append (String.singleton c)) (fun fmt =>
        if o.bit 23 then fmt.append basePrefix else .ok (.Ok (), fmt))
  let content : Callback := fun fmt =>
    thenFormat (writePrefix fmt) (fun fmt => fmt.append digits)
  let length := digits.utf8ByteSize + (if sign.isSome then 1 else 0) +
    (if o.bit 23 then basePrefix.length else 0)
  let padding := o.width - length
  if padding == 0 then content fmt
  else if o.bit 24 then
    let fmt := { fmt with options := o.zeroPadded }
    thenFormat (writePrefix fmt) (fun fmt =>
      thenFormat (writeFill '0' padding fmt) (fun fmt =>
        thenFormat (fmt.append digits) (fun fmt => .ok (.Ok (), { fmt with options := o }))))
  else fmt.padWith padding true content

@[rust_trait "core::fmt::Debug"]
structure Debug (T : Type u) where
  fmt : T → Formatter → Outcome

@[rust_trait "core::fmt::Display"]
structure Display (Self : Type) where
  fmt : Self → Formatter → Outcome

@[rust_trait "core::fmt::LowerHex"]
structure LowerHex (Self : Type) where
  fmt : Self → Formatter → Outcome

@[rust_trait "core::fmt::UpperHex"]
structure UpperHex (Self : Type) where
  fmt : Self → Formatter → Outcome

@[rust_trait "core::fmt::LowerExp"]
structure LowerExp (Self : Type) where
  fmt : Self → Formatter → Outcome

@[rust_type "core::fmt::rt::Argument"]
inductive rt.Argument where
  | placeholder (format : Callback)
  | count (value : Nat)

@[rust_type "core::fmt::Arguments"]
inductive Arguments where
  | literal (text : String)
  | template (bytes : List U8) (args : List rt.Argument)

@[rust_fun "core::fmt::{core::fmt::Arguments<'a>}::from_str"]
def Arguments.from_str (s : Str) : Result Arguments := do
  .ok (.literal (← decode s.val))

@[rust_fun "core::fmt::{core::fmt::Arguments<'a>}::from_str_nonconst"]
def Arguments.from_str_nonconst := Arguments.from_str

@[rust_fun "core::fmt::{core::fmt::Arguments<'a>}::new"]
def Arguments.new {N M : Usize} (bytes : Std.Array U8 N)
    (args : Std.Array rt.Argument M) : Result Arguments :=
  .ok (.template bytes.val args.val)

@[rust_fun "core::fmt::rt::{core::fmt::rt::Argument<'0>}::new_debug"]
def rt.Argument.new_debug {T : Type} (inst : Debug T) (x : T) : Result rt.Argument :=
  .ok (.placeholder (inst.fmt x))

@[rust_fun "core::fmt::rt::{core::fmt::rt::Argument<'0>}::new_display"]
def rt.Argument.new_display {T : Type} (inst : Display T) (x : T) : Result rt.Argument :=
  .ok (.placeholder (inst.fmt x))

@[rust_fun "core::fmt::rt::{core::fmt::rt::Argument<'0>}::new_lower_hex"]
def rt.Argument.new_lower_hex {T : Type} (inst : LowerHex T) (x : T) : Result rt.Argument :=
  .ok (.placeholder (inst.fmt x))

@[rust_fun "core::fmt::rt::{core::fmt::rt::Argument<'0>}::new_upper_hex"]
def rt.Argument.new_upper_hex {T : Type} (inst : UpperHex T) (x : T) : Result rt.Argument :=
  .ok (.placeholder (inst.fmt x))

@[rust_fun "core::fmt::rt::{core::fmt::rt::Argument<'0>}::new_lower_exp"]
def rt.Argument.new_lower_exp {T : Type} (inst : LowerExp T) (x : T) : Result rt.Argument :=
  .ok (.placeholder (inst.fmt x))

@[rust_fun "core::fmt::rt::{core::fmt::rt::Argument<'0>}::new_debug_noop"]
def rt.Argument.new_debug_noop {T : Type} (_ : Debug T) (_ : T) : Result rt.Argument :=
  .ok (.placeholder (fun f => .ok (.Ok (), f)))

@[rust_fun "core::fmt::rt::{core::fmt::rt::Argument<'0>}::from_usize"]
def rt.Argument.from_usize (n : Usize) : Result rt.Argument :=
  if n.val ≤ 65535 then .ok (.count n.val) else .fail .panic

/-- Reads a fixed-width little-endian field, rejecting invalid unsafe templates. -/
def readLE : Nat → List U8 → Result (Nat × List U8)
  | 0, bytes => .ok (0, bytes)
  | n + 1, b :: bytes => do
    let (v, rest) ← readLE n bytes
    .ok (b.val + 256 * v, rest)
  | _ + 1, [] => .fail .panic

def readField (present : Bool) (size defaultValue : Nat) (bytes : List U8) :
    Result (Nat × List U8) :=
  if present then readLE size bytes else .ok (defaultValue, bytes)

def argumentCount (args : List rt.Argument) (i : Nat) : Result Nat :=
  match args[i]? with
  | some (.count n) => .ok n
  | _ => .fail .panic

/-- Invoke a dynamic argument without changing the meaning of invalid indices or
    count arguments. Keeping invocation separate exposes the consumed callback
    to the partial-fixpoint monotonicity prover. -/
def argumentFormat (args : List rt.Argument) (i : Nat) (fmt : Formatter) : Outcome :=
  match args[i]? with
  | some (.placeholder callback) => callback fmt
  | _ => .fail .panic

/-- Fuel is the byte length, not an arbitrary execution bound: every opcode
    consumes at least one byte. Embedded NULs belong to fields/literal payloads. -/
def renderTemplate : Nat → List U8 → List rt.Argument → Nat → Formatter → Outcome
  | 0, _, _, _, _ => .fail .panic
  | fuel + 1, bytes, args, next, fmt => do
    let (tag, bytes) ← readLE 1 bytes
    if tag == 0 then return (.Ok (), fmt)
    if tag ≤ 128 then
      let (length, bytes) ← if tag == 128 then readLE 2 bytes else .ok (tag, bytes)
      if length > bytes.length then return ← .fail .panic
      let text ← decode (bytes.take length)
      thenFormat (fmt.append text) (renderTemplate fuel (bytes.drop length) args next)
    else if tag < 192 then .fail .panic
    else
      let bit := fun n => tag / 2 ^ n % 2 == 1
      let (flags, bytes) ← readField (bit 0) 4 0x60000020 bytes
      let (width, bytes) ← readField (bit 1) 2 0 bytes
      let (precision, bytes) ← readField (bit 2) 2 0 bytes
      let (index, bytes) ← readField (bit 3) 2 next bytes
      let width ← if bit 4 then argumentCount args width else .ok width
      let precision ← if bit 5 then argumentCount args precision else .ok precision
      let (status, f) ← argumentFormat args index { fmt with options := ⟨flags, width, precision⟩ }
      let f := { f with options := fmt.options }
      thenFormat (.ok (status, f)) (renderTemplate fuel bytes args (index + 1))

@[rust_fun "core::fmt::{core::fmt::Formatter<'a>}::write_str"]
def Formatter.write_str (fmt : Formatter) (s : Str) : Outcome := do
  fmt.append (← decode s.val)

@[rust_fun "core::fmt::{core::fmt::Formatter<'a>}::write_fmt"]
def Formatter.write_fmt (fmt : Formatter) (args : Arguments) : Outcome :=
  match args with
  | .literal text => fmt.append text
  | .template bytes args => renderTemplate (bytes.length + 1) bytes args 0 fmt

abbrev DebugValue := Dyn (fun T : Type => Debug T)

def debugValue (x : DebugValue) : Callback := x.inst.fmt x.value

def Formatter.indented (fmt : Formatter) (indent : Nat) (k : Callback) : Outcome := do
  let (status, f) ← k { fmt with indent }
  .ok (status, { f with indent := fmt.indent })

/-- All builders share Rust's separators and short-circuiting behavior. Pretty
    indentation is writer state, so embedded newlines are indented as well. -/
def debugEntries {T : Type u} (pretty : Bool) (render : T → Callback) :
    List T → Formatter → Outcome
  | [], fmt => .ok (.Ok (), fmt)
  | value :: rest, fmt =>
    thenFormat (render value fmt) (fun fmt =>
      if !pretty && rest.isEmpty then .ok (.Ok (), fmt)
      else thenFormat (fmt.append (if pretty then ",\n" else ", "))
        (debugEntries pretty render rest))

def debugFields (pretty : Bool) (fields : List (String × DebugValue)) : Callback :=
  debugEntries pretty (fun (name, value) fmt =>
    thenFormat (fmt.append (name ++ ": ")) (debugValue value)) fields

def Formatter.debugStruct (fmt : Formatter) (name : String)
    (fields : List (String × DebugValue)) : Outcome :=
  if fields.isEmpty then fmt.append name
  else
    let pretty := fmt.options.bit 23
    thenFormat (fmt.append (name ++ if pretty then " {\n" else " { ")) (fun f =>
      thenFormat (f.indented (if pretty then fmt.indent + 4 else fmt.indent)
        (debugFields pretty fields)) (fun f => f.append (if pretty then "}" else " }")))

def Formatter.debugTuple (fmt : Formatter) (name : String)
    (fields : List DebugValue) : Outcome :=
  if fields.isEmpty then fmt.append name
  else
    let pretty := fmt.options.bit 23
    thenFormat (fmt.append (name ++ if pretty then "(\n" else "(")) (fun f =>
      thenFormat (f.indented (if pretty then fmt.indent + 4 else fmt.indent)
        (debugEntries pretty debugValue fields)) (fun f =>
          f.append (if !pretty && name.isEmpty && fields.length == 1 then ",)" else ")")))

def Formatter.debugList {T : Type} (fmt : Formatter) (inst : Debug T) (values : List T) : Outcome :=
  let pretty := fmt.options.bit 23 && !values.isEmpty
  thenFormat (fmt.append (if pretty then "[\n" else "[")) (fun f =>
    thenFormat (f.indented (if pretty then fmt.indent + 4 else fmt.indent)
      (debugEntries pretty inst.fmt values))
      (fun f => f.append "]"))

/-- `Formatter::debug_set().entries(..).finish()` (core/src/fmt/builders.rs `DebugSet`): the
    entries of `debug_list` between `{` and `}`. -/
def Formatter.debugSet {T : Type} (fmt : Formatter) (inst : Debug T) (values : List T) : Outcome :=
  let pretty := fmt.options.bit 23 && !values.isEmpty
  thenFormat (fmt.append (if pretty then "{\n" else "{")) (fun f =>
    thenFormat (f.indented (if pretty then fmt.indent + 4 else fmt.indent)
      (debugEntries pretty inst.fmt values))
      (fun f => f.append "}"))

/-- `Formatter::debug_map().entries(..).finish()` (core/src/fmt/builders.rs `DebugMap`):
    `{`, the entries as `key: value` separated by `, ` (pretty: each entry on its own
    indented line followed by `,`), then `}`. The key and the value of an entry are
    written through the same pad adapter. -/
def Formatter.debugMap {K V : Type} (fmt : Formatter) (keyInst : Debug K) (valueInst : Debug V)
    (entries : List (K × V)) : Outcome :=
  let pretty := fmt.options.bit 23 && !entries.isEmpty
  thenFormat (fmt.append (if pretty then "{\n" else "{")) (fun f =>
    thenFormat (f.indented (if pretty then fmt.indent + 4 else fmt.indent)
      (debugEntries pretty (fun (key, value) fmt =>
        thenFormat (keyInst.fmt key fmt) (fun fmt =>
          thenFormat (fmt.append ": ") (valueInst.fmt value))) entries))
      (fun f => f.append "}"))

@[rust_fun "core::fmt::{core::fmt::Debug<&'0 @T>}::fmt"]
def DebugShared.fmt {T : Type} (inst : Debug T) (x : T) (fmt : Formatter) : Outcome := inst.fmt x fmt
@[reducible, rust_trait_impl "core::fmt::Debug<&'0 @T>"]
def DebugShared {T : Type} (inst : Debug T) : Debug T := ⟨DebugShared.fmt inst⟩

/-- `impl UpperHex for &T` (core/src/fmt/mod.rs `fmt_ref!`): `UpperHex::fmt(&**self, f)`. -/
@[rust_fun "core::fmt::{core::fmt::UpperHex<&'0 @T>}::fmt"]
def UpperHexShared.fmt {T : Type} (inst : UpperHex T) (x : T) (fmt : Formatter) : Outcome :=
  inst.fmt x fmt
@[reducible, rust_trait_impl "core::fmt::UpperHex<&'0 @T>"]
def UpperHexShared {T : Type} (inst : UpperHex T) : UpperHex T := ⟨UpperHexShared.fmt inst⟩

/-- `impl LowerHex for &T` (core/src/fmt/mod.rs `fmt_ref!`): `LowerHex::fmt(&**self, f)`. -/
@[rust_fun "core::fmt::{core::fmt::LowerHex<&'0 @T>}::fmt"]
def LowerHexShared.fmt {T : Type} (inst : LowerHex T) (x : T) (fmt : Formatter) : Outcome :=
  inst.fmt x fmt
@[reducible, rust_trait_impl "core::fmt::LowerHex<&'0 @T>"]
def LowerHexShared {T : Type} (inst : LowerHex T) : LowerHex T := ⟨LowerHexShared.fmt inst⟩

@[rust_fun "core::fmt::{core::fmt::Debug<bool>}::fmt"]
def DebugBool.fmt (x : Bool) (fmt : Formatter) : Outcome :=
  let text := if x then "true" else "false"
  fmt.pad (if fmt.options.bit 28 then String.ofList (text.toList.take fmt.options.precision) else text)
@[reducible, rust_trait_impl "core::fmt::Debug<bool>"]
def DebugBool : Debug Bool := ⟨DebugBool.fmt⟩
@[rust_fun "core::fmt::{core::fmt::Display<bool>}::fmt"]
def DisplayBool.fmt := DebugBool.fmt
@[reducible, rust_trait_impl "core::fmt::Display<bool>"]
def DisplayBool : Display Bool := ⟨DisplayBool.fmt⟩

@[rust_fun "core::fmt::{core::fmt::Debug<()>}::fmt"]
def DebugUnit.fmt (_ : Unit) (fmt : Formatter) : Outcome := fmt.append "()"
@[reducible, rust_trait_impl "core::fmt::Debug<()>"]
def DebugUnit : Debug Unit := ⟨DebugUnit.fmt⟩

@[rust_fun "core::fmt::{core::fmt::Formatter<'a>}::debug_struct_field1_finish"]
def Formatter.debug_struct_field1_finish (fmt : Formatter) (name n0 : Str)
    (v0 : DebugValue) : Outcome := do
  fmt.debugStruct (← decode name.val) [(← decode n0.val, v0)]

@[rust_fun "core::fmt::{core::fmt::Formatter<'a>}::debug_struct_field2_finish"]
def Formatter.debug_struct_field2_finish (fmt : Formatter) (name n0 : Str)
    (v0 : DebugValue) (n1 : Str) (v1 : DebugValue) : Outcome := do
  fmt.debugStruct (← decode name.val) [(← decode n0.val, v0), (← decode n1.val, v1)]

@[rust_fun "core::fmt::{core::fmt::Formatter<'a>}::debug_struct_field3_finish"]
def Formatter.debug_struct_field3_finish (fmt : Formatter) (name n0 : Str)
    (v0 : DebugValue) (n1 : Str) (v1 : DebugValue) (n2 : Str) (v2 : DebugValue) : Outcome := do
  fmt.debugStruct (← decode name.val)
    [(← decode n0.val, v0), (← decode n1.val, v1), (← decode n2.val, v2)]

@[rust_fun "core::fmt::{core::fmt::Formatter<'a>}::debug_struct_field4_finish"]
def Formatter.debug_struct_field4_finish (fmt : Formatter) (name n0 : Str)
    (v0 : DebugValue) (n1 : Str) (v1 : DebugValue) (n2 : Str) (v2 : DebugValue)
    (n3 : Str) (v3 : DebugValue) : Outcome := do
  fmt.debugStruct (← decode name.val)
    [(← decode n0.val, v0), (← decode n1.val, v1), (← decode n2.val, v2), (← decode n3.val, v3)]

@[rust_fun "core::fmt::{core::fmt::Formatter<'a>}::debug_struct_field5_finish"]
def Formatter.debug_struct_field5_finish (fmt : Formatter) (name n0 : Str)
    (v0 : DebugValue) (n1 : Str) (v1 : DebugValue) (n2 : Str) (v2 : DebugValue)
    (n3 : Str) (v3 : DebugValue) (n4 : Str) (v4 : DebugValue) : Outcome := do
  fmt.debugStruct (← decode name.val)
    [(← decode n0.val, v0), (← decode n1.val, v1), (← decode n2.val, v2),
      (← decode n3.val, v3), (← decode n4.val, v4)]

@[rust_fun "core::fmt::{core::fmt::Formatter<'a>}::debug_tuple_field1_finish"]
def Formatter.debug_tuple_field1_finish (fmt : Formatter) (name : Str) (v0 : DebugValue) : Outcome := do
  fmt.debugTuple (← decode name.val) [v0]

@[rust_fun "core::fmt::{core::fmt::Formatter<'a>}::debug_tuple_field2_finish"]
def Formatter.debug_tuple_field2_finish (fmt : Formatter) (name : Str)
    (v0 v1 : DebugValue) : Outcome := do
  fmt.debugTuple (← decode name.val) [v0, v1]

@[rust_fun "core::fmt::{core::fmt::Formatter<'a>}::debug_tuple_field3_finish"]
def Formatter.debug_tuple_field3_finish (fmt : Formatter) (name : Str)
    (v0 v1 v2 : DebugValue) : Outcome := do
  fmt.debugTuple (← decode name.val) [v0, v1, v2]

/-- `core::fmt::builders::DebugStruct<'a, 'b> { fmt: &'a mut Formatter<'b>, result: fmt::Result,
    has_fields: bool }` (core/src/fmt/builders.rs, rustc 1.95): the borrowed formatter is held by
    value, and `Formatter::debug_struct`'s lens gives it back from the final builder. -/
@[rust_type "core::fmt::builders::DebugStruct" (mutRegions := #[0]) (body := .opaque)]
structure DebugStruct where
  fmt : Formatter
  result : core.result.Result Unit Error
  has_fields : Bool

/-- `Formatter::debug_struct` = `builders::debug_struct_new(self, name)`:
    `let result = fmt.write_str(name); DebugStruct { fmt, result, has_fields: false }`. -/
@[rust_fun "core::fmt::{core::fmt::Formatter<'a>}::debug_struct"]
def Formatter.debug_struct (fmt : Formatter) (name : Str) :
    Result (DebugStruct × (DebugStruct → Formatter)) := do
  let (result, fmt) ← fmt.write_str name
  .ok ({ fmt, result, has_fields := false }, fun b => b.fmt)

/-- `DebugStruct::field(name, value)` = `field_with(name, |f| value.fmt(f))`: unless the result is
    already an error, `" { "` (the first field) or `", "`, the name, `": "` and the value; pretty
    (`{:#?}`), `" {\n"` before the first field, then the name, `": "`, the value and `",\n"` through
    a pad adapter (each line indented by four more spaces). The result is the first error; the
    builder has fields from then on. The returned `&mut Self` is the builder itself: the value
    given back to it is the value given back to `self` (`fun b => b`), and the staged backward
    function of the lifetime `'a` (the formatter's borrow) passes the builder given back through
    `self` (first stage) and the one given back through the returned reference (last stage) on as
    the values of `self` for the caller of `self` and for the lender of `'a` (`fun s b => (s, b)`,
    the whole builder being the state of `'a`). -/
@[rust_fun "core::fmt::builders::{core::fmt::builders::DebugStruct<'a, 'b>}::field"]
def DebugStruct.field (self : DebugStruct) (name : Str) (value : DebugValue) :
    Result (DebugStruct × (DebugStruct → DebugStruct) ×
      (DebugStruct → DebugStruct → DebugStruct × DebugStruct)) := do
  let (result, fmt) ← match self.result with
    | .Err e => .ok (.Err e, self.fmt)
    | .Ok () =>
      if self.fmt.options.bit 23 then
        thenFormat (if self.has_fields then .ok (.Ok (), self.fmt) else self.fmt.append " {\n")
          (fun f => f.indented (self.fmt.indent + 4) (fun f =>
            thenFormat (f.write_str name) (fun f =>
              thenFormat (f.append ": ") (fun f =>
                thenFormat (debugValue value f) (fun f => f.append ",\n")))))
      else
        thenFormat (self.fmt.append (if self.has_fields then ", " else " { ")) (fun f =>
          thenFormat (f.write_str name) (fun f =>
            thenFormat (f.append ": ") (debugValue value)))
  .ok ({ fmt, result, has_fields := true }, fun b => b, fun s b => (s, b))

/-- `DebugStruct::finish`: with fields and no error, `"}"` (pretty) or `" }"`; the result, the
    builder given back to `self`, and the backward function of `'a` (the builder is the state of
    `'a`: what is given back through `'a` is given back unchanged). -/
@[rust_fun "core::fmt::builders::{core::fmt::builders::DebugStruct<'a, 'b>}::finish"]
def DebugStruct.finish (self : DebugStruct) :
    Result (core.result.Result Unit Error × DebugStruct × (DebugStruct → DebugStruct)) := do
  if self.has_fields then
    match self.result with
    | .Err e => .ok (.Err e, self, fun b => b)
    | .Ok () =>
      let (result, fmt) ← self.fmt.append (if self.fmt.options.bit 23 then "}" else " }")
      .ok (result, { self with fmt, result }, fun b => b)
  else .ok (self.result, self, fun b => b)

section Monotonicity

open Lean.Order

@[partial_fixpoint_monotone]
theorem thenFormat.monotone {α : Type u} [Lean.Order.PartialOrder α]
    (r : α → Outcome) (k : α → Callback)
    (hr : monotone r) (hk : monotone k) :
    monotone (fun a => thenFormat (r a) (k a)) := by
  unfold thenFormat
  repeat' first | assumption | exact monotone_apply _ _ hk | monotonicity

@[partial_fixpoint_monotone]
theorem Formatter.indented.monotone {α : Type u} [Lean.Order.PartialOrder α]
    (fmt : Formatter) (indent : Nat) (k : α → Callback)
    (hk : monotone k) :
    monotone (fun a => fmt.indented indent (k a)) := by
  unfold Formatter.indented
  repeat' first | assumption | exact monotone_apply _ _ hk | monotonicity

@[partial_fixpoint_monotone]
theorem argumentCount.cons_placeholder_monotone {α : Type u} [Lean.Order.PartialOrder α]
    (callback : α → Callback) (args : α → List rt.Argument) (i : Nat)
    (hargs : ∀ i, monotone (fun a => argumentCount (args a) i)) :
    monotone (fun a => argumentCount (.placeholder (callback a) :: args a) i) := by
  cases i with
  | zero => exact monotone_const _
  | succ i => exact hargs i

@[partial_fixpoint_monotone]
theorem argumentCount.cons_count_monotone {α : Type u} [Lean.Order.PartialOrder α]
    (n : Nat) (args : α → List rt.Argument) (i : Nat)
    (hargs : ∀ i, monotone (fun a => argumentCount (args a) i)) :
    monotone (fun a => argumentCount (.count n :: args a) i) := by
  cases i with
  | zero => exact monotone_const _
  | succ i => exact hargs i

@[partial_fixpoint_monotone]
theorem argumentFormat.cons_placeholder_monotone {α : Type u} [Lean.Order.PartialOrder α]
    (callback : α → Callback) (args : α → List rt.Argument) (i : Nat) (fmt : Formatter)
    (hcallback : monotone callback)
    (hargs : ∀ i fmt, monotone (fun a => argumentFormat (args a) i fmt)) :
    monotone (fun a => argumentFormat (.placeholder (callback a) :: args a) i fmt) := by
  cases i with
  | zero => exact monotone_apply fmt _ hcallback
  | succ i => exact hargs i fmt

@[partial_fixpoint_monotone]
theorem argumentFormat.cons_count_monotone {α : Type u} [Lean.Order.PartialOrder α]
    (n : Nat) (args : α → List rt.Argument) (i : Nat) (fmt : Formatter)
    (hargs : ∀ i fmt, monotone (fun a => argumentFormat (args a) i fmt)) :
    monotone (fun a => argumentFormat (.count n :: args a) i fmt) := by
  cases i with
  | zero => exact monotone_const _
  | succ i => exact hargs i fmt

@[partial_fixpoint_monotone]
theorem renderTemplate.monotone {α : Type u} [Lean.Order.PartialOrder α]
    (fuel : Nat) (bytes : List U8) (args : α → List rt.Argument)
    (next : Nat) (fmt : Formatter)
    (hcount : ∀ i, monotone (fun a => argumentCount (args a) i))
    (hformat : ∀ i fmt, monotone (fun a => argumentFormat (args a) i fmt)) :
    monotone (fun a => renderTemplate fuel bytes (args a) next fmt) := by
  induction fuel generalizing bytes next fmt with
  | zero => exact monotone_const _
  | succ fuel ih =>
    have ihCallback (bytes : List U8) (next : Nat) :
        Lean.Order.monotone (fun a => renderTemplate fuel bytes (args a) next) :=
      fun a b h fmt => ih bytes next fmt a b h
    simp only [renderTemplate]
    repeat' first
      | apply ihCallback
      | apply ih
      | apply hcount
      | apply hformat
      | assumption
      | exact monotone_const _
      | monotonicity

@[partial_fixpoint_monotone]
theorem Formatter.write_fmt.template_monotone {α : Type u} [Lean.Order.PartialOrder α]
    (fmt : Formatter) (bytes : List U8) (args : α → List rt.Argument)
    (hcount : ∀ i, monotone (fun a => argumentCount (args a) i))
    (hformat : ∀ i fmt, monotone (fun a => argumentFormat (args a) i fmt)) :
    monotone (fun a => fmt.write_fmt (.template bytes (args a))) :=
  renderTemplate.monotone _ _ _ _ _ hcount hformat

@[partial_fixpoint_monotone]
theorem debugValue.mk_monotone {α : Type u} [Lean.Order.PartialOrder α]
    {T : Type} (callback : α → T → Callback) (x : T)
    (hfmt : monotone callback) :
    monotone (fun a => debugValue ⟨T, ⟨callback a⟩, x⟩) :=
  monotone_apply x _ hfmt

@[partial_fixpoint_monotone]
theorem DebugShared.fmt.monotone {α : Type u} [Lean.Order.PartialOrder α]
    {T : Type} (callback : α → T → Callback)
    (hfmt : monotone callback) :
    monotone (fun a => DebugShared.fmt ⟨callback a⟩) :=
  hfmt

@[partial_fixpoint_monotone]
theorem DebugShared.fmt.apply_monotone {α : Type u} [Lean.Order.PartialOrder α]
    {T : Type} (callback : α → T → Callback) (x : T)
    (hfmt : Lean.Order.monotone callback) :
    Lean.Order.monotone (fun a => DebugShared.fmt ⟨callback a⟩ x) :=
  monotone_apply x _ hfmt

@[partial_fixpoint_monotone]
theorem DebugShared.fmt.apply_fmt_monotone {α : Type u} [Lean.Order.PartialOrder α]
    {T : Type} (callback : α → T → Callback) (x : T) (fmt : Formatter)
    (hfmt : Lean.Order.monotone callback) :
    Lean.Order.monotone (fun a => DebugShared.fmt ⟨callback a⟩ x fmt) :=
  monotone_apply fmt _ (monotone_apply x _ hfmt)

@[partial_fixpoint_monotone]
theorem Formatter.debug_tuple_field1_finish.monotone {α : Type u} [Lean.Order.PartialOrder α]
    (fmt : Formatter) (name : Str) (v : α → DebugValue)
    (hv : monotone (fun a => debugValue (v a))) :
    monotone (fun a => fmt.debug_tuple_field1_finish name (v a)) := by
  unfold Formatter.debug_tuple_field1_finish Formatter.debugTuple
  simp only [List.isEmpty_cons, List.length_cons, List.length_nil, Bool.false_eq_true,
    ↓reduceIte, debugEntries]
  repeat' first
    | assumption
    | exact monotone_apply _ _ hv
    | exact monotone_const _
    | monotonicity
  all_goals
    intro a b h
    exact Lean.Order.PartialOrder.rel_refl

@[partial_fixpoint_monotone]
theorem Formatter.debug_tuple_field2_finish.monotone {α : Type u} [Lean.Order.PartialOrder α]
    (fmt : Formatter) (name : Str) (v₀ v₁ : α → DebugValue)
    (h₀ : monotone (fun a => debugValue (v₀ a)))
    (h₁ : monotone (fun a => debugValue (v₁ a))) :
    monotone (fun a => fmt.debug_tuple_field2_finish name (v₀ a) (v₁ a)) := by
  unfold Formatter.debug_tuple_field2_finish Formatter.debugTuple
  simp only [List.isEmpty_cons, List.length_cons, List.length_nil, Bool.false_eq_true,
    ↓reduceIte, debugEntries]
  repeat' first
    | assumption
    | exact monotone_apply _ _ h₀
    | exact monotone_apply _ _ h₁
    | exact monotone_const _
    | monotonicity
  all_goals
    intro a b h
    exact Lean.Order.PartialOrder.rel_refl

@[partial_fixpoint_monotone]
theorem Formatter.debug_tuple_field3_finish.monotone {α : Type u} [Lean.Order.PartialOrder α]
    (fmt : Formatter) (name : Str) (v₀ v₁ v₂ : α → DebugValue)
    (h₀ : monotone (fun a => debugValue (v₀ a)))
    (h₁ : monotone (fun a => debugValue (v₁ a)))
    (h₂ : monotone (fun a => debugValue (v₂ a))) :
    monotone (fun a => fmt.debug_tuple_field3_finish name (v₀ a) (v₁ a) (v₂ a)) := by
  unfold Formatter.debug_tuple_field3_finish Formatter.debugTuple
  simp only [List.isEmpty_cons, List.length_cons, List.length_nil, Bool.false_eq_true,
    ↓reduceIte, debugEntries]
  repeat' first
    | assumption
    | exact monotone_apply _ _ h₀
    | exact monotone_apply _ _ h₁
    | exact monotone_apply _ _ h₂
    | exact monotone_const _
    | monotonicity
  all_goals
    intro a b h
    exact Lean.Order.PartialOrder.rel_refl

end Monotonicity

end core.fmt

@[rust_fun "core::result::{core::result::Result<@T, @E>}::unwrap"]
def core.result.Result.unwrap {T E : Type} (_ : core.fmt.Debug E)
    (r : core.result.Result T E) : Std.Result T :=
  match r with
  | .Ok x => .ok x
  | .Err _ => .fail .panic

def core.result.Result.unwrap.mut {T E : Type} (_ : core.fmt.Debug E)
    (r : core.result.Result T E) : Std.Result (T × (T → core.result.Result T E)) :=
  match r with
  | .Ok x => .ok (x, .Ok)
  | .Err _ => .fail .panic

@[rust_fun "core::result::{core::result::Result<@T, @E>}::expect"]
def core.result.Result.expect {T E : Type} (inst : core.fmt.Debug E)
    (r : core.result.Result T E) (_ : Str) : Std.Result T :=
  core.result.Result.unwrap inst r

end Aeneas.Std
