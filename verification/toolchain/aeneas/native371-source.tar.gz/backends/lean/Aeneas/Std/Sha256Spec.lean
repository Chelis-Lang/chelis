/-!
FIPS 180-4 SHA-256 as a kernel-reducible Lean function over byte lists.

This is the model assigned to the native `sha2` hasher used for checked-library
identities. The native crate is trusted to implement this standard function;
the test vectors below are the FIPS 180-4 / NIST examples, checked by the
kernel with `decide`, not by compiled evaluation.
-/

namespace ChelisModels.Sha256

def k : List UInt32 := [
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
  0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
  0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
  0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2]

def h0 : List UInt32 :=
  [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]

def rotr (x : UInt32) (n : UInt32) : UInt32 := (x >>> n) ||| (x <<< (32 - n))

def bigSigma0 (x : UInt32) : UInt32 := rotr x 2 ^^^ rotr x 13 ^^^ rotr x 22
def bigSigma1 (x : UInt32) : UInt32 := rotr x 6 ^^^ rotr x 11 ^^^ rotr x 25
def smallSigma0 (x : UInt32) : UInt32 := rotr x 7 ^^^ rotr x 18 ^^^ (x >>> 3)
def smallSigma1 (x : UInt32) : UInt32 := rotr x 17 ^^^ rotr x 19 ^^^ (x >>> 10)
def ch (x y z : UInt32) : UInt32 := (x &&& y) ^^^ (~~~x &&& z)
def maj (x y z : UInt32) : UInt32 := (x &&& y) ^^^ (x &&& z) ^^^ (y &&& z)

/-- Big-endian word from four bytes. -/
def word (a b c d : UInt8) : UInt32 :=
  (a.toUInt32 <<< 24) ||| (b.toUInt32 <<< 16) ||| (c.toUInt32 <<< 8) ||| d.toUInt32

def words : List UInt8 → List UInt32
  | a :: b :: c :: d :: rest => word a b c d :: words rest
  | _ => []

def wordBytes (w : UInt32) : List UInt8 :=
  [(w >>> 24).toUInt8, (w >>> 16).toUInt8, (w >>> 8).toUInt8, w.toUInt8]

def u64Bytes (n : Nat) : List UInt8 :=
  (List.range 8).reverse.map fun i => (UInt8.ofNat (n / 2 ^ (8 * i)))

/-- Message padding: 0x80, zeros to 56 mod 64, then the 64-bit big-endian bit length. -/
def pad (msg : List UInt8) : List UInt8 :=
  let zeros := (119 - msg.length % 64) % 64
  msg ++ [0x80] ++ List.replicate zeros 0 ++ u64Bytes (8 * msg.length)

/-- The 64-entry message schedule of one block. -/
def schedule (block : List UInt32) : List UInt32 :=
  (List.range 48).foldl (fun w t =>
    let i := t + 16
    w ++ [smallSigma1 (w.getD (i - 2) 0) + w.getD (i - 7) 0 +
          smallSigma0 (w.getD (i - 15) 0) + w.getD (i - 16) 0]) block

def compress (state : List UInt32) (block : List UInt32) : List UInt32 :=
  let w := schedule block
  let init := (state.getD 0 0, state.getD 1 0, state.getD 2 0, state.getD 3 0,
    state.getD 4 0, state.getD 5 0, state.getD 6 0, state.getD 7 0)
  let (a, b, c, d, e, f, g, h) := (List.range 64).foldl (fun (a, b, c, d, e, f, g, h) t =>
    let t1 := h + bigSigma1 e + ch e f g + k.getD t 0 + w.getD t 0
    let t2 := bigSigma0 a + maj a b c
    (t1 + t2, a, b, c, d + t1, e, f, g)) init
  List.zipWith (· + ·) state [a, b, c, d, e, f, g, h]

/-- Split words into 16-word blocks. Structural on the length bound so the
    kernel and `decide` can evaluate it; `ws.length` steps always suffice. -/
def blocksUpTo : Nat → List UInt32 → List (List UInt32)
  | 0, _ => []
  | _ + 1, [] => []
  | n + 1, ws => ws.take 16 :: blocksUpTo n (ws.drop 16)

def blocks (ws : List UInt32) : List (List UInt32) := blocksUpTo ws.length ws

def digest (msg : List UInt8) : List UInt8 :=
  ((blocks (words (pad msg))).foldl compress h0).flatMap wordBytes

/-- NIST FIPS 180-4 example (abc). -/
theorem digest_abc :
    (digest (([97, 98, 99] : List Nat).map UInt8.ofNat)).map UInt8.toNat =
      [186, 120, 22, 191, 143, 1, 207, 234, 65, 65, 64, 222, 93, 174, 34, 35, 176, 3, 97, 163, 150, 23, 122, 156, 180, 16, 255, 97, 242, 0, 21, 173] := by
  decide +kernel

/-- NIST FIPS 180-4 example (empty). -/
theorem digest_empty :
    (digest (([] : List Nat).map UInt8.ofNat)).map UInt8.toNat =
      [227, 176, 196, 66, 152, 252, 28, 20, 154, 251, 244, 200, 153, 111, 185, 36, 39, 174, 65, 228, 100, 155, 147, 76, 164, 149, 153, 27, 120, 82, 184, 85] := by
  decide +kernel

/-- NIST FIPS 180-4 example (two_block). -/
theorem digest_two_block :
    (digest (([97, 98, 99, 100, 98, 99, 100, 101, 99, 100, 101, 102, 100, 101, 102, 103, 101, 102, 103, 104, 102, 103, 104, 105, 103, 104, 105, 106, 104, 105, 106, 107, 105, 106, 107, 108, 106, 107, 108, 109, 107, 108, 109, 110, 108, 109, 110, 111, 109, 110, 111, 112, 110, 111, 112, 113] : List Nat).map UInt8.ofNat)).map UInt8.toNat =
      [36, 141, 106, 97, 210, 6, 56, 184, 229, 192, 38, 147, 12, 62, 96, 57, 163, 60, 228, 89, 100, 255, 33, 103, 246, 236, 237, 212, 25, 219, 6, 193] := by
  decide +kernel

theorem foldl_compress_length (bs : List (List UInt32)) (s : List UInt32) (h : s.length = 8) :
    (bs.foldl compress s).length = 8 := by
  induction bs generalizing s with
  | nil => simpa using h
  | cons b bs ih => exact ih _ (by simp [compress, List.length_zipWith, h])

/-- Every digest has 32 bytes. -/
theorem digest_length (msg : List UInt8) : (digest msg).length = 32 := by
  have h8 := foldl_compress_length (blocks (words (pad msg))) h0 rfl
  unfold digest
  generalize (blocks (words (pad msg))).foldl compress h0 = st at h8
  simp only [List.length_flatMap, wordBytes, List.length_cons, List.length_nil, List.map_const', h8]
  rfl

end ChelisModels.Sha256
