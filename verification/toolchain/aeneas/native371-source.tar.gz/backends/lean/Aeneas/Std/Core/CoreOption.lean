import Aeneas.Std.Core.Core
import Aeneas.Std.Core.Result
import Aeneas.Std.String

namespace Aeneas.Std

@[rust_fun "core::option::unwrap_failed"]
def core.option.unwrap_failed : Result Empty := .fail .panic

/-- `core::option::expect_failed(msg: &str) -> !` (core/src/option.rs), the cold path of
    `Option::expect`: `panic_display(&msg)`. -/
@[rust_fun "core::option::expect_failed"]
def core.option.expect_failed (_ : Str) : Result Never := .fail .panic

@[rust_fun "core::option::{core::clone::Clone<core::option::Option<@T>>}::clone"]
def core.option.Option.Clone.clone {T : Type} (cloneInst : core.clone.Clone T)
    (self : Option T) : Result (Option T) := do
  match self with
  | none => .ok none
  | some value => return some (← cloneInst.clone value)

/-- `Option::clone_from` (core/src/option.rs): `(Some(to), Some(from)) => to.clone_from(from)`,
    otherwise `*to = from.clone()`. -/
@[rust_fun "core::option::{core::clone::Clone<core::option::Option<@T>>}::clone_from"]
def core.option.Option.Clone.clone_from {T : Type} (cloneInst : core.clone.Clone T)
    (self source : Option T) : Result (Option T) := do
  match self, source with
  | some target, some value => return some (← cloneInst.clone_from target value)
  | _, source => core.option.Option.Clone.clone cloneInst source

@[reducible, rust_trait_impl "core::clone::Clone<core::option::Option<@T>>"]
def core.clone.CloneOption {T : Type} (cloneInst : core.clone.Clone T) :
    core.clone.Clone (Option T) := {
  clone := core.option.Option.Clone.clone cloneInst
  clone_from := core.option.Option.Clone.clone_from cloneInst
}

/-- Returns the contained `some` value. The message is ignored: on `none`, this
    fails with `Error.panic`, which is the same behavior as `unwrap`. -/
@[rust_fun "core::option::{core::option::Option<@T>}::expect"]
def core.option.Option.expect {T : Type} (x : Option T) (_msg: Str) : Result T :=
  Result.ofOption x Error.panic

@[simp, step_simps, rust_fun "core::option::{core::option::Option<@T>}::ok_or"]
def core.option.Option.ok_or {T E : Type} (x : Option T) (err : E) :
    Result (core.result.Result T E) :=
  match x with
  | some value => .ok (.Ok value)
  | none => .ok (.Err err)

/-- `Option::get_or_insert` (core/src/option.rs): `self.get_or_insert_with(|| value)`, which
    stores `value` when the option is `None` (the value is dropped otherwise), then lends the
    contained value. The option given back holds the value given back to that borrow. -/
@[rust_fun "core::option::{core::option::Option<@T>}::get_or_insert"]
def core.option.Option.get_or_insert {T : Type} (self : Option T) (value : T) :
    Result (T × (T → Option T)) :=
  .ok (self.getD value, some)

@[rust_fun
  "core::option::{core::cmp::PartialEq<core::option::Option<@T>, core::option::Option<@T>>}::eq"]
def core.option.Option.Insts.CoreCmpPartialEqOption.eq
    {T : Type} (cmpPartialEqInst : core.cmp.PartialEq T T)
    (x y : Option T) : Result Bool :=
  match x, y with
  | none, none => .ok true
  | some x, some y => cmpPartialEqInst.eq x y
  | _, _ => .ok false

attribute [agrind =] Option.isSome_none Option.isSome_some

theorem core.option.Option.expect.spec {T : Type} (x : Option T) (msg: Str) (h : x.isSome) :
  expect x msg ⦃ v => x = some v ⦄ := by
  simp only [expect, Result.ofOption]; grind

end Aeneas.Std
