import Aeneas.Std.Core.Iter

namespace Aeneas.Std

/-! Native `GenericShunt` (core iter/adapters/mod.rs, rustc 1.95), the iterator
    that `iter::try_process` hands to the inner collector of
    `FromIterator<Result<A, E>> for Result<V, E>` and
    `FromIterator<Option<A>> for Option<V>`. `branch` is the item's
    `Try::branch`: `Continue` with its output, or `Break` with its residual. -/
namespace core.iter.adapters.GenericShunt

/-- The shunt's state. The residual belongs to the whole collection, not just
    one call to an iterator method. -/
structure Shunt (I R : Type) where
  iter : I
  residual : Option R

/-- Native `GenericShunt::try_fold` delegates to the underlying override using
    `ControlFlow<R, B>`. A callback break reconstructs `R` immediately; an input
    residual is stored and breaks with `R::from_output(acc)`. -/
def tryFold {I T A Res B F R Residual : Type}
    (branch : T → core.ops.control_flow.ControlFlow Res A)
    (iterInst : core.iter.traits.iterator.Iterator I T)
    (fnInst : core.ops.function.FnMut F (B × A) R)
    (tryInst : core.ops.try_trait.Try R B Residual)
    (self : Shunt I Res) (init : B) (f : F) : Aeneas.Std.Result (R × Shunt I Res × F) := do
  let call := fun (state : F × Option Res) (args : B × T) => do
    match branch args.2 with
    | .Continue item =>
      let (r, f) ← fnInst.call_mut state.1 (args.1, item)
      match ← tryInst.branch r with
      | .Continue acc =>
        return ((.Continue acc : core.ops.control_flow.ControlFlow R B), (f, state.2))
      | .Break residual =>
        let r ← tryInst.FromResidualInst.from_residual residual
        return ((.Break r : core.ops.control_flow.ControlFlow R B), (f, state.2))
    | .Break residual =>
      let r ← tryInst.from_output args.1
      return ((.Break r : core.ops.control_flow.ControlFlow R B), (state.1, some residual))
  let wrapped : core.ops.function.FnMut (F × Option Res) (B × T)
      (core.ops.control_flow.ControlFlow R B) := {
    FnOnceInst := { call_once := call }
    call_mut := call
  }
  let (r, iter, f, residual) ← iterInst.try_fold wrapped
    (core.iter.traits.iterator.controlFlowTry R B) self.iter init (f, self.residual)
  let r ← match r with
    | .Continue acc => tryInst.from_output acc
    | .Break r => .ok r
  return (r, { iter, residual }, f)

/-- `next` is `try_for_each(ControlFlow::Break)`, so even single-item pulls
    preserve an underlying specialized `try_fold`. A stored residual does not
    fuse this wrapper: another call can consume a value or replace the residual. -/
def next {I T A Res : Type}
    (branch : T → core.ops.control_flow.ControlFlow Res A)
    (iterInst : core.iter.traits.iterator.Iterator I T)
    (self : Shunt I Res) : Aeneas.Std.Result (Option A × Shunt I Res) := do
  let call := fun (_ : Unit) (args : Unit × A) =>
    (.ok ((.Break args.2 : core.ops.control_flow.ControlFlow A Unit), ()) :
      Aeneas.Std.Result (core.ops.control_flow.ControlFlow A Unit × Unit))
  let fnInst : core.ops.function.FnMut Unit (Unit × A)
      (core.ops.control_flow.ControlFlow A Unit) := {
    FnOnceInst := { call_once := call }
    call_mut := call
  }
  let (r, self, _) ← tryFold branch iterInst fnInst
    (core.iter.traits.iterator.controlFlowTry A Unit) self () ()
  return (match r with | .Break item => some item | .Continue _ => none, self)

/-- The native fold macro wraps the callback in a non-short-circuiting `Try`
    and invokes the shunt's `try_fold`, rather than the underlying `fold`. -/
def fold {I T A Res B F : Type}
    (branch : T → core.ops.control_flow.ControlFlow Res A)
    (iterInst : core.iter.traits.iterator.Iterator I T)
    (fnInst : core.ops.function.FnMut F (B × A) B)
    (self : Shunt I Res) (init : B) (f : F) : Aeneas.Std.Result (B × Shunt I Res × F) := do
  let call := fun f args => do
    let (acc, f) ← fnInst.call_mut f args
    return ((.Continue acc : core.ops.control_flow.ControlFlow Empty B), f)
  let wrapped : core.ops.function.FnMut F (B × A)
      (core.ops.control_flow.ControlFlow Empty B) := {
    FnOnceInst := { call_once := call }
    call_mut := call
  }
  let (r, self, f) ← tryFold branch iterInst wrapped
    (core.iter.traits.iterator.controlFlowTry Empty B) self init f
  match r with
  | .Continue acc => return (acc, self, f)
  | .Break impossible => nomatch impossible

/-- `(0, Some(0))` once a residual is stored, else `(0, upper)` of the source. -/
def sizeHint {I T Res : Type}
    (iterInst : core.iter.traits.iterator.Iterator I T)
    (self : Shunt I Res) : Aeneas.Std.Result (Usize × Option Usize) := do
  match self.residual with
  | some _ => return (0#usize, some 0#usize)
  | none =>
    let (_, upper) ← iterInst.size_hint self.iter
    return (0#usize, upper)

def iterator {I T A Res : Type}
    (branch : T → core.ops.control_flow.ControlFlow Res A)
    (iterInst : core.iter.traits.iterator.Iterator I T) :
    core.iter.traits.iterator.Iterator (Shunt I Res) A := {
  next := next branch iterInst
  try_fold := tryFold branch iterInst
  fold := fold branch iterInst
  size_hint := sizeHint iterInst
}

/-- `iter::try_process(iter.into_iter(), |i| i.collect())`: run the supplied
    collector directly over the shunt. Its terminal state determines both the
    stored residual and the restored original source. -/
def tryProcess {A T Res V I IntoIter : Type}
    (branch : T → core.ops.control_flow.ControlFlow Res A)
    (FromIteratorInst : core.iter.traits.collect.FromIterator V A)
    (IntoIteratorInst : core.iter.traits.collect.IntoIterator I T IntoIter)
    (input : I) : Aeneas.Std.Result ((V × Option Res) × I) := do
  let (iter, recover) ← IntoIteratorInst.into_iter input
  let (value, shunt) ← FromIteratorInst.from_iter
    (core.iter.traits.collect.IntoIterator.Blanket (iterator branch IntoIteratorInst.iteratorInst))
    { iter, residual := none }
  return ((value, shunt.residual), recover shunt.iter)

end core.iter.adapters.GenericShunt

/-- `Result::branch`: `Ok` continues with its value, `Err` breaks with its
    error (the residual `Result<Infallible, E>`). -/
def core.result.FromIteratorResult.branch {A E : Type} :
    core.result.Result A E → core.ops.control_flow.ControlFlow E A
  | .Ok value => .Continue value
  | .Err err => .Break err

@[rust_fun
  "core::result::{core::iter::traits::collect::FromIterator<core::result::Result<@V, @E>, core::result::Result<@A, @E>>}::from_iter"]
def core.result.FromIteratorResult.from_iter {A E V I IntoIter : Type}
    (FromIteratorInst : core.iter.traits.collect.FromIterator V A)
    (IntoIteratorInst : core.iter.traits.collect.IntoIterator I (core.result.Result A E) IntoIter)
    (input : I) : Aeneas.Std.Result (core.result.Result V E × I) := do
  let ((value, residual), input) ← core.iter.adapters.GenericShunt.tryProcess
    core.result.FromIteratorResult.branch FromIteratorInst IntoIteratorInst input
  let result := match residual with
    | none => core.result.Result.Ok value
    | some err => core.result.Result.Err err
  return (result, input)

@[reducible, rust_trait_impl
  "core::iter::traits::collect::FromIterator<core::result::Result<@V, @E>, core::result::Result<@A, @E>>"]
def core.iter.traits.collect.FromIteratorResult {A : Type} (E : Type) {V : Type}
    (FromIteratorInst : core.iter.traits.collect.FromIterator V A) :
    core.iter.traits.collect.FromIterator (core.result.Result V E) (core.result.Result A E) := {
  from_iter := core.result.FromIteratorResult.from_iter FromIteratorInst
}

/-- `Option::branch`: `Some` continues with its value, `None` breaks with the
    residual `Option<Infallible>` (its only value, `None`: here `()`). -/
def core.option.FromIteratorOption.branch {A : Type} :
    Option A → core.ops.control_flow.ControlFlow Unit A
  | some value => .Continue value
  | none => .Break ()

/-- `impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V>` (core
    option.rs): `iter::try_process(iter.into_iter(), |i| i.collect())`. The inner
    collector stops at the first `None`, which leaves the source just after it,
    and the result is then `None`. -/
@[rust_fun
  "core::option::{core::iter::traits::collect::FromIterator<core::option::Option<@V>, core::option::Option<@A>>}::from_iter"]
def core.option.FromIteratorOption.from_iter {A V I IntoIter : Type}
    (FromIteratorInst : core.iter.traits.collect.FromIterator V A)
    (IntoIteratorInst : core.iter.traits.collect.IntoIterator I (Option A) IntoIter)
    (input : I) : Aeneas.Std.Result (Option V × I) := do
  let ((value, residual), input) ← core.iter.adapters.GenericShunt.tryProcess
    core.option.FromIteratorOption.branch FromIteratorInst IntoIteratorInst input
  return ((match residual with | none => some value | some () => none), input)

@[reducible, rust_trait_impl
  "core::iter::traits::collect::FromIterator<core::option::Option<@V>, core::option::Option<@A>>"]
def core.iter.traits.collect.FromIteratorOption {A V : Type}
    (FromIteratorInst : core.iter.traits.collect.FromIterator V A) :
    core.iter.traits.collect.FromIterator (Option V) (Option A) := {
  from_iter := core.option.FromIteratorOption.from_iter FromIteratorInst
}

end Aeneas.Std
