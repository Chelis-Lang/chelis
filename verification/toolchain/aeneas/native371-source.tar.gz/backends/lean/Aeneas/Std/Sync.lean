import Lean
import Aeneas.Extract
import Aeneas.Std.Primitives
import Aeneas.Std.Core.Core
import Aeneas.Std.Core.Default
import Aeneas.Std.Core.Fmt
import Aeneas.Std.Core.Cmp
import Aeneas.Std.Core.Ops

/-!
Shared-ownership pointers as immutable values.

`Arc<T>` and `Rc<T>` only expose shared access to their payload in the admitted
domain: the extraction rejects `get_mut`, `make_mut`, `try_unwrap`, `ptr_eq`,
reference counts and weak pointers because they have no model here. Without
those operations a program cannot observe sharing, so an `Arc<T>` is modeled
by its payload: construction and cloning copy the value, dereferencing returns
it, and dropping has no effect. Allocation failure and reference-count
overflow abort natively; they are outside the value model like every other
allocation failure.
-/

namespace Aeneas

namespace Std

open Result

@[rust_type "alloc::sync::Arc"]
abbrev alloc.sync.Arc (T : Type) : Type := T

@[rust_type "alloc::rc::Rc"]
abbrev alloc.rc.Rc (T : Type) : Type := T

@[rust_fun "alloc::sync::{alloc::sync::Arc<@T>}::new" -canFail]
def alloc.sync.Arc.new {T : Type} (value : T) : alloc.sync.Arc T := value

@[rust_fun "alloc::rc::{alloc::rc::Rc<@T>}::new" -canFail]
def alloc.rc.Rc.new {T : Type} (value : T) : alloc.rc.Rc T := value

@[rust_fun "alloc::sync::{core::clone::Clone<alloc::sync::Arc<@T>>}::clone"
    (keepParams := [true, false]) (keepTraitClauses := [false])]
def alloc.sync.CloneArc.clone {T : Type} (value : alloc.sync.Arc T) : Result (alloc.sync.Arc T) :=
  ok value

@[reducible, rust_trait_impl "core::clone::Clone<alloc::sync::Arc<@T>>"
    (keepParams := [true, false]) (keepTraitClauses := [false])]
def core.clone.CloneArc (T : Type) : core.clone.Clone (alloc.sync.Arc T) := {
  clone := alloc.sync.CloneArc.clone
}

@[rust_fun "alloc::rc::{core::clone::Clone<alloc::rc::Rc<@T>>}::clone"
    (keepParams := [true, false]) (keepTraitClauses := [false])]
def alloc.rc.CloneRc.clone {T : Type} (value : alloc.rc.Rc T) : Result (alloc.rc.Rc T) :=
  ok value

@[reducible, rust_trait_impl "core::clone::Clone<alloc::rc::Rc<@T>>"
    (keepParams := [true, false]) (keepTraitClauses := [false])]
def core.clone.CloneRc (T : Type) : core.clone.Clone (alloc.rc.Rc T) := {
  clone := alloc.rc.CloneRc.clone
}

@[rust_fun "alloc::sync::{core::ops::deref::Deref<alloc::sync::Arc<@T>, @T>}::deref"
    -canFail (keepParams := [true, false])]
def alloc.sync.DerefArc.deref {T : Type} (value : alloc.sync.Arc T) : T := value

@[reducible, rust_trait_impl "core::ops::deref::Deref<alloc::sync::Arc<@T>, @T>"
    (keepParams := [true, false])]
def core.ops.deref.DerefArc (T : Type) : core.ops.deref.Deref (alloc.sync.Arc T) T := {
  deref := fun value => ok (alloc.sync.DerefArc.deref value)
}

@[rust_fun "alloc::rc::{core::ops::deref::Deref<alloc::rc::Rc<@T>, @T>}::deref"
    -canFail (keepParams := [true, false])]
def alloc.rc.DerefRc.deref {T : Type} (value : alloc.rc.Rc T) : T := value

@[reducible, rust_trait_impl "core::ops::deref::Deref<alloc::rc::Rc<@T>, @T>"
    (keepParams := [true, false])]
def core.ops.deref.DerefRc (T : Type) : core.ops.deref.Deref (alloc.rc.Rc T) T := {
  deref := fun value => ok (alloc.rc.DerefRc.deref value)
}

@[rust_fun "alloc::sync::{core::fmt::Debug<alloc::sync::Arc<@T>>}::fmt"
    (keepParams := [true, false])]
def alloc.sync.DebugArc.fmt {T : Type} (inst : core.fmt.Debug T) (value : alloc.sync.Arc T)
    (formatter : core.fmt.Formatter) : core.fmt.Outcome :=
  inst.fmt value formatter

@[reducible, rust_trait_impl "core::fmt::Debug<alloc::sync::Arc<@T>>"
    (keepParams := [true, false])]
def core.fmt.DebugArc {T : Type} (inst : core.fmt.Debug T) : core.fmt.Debug (alloc.sync.Arc T) :=
  ⟨alloc.sync.DebugArc.fmt inst⟩

/-- `impl AsRef<T> for Arc<T>` (alloc/src/sync.rs): `&**self` (a shared borrow of the value). -/
@[rust_fun "alloc::sync::{core::convert::AsRef<alloc::sync::Arc<@T>, @T>}::as_ref"
    (keepParams := [true, false])]
def alloc.sync.AsRefArc.as_ref {T : Type} (value : alloc.sync.Arc T) : Result T :=
  ok value

/-- `impl Default for Arc<T>` (alloc/src/sync.rs): `Arc::new(T::default())`. -/
@[rust_fun "alloc::sync::{core::default::Default<alloc::sync::Arc<@T>>}::default"]
def alloc.sync.DefaultArc.default {T : Type} (inst : core.default.Default T) :
    Result (alloc.sync.Arc T) :=
  inst.default

@[reducible, rust_trait_impl "core::default::Default<alloc::sync::Arc<@T>>"]
def core.default.DefaultArc {T : Type} (inst : core.default.Default T) :
    core.default.Default (alloc.sync.Arc T) :=
  ⟨alloc.sync.DefaultArc.default inst⟩

@[rust_fun "alloc::rc::{core::default::Default<alloc::rc::Rc<@T>>}::default"
    (keepParams := [true, false])]
def alloc.rc.DefaultRc.default {T : Type} (inst : core.default.Default T) :
    Result (alloc.rc.Rc T) :=
  inst.default

@[reducible, rust_trait_impl "core::default::Default<alloc::rc::Rc<@T>>"
    (keepParams := [true, false])]
def core.default.DefaultRc {T : Type} (inst : core.default.Default T) :
    core.default.Default (alloc.rc.Rc T) :=
  ⟨alloc.rc.DefaultRc.default inst⟩

end Std

end Aeneas
