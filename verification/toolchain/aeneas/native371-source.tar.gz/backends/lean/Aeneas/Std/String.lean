import Aeneas.Std.Scalar.Core
import Aeneas.Std.Slice
import Aeneas.Std.Alloc
import Aeneas.Std.Core.Core
import Aeneas.Std.Core.Cmp
import Aeneas.Std.Core.Default
import Aeneas.Std.Scalar.Notations

namespace Aeneas.Std

def Str := Slice U8

/-- Construct the UTF-8 byte slice. Kernel reduction checks the literal-size proof directly,
avoiding the elaborator's recursive normalization of the UTF-8 encoding of long literals. -/
def toStr (s : String)
    (h : s.toByteArray.size ≤ U32.max := by simp only [U32.max_eq]; decide +kernel) : Str :=
  ⟨s.toByteArray.data.toList.map
    (fun x => ⟨x.toNat, by cases x; simp only [UInt8.toNat_ofBitVec, UScalarTy.U8_numBits_eq, Nat.reducePow]; omega⟩),
    by
      simp only [List.length_map, Array.length_toList, ByteArray.size_data]
      scalar_tac⟩

example : Str := toStr "hello"

/-- A dynamic Rust string view contains UTF-8 bytes, not Unicode scalar values. -/
def Str.ofString (value : String) : Result Str :=
  let bytes := value.toByteArray
  if h : bytes.size ≤ Usize.max then
    .ok ⟨bytes.data.toList.map (fun byte => (⟨byte.toBitVec⟩ : U8)), by
      simpa only [List.length_map, Array.length_toList, ByteArray.size_data] using h⟩
  else .fail .panic

/-- Rust `str` is valid UTF-8. Malformed model inputs are undefined, not lossy text. -/
def Str.toString (value : Str) : Result String :=
  let bytes := value.val.foldl
    (fun bytes byte => bytes.push (UInt8.ofBitVec byte.bv)) ByteArray.empty
  match String.fromUTF8? bytes with
  | some value => .ok value
  | none => .fail .undef

private def stringEqStr (left : String) (right : Str) : Bool :=
  let bytes := left.toByteArray
  let rec go (index : Nat) (remaining : List U8) : Bool :=
    match remaining with
    | [] => index == bytes.size
    | byte :: rest =>
      if h : index < bytes.size then
        if bytes[index]'h == UInt8.ofBitVec byte.bv then go (index + 1) rest else false
      else false
  go 0 right.val

private def compareStrBytes : List U8 → List U8 → Ordering
  | [], [] => .eq
  | [], _ :: _ => .lt
  | _ :: _, [] => .gt
  | x :: xs, y :: ys =>
    match compare x.val y.val with
    | .eq => compareStrBytes xs ys
    | ordering => ordering

@[rust_fun "alloc::string::{core::cmp::PartialEq<alloc::string::String, alloc::string::String>}::eq"]
def alloc.string.PartialEqString.eq (left right : String) : Result Bool :=
  .ok (left == right)

@[rust_fun "alloc::string::{core::cmp::PartialEq<alloc::string::String, alloc::string::String>}::ne"]
def alloc.string.PartialEqString.ne (left right : String) : Result Bool :=
  .ok (left != right)

@[reducible, rust_trait_impl "core::cmp::PartialEq<alloc::string::String, alloc::string::String>"]
def core.cmp.PartialEqString : core.cmp.PartialEq String String := {
  eq := alloc.string.PartialEqString.eq
  ne := alloc.string.PartialEqString.ne
}

@[rust_fun "alloc::string::{core::cmp::PartialEq<alloc::string::String, str>}::eq"]
def alloc.string.PartialEqStringStr.eq (left : String) (right : Str) : Result Bool :=
  .ok (stringEqStr left right)

@[rust_fun "alloc::string::{core::cmp::PartialEq<alloc::string::String, str>}::ne"]
def alloc.string.PartialEqStringStr.ne (left : String) (right : Str) : Result Bool :=
  .ok (!stringEqStr left right)

@[reducible, rust_trait_impl "core::cmp::PartialEq<alloc::string::String, str>"]
def core.cmp.PartialEqStringStr : core.cmp.PartialEq String Str := {
  eq := alloc.string.PartialEqStringStr.eq
  ne := alloc.string.PartialEqStringStr.ne
}

/-- `impl PartialEq<&'a str> for String` (alloc/src/string.rs `impl_eq!`):
    compares with the referenced `str`. -/
@[rust_fun "alloc::string::{core::cmp::PartialEq<alloc::string::String, &'a str>}::eq"]
def alloc.string.PartialEqStringSharedStr.eq (left : String) (right : Str) : Result Bool :=
  .ok (stringEqStr left right)

@[rust_fun "alloc::string::{core::cmp::PartialEq<alloc::string::String, &'a str>}::ne"]
def alloc.string.PartialEqStringSharedStr.ne (left : String) (right : Str) : Result Bool :=
  .ok (!stringEqStr left right)

@[reducible, rust_trait_impl "core::cmp::PartialEq<alloc::string::String, &'a str>"]
def core.cmp.PartialEqStringSharedStr : core.cmp.PartialEq String Str := {
  eq := alloc.string.PartialEqStringSharedStr.eq
  ne := alloc.string.PartialEqStringSharedStr.ne
}

/-- `impl PartialEq<String> for &'a str` (alloc/src/string.rs `impl_eq!`): the bytes of the
    `str` against those of the `String`. -/
@[rust_fun "alloc::string::{core::cmp::PartialEq<&'a str, alloc::string::String>}::eq"]
def alloc.string.PartialEqSharedStrString.eq (left : Str) (right : String) : Result Bool :=
  .ok (stringEqStr right left)

@[rust_fun "alloc::string::{core::cmp::PartialEq<&'a str, alloc::string::String>}::ne"]
def alloc.string.PartialEqSharedStrString.ne (left : Str) (right : String) : Result Bool :=
  .ok (!stringEqStr right left)

@[reducible, rust_trait_impl "core::cmp::PartialEq<&'a str, alloc::string::String>"]
def core.cmp.PartialEqSharedStrString : core.cmp.PartialEq Str String := {
  eq := alloc.string.PartialEqSharedStrString.eq
  ne := alloc.string.PartialEqSharedStrString.ne
}

/-- `str::to_ascii_lowercase` (alloc/src/str.rs): `self.to_owned()` with
    `make_ascii_lowercase`, which maps the bytes `A..=Z` to `a..=z` and keeps
    every other byte (so non-ASCII UTF-8 sequences are unchanged). -/
@[rust_fun "alloc::str::{str}::to_ascii_lowercase"]
def alloc.str.Str.to_ascii_lowercase (s : Str) : Result String :=
  Str.toString ⟨s.val.map (fun byte =>
    if 0x41 ≤ byte.val ∧ byte.val ≤ 0x5A then ⟨byte.bv + 32⟩ else byte), by
    simpa only [List.length_map] using s.property⟩

@[rust_fun "core::str::traits::{core::cmp::PartialEq<str, str>}::eq"]
def core.str.traits.PartialEqStr.eq (left right : Str) : Result Bool :=
  .ok (left.val == right.val)

@[rust_fun "core::str::traits::{core::cmp::PartialEq<str, str>}::ne"]
def core.str.traits.PartialEqStr.ne (left right : Str) : Result Bool :=
  .ok (left.val != right.val)

@[reducible, rust_trait_impl "core::cmp::PartialEq<str, str>"]
def core.cmp.PartialEqStr : core.cmp.PartialEq Str Str := {
  eq := core.str.traits.PartialEqStr.eq
  ne := core.str.traits.PartialEqStr.ne
}

@[rust_fun "alloc::string::{core::cmp::Eq<alloc::string::String>}::assert_receiver_is_total_eq"]
def alloc.string.EqString.assert_receiver_is_total_eq (_ : String) : Result Unit := .ok ()

@[reducible, rust_trait_impl "core::cmp::Eq<alloc::string::String>"]
def core.cmp.EqString : core.cmp.Eq String := {
  partialEqInst := core.cmp.PartialEqString
  assert_receiver_is_total_eq := alloc.string.EqString.assert_receiver_is_total_eq
}

@[rust_fun "core::str::traits::{core::cmp::Eq<str>}::assert_receiver_is_total_eq"]
def core.str.traits.EqStr.assert_receiver_is_total_eq (_ : Str) : Result Unit := .ok ()

@[reducible, rust_trait_impl "core::cmp::Eq<str>"]
def core.cmp.EqStr : core.cmp.Eq Str := {
  partialEqInst := core.cmp.PartialEqStr
  assert_receiver_is_total_eq := core.str.traits.EqStr.assert_receiver_is_total_eq
}

@[rust_fun "alloc::string::{core::cmp::Ord<alloc::string::String>}::cmp"]
def alloc.string.OrdString.cmp (left right : String) : Result Ordering :=
  .ok (compare left right)

@[rust_fun "alloc::string::{core::cmp::PartialOrd<alloc::string::String, alloc::string::String>}::partial_cmp"]
def alloc.string.PartialOrdString.partial_cmp (left right : String) : Result (Option Ordering) :=
  .ok (some (compare left right))

@[reducible, rust_trait_impl "core::cmp::PartialOrd<alloc::string::String, alloc::string::String>"]
def core.cmp.PartialOrdString : core.cmp.PartialOrd String String := {
  partialEqInst := core.cmp.PartialEqString
  partial_cmp := alloc.string.PartialOrdString.partial_cmp
}

@[reducible, rust_trait_impl "core::cmp::Ord<alloc::string::String>"]
def core.cmp.OrdString : core.cmp.Ord String := {
  eqInst := core.cmp.EqString
  partialOrdInst := core.cmp.PartialOrdString
  cmp := alloc.string.OrdString.cmp
}

@[rust_fun "core::str::traits::{core::cmp::Ord<str>}::cmp"]
def core.str.traits.OrdStr.cmp (left right : Str) : Result Ordering :=
  .ok (compareStrBytes left.val right.val)

@[rust_fun "core::str::traits::{core::cmp::PartialOrd<str, str>}::partial_cmp"]
def core.str.traits.PartialOrdStr.partial_cmp (left right : Str) : Result (Option Ordering) :=
  .ok (some (compareStrBytes left.val right.val))

@[reducible, rust_trait_impl "core::cmp::PartialOrd<str, str>"]
def core.cmp.PartialOrdStr : core.cmp.PartialOrd Str Str := {
  partialEqInst := core.cmp.PartialEqStr
  partial_cmp := core.str.traits.PartialOrdStr.partial_cmp
}

@[reducible, rust_trait_impl "core::cmp::Ord<str>"]
def core.cmp.OrdStr : core.cmp.Ord Str := {
  eqInst := core.cmp.EqStr
  partialOrdInst := core.cmp.PartialOrdStr
  cmp := core.str.traits.OrdStr.cmp
}

@[rust_fun "alloc::string::{core::clone::Clone<alloc::string::String>}::clone"]
def alloc.string.CloneString.clone (value : String) : Result String := .ok value

@[reducible, rust_trait_impl "core::clone::Clone<alloc::string::String>"]
def core.clone.CloneString : core.clone.Clone String := {
  clone := alloc.string.CloneString.clone
}

/-- `impl Clone for Box<str>` (alloc/src/boxed.rs): a new allocation with the
    same bytes; `Box` is erased, so the model is the identity on `Str`. -/
@[rust_fun "alloc::boxed::{core::clone::Clone<Box<str>>}::clone"]
def alloc.boxed.CloneBoxStr.clone (value : Str) : Result Str := .ok value

@[reducible, rust_trait_impl "core::clone::Clone<Box<str>>"]
def core.clone.CloneBoxStr : core.clone.Clone Str := {
  clone := alloc.boxed.CloneBoxStr.clone
}

@[rust_fun "alloc::string::{core::ops::deref::Deref<alloc::string::String, str>}::deref"]
def alloc.string.DerefString.deref (value : String) : Result Str := Str.ofString value

@[rust_fun "alloc::string::{alloc::string::String}::as_str"]
def alloc.string.String.as_str (value : String) : Result Str := Str.ofString value

/-- `String::as_bytes` (alloc/src/string.rs): `self.vec.as_slice()`, the UTF-8 bytes. -/
@[rust_fun "alloc::string::{alloc::string::String}::as_bytes"]
def alloc.string.String.as_bytes (value : String) : Result (Slice U8) := Str.ofString value

@[rust_fun "alloc::string::{alloc::string::String}::is_empty"]
def alloc.string.String.is_empty (value : String) : Result Bool := .ok value.isEmpty

@[rust_fun "core::str::{str}::is_empty"]
def core.str.Str.is_empty (value : Str) : Result Bool := .ok value.val.isEmpty

/-- `str::len` (core/src/str/mod.rs): `self.as_bytes().len()`, the length in
    UTF-8 bytes. -/
@[rust_fun "core::str::{str}::len"]
def core.str.Str.len (value : Str) : Result Usize := .ok (Slice.len value)

/-- `core::str::pattern::StrSearcher<'a, 'b>`, the searcher of a `&str` needle.
    Only its construction data are modeled; its search steps are not, so an
    extracted call to them is an unknown external. -/
@[rust_type "core::str::pattern::StrSearcher" (body := .opaque)]
structure core.str.pattern.StrSearcher where
  haystack : Str
  needle : Str

/-- The byte ranges `(a, b)` that successive `next_match` calls of the forward
    `StrSearcher` of a nonempty needle return (core str/pattern.rs, rustc 1.95):
    the leftmost occurrence of the needle's bytes at or after the search
    position, which then resumes at the end of that match (`TwoWaySearcher`
    reports non-overlapping matches). `rest` is the haystack from byte `pos`
    on, and `skip` counts the bytes of the last match still to pass. -/
def core.str.pattern.StrSearcher.needleMatches (needle : List U8) :
    (rest : List U8) → (pos skip : Nat) → List (Nat × Nat)
  | [], _, _ => []
  | _ :: tail, pos, skip + 1 =>
    core.str.pattern.StrSearcher.needleMatches needle tail (pos + 1) skip
  | rest@(_ :: tail), pos, 0 =>
    if needle.isPrefixOf rest then
      (pos, pos + needle.length) ::
        core.str.pattern.StrSearcher.needleMatches needle tail (pos + 1) (needle.length - 1)
    else core.str.pattern.StrSearcher.needleMatches needle tail (pos + 1) 0

/-- The successive `next_match` results of `StrSearcher::new(haystack, needle)`
    (core str/pattern.rs, rustc 1.95). An empty needle uses `EmptyNeedle`, which
    alternates a match at the current position with a reject of the next char
    (`haystack[pos..].chars().next()`, advancing by its `len_utf8`) until the end:
    an empty match at every char boundary, both ends included. A nonempty needle
    uses the two-way searcher: the leftmost non-overlapping occurrences of its
    bytes. The haystack is a `&str`, valid UTF-8; the model validates it once,
    so a malformed model haystack is undefined, as `Str.toString` states. -/
def core.str.pattern.StrSearcher.forwardMatches (haystack needle : Str) :
    Result (List (Nat × Nat)) := do
  let text ← Str.toString haystack
  if needle.val.isEmpty then
    .ok ((text.toList.scanl (fun pos char => pos + char.utf8Size) 0).map fun pos => (pos, pos))
  else .ok (core.str.pattern.StrSearcher.needleMatches needle.val haystack.val 0 0)

/-- The successive `next_match_back` results of `StrSearcher::new(haystack,
    needle)` as a `ReverseSearcher` (core str/pattern.rs, rustc 1.95). An empty
    needle's `EmptyNeedle::next_back` alternates a match at the current end with
    a reject of the char before it, from the end: an empty match at every char
    boundary, from the last to the first. A nonempty needle's two-way
    `next_back` finds the rightmost occurrence ending at or before the search
    end, which then resumes at the start of that match: the rightmost
    non-overlapping occurrences, i.e. the leftmost non-overlapping occurrences
    of the reversed needle in the reversed haystack, mirrored. -/
def core.str.pattern.StrSearcher.reverseMatches (haystack needle : Str) :
    Result (List (Nat × Nat)) := do
  let text ← Str.toString haystack
  if needle.val.isEmpty then
    .ok ((text.toList.scanl (fun pos char => pos + char.utf8Size) 0).reverse.map fun pos => (pos, pos))
  else
    let length := haystack.val.length
    .ok ((core.str.pattern.StrSearcher.needleMatches needle.val.reverse haystack.val.reverse 0 0).map
      fun (start, stop) => (length - stop, length - start))

/-- `core::str::pattern::CharSearcher<'a>`, the searcher of a `char` needle.
    As for `StrSearcher`, only its construction data are modeled. -/
@[rust_type "core::str::pattern::CharSearcher" (body := .opaque)]
structure core.str.pattern.CharSearcher where
  haystack : Str
  needle : Char

/-- The successive `next_match` results of the `CharSearcher` of `needle` (core
    str/pattern.rs, rustc 1.95): each occurrence of the needle's UTF-8 encoding
    (found with `memchr` on one of its bytes, then compared), from the first. In
    a valid UTF-8 haystack an occurrence of a char's encoding starts at a char
    boundary: these are the byte ranges of the chars equal to the needle.
    `next_match_back` (`memrchr` on its last byte) returns the same ranges from
    the last. -/
def core.str.pattern.CharSearcher.forwardMatches (haystack : Str) (needle : Char) :
    Result (List (Nat × Nat)) := do
  let chars := (← Str.toString haystack).toList
  let starts := chars.scanl (fun pos char => pos + char.utf8Size) 0
  .ok ((chars.zip starts).filterMap fun (char, pos) =>
    if char = needle then some (pos, pos + char.utf8Size) else none)

/-- `core::str::pattern::Pattern`, through its provided `is_prefix_of`
    (the only method `str::starts_with` uses) and, as evidence, the matches of
    its forward and reverse searchers. -/
@[rust_trait "core::str::pattern::Pattern"
  (auxiliaryFields := ["forward_matches", "reverse_matches"])]
structure core.str.pattern.Pattern (Self : Type) where
  is_prefix_of : Self → Str → Result Bool
  /-- `forward_matches pat haystack` lists the successive `next_match` results
      of `pat.into_searcher(haystack)`: how every forward pattern consumer
      (`str::split`, ...) searches. `none` denotes a model dictionary without
      that evidence, never a Rust instance: every `Pattern` instance below
      supplies the exact matches of its searcher. -/
  forward_matches : Option (Self → Str → Result (List (Nat × Nat))) := none
  /-- `reverse_matches pat haystack` lists the successive `next_match_back`
      results of `pat.into_searcher(haystack)` when it is a `ReverseSearcher`:
      how every reverse pattern consumer (`str::rsplit_once`, ...) searches.
      `none` as for `forward_matches`. -/
  reverse_matches : Option (Self → Str → Result (List (Nat × Nat))) := none

/-- `core::str::pattern::Searcher<'a>`, through `haystack`. Its search steps
    (`next`, `next_match`, ...) are not modeled, so an extracted call to them
    is an unknown method: the pattern consumers read the searcher's matches
    from `Pattern.forward_matches` and `Pattern.reverse_matches`. -/
@[rust_trait "core::str::pattern::Searcher"]
structure core.str.pattern.Searcher (Self : Type) where
  haystack : Self → Result Str

/-- `core::str::pattern::ReverseSearcher<'a>: Searcher<'a>`, through its
    parent only (its steps `next_back`, ... are not modeled, as for
    `Searcher`). -/
@[rust_trait "core::str::pattern::ReverseSearcher" (parentClauses := ["searcherInst"])]
structure core.str.pattern.ReverseSearcher (Self : Type) where
  searcherInst : core.str.pattern.Searcher Self

/-- `impl Searcher for StrSearcher`, pattern.rs: `haystack` returns `self.haystack`. -/
@[rust_fun
  "core::str::pattern::{core::str::pattern::Searcher<'a, core::str::pattern::StrSearcher<'a, 'b>>}::haystack"]
def core.str.pattern.SearcherStrSearcher.haystack (self : core.str.pattern.StrSearcher) :
    Result Str :=
  .ok self.haystack

@[reducible, rust_trait_impl
  "core::str::pattern::Searcher<'a, core::str::pattern::StrSearcher<'a, 'b>>"]
def core.str.pattern.SearcherStrSearcher : core.str.pattern.Searcher core.str.pattern.StrSearcher := {
  haystack := core.str.pattern.SearcherStrSearcher.haystack
}

@[reducible, rust_trait_impl
  "core::str::pattern::ReverseSearcher<'a, core::str::pattern::StrSearcher<'a, 'b>>"]
def core.str.pattern.ReverseSearcherStrSearcher :
    core.str.pattern.ReverseSearcher core.str.pattern.StrSearcher := {
  searcherInst := core.str.pattern.SearcherStrSearcher
}

/-- `impl Searcher for CharSearcher`, pattern.rs: `haystack` returns `self.haystack`. -/
@[rust_fun
  "core::str::pattern::{core::str::pattern::Searcher<'a, core::str::pattern::CharSearcher<'a>>}::haystack"]
def core.str.pattern.SearcherCharSearcher.haystack (self : core.str.pattern.CharSearcher) :
    Result Str :=
  .ok self.haystack

@[reducible, rust_trait_impl
  "core::str::pattern::Searcher<'a, core::str::pattern::CharSearcher<'a>>"]
def core.str.pattern.SearcherCharSearcher : core.str.pattern.Searcher core.str.pattern.CharSearcher := {
  haystack := core.str.pattern.SearcherCharSearcher.haystack
}

@[reducible, rust_trait_impl
  "core::str::pattern::ReverseSearcher<'a, core::str::pattern::CharSearcher<'a>>"]
def core.str.pattern.ReverseSearcherCharSearcher :
    core.str.pattern.ReverseSearcher core.str.pattern.CharSearcher := {
  searcherInst := core.str.pattern.SearcherCharSearcher
}

/-- `impl Pattern for &str`, pattern.rs: `haystack.as_bytes().starts_with(self.as_bytes())`,
    a prefix test on the UTF-8 bytes; its searcher is `StrSearcher`. -/
@[rust_fun "core::str::pattern::{core::str::pattern::Pattern<&'b str>}::is_prefix_of"]
def core.str.pattern.PatternSharedStr.is_prefix_of (needle haystack : Str) : Result Bool :=
  .ok (needle.val.isPrefixOf haystack.val)

@[reducible, rust_trait_impl "core::str::pattern::Pattern<&'b str>"]
def core.str.pattern.PatternSharedStr : core.str.pattern.Pattern Str := {
  is_prefix_of := core.str.pattern.PatternSharedStr.is_prefix_of
  forward_matches := some fun needle haystack =>
    core.str.pattern.StrSearcher.forwardMatches haystack needle
  reverse_matches := some fun needle haystack =>
    core.str.pattern.StrSearcher.reverseMatches haystack needle
}

/-- `impl Pattern for char`, pattern.rs: `self.encode_utf8(&mut [0u8; 4])
    .is_prefix_of(haystack)`, a prefix test of the char's UTF-8 bytes; its
    searcher is `CharSearcher`. -/
@[rust_fun "core::str::pattern::{core::str::pattern::Pattern<char>}::is_prefix_of"]
def core.str.pattern.PatternChar.is_prefix_of (needle : Char) (haystack : Str) : Result Bool := do
  let encoded ← Str.ofString (String.singleton needle)
  .ok (encoded.val.isPrefixOf haystack.val)

@[reducible, rust_trait_impl "core::str::pattern::Pattern<char>"]
def core.str.pattern.PatternChar : core.str.pattern.Pattern Char := {
  is_prefix_of := core.str.pattern.PatternChar.is_prefix_of
  forward_matches := some fun needle haystack =>
    core.str.pattern.CharSearcher.forwardMatches haystack needle
  reverse_matches := some fun needle haystack => do
    .ok (← core.str.pattern.CharSearcher.forwardMatches haystack needle).reverse
}

/-- `str::starts_with`, str/mod.rs: `pat.is_prefix_of(self)`. -/
@[rust_fun "core::str::{str}::starts_with"]
def core.str.Str.starts_with {P : Type} (patInst : core.str.pattern.Pattern P)
    (s : Str) (pat : P) : Result Bool :=
  patInst.is_prefix_of pat s

/-- The `&str` pattern is a byte-prefix test on UTF-8 bytes. -/
theorem core.str.Str.starts_with_str (s pat : Str) :
    core.str.Str.starts_with core.str.pattern.PatternSharedStr s pat = .ok true ↔
      pat.val <+: s.val := by
  simp [core.str.Str.starts_with, core.str.pattern.PatternSharedStr.is_prefix_of,
    List.isPrefixOf_iff_prefix]

/-- `str::contains`, str/mod.rs: `pat.is_contained_in(self)`. `Pattern`'s
    `is_contained_in` is `self.into_searcher(haystack).next_match().is_some()`; the
    overrides of `char` (a byte `memchr` below 128, else the `&str` of its UTF-8
    encoding) and `&str` (true for an empty needle, a byte test for a one-byte
    needle, `self == haystack` when not shorter than the haystack, else the
    searcher) decide the same: whether the searcher has a first match. A model
    dictionary without searcher evidence fails, as for `str::split`. -/
@[rust_fun "core::str::{str}::contains"]
def core.str.Str.contains {P : Type} (patInst : core.str.pattern.Pattern P)
    (s : Str) (pat : P) : Result Bool :=
  match patInst.forward_matches with
  | none => .fail .panic
  | some search => do .ok !(← search pat s).isEmpty

/-- `String::len` (string.rs): `self.vec.len()`, the length in UTF-8 bytes. -/
@[rust_fun "alloc::string::{alloc::string::String}::len"]
def alloc.string.String.len (value : String) : Result Usize := do
  .ok (Slice.len (← Str.ofString value))

/-- `String::new` (string.rs): `String { vec: Vec::new() }`, the empty string. -/
@[rust_fun "alloc::string::{alloc::string::String}::new"]
def alloc.string.String.new : Result String := .ok ""

/-- `Default for String` (string.rs): `String::new()`. -/
@[rust_fun "alloc::string::{core::default::Default<alloc::string::String>}::default"]
def alloc.string.DefaultString.default : Result String := .ok ""

@[reducible, rust_trait_impl "core::default::Default<alloc::string::String>"]
def core.default.DefaultString : core.default.Default String := {
  default := alloc.string.DefaultString.default
}

/-- `String::pop` (string.rs): `let ch = self.chars().rev().next()?`, then the byte
    vector is shortened by `ch.len_utf8()`: the last char, removed; `None` (and the
    string unchanged) when it is empty. -/
@[rust_fun "alloc::string::{alloc::string::String}::pop"]
def alloc.string.String.pop (value : String) : Result (Option Char × String) :=
  match value.toList.getLast? with
  | none => .ok (none, value)
  | some ch => .ok (some ch, String.ofList value.toList.dropLast)

/-- `char::len_utf8` (core/src/char/methods.rs, rustc 1.95): the length of the UTF-8
    encoding, 1 below `0x80`, 2 below `0x800`, 3 below `0x10000`, else 4. -/
@[rust_fun "core::char::methods::{char}::len_utf8"]
def core.char.methods.Char.len_utf8 (c : Char) : Result Usize :=
  .ok (if c.val < 0x80 then 1#usize else if c.val < 0x800 then 2#usize
    else if c.val < 0x10000 then 3#usize else 4#usize)

/-- `char::is_ascii_digit` (core/src/char/methods.rs): `matches!(*self, '0'..='9')`. -/
@[rust_fun "core::char::methods::{char}::is_ascii_digit"]
def core.char.methods.Char.is_ascii_digit (c : Char) : Result Bool :=
  .ok ('0' ≤ c && c ≤ '9')

/-- `char::is_ascii_alphanumeric` (core/src/char/methods.rs): `'0'..='9'`, `'A'..='Z'` or
    `'a'..='z'`. -/
@[rust_fun "core::char::methods::{char}::is_ascii_alphanumeric"]
def core.char.methods.Char.is_ascii_alphanumeric (c : Char) : Result Bool :=
  .ok (('0' ≤ c && c ≤ '9') || ('A' ≤ c && c ≤ 'Z') || ('a' ≤ c && c ≤ 'z'))

/-- `char::is_ascii_uppercase`: `matches!(*self, 'A'..='Z')`. -/
@[rust_fun "core::char::methods::{char}::is_ascii_uppercase"]
def core.char.methods.Char.is_ascii_uppercase (c : Char) : Result Bool :=
  .ok ('A' ≤ c && c ≤ 'Z')

/-- `char::is_ascii_lowercase`: `matches!(*self, 'a'..='z')`. -/
@[rust_fun "core::char::methods::{char}::is_ascii_lowercase"]
def core.char.methods.Char.is_ascii_lowercase (c : Char) : Result Bool :=
  .ok ('a' ≤ c && c ≤ 'z')

/-- `char::to_ascii_lowercase`: `'A'..='Z'` mapped to `'a'..='z'` (`self ^ 0x20` on the
    ASCII uppercase letters), every other char unchanged. -/
@[rust_fun "core::char::methods::{char}::to_ascii_lowercase"]
def core.char.methods.Char.to_ascii_lowercase (c : Char) : Result Char :=
  .ok (if 'A' ≤ c && c ≤ 'Z' then Char.ofNat (c.toNat + 32) else c)

/-- `char::to_ascii_uppercase`: `'a'..='z'` mapped to `'A'..='Z'`, every other char
    unchanged. -/
@[rust_fun "core::char::methods::{char}::to_ascii_uppercase"]
def core.char.methods.Char.to_ascii_uppercase (c : Char) : Result Char :=
  .ok (if 'a' ≤ c && c ≤ 'z' then Char.ofNat (c.toNat - 32) else c)

/-- `u8::is_ascii_digit` (core/src/num/mod.rs): `matches!(*self, b'0'..=b'9')`. -/
@[rust_fun "core::num::{u8}::is_ascii_digit"]
def core.num.U8.is_ascii_digit (b : U8) : Result Bool :=
  .ok (48 ≤ b.val && b.val ≤ 57)

/-- `u8::is_ascii_hexdigit` (core/src/num/mod.rs): `b'0'..=b'9'`, `b'A'..=b'F'` or `b'a'..=b'f'`. -/
@[rust_fun "core::num::{u8}::is_ascii_hexdigit"]
def core.num.U8.is_ascii_hexdigit (b : U8) : Result Bool :=
  .ok ((48 ≤ b.val && b.val ≤ 57) || (65 ≤ b.val && b.val ≤ 70) || (97 ≤ b.val && b.val ≤ 102))

/-- `u8::is_ascii_whitespace` (core/src/num/mod.rs): `b'\t'`, `b'\n'`, `b'\x0C'`, `b'\r'` or
    `b' '` (not `b'\x0B'`). -/
@[rust_fun "core::num::{u8}::is_ascii_whitespace"]
def core.num.U8.is_ascii_whitespace (b : U8) : Result Bool :=
  .ok (b.val = 9 || b.val = 10 || b.val = 12 || b.val = 13 || b.val = 32)

/-- `u8::is_ascii_alphabetic` (core/src/num/mod.rs): `b'A'..=b'Z'` or `b'a'..=b'z'`. -/
@[rust_fun "core::num::{u8}::is_ascii_alphabetic"]
def core.num.U8.is_ascii_alphabetic (b : U8) : Result Bool :=
  .ok ((65 ≤ b.val && b.val ≤ 90) || (97 ≤ b.val && b.val ≤ 122))

/-- `u8::is_ascii_alphanumeric` (core/src/num/mod.rs): `b'0'..=b'9'`, `b'A'..=b'Z'` or
    `b'a'..=b'z'`. -/
@[rust_fun "core::num::{u8}::is_ascii_alphanumeric"]
def core.num.U8.is_ascii_alphanumeric (b : U8) : Result Bool :=
  .ok ((48 ≤ b.val && b.val ≤ 57) || (65 ≤ b.val && b.val ≤ 90) || (97 ≤ b.val && b.val ≤ 122))

/-- `String::with_capacity` (string.rs): `String { vec: Vec::with_capacity(capacity) }`,
    an empty string. The capacity is not part of the model, except that `RawVec` panics
    with "capacity overflow" when it exceeds `isize::MAX` bytes; allocation failure
    below that bound is outside the model, as for `Vec`. -/
@[rust_fun "alloc::string::{alloc::string::String}::with_capacity"]
def alloc.string.String.with_capacity (capacity : Usize) : Result String :=
  if (capacity.val : Int) ≤ Isize.max then .ok "" else .fail .panic

/-- `String::push` (string.rs): `self.reserve(ch.len_utf8())`, then the UTF-8 encoding
    of `ch` is written after the last byte. Reserving past `isize::MAX` bytes (capacity
    overflow) and allocation failure are outside the model, as for `Vec`. -/
@[rust_fun "alloc::string::{alloc::string::String}::push"]
def alloc.string.String.push (value : String) (ch : Char) : Result String :=
  .ok (value.push ch)

/-- `String::push_str` (string.rs): `self.vec.extend_from_slice(string.as_bytes())`,
    the bytes of `string` appended (the bounds as for `push`). -/
@[rust_fun "alloc::string::{alloc::string::String}::push_str"]
def alloc.string.String.push_str (value : String) (string : Str) : Result String := do
  .ok (value ++ (← Str.toString string))

/-- `str::repeat` (alloc/src/str.rs): `String::from_utf8_unchecked(self.as_bytes().repeat(n))`.
    `<[T]>::repeat` (alloc/src/slice.rs) returns an empty vector for `n = 0`; otherwise
    `self.len().checked_mul(n).expect("capacity overflow")` then `Vec::with_capacity`, so it
    panics exactly when `len * n` exceeds `isize::MAX` bytes (above `usize::MAX` the
    multiplication overflows). Allocation failure below that bound is outside the model. -/
@[rust_fun "alloc::str::{str}::repeat"]
def alloc.str.Str.repeat (s : Str) (n : Usize) : Result String := do
  if (s.length * n.val : Int) ≤ Isize.max then
    if s.val.isEmpty then .ok ""
    else
      let text ← Str.toString s
      .ok (String.join (List.replicate n.val text))
  else .fail .panic

@[rust_fun "alloc::string::{core::convert::From<alloc::string::String, &'a str>}::from"]
def alloc.string.FromStrString.from_ (value : Str) : Result String := Str.toString value

@[reducible, rust_trait_impl "core::convert::From<alloc::string::String, &'a str>"]
def core.convert.FromStrString : core.convert.From String Str := {
  from_ := alloc.string.FromStrString.from_
}

@[rust_fun "alloc::str::{alloc::borrow::ToOwned<str, alloc::string::String>}::to_owned"]
def alloc.str.ToOwnedStr.to_owned (value : Str) : Result String := Str.toString value

@[rust_fun "alloc::string::{core::convert::From<Box<str>, alloc::string::String>}::from"]
def alloc.string.FromStringBoxStr.from_ (value : String) : Result Str := Str.ofString value

@[reducible, rust_trait_impl "core::convert::From<Box<str>, alloc::string::String>"]
def core.convert.FromStringBoxStr : core.convert.From Str String := {
  from_ := alloc.string.FromStringBoxStr.from_
}

/-- `impl From<&String> for String` (alloc/src/string.rs): `s.clone()`. -/
@[rust_fun "alloc::string::{core::convert::From<alloc::string::String, &'0 alloc::string::String>}::from"]
def alloc.string.FromSharedStringString.from_ (value : String) : Result String := .ok value

@[reducible, rust_trait_impl "core::convert::From<alloc::string::String, &'0 alloc::string::String>"]
def core.convert.FromSharedStringString : core.convert.From String String := {
  from_ := alloc.string.FromSharedStringString.from_
}

/-- `impl From<&str> for Box<str>` (alloc/src/boxed/convert.rs): a boxed copy of the bytes. -/
@[rust_fun "alloc::boxed::convert::{core::convert::From<Box<str>, &'0 str>}::from"]
def alloc.boxed.convert.FromSharedStrBoxStr.from_ (value : Str) : Result Str := .ok value

@[reducible, rust_trait_impl "core::convert::From<Box<str>, &'0 str>"]
def core.convert.FromSharedStrBoxStr : core.convert.From Str Str := {
  from_ := alloc.boxed.convert.FromSharedStrBoxStr.from_
}

end Aeneas.Std
