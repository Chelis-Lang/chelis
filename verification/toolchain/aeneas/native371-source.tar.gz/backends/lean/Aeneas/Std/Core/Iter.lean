import Aeneas.Std.Core.Cmp
import Aeneas.Std.Primitives
import Aeneas.Std.Range
import Aeneas.Std.Scalar.Core
import Aeneas.Std.Scalar.Notations
import Aeneas.Std.Scalar.CloneCopy
import Aeneas.Std.Scalar.EqOrd
import Aeneas.Std.Scalar.CheckedOps
import Aeneas.Std.Core.Core
import Aeneas.Std.Core.Ops
import Aeneas.Std.Core.Result
import Aeneas.Std.Core.NonZero

namespace Aeneas.Std

/-- Presence witnesses the native NoCoerce marker; `is_full` witnesses the
    stronger TrustedRandomAccess marker. Indexed access preserves its state. -/
structure core.iter.traits.iterator.RandomAccess (Self Item : Type) where
  get_unchecked : Self → Usize → Result (Item × Self)
  may_have_side_effect : Bool
  is_full : Bool

/-- Native integer-range StepBy specialization. Unlike a marker, this carries
    the operations on the range's preprocessed representation. -/
structure core.iter.adapters.step_by.StepByImpl (I Item : Type) where
  setup : I → Usize → Result I
  next : I → Usize → Result (Option Item × I)
  next_back : I → Usize → Result (Option Item × I)
  size_hint : I → Result (Usize × Option Usize)
  fold : {B F : Type} → core.ops.function.FnMut F (B × Item) B →
    I → Usize → B → F → Result (B × I × F)

@[rust_trait "core::iter::range::Step"
  (parentClauses := ["cloneInst", "partialOrdInst"])
  (defaultMethods := ["forward"])
  (auxiliaryFields := ["trusted_len", "step_by_range", "range_random_access"])]
structure core.iter.range.Step (Self : Type) where
  cloneInst : core.clone.Clone Self
  partialOrdInst : core.cmp.PartialOrd Self Self
  steps_between : Self → Self → Result (Usize × (Option Usize))
  forward_checked : Self → Usize → Result (Option Self)
  backward_checked : Self → Usize → Result (Option Self)
  -- The default step fails on overflow.
  forward : Self → Usize → Result Self := fun start n => do
    -- Check the next value.
    match ← forward_checked start n with
    | some value => return value
    | none => .fail .panic
  trusted_len : Bool := false
  step_by_range : Option (core.iter.adapters.step_by.StepByImpl (core.ops.range.Range Self) Self) :=
    none
  range_random_access :
    Option (core.iter.traits.iterator.RandomAccess (core.ops.range.Range Self) Self) := none

def core.iter.range.Step.forward.default {Self : Type}
    (stepInst : core.iter.range.Step Self) (start : Self) (n : Usize) : Result Self := do
  -- Check the next value.
  match ← stepInst.forward_checked start n with
  | some value => return value
  | none => .fail .panic

open Result

@[rust_trait "core::iter::adapters::zip::TrustedRandomAccessNoCoerce"
  (consts := ["MAY_HAVE_SIDE_EFFECT"])]
structure core.iter.adapters.zip.TrustedRandomAccessNoCoerce (Self : Type u)
  where
  MAY_HAVE_SIDE_EFFECT : Bool

structure core.iter.adapters.step_by.StepBy (I : Type u) where
  iter : I
  /-- Original positive stride; Rust stores this minus one. -/
  step_by : Usize
  first_take : Bool := true

def core.iter.adapters.step_by.StepBy.recombine {I : Type u}
    (mergeI : I → I → I) (original current : core.iter.adapters.step_by.StepBy I) :
    core.iter.adapters.step_by.StepBy I :=
  { original with iter := mergeI original.iter current.iter }

attribute [rust_type "core::iter::adapters::step_by::StepBy" (body := .opaque)
  (stateMerge := some ("Aeneas.Std.core.iter.adapters.step_by.StepBy.recombine", [0]))]
  core.iter.adapters.step_by.StepBy

@[rust_type "core::iter::adapters::enumerate::Enumerate"]
structure core.iter.adapters.enumerate.Enumerate (I : Type u) where
  iter : I
  count : Usize

@[rust_type "core::iter::adapters::take::Take"]
structure core.iter.adapters.take.Take (I : Type u) where
  iter : I
  n : Usize

@[rust_type "core::iter::adapters::filter_map::FilterMap"]
structure core.iter.adapters.filter_map.FilterMap (I F : Type) where
  iter : I
  f : F

@[rust_type "core::iter::adapters::rev::Rev"]
structure core.iter.adapters.rev.Rev (T : Type u) where
  iter : T

/-- Return the state from the terminal `next`, not the input state. Checked count
    overflow propagates failure after consuming the item, as in Rust's fold. -/
def core.iter.traits.iterator.countFromNext
  {Self Item : Type} (next : Self → Result (Option Item × Self))
  (self : Self) (count : Usize) : Result (Usize × Self) := do
  let (item, self) ← next self
  match item with
  | none => ok (count, self)
  | some _ =>
    let count ← count + 1#usize
    core.iter.traits.iterator.countFromNext next self count
partial_fixpoint

/-- `any` through `next` given the closure's call: each item in turn, until the closure
    returns `true`. -/
def core.iter.traits.iterator.anyFromNextWith
  {Self F Item : Type} (next : Self → Result (Option Item × Self))
  (call : F → Item → Result (Bool × F))
  (self : Self) (f : F) : Result (Bool × Self × F) := do
  let (item, self) ← next self
  match item with
  | none => ok (false, self, f)
  | some item =>
    let (found, f) ← call f item
    if found then ok (true, self, f)
    else core.iter.traits.iterator.anyFromNextWith next call self f
partial_fixpoint

def core.iter.traits.iterator.anyFromNext
  {Self F Item : Type} (next : Self → Result (Option Item × Self))
  (fnInst : core.ops.function.FnMut F Item Bool)
  (self : Self) (f : F) : Result (Bool × Self × F) :=
  core.iter.traits.iterator.anyFromNextWith next fnInst.call_mut self f

def core.iter.traits.iterator.foldFromNext
    {Self Item B F : Type} (next : Self → Result (Option Item × Self))
    (fnInst : core.ops.function.FnMut F (B × Item) B)
    (self : Self) (init : B) (f : F) : Result (B × Self × F) := do
  let (item, self) ← next self
  match item with
  | none => return (init, self, f)
  | some item =>
    let (acc, f) ← fnInst.call_mut f (init, item)
    core.iter.traits.iterator.foldFromNext next fnInst self acc f
partial_fixpoint

def core.iter.traits.iterator.tryFoldFromNext
    {Self Item B F R Residual : Type} (next : Self → Result (Option Item × Self))
    (fnInst : core.ops.function.FnMut F (B × Item) R)
    (tryInst : core.ops.try_trait.Try R B Residual)
    (self : Self) (init : B) (f : F) : Result (R × Self × F) := do
  let (item, self) ← next self
  match item with
  | none => return (← tryInst.from_output init, self, f)
  | some item =>
    let (r, f) ← fnInst.call_mut f (init, item)
    match ← tryInst.branch r with
    | .Break residual => return (← tryInst.FromResidualInst.from_residual residual, self, f)
    | .Continue acc => core.iter.traits.iterator.tryFoldFromNext next fnInst tryInst self acc f
partial_fixpoint

def core.iter.traits.iterator.advanceByFromNext
    {Self Item : Type} (next : Self → Result (Option Item × Self))
    (self : Self) (n : Usize) :
    Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) × Self) := do
  if n.val = 0 then return (.Ok (), self)
  let (item, self) ← next self
  match item with
  | none => return (.Err (← core.num.nonzero.NonZero.new_unchecked n), self)
  | some _ =>
    core.iter.traits.iterator.advanceByFromNext next self (← n - 1#usize)
partial_fixpoint

def core.iter.traits.iterator.nthFromNext
    {Self Item : Type} (next : Self → Result (Option Item × Self))
    (self : Self) (n : Nat) : Result (Option Item × Self) := do
  match n with
  | 0 => next self
  | n + 1 =>
    let (item, self) ← next self
    match item with
    | none => return (none, self)
    | some _ => core.iter.traits.iterator.nthFromNext next self n

/-- Internal `ControlFlow` dictionary, preserving residual reconstruction. -/
def core.iter.traits.iterator.controlFlowTry (B C : Type) :
    core.ops.try_trait.Try (core.ops.control_flow.ControlFlow B C) C B := {
  FromResidualInst := { from_residual := fun b => .ok (.Break b) }
  from_output := fun c => .ok (.Continue c)
  branch := fun r => .ok r
}

def core.iter.traits.iterator.countFromFold {Self Item : Type}
    (fold : {B F : Type} → core.ops.function.FnMut F (B × Item) B →
      Self → B → F → Result (B × Self × F))
    (self : Self) : Result (Usize × Self) := do
  let fnInst : core.ops.function.FnMut Unit (Usize × Item) Usize := {
    FnOnceInst := { call_once := fun _ x => do return (← x.1 + 1#usize, ()) }
    call_mut := fun _ x => do return (← x.1 + 1#usize, ())
  }
  let (count, self, _) ← fold fnInst self 0#usize ()
  return (count, self)

def core.iter.traits.iterator.anyFromTryFold {Self Item F : Type}
    (try_fold : {B F R Residual : Type} →
      core.ops.function.FnMut F (B × Item) R → core.ops.try_trait.Try R B Residual →
      Self → B → F → Result (R × Self × F))
    (fnInst : core.ops.function.FnMut F Item Bool)
    (self : Self) (f : F) : Result (Bool × Self × F) := do
  let call := fun f (x : Unit × Item) => do
    let (found, f) ← fnInst.call_mut f x.2
    return ((if found then .Break () else .Continue () :
      core.ops.control_flow.ControlFlow Unit Unit), f)
  let wrapped : core.ops.function.FnMut F (Unit × Item)
      (core.ops.control_flow.ControlFlow Unit Unit) := {
    FnOnceInst := { call_once := call }
    call_mut := call
  }
  let (r, self, f) ← try_fold wrapped
    (core.iter.traits.iterator.controlFlowTry Unit Unit) self () f
  return (match r with | .Break _ => true | .Continue _ => false, self, f)

def core.iter.traits.iterator.allFromTryFold {Self Item F : Type}
    (try_fold : {B F R Residual : Type} →
      core.ops.function.FnMut F (B × Item) R → core.ops.try_trait.Try R B Residual →
      Self → B → F → Result (R × Self × F))
    (fnInst : core.ops.function.FnMut F Item Bool)
    (self : Self) (f : F) : Result (Bool × Self × F) := do
  let call := fun f (x : Unit × Item) => do
    let (accepted, f) ← fnInst.call_mut f x.2
    return ((if accepted then .Continue () else .Break () :
      core.ops.control_flow.ControlFlow Unit Unit), f)
  let wrapped : core.ops.function.FnMut F (Unit × Item)
      (core.ops.control_flow.ControlFlow Unit Unit) := {
    FnOnceInst := { call_once := call }
    call_mut := call
  }
  let (r, self, f) ← try_fold wrapped
    (core.iter.traits.iterator.controlFlowTry Unit Unit) self () f
  return (match r with | .Break _ => false | .Continue _ => true, self, f)

/-- The predicate borrows the item: shared-reference erasure leaves `Item` as
    its argument, and the original item, not a clone, is returned on success. -/
def core.iter.traits.iterator.findFromTryFold {Self Item P : Type}
    (try_fold : {B F R Residual : Type} →
      core.ops.function.FnMut F (B × Item) R → core.ops.try_trait.Try R B Residual →
      Self → B → F → Result (R × Self × F))
    (fnInst : core.ops.function.FnMut P Item Bool)
    (self : Self) (predicate : P) : Result (Option Item × Self × P) := do
  let call := fun predicate (x : Unit × Item) => do
    let (found, predicate) ← fnInst.call_mut predicate x.2
    return ((if found then .Break x.2 else .Continue () :
      core.ops.control_flow.ControlFlow Item Unit), predicate)
  let wrapped : core.ops.function.FnMut P (Unit × Item)
      (core.ops.control_flow.ControlFlow Item Unit) := {
    FnOnceInst := { call_once := call }
    call_mut := call
  }
  let (r, self, predicate) ← try_fold wrapped
    (core.iter.traits.iterator.controlFlowTry Item Unit) self () predicate
  return (match r with | .Break item => some item | .Continue _ => none, self, predicate)

def core.iter.traits.iterator.findMapFromTryFold {Self Item B F : Type}
    (try_fold : {B F R Residual : Type} →
      core.ops.function.FnMut F (B × Item) R → core.ops.try_trait.Try R B Residual →
      Self → B → F → Result (R × Self × F))
    (fnInst : core.ops.function.FnMut F Item (Option B))
    (self : Self) (f : F) : Result (Option B × Self × F) := do
  let call := fun f (x : Unit × Item) => do
    let (mapped, f) ← fnInst.call_mut f x.2
    return ((match mapped with | some item => .Break item | none => .Continue () :
      core.ops.control_flow.ControlFlow B Unit), f)
  let wrapped : core.ops.function.FnMut F (Unit × Item)
      (core.ops.control_flow.ControlFlow B Unit) := {
    FnOnceInst := { call_once := call }
    call_mut := call
  }
  let (r, self, f) ← try_fold wrapped
    (core.iter.traits.iterator.controlFlowTry B Unit) self () f
  return (match r with | .Break item => some item | .Continue _ => none, self, f)

def core.iter.traits.iterator.positionFromTryFold {Self Item P : Type}
    (try_fold : {B F R Residual : Type} →
      core.ops.function.FnMut F (B × Item) R → core.ops.try_trait.Try R B Residual →
      Self → B → F → Result (R × Self × F))
    (fnInst : core.ops.function.FnMut P Item Bool)
    (self : Self) (predicate : P) : Result (Option Usize × Self × P) := do
  -- Rust keeps the index in the callback, with a unit fold accumulator.
  let call : (Usize × P) → (Unit × Item) →
      Result (core.ops.control_flow.ControlFlow Usize Unit × (Usize × P)) :=
    fun state x => do
      let (found, predicate) ← fnInst.call_mut state.2 x.2
      if found then
        return (.Break state.1, (state.1, predicate))
      else
        let index ← state.1 + 1#usize
        return (.Continue (), (index, predicate))
  let wrapped : core.ops.function.FnMut (Usize × P) (Unit × Item)
      (core.ops.control_flow.ControlFlow Usize Unit) := {
    FnOnceInst := { call_once := call }
    call_mut := call
  }
  let (r, self, _, predicate) ← try_fold wrapped
    (core.iter.traits.iterator.controlFlowTry Usize Unit) self () (0#usize, predicate)
  return (match r with | .Break index => some index | .Continue _ => none, self, predicate)

/-- Sized Rust iterators specialize the default through `try_fold`. -/
def core.iter.traits.iterator.advanceByFromTryFold {Self Item : Type}
    (try_fold : {B F R Residual : Type} →
      core.ops.function.FnMut F (B × Item) R → core.ops.try_trait.Try R B Residual →
      Self → B → F → Result (R × Self × F))
    (self : Self) (n : Usize) :
    Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) × Self) := do
  if n.val = 0 then return (.Ok (), self)
  let call := fun (_ : Unit) (x : Usize × Item) => do
    let remaining ← x.1 - 1#usize
    return ((if remaining.val = 0 then .Break () else .Continue remaining :
      core.ops.control_flow.ControlFlow Unit Usize), ())
  let fnInst : core.ops.function.FnMut Unit (Usize × Item)
      (core.ops.control_flow.ControlFlow Unit Usize) := {
    FnOnceInst := { call_once := call }
    call_mut := call
  }
  let (r, self, _) ← try_fold fnInst
    (core.iter.traits.iterator.controlFlowTry Unit Usize) self n ()
  match r with
  | .Break _ => return (.Ok (), self)
  | .Continue remaining =>
    return (.Err (← core.num.nonzero.NonZero.new_unchecked remaining), self)

@[rust_trait "core::iter::traits::iterator::Iterator"
  (defaultMethods := ["step_by", "enumerate", "take", "filter_map", "count", "any",
    "all", "find", "find_map", "position", "advance_by", "nth", "fold", "try_fold", "size_hint"])
  (defaultOnlyMethods := ["collect", "unzip"])
  (auxiliaryFields := ["trusted_len", "one_shot", "fused", "random_access", "step_by_impl",
    "in_place_collect"])]
structure core.iter.traits.iterator.Iterator (Self : Type) (Self_Item : Type)
  where
  next : Self → Result ((Option Self_Item) × Self)
  fold : {B F : Type} → core.ops.function.FnMut F (B × Self_Item) B →
    Self → B → F → Result (B × Self × F) :=
    fun fnInst => core.iter.traits.iterator.foldFromNext next fnInst
  try_fold : {B F R Residual : Type} →
    core.ops.function.FnMut F (B × Self_Item) R → core.ops.try_trait.Try R B Residual →
    Self → B → F → Result (R × Self × F) :=
    fun fnInst tryInst => core.iter.traits.iterator.tryFoldFromNext next fnInst tryInst
  advance_by : Self → Usize →
    Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) × Self) :=
    core.iter.traits.iterator.advanceByFromTryFold try_fold
  nth : Self → Usize → Result (Option Self_Item × Self) := fun self n => do
    let (r, self) ← advance_by self n
    match r with
    | .Ok _ => next self
    | .Err _ => return (none, self)
  size_hint : Self → Result (Usize × Option Usize) := fun _ => .ok (0#usize, none)
  trusted_len : Bool := false
  one_shot : Bool := false
  fused : Bool := false
  random_access : Option (core.iter.traits.iterator.RandomAccess Self Self_Item) := none
  step_by_impl : Option (core.iter.adapters.step_by.StepByImpl Self Self_Item) := none
  /-- True needs a native layout and one-to-one source certificate. -/
  in_place_collect : Bool := false
  step_by : Self → Usize → Result (core.iter.adapters.step_by.StepBy Self) :=
    fun self step => do
      if step.val = 0 then .fail .panic
      else
        let iter ← match step_by_impl with
          | none => .ok self
          | some spec => spec.setup self step
        return { iter, step_by := step }
  enumerate : Self → Result (core.iter.adapters.enumerate.Enumerate Self) :=
    fun self => .ok { iter := self, count := 0#usize }
  take : Self → Usize → Result (core.iter.adapters.take.Take Self) :=
    fun self n => .ok ⟨self, n⟩
  filter_map : {B F : Type} → core.ops.function.FnMut F Self_Item (Option B) →
    Self → F → Result (core.iter.adapters.filter_map.FilterMap Self F) :=
    fun _ self f => .ok ⟨self, f⟩
  count : Self → Result (Usize × Self) :=
    core.iter.traits.iterator.countFromFold fold
  any : {F : Type} → core.ops.function.FnMut F Self_Item Bool →
    Self → F → Result (Bool × Self × F) :=
    fun {F} fnInst => core.iter.traits.iterator.anyFromTryFold (F := F) try_fold fnInst
  all : {F : Type} → core.ops.function.FnMut F Self_Item Bool →
    Self → F → Result (Bool × Self × F) :=
    fun {F} fnInst => core.iter.traits.iterator.allFromTryFold (F := F) try_fold fnInst
  find : {P : Type} → core.ops.function.FnMut P Self_Item Bool →
    Self → P → Result (Option Self_Item × Self × P) :=
    fun {P} fnInst => core.iter.traits.iterator.findFromTryFold (P := P) try_fold fnInst
  find_map : {B F : Type} → core.ops.function.FnMut F Self_Item (Option B) →
    Self → F → Result (Option B × Self × F) :=
    fun {B F} fnInst =>
      core.iter.traits.iterator.findMapFromTryFold (B := B) (F := F) try_fold fnInst
  position : {P : Type} → core.ops.function.FnMut P Self_Item Bool →
    Self → P → Result (Option Usize × Self × P) :=
    fun {P} fnInst => core.iter.traits.iterator.positionFromTryFold (P := P) try_fold fnInst
  -- rev remains a standalone model: DoubleEndedIterator refers back to Iterator.
  -- collect remains a standalone model: FromIterator refers back to Iterator.

def core.iter.traits.iterator.Iterator.trusted_random_access {Self Item : Type}
    (self : core.iter.traits.iterator.Iterator Self Item) : Bool :=
  self.random_access.any (fun access => access.is_full)

@[rust_fun
  "core::iter::traits::iterator::{core::iter::traits::iterator::Iterator<&'a mut @I, @Item>}::next"]
def core.iter.traits.iterator.IteratorMut.next
    {I Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
    (self : I) : Result (Option Item × I) :=
  iterInst.next self

@[rust_fun
  "core::iter::traits::iterator::{core::iter::traits::iterator::Iterator<&'a mut @I, @Item>}::size_hint"]
def core.iter.traits.iterator.IteratorMut.size_hint
    {I Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
    (self : I) : Result (Usize × Option Usize) :=
  iterInst.size_hint self

@[rust_fun
  "core::iter::traits::iterator::{core::iter::traits::iterator::Iterator<&'a mut @I, @Item>}::advance_by"]
def core.iter.traits.iterator.IteratorMut.advance_by
    {I Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
    (self : I) (n : Usize) :
    Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) × I) :=
  iterInst.advance_by self n

@[rust_fun
  "core::iter::traits::iterator::{core::iter::traits::iterator::Iterator<&'a mut @I, @Item>}::nth"]
def core.iter.traits.iterator.IteratorMut.nth
    {I Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
    (self : I) (n : Usize) : Result (Option Item × I) :=
  iterInst.nth self n

-- For sized iterator state, IteratorRefSpec folds through the receiver's
-- try_fold, not its consuming fold override. The wrapper cannot short-circuit.
@[rust_fun
  "core::iter::traits::iterator::{core::iter::traits::iterator::Iterator<&'a mut @I, @Item>}::fold"]
def core.iter.traits.iterator.IteratorMut.fold
    {I Item B F : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
    (fnInst : core.ops.function.FnMut F (B × Item) B)
    (self : I) (init : B) (f : F) : Result (B × I × F) := do
  let wrapped : core.ops.function.FnMut F (B × Item)
      (core.ops.control_flow.ControlFlow Empty B) := {
    FnOnceInst := { call_once := fun f args => do
      let (value, f) ← fnInst.call_mut f args
      return (.Continue value, f) }
    call_mut := fun f args => do
      let (value, f) ← fnInst.call_mut f args
      return (.Continue value, f)
  }
  let (result, self, f) ←
    iterInst.try_fold wrapped (core.iter.traits.iterator.controlFlowTry Empty B) self init f
  match result with
  | .Continue value => return (value, self, f)
  | .Break impossible => nomatch impossible

@[rust_fun
  "core::iter::traits::iterator::{core::iter::traits::iterator::Iterator<&'a mut @I, @Item>}::try_fold"]
def core.iter.traits.iterator.IteratorMut.try_fold
    {I Item B F R Residual : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
    (fnInst : core.ops.function.FnMut F (B × Item) R)
    (tryInst : core.ops.try_trait.Try R B Residual)
    (self : I) (init : B) (f : F) : Result (R × I × F) :=
  iterInst.try_fold fnInst tryInst self init f

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<&'a mut @I, @Item>"]
def core.iter.traits.iterator.IteratorMut
    {I Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item) :
    core.iter.traits.iterator.Iterator I Item := {
  next := core.iter.traits.iterator.IteratorMut.next iterInst
  size_hint := core.iter.traits.iterator.IteratorMut.size_hint iterInst
  advance_by := core.iter.traits.iterator.IteratorMut.advance_by iterInst
  nth := core.iter.traits.iterator.IteratorMut.nth iterInst
  fold := core.iter.traits.iterator.IteratorMut.fold iterInst
  try_fold := core.iter.traits.iterator.IteratorMut.try_fold iterInst
  trusted_len := iterInst.trusted_len
  one_shot := iterInst.one_shot
  fused := iterInst.fused
}

def core.iter.traits.iterator.Iterator.step_by.default
  {Self : Type} (self: Self) (step_by : Std.Usize) :
  Result (core.iter.adapters.step_by.StepBy Self) :=
  if step_by.val = 0 then .fail .panic
  else .ok { iter := self, step_by }

def core.iter.traits.iterator.Iterator.enumerate.default
  {Self : Type} (self : Self) :
  Result (core.iter.adapters.enumerate.Enumerate Self) :=
  .ok { iter := self, count := 0#usize }

def core.iter.traits.iterator.Iterator.take.default
  {Self : Type} (self : Self) (n : Usize) :
  Result (core.iter.adapters.take.Take Self) :=
  .ok ⟨self, n⟩

def core.iter.traits.iterator.Iterator.count.default
  {Self Item : Type} (iterInst : core.iter.traits.iterator.Iterator Self Item)
  (self : Self) : Result (Usize × Self) :=
  core.iter.traits.iterator.countFromFold iterInst.fold self

def core.iter.traits.iterator.Iterator.any.default
  {Self F Item : Type} (iterInst : core.iter.traits.iterator.Iterator Self Item)
  (fnInst : core.ops.function.FnMut F Item Bool)
  (self : Self) (f : F) : Result (Bool × Self × F) :=
  core.iter.traits.iterator.anyFromTryFold iterInst.try_fold fnInst self f

def core.iter.traits.iterator.Iterator.all.default
  {Self F Item : Type} (iterInst : core.iter.traits.iterator.Iterator Self Item)
  (fnInst : core.ops.function.FnMut F Item Bool)
  (self : Self) (f : F) : Result (Bool × Self × F) :=
  core.iter.traits.iterator.allFromTryFold iterInst.try_fold fnInst self f

def core.iter.traits.iterator.Iterator.find.default
  {Self P Item : Type} (iterInst : core.iter.traits.iterator.Iterator Self Item)
  (fnInst : core.ops.function.FnMut P Item Bool)
  (self : Self) (predicate : P) : Result (Option Item × Self × P) :=
  core.iter.traits.iterator.findFromTryFold iterInst.try_fold fnInst self predicate

def core.iter.traits.iterator.Iterator.find_map.default
  {Self B F Item : Type} (iterInst : core.iter.traits.iterator.Iterator Self Item)
  (fnInst : core.ops.function.FnMut F Item (Option B))
  (self : Self) (f : F) : Result (Option B × Self × F) :=
  core.iter.traits.iterator.findMapFromTryFold iterInst.try_fold fnInst self f

def core.iter.traits.iterator.Iterator.position.default
  {Self P Item : Type} (iterInst : core.iter.traits.iterator.Iterator Self Item)
  (fnInst : core.ops.function.FnMut P Item Bool)
  (self : Self) (predicate : P) : Result (Option Usize × Self × P) :=
  core.iter.traits.iterator.positionFromTryFold iterInst.try_fold fnInst self predicate

def core.iter.traits.iterator.Iterator.fold.default {Self Item B F : Type}
    (iterInst : core.iter.traits.iterator.Iterator Self Item)
    (fnInst : core.ops.function.FnMut F (B × Item) B)
    (self : Self) (init : B) (f : F) : Result (B × Self × F) :=
  core.iter.traits.iterator.foldFromNext iterInst.next fnInst self init f

def core.iter.traits.iterator.Iterator.try_fold.default {Self Item B F R Residual : Type}
    (iterInst : core.iter.traits.iterator.Iterator Self Item)
    (fnInst : core.ops.function.FnMut F (B × Item) R)
    (tryInst : core.ops.try_trait.Try R B Residual)
    (self : Self) (init : B) (f : F) : Result (R × Self × F) :=
  core.iter.traits.iterator.tryFoldFromNext iterInst.next fnInst tryInst self init f

def core.iter.traits.iterator.Iterator.advance_by.default {Self Item : Type}
    (iterInst : core.iter.traits.iterator.Iterator Self Item) (self : Self) (n : Usize) :
    Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) × Self) :=
  core.iter.traits.iterator.advanceByFromTryFold iterInst.try_fold self n

def core.iter.traits.iterator.Iterator.nth.default {Self Item : Type}
    (iterInst : core.iter.traits.iterator.Iterator Self Item) (self : Self) (n : Usize) :
    Result (Option Item × Self) := do
  let (r, self) ← iterInst.advance_by self n
  match r with
  | .Ok _ => iterInst.next self
  | .Err _ => return (none, self)

def core.iter.traits.iterator.Iterator.size_hint.default {Self Item : Type}
    (_iterInst : core.iter.traits.iterator.Iterator Self Item) (_self : Self) :
    Result (Usize × Option Usize) := .ok (0#usize, none)

/-- Skip up to `n` elements from an iterator -/
def core.iter.adapters.step_by.skipN
    {I : Type} {Item : Type}
    (iterInst : core.iter.traits.iterator.Iterator I Item)
    (iter : I) : (n : Nat) → Result I
  | 0 => .ok iter
  | n + 1 => do
    let (opt, iter) ← iterInst.next iter
    match opt with
    | none => .ok iter
    | some _ => core.iter.adapters.step_by.skipN iterInst iter n

@[rust_fun
  "core::iter::adapters::step_by::{core::iter::traits::iterator::Iterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Item>}::next"]
def core.iter.adapters.step_by.IteratorStepBy.next
  {I : Type} {Item : Type}
  (IteratorInst : core.iter.traits.iterator.Iterator I Item) :
  core.iter.adapters.step_by.StepBy I →
  Result ((Option Item) × (core.iter.adapters.step_by.StepBy I)) :=
  fun self => do
    if let some spec := IteratorInst.step_by_impl then
      let (item, iter) ← spec.next self.iter self.step_by
      return (item, { self with iter })
    let n ← if self.first_take then .ok 0#usize else self.step_by - 1#usize
    let (item, iter) ← IteratorInst.nth self.iter n
    return (item, { self with iter, first_take := false })

@[rust_fun
  "core::iter::adapters::step_by::{core::iter::traits::iterator::Iterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Item>}::step_by"]
def core.iter.adapters.step_by.IteratorStepBy.step_by
  {I : Type} {Item : Type}
  (_IteratorInst : core.iter.traits.iterator.Iterator I Item) :
  core.iter.adapters.step_by.StepBy I → Std.Usize →
  Result (core.iter.adapters.step_by.StepBy (core.iter.adapters.step_by.StepBy I)) :=
  fun self steps =>
    if steps.val = 0 then .fail .panic
    else .ok { iter := self, step_by := steps }

@[rust_fun
  "core::iter::adapters::step_by::{core::iter::traits::iterator::Iterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Item>}::enumerate"]
def core.iter.adapters.step_by.IteratorStepBy.enumerate
  {I : Type} {Item : Type}
  (_IteratorInst : core.iter.traits.iterator.Iterator I Item) :
  core.iter.adapters.step_by.StepBy I →
  Result (core.iter.adapters.enumerate.Enumerate (core.iter.adapters.step_by.StepBy I)) :=
  fun self => .ok { iter := self, count := 0#usize }

@[rust_fun
  "core::iter::adapters::step_by::{core::iter::traits::iterator::Iterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Item>}::take"]
def core.iter.adapters.step_by.IteratorStepBy.take
  {I : Type} {Item : Type}
  (_IteratorInst : core.iter.traits.iterator.Iterator I Item) :
  core.iter.adapters.step_by.StepBy I → Std.Usize →
  Result (core.iter.adapters.take.Take (core.iter.adapters.step_by.StepBy I)) :=
  fun self n => .ok ⟨ self, n ⟩

/-- Rust's overflow splitting preserves the exact sequence of inner `nth` calls. -/
def core.iter.adapters.step_by.nthLoop {I Item : Type}
    (iterInst : core.iter.traits.iterator.Iterator I Item)
    (iter : I) (n step : Usize) : Result (Option Item × I) := do
  match Usize.checked_mul n step with
  | some total => iterInst.nth iter (← total - 1#usize)
  | none =>
    let max := core.num.Usize.MAX
    let divN ← max / n
    let divStep ← max / step
    let nthN ← divN * n
    let nthStep ← divStep * step
    if nthN.val > nthStep.val then
      let (_, iter) ← iterInst.nth iter (← nthN - 1#usize)
      core.iter.adapters.step_by.nthLoop iterInst iter n (← step - divN)
    else
      let (_, iter) ← iterInst.nth iter (← nthStep - 1#usize)
      core.iter.adapters.step_by.nthLoop iterInst iter (← n - divStep) step
partial_fixpoint

@[rust_fun
  "core::iter::adapters::step_by::{core::iter::traits::iterator::Iterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Item>}::nth"]
def core.iter.adapters.step_by.IteratorStepBy.nth {I Item : Type}
    (iterInst : core.iter.traits.iterator.Iterator I Item)
    (self : core.iter.adapters.step_by.StepBy I) (n : Usize) :
    Result (Option Item × core.iter.adapters.step_by.StepBy I) := do
  if let some spec := iterInst.step_by_impl then
    let next := fun iter => spec.next iter self.step_by
    let (r, iter) ← core.iter.traits.iterator.advanceByFromNext next self.iter n
    match r with
    | .Err _ => return (none, { self with iter })
    | .Ok _ =>
      let (item, iter) ← next iter
      return (item, { self with iter })
  let mut self := self
  let mut n := n
  if self.first_take then
    let (first, iter) ← iterInst.next self.iter
    self := { self with iter, first_take := false }
    if n.val = 0 then return (first, self)
    n ← n - 1#usize
  if n.val = Usize.max then
    let (_, iter) ← iterInst.nth self.iter (← self.step_by - 1#usize)
    self := { self with iter }
  else
    n ← n + 1#usize
  let (item, iter) ← core.iter.adapters.step_by.nthLoop iterInst self.iter n self.step_by
  return (item, { self with iter })

@[rust_fun
  "core::iter::adapters::step_by::{core::iter::traits::iterator::Iterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Item>}::size_hint"]
def core.iter.adapters.step_by.IteratorStepBy.size_hint {I Item : Type}
    (iterInst : core.iter.traits.iterator.Iterator I Item)
    (self : core.iter.adapters.step_by.StepBy I) : Result (Usize × Option Usize) := do
  if let some spec := iterInst.step_by_impl then
    return ← spec.size_hint self.iter
  let (lo, hi) ← iterInst.size_hint self.iter
  let size := fun (n : Usize) => do
    if self.first_take then
      if n.val = 0 then return 0#usize
      let n ← n - 1#usize
      let n ← n / self.step_by
      n + 1#usize
    else n / self.step_by
  let lo ← size lo
  let hi ← match hi with
    | none => .ok none
    | some upper => do
      let upper ← size upper
      pure (some upper)
  return (lo, hi)

/-- Fold's first call is `next`, whereas StepBy.next calls `nth(0)`. -/
def core.iter.adapters.step_by.foldNext {I Item : Type}
    (iterInst : core.iter.traits.iterator.Iterator I Item)
    (self : core.iter.adapters.step_by.StepBy I) :
    Result (Option Item × core.iter.adapters.step_by.StepBy I) := do
  if let some spec := iterInst.step_by_impl then
    let (item, iter) ← spec.next self.iter self.step_by
    return (item, { self with iter })
  let (item, iter) ← if self.first_take then iterInst.next self.iter
    else iterInst.nth self.iter (← self.step_by - 1#usize)
  return (item, { self with iter, first_take := false })

@[rust_fun
  "core::iter::adapters::step_by::{core::iter::traits::iterator::Iterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Item>}::fold"]
def core.iter.adapters.step_by.IteratorStepBy.fold {I Item B F : Type}
    (iterInst : core.iter.traits.iterator.Iterator I Item)
    (fnInst : core.ops.function.FnMut F (B × Item) B)
    (self : core.iter.adapters.step_by.StepBy I) (init : B) (f : F) :
    Result (B × core.iter.adapters.step_by.StepBy I × F) := do
  if let some spec := iterInst.step_by_impl then
    let (acc, iter, f) ← spec.fold fnInst self.iter self.step_by init f
    return (acc, { self with iter }, f)
  core.iter.traits.iterator.foldFromNext
    (core.iter.adapters.step_by.foldNext iterInst) fnInst self init f

@[rust_fun
  "core::iter::adapters::step_by::{core::iter::traits::iterator::Iterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Item>}::try_fold"]
def core.iter.adapters.step_by.IteratorStepBy.try_fold {I Item B F R Residual : Type}
    (iterInst : core.iter.traits.iterator.Iterator I Item)
    (fnInst : core.ops.function.FnMut F (B × Item) R)
    (tryInst : core.ops.try_trait.Try R B Residual)
    (self : core.iter.adapters.step_by.StepBy I) (init : B) (f : F) :
    Result (R × core.iter.adapters.step_by.StepBy I × F) :=
  core.iter.traits.iterator.tryFoldFromNext
    (core.iter.adapters.step_by.foldNext iterInst) fnInst tryInst self init f

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Item>"]
def core.iter.traits.iterator.IteratorStepBy {I : Type} {Item : Type}
  (IteratorInst : core.iter.traits.iterator.Iterator I Item) :
  core.iter.traits.iterator.Iterator (core.iter.adapters.step_by.StepBy I) Item := {
  next := core.iter.adapters.step_by.IteratorStepBy.next IteratorInst
  nth := core.iter.adapters.step_by.IteratorStepBy.nth IteratorInst
  size_hint := core.iter.adapters.step_by.IteratorStepBy.size_hint IteratorInst
  fold := core.iter.adapters.step_by.IteratorStepBy.fold IteratorInst
  try_fold := core.iter.adapters.step_by.IteratorStepBy.try_fold IteratorInst
  trusted_len := IteratorInst.trusted_random_access
  fused := IteratorInst.fused
  step_by := core.iter.adapters.step_by.IteratorStepBy.step_by IteratorInst
  enumerate := core.iter.adapters.step_by.IteratorStepBy.enumerate IteratorInst
  take := core.iter.adapters.step_by.IteratorStepBy.take IteratorInst
}

/-- `Sum::sum(iter)` consumes the iterator: the model also returns its final state
    (the state contract of `ModelStateInputs.for_method`), which gives back what
    the iterator borrows mutably, e.g. through a mapping closure. -/
@[rust_trait "core::iter::traits::accum::Sum"]
structure core.iter.traits.accum.Sum (Self : Type) (A : Type) where
  sum : forall {I : Type} (_ : core.iter.traits.iterator.Iterator I A), I → Result (Self × I)

/-- `Product::product(iter)`, with the final state of the iterator as for `Sum`. -/
@[rust_trait "core::iter::traits::accum::Product"]
structure core.iter.traits.accum.Product (Self : Type) (A : Type) where
  product : forall {I : Type} (_ : core.iter.traits.iterator.Iterator I A), I → Result (Self × I)

/-- `Iterator::product` (core/src/iter/traits/iterator.rs, rustc 1.95):
    `Product::product(self)`. No core iterator overrides it. -/
@[rust_fun "core::iter::traits::iterator::Iterator::product"]
def core.iter.traits.iterator.Iterator.product.default
  {Self P Item : Type} (IteratorInst : core.iter.traits.iterator.Iterator Self Item)
  (productInst : core.iter.traits.accum.Product P Item) (self : Self) : Result (P × Self) :=
  productInst.product IteratorInst self

/-- `Iterator::max` (core/src/iter/traits/iterator.rs, rustc 1.95): `self.max_by(Ord::cmp)`,
    i.e. `self.reduce(|x, y| cmp::max_by(x, y, Ord::cmp))`: `reduce` takes the first item with
    `next`, then folds the rest with the iterator's own `fold`; `max_by(x, y)` keeps `x` iff
    `x.cmp(&y)` is `Greater`, so the last of equal maxima is returned. The iterator's final
    state is returned (`ModelStateInputs.for_method`). -/
@[rust_fun "core::iter::traits::iterator::Iterator::max"]
def core.iter.traits.iterator.Iterator.max.default {Self Item : Type}
    (iterInst : core.iter.traits.iterator.Iterator Self Item) (ordInst : core.cmp.Ord Item)
    (self : Self) : Result (Option Item × Self) := do
  let (first, self) ← iterInst.next self
  match first with
  | none => ok (none, self)
  | some first =>
    let step := fun (x : Item × Item) => do
      if (← ordInst.cmp x.1 x.2) = Ordering.gt then ok x.1 else ok x.2
    let maxInst : core.ops.function.FnMut Unit (Item × Item) Item := {
      FnOnceInst := { call_once := fun _ x => do ok (← step x, ()) }
      call_mut := fun _ x => do ok (← step x, ())
    }
    let (m, self, _) ← iterInst.fold maxInst self first ()
    ok (some m, self)

/-- `Iterator::reduce` (core/src/iter/traits/iterator.rs, rustc 1.95):
    `let first = self.next()?; Some(self.fold(first, f))`: the first item through `next`, then
    the other items through the iterator's own `fold` with the closure, from left to right. The
    iterator's and the closure's final states are returned (`ModelStateInputs.for_method`). -/
@[rust_fun "core::iter::traits::iterator::Iterator::reduce"]
def core.iter.traits.iterator.Iterator.reduce.default {Self F Item : Type}
    (iterInst : core.iter.traits.iterator.Iterator Self Item)
    (fnInst : core.ops.function.FnMut F (Item × Item) Item)
    (self : Self) (f : F) : Result (Option Item × Self × F) := do
  let (first, self) ← iterInst.next self
  match first with
  | none => ok (none, self, f)
  | some first =>
    let (r, self, f) ← iterInst.fold fnInst self first f
    ok (some r, self, f)

/-- `Iterator::for_each` (core/src/iter/traits/iterator.rs, rustc 1.95):
    `self.fold((), call(f))`: the closure on each item, from left to right, through the
    iterator's own `fold`. The iterator's and the closure's final states are returned
    (`ModelStateInputs.for_method`). -/
@[rust_fun "core::iter::traits::iterator::Iterator::for_each"]
def core.iter.traits.iterator.Iterator.for_each.default {Self F Item : Type}
    (iterInst : core.iter.traits.iterator.Iterator Self Item)
    (fnInst : core.ops.function.FnMut F Item Unit)
    (self : Self) (f : F) : Result (Unit × Self × F) := do
  let callInst : core.ops.function.FnMut F (Unit × Item) Unit := {
    FnOnceInst := { call_once := fun f x => fnInst.call_mut f x.2 }
    call_mut := fun f x => fnInst.call_mut f x.2
  }
  let (_, self, f) ← iterInst.fold callInst self () f
  ok ((), self, f)

/-- Native `try_for_each` uses the receiver's `try_fold`. It stops at the first residual.
    The result includes the final receiver and callback states. -/
@[rust_fun "core::iter::traits::iterator::Iterator::try_for_each"]
def core.iter.traits.iterator.Iterator.try_for_each.default {Self F R Item Residual : Type}
    (iterInst : core.iter.traits.iterator.Iterator Self Item)
    -- The callback returns a native Try value.
    (fnInst : core.ops.function.FnMut F Item R)
    (tryInst : core.ops.try_trait.Try R Unit Residual)

    -- Both state inputs return to the caller.
    (self : Self) (f : F) : Result (R × Self × F) := do
  -- Ignore the unit accumulator.
  let callInst : core.ops.function.FnMut F (Unit × Item) R := {
    FnOnceInst := { call_once := fun f x => fnInst.call_mut f x.2 }
    -- Preserve state.
    call_mut := fun f x => fnInst.call_mut f x.2
  }
  iterInst.try_fold callInst tryInst self () f

/-- `Iterator::min_by_key` (core/src/iter/traits/iterator.rs, rustc 1.95):
    `self.map(|x| (f(&x), x)).min_by(|(a, _), (b, _)| a.cmp(b))`, i.e. `reduce` over the keyed
    items: the first item's key through `next`, then the iterator's own `fold`, computing each
    item's key before comparing; `min_by(x, y)` keeps `x` iff `x.cmp(&y)` is `Less` or `Equal`,
    so the first of equal minima is returned. The iterator's and the key closure's final
    states are returned. -/
@[rust_fun "core::iter::traits::iterator::Iterator::min_by_key"]
def core.iter.traits.iterator.Iterator.min_by_key.default {Self Item B F : Type}
    (iterInst : core.iter.traits.iterator.Iterator Self Item) (ordInst : core.cmp.Ord B)
    (fnInst : core.ops.function.FnMut F Item B) (self : Self) (f : F) :
    Result (Option Item × Self × F) := do
  let (first, self) ← iterInst.next self
  match first with
  | none => ok (none, self, f)
  | some first =>
    let (k, f) ← fnInst.call_mut f first
    let step := fun (f : F) (x : (B × Item) × Item) => do
      let (ky, f) ← fnInst.call_mut f x.2
      if (← ordInst.cmp x.1.1 ky) = Ordering.gt then ok ((ky, x.2), f) else ok (x.1, f)
    let minInst : core.ops.function.FnMut F ((B × Item) × Item) (B × Item) := {
      FnOnceInst := { call_once := step }
      call_mut := step
    }
    let ((_, m), self, f) ← iterInst.fold minInst self (k, first) f
    ok (some m, self, f)

/-- `Iterator::min` (core/src/iter/traits/iterator.rs, rustc 1.95): `self.min_by(Ord::cmp)`,
    i.e. `self.reduce(|x, y| cmp::min_by(x, y, Ord::cmp))`: `reduce` takes the first item with
    `next`, then folds the rest with the iterator's own `fold`; `min_by(x, y)` keeps `x` iff
    `x.cmp(&y)` is `Less` or `Equal`, so the first of equal minima is returned. The iterator's
    final state is returned (`ModelStateInputs.for_method`). -/
@[rust_fun "core::iter::traits::iterator::Iterator::min"]
def core.iter.traits.iterator.Iterator.min.default {Self Item : Type}
    (iterInst : core.iter.traits.iterator.Iterator Self Item) (ordInst : core.cmp.Ord Item)
    (self : Self) : Result (Option Item × Self) := do
  let (first, self) ← iterInst.next self
  match first with
  | none => ok (none, self)
  | some first =>
    let step := fun (x : Item × Item) => do
      if (← ordInst.cmp x.1 x.2) = Ordering.gt then ok x.2 else ok x.1
    let minInst : core.ops.function.FnMut Unit (Item × Item) Item := {
      FnOnceInst := { call_once := fun _ x => do ok (← step x, ()) }
      call_mut := fun _ x => do ok (← step x, ())
    }
    let (m, self, _) ← iterInst.fold minInst self first ()
    ok (some m, self)

/-- `impl<'a> Product<&'a usize> for usize` (core/src/iter/traits/accum.rs,
    `integer_sum_product!`, rustc 1.95): `iter.fold(1, |a, b| a * b)` through the
    iterator's own `fold`. The closure carries `#[rustc_inherit_overflow_checks]`,
    so a checked caller panics at the first overflowing step, left to right, even
    if a later element is zero. -/
@[rust_fun
  "core::iter::traits::accum::{core::iter::traits::accum::Product<usize, &'a usize>}::product"]
def core.iter.traits.accum.ProductUsizeSharedUsize.product {I : Type}
  (iteratorInst : core.iter.traits.iterator.Iterator I Usize) (iter : I) : Result (Usize × I) := do
  let mulInst : core.ops.function.FnMut Unit (Usize × Usize) Usize := {
    FnOnceInst := { call_once := fun _ x => do return (← x.1 * x.2, ()) }
    call_mut := fun _ x => do return (← x.1 * x.2, ())
  }
  let (product, iter, _) ← iteratorInst.fold mulInst iter 1#usize ()
  ok (product, iter)

@[reducible, rust_trait_impl "core::iter::traits::accum::Product<usize, &'a usize>"]
def core.iter.traits.accum.ProductUsizeSharedUsize :
  core.iter.traits.accum.Product Usize Usize := {
  product := core.iter.traits.accum.ProductUsizeSharedUsize.product
}

/-- `impl Product for usize` (core/src/iter/traits/accum.rs, `integer_sum_product!`,
    rustc 1.95): `iter.fold(1, |a, b| a * b)`, checked as `Product<&usize>`. -/
@[rust_fun
  "core::iter::traits::accum::{core::iter::traits::accum::Product<usize, usize>}::product"]
def core.iter.traits.accum.ProductUsizeUsize.product {I : Type}
  (iteratorInst : core.iter.traits.iterator.Iterator I Usize) (iter : I) : Result (Usize × I) := do
  let mulInst : core.ops.function.FnMut Unit (Usize × Usize) Usize := {
    FnOnceInst := { call_once := fun _ x => do return (← x.1 * x.2, ()) }
    call_mut := fun _ x => do return (← x.1 * x.2, ())
  }
  let (product, iter, _) ← iteratorInst.fold mulInst iter 1#usize ()
  ok (product, iter)

@[reducible, rust_trait_impl "core::iter::traits::accum::Product<usize, usize>"]
def core.iter.traits.accum.ProductUsizeUsize :
  core.iter.traits.accum.Product Usize Usize := {
  product := core.iter.traits.accum.ProductUsizeUsize.product
}

/-- `Iterator::sum` (core/src/iter/traits/iterator.rs, rustc 1.95): `Sum::sum(self)`.
    No core iterator overrides it. -/
@[rust_fun "core::iter::traits::iterator::Iterator::sum"]
def core.iter.traits.iterator.Iterator.sum.default
  {Self S Item : Type} (IteratorInst : core.iter.traits.iterator.Iterator Self Item)
  (sumInst : core.iter.traits.accum.Sum S Item) (self : Self) : Result (S × Self) :=
  sumInst.sum IteratorInst self

/-- `impl Sum for usize` (core/src/iter/traits/accum.rs, `integer_sum_product!`,
    rustc 1.95): `iter.fold(0, |a, b| a + b)` through the iterator's own `fold`. The
    closure carries `#[rustc_inherit_overflow_checks]`, so a checked caller panics at
    the first overflowing step, left to right. -/
@[rust_fun "core::iter::traits::accum::{core::iter::traits::accum::Sum<usize, usize>}::sum"]
def core.iter.traits.accum.SumUsizeUsize.sum {I : Type}
  (iteratorInst : core.iter.traits.iterator.Iterator I Usize) (iter : I) : Result (Usize × I) := do
  let addInst : core.ops.function.FnMut Unit (Usize × Usize) Usize := {
    FnOnceInst := { call_once := fun _ x => do return (← x.1 + x.2, ()) }
    call_mut := fun _ x => do return (← x.1 + x.2, ())
  }
  let (sum, iter, _) ← iteratorInst.fold addInst iter 0#usize ()
  ok (sum, iter)

@[reducible, rust_trait_impl "core::iter::traits::accum::Sum<usize, usize>"]
def core.iter.traits.accum.SumUsizeUsize :
  core.iter.traits.accum.Sum Usize Usize := {
  sum := core.iter.traits.accum.SumUsizeUsize.sum
}

/-- `impl<'a> Sum<&'a usize> for usize` (core/src/iter/traits/accum.rs,
    `integer_sum_product!`, rustc 1.95): `iter.fold(0, |a, b| a + b)`, checked as
    `Sum<usize>`. -/
@[rust_fun "core::iter::traits::accum::{core::iter::traits::accum::Sum<usize, &'a usize>}::sum"]
def core.iter.traits.accum.SumUsizeSharedUsize.sum {I : Type}
  (iteratorInst : core.iter.traits.iterator.Iterator I Usize) (iter : I) : Result (Usize × I) := do
  let addInst : core.ops.function.FnMut Unit (Usize × Usize) Usize := {
    FnOnceInst := { call_once := fun _ x => do return (← x.1 + x.2, ()) }
    call_mut := fun _ x => do return (← x.1 + x.2, ())
  }
  let (sum, iter, _) ← iteratorInst.fold addInst iter 0#usize ()
  ok (sum, iter)

@[reducible, rust_trait_impl "core::iter::traits::accum::Sum<usize, &'a usize>"]
def core.iter.traits.accum.SumUsizeSharedUsize :
  core.iter.traits.accum.Sum Usize Usize := {
  sum := core.iter.traits.accum.SumUsizeSharedUsize.sum
}

@[rust_trait "core::iter::traits::collect::IntoIterator"
  (parentClauses := ["iteratorInst"])
  (auxiliaryFields := ["const_size"])]
structure core.iter.traits.collect.IntoIterator (Self : Type) (Item :
  Type) (IntoIter : Type) where
  iteratorInst : core.iter.traits.iterator.Iterator IntoIter Item
  /-- Recover the source from the actual returned iterator state after use. -/
  into_iter : Self → Result (IntoIter × (IntoIter → Self))
  const_size : Option Usize := none

@[rust_trait "core::iter::traits::collect::FromIterator"]
structure core.iter.traits.collect.FromIterator (Self : Type) (A : Type) where
  from_iter : forall {T : Type} {IntoIter : Type}
    (_ : core.iter.traits.collect.IntoIterator T A IntoIter),
    T → Result (Self × T)

@[rust_fun
  "core::iter::traits::collect::{core::iter::traits::collect::IntoIterator<@I, @Item, @I>}::into_iter",
  simp]
def core.iter.traits.collect.IntoIterator.Blanket.into_iter
  {I : Type} {Item : Type} (_ : core.iter.traits.iterator.Iterator I Item) :
  I → Result (I × (I → I)) :=
    λ x => ok (x, id)

@[reducible, rust_trait_impl
  "core::iter::traits::collect::IntoIterator<@I, @Item, @I>"]
def core.iter.traits.collect.IntoIterator.Blanket {I : Type} {Item : Type}
  (IteratorInst : core.iter.traits.iterator.Iterator I Item) :
    core.iter.traits.collect.IntoIterator I Item I := {
  iteratorInst := IteratorInst
  into_iter := core.iter.traits.collect.IntoIterator.Blanket.into_iter IteratorInst
}

-- `collect` cannot be a field of Iterator: FromIterator itself depends on
-- Iterator. Generic use of this standalone default is therefore restricted by
-- the rust_trait defaultOnlyMethods contract, checked against Rust provenance
-- for every canonical dictionary. Native overrides are never replaced.
@[rust_fun "core::iter::traits::iterator::Iterator::collect"]
def core.iter.traits.iterator.Iterator.collect.default
  {Self : Type} {B : Type} {Item : Type} (IteratorInst :
  core.iter.traits.iterator.Iterator Self Item)
  (collectFromIteratorInst : core.iter.traits.collect.FromIterator B Item) :
  Self → Result (B × Self) :=
  fun self => collectFromIteratorInst.from_iter
    (core.iter.traits.collect.IntoIterator.Blanket IteratorInst) self

/-- `iter_eq(a, b, f)` of `eq_by` (core/src/iter/traits/iterator.rs, rustc 1.95), with
    `f(x, y) = if x == y { Continue(()) } else { Break(()) }`: `iter_compare` runs
    `a.try_for_each(|x| match b.next() { None => Break(Continue(Greater)), Some(y) =>
    f(x, y).map_break(Break) })` through `a`'s own `try_fold`; when `a` runs out it calls
    `b.next()` once more (`Equal` iff `None`). The result is `Continue(Equal)`, i.e. every item
    of `a` equal to the item of `b` at its position and `b` exhausted with `a`. -/
def core.iter.traits.iterator.iterEq {A B Item BItem : Type}
    (aInst : core.iter.traits.iterator.Iterator A Item)
    (bInst : core.iter.traits.iterator.Iterator B BItem)
    (eqInst : core.cmp.PartialEq Item BItem) (a : A) (b : B) : Result (Bool × A × B) := do
  let call := fun (b : B) (x : Unit × Item) => do
    let (y, b) ← bInst.next b
    match y with
    | none => ok ((.Break () : core.ops.control_flow.ControlFlow Unit Unit), b)
    | some y =>
      if (← eqInst.eq x.2 y) then ok (.Continue (), b) else ok (.Break (), b)
  let compare : core.ops.function.FnMut B (Unit × Item)
      (core.ops.control_flow.ControlFlow Unit Unit) := {
    FnOnceInst := { call_once := call }
    call_mut := call
  }
  let (r, a, b) ← aInst.try_fold compare
    (core.iter.traits.iterator.controlFlowTry Unit Unit) a () b
  match r with
  | .Break _ => ok (false, a, b)
  | .Continue _ => do
    let (y, b) ← bInst.next b
    ok (y.isNone, a, b)

/-- `Iterator::eq` (core/src/iter/traits/iterator.rs, rustc 1.95): `self.eq_by(other, |x, y|
    x == y)`, i.e. `SpecIterEq::spec_iter_eq(self, other.into_iter(), ..)`. The specialization
    for two `TrustedLen` iterators (the dictionaries' `trusted_len`) first compares the upper
    bounds of `self.size_hint()` and `b.size_hint()`: equal bounds, or both `None`, go on to
    `iter_eq`; otherwise the result is `false` without calling `next` (nor a mapping closure). The
    other iterators always run `iter_eq`.
    The result retains the final receiver and the restored second input.
    A length short circuit retains both initial iterator states. -/
@[rust_fun "core::iter::traits::iterator::Iterator::eq"]
def core.iter.traits.iterator.Iterator.eq.default {Self U Item UItem IntoIter : Type}
    (iterInst : core.iter.traits.iterator.Iterator Self Item)
    (intoInst : core.iter.traits.collect.IntoIterator U UItem IntoIter)
    (eqInst : core.cmp.PartialEq Item UItem) (self : Self) (other : U) : Result (Bool × Self × U) := do
  let (b, restore) ← intoInst.into_iter other
  let bInst := intoInst.iteratorInst
  let (equal, self, b) ← if iterInst.trusted_len && bInst.trusted_len then do
    let (_, aUpper) ← iterInst.size_hint self
    let (_, bUpper) ← bInst.size_hint b
    match aUpper, bUpper with
    | some aLen, some bLen =>
      if aLen.val = bLen.val then core.iter.traits.iterator.iterEq iterInst bInst eqInst self b
      else ok (false, self, b)
    | none, none => core.iter.traits.iterator.iterEq iterInst bInst eqInst self b
    | _, _ => ok (false, self, b)
  else core.iter.traits.iterator.iterEq iterInst bInst eqInst self b
  return (equal, self, restore b)

/-- `Iterator::ne` (core/src/iter/traits/iterator.rs, rustc 1.95): `!self.eq(other)`. -/
@[rust_fun "core::iter::traits::iterator::Iterator::ne"]
def core.iter.traits.iterator.Iterator.ne.default {Self U Item UItem IntoIter : Type}
    (iterInst : core.iter.traits.iterator.Iterator Self Item)
    (intoInst : core.iter.traits.collect.IntoIterator U UItem IntoIter)
    (eqInst : core.cmp.PartialEq Item UItem) (self : Self) (other : U) : Result (Bool × Self × U) := do
  let (equal, self, other) ← core.iter.traits.iterator.Iterator.eq.default iterInst intoInst eqInst self other
  return (!equal, self, other)

-- Canonical state results keep the Rust return value, including Unit, before
-- the updated receiver and the consumed input carrier.
@[rust_trait "core::iter::traits::collect::Extend"]
structure core.iter.traits.collect.Extend (Self : Type) (A : Type) where
  extend : forall {T : Type} {IntoIter : Type}
    (_ : core.iter.traits.collect.IntoIterator T A IntoIter), Self → T → Result (Unit × Self × T)

@[rust_trait "core::iter::traits::double_ended::DoubleEndedIterator"
  (parentClauses := ["iteratorInst"])
  (defaultMethods := ["advance_back_by", "nth_back", "rfold", "try_rfold", "rfind"])]
structure core.iter.traits.double_ended.DoubleEndedIterator (Self : Type) (Item : Type) where
  iteratorInst : core.iter.traits.iterator.Iterator Self Item
  next_back : Self → Result ((Option Item) × Self)
  advance_back_by : Self → Usize →
    Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) × Self) :=
    core.iter.traits.iterator.advanceByFromNext next_back
  nth_back : Self → Usize → Result (Option Item × Self) := fun self n => do
    let (r, self) ← advance_back_by self n
    match r with
    | .Ok _ => next_back self
    | .Err _ => return (none, self)
  rfold : {B F : Type} → core.ops.function.FnMut F (B × Item) B →
    Self → B → F → Result (B × Self × F) :=
    fun fnInst => core.iter.traits.iterator.foldFromNext next_back fnInst
  try_rfold : {B F R Residual : Type} →
    core.ops.function.FnMut F (B × Item) R → core.ops.try_trait.Try R B Residual →
    Self → B → F → Result (R × Self × F) :=
    fun fnInst tryInst => core.iter.traits.iterator.tryFoldFromNext next_back fnInst tryInst
  rfind : {P : Type} → core.ops.function.FnMut P Item Bool →
    Self → P → Result (Option Item × Self × P) :=
    fun {P} fnInst => core.iter.traits.iterator.findFromTryFold (P := P) try_rfold fnInst

def core.iter.traits.double_ended.DoubleEndedIterator.advance_back_by.default
    {Self Item : Type} (iterInst : core.iter.traits.double_ended.DoubleEndedIterator Self Item)
    (self : Self) (n : Usize) :
    Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) × Self) :=
  core.iter.traits.iterator.advanceByFromNext iterInst.next_back self n

def core.iter.traits.double_ended.DoubleEndedIterator.nth_back.default
    {Self Item : Type} (iterInst : core.iter.traits.double_ended.DoubleEndedIterator Self Item)
    (self : Self) (n : Usize) : Result (Option Item × Self) := do
  let (r, self) ← iterInst.advance_back_by self n
  match r with
  | .Ok _ => iterInst.next_back self
  | .Err _ => return (none, self)

def core.iter.traits.double_ended.DoubleEndedIterator.rfold.default
    {Self Item B F : Type} (iterInst : core.iter.traits.double_ended.DoubleEndedIterator Self Item)
    (fnInst : core.ops.function.FnMut F (B × Item) B)
    (self : Self) (init : B) (f : F) : Result (B × Self × F) :=
  core.iter.traits.iterator.foldFromNext iterInst.next_back fnInst self init f

def core.iter.traits.double_ended.DoubleEndedIterator.try_rfold.default
    {Self Item B F R Residual : Type}
    (iterInst : core.iter.traits.double_ended.DoubleEndedIterator Self Item)
    (fnInst : core.ops.function.FnMut F (B × Item) R)
    (tryInst : core.ops.try_trait.Try R B Residual)
    (self : Self) (init : B) (f : F) : Result (R × Self × F) :=
  core.iter.traits.iterator.tryFoldFromNext iterInst.next_back fnInst tryInst self init f

def core.iter.traits.double_ended.DoubleEndedIterator.rfind.default
    {Self P Item : Type}
    (iterInst : core.iter.traits.double_ended.DoubleEndedIterator Self Item)
    (fnInst : core.ops.function.FnMut P Item Bool)
    (self : Self) (predicate : P) : Result (Option Item × Self × P) :=
  core.iter.traits.iterator.findFromTryFold iterInst.try_rfold fnInst self predicate

@[rust_trait "core::iter::traits::exact_size::ExactSizeIterator"
  (parentClauses := ["iteratorInst"]) (defaultMethods := ["len"])]
structure core.iter.traits.exact_size.ExactSizeIterator (Self : Type) (Item : Type) where
  iteratorInst : core.iter.traits.iterator.Iterator Self Item
  len : Self → Result Usize := fun self => do
    let (lower, upper) ← iteratorInst.size_hint self
    match upper with
    | some upper =>
      if lower.val = upper.val then return lower else .fail .panic
    | none => .fail .panic

def core.iter.traits.exact_size.ExactSizeIterator.len.default {Self Item : Type}
    (iterInst : core.iter.traits.exact_size.ExactSizeIterator Self Item)
    (self : Self) : Result Usize := do
  let (lower, upper) ← iterInst.iteratorInst.size_hint self
  match upper with
  | some upper => if lower.val = upper.val then return lower else .fail .panic
  | none => .fail .panic

/-- `Iterator::rposition` (core/src/iter/traits/iterator.rs, rustc 1.95), the default of the
    iterators which do not override it: `let n = self.len(); self.try_rfold(n, check(predicate))
    .break_value()`, where `check(predicate)` is `move |i, x| { let i = i - 1; if predicate(x)
    { Break(i) } else { Continue(i) } }` (core is built without overflow checks: `i - 1` wraps).
    The item types of the `ExactSizeIterator` and `DoubleEndedIterator` clauses are `Self::Item`
    (kept once: `keepParams`). The result holds the final state of the iterator and of the
    predicate (the canonical state ABI of the iterator consumers, `ModelStateInputs`). -/
@[rust_fun "core::iter::traits::iterator::Iterator::rposition"
  (keepParams := [true, true, true, false, false])]
def core.iter.traits.iterator.Iterator.rposition.default {Self P Item : Type}
    (_iterInst : core.iter.traits.iterator.Iterator Self Item)
    (fnInst : core.ops.function.FnMut P Item Bool)
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator Self Item)
    (doubleInst : core.iter.traits.double_ended.DoubleEndedIterator Self Item)
    (self : Self) (predicate : P) : Result (Option Usize × Self × P) := do
  let n ← exactInst.len self
  let call : P → (Usize × Item) →
      Result (core.ops.control_flow.ControlFlow Usize Usize × P) :=
    fun predicate x => do
      let i : Usize := ⟨x.1.bv - BitVec.ofNat _ 1⟩
      let (found, predicate) ← fnInst.call_mut predicate x.2
      return (if found then .Break i else .Continue i, predicate)
  let wrapped : core.ops.function.FnMut P (Usize × Item)
      (core.ops.control_flow.ControlFlow Usize Usize) := {
    FnOnceInst := { call_once := call }
    call_mut := call
  }
  let (r, self, predicate) ← doubleInst.try_rfold wrapped
    (core.iter.traits.iterator.controlFlowTry Usize Usize) self n predicate
  return (match r with | .Break i => some i | .Continue _ => none, self, predicate)

@[rust_fun
  "core::iter::range::{core::iter::range::Step<i32>}::steps_between"]
def core.iter.range.StepI32.steps_between
    (start end_ : I32) : Result (Usize × Option Usize) := do
  if start.val > end_.val then return (0#usize, none)
  -- The nonnegative difference fits usize even when it does not fit i32.
  let steps ← UScalar.tryMk .Usize (end_.val - start.val).toNat
  return (steps, some steps)

@[rust_fun
  "core::iter::range::{core::iter::range::Step<i32>}::forward_checked"]
def core.iter.range.StepI32.forward_checked
    (start : I32) (n : Usize) : Result (Option I32) :=
  -- Check the mathematical result, not a signed conversion of the count:
  -- Rust permits crossing zero with counts larger than i32::MAX.
  ok (IScalar.tryMkOpt .I32 (start.val + Int.ofNat n.val))

@[rust_fun
  "core::iter::range::{core::iter::range::Step<i32>}::backward_checked"]
def core.iter.range.StepI32.backward_checked
    (start : I32) (n : Usize) : Result (Option I32) :=
  ok (IScalar.tryMkOpt .I32 (start.val - Int.ofNat n.val))

@[reducible, rust_trait_impl "core::iter::range::Step<i32>"]
def core.iter.range.StepI32 : core.iter.range.Step I32 := {
  cloneInst := core.clone.CloneI32
  partialOrdInst := core.cmp.PartialOrdI32
  steps_between := core.iter.range.StepI32.steps_between
  forward_checked := core.iter.range.StepI32.forward_checked
  backward_checked := core.iter.range.StepI32.backward_checked
  trusted_len := true
  range_random_access := some {
    get_unchecked := fun self idx => do
      let value ← IScalar.tryMk .I32 (self.start.val + Int.ofNat idx.val)
      return (value, self)
    may_have_side_effect := false
    is_full := true
  }
}

@[rust_fun
  "core::iter::range::{core::iter::range::Step<usize>}::steps_between"]
def core.iter.range.StepUsize.steps_between
  : Usize → Usize → Result (Usize × (Option Usize)) :=
  λ start end_ =>
    if h: start > end_ then ok ⟨ 0#usize, none ⟩ else
      let steps := Usize.ofNatCore (end_.val - start.val) (by scalar_tac)
      ok ⟨ steps, some steps ⟩

@[rust_fun
  "core::iter::range::{core::iter::range::Step<usize>}::forward_checked"]
def core.iter.range.StepUsize.forward_checked
  : Usize → Usize → Result (Option Usize) :=
  λ start n => ok (Usize.checked_add start n)

@[rust_fun
  "core::iter::range::{core::iter::range::Step<usize>}::backward_checked"]
def core.iter.range.StepUsize.backward_checked
  : Usize → Usize → Result (Option Usize) :=
  λ start n => ok (Usize.checked_sub start n)

/-- `Step for u32` (core/src/iter/range.rs `step_integer_impls!`, narrower than `usize`):
    `steps_between` is `((end - start) as usize, Some(..))` when `start <= end`, else `(0, None)`. -/
@[rust_fun
  "core::iter::range::{core::iter::range::Step<u32>}::steps_between"]
def core.iter.range.StepU32.steps_between
  : U32 → U32 → Result (Usize × (Option Usize)) :=
  λ start end_ =>
    if start.val ≤ end_.val then
      let steps : Usize := ⟨BitVec.ofNat _ (end_.val - start.val)⟩
      ok (steps, some steps)
    else ok (0#usize, none)

/-- `forward_checked`: `match u32::try_from(n) { Ok(n) => start.checked_add(n), Err(_) => None }`. -/
@[rust_fun
  "core::iter::range::{core::iter::range::Step<u32>}::forward_checked"]
def core.iter.range.StepU32.forward_checked
  : U32 → Usize → Result (Option U32) :=
  λ start n =>
    if n.val ≤ U32.max then ok (U32.checked_add start ⟨BitVec.ofNat _ n.val⟩) else ok none

/-- `backward_checked`: `match u32::try_from(n) { Ok(n) => start.checked_sub(n), Err(_) => None }`. -/
@[rust_fun
  "core::iter::range::{core::iter::range::Step<u32>}::backward_checked"]
def core.iter.range.StepU32.backward_checked
  : U32 → Usize → Result (Option U32) :=
  λ start n =>
    if n.val ≤ U32.max then ok (U32.checked_sub start ⟨BitVec.ofNat _ n.val⟩) else ok none

def core.iter.range.StepUsize.stepByNext (self : core.ops.range.Range Usize)
    (step : Usize) : Result (Option Usize × core.ops.range.Range Usize) := do
  if self.end.val = 0 then return (none, self)
  let remaining ← self.end - 1#usize
  let start := Usize.ofNatCore
    ((self.start.val + step.val) % (2 ^ UScalarTy.Usize.numBits)) (by
      exact Nat.mod_lt _ (Nat.two_pow_pos _))
  return (some self.start, { start, «end» := remaining })

def core.iter.range.StepUsize.stepByImpl :
    core.iter.adapters.step_by.StepByImpl (core.ops.range.Range Usize) Usize := {
  setup := fun self step => do
    if step.val = 0 then .fail .panic
    else
      let len := self.end.val - self.start.val
      let count := if len = 0 then 0 else 1 + (len - 1) / step.val
      let count ← UScalar.tryMk .Usize count
      return { self with «end» := count }
  next := core.iter.range.StepUsize.stepByNext
  next_back := fun self step => do
    if self.end.val = 0 then return (none, self)
    let remaining ← self.end - 1#usize
    let offset ← step * remaining
    let value ← self.start + offset
    return (some value, { self with «end» := remaining })
  size_hint := fun self => .ok (self.end, some self.end)
  fold := fun fnInst self step init f => do
    let (acc, _, f) ← core.iter.traits.iterator.foldFromNext
      (fun iter => core.iter.range.StepUsize.stepByNext iter step) fnInst self init f
    return (acc, self, f)
}

@[reducible, rust_trait_impl "core::iter::range::Step<usize>"]
def core.iter.range.StepUsize : core.iter.range.Step Usize := {
  cloneInst := core.clone.CloneUsize
  partialOrdInst := core.cmp.PartialOrdUsize
  steps_between := core.iter.range.StepUsize.steps_between
  forward_checked := core.iter.range.StepUsize.forward_checked
  backward_checked := core.iter.range.StepUsize.backward_checked
  trusted_len := true
  step_by_range := some core.iter.range.StepUsize.stepByImpl
  range_random_access := some {
    get_unchecked := fun self idx => do
      let value ← self.start + idx
      return (value, self)
    may_have_side_effect := false
    is_full := true
  }
}

@[rust_fun
  "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::Range<@A>, @A>}::next"]
def core.iter.range.IteratorRange.next
   {A : Type} (StepInst : core.iter.range.Step A) :
  core.ops.range.Range A → Result ((Option A) × (core.ops.range.Range A)) :=
  λ range => do
    let cmp ← StepInst.partialOrdInst.lt range.start range.end;
    if cmp then
      let range' ← StepInst.cloneInst.clone range.start;
      let n ← StepInst.forward_checked range' 1#usize;
      match n with
      | none => fail .panic -- Step invariants not upheld
      | some n => ok ⟨ some range.start, {range with start := n} ⟩
    else ok ⟨ none, range ⟩

@[rust_fun
  "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::Range<@A>, @A>}::step_by"]
def core.iter.range.IteratorRange.step_by
   {A : Type} (StepInst : core.iter.range.Step A) :
  core.ops.range.Range A → Usize → Result (adapters.step_by.StepBy (ops.range.Range A)) :=
  λ range step_by => do
    if step_by.val = 0 then .fail .panic
    else
      let iter ← match StepInst.step_by_range with
        | none => .ok range
        | some spec => spec.setup range step_by
      return { iter, step_by }

@[rust_fun
  "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::Range<@A>, @A>}::enumerate"]
def core.iter.range.IteratorRange.enumerate
   {A : Type} (_StepInst : core.iter.range.Step A)
  (range : core.ops.range.Range A) : Result (adapters.enumerate.Enumerate (ops.range.Range A)) :=
  .ok { iter := range, count := 0#usize }

@[rust_fun
  "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::Range<@A>, @A>}::take"]
def core.iter.range.IteratorRange.take
   {A : Type} (_StepInst : core.iter.range.Step A)
  (iter : core.ops.range.Range A) (n : Usize) : Result (adapters.take.Take (ops.range.Range A)) :=
  .ok { iter, n }

@[rust_fun
  "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::Range<@A>, @A>}::size_hint"]
def core.iter.range.IteratorRange.size_hint {A : Type} (stepInst : core.iter.range.Step A)
    (self : core.ops.range.Range A) : Result (Usize × Option Usize) := do
  if ← stepInst.partialOrdInst.lt self.start self.end then
    stepInst.steps_between self.start self.end
  else return (0#usize, some 0#usize)

@[rust_fun
  "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::Range<@A>, @A>}::count"]
def core.iter.range.IteratorRange.count {A : Type} (stepInst : core.iter.range.Step A)
    (self : core.ops.range.Range A) : Result (Usize × core.ops.range.Range A) := do
  let (_, upper) ← core.iter.range.IteratorRange.size_hint stepInst self
  match upper with
  | none => .fail .panic
  | some n => return (n, self)

@[rust_fun
  "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::Range<@A>, @A>}::nth"]
def core.iter.range.IteratorRange.nth {A : Type} (stepInst : core.iter.range.Step A)
    (self : core.ops.range.Range A) (n : Usize) :
    Result (Option A × core.ops.range.Range A) := do
  let start ← stepInst.cloneInst.clone self.start
  match ← stepInst.forward_checked start n with
  | some plusN =>
    if ← stepInst.partialOrdInst.lt plusN self.end then
      let next ← stepInst.cloneInst.clone plusN
      match ← stepInst.forward_checked next 1#usize with
      | none => .fail .panic
      | some start => return (some plusN, { self with start })
    else
      return (none, { self with start := ← stepInst.cloneInst.clone self.end })
  | none => return (none, { self with start := ← stepInst.cloneInst.clone self.end })

@[rust_fun
  "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::Range<@A>, @A>}::advance_by"]
def core.iter.range.IteratorRange.advance_by {A : Type} (stepInst : core.iter.range.Step A)
    (self : core.ops.range.Range A) (n : Usize) :
    Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) × core.ops.range.Range A) := do
  let (lower, upper) ← stepInst.steps_between self.start self.end
  let available := upper.getD lower
  let taken := if available.val < n.val then available else n
  let start ← stepInst.cloneInst.clone self.start
  match ← stepInst.forward_checked start taken with
  | none => .fail .panic
  | some start =>
    let remaining ← core.num.nonzero.NonZero.new (← n - taken)
    return (match remaining with | none => .Ok () | some n => .Err n, { self with start })

@[rust_fun
  "core::iter::range::{core::iter::traits::double_ended::DoubleEndedIterator<core::ops::range::Range<@A>, @A>}::next_back"]
def core.iter.range.DoubleEndedIteratorRange.next_back {A : Type}
    (stepInst : core.iter.range.Step A) (self : core.ops.range.Range A) :
    Result (Option A × core.ops.range.Range A) := do
  if ← stepInst.partialOrdInst.lt self.start self.end then
    let end_ ← stepInst.cloneInst.clone self.end
    match ← stepInst.backward_checked end_ 1#usize with
    | none => .fail .panic
    | some end_ =>
      return (some (← stepInst.cloneInst.clone end_), { self with «end» := end_ })
  else return (none, self)

@[rust_fun
  "core::iter::range::{core::iter::traits::double_ended::DoubleEndedIterator<core::ops::range::Range<@A>, @A>}::nth_back"]
def core.iter.range.DoubleEndedIteratorRange.nth_back {A : Type}
    (stepInst : core.iter.range.Step A) (self : core.ops.range.Range A) (n : Usize) :
    Result (Option A × core.ops.range.Range A) := do
  let end_ ← stepInst.cloneInst.clone self.end
  match ← stepInst.backward_checked end_ n with
  | some minusN =>
    if ← stepInst.partialOrdInst.gt minusN self.start then
      match ← stepInst.backward_checked minusN 1#usize with
      | none => .fail .panic
      | some end_ => return (some (← stepInst.cloneInst.clone end_), { self with «end» := end_ })
    else return (none, { self with «end» := ← stepInst.cloneInst.clone self.start })
  | none => return (none, { self with «end» := ← stepInst.cloneInst.clone self.start })

@[rust_fun
  "core::iter::range::{core::iter::traits::double_ended::DoubleEndedIterator<core::ops::range::Range<@A>, @A>}::advance_back_by"]
def core.iter.range.DoubleEndedIteratorRange.advance_back_by {A : Type}
    (stepInst : core.iter.range.Step A) (self : core.ops.range.Range A) (n : Usize) :
    Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) × core.ops.range.Range A) := do
  let (lower, upper) ← stepInst.steps_between self.start self.end
  let available := upper.getD lower
  let taken := if available.val < n.val then available else n
  let end_ ← stepInst.cloneInst.clone self.end
  match ← stepInst.backward_checked end_ taken with
  | none => .fail .panic
  | some end_ =>
    let remaining ← core.num.nonzero.NonZero.new (← n - taken)
    return (match remaining with | none => .Ok () | some n => .Err n, { self with «end» := end_ })

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::ops::range::Range<@A>, @A>"]
def core.iter.traits.iterator.IteratorRange {A : Type}
  (StepInst : core.iter.range.Step A) : core.iter.traits.iterator.Iterator
  (core.ops.range.Range A) A := {
  next := core.iter.range.IteratorRange.next StepInst
  nth := core.iter.range.IteratorRange.nth StepInst
  advance_by := core.iter.range.IteratorRange.advance_by StepInst
  size_hint := core.iter.range.IteratorRange.size_hint StepInst
  count := core.iter.range.IteratorRange.count StepInst
  trusted_len := StepInst.trusted_len
  step_by_impl := StepInst.step_by_range
  random_access := StepInst.range_random_access
  fused := true
  step_by := core.iter.range.IteratorRange.step_by StepInst
  enumerate := core.iter.range.IteratorRange.enumerate StepInst
  take := core.iter.range.IteratorRange.take StepInst
}

/-- Native `next` advances before it returns the previous start.
    Integer overflow fails for checked callers. -/
@[rust_fun
  "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeFrom<@A>, @A>}::next"]
def core.iter.range.IteratorRangeFrom.next {A : Type}
    (stepInst : core.iter.range.Step A) (self : core.ops.range.RangeFrom A) :
    -- Return the next state.
    Result (Option A × core.ops.range.RangeFrom A) := do
  let start ← stepInst.forward (← stepInst.cloneInst.clone self.start) 1#usize
  return (some self.start, { start })

@[rust_fun
  "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeFrom<@A>, @A>}::size_hint"]
def core.iter.range.IteratorRangeFrom.size_hint {A : Type}
    (_stepInst : core.iter.range.Step A) (_self : core.ops.range.RangeFrom A) :
    -- No finite upper bound.
    Result (Usize × Option Usize) :=
  .ok (Usize.ofNatCore Usize.max (by scalar_tac), none)

@[rust_fun
  "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeFrom<@A>, @A>}::nth"]
def core.iter.range.IteratorRangeFrom.nth {A : Type}
    (stepInst : core.iter.range.Step A)
    -- The result includes the advanced source.
    (self : core.ops.range.RangeFrom A) (n : Usize) :
    Result (Option A × core.ops.range.RangeFrom A) := do
  -- Skip the first n items.
  let value ← stepInst.forward (← stepInst.cloneInst.clone self.start) n
  -- Advance beyond the returned value.
  let start ← stepInst.forward (← stepInst.cloneInst.clone value) 1#usize
  return (some value, { start })

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::ops::range::RangeFrom<@A>, @A>"]
def core.iter.traits.iterator.IteratorRangeFrom {A : Type}
    (stepInst : core.iter.range.Step A) :
    core.iter.traits.iterator.Iterator (core.ops.range.RangeFrom A) A := {
  -- Native RangeFrom uses the default fold operations.
  next := core.iter.range.IteratorRangeFrom.next stepInst
  size_hint := core.iter.range.IteratorRangeFrom.size_hint stepInst
  nth := core.iter.range.IteratorRangeFrom.nth stepInst
  trusted_len := stepInst.trusted_len
  fused := true
}

@[rust_fun
  "core::iter::range::{core::iter::traits::iterator::Iterator<core::ops::range::RangeFrom<@A>, @A>}::try_for_each"]
def core.iter.range.IteratorRangeFrom.try_for_each {A F R Residual : Type}
    (stepInst : core.iter.range.Step A)
    -- The callback returns a native Try value.
    (fnInst : core.ops.function.FnMut F A R)
    (tryInst : core.ops.try_trait.Try R Unit Residual)
    -- Preserve the advanced source and callback state.
    (self : core.ops.range.RangeFrom A) (f : F) :
    Result (R × core.ops.range.RangeFrom A × F) :=
  core.iter.traits.iterator.Iterator.try_for_each.default
    (core.iter.traits.iterator.IteratorRangeFrom stepInst) fnInst tryInst self f

@[reducible, rust_trait_impl
  "core::iter::traits::double_ended::DoubleEndedIterator<core::ops::range::Range<@A>, @A>"]
def core.iter.traits.double_ended.DoubleEndedIteratorRange {A : Type}
    (stepInst : core.iter.range.Step A) :
    core.iter.traits.double_ended.DoubleEndedIterator (core.ops.range.Range A) A := {
  iteratorInst := core.iter.traits.iterator.IteratorRange stepInst
  next_back := core.iter.range.DoubleEndedIteratorRange.next_back stepInst
  nth_back := core.iter.range.DoubleEndedIteratorRange.nth_back stepInst
  advance_back_by := core.iter.range.DoubleEndedIteratorRange.advance_back_by stepInst
}

@[rust_fun
  "core::iter::adapters::take::{core::iter::traits::iterator::Iterator<core::iter::adapters::take::Take<@I>, @Clause0_Item>}::next"]
def core.iter.adapters.take.IteratorTake.next {I Item : Type}
    (iterInst : core.iter.traits.iterator.Iterator I Item)
    (self : core.iter.adapters.take.Take I) :
    Result (Option Item × core.iter.adapters.take.Take I) := do
  if self.n.val = 0 then return (none, self)
  let n ← self.n - 1#usize
  let (item, iter) ← iterInst.next self.iter
  return (item, { iter, n })

@[rust_fun
  "core::iter::adapters::take::{core::iter::traits::iterator::Iterator<core::iter::adapters::take::Take<@I>, @Clause0_Item>}::nth"]
def core.iter.adapters.take.IteratorTake.nth {I Item : Type}
    (iterInst : core.iter.traits.iterator.Iterator I Item)
    (self : core.iter.adapters.take.Take I) (n : Usize) :
    Result (Option Item × core.iter.adapters.take.Take I) := do
  if self.n.val > n.val then
    let remaining ← self.n - (← n + 1#usize)
    let (item, iter) ← iterInst.nth self.iter n
    return (item, { iter, n := remaining })
  else if self.n.val > 0 then
    let (_, iter) ← iterInst.nth self.iter (← self.n - 1#usize)
    return (none, { iter, n := 0#usize })
  else return (none, self)

@[rust_fun
  "core::iter::adapters::take::{core::iter::traits::iterator::Iterator<core::iter::adapters::take::Take<@I>, @Clause0_Item>}::advance_by"]
def core.iter.adapters.take.IteratorTake.advance_by {I Item : Type}
    (iterInst : core.iter.traits.iterator.Iterator I Item)
    (self : core.iter.adapters.take.Take I) (n : Usize) :
    Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) ×
      core.iter.adapters.take.Take I) := do
  let amount := if self.n.val < n.val then self.n else n
  let (r, iter) ← iterInst.advance_by self.iter amount
  let remainder := match r with | .Ok _ => 0#usize | .Err n => n.val
  let advanced ← amount - remainder
  let remaining ← self.n - advanced
  let error ← core.num.nonzero.NonZero.new (← n - advanced)
  return (match error with | none => .Ok () | some n => .Err n, { iter, n := remaining })

@[rust_fun
  "core::iter::adapters::take::{core::iter::traits::iterator::Iterator<core::iter::adapters::take::Take<@I>, @Clause0_Item>}::size_hint"]
def core.iter.adapters.take.IteratorTake.size_hint {I Item : Type}
    (iterInst : core.iter.traits.iterator.Iterator I Item)
    (self : core.iter.adapters.take.Take I) : Result (Usize × Option Usize) := do
  if self.n.val = 0 then return (0#usize, some 0#usize)
  let (lo, hi) ← iterInst.size_hint self.iter
  let lo := if lo.val < self.n.val then lo else self.n
  let hi := match hi with
    | some n => if n.val < self.n.val then n else self.n
    | none => self.n
  return (lo, some hi)

@[rust_fun
  "core::iter::adapters::take::{core::iter::traits::iterator::Iterator<core::iter::adapters::take::Take<@I>, @Clause0_Item>}::try_fold"]
def core.iter.adapters.take.IteratorTake.try_fold {I Item B F R Residual : Type}
    (iterInst : core.iter.traits.iterator.Iterator I Item)
    (fnInst : core.ops.function.FnMut F (B × Item) R)
    (tryInst : core.ops.try_trait.Try R B Residual)
    (self : core.iter.adapters.take.Take I) (init : B) (f : F) :
    Result (R × core.iter.adapters.take.Take I × F) := do
  if self.n.val = 0 then return (← tryInst.from_output init, self, f)
  let call : (Usize × F) → (B × Item) → Result (core.ops.control_flow.ControlFlow R B × (Usize × F)) := fun state x => do
    let n ← state.1 - 1#usize
    let (r, f) ← fnInst.call_mut state.2 x
    if n.val = 0 then
      return (.Break r, (n, f))
    else
      match ← tryInst.branch r with
      | .Continue acc => return (.Continue acc, (n, f))
      | .Break residual =>
        return (.Break (← tryInst.FromResidualInst.from_residual residual), (n, f))
  let wrapped : core.ops.function.FnMut (Usize × F) (B × Item)
      (core.ops.control_flow.ControlFlow R B) := {
    FnOnceInst := { call_once := call }
    call_mut := call
  }
  let (r, iter, n, f) ← iterInst.try_fold wrapped
    (core.iter.traits.iterator.controlFlowTry R B) self.iter init (self.n, f)
  let r ← match r with
    | .Break r => .ok r
    | .Continue acc => tryInst.from_output acc
  return (r, { iter, n }, f)

def core.iter.adapters.take.foldIndexed {I Item B F : Type}
    (access : core.iter.traits.iterator.RandomAccess I Item)
    (fnInst : core.ops.function.FnMut F (B × Item) B)
    (iter : I) (index remaining : Usize) (init : B) (f : F) :
    Result (B × I × F) := do
  if remaining.val = 0 then return (init, iter, f)
  let (item, iter) ← access.get_unchecked iter index
  let (acc, f) ← fnInst.call_mut f (init, item)
  core.iter.adapters.take.foldIndexed access fnInst iter
    (← index + 1#usize) (← remaining - 1#usize) acc f
partial_fixpoint

@[rust_fun
  "core::iter::adapters::take::{core::iter::traits::iterator::Iterator<core::iter::adapters::take::Take<@I>, @Clause0_Item>}::fold"]
def core.iter.adapters.take.IteratorTake.fold {I Item B F : Type}
    (iterInst : core.iter.traits.iterator.Iterator I Item)
    (fnInst : core.ops.function.FnMut F (B × Item) B)
    (self : core.iter.adapters.take.Take I) (init : B) (f : F) :
    Result (B × core.iter.adapters.take.Take I × F) := do
  if let some access := iterInst.random_access then
    if access.is_full then
      let (len, _) ← iterInst.size_hint self.iter
      let remaining := if self.n.val < len.val then self.n else len
      let (acc, iter, f) ← core.iter.adapters.take.foldIndexed access fnInst
        self.iter 0#usize remaining init f
      return (acc, { self with iter }, f)
  let never : core.ops.try_trait.Try B B Empty := {
    FromResidualInst := { from_residual := fun impossible => nomatch impossible }
    from_output := fun acc => .ok acc
    branch := fun acc => .ok (.Continue acc)
  }
  core.iter.adapters.take.IteratorTake.try_fold iterInst fnInst never self init f

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::iter::adapters::take::Take<@I>, @Clause0_Item>"]
def core.iter.traits.iterator.IteratorTake {I Item : Type}
    (iterInst : core.iter.traits.iterator.Iterator I Item) :
    core.iter.traits.iterator.Iterator (core.iter.adapters.take.Take I) Item := {
  next := core.iter.adapters.take.IteratorTake.next iterInst
  nth := core.iter.adapters.take.IteratorTake.nth iterInst
  advance_by := core.iter.adapters.take.IteratorTake.advance_by iterInst
  size_hint := core.iter.adapters.take.IteratorTake.size_hint iterInst
  fold := core.iter.adapters.take.IteratorTake.fold iterInst
  try_fold := core.iter.adapters.take.IteratorTake.try_fold iterInst
  trusted_len := iterInst.trusted_len
  fused := iterInst.fused
}

@[rust_fun
  "core::iter::adapters::take::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::take::Take<@I>, @Clause0_Clause0_Item>}::next_back"]
def core.iter.adapters.take.DoubleEndedIteratorTake.next_back {I Item : Type}
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item)
    (self : core.iter.adapters.take.Take I) :
    Result (Option Item × core.iter.adapters.take.Take I) := do
  if self.n.val = 0 then return (none, self)
  let n ← self.n - 1#usize
  let len ← exactInst.len self.iter
  let index ← UScalar.tryMk .Usize (len.val - self.n.val)
  let (item, iter) ← backInst.nth_back self.iter index
  return (item, { iter, n })

@[rust_fun
  "core::iter::adapters::take::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::take::Take<@I>, @Clause0_Clause0_Item>}::nth_back"]
def core.iter.adapters.take.DoubleEndedIteratorTake.nth_back {I Item : Type}
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item)
    (self : core.iter.adapters.take.Take I) (n : Usize) :
    Result (Option Item × core.iter.adapters.take.Take I) := do
  let len ← exactInst.len self.iter
  if self.n.val > n.val then
    let skip ← UScalar.tryMk .Usize (len.val - self.n.val)
    let index ← skip + n
    let remaining ← self.n - (← n + 1#usize)
    let (item, iter) ← backInst.nth_back self.iter index
    return (item, { iter, n := remaining })
  else if len.val > 0 then
    let (_, iter) ← backInst.nth_back self.iter (← len - 1#usize)
    return (none, { self with iter })
  else return (none, self)

def core.iter.adapters.take.trimBack {I Item : Type}
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item)
    (self : core.iter.adapters.take.Take I) :
    Result (Bool × core.iter.adapters.take.Take I) := do
  if self.n.val = 0 then return (false, self)
  let len ← exactInst.len self.iter
  if len.val > self.n.val then
    let skip ← len - self.n
    let (item, iter) ← backInst.nth_back self.iter (← skip - 1#usize)
    return (item.isSome, { self with iter })
  else return (true, self)

@[rust_fun
  "core::iter::adapters::take::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::take::Take<@I>, @Clause0_Clause0_Item>}::try_rfold"]
def core.iter.adapters.take.DoubleEndedIteratorTake.try_rfold {I Item B F R Residual : Type}
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item)
    (fnInst : core.ops.function.FnMut F (B × Item) R)
    (tryInst : core.ops.try_trait.Try R B Residual)
    (self : core.iter.adapters.take.Take I) (init : B) (f : F) :
    Result (R × core.iter.adapters.take.Take I × F) := do
  let (proceed, self) ← core.iter.adapters.take.trimBack backInst exactInst self
  if !proceed then return (← tryInst.from_output init, self, f)
  let (r, iter, f) ← backInst.try_rfold fnInst tryInst self.iter init f
  return (r, { self with iter }, f)

@[rust_fun
  "core::iter::adapters::take::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::take::Take<@I>, @Clause0_Clause0_Item>}::rfold"]
def core.iter.adapters.take.DoubleEndedIteratorTake.rfold {I Item B F : Type}
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item)
    (fnInst : core.ops.function.FnMut F (B × Item) B)
    (self : core.iter.adapters.take.Take I) (init : B) (f : F) :
    Result (B × core.iter.adapters.take.Take I × F) := do
  let (proceed, self) ← core.iter.adapters.take.trimBack backInst exactInst self
  if !proceed then return (init, self, f)
  let (acc, iter, f) ← backInst.rfold fnInst self.iter init f
  return (acc, { self with iter }, f)

@[rust_fun
  "core::iter::adapters::take::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::take::Take<@I>, @Clause0_Clause0_Item>}::advance_back_by"]
def core.iter.adapters.take.DoubleEndedIteratorTake.advance_back_by {I Item : Type}
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item)
    (self : core.iter.adapters.take.Take I) (n : Usize) :
    Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) ×
      core.iter.adapters.take.Take I) := do
  let len ← exactInst.len self.iter
  let trim ← UScalar.tryMk .Usize (len.val - self.n.val)
  let amount ← UScalar.tryMk .Usize (min (trim.val + n.val) Usize.max)
  let (r, iter) ← backInst.advance_back_by self.iter amount
  let remainder := match r with | .Ok _ => 0#usize | .Err n => n.val
  let advancedInner ← amount - remainder
  let advanced ← advancedInner - trim
  let remaining ← self.n - advanced
  let error ← core.num.nonzero.NonZero.new (← n - advanced)
  return (match error with | none => .Ok () | some n => .Err n, { iter, n := remaining })

@[reducible, rust_trait_impl
  "core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::take::Take<@I>, @Clause0_Clause0_Item>"]
def core.iter.traits.double_ended.DoubleEndedIteratorTake {I Item : Type}
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item) :
    core.iter.traits.double_ended.DoubleEndedIterator (core.iter.adapters.take.Take I) Item := {
  iteratorInst := core.iter.traits.iterator.IteratorTake backInst.iteratorInst
  next_back := core.iter.adapters.take.DoubleEndedIteratorTake.next_back backInst exactInst
  nth_back := core.iter.adapters.take.DoubleEndedIteratorTake.nth_back backInst exactInst
  advance_back_by := core.iter.adapters.take.DoubleEndedIteratorTake.advance_back_by backInst exactInst
  rfold := core.iter.adapters.take.DoubleEndedIteratorTake.rfold backInst exactInst
  try_rfold := core.iter.adapters.take.DoubleEndedIteratorTake.try_rfold backInst exactInst
}

@[reducible, rust_trait_impl
  "core::iter::traits::exact_size::ExactSizeIterator<core::iter::adapters::take::Take<@I>, @Clause0_Clause0_Item>"]
def core.iter.traits.exact_size.ExactSizeIteratorTake {I Item : Type}
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item) :
    core.iter.traits.exact_size.ExactSizeIterator (core.iter.adapters.take.Take I) Item := {
  iteratorInst := core.iter.traits.iterator.IteratorTake exactInst.iteratorInst
}

def core.iter.adapters.step_by.backIndex {I Item : Type}
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item)
    (self : core.iter.adapters.step_by.StepBy I) : Result Usize := do
  let len ← exactInst.len self.iter
  let remainder ← len % self.step_by
  if self.first_take then
    if remainder.val = 0 then self.step_by - 1#usize else remainder - 1#usize
  else return remainder

@[rust_fun
  "core::iter::adapters::step_by::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Clause0_Item>}::next_back"]
def core.iter.adapters.step_by.DoubleEndedIteratorStepBy.next_back {I Item : Type}
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item)
    (self : core.iter.adapters.step_by.StepBy I) :
    Result (Option Item × core.iter.adapters.step_by.StepBy I) := do
  if let some spec := backInst.iteratorInst.step_by_impl then
    let (item, iter) ← spec.next_back self.iter self.step_by
    return (item, { self with iter })
  let index ← core.iter.adapters.step_by.backIndex exactInst self
  let (item, iter) ← backInst.nth_back self.iter index
  return (item, { self with iter })

@[rust_fun
  "core::iter::adapters::step_by::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Clause0_Item>}::nth_back"]
def core.iter.adapters.step_by.DoubleEndedIteratorStepBy.nth_back {I Item : Type}
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item)
    (self : core.iter.adapters.step_by.StepBy I) (n : Usize) :
    Result (Option Item × core.iter.adapters.step_by.StepBy I) := do
  if let some spec := backInst.iteratorInst.step_by_impl then
    let next := fun iter => spec.next_back iter self.step_by
    let (r, iter) ← core.iter.traits.iterator.advanceByFromNext next self.iter n
    match r with
    | .Err _ => return (none, { self with iter })
    | .Ok _ =>
      let (item, iter) ← next iter
      return (item, { self with iter })
  let offset ← core.iter.adapters.step_by.backIndex exactInst self
  let index ← UScalar.tryMk .Usize (min (n.val * self.step_by.val + offset.val) Usize.max)
  let (item, iter) ← backInst.nth_back self.iter index
  return (item, { self with iter })

/-- The first reverse fold step trims the tail; subsequent steps use the
    original stride directly. This flag belongs to the fold closure, not StepBy. -/
def core.iter.adapters.step_by.rfoldNext {I Item : Type}
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item)
    (state : Bool × core.iter.adapters.step_by.StepBy I) :
    Result (Option Item × (Bool × core.iter.adapters.step_by.StepBy I)) := do
  let (first, self) := state
  if first || backInst.iteratorInst.step_by_impl.isSome then
    let (item, self) ←
      core.iter.adapters.step_by.DoubleEndedIteratorStepBy.next_back backInst exactInst self
    return (item, (false, self))
  let (item, iter) ← backInst.nth_back self.iter (← self.step_by - 1#usize)
  return (item, (false, { self with iter }))

@[rust_fun
  "core::iter::adapters::step_by::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Clause0_Item>}::rfold"]
def core.iter.adapters.step_by.DoubleEndedIteratorStepBy.rfold {I Item B F : Type}
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item)
    (fnInst : core.ops.function.FnMut F (B × Item) B)
    (self : core.iter.adapters.step_by.StepBy I) (init : B) (f : F) :
    Result (B × core.iter.adapters.step_by.StepBy I × F) := do
  let (acc, state, f) ← core.iter.traits.iterator.foldFromNext
    (core.iter.adapters.step_by.rfoldNext backInst exactInst) fnInst (true, self) init f
  return (acc, state.2, f)

@[rust_fun
  "core::iter::adapters::step_by::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Clause0_Item>}::try_rfold"]
def core.iter.adapters.step_by.DoubleEndedIteratorStepBy.try_rfold {I Item B F R Residual : Type}
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item)
    (fnInst : core.ops.function.FnMut F (B × Item) R)
    (tryInst : core.ops.try_trait.Try R B Residual)
    (self : core.iter.adapters.step_by.StepBy I) (init : B) (f : F) :
    Result (R × core.iter.adapters.step_by.StepBy I × F) := do
  let (r, state, f) ← core.iter.traits.iterator.tryFoldFromNext
    (core.iter.adapters.step_by.rfoldNext backInst exactInst) fnInst tryInst (true, self) init f
  return (r, state.2, f)

@[reducible, rust_trait_impl
  "core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Clause0_Item>"]
def core.iter.traits.double_ended.DoubleEndedIteratorStepBy {I Item : Type}
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item) :
    core.iter.traits.double_ended.DoubleEndedIterator (core.iter.adapters.step_by.StepBy I) Item := {
  iteratorInst := core.iter.traits.iterator.IteratorStepBy backInst.iteratorInst
  next_back := core.iter.adapters.step_by.DoubleEndedIteratorStepBy.next_back backInst exactInst
  nth_back := core.iter.adapters.step_by.DoubleEndedIteratorStepBy.nth_back backInst exactInst
  rfold := core.iter.adapters.step_by.DoubleEndedIteratorStepBy.rfold backInst exactInst
  try_rfold := core.iter.adapters.step_by.DoubleEndedIteratorStepBy.try_rfold backInst exactInst
}

@[reducible, rust_trait_impl
  "core::iter::traits::exact_size::ExactSizeIterator<core::iter::adapters::step_by::StepBy<@I>, @Clause0_Clause0_Item>"]
def core.iter.traits.exact_size.ExactSizeIteratorStepBy {I Item : Type}
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item) :
    core.iter.traits.exact_size.ExactSizeIterator (core.iter.adapters.step_by.StepBy I) Item := {
  iteratorInst := core.iter.traits.iterator.IteratorStepBy exactInst.iteratorInst
}

@[reducible, rust_trait_impl
  "core::iter::traits::exact_size::ExactSizeIterator<core::ops::range::Range<usize>, usize>"]
def core.iter.traits.exact_size.ExactSizeIteratorRangeUsize :
    core.iter.traits.exact_size.ExactSizeIterator (core.ops.range.Range Usize) Usize := {
  iteratorInst := core.iter.traits.iterator.IteratorRange core.iter.range.StepUsize
}

@[rust_type "core::iter::adapters::map::Map"]
structure core.iter.adapters.map.Map (I : Type u) (F : Type v) where
  iter : I
  f : F
