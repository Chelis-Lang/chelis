import Aeneas.Std.Slice
import Aeneas.Std.Array.Array
import Aeneas.Std.Scalar.Notations
import Aeneas.Std.Core.Cmp
import Aeneas.Std.Core.Core
import Aeneas.Std.Core.Result

/-!
# `<[T]>::as_chunks`, `binary_search`, `partition_point` and `fill`

Transcriptions of core/src/slice/mod.rs and core/src/slice/specialize.rs (rustc 1.95.0-nightly
efc9e1b50 2026-02-06). `binary_search` and `partition_point` return the index std's algorithm
finds (among equal elements it is not the first one), and call the comparison or the predicate on
the same elements in the same order, so the calls of a stateful predicate are the native ones.
-/

namespace Aeneas.Std

open Result

/-- The elements of `l` in consecutive groups of `n`; the last group is shorter when `n` does not
    divide the length. -/
def core.slice.chunkList {T : Type} (n : Nat) (hn : 0 < n) (l : List T) : List (List T) :=
  if h : l = [] then [] else l.take n :: core.slice.chunkList n hn (l.drop n)
termination_by l.length
decreasing_by
  have : l.length ≠ 0 := by simpa [List.length_eq_zero_iff] using h
  simp only [List.length_drop]; omega

/-- A list as a slice (unreachable failure: every caller's list is no longer than a slice). -/
def core.slice.ofList {T : Type} (l : List T) : Result (Slice T) :=
  if h : l.length ≤ Usize.max then ok ⟨l, h⟩ else fail .panic

/-- `<[T]>::as_chunks::<N>` (core/src/slice/mod.rs): `assert!(N != 0)`; the first
    `len / N * N` elements as `N`-element arrays, and the remainder (a shared borrow: the
    elements are copied into the model). -/
@[rust_fun "core::slice::{[@T]}::as_chunks"]
def core.slice.Slice.as_chunks {T : Type} (N : Usize) (s : Slice T) :
    Result (Slice (Array T N) × Slice T) :=
  if hn : N.val = 0 then fail .panic
  else do
    let split := s.length / N.val * N.val
    let arrays ← (core.slice.chunkList N.val (Nat.pos_of_ne_zero hn) (s.val.take split)).mapM
      fun chunk => if h : chunk.length = N.val then ok (⟨chunk, h⟩ : Array T N) else fail .panic
    let arrays ← core.slice.ofList arrays
    let rest ← core.slice.ofList (s.val.drop split)
    ok (arrays, rest)

/-- The loop of `<[T]>::binary_search_by` (core/src/slice/mod.rs): while `size > 1`,
    `half = size / 2`, `mid = base + half`, `cmp = f(&self[mid])`,
    `base = if cmp == Greater { base } else { mid }`, `size -= half`. -/
def core.slice.binarySearchLoop {T F : Type} (call : F → T → Result (Ordering × F)) (l : List T)
    (base size : Nat) (f : F) : Result (Nat × F) :=
  if size > 1 then do
    let half := size / 2
    let mid := base + half
    let x ← match l[mid]? with
      | some x => ok x
      | none => fail .panic
    let (cmp, f) ← call f x
    let base := match cmp with
      | .gt => base
      | _ => mid
    core.slice.binarySearchLoop call l base (size - half) f
  else ok (base, f)
termination_by size
decreasing_by omega

/-- `<[T]>::binary_search_by` (core/src/slice/mod.rs), with the comparison's call `call` threading
    the closure state: `Err(0)` for an empty slice; else after the loop `cmp = f(&self[base])`,
    `Ok(base)` if `cmp == Equal`, else `Err(base + (cmp == Less) as usize)`. -/
def core.slice.Slice.binary_search_by_with {T F : Type} (call : F → T → Result (Ordering × F))
    (s : Slice T) (f : F) : Result (core.result.Result Usize Usize × F) :=
  if s.length = 0 then ok (.Err 0#usize, f)
  else do
    let (base, f) ← core.slice.binarySearchLoop call s.val 0 s.length f
    let x ← match s.val[base]? with
      | some x => ok x
      | none => fail .panic
    let (cmp, f) ← call f x
    let index (n : Nat) : Result Usize :=
      if h : n < 2 ^ UScalarTy.Usize.numBits then ok (Usize.ofNatCore n h) else fail .panic
    match cmp with
    | .eq => ok (.Ok (← index base), f)
    | .lt => ok (.Err (← index (base + 1)), f)
    | .gt => ok (.Err (← index base), f)

/-- `<[T]>::binary_search` (core/src/slice/mod.rs): `self.binary_search_by(|p| p.cmp(x))`. -/
@[rust_fun "core::slice::{[@T]}::binary_search"]
def core.slice.Slice.binary_search {T : Type} (ordInst : core.cmp.Ord T) (s : Slice T) (x : T) :
    Result (core.result.Result Usize Usize) := do
  let (r, _) ← core.slice.Slice.binary_search_by_with
    (fun (_ : Unit) p => do ok (← ordInst.cmp p x, ())) s ()
  ok r

/-- `<[T]>::partition_point` (core/src/slice/mod.rs), with the predicate's call `call` threading
    the closure state: `self.binary_search_by(|x| if pred(x) { Less } else { Greater })
    .unwrap_or_else(|i| i)`. The result is the index, the slice (a shared borrow: unchanged) and
    the final closure state, the layout of the closure-state instances (`closure_state_models` of
    ModelStateABI.ml). -/
def core.slice.Slice.partition_point_with {T P : Type} (call : P → T → Result (Bool × P))
    (s : Slice T) (pred : P) : Result (Usize × Slice T × P) := do
  let (r, pred) ← core.slice.Slice.binary_search_by_with
    (fun pred x => do
      let (b, pred) ← call pred x
      ok (if b then Ordering.lt else Ordering.gt, pred)) s pred
  match r with
  | .Ok i => ok (i, s, pred)
  | .Err i => ok (i, s, pred)

/-- `<[T]>::partition_point` (core/src/slice/mod.rs): see `partition_point_with`. Only `call_mut`
    is called. -/
@[rust_fun "core::slice::{[@T]}::partition_point"]
def core.slice.Slice.partition_point {T P : Type} (fnInst : core.ops.function.FnMut P T Bool)
    (s : Slice T) (pred : P) : Result Usize := do
  let (i, _, _) ← core.slice.Slice.partition_point_with fnInst.call_mut s pred
  ok i

/-- `<[T]>::fill` (core/src/slice/mod.rs, `SpecFill` of core/src/slice/specialize.rs): every
    element but the last `clone_from(&value)`, the last receives `value` (nothing for an empty
    slice). The `TrivialClone` specialization writes copies of `value` instead, which is the same
    for the types it applies to (their `clone` is a copy). -/
@[rust_fun "core::slice::{[@T]}::fill"]
def core.slice.Slice.fill {T : Type} (cloneInst : core.clone.Clone T) (s : Slice T) (value : T) :
    Result (Slice T) :=
  match s.val.getLast? with
  | none => ok s
  | some _ => do
    let init ← s.val.dropLast.mapM fun el => cloneInst.clone_from el value
    core.slice.ofList (init ++ [value])

end Aeneas.Std
