import Aeneas.Std.Alloc
import Aeneas.Std.String
import Aeneas.Std.Core.Core
import Aeneas.Std.Core.Ops

namespace Aeneas.Std

@[rust_trait "core::borrow::Borrow"]
structure core.borrow.Borrow (Self Borrowed : Type) where
  borrow : Self → Result Borrowed

@[rust_fun "core::borrow::{core::borrow::Borrow<@T, @T>}::borrow"]
def core.borrow.BorrowSelf.borrow {T : Type} (value : T) : Result T := .ok value

@[reducible, rust_trait_impl "core::borrow::Borrow<@T, @T>"]
def core.borrow.BorrowSelf (T : Type) : core.borrow.Borrow T T := {
  borrow := core.borrow.BorrowSelf.borrow
}

/-- `impl<T: ?Sized> Borrow<T> for &T` (core/src/borrow.rs): `&**self`, the referenced value. -/
@[rust_fun "core::borrow::{core::borrow::Borrow<&'a @T, @T>}::borrow"]
def core.borrow.BorrowShared.borrow {T : Type} (value : T) : Result T := .ok value

@[reducible, rust_trait_impl "core::borrow::Borrow<&'a @T, @T>"]
def core.borrow.BorrowShared (T : Type) : core.borrow.Borrow T T := {
  borrow := core.borrow.BorrowShared.borrow
}

/-- Rust's shared str view contains the String's UTF-8 bytes, not its characters.
The length check is the same representability boundary as other Slice models. -/
@[rust_fun "alloc::str::{core::borrow::Borrow<alloc::string::String, str>}::borrow"]
def alloc.str.BorrowString.borrow (value : String) : Result Str :=
  Str.ofString value

@[reducible, rust_trait_impl "core::borrow::Borrow<alloc::string::String, str>"]
def core.borrow.BorrowString : core.borrow.Borrow String Str := {
  borrow := alloc.str.BorrowString.borrow
}

/-- `alloc::borrow::ToOwned` (alloc/src/borrow.rs). The associated type
    `Owned: Borrow<Self>` is lifted to the parameter `Owned`. -/
@[rust_trait "alloc::borrow::ToOwned"
  (parentClauses := ["coreborrowBorrowInst"]) (defaultMethods := ["clone_into"])]
structure alloc.borrow.ToOwned (Self Owned : Type) where
  coreborrowBorrowInst : core.borrow.Borrow Owned Self
  to_owned : Self → Result Owned
  /-- `fn clone_into(&self, target: &mut Owned) { *target = self.to_owned(); }` -/
  clone_into : Self → Owned → Result Owned := fun self _ => to_owned self

/-- The blanket `impl<T: Clone> ToOwned for T { type Owned = T; }`:
    `to_owned` is `self.clone()`. -/
@[rust_fun "alloc::borrow::{alloc::borrow::ToOwned<@T, @T>}::to_owned"]
def alloc.borrow.ToOwnedClone.to_owned {T : Type} (cloneInst : core.clone.Clone T) (self : T) :
  Result T :=
  cloneInst.clone self

/-- Blanket `clone_into`: `target.clone_from(self)`. -/
@[rust_fun "alloc::borrow::{alloc::borrow::ToOwned<@T, @T>}::clone_into"]
def alloc.borrow.ToOwnedClone.clone_into {T : Type} (cloneInst : core.clone.Clone T)
  (self target : T) : Result T :=
  cloneInst.clone_from target self

@[reducible, rust_trait_impl "alloc::borrow::ToOwned<@T, @T>"]
def alloc.borrow.ToOwnedClone {T : Type} (cloneInst : core.clone.Clone T) :
  alloc.borrow.ToOwned T T := {
  coreborrowBorrowInst := core.borrow.BorrowSelf T
  to_owned := alloc.borrow.ToOwnedClone.to_owned cloneInst
  clone_into := alloc.borrow.ToOwnedClone.clone_into cloneInst
}

/-- `impl ToOwned for str { type Owned = String; }` (alloc/src/str.rs): its
    `clone_into` replaces the target with `self.to_owned()`, the default. -/
@[reducible, rust_trait_impl "alloc::borrow::ToOwned<str, alloc::string::String>"]
def alloc.borrow.ToOwnedStr : alloc.borrow.ToOwned Str String := {
  coreborrowBorrowInst := core.borrow.BorrowString
  to_owned := alloc.str.ToOwnedStr.to_owned
}

/-- `enum Cow<'a, B: ?Sized + ToOwned> { Borrowed(&'a B), Owned(<B as ToOwned>::Owned) }`
    (alloc/src/borrow.rs); the lifted associated type is the parameter `O`. -/
@[rust_type "alloc::borrow::Cow"]
inductive alloc.borrow.Cow (B : Type) (O : Type) where
| Borrowed : B → alloc.borrow.Cow B O
| Owned : O → alloc.borrow.Cow B O

/-- `impl Deref for Cow<'_, B>`:
    `match *self { Borrowed(borrowed) => borrowed, Owned(ref owned) => owned.borrow() }`. -/
@[rust_fun "alloc::borrow::{core::ops::deref::Deref<alloc::borrow::Cow<'0, @B, @O>, @B>}::deref"]
def alloc.borrow.DerefCow.deref {B O : Type} (toOwnedInst : alloc.borrow.ToOwned B O) :
  alloc.borrow.Cow B O → Result B
  | .Borrowed borrowed => .ok borrowed
  | .Owned owned => toOwnedInst.coreborrowBorrowInst.borrow owned

@[reducible, rust_trait_impl "core::ops::deref::Deref<alloc::borrow::Cow<'0, @B, @O>, @B>"]
def alloc.borrow.DerefCow {B O : Type} (toOwnedInst : alloc.borrow.ToOwned B O) :
  core.ops.deref.Deref (alloc.borrow.Cow B O) B := {
  deref := alloc.borrow.DerefCow.deref toOwnedInst
}

/-- `impl<T: ?Sized + ToOwned> AsRef<T> for Cow<'_, T>` (alloc/src/borrow.rs, rustc 1.95):
    `self`, through `Deref`: the borrowed value, or the owned value's `borrow()`. -/
@[rust_fun "alloc::borrow::{core::convert::AsRef<alloc::borrow::Cow<'0, @T, @O>, @T>}::as_ref"]
def alloc.borrow.AsRefCow.as_ref {T O : Type} (toOwnedInst : alloc.borrow.ToOwned T O)
    (self : alloc.borrow.Cow T O) : Result T :=
  alloc.borrow.DerefCow.deref toOwnedInst self

namespace alloc.string.lossy

/-- `TAG_CONT_U8`: `byte & 192 == 128`. -/
def isCont (b : Nat) : Bool := b % 256 / 64 == 2

/-- One `Utf8Chunks::next` (core str/lossy.rs, rustc 1.95) on a nonempty source: `(valid_up_to, i)`,
    the length of the chunk's valid prefix and the number of bytes it inspects (its valid part and
    its invalid part, a maximal prefix of an ill-formed sequence). Bytes past the end read as 0. -/
def chunkSplit (src : Array Nat) : Nat × Nat :=
  let get := fun i => src.getD i 0
  let rec loop (i valid : Nat) : (fuel : Nat) → Nat × Nat
    | 0 => (valid, i)
    | fuel + 1 =>
      if i < src.size then
        let byte := get i
        let i := i + 1
        if byte < 128 then loop i i fuel
        else if 0xC2 ≤ byte ∧ byte ≤ 0xDF then
          if isCont (get i) then loop (i + 1) (i + 1) fuel else (valid, i)
        else if 0xE0 ≤ byte ∧ byte ≤ 0xEF then
          let b := get i
          let second :=
            (byte == 0xE0 && 0xA0 ≤ b && b ≤ 0xBF) || (0xE1 ≤ byte && byte ≤ 0xEC && 0x80 ≤ b && b ≤ 0xBF) ||
            (byte == 0xED && 0x80 ≤ b && b ≤ 0x9F) || (0xEE ≤ byte && byte ≤ 0xEF && 0x80 ≤ b && b ≤ 0xBF)
          if !second then (valid, i)
          else if isCont (get (i + 1)) then loop (i + 2) (i + 2) fuel else (valid, i + 1)
        else if 0xF0 ≤ byte ∧ byte ≤ 0xF4 then
          let b := get i
          let second :=
            (byte == 0xF0 && 0x90 ≤ b && b ≤ 0xBF) || (0xF1 ≤ byte && byte ≤ 0xF3 && 0x80 ≤ b && b ≤ 0xBF) ||
            (byte == 0xF4 && 0x80 ≤ b && b ≤ 0x8F)
          if !second then (valid, i)
          else if !isCont (get (i + 1)) then (valid, i + 1)
          else if isCont (get (i + 2)) then loop (i + 3) (i + 3) fuel else (valid, i + 2)
        else (valid, i)
      else (valid, i)
  loop 0 0 src.size

/-- The chunks of `bytes` (`<[u8]>::utf8_chunks`): each chunk's valid part and whether its invalid
    part is nonempty. -/
def chunks (bytes : List Nat) : List (List Nat × Bool) :=
  let rec go : (fuel : Nat) → List Nat → List (List Nat × Bool)
    | 0, _ => []
    | _, [] => []
    | fuel + 1, src@(_ :: _) =>
      let (valid, inspected) := chunkSplit src.toArray
      (src.take valid, valid < inspected) :: go fuel (src.drop inspected)
  go bytes.length bytes

end alloc.string.lossy

/-- `String::from_utf8_lossy` (alloc string.rs, rustc 1.95): `Cow::Borrowed` of the input when it
    is valid UTF-8 (the first chunk has no invalid part; `""` for no chunk), otherwise
    `Cow::Owned` of the valid parts with U+FFFD for each invalid part. -/
@[rust_fun "alloc::string::{alloc::string::String}::from_utf8_lossy"]
def alloc.string.String.from_utf8_lossy (v : Slice U8) :
    Result (alloc.borrow.Cow Str String) := do
  let bytes := v.val.map (·.val)
  match alloc.string.lossy.chunks bytes with
  | [] => .ok (.Borrowed v)
  | (_, false) :: _ => .ok (.Borrowed v)
  | cs =>
    let decode (valid : List Nat) : Result String :=
      match String.fromUTF8? ⟨(valid.map Nat.toUInt8).toArray⟩ with
      | some s => .ok s
      | none => .fail .undef
    let mut res := ""
    for (valid, invalid) in cs do
      res := res ++ (← decode valid)
      if invalid then res := res.push '\uFFFD'
    .ok (.Owned res)

end Aeneas.Std
