import Aeneas.Std.Serde.De

/-! # Recursive serde groups

A generic format dictionary can inspect `.div`. Its methods need not be monotone.
Recursive groups that pass their methods through a serde knot use finite approximations.
Zero fuel gives `.div`. A successor uses the original body with predecessor calls.
The public definition searches for the first defined approximation, without a fixed bound.

A defined approximation alone does not prove an unrestricted Rust correspondence.
The chain premise excludes results that change with more fuel.
The continuity premise states preservation of these limits by the original body.
A chain alone does not imply the unfolding equation or a least fixpoint.
Leastness also needs monotonicity.
These premises are proof obligations, not attributes on arbitrary format dictionaries.
-/

namespace Aeneas.Std

def fuelLimit {α : Type} (f : Nat → Result α) : Result α :=
  serde_core.de.limitFrom f 0

theorem fuelLimit_eq_of_chain {α : Type} {f : Nat → Result α}
    (hc : serde_core.de.IsChain f) {n : Nat} (hn : f n ≠ .div) :

    fuelLimit f = f n :=
  serde_core.de.limitFrom_eq_of_chain hc (Nat.zero_le n) hn

theorem fuelLimit_defined {α : Type} (f : Nat → Result α)
    (h : fuelLimit f ≠ .div) : ∃ n, f n = fuelLimit f := by

  rcases serde_core.de.limitFrom_defined f 0 h with ⟨n, _, hn⟩
  exact ⟨n, hn⟩

theorem fuelLimit_eq_div_iff {α : Type} (f : Nat → Result α) :
    fuelLimit f = .div ↔ ∀ n, f n = .div := by

  constructor
  · intro h n
    by_contra hn
    have key : ∀ k, k ≤ n → serde_core.de.limitFrom f k ≠ .div := by

      intro k hk
      induction distance : n - k generalizing k with
      | zero =>
        have hkn : k = n := by omega

        subst k
        rw [serde_core.de.limitFrom_of_ne_div f n hn]
        exact hn
      | succ d ih =>
        by_cases hkdiv : f k = .div

        · rw [serde_core.de.limitFrom_of_div f k hkdiv]
          exact ih (k + 1) (by omega) (by omega)

        · rw [serde_core.de.limitFrom_of_ne_div f k hkdiv]
          exact hkdiv

    exact key 0 (Nat.zero_le n) h
  · intro h
    by_contra hn
    rcases fuelLimit_defined f hn with ⟨n, heq⟩

    exact hn (heq.symm.trans (h n))

theorem fuelLimit_tail {α : Type} {f : Nat → Result α}
    (hc : serde_core.de.IsChain f) :
    fuelLimit (fun n => f (n + 1)) = fuelLimit f := by

  have ht : serde_core.de.IsChain (fun n => f (n + 1)) :=

    fun m n h => hc (m + 1) (n + 1) (Nat.add_le_add_right h 1)

  by_cases h : fuelLimit f = .div
  · have hall := (fuelLimit_eq_div_iff f).mp h
    rw [h]

    exact (fuelLimit_eq_div_iff _).mpr (fun n => hall (n + 1))

  · rcases fuelLimit_defined f h with ⟨n, hn⟩
    have hnd : f n ≠ .div := by
      rw [hn]
      exact h

    have heq : f n = f (n + 1) := by
      rcases hc n (n + 1) (Nat.le_succ n) with hd | heq

      · exact False.elim (hnd hd)
      · exact heq
    have hs : f (n + 1) ≠ .div := by
      rw [← heq]
      exact hnd

    exact (fuelLimit_eq_of_chain ht hs).trans (heq.symm.trans hn)

namespace FuelRecursion

def Below {ι : Type u} {β : ι → Type} (f g : (x : ι) → Result (β x)) : Prop :=

  ∀ x, f x = .div ∨ f x = g x

def iterate {ι : Type u} {β : ι → Type}

    (body : ((x : ι) → Result (β x)) → (x : ι) → Result (β x)) :

    Nat → (x : ι) → Result (β x)
  | 0 => fun _ => .div
  | n + 1 => body (iterate body n)

def limit {ι : Type u} {β : ι → Type}

    (f : Nat → (x : ι) → Result (β x)) : (x : ι) → Result (β x) :=

  fun x => fuelLimit (fun n => f n x)

def Continuous {ι : Type u} {β : ι → Type}

    (body : ((x : ι) → Result (β x)) → (x : ι) → Result (β x)) : Prop :=

  ∀ f, (∀ x, serde_core.de.IsChain (fun n => f n x)) →
    body (limit f) = limit (fun n => body (f n))

theorem unfolding {ι : Type u} {β : ι → Type}

    (body : ((x : ι) → Result (β x)) → (x : ι) → Result (β x))

    (hc : ∀ x, serde_core.de.IsChain (fun n => iterate body n x))
    (hcontinuous : Continuous body) :

    limit (iterate body) = body (limit (iterate body)) := by
  rw [hcontinuous (iterate body) hc]
  funext x

  change fuelLimit (fun n => iterate body n x) =
    fuelLimit (fun n => iterate body (n + 1) x)

  exact (fuelLimit_tail (hc x)).symm

theorem limit_below {ι : Type u} {β : ι → Type}

    (f : Nat → (x : ι) → Result (β x)) (p : (x : ι) → Result (β x))

    (h : ∀ n, Below (f n) p) : Below (limit f) p := by
  intro x

  by_cases hd : limit f x = .div
  · exact Or.inl hd
  · rcases fuelLimit_defined (fun n => f n x) hd with ⟨n, hn⟩

    rcases h n x with hb | hb
    · exact False.elim (hd (hn.symm.trans hb))
    · exact Or.inr (hn.symm.trans hb)

theorem least {ι : Type u} {β : ι → Type}

    (body : ((x : ι) → Result (β x)) → (x : ι) → Result (β x))

    (hc : ∀ x, serde_core.de.IsChain (fun n => iterate body n x))
    (hcontinuous : Continuous body)

    (hmono : ∀ f g, Below f g → Below (body f) (body g)) :
    limit (iterate body) = body (limit (iterate body)) ∧

      ∀ p, Below (body p) p → Below (limit (iterate body)) p := by
  refine ⟨unfolding body hc hcontinuous, ?_⟩

  intro p hp
  apply limit_below
  intro n
  induction n with
  | zero => exact fun _ => Or.inl rfl
  | succ n ih =>
    intro x

    rcases hmono _ _ ih x with hd | heq
    · exact Or.inl hd
    · rcases hp x with hd | hp'

      · exact Or.inl (heq.trans hd)
      · exact Or.inr (heq.trans hp')

end FuelRecursion
end Aeneas.Std
