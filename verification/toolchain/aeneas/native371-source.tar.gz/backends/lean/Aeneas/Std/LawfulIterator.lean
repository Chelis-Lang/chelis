import Aeneas.Std.VecIter
import Aeneas.Std.ArrayIter
import Aeneas.Std.BTreeMap
import Aeneas.Std.BTreeSet
import Aeneas.Std.IteratorSources

/-!
# Lawful iterator dictionaries

Native Rust 1.98.0 selects collection consumers by complete iterator types.
Vec collection uses fold for TrustedLen iterators.
An authenticated in-place certificate selects try_fold or indexed access.
Unknown source or layout evidence cannot establish this certificate.
BTreeMap and BTreeSet use the same Vec consumer before stable sorting.
The heap abstraction excludes allocation identity, allocation failure, and destructor effects.

An absent TrustedLen upper bound causes a panic before callbacks.
Collection returns the state from the selected consumer.
Specialized Zip and StepBy folds need not equal repeated next.

LawfulIterator states the separate equality of fold and try_fold with next.
It does not certify native collection selection or an in-place layout.
Collection admission must retain its closed source and layout guards.
-/

namespace Aeneas.Std

structure core.iter.traits.iterator.LawfulIterator {I Item : Type}
    (it : core.iter.traits.iterator.Iterator I Item) : Prop where
  fold_eq : ∀ {B F : Type} (fnInst : core.ops.function.FnMut F (B × Item) B)
    (s : I) (init : B) (f : F),
    it.fold fnInst s init f = core.iter.traits.iterator.foldFromNext it.next fnInst s init f
  try_fold_eq : ∀ {B F R Residual : Type}
    (fnInst : core.ops.function.FnMut F (B × Item) R)
    (tryInst : core.ops.try_trait.Try R B Residual) (s : I) (init : B) (f : F),
    it.try_fold fnInst tryInst s init f =
      core.iter.traits.iterator.tryFoldFromNext it.next fnInst tryInst s init f

namespace core.iter.traits.iterator.LawfulIterator

/-- Dictionaries that keep the provided `fold`/`try_fold` are lawful. -/
theorem of_defaults {I Item : Type} (next : I → Result (Option Item × I)) :
    core.iter.traits.iterator.LawfulIterator
      ({ next } : core.iter.traits.iterator.Iterator I Item) :=
  ⟨fun _ _ _ _ => rfl, fun _ _ _ _ _ => rfl⟩

theorem vecIntoIter (T : Type) :
    core.iter.traits.iterator.LawfulIterator
      (core.iter.traits.iterator.IteratorVecIntoIter T) :=
  ⟨fun _ _ _ _ => rfl, fun _ _ _ _ _ => rfl⟩

theorem arrayIntoIter (T : Type) (N : Usize) :
    core.iter.traits.iterator.LawfulIterator
      (core.iter.traits.iterator.IteratorArrayIntoIter T N) :=
  ⟨fun _ _ _ _ => rfl, fun _ _ _ _ _ => rfl⟩

theorem btreeIter (K V : Type) :
    core.iter.traits.iterator.LawfulIterator
      (core.iter.traits.iterator.IteratorBTreeIter K V) :=
  ⟨fun _ _ _ _ => rfl, fun _ _ _ _ _ => rfl⟩

theorem btreeIntoIter (K V : Type) :
    core.iter.traits.iterator.LawfulIterator
      (core.iter.traits.iterator.IteratorBTreeIntoIter K V) :=
  ⟨fun _ _ _ _ => rfl, fun _ _ _ _ _ => rfl⟩

theorem btreeSetIntoIter (T : Type) :
    core.iter.traits.iterator.LawfulIterator
      (core.iter.traits.iterator.IteratorBTreeSetIntoIter T) :=
  ⟨fun _ _ _ _ => rfl, fun _ _ _ _ _ => rfl⟩

theorem btreeSetIter (T : Type) :
    core.iter.traits.iterator.LawfulIterator
      (core.iter.traits.iterator.IteratorBTreeSetIter T) :=
  ⟨fun _ _ _ _ => rfl, fun _ _ _ _ _ => rfl⟩

theorem once (T : Type) :
    core.iter.traits.iterator.LawfulIterator
      (core.iter.traits.iterator.IteratorOnce T) :=
  ⟨fun _ _ _ _ => rfl, fun _ _ _ _ _ => rfl⟩

end core.iter.traits.iterator.LawfulIterator

end Aeneas.Std
