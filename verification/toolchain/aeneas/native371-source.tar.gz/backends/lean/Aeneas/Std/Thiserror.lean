import Aeneas.Std.Core.FmtWithSlice
import Aeneas.Std.Core.Error

/-!
# thiserror (2.0.18)

`#[derive(thiserror::Error)]` formats each interpolated field `{field}` of an error message as
`field.as_display()` (thiserror-impl `fmt.rs`), with the `AsDisplay` trait of thiserror's
`src/display.rs`. The derived `Error::source` of a variant with a `#[source]` (or `#[from]`)
field returns `Some(field.as_dyn_error())`, with the `AsDynError` trait of `src/aserror.rs`.
-/

namespace Aeneas.Std

open Result

/-- `impl<'a, T: Display + ?Sized + 'a> AsDisplay<'a> for &T` (`type Target = &'a T`):
    `as_display(&'a self)` is `*self`, the borrowed field itself (the borrows are erased). -/
@[rust_fun "thiserror::display::{thiserror::display::AsDisplay<'a, &'0 @T, &'a @T>}::as_display"]
def thiserror.display.AsDisplayShared.as_display {T : Type} (_displayInst : core.fmt.Display T)
    (self : T) : Result T :=
  ok self

/-- `impl<'a, T: Error + 'a> AsDynError<'a> for T`: `as_dyn_error(&self) -> &(dyn Error + 'a)` is
    `self` unsized to a trait object, i.e. the value with its `Error` dictionary (the borrow is
    erased), as the translation of an unsizing cast to `dyn Error` builds it (`Dyn.mk`). -/
@[rust_fun "thiserror::aserror::{thiserror::aserror::AsDynError<'a, @T>}::as_dyn_error"]
def thiserror.aserror.AsDynError.as_dyn_error {T : Type} (errorInst : core.error.Error T)
    (self : T) : Result (Dyn (fun _dyn => core.error.Error _dyn)) :=
  ok ⟨T, errorInst, self⟩

end Aeneas.Std
