import Aeneas.Std.Core.Fmt
import Aeneas.Std.Core.FmtWithSlice
import Aeneas.Std.Core.Error
import Aeneas.Std.Core.Result
import Aeneas.Std.Scalar.Fmt
import Aeneas.Std.Scalar.Casts
import Aeneas.Std.Float
import Aeneas.Std.FloatFmt
import Aeneas.Std.String
import Aeneas.Std.Vec
import Aeneas.Std.Nested

/-!
# `serde_core::de` (serde 1.0.228)

`Deserialize`, `DeserializeSeed`, `Visitor` (the *data side*: implemented by the deserialized types)
and `Deserializer`, `SeqAccess`, `MapAccess`, `EnumAccess`, `VariantAccess` (the *format side*) form
a recursive group through method-level bounds (`deserialize<D: Deserializer>`,
`deserialize_seq<V: Visitor>`, `visit_seq<A: SeqAccess>`, `next_element_seed<T: DeserializeSeed>`,
...), i.e. negative occurrences. As in `Serde/Ser.lean`, the format side is defined relative to a
knot family `X : Fam` (the data-side dictionaries it receives at its method-level bounds), the data
side over the format side at `X`, the levels are `DeAt 0 = PUnit`, `DeAt (n + 1) = Step (DeAt n)`,
and the Rust traits are the structures at the limit `Ω`. The knots `Deserialize.wrap : Deserialize T → DeserializeΩ T`,
`DeserializeSeed.wrap`, `Visitor.wrap` (the `knot`s of their `rust_trait` attributes: Aeneas wraps
the dictionaries passed at the format side's method-level bounds) run a dictionary at level `n + 1`
against the level-`n` formats (`*.map (proj n)`); they are definitional (`wrap_level_succ`). `FormatProgram.encode` encodes every Rust format (a family of deserializers and
access types, generic in the knot family), with `rfl` unfolding lemmas.

`&dyn Expected` (the `exp` argument of `Error::invalid_type`/`invalid_value`/`invalid_length`) is
`Dyn (fun T => Expected T)`, Aeneas's translation of trait objects.
-/

namespace Aeneas.Std

open Result

namespace serde_core.private

/-- `fmt::write(f.buf, args)`: the pieces and arguments are written to the formatter's output with
    default options (the formatter's own options are restored). -/
def writeArgs (f : core.fmt.Formatter) (k : core.fmt.Callback) : core.fmt.Outcome := do
  let (status, g) ← k { f with options := {} }
  .ok (status, { g with options := f.options })

/-- A `fmt::Arguments` given to `Error::custom`, with `impl Display for Arguments`
    (`write(fmt.buf, *self)`). `custom<T: Display>` is parametric in `T`. -/
abbrev Msg := core.fmt.Callback

def displayMsg : core.fmt.Display Msg := ⟨fun m f => writeArgs f m⟩

def lit (s : String) : core.fmt.Callback := fun f => f.append s

/-- The pieces of a `format_args!`, written in order, stopping at the first error. -/
def cat : List core.fmt.Callback → core.fmt.Callback
  | [] => fun f => .ok (.Ok (), f)
  | k :: ks => fun f => core.fmt.thenFormat (k f) (cat ks)

/-- `{}` of a `&str` (default options). -/
def strArg (s : Str) : core.fmt.Callback := fun f => do f.append (← core.fmt.decode s.val)

def utf8 (c : Char) : Result Str := Str.ofString (String.singleton c)

end serde_core.private

open serde_core.private

/-- `serde_core::de::Unexpected` -/
@[rust_type "serde_core::de::Unexpected"]
inductive serde_core.de.Unexpected where
  | Bool : Bool → serde_core.de.Unexpected
  | Unsigned : U64 → serde_core.de.Unexpected
  | Signed : I64 → serde_core.de.Unexpected
  | Float : F64 → serde_core.de.Unexpected
  | Char : Char → serde_core.de.Unexpected
  | Str : Str → serde_core.de.Unexpected
  | Bytes : Slice U8 → serde_core.de.Unexpected
  | Unit : serde_core.de.Unexpected
  | Option : serde_core.de.Unexpected
  | NewtypeStruct : serde_core.de.Unexpected
  | Seq : serde_core.de.Unexpected
  | Map : serde_core.de.Unexpected
  | Enum : serde_core.de.Unexpected
  | UnitVariant : serde_core.de.Unexpected
  | NewtypeVariant : serde_core.de.Unexpected
  | TupleVariant : serde_core.de.Unexpected
  | StructVariant : serde_core.de.Unexpected
  | Other : Str → serde_core.de.Unexpected

/-- `serde_core::private::content::Content<'de>` (private/content.rs): the value an untagged or
    internally tagged enum buffers before it deserializes its variant (not public API). `Box<Content>`
    is `Content`; the `Vec`s of this recursive type are the nested carrier `NestedVec`, as Aeneas
    translates them. -/
@[rust_type "serde_core::private::content::Content"]
inductive serde_core.private.content.Content where
  | Bool : Bool → serde_core.private.content.Content
  | U8 : U8 → serde_core.private.content.Content
  | U16 : U16 → serde_core.private.content.Content
  | U32 : U32 → serde_core.private.content.Content
  | U64 : U64 → serde_core.private.content.Content
  | I8 : I8 → serde_core.private.content.Content
  | I16 : I16 → serde_core.private.content.Content
  | I32 : I32 → serde_core.private.content.Content
  | I64 : I64 → serde_core.private.content.Content
  | F32 : F32 → serde_core.private.content.Content
  | F64 : F64 → serde_core.private.content.Content
  | Char : Char → serde_core.private.content.Content
  | String : String → serde_core.private.content.Content
  | Str : Str → serde_core.private.content.Content
  | ByteBuf : alloc.vec.Vec U8 → serde_core.private.content.Content
  | Bytes : Slice U8 → serde_core.private.content.Content
  | None : serde_core.private.content.Content
  | Some : serde_core.private.content.Content → serde_core.private.content.Content
  | Unit : serde_core.private.content.Content
  | Newtype : serde_core.private.content.Content → serde_core.private.content.Content
  | Seq : NestedVec serde_core.private.content.Content → serde_core.private.content.Content
  | Map : NestedVec (serde_core.private.content.Content × serde_core.private.content.Content) →
      serde_core.private.content.Content

/-- `serde_core::de::Expected` -/
@[rust_trait "serde_core::de::Expected"]
structure serde_core.de.Expected (Self : Type) where
  fmt : Self → core.fmt.Formatter → core.fmt.Outcome

/-- `&dyn Expected` (as Aeneas translates trait objects). -/
abbrev serde_core.de.DynExpected := Dyn (fun T => serde_core.de.Expected T)

namespace serde_core.de

/-- `impl Display for dyn Expected`: `Expected::fmt(self, formatter)`. -/
def DynExpected.fmt (exp : DynExpected) : core.fmt.Callback := exp.inst.fmt exp.value

/-- `impl Expected for &str`: `formatter.write_str(self)`. -/
@[rust_fun "serde_core::de::{serde_core::de::Expected<&'0 str>}::fmt"]
def ExpectedSharedStr.fmt (s : Str) (formatter : core.fmt.Formatter) : core.fmt.Outcome :=
  core.fmt.Formatter.write_str formatter s

@[reducible, rust_trait_impl "serde_core::de::Expected<&'0 str>"]
def ExpectedSharedStr : serde_core.de.Expected Str := ⟨ExpectedSharedStr.fmt⟩

/-- `impl<'de, T: Visitor<'de>> Expected for T`: `self.expecting(formatter)`. -/
def expectedOf {Self : Type} (expecting : Self → core.fmt.Formatter → core.fmt.Outcome)
    (self : Self) : DynExpected :=
  ⟨Self, ⟨expecting⟩, self⟩

/-- `struct WithDecimalPoint(f64)`: a finite float written without a `.` gets `.0`. -/
def withDecimalPoint (x : F64) : core.fmt.Callback := fun f =>
  if x.isFinite then do
    let (status, g) ← core.fmt.DisplayF64.fmt x { f with output := "" }
    match status with
    | .Err e => .ok (.Err e, { f with output := f.output ++ g.output })
    | .Ok () =>
      let text := g.output
      core.fmt.thenFormat (f.append text) (fun f =>
        if text.contains '.' then .ok (.Ok (), f) else f.append ".0")
  else core.fmt.DisplayF64.fmt x f

/-- `impl Display for Unexpected` -/
def Unexpected.fmt (u : Unexpected) (f : core.fmt.Formatter) : core.fmt.Outcome :=
  match u with
  | .Bool b => writeArgs f (cat [lit "boolean `", core.fmt.DisplayBool.fmt b, lit "`"])
  | .Unsigned i => writeArgs f (cat [lit "integer `", core.fmt.num.DisplayU64.fmt i, lit "`"])
  | .Signed i => writeArgs f (cat [lit "integer `", core.fmt.num.DisplayI64.fmt i, lit "`"])
  | .Float x => writeArgs f (cat [lit "floating point `", withDecimalPoint x, lit "`"])
  | .Char c => writeArgs f (cat [lit "character `", fun f => f.pad (String.singleton c), lit "`"])
  | .Str s => writeArgs f (cat [lit "string ", core.fmt.DebugStr.fmt s])
  | .Bytes _ => f.append "byte array"
  | .Unit => f.append "unit value"
  | .Option => f.append "Option value"
  | .NewtypeStruct => f.append "newtype struct"
  | .Seq => f.append "sequence"
  | .Map => f.append "map"
  | .Enum => f.append "enum"
  | .UnitVariant => f.append "unit variant"
  | .NewtypeVariant => f.append "newtype variant"
  | .TupleVariant => f.append "tuple variant"
  | .StructVariant => f.append "struct variant"
  | .Other other => do f.append (← core.fmt.decode other.val)

/-- `struct OneOf { names }` and its `Display`. -/
def oneOf (names : List Str) : core.fmt.Callback := fun f =>
  match names with
  | [] => .fail .panic
  | [a] => writeArgs f (cat [lit "`", strArg a, lit "`"])
  | [a, b] => writeArgs f (cat [lit "`", strArg a, lit "` or `", strArg b, lit "`"])
  | _ =>
    core.fmt.thenFormat (f.append "one of ") (fun f =>
      cat ((names.zipIdx.map fun (alt, i) =>
        cat [if i > 0 then lit ", " else cat [],
             fun f => writeArgs f (cat [lit "`", strArg alt, lit "`"])])) f)

end serde_core.de

/-- `serde_core::de::Error`: the provided methods build their `format_args!` messages. -/
@[rust_trait "serde_core::de::Error" (parentClauses := ["coreerrorErrorInst"])
  (defaultMethods := ["invalid_type", "invalid_value", "invalid_length", "unknown_variant",
    "unknown_field", "missing_field", "duplicate_field"])]
structure serde_core.de.Error (Self : Type) where
  coreerrorErrorInst : core.error.Error Self
  custom : {T : Type} → core.fmt.Display T → T → Result Self
  invalid_type : serde_core.de.Unexpected → serde_core.de.DynExpected → Result Self :=
    fun unexp exp => custom displayMsg
      (cat [lit "invalid type: ", unexp.fmt, lit ", expected ", exp.inst.fmt exp.value])
  invalid_value : serde_core.de.Unexpected → serde_core.de.DynExpected → Result Self :=
    fun unexp exp => custom displayMsg
      (cat [lit "invalid value: ", unexp.fmt, lit ", expected ", exp.inst.fmt exp.value])
  invalid_length : Usize → serde_core.de.DynExpected → Result Self :=
    fun len exp => custom displayMsg
      (cat [lit "invalid length ", core.fmt.num.DisplayUsize.fmt len, lit ", expected ",
        exp.inst.fmt exp.value])
  unknown_variant : Str → Slice Str → Result Self :=
    fun variant expected =>
      if expected.val.isEmpty then
        custom displayMsg (cat [lit "unknown variant `", strArg variant,
          lit "`, there are no variants"])
      else
        custom displayMsg (cat [lit "unknown variant `", strArg variant, lit "`, expected ",
          serde_core.de.oneOf expected.val])
  unknown_field : Str → Slice Str → Result Self :=
    fun field expected =>
      if expected.val.isEmpty then
        custom displayMsg (cat [lit "unknown field `", strArg field,
          lit "`, there are no fields"])
      else
        custom displayMsg (cat [lit "unknown field `", strArg field, lit "`, expected ",
          serde_core.de.oneOf expected.val])
  missing_field : Str → Result Self :=
    fun field => custom displayMsg (cat [lit "missing field `", strArg field, lit "`"])
  duplicate_field : Str → Result Self :=
    fun field => custom displayMsg (cat [lit "duplicate field `", strArg field, lit "`"])

namespace serde_core.de

/-! ## The knot families -/

/-- The data-side dictionaries at the format side's method-level bounds. `phantom` is
    `impl<T: Deserialize> DeserializeSeed for PhantomData<T>` (`T::deserialize(deserializer)`), used
    by the provided `next_element` & co. -/
structure Fam : Type 2 where
  Deserialize : Type → Type 1
  Seed : Type → Type → Type 1
  Visitor : Type → Type → Type 1
  phantom : {T : Type} → Deserialize T → Seed Unit T

/-- A morphism of knot families (the format side is contravariant in it, the data side covariant). -/
structure Fam.Hom (Y X : Fam) where
  deserialize : {T : Type} → Y.Deserialize T → X.Deserialize T
  seed : {T Value : Type} → Y.Seed T Value → X.Seed T Value
  visitor : {V Value : Type} → Y.Visitor V Value → X.Visitor V Value

/-! ## Format side, relative to the knot family `X` -/

section
variable (X : Fam)

def i128Unsupported {Value Error : Type} (errInst : serde_core.de.Error Error) (msg : String) :
    Result (core.result.Result Value Error) := do
  .ok (.Err (← errInst.custom core.fmt.DisplayStr (← Str.ofString msg)))

structure DeserializerF (Self Error : Type) : Type 1 where
  serde_coredeErrorInst : serde_core.de.Error Error
  deserialize_any : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error)
  deserialize_bool : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error)
  deserialize_i8 : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error)
  deserialize_i16 : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error)
  deserialize_i32 : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error)
  deserialize_i64 : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error)
  /-- Provided: `let _ = visitor; Err(Error::custom("i128 is not supported"))`. -/
  deserialize_i128 : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error) :=
    fun _ _ _ => i128Unsupported serde_coredeErrorInst "i128 is not supported"
  deserialize_u8 : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error)
  deserialize_u16 : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error)
  deserialize_u32 : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error)
  deserialize_u64 : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error)
  /-- Provided: `let _ = visitor; Err(Error::custom("u128 is not supported"))`. -/
  deserialize_u128 : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error) :=
    fun _ _ _ => i128Unsupported serde_coredeErrorInst "u128 is not supported"
  deserialize_f32 : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error)
  deserialize_f64 : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error)
  deserialize_char : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error)
  deserialize_str : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error)
  deserialize_string : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error)
  deserialize_bytes : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error)
  deserialize_byte_buf : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error)
  deserialize_option : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error)
  deserialize_unit : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error)
  deserialize_unit_struct : {V Value : Type} → X.Visitor V Value → Self → Str → V →
    Result (core.result.Result Value Error)
  deserialize_newtype_struct : {V Value : Type} → X.Visitor V Value → Self → Str → V →
    Result (core.result.Result Value Error)
  deserialize_seq : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error)
  deserialize_tuple : {V Value : Type} → X.Visitor V Value → Self → Usize → V →
    Result (core.result.Result Value Error)
  deserialize_tuple_struct : {V Value : Type} → X.Visitor V Value → Self → Str → Usize → V →
    Result (core.result.Result Value Error)
  deserialize_map : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error)
  deserialize_struct : {V Value : Type} → X.Visitor V Value → Self → Str → Slice Str → V →
    Result (core.result.Result Value Error)
  deserialize_enum : {V Value : Type} → X.Visitor V Value → Self → Str → Slice Str → V →
    Result (core.result.Result Value Error)
  deserialize_identifier : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error)
  deserialize_ignored_any : {V Value : Type} → X.Visitor V Value → Self → V →
    Result (core.result.Result Value Error)
  /-- Provided: `true`. -/
  is_human_readable : Self → Result Bool := fun _ => ok true
  /-- Provided (hidden, not public API; serde_core 1.0.228 `de/mod.rs` with `std`/`alloc`):
      `self.deserialize_any(visitor)`, for a visitor whose value is `Content` (`ContentVisitor`'s
      `DeserializeSeed::deserialize` calls it; `ContentDeserializer` gives back its content). -/
  __deserialize_content_v1 : {V : Type} → X.Visitor V serde_core.private.content.Content → Self →
    V → Result (core.result.Result serde_core.private.content.Content Error) :=
    fun v self vis => deserialize_any v self vis

structure SeqAccessF (Self Error : Type) : Type 1 where
  serde_coredeErrorInst : serde_core.de.Error Error
  next_element_seed : {T Value : Type} → X.Seed T Value → Self → T →
    Result (core.result.Result (Option Value) Error × Self)
  /-- Provided: `self.next_element_seed(PhantomData)`. -/
  next_element : {T : Type} → X.Deserialize T → Self →
    Result (core.result.Result (Option T) Error × Self) :=
    fun d self => next_element_seed (X.phantom d) self ()
  /-- Provided: `None`. -/
  size_hint : Self → Result (Option Usize) := fun _ => ok none

structure MapAccessF (Self Error : Type) : Type 1 where
  serde_coredeErrorInst : serde_core.de.Error Error
  next_key_seed : {K Value : Type} → X.Seed K Value → Self → K →
    Result (core.result.Result (Option Value) Error × Self)
  next_value_seed : {V Value : Type} → X.Seed V Value → Self → V →
    Result (core.result.Result Value Error × Self)
  /-- Provided: `next_key_seed(kseed)?` then, for a key, `next_value_seed(vseed)?`. -/
  next_entry_seed : {K V KValue VValue : Type} → X.Seed K KValue → X.Seed V VValue → Self →
    K → V → Result (core.result.Result (Option (KValue × VValue)) Error × Self) :=
    fun kInst vInst self kseed vseed => do
      let (r, self) ← next_key_seed kInst self kseed
      match r with
      | .Err e => ok (.Err e, self)
      | .Ok none => ok (.Ok none, self)
      | .Ok (some key) =>
        let (r, self) ← next_value_seed vInst self vseed
        match r with
        | .Err e => ok (.Err e, self)
        | .Ok value => ok (.Ok (some (key, value)), self)
  /-- Provided: `self.next_key_seed(PhantomData)`. -/
  next_key : {K : Type} → X.Deserialize K → Self →
    Result (core.result.Result (Option K) Error × Self) :=
    fun d self => next_key_seed (X.phantom d) self ()
  /-- Provided: `self.next_value_seed(PhantomData)`. -/
  next_value : {V : Type} → X.Deserialize V → Self →
    Result (core.result.Result V Error × Self) :=
    fun d self => next_value_seed (X.phantom d) self ()
  /-- Provided: `self.next_entry_seed(PhantomData, PhantomData)`. -/
  next_entry : {K V : Type} → X.Deserialize K → X.Deserialize V → Self →
    Result (core.result.Result (Option (K × V)) Error × Self) :=
    fun dk dv self => next_entry_seed (X.phantom dk) (X.phantom dv) self () ()
  /-- Provided: `None`. -/
  size_hint : Self → Result (Option Usize) := fun _ => ok none

structure VariantAccessF (Self Error : Type) : Type 1 where
  serde_coredeErrorInst : serde_core.de.Error Error
  unit_variant : Self → Result (core.result.Result Unit Error)
  newtype_variant_seed : {T Value : Type} → X.Seed T Value → Self → T →
    Result (core.result.Result Value Error)
  /-- Provided: `self.newtype_variant_seed(PhantomData)`. -/
  newtype_variant : {T : Type} → X.Deserialize T → Self → Result (core.result.Result T Error) :=
    fun d self => newtype_variant_seed (X.phantom d) self ()
  tuple_variant : {V Value : Type} → X.Visitor V Value → Self → Usize → V →
    Result (core.result.Result Value Error)
  struct_variant : {V Value : Type} → X.Visitor V Value → Self → Slice Str → V →
    Result (core.result.Result Value Error)

structure EnumAccessF (Self Error Variant : Type) : Type 1 where
  serde_coredeErrorInst : serde_core.de.Error Error
  VariantAccessInst : VariantAccessF X Variant Error
  variant_seed : {V Value : Type} → X.Seed V Value → Self → V →
    Result (core.result.Result (Value × Variant) Error)
  /-- Provided: `self.variant_seed(PhantomData)`. -/
  variant : {V : Type} → X.Deserialize V → Self → Result (core.result.Result (V × Variant) Error) :=
    fun d self => variant_seed (X.phantom d) self ()

/-! ## Data side, relative to the knot family `X` -/

structure DeserializeStep (Self : Type) : Type 1 where
  deserialize : {D Error : Type} → DeserializerF X D Error → D →
    Result (core.result.Result Self Error)

structure SeedStep (Self Value : Type) : Type 1 where
  deserialize : {D Error : Type} → DeserializerF X D Error → Self → D →
    Result (core.result.Result Value Error)

/-- `Err(Error::invalid_type(unexp, &self))` of the provided `visit_*` methods (`&self` as
    `&dyn Expected`: `impl<T: Visitor> Expected for T` is `self.expecting(formatter)`). -/
def invalidType {Self Value E : Type} (expecting : Self → core.fmt.Formatter → core.fmt.Outcome)
    (errInst : serde_core.de.Error E) (self : Self) (unexp : serde_core.de.Unexpected) :
    Result (core.result.Result Value E) := do
  .ok (.Err (← errInst.invalid_type unexp (expectedOf expecting self)))

structure VisitorStep (Self Value : Type) : Type 1 where
  expecting : Self → core.fmt.Formatter → core.fmt.Outcome
  visit_bool : {E : Type} → serde_core.de.Error E → Self → Bool →
    Result (core.result.Result Value E) :=
    fun e self v => invalidType expecting e self (.Bool v)
  visit_i64 : {E : Type} → serde_core.de.Error E → Self → I64 →
    Result (core.result.Result Value E) :=
    fun e self v => invalidType expecting e self (.Signed v)
  visit_i8 : {E : Type} → serde_core.de.Error E → Self → I8 →
    Result (core.result.Result Value E) :=
    fun e self v => visit_i64 e self (v.cast .I64)
  visit_i16 : {E : Type} → serde_core.de.Error E → Self → I16 →
    Result (core.result.Result Value E) :=
    fun e self v => visit_i64 e self (v.cast .I64)
  visit_i32 : {E : Type} → serde_core.de.Error E → Self → I32 →
    Result (core.result.Result Value E) :=
    fun e self v => visit_i64 e self (v.cast .I64)
  visit_i128 : {E : Type} → serde_core.de.Error E → Self → I128 →
    Result (core.result.Result Value E) :=
    fun e self v => do
      let text := "integer `" ++ toString v.val ++ "` as i128"
      invalidType expecting e self (.Other (← Str.ofString text))
  visit_u64 : {E : Type} → serde_core.de.Error E → Self → U64 →
    Result (core.result.Result Value E) :=
    fun e self v => invalidType expecting e self (.Unsigned v)
  visit_u8 : {E : Type} → serde_core.de.Error E → Self → U8 →
    Result (core.result.Result Value E) :=
    fun e self v => visit_u64 e self (v.cast .U64)
  visit_u16 : {E : Type} → serde_core.de.Error E → Self → U16 →
    Result (core.result.Result Value E) :=
    fun e self v => visit_u64 e self (v.cast .U64)
  visit_u32 : {E : Type} → serde_core.de.Error E → Self → U32 →
    Result (core.result.Result Value E) :=
    fun e self v => visit_u64 e self (v.cast .U64)
  visit_u128 : {E : Type} → serde_core.de.Error E → Self → U128 →
    Result (core.result.Result Value E) :=
    fun e self v => do
      let text := "integer `" ++ toString v.val ++ "` as u128"
      invalidType expecting e self (.Other (← Str.ofString text))
  visit_f64 : {E : Type} → serde_core.de.Error E → Self → F64 →
    Result (core.result.Result Value E) :=
    fun e self v => invalidType expecting e self (.Float v)
  visit_f32 : {E : Type} → serde_core.de.Error E → Self → F32 →
    Result (core.result.Result Value E) :=
    fun e self v => visit_f64 e self (F32.toF64 v)
  visit_str : {E : Type} → serde_core.de.Error E → Self → Str →
    Result (core.result.Result Value E) :=
    fun e self v => invalidType expecting e self (.Str v)
  visit_char : {E : Type} → serde_core.de.Error E → Self → Char →
    Result (core.result.Result Value E) :=
    fun e self v => do visit_str e self (← utf8 v)
  visit_borrowed_str : {E : Type} → serde_core.de.Error E → Self → Str →
    Result (core.result.Result Value E) :=
    fun e self v => visit_str e self v
  visit_string : {E : Type} → serde_core.de.Error E → Self → String →
    Result (core.result.Result Value E) :=
    fun e self v => do visit_str e self (← Str.ofString v)
  visit_bytes : {E : Type} → serde_core.de.Error E → Self → Slice U8 →
    Result (core.result.Result Value E) :=
    fun e self v => invalidType expecting e self (.Bytes v)
  visit_borrowed_bytes : {E : Type} → serde_core.de.Error E → Self → Slice U8 →
    Result (core.result.Result Value E) :=
    fun e self v => visit_bytes e self v
  visit_byte_buf : {E : Type} → serde_core.de.Error E → Self → alloc.vec.Vec U8 →
    Result (core.result.Result Value E) :=
    fun e self v => visit_bytes e self v
  visit_none : {E : Type} → serde_core.de.Error E → Self → Result (core.result.Result Value E) :=
    fun e self => invalidType expecting e self .Option
  visit_some : {D Error : Type} → DeserializerF X D Error → Self → D →
    Result (core.result.Result Value Error) :=
    fun d self _ => invalidType expecting d.serde_coredeErrorInst self .Option
  visit_unit : {E : Type} → serde_core.de.Error E → Self → Result (core.result.Result Value E) :=
    fun e self => invalidType expecting e self .Unit
  visit_newtype_struct : {D Error : Type} → DeserializerF X D Error → Self → D →
    Result (core.result.Result Value Error) :=
    fun d self _ => invalidType expecting d.serde_coredeErrorInst self .NewtypeStruct
  visit_seq : {A Error : Type} → SeqAccessF X A Error → Self → A →
    Result (core.result.Result Value Error) :=
    fun a self _ => invalidType expecting a.serde_coredeErrorInst self .Seq
  visit_map : {A Error : Type} → MapAccessF X A Error → Self → A →
    Result (core.result.Result Value Error) :=
    fun a self _ => invalidType expecting a.serde_coredeErrorInst self .Map
  visit_enum : {A Error Variant : Type} → EnumAccessF X A Error Variant → Self → A →
    Result (core.result.Result Value Error) :=
    fun a self _ => invalidType expecting a.serde_coredeErrorInst self .Enum

/-- One level up: the data side over the format side at `X`. -/
def Step (X : Fam) : Fam where
  Deserialize := DeserializeStep X
  Seed := SeedStep X
  Visitor := VisitorStep X
  phantom := fun d => ⟨fun inst _ de => d.deserialize inst de⟩

end

/-! ## Maps along a morphism of knot families -/

section map
variable {X Y : Fam} (g : Fam.Hom Y X)

def DeserializerF.map {Self Error : Type} (d : DeserializerF X Self Error) :
    DeserializerF Y Self Error :=
  { serde_coredeErrorInst := d.serde_coredeErrorInst
    deserialize_any := fun v => d.deserialize_any (g.visitor v)
    deserialize_bool := fun v => d.deserialize_bool (g.visitor v)
    deserialize_i8 := fun v => d.deserialize_i8 (g.visitor v)
    deserialize_i16 := fun v => d.deserialize_i16 (g.visitor v)
    deserialize_i32 := fun v => d.deserialize_i32 (g.visitor v)
    deserialize_i64 := fun v => d.deserialize_i64 (g.visitor v)
    deserialize_i128 := fun v => d.deserialize_i128 (g.visitor v)
    deserialize_u8 := fun v => d.deserialize_u8 (g.visitor v)
    deserialize_u16 := fun v => d.deserialize_u16 (g.visitor v)
    deserialize_u32 := fun v => d.deserialize_u32 (g.visitor v)
    deserialize_u64 := fun v => d.deserialize_u64 (g.visitor v)
    deserialize_u128 := fun v => d.deserialize_u128 (g.visitor v)
    deserialize_f32 := fun v => d.deserialize_f32 (g.visitor v)
    deserialize_f64 := fun v => d.deserialize_f64 (g.visitor v)
    deserialize_char := fun v => d.deserialize_char (g.visitor v)
    deserialize_str := fun v => d.deserialize_str (g.visitor v)
    deserialize_string := fun v => d.deserialize_string (g.visitor v)
    deserialize_bytes := fun v => d.deserialize_bytes (g.visitor v)
    deserialize_byte_buf := fun v => d.deserialize_byte_buf (g.visitor v)
    deserialize_option := fun v => d.deserialize_option (g.visitor v)
    deserialize_unit := fun v => d.deserialize_unit (g.visitor v)
    deserialize_unit_struct := fun v => d.deserialize_unit_struct (g.visitor v)
    deserialize_newtype_struct := fun v => d.deserialize_newtype_struct (g.visitor v)
    deserialize_seq := fun v => d.deserialize_seq (g.visitor v)
    deserialize_tuple := fun v => d.deserialize_tuple (g.visitor v)
    deserialize_tuple_struct := fun v => d.deserialize_tuple_struct (g.visitor v)
    deserialize_map := fun v => d.deserialize_map (g.visitor v)
    deserialize_struct := fun v => d.deserialize_struct (g.visitor v)
    deserialize_enum := fun v => d.deserialize_enum (g.visitor v)
    deserialize_identifier := fun v => d.deserialize_identifier (g.visitor v)
    deserialize_ignored_any := fun v => d.deserialize_ignored_any (g.visitor v)
    is_human_readable := d.is_human_readable
    __deserialize_content_v1 := fun v => d.__deserialize_content_v1 (g.visitor v) }

def SeqAccessF.map {Self Error : Type} (d : SeqAccessF X Self Error) : SeqAccessF Y Self Error :=
  { serde_coredeErrorInst := d.serde_coredeErrorInst
    next_element_seed := fun s => d.next_element_seed (g.seed s)
    next_element := fun t => d.next_element (g.deserialize t)
    size_hint := d.size_hint }

def MapAccessF.map {Self Error : Type} (d : MapAccessF X Self Error) : MapAccessF Y Self Error :=
  { serde_coredeErrorInst := d.serde_coredeErrorInst
    next_key_seed := fun s => d.next_key_seed (g.seed s)
    next_value_seed := fun s => d.next_value_seed (g.seed s)
    next_entry_seed := fun k v => d.next_entry_seed (g.seed k) (g.seed v)
    next_key := fun t => d.next_key (g.deserialize t)
    next_value := fun t => d.next_value (g.deserialize t)
    next_entry := fun k v => d.next_entry (g.deserialize k) (g.deserialize v)
    size_hint := d.size_hint }

def VariantAccessF.map {Self Error : Type} (d : VariantAccessF X Self Error) :
    VariantAccessF Y Self Error :=
  { serde_coredeErrorInst := d.serde_coredeErrorInst
    unit_variant := d.unit_variant
    newtype_variant_seed := fun s => d.newtype_variant_seed (g.seed s)
    newtype_variant := fun t => d.newtype_variant (g.deserialize t)
    tuple_variant := fun v => d.tuple_variant (g.visitor v)
    struct_variant := fun v => d.struct_variant (g.visitor v) }

def EnumAccessF.map {Self Error Variant : Type} (d : EnumAccessF X Self Error Variant) :
    EnumAccessF Y Self Error Variant :=
  { serde_coredeErrorInst := d.serde_coredeErrorInst
    VariantAccessInst := d.VariantAccessInst.map g
    variant_seed := fun s => d.variant_seed (g.seed s)
    variant := fun t => d.variant (g.deserialize t) }

def DeserializeStep.map {Self : Type} (d : DeserializeStep Y Self) : DeserializeStep X Self :=
  ⟨fun inst de => d.deserialize (inst.map g) de⟩

def SeedStep.map {Self Value : Type} (d : SeedStep Y Self Value) : SeedStep X Self Value :=
  ⟨fun inst self de => d.deserialize (inst.map g) self de⟩

def VisitorStep.map {Self Value : Type} (d : VisitorStep Y Self Value) : VisitorStep X Self Value :=
  { expecting := d.expecting
    visit_bool := d.visit_bool, visit_i64 := d.visit_i64, visit_i8 := d.visit_i8
    visit_i16 := d.visit_i16, visit_i32 := d.visit_i32, visit_i128 := d.visit_i128
    visit_u64 := d.visit_u64, visit_u8 := d.visit_u8, visit_u16 := d.visit_u16
    visit_u32 := d.visit_u32, visit_u128 := d.visit_u128, visit_f64 := d.visit_f64
    visit_f32 := d.visit_f32, visit_str := d.visit_str, visit_char := d.visit_char
    visit_borrowed_str := d.visit_borrowed_str, visit_string := d.visit_string
    visit_bytes := d.visit_bytes, visit_borrowed_bytes := d.visit_borrowed_bytes
    visit_byte_buf := d.visit_byte_buf, visit_none := d.visit_none
    visit_some := fun inst => d.visit_some (inst.map g)
    visit_unit := d.visit_unit
    visit_newtype_struct := fun inst => d.visit_newtype_struct (inst.map g)
    visit_seq := fun inst => d.visit_seq (inst.map g)
    visit_map := fun inst => d.visit_map (inst.map g)
    visit_enum := fun inst => d.visit_enum (inst.map g) }

/-- A morphism one level up. -/
def Fam.Hom.step (g : Fam.Hom Y X) : Fam.Hom (Step Y) (Step X) where
  deserialize := fun d => d.map g
  seed := fun d => d.map g
  visitor := fun d => d.map g
end map

/-! ## Levels and the limit -/

/-- The data-side dictionaries usable with formats nesting at most `n` data-side calls. -/
def DeAt : Nat → Fam
  | 0 => ⟨fun _ => PUnit, fun _ _ => PUnit, fun _ _ => PUnit, fun _ => PUnit.unit⟩
  | n + 1 => Step (DeAt n)

structure DeserializeΩ (T : Type) : Type 1 where
  level : ∀ n, (DeAt n).Deserialize T

structure SeedΩ (T Value : Type) : Type 1 where
  level : ∀ n, (DeAt n).Seed T Value

structure VisitorΩ (V Value : Type) : Type 1 where
  level : ∀ n, (DeAt n).Visitor V Value

/-- The knot positions of the Rust format side: data-side dictionaries at every level. -/
@[reducible] def Ω : Fam where
  Deserialize := DeserializeΩ
  Seed := SeedΩ
  Visitor := VisitorΩ
  phantom := fun d => ⟨fun n => (DeAt n).phantom (d.level n)⟩

/-- The projection of the limit to level `n`. -/
def proj (n : Nat) : Fam.Hom Ω (DeAt n) where
  deserialize := fun d => d.level n
  seed := fun d => d.level n
  visitor := fun d => d.level n

end serde_core.de

/-! ## The Rust traits -/

@[reducible, rust_trait "serde_core::de::Deserializer" (parentClauses := ["serde_coredeErrorInst"])
  (methods := ["deserialize_any", "deserialize_bool", "deserialize_i8", "deserialize_i16",
    "deserialize_i32", "deserialize_i64", "deserialize_i128", "deserialize_u8", "deserialize_u16",
    "deserialize_u32", "deserialize_u64", "deserialize_u128", "deserialize_f32",
    "deserialize_f64", "deserialize_char", "deserialize_str", "deserialize_string",
    "deserialize_bytes", "deserialize_byte_buf", "deserialize_option", "deserialize_unit",
    "deserialize_unit_struct", "deserialize_newtype_struct", "deserialize_seq",
    "deserialize_tuple", "deserialize_tuple_struct", "deserialize_map", "deserialize_struct",
    "deserialize_enum", "deserialize_identifier", "deserialize_ignored_any",
    "is_human_readable", "__deserialize_content_v1"])
  (defaultMethods := ["deserialize_i128", "deserialize_u128", "is_human_readable",
    "__deserialize_content_v1"])]
def serde_core.de.Deserializer := serde_core.de.DeserializerF serde_core.de.Ω

@[reducible, rust_trait "serde_core::de::SeqAccess" (parentClauses := ["serde_coredeErrorInst"])
  (methods := ["next_element_seed", "next_element", "size_hint"])
  (defaultMethods := ["next_element", "size_hint"])]
def serde_core.de.SeqAccess := serde_core.de.SeqAccessF serde_core.de.Ω

@[reducible, rust_trait "serde_core::de::MapAccess" (parentClauses := ["serde_coredeErrorInst"])
  (methods := ["next_key_seed", "next_value_seed", "next_entry_seed", "next_key", "next_value",
    "next_entry", "size_hint"])
  (defaultMethods := ["next_entry_seed", "next_key", "next_value", "next_entry", "size_hint"])]
def serde_core.de.MapAccess := serde_core.de.MapAccessF serde_core.de.Ω

@[reducible, rust_trait "serde_core::de::VariantAccess"
  (parentClauses := ["serde_coredeErrorInst"])
  (methods := ["unit_variant", "newtype_variant_seed", "newtype_variant", "tuple_variant",
    "struct_variant"])
  (defaultMethods := ["newtype_variant"])]
def serde_core.de.VariantAccess := serde_core.de.VariantAccessF serde_core.de.Ω

@[reducible, rust_trait "serde_core::de::EnumAccess"
  (parentClauses := ["serde_coredeErrorInst", "VariantAccessInst"])
  (methods := ["variant_seed", "variant"]) (defaultMethods := ["variant"])]
def serde_core.de.EnumAccess := serde_core.de.EnumAccessF serde_core.de.Ω

@[reducible, rust_trait "serde_core::de::Deserialize" (methods := ["deserialize"])
  (knot := "Aeneas.Std.serde_core.de.Deserialize.wrap")]
def serde_core.de.Deserialize := serde_core.de.DeserializeStep serde_core.de.Ω

@[reducible, rust_trait "serde_core::de::DeserializeSeed" (methods := ["deserialize"])
  (knot := "Aeneas.Std.serde_core.de.DeserializeSeed.wrap")]
def serde_core.de.DeserializeSeed := serde_core.de.SeedStep serde_core.de.Ω

@[reducible, rust_trait "serde_core::de::Visitor"
  (methods := ["expecting", "visit_bool", "visit_i8", "visit_i16", "visit_i32", "visit_i64",
    "visit_i128", "visit_u8", "visit_u16", "visit_u32", "visit_u64", "visit_u128", "visit_f32",
    "visit_f64", "visit_char", "visit_str", "visit_borrowed_str", "visit_string", "visit_bytes",
    "visit_borrowed_bytes", "visit_byte_buf", "visit_none", "visit_some", "visit_unit",
    "visit_newtype_struct", "visit_seq", "visit_map", "visit_enum"])
  (defaultMethods := ["visit_bool", "visit_i8", "visit_i16", "visit_i32", "visit_i64",
    "visit_i128", "visit_u8", "visit_u16", "visit_u32", "visit_u64", "visit_u128", "visit_f32",
    "visit_f64", "visit_char", "visit_str", "visit_borrowed_str", "visit_string", "visit_bytes",
    "visit_borrowed_bytes", "visit_byte_buf", "visit_none", "visit_some", "visit_unit",
    "visit_newtype_struct", "visit_seq", "visit_map", "visit_enum"])
  (knot := "Aeneas.Std.serde_core.de.Visitor.wrap")]
def serde_core.de.Visitor := serde_core.de.VisitorStep serde_core.de.Ω

namespace serde_core.de

/-! ## The knot -/

def Deserialize.wrap {T : Type} (d : serde_core.de.Deserialize T) : DeserializeΩ T :=
  ⟨fun n => match n with
    | 0 => PUnit.unit
    | n + 1 => DeserializeStep.map (proj n) d⟩

def DeserializeSeed.wrap {T Value : Type} (d : serde_core.de.DeserializeSeed T Value) :
    SeedΩ T Value :=
  ⟨fun n => match n with
    | 0 => PUnit.unit
    | n + 1 => SeedStep.map (proj n) d⟩

def Visitor.wrap {V Value : Type} (d : serde_core.de.Visitor V Value) : VisitorΩ V Value :=
  ⟨fun n => match n with
    | 0 => PUnit.unit
    | n + 1 => VisitorStep.map (proj n) d⟩

/-- The knot is definitional: at level `n + 1` a wrapped dictionary runs against the level-`n`
    formats. -/
theorem Deserialize.wrap_level_succ {T : Type} (d : serde_core.de.Deserialize T) (n : Nat) :
    (Deserialize.wrap d).level (n + 1) = DeserializeStep.map (proj n) d := rfl

theorem DeserializeSeed.wrap_level_succ {T Value : Type} (d : serde_core.de.DeserializeSeed T Value)
    (n : Nat) : (DeserializeSeed.wrap d).level (n + 1) = SeedStep.map (proj n) d := rfl

theorem Visitor.wrap_level_succ {V Value : Type} (d : serde_core.de.Visitor V Value) (n : Nat) :
    (Visitor.wrap d).level (n + 1) = VisitorStep.map (proj n) d := rfl

/-! ## Every Rust format has an encoding -/

/-- The types of a Rust format: its deserializers, sequence/map/enum/variant access types (each
    family indexed by its own index type) with their associated types. -/
structure FormatTypes where
  ιD : Type
  D : ιD → Type
  DError : ιD → Type
  ιS : Type
  S : ιS → Type
  SError : ιS → Type
  ιM : Type
  M : ιM → Type
  MError : ιM → Type
  ιE : Type
  E : ιE → Type
  EError : ιE → Type
  EVariant : ιE → Type
  ιV : Type
  V : ιV → Type
  VError : ιV → Type

/-- The format-side dictionaries of the family at the knot family `X`. -/
structure FormatTypes.Dicts (τ : FormatTypes) (X : Fam) : Type 1 where
  des : ∀ i, DeserializerF X (τ.D i) (τ.DError i)
  seqs : ∀ i, SeqAccessF X (τ.S i) (τ.SError i)
  maps : ∀ i, MapAccessF X (τ.M i) (τ.MError i)
  enums : ∀ i, EnumAccessF X (τ.E i) (τ.EError i) (τ.EVariant i)
  variants : ∀ i, VariantAccessF X (τ.V i) (τ.VError i)

/-- A Rust format: its dictionaries, generic in the knot family, given the family's dictionaries one
    level down. A received `X'.Visitor` (resp. seed, `Deserialize`) at `X' = Step X` can only be run
    against format-side dictionaries at `X`: the family one level down, or dictionaries built from
    it, as a Rust format calls `visitor.visit_seq(access)` or `seed.deserialize(sub)`. -/
structure FormatProgram (τ : FormatTypes) where
  base : τ.Dicts (DeAt 0)
  step : ∀ (X : Fam), τ.Dicts X → τ.Dicts (Step X)

def FormatProgram.level {τ : FormatTypes} (p : FormatProgram τ) : (n : Nat) → τ.Dicts (DeAt n)
  | 0 => p.base
  | n + 1 => p.step (DeAt n) (p.level n)

/-- The encoded deserializers of a Rust format, with nesting bound `n`. -/
def FormatProgram.encode {τ : FormatTypes} (p : FormatProgram τ) (n : Nat) (i : τ.ιD) :
    serde_core.de.Deserializer (τ.D i) (τ.DError i) :=
  ((p.level n).des i).map (proj n)

def FormatProgram.encodeSeq {τ : FormatTypes} (p : FormatProgram τ) (n : Nat) (i : τ.ιS) :
    serde_core.de.SeqAccess (τ.S i) (τ.SError i) :=
  ((p.level n).seqs i).map (proj n)

def FormatProgram.encodeMap {τ : FormatTypes} (p : FormatProgram τ) (n : Nat) (i : τ.ιM) :
    serde_core.de.MapAccess (τ.M i) (τ.MError i) :=
  ((p.level n).maps i).map (proj n)

def FormatProgram.encodeEnum {τ : FormatTypes} (p : FormatProgram τ) (n : Nat) (i : τ.ιE) :
    serde_core.de.EnumAccess (τ.E i) (τ.EError i) (τ.EVariant i) :=
  ((p.level n).enums i).map (proj n)

/-- The encoded format at bound `n + 1` is the program's step over the level-`n` family, with the
    nested dictionaries projected to level `n + 1`. -/
theorem FormatProgram.encode_succ {τ : FormatTypes} (p : FormatProgram τ) (n : Nat) (i : τ.ιD) :
    p.encode (n + 1) i = ((p.step (DeAt n) (p.level n)).des i).map (proj (n + 1)) := rfl

/-- A received wrapped visitor, run with an access dictionary of the family one level down, runs
    the Rust visitor with that access dictionary's encoding: the Rust semantics of
    `visitor.visit_seq(access)` inside a format. -/
theorem FormatProgram.visit_seq_wrap {τ : FormatTypes} (p : FormatProgram τ) {V Value : Type}
    (d : serde_core.de.Visitor V Value) (n : Nat) (j : τ.ιS) :
    ((Visitor.wrap d).level (n + 1)).visit_seq ((p.level n).seqs j) =
      d.visit_seq (p.encodeSeq n j) := rfl

theorem FormatProgram.visit_map_wrap {τ : FormatTypes} (p : FormatProgram τ) {V Value : Type}
    (d : serde_core.de.Visitor V Value) (n : Nat) (j : τ.ιM) :
    ((Visitor.wrap d).level (n + 1)).visit_map ((p.level n).maps j) =
      d.visit_map (p.encodeMap n j) := rfl

theorem FormatProgram.visit_enum_wrap {τ : FormatTypes} (p : FormatProgram τ) {V Value : Type}
    (d : serde_core.de.Visitor V Value) (n : Nat) (j : τ.ιE) :
    ((Visitor.wrap d).level (n + 1)).visit_enum ((p.level n).enums j) =
      d.visit_enum (p.encodeEnum n j) := rfl

theorem FormatProgram.visit_some_wrap {τ : FormatTypes} (p : FormatProgram τ) {V Value : Type}
    (d : serde_core.de.Visitor V Value) (n : Nat) (j : τ.ιD) :
    ((Visitor.wrap d).level (n + 1)).visit_some ((p.level n).des j) =
      d.visit_some (p.encode n j) := rfl

/-- `seed.deserialize(sub)` / `T::deserialize(sub)` inside a format. -/
theorem FormatProgram.seed_wrap {τ : FormatTypes} (p : FormatProgram τ) {T Value : Type}
    (d : serde_core.de.DeserializeSeed T Value) (n : Nat) (j : τ.ιD) :
    ((DeserializeSeed.wrap d).level (n + 1)).deserialize ((p.level n).des j) =
      d.deserialize (p.encode n j) := rfl

theorem FormatProgram.deserialize_wrap {τ : FormatTypes} (p : FormatProgram τ) {T : Type}
    (d : serde_core.de.Deserialize T) (n : Nat) (j : τ.ιD) :
    ((Deserialize.wrap d).level (n + 1)).deserialize ((p.level n).des j) =
      d.deserialize (p.encode n j) := rfl

/-- An error type's dictionary whose methods diverge. -/
def bottomError (Error : Type) : serde_core.de.Error Error :=
  { coreerrorErrorInst := ⟨⟨fun _ _ => .div⟩, ⟨fun _ _ => .div⟩⟩, custom := fun _ _ => .div }

/-- Every family of format types has a program (e.g. the one whose methods diverge): the
    `Deserializer` dictionaries of statements about data-side implementations are never vacuous. -/
def bottom (X : Fam) (τ : FormatTypes) : τ.Dicts X where
  des := fun i =>
    { serde_coredeErrorInst := bottomError (τ.DError i)
      deserialize_any := fun _ _ _ => .div, deserialize_bool := fun _ _ _ => .div
      deserialize_i8 := fun _ _ _ => .div, deserialize_i16 := fun _ _ _ => .div
      deserialize_i32 := fun _ _ _ => .div, deserialize_i64 := fun _ _ _ => .div
      deserialize_u8 := fun _ _ _ => .div, deserialize_u16 := fun _ _ _ => .div
      deserialize_u32 := fun _ _ _ => .div, deserialize_u64 := fun _ _ _ => .div
      deserialize_f32 := fun _ _ _ => .div, deserialize_f64 := fun _ _ _ => .div
      deserialize_char := fun _ _ _ => .div, deserialize_str := fun _ _ _ => .div
      deserialize_string := fun _ _ _ => .div, deserialize_bytes := fun _ _ _ => .div
      deserialize_byte_buf := fun _ _ _ => .div, deserialize_option := fun _ _ _ => .div
      deserialize_unit := fun _ _ _ => .div, deserialize_unit_struct := fun _ _ _ _ => .div
      deserialize_newtype_struct := fun _ _ _ _ => .div, deserialize_seq := fun _ _ _ => .div
      deserialize_tuple := fun _ _ _ _ => .div, deserialize_tuple_struct := fun _ _ _ _ _ => .div
      deserialize_map := fun _ _ _ => .div, deserialize_struct := fun _ _ _ _ _ => .div
      deserialize_enum := fun _ _ _ _ _ => .div, deserialize_identifier := fun _ _ _ => .div
      deserialize_ignored_any := fun _ _ _ => .div
      deserialize_i128 := fun _ _ _ => .div, deserialize_u128 := fun _ _ _ => .div
      is_human_readable := fun _ => .div
      __deserialize_content_v1 := fun _ _ _ => .div }
  seqs := fun i => { serde_coredeErrorInst := bottomError (τ.SError i),
                     next_element_seed := fun _ _ _ => .div, size_hint := fun _ => .div }
  maps := fun i => { serde_coredeErrorInst := bottomError (τ.MError i),
                     next_key_seed := fun _ _ _ => .div, next_value_seed := fun _ _ _ => .div,
                     size_hint := fun _ => .div }
  enums := fun i => { serde_coredeErrorInst := bottomError (τ.EError i),
                      VariantAccessInst := { serde_coredeErrorInst := bottomError (τ.EError i),
                                             unit_variant := fun _ => .div,
                                             newtype_variant_seed := fun _ _ _ => .div,
                                             tuple_variant := fun _ _ _ _ => .div,
                                             struct_variant := fun _ _ _ _ => .div },
                      variant_seed := fun _ _ _ => .div }
  variants := fun i => { serde_coredeErrorInst := bottomError (τ.VError i),
                         unit_variant := fun _ => .div, newtype_variant_seed := fun _ _ _ => .div,
                         tuple_variant := fun _ _ _ _ => .div, struct_variant := fun _ _ _ _ => .div }

/-! ## Formats without a nesting bound

A format that serde builds inside a data-side implementation (`ContentDeserializer`,
`SeqAccessDeserializer`) is a Rust trait dictionary (`Ω`): it has no nesting bound of its own. Its
runs are those of its levels: at a level too small for the nested calls a run reaches the
diverging dictionaries of level `0` (`bottom`, `bottomData`), which no data-side code can observe,
and every large enough level gives the same result. `limitFrom` takes the first level with a
result.

### The cut-monotonicity invariant

`limitFrom` and `consumedRun` (`Serde/Content.lean`) take the first defined run of a search. A
defined run gives the native result only under two conditions on the data side.

- Strictness. Every data-side dictionary that a format receives is strict in `.div`. If a callee
  gives `.div`, the caller gives `.div`. Aeneas-extracted code obeys this (monadic `do`, the
  strict `loop`). The data-side models of this library bind with `←` and obey it too.
- Cut. The level-`m` version of a dictionary is the same code, cut at depth `m`. The cut
  dictionaries (`bottom`, `bottomError`, `bottomVisitor`, `bottomData`) diverge in every method.
  The access with budget `k` of `consumedRun` is the same access, cut after `k` elements.

Then the runs at increasing levels or budgets form a chain in the flat order (`IsChain`). For
`m ≤ n`, the run `m` diverges or gives the result of the run `n`. Thus a defined run gives the
result of every larger level, which is the native result. Only `limitFrom`, `consumedRun` and
`loop` match on `.div`. A data-side model must not match on `.div`, because such a match can
break strictness.

The lemmas below and after `consumedRun` prove the consequences from `IsChain`. `IsChain` itself
is the invariant of the library constructions (`Visitor.wrap`, `Deserialize.wrap`,
`DeserializeSeed.wrap`, `embed`, `lvl`, `contentAt`, `tagOrContentAt`). It is not a theorem here.
The levels of a dictionary have different types, and a proof needs a relation between the
levels. -/

/-- The first result of `f n`, `f (n + 1)`, ...: diverges when every level does. -/
def limitFrom {α : Type} (f : Nat → Result α) (n : Nat) : Result α :=
  match f n with
  | .div => limitFrom f (n + 1)
  | r => r
partial_fixpoint

/-- The values of `f` form a chain in the flat order. -/
def IsChain {α : Type} (f : Nat → Result α) : Prop :=
  -- A defined value stays.
  ∀ m n, m ≤ n → f m = .div ∨ f m = f n

/-- A defined level is the result. -/
theorem limitFrom_of_ne_div {α : Type} (f : Nat → Result α) (n : Nat)
    -- The level gives a result.
    (h : f n ≠ .div) : limitFrom f n = f n := by
  -- Unfold one step.
  rw [limitFrom.eq_def]
  split
  · contradiction
  · rfl

/-- A diverging level goes one level up. -/
theorem limitFrom_of_div {α : Type} (f : Nat → Result α) (n : Nat)
    -- The level diverges.
    (h : f n = .div) : limitFrom f n = limitFrom f (n + 1) := by
  -- Unfold one step.
  rw [limitFrom.eq_def, h]

/-- On a chain, the result is every defined level. -/
theorem limitFrom_eq_of_chain {α : Type} {f : Nat → Result α}
    -- The chain.
    (hc : IsChain f) {k n : Nat} (hkn : k ≤ n)
    -- A level with a result.
    (hn : f n ≠ .div) : limitFrom f k = f n := by
  -- Induction on the distance.
  induction hd : n - k generalizing k with

  | zero =>
    -- The level is the start.
    rw [show k = n by omega]
    exact limitFrom_of_ne_div f n hn

  | succ d ih =>
    -- The start diverges or not.
    by_cases hk : f k = .div
    · rw [limitFrom_of_div f k hk]
      exact ih (by omega) (by omega)

    -- The chain gives the value.
    · rw [limitFrom_of_ne_div f k hk]
      rcases hc k n hkn with h' | h'
      · exact absurd h' hk
      · exact h'

/-- A defined result is the value of a level, also without a chain. -/
theorem limitFrom_defined {α : Type} (f : Nat → Result α) (k : Nat)
    -- The result does not diverge.
    (h : limitFrom f k ≠ .div) :
    ∃ n, k ≤ n ∧ f n = limitFrom f k := by
  -- Fixpoint induction.
  suffices key : ∀ k,
      -- The result diverges or is a level.
      limitFrom f k = .div ∨ ∃ n, k ≤ n ∧ f n = limitFrom f k by

    -- Use the property at the start.
    rcases key k with h' | h'
    · exact absurd h' h
    · exact h'

  -- The motive.
  refine limitFrom.fixpoint_induct f
    (fun g => ∀ k, g k = .div ∨ ∃ n, k ≤ n ∧ f n = g k) ?_ ?_

  -- The property is admissible.
  · refine Lean.Order.admissible_pi_apply
      (fun k r => r = .div ∨ ∃ n, k ≤ n ∧ f n = r) ?_
    -- The property holds at the bottom.
    intro k
    exact Lean.Order.admissible_flatOrder (b := Result.div) _ (Or.inl rfl)

  -- One step.
  · intro g ih k
    dsimp only
    split
    -- The level diverges.
    · rcases ih (k + 1) with h' | ⟨n, hn, h'⟩
      · exact Or.inl h'
      -- A later level.
      · exact Or.inr ⟨n, by omega, h'⟩
    -- The level gives the result.
    · exact Or.inr ⟨k, Nat.le_refl k, rfl⟩

/-- A visitor whose methods diverge. -/
def bottomVisitor (X : Fam) (V Value : Type) : VisitorStep X V Value :=
  { expecting := fun _ _ => .div
    visit_bool := fun _ _ _ => .div, visit_i64 := fun _ _ _ => .div
    visit_i8 := fun _ _ _ => .div, visit_i16 := fun _ _ _ => .div
    visit_i32 := fun _ _ _ => .div, visit_i128 := fun _ _ _ => .div
    visit_u64 := fun _ _ _ => .div, visit_u8 := fun _ _ _ => .div
    visit_u16 := fun _ _ _ => .div, visit_u32 := fun _ _ _ => .div
    visit_u128 := fun _ _ _ => .div, visit_f64 := fun _ _ _ => .div
    visit_f32 := fun _ _ _ => .div, visit_str := fun _ _ _ => .div
    visit_char := fun _ _ _ => .div, visit_borrowed_str := fun _ _ _ => .div
    visit_string := fun _ _ _ => .div, visit_bytes := fun _ _ _ => .div
    visit_borrowed_bytes := fun _ _ _ => .div, visit_byte_buf := fun _ _ _ => .div
    visit_none := fun _ _ => .div, visit_some := fun _ _ _ => .div
    visit_unit := fun _ _ => .div, visit_newtype_struct := fun _ _ _ => .div
    visit_seq := fun _ _ _ => .div, visit_map := fun _ _ _ => .div
    visit_enum := fun _ _ _ => .div }

/-- The data side above level `0`: dictionaries whose methods diverge. -/
def bottomData (X : Fam) : Fam.Hom (DeAt 0) (Step X) where
  deserialize := fun _ => ⟨fun _ _ => .div⟩
  seed := fun _ => ⟨fun _ _ _ => .div⟩
  visitor := fun {V Value} _ => bottomVisitor X V Value

/-- A data-side dictionary of level `n` at level `m`: the same dictionary with the levels of its
    nested formats adjusted, cut below level `n` (the dictionaries it builds for nested values
    diverge `n` levels down). -/
def lvl : (n m : Nat) → Fam.Hom (DeAt n) (DeAt m)
  | _, 0 => ⟨fun _ => PUnit.unit, fun _ => PUnit.unit, fun _ => PUnit.unit⟩
  | 0, _ + 1 => bottomData _
  | n + 1, m + 1 => (lvl n m).step

/-- A data-side dictionary of level `n` at every level. -/
def embed (n : Nat) : Fam.Hom (DeAt n) Ω where
  deserialize := fun d => ⟨fun m => (lvl n m).deserialize d⟩
  seed := fun d => ⟨fun m => (lvl n m).seed d⟩
  visitor := fun d => ⟨fun m => (lvl n m).visitor d⟩

/-- The dictionaries of a Rust format at every level of the knot (a `FormatProgram`'s `level`, or
    dictionaries built level by level because the format itself calls data-side implementations,
    e.g. `ContentDeserializer`'s `unit_variant`). -/
abbrev FormatLevels (τ : FormatTypes) := (n : Nat) → τ.Dicts (DeAt n)

/-- The deserializer `i` of a format as a Rust trait dictionary: each method runs at the first
    level (from `1`) with a result. The error dictionary is the format's (level `0` is `bottom`). -/
def FormatLevels.limit {τ : FormatTypes} (lv : FormatLevels τ) (i : τ.ιD)
    (errInst : serde_core.de.Error (τ.DError i)) :
    serde_core.de.Deserializer (τ.D i) (τ.DError i) :=
  let enc := fun n => ((lv n).des i).map (proj n)
  { serde_coredeErrorInst := errInst
    deserialize_any := fun v self x => limitFrom (fun n => (enc n).deserialize_any v self x) 1
    deserialize_bool := fun v self x => limitFrom (fun n => (enc n).deserialize_bool v self x) 1
    deserialize_i8 := fun v self x => limitFrom (fun n => (enc n).deserialize_i8 v self x) 1
    deserialize_i16 := fun v self x => limitFrom (fun n => (enc n).deserialize_i16 v self x) 1
    deserialize_i32 := fun v self x => limitFrom (fun n => (enc n).deserialize_i32 v self x) 1
    deserialize_i64 := fun v self x => limitFrom (fun n => (enc n).deserialize_i64 v self x) 1
    deserialize_i128 := fun v self x => limitFrom (fun n => (enc n).deserialize_i128 v self x) 1
    deserialize_u8 := fun v self x => limitFrom (fun n => (enc n).deserialize_u8 v self x) 1
    deserialize_u16 := fun v self x => limitFrom (fun n => (enc n).deserialize_u16 v self x) 1
    deserialize_u32 := fun v self x => limitFrom (fun n => (enc n).deserialize_u32 v self x) 1
    deserialize_u64 := fun v self x => limitFrom (fun n => (enc n).deserialize_u64 v self x) 1
    deserialize_u128 := fun v self x => limitFrom (fun n => (enc n).deserialize_u128 v self x) 1
    deserialize_f32 := fun v self x => limitFrom (fun n => (enc n).deserialize_f32 v self x) 1
    deserialize_f64 := fun v self x => limitFrom (fun n => (enc n).deserialize_f64 v self x) 1
    deserialize_char := fun v self x => limitFrom (fun n => (enc n).deserialize_char v self x) 1
    deserialize_str := fun v self x => limitFrom (fun n => (enc n).deserialize_str v self x) 1
    deserialize_string := fun v self x =>
      limitFrom (fun n => (enc n).deserialize_string v self x) 1
    deserialize_bytes := fun v self x => limitFrom (fun n => (enc n).deserialize_bytes v self x) 1
    deserialize_byte_buf := fun v self x =>
      limitFrom (fun n => (enc n).deserialize_byte_buf v self x) 1
    deserialize_option := fun v self x =>
      limitFrom (fun n => (enc n).deserialize_option v self x) 1
    deserialize_unit := fun v self x => limitFrom (fun n => (enc n).deserialize_unit v self x) 1
    deserialize_unit_struct := fun v self name x =>
      limitFrom (fun n => (enc n).deserialize_unit_struct v self name x) 1
    deserialize_newtype_struct := fun v self name x =>
      limitFrom (fun n => (enc n).deserialize_newtype_struct v self name x) 1
    deserialize_seq := fun v self x => limitFrom (fun n => (enc n).deserialize_seq v self x) 1
    deserialize_tuple := fun v self len x =>
      limitFrom (fun n => (enc n).deserialize_tuple v self len x) 1
    deserialize_tuple_struct := fun v self name len x =>
      limitFrom (fun n => (enc n).deserialize_tuple_struct v self name len x) 1
    deserialize_map := fun v self x => limitFrom (fun n => (enc n).deserialize_map v self x) 1
    deserialize_struct := fun v self name fields x =>
      limitFrom (fun n => (enc n).deserialize_struct v self name fields x) 1
    deserialize_enum := fun v self name variants x =>
      limitFrom (fun n => (enc n).deserialize_enum v self name variants x) 1
    deserialize_identifier := fun v self x =>
      limitFrom (fun n => (enc n).deserialize_identifier v self x) 1
    deserialize_ignored_any := fun v self x =>
      limitFrom (fun n => (enc n).deserialize_ignored_any v self x) 1
    is_human_readable := fun self => limitFrom (fun n => (enc n).is_human_readable self) 1
    __deserialize_content_v1 := fun v self x =>
      limitFrom (fun n => (enc n).__deserialize_content_v1 v self x) 1 }

end serde_core.de

end Aeneas.Std
