import Aeneas.Std.Core.Core
import Aeneas.Std.Float

/-!
# Models of the `half` 2.7.1 crate

Every conversion below is a transliteration of the crate's software algorithm
on raw bits (`src/binary16/arch.rs` `*_fallback`, `src/bfloat/convert.rs`),
including its NaN payload rules and `bf16::from_f64`'s truncation of the low
32 bits of the `f64` encoding. `Nat` arithmetic stands for the crate's `u32`/
`u64` arithmetic: no intermediate value of these algorithms leaves the Rust
integer range, and every `as u16` narrowing is written as `% 2 ^ 16`.

On aarch64 targets with `fp16` (the Chelis build hosts), `f16::from_f32`,
`f16::to_f32` and `f16::to_f64` dispatch to `FCVT`; the fixture
`verification/crate_model_oracle` checks exhaustively that the hardware results
equal these software algorithms bit for bit.

The comparison impls are the crate's bit-level algorithms; the lemmas at the end
of this file prove that they coincide with `BinaryFloat.eq/lt/le/partialCmp`.
-/

namespace Aeneas.Std

namespace Half

/-- `u16::leading_zeros` (half's `leading_zeros_u16`). -/
def leadingZerosU16 (x : Nat) : Nat := if x = 0 then 16 else 15 - x.log2

/-- `binary16/arch.rs::f32_to_f16_fallback`, from `u32` bits to `u16` bits. -/
def f32ToF16 (x : Nat) : Nat :=
  let sign := x &&& 0x8000_0000
  let exp := x &&& 0x7F80_0000
  let man := x &&& 0x007F_FFFF
  if exp == 0x7F80_0000 then
    let nanBit := if man == 0 then 0 else 0x0200
    ((sign >>> 16) ||| 0x7C00 ||| nanBit ||| (man >>> 13)) % 2 ^ 16
  else
    let halfSign := sign >>> 16
    let unbiasedExp : Int := ((exp >>> 23 : Nat) : Int) - 127
    let halfExp := unbiasedExp + 15
    if halfExp ≥ 0x1F then (halfSign ||| 0x7C00) % 2 ^ 16
    else if halfExp ≤ 0 then
      if 14 - halfExp > 24 then halfSign % 2 ^ 16
      else
        let man := man ||| 0x0080_0000
        let halfMan := man >>> (14 - halfExp).toNat
        let roundBit := 1 <<< (13 - halfExp).toNat
        let halfMan :=
          if man &&& roundBit != 0 && man &&& (3 * roundBit - 1) != 0 then halfMan + 1
          else halfMan
        (halfSign ||| halfMan) % 2 ^ 16
    else
      let halfExp := halfExp.toNat <<< 10
      let halfMan := man >>> 13
      let roundBit := 0x0000_1000
      if man &&& roundBit != 0 && man &&& (3 * roundBit - 1) != 0 then
        ((halfSign ||| halfExp ||| halfMan) + 1) % 2 ^ 16
      else (halfSign ||| halfExp ||| halfMan) % 2 ^ 16

/-- `binary16/arch.rs::f16_to_f32_fallback`, from `u16` bits to `u32` bits. -/
def f16ToF32 (i : Nat) : Nat :=
  if i &&& 0x7FFF == 0 then i <<< 16
  else
    let halfSign := i &&& 0x8000
    let halfExp := i &&& 0x7C00
    let halfMan := i &&& 0x03FF
    if halfExp == 0x7C00 then
      if halfMan == 0 then (halfSign <<< 16) ||| 0x7F80_0000
      else (halfSign <<< 16) ||| 0x7FC0_0000 ||| (halfMan <<< 13)
    else
      let sign := halfSign <<< 16
      let unbiasedExp : Int := ((halfExp >>> 10 : Nat) : Int) - 15
      if halfExp == 0 then
        let e := leadingZerosU16 halfMan - 6
        let exp := (127 - 15 - e) <<< 23
        let man := (halfMan <<< (14 + e)) &&& 0x7F_FFFF
        sign ||| exp ||| man
      else
        let exp := (unbiasedExp + 127).toNat <<< 23
        let man := (halfMan &&& 0x03FF) <<< 13
        sign ||| exp ||| man

/-- `binary16/arch.rs::f16_to_f64_fallback`, from `u16` bits to `u64` bits. -/
def f16ToF64 (i : Nat) : Nat :=
  if i &&& 0x7FFF == 0 then i <<< 48
  else
    let halfSign := i &&& 0x8000
    let halfExp := i &&& 0x7C00
    let halfMan := i &&& 0x03FF
    if halfExp == 0x7C00 then
      if halfMan == 0 then (halfSign <<< 48) ||| 0x7FF0_0000_0000_0000
      else (halfSign <<< 48) ||| 0x7FF8_0000_0000_0000 ||| (halfMan <<< 42)
    else
      let sign := halfSign <<< 48
      let unbiasedExp : Int := ((halfExp >>> 10 : Nat) : Int) - 15
      if halfExp == 0 then
        let e := leadingZerosU16 halfMan - 6
        let exp := (1023 - 15 - e) <<< 52
        let man := (halfMan <<< (43 + e)) &&& 0xF_FFFF_FFFF_FFFF
        sign ||| exp ||| man
      else
        let exp := (unbiasedExp + 1023).toNat <<< 52
        let man := (halfMan &&& 0x03FF) <<< 42
        sign ||| exp ||| man

/-- `bfloat/convert.rs::f32_to_bf16`, from `u32` bits to `u16` bits. The final
    `u16` increment cannot overflow: a carry out of `0xFFFF` would need the NaN
    encodings excluded by the first branch. -/
def f32ToBf16 (x : Nat) : Nat :=
  if x &&& 0x7FFF_FFFF > 0x7F80_0000 then ((x >>> 16) ||| 0x0040) % 2 ^ 16
  else
    let roundBit := 0x0000_8000
    if x &&& roundBit != 0 && x &&& (3 * roundBit - 1) != 0 then (x >>> 16) % 2 ^ 16 + 1
    else (x >>> 16) % 2 ^ 16

/-- `bfloat/convert.rs::f64_to_bf16`, from `u64` bits to `u16` bits. Only the
    high 32 bits take part in rounding; the low 32 bits only decide NaN-ness. -/
def f64ToBf16 (val : Nat) : Nat :=
  let x := (val >>> 32) % 2 ^ 32
  let sign := x &&& 0x8000_0000
  let exp := x &&& 0x7FF0_0000
  let man := x &&& 0x000F_FFFF
  if exp == 0x7FF0_0000 then
    let nanBit := if man == 0 && val % 2 ^ 32 == 0 then 0 else 0x0040
    ((sign >>> 16) ||| 0x7F80 ||| nanBit ||| (man >>> 13)) % 2 ^ 16
  else
    let halfSign := sign >>> 16
    let unbiasedExp : Int := ((exp >>> 20 : Nat) : Int) - 1023
    let halfExp := unbiasedExp + 127
    if halfExp ≥ 0xFF then (halfSign ||| 0x7F80) % 2 ^ 16
    else if halfExp ≤ 0 then
      if 7 - halfExp > 21 then halfSign % 2 ^ 16
      else
        let man := man ||| 0x0010_0000
        let halfMan := man >>> (14 - halfExp).toNat
        let roundBit := 1 <<< (13 - halfExp).toNat
        let halfMan :=
          if man &&& roundBit != 0 && man &&& (3 * roundBit - 1) != 0 then halfMan + 1
          else halfMan
        (halfSign ||| halfMan) % 2 ^ 16
    else
      let halfExp := halfExp.toNat <<< 7
      let halfMan := man >>> 13
      let roundBit := 0x0000_1000
      if man &&& roundBit != 0 && man &&& (3 * roundBit - 1) != 0 then
        ((halfSign ||| halfExp ||| halfMan) + 1) % 2 ^ 16
      else (halfSign ||| halfExp ||| halfMan) % 2 ^ 16

/-- `bfloat/convert.rs::bf16_to_f32`, from `u16` bits to `u32` bits. -/
def bf16ToF32 (i : Nat) : Nat :=
  if i &&& 0x7FFF > 0x7F80 then (i ||| 0x0040) <<< 16 else i <<< 16

/-- `bfloat/convert.rs::bf16_to_f64`, from `u16` bits to `u64` bits. -/
def bf16ToF64 (i : Nat) : Nat :=
  if i &&& 0x7FFF == 0 then i <<< 48
  else
    let halfSign := i &&& 0x8000
    let halfExp := i &&& 0x7F80
    let halfMan := i &&& 0x007F
    if halfExp == 0x7F80 then
      if halfMan == 0 then (halfSign <<< 48) ||| 0x7FF0_0000_0000_0000
      else (halfSign <<< 48) ||| 0x7FF8_0000_0000_0000 ||| (halfMan <<< 45)
    else
      let sign := halfSign <<< 48
      let unbiasedExp : Int := ((halfExp >>> 7 : Nat) : Int) - 127
      if halfExp == 0 then
        let e := leadingZerosU16 halfMan - 9
        let exp := (1023 - 127 - e) <<< 52
        let man := (halfMan <<< (46 + e)) &&& 0xF_FFFF_FFFF_FFFF
        sign ||| exp ||| man
      else
        let exp := (unbiasedExp + 1023).toNat <<< 52
        let man := (halfMan &&& 0x007F) <<< 45
        sign ||| exp ||| man

/-! The `PartialEq`/`PartialOrd` impls of `f16` and `bf16` are textually the
same bit algorithm; only `is_nan`'s infinity encoding `inf` differs
(`0x7C00` for `f16`, `0x7F80` for `bf16`). -/

/-- `is_nan`: `self.0 & 0x7FFF > inf`. -/
def isNaN (inf a : Nat) : Bool := a &&& 0x7FFF > inf

/-- `PartialEq::eq`. -/
def eq (inf a b : Nat) : Bool :=
  if isNaN inf a || isNaN inf b then false
  else a == b || (a ||| b) &&& 0x7FFF == 0

/-- `PartialOrd::partial_cmp`. -/
def partialCmp (inf a b : Nat) : Option Ordering :=
  if isNaN inf a || isNaN inf b then none
  else
    let neg := a &&& 0x8000 != 0
    let otherNeg := b &&& 0x8000 != 0
    match neg, otherNeg with
    | false, false => some (compare a b)
    | false, true => if (a ||| b) &&& 0x7FFF == 0 then some .eq else some .gt
    | true, false => if (a ||| b) &&& 0x7FFF == 0 then some .eq else some .lt
    | true, true => some (compare b a)

/-- `PartialOrd::lt`. -/
def lt (inf a b : Nat) : Bool :=
  if isNaN inf a || isNaN inf b then false
  else
    let neg := a &&& 0x8000 != 0
    let otherNeg := b &&& 0x8000 != 0
    match neg, otherNeg with
    | false, false => a < b
    | false, true => false
    | true, false => (a ||| b) &&& 0x7FFF != 0
    | true, true => a > b

/-- `PartialOrd::le`. -/
def le (inf a b : Nat) : Bool :=
  if isNaN inf a || isNaN inf b then false
  else
    let neg := a &&& 0x8000 != 0
    let otherNeg := b &&& 0x8000 != 0
    match neg, otherNeg with
    | false, false => a ≤ b
    | false, true => (a ||| b) &&& 0x7FFF == 0
    | true, false => true
    | true, true => a ≥ b

/-- `PartialOrd::gt`. -/
def gt (inf a b : Nat) : Bool :=
  if isNaN inf a || isNaN inf b then false
  else
    let neg := a &&& 0x8000 != 0
    let otherNeg := b &&& 0x8000 != 0
    match neg, otherNeg with
    | false, false => a > b
    | false, true => (a ||| b) &&& 0x7FFF != 0
    | true, false => false
    | true, true => a < b

/-- `PartialOrd::ge`. -/
def ge (inf a b : Nat) : Bool :=
  if isNaN inf a || isNaN inf b then false
  else
    let neg := a &&& 0x8000 != 0
    let otherNeg := b &&& 0x8000 != 0
    match neg, otherNeg with
    | false, false => a ≥ b
    | false, true => true
    | true, false => (a ||| b) &&& 0x7FFF == 0
    | true, true => a ≤ b

end Half

/-! ## `half::binary16::f16` -/

namespace F16

/-- The infinity encoding used by `f16::is_nan`. -/
def infBits : Nat := 0x7C00

@[rust_fun "half::binary16::{half::binary16::f16}::from_f32"]
def from_f32 (x : F32) : Result F16 := .ok (BinaryFloat.ofNat _ (Half.f32ToF16 x.bits.toNat))
/-- `f16::from_f64` on the Chelis build hosts (aarch64, where `fp16` is always
    present): the crate dispatches to `FCVT Hd, Dd` (`binary16/arch/aarch64.rs`),
    the IEEE conversion rounding to nearest, ties to even (default FPCR), which is
    `BinaryFloat.cast`. A NaN keeps its sign, gets the quiet bit and keeps the top
    9 bits of the rest of its payload (Arm `FPConvertNaN`; the crate's software
    fallback agrees on NaNs). This is a platform assumption
    (verification/trusted_base.json "platform_assumptions"): the crate's software
    `f64_to_f16_fallback` (hosts without `fp16`/`f16c`) first truncates the low
    32 bits of the `f64`, and x86 `f16c` converts through `f32`; both round twice
    and differ from this model on some inputs. -/
@[rust_fun "half::binary16::{half::binary16::f16}::from_f64"]
def from_f64 (x : F64) : Result F16 :=
  .ok (if x.isNaN then
        BinaryFloat.ofNat _ ((if x.sign then 0x8000 else 0) + 0x7E00 + (x.fraction >>> 42) % 2 ^ 9)
      else BinaryFloat.cast .binary16 x)

/-- Off NaNs, `from_f64` is the single correctly rounded conversion `cast`. -/
theorem from_f64_of_not_nan (x : F64) (h : x.isNaN = false) :
    from_f64 x = .ok (BinaryFloat.cast .binary16 x) := by
  simp [from_f64, h]

@[rust_fun "half::binary16::{half::binary16::f16}::to_f32"]
def to_f32 (x : F16) : Result F32 := .ok (BinaryFloat.ofNat _ (Half.f16ToF32 x.bits.toNat))
@[rust_fun "half::binary16::{half::binary16::f16}::to_f64"]
def to_f64 (x : F16) : Result F64 := .ok (BinaryFloat.ofNat _ (Half.f16ToF64 x.bits.toNat))
@[rust_fun "half::binary16::{half::binary16::f16}::is_nan"]
def is_nan (x : F16) : Result Bool := .ok (Half.isNaN infBits x.bits.toNat)
/-- `is_finite` (half 2.x): `self.0 & 0x7C00 != 0x7C00` (the exponent is not all ones). -/
@[rust_fun "half::binary16::{half::binary16::f16}::is_finite"]
def is_finite (x : F16) : Result Bool := .ok (x.bits.toNat &&& 0x7C00 != 0x7C00)

@[rust_const "half::binary16::{half::binary16::f16}::ZERO"]
def ZERO : F16 := BinaryFloat.ofNat _ 0x0000
@[rust_const "half::binary16::{half::binary16::f16}::NEG_ZERO"]
def NEG_ZERO : F16 := BinaryFloat.ofNat _ 0x8000
@[rust_const "half::binary16::{half::binary16::f16}::ONE"]
def ONE : F16 := BinaryFloat.ofNat _ 0x3C00
@[rust_const "half::binary16::{half::binary16::f16}::INFINITY"]
def INFINITY : F16 := BinaryFloat.ofNat _ 0x7C00
@[rust_const "half::binary16::{half::binary16::f16}::NAN"]
def NAN : F16 := BinaryFloat.ofNat _ 0x7E00
@[rust_const "half::binary16::{half::binary16::f16}::MAX"]
def MAX : F16 := BinaryFloat.ofNat _ 0x7BFF

end F16

@[rust_fun "half::binary16::{core::convert::From<f64, half::binary16::f16>}::from"]
def half.binary16.FromF64F16.from_ (x : F16) : Result F64 := F16.to_f64 x
@[reducible, rust_trait_impl "core::convert::From<f64, half::binary16::f16>"]
def half.binary16.FromF64F16 : core.convert.From F64 F16 := { from_ := half.binary16.FromF64F16.from_ }

@[rust_fun "half::binary16::{core::cmp::PartialEq<half::binary16::f16, half::binary16::f16>}::eq"]
def half.binary16.PartialEqF16.eq (x y : F16) : Result Bool :=
  .ok (Half.eq F16.infBits x.bits.toNat y.bits.toNat)
@[reducible, rust_trait_impl "core::cmp::PartialEq<half::binary16::f16, half::binary16::f16>"]
def half.binary16.PartialEqF16 : core.cmp.PartialEq F16 F16 := {
  eq := half.binary16.PartialEqF16.eq
}
@[rust_fun "half::binary16::{core::cmp::PartialOrd<half::binary16::f16, half::binary16::f16>}::partial_cmp"]
def half.binary16.PartialOrdF16.partial_cmp (x y : F16) : Result (Option Ordering) :=
  .ok (Half.partialCmp F16.infBits x.bits.toNat y.bits.toNat)
@[rust_fun "half::binary16::{core::cmp::PartialOrd<half::binary16::f16, half::binary16::f16>}::lt"]
def half.binary16.PartialOrdF16.lt (x y : F16) : Result Bool :=
  .ok (Half.lt F16.infBits x.bits.toNat y.bits.toNat)
@[rust_fun "half::binary16::{core::cmp::PartialOrd<half::binary16::f16, half::binary16::f16>}::le"]
def half.binary16.PartialOrdF16.le (x y : F16) : Result Bool :=
  .ok (Half.le F16.infBits x.bits.toNat y.bits.toNat)
@[rust_fun "half::binary16::{core::cmp::PartialOrd<half::binary16::f16, half::binary16::f16>}::gt"]
def half.binary16.PartialOrdF16.gt (x y : F16) : Result Bool :=
  .ok (Half.gt F16.infBits x.bits.toNat y.bits.toNat)
@[rust_fun "half::binary16::{core::cmp::PartialOrd<half::binary16::f16, half::binary16::f16>}::ge"]
def half.binary16.PartialOrdF16.ge (x y : F16) : Result Bool :=
  .ok (Half.ge F16.infBits x.bits.toNat y.bits.toNat)
@[reducible, rust_trait_impl "core::cmp::PartialOrd<half::binary16::f16, half::binary16::f16>"]
def half.binary16.PartialOrdF16 : core.cmp.PartialOrd F16 F16 := {
  partialEqInst := half.binary16.PartialEqF16
  partial_cmp := half.binary16.PartialOrdF16.partial_cmp
  lt := half.binary16.PartialOrdF16.lt
  le := half.binary16.PartialOrdF16.le
  gt := half.binary16.PartialOrdF16.gt
  ge := half.binary16.PartialOrdF16.ge
}

/-! ## `half::bfloat::bf16` -/

namespace BF16

/-- The infinity encoding used by `bf16::is_nan`. -/
def infBits : Nat := 0x7F80

@[rust_fun "half::bfloat::{half::bfloat::bf16}::from_f32"]
def from_f32 (x : F32) : Result BF16 := .ok (BinaryFloat.ofNat _ (Half.f32ToBf16 x.bits.toNat))
@[rust_fun "half::bfloat::{half::bfloat::bf16}::from_f64"]
def from_f64 (x : F64) : Result BF16 := .ok (BinaryFloat.ofNat _ (Half.f64ToBf16 x.bits.toNat))
@[rust_fun "half::bfloat::{half::bfloat::bf16}::to_f32"]
def to_f32 (x : BF16) : Result F32 := .ok (BinaryFloat.ofNat _ (Half.bf16ToF32 x.bits.toNat))
@[rust_fun "half::bfloat::{half::bfloat::bf16}::to_f64"]
def to_f64 (x : BF16) : Result F64 := .ok (BinaryFloat.ofNat _ (Half.bf16ToF64 x.bits.toNat))
@[rust_fun "half::bfloat::{half::bfloat::bf16}::is_nan"]
def is_nan (x : BF16) : Result Bool := .ok (Half.isNaN infBits x.bits.toNat)
/-- `is_finite` (half 2.x): `self.0 & 0x7F80 != 0x7F80` (the exponent is not all ones). -/
@[rust_fun "half::bfloat::{half::bfloat::bf16}::is_finite"]
def is_finite (x : BF16) : Result Bool := .ok (x.bits.toNat &&& 0x7F80 != 0x7F80)

@[rust_const "half::bfloat::{half::bfloat::bf16}::ZERO"]
def ZERO : BF16 := BinaryFloat.ofNat _ 0x0000
@[rust_const "half::bfloat::{half::bfloat::bf16}::NEG_ZERO"]
def NEG_ZERO : BF16 := BinaryFloat.ofNat _ 0x8000
@[rust_const "half::bfloat::{half::bfloat::bf16}::ONE"]
def ONE : BF16 := BinaryFloat.ofNat _ 0x3F80
@[rust_const "half::bfloat::{half::bfloat::bf16}::INFINITY"]
def INFINITY : BF16 := BinaryFloat.ofNat _ 0x7F80
@[rust_const "half::bfloat::{half::bfloat::bf16}::NAN"]
def NAN : BF16 := BinaryFloat.ofNat _ 0x7FC0
@[rust_const "half::bfloat::{half::bfloat::bf16}::MAX"]
def MAX : BF16 := BinaryFloat.ofNat _ 0x7F7F

end BF16

@[rust_fun "half::bfloat::{core::convert::From<f64, half::bfloat::bf16>}::from"]
def half.bfloat.FromF64BF16.from_ (x : BF16) : Result F64 := BF16.to_f64 x
@[reducible, rust_trait_impl "core::convert::From<f64, half::bfloat::bf16>"]
def half.bfloat.FromF64BF16 : core.convert.From F64 BF16 := { from_ := half.bfloat.FromF64BF16.from_ }

@[rust_fun "half::bfloat::{core::cmp::PartialEq<half::bfloat::bf16, half::bfloat::bf16>}::eq"]
def half.bfloat.PartialEqBF16.eq (x y : BF16) : Result Bool :=
  .ok (Half.eq BF16.infBits x.bits.toNat y.bits.toNat)
@[reducible, rust_trait_impl "core::cmp::PartialEq<half::bfloat::bf16, half::bfloat::bf16>"]
def half.bfloat.PartialEqBF16 : core.cmp.PartialEq BF16 BF16 := {
  eq := half.bfloat.PartialEqBF16.eq
}
@[rust_fun "half::bfloat::{core::cmp::PartialOrd<half::bfloat::bf16, half::bfloat::bf16>}::partial_cmp"]
def half.bfloat.PartialOrdBF16.partial_cmp (x y : BF16) : Result (Option Ordering) :=
  .ok (Half.partialCmp BF16.infBits x.bits.toNat y.bits.toNat)
@[rust_fun "half::bfloat::{core::cmp::PartialOrd<half::bfloat::bf16, half::bfloat::bf16>}::lt"]
def half.bfloat.PartialOrdBF16.lt (x y : BF16) : Result Bool :=
  .ok (Half.lt BF16.infBits x.bits.toNat y.bits.toNat)
@[rust_fun "half::bfloat::{core::cmp::PartialOrd<half::bfloat::bf16, half::bfloat::bf16>}::le"]
def half.bfloat.PartialOrdBF16.le (x y : BF16) : Result Bool :=
  .ok (Half.le BF16.infBits x.bits.toNat y.bits.toNat)
@[rust_fun "half::bfloat::{core::cmp::PartialOrd<half::bfloat::bf16, half::bfloat::bf16>}::gt"]
def half.bfloat.PartialOrdBF16.gt (x y : BF16) : Result Bool :=
  .ok (Half.gt BF16.infBits x.bits.toNat y.bits.toNat)
@[rust_fun "half::bfloat::{core::cmp::PartialOrd<half::bfloat::bf16, half::bfloat::bf16>}::ge"]
def half.bfloat.PartialOrdBF16.ge (x y : BF16) : Result Bool :=
  .ok (Half.ge BF16.infBits x.bits.toNat y.bits.toNat)
@[reducible, rust_trait_impl "core::cmp::PartialOrd<half::bfloat::bf16, half::bfloat::bf16>"]
def half.bfloat.PartialOrdBF16 : core.cmp.PartialOrd BF16 BF16 := {
  partialEqInst := half.bfloat.PartialEqBF16
  partial_cmp := half.bfloat.PartialOrdBF16.partial_cmp
  lt := half.bfloat.PartialOrdBF16.lt
  le := half.bfloat.PartialOrdBF16.le
  gt := half.bfloat.PartialOrdBF16.gt
  ge := half.bfloat.PartialOrdBF16.ge
}

/-! ## Agreement of the comparison impls with IEEE comparison (`BinaryFloat`) -/

namespace Half

theorem and_7fff (a : Nat) : a &&& 0x7FFF = a % 32768 :=
  Nat.and_two_pow_sub_one_eq_mod a 15

theorem or_eq_zero (x y : Nat) : x ||| y = 0 ↔ x = 0 ∧ y = 0 := by
  constructor
  · intro h
    constructor <;> apply Nat.eq_of_testBit_eq <;> intro i
    · have := congrArg (fun n => n.testBit i) h
      simp only [Nat.testBit_or, Nat.zero_testBit, Bool.or_eq_false_iff] at this
      simp [this.1]
    · have := congrArg (fun n => n.testBit i) h
      simp only [Nat.testBit_or, Nat.zero_testBit, Bool.or_eq_false_iff] at this
      simp [this.2]
  · rintro ⟨rfl, rfl⟩; rfl

theorem or_and_7fff (a b : Nat) :
    ((a ||| b) &&& 0x7FFF == 0) = (a % 32768 == 0 && b % 32768 == 0) := by
  rw [Nat.and_or_distrib_right, and_7fff, and_7fff]
  apply Bool.eq_iff_iff.mpr
  simp only [beq_iff_eq, Bool.and_eq_true, or_eq_zero]

theorem and_8000 (a : Nat) : (a &&& 0x8000 != 0) = (a / 32768 % 2 == 1) := by
  have key : a &&& 0x8000 = if a / 32768 % 2 = 1 then 32768 else 0 := by
    apply Nat.eq_of_testBit_eq; intro i
    rw [Nat.testBit_and, show (0x8000 : Nat) = 2 ^ 15 from rfl, Nat.testBit_two_pow]
    by_cases hi : i = 15
    · subst hi
      split <;> simp_all [Nat.testBit_eq_decide_div_mod_eq]
    · have : decide (15 = i) = false := by simp; omega
      rw [this, Bool.and_false]
      split
      · rw [Nat.testBit_two_pow]; simp; omega
      · simp
  rw [key]; split <;> simp_all

theorem sign_bit {a : Nat} (h : a < 65536) : (a / 32768 % 2 == 1) = decide (a ≥ 32768) := by
  apply Bool.eq_iff_iff.mpr; simp only [beq_iff_eq, decide_eq_true_eq]; omega

theorem compare_nat (a b : Nat) :
    compare a b = if a < b then .lt else if a = b then .eq else .gt := by
  simp only [compare, compareOfLessAndEq]

/-- Common closing step: the arithmetic facts are all in terms of `a`, `b`. -/
theorem cmp_facts {a : Nat} (h : a < 65536) :
    (a &&& 0x8000 != 0) = decide (a ≥ 32768) := by rw [and_8000, sign_bit h]

end Half

section
variable {f : BinaryFormat}

theorem BinaryFloat.bits_beq (x y : BinaryFloat f) :
    (x.bits == y.bits) = (x.bits.toNat == y.bits.toNat) := by
  apply Bool.eq_iff_iff.mpr; simp [BitVec.toNat_eq]
end

/-- Facts shared by both 16-bit formats. -/
theorem F16.magnitude_eq (x : F16) : x.magnitude = x.bits.toNat % 32768 := rfl
theorem F16.sign_eq (x : F16) : x.sign = decide (x.bits.toNat ≥ 32768) := rfl
theorem F16.isZero_eq (x : F16) : x.isZero = (x.bits.toNat % 32768 == 0) := rfl
theorem BF16.magnitude_eq (x : BF16) : x.magnitude = x.bits.toNat % 32768 := rfl
theorem BF16.sign_eq (x : BF16) : x.sign = decide (x.bits.toNat ≥ 32768) := rfl
theorem BF16.isZero_eq (x : BF16) : x.isZero = (x.bits.toNat % 32768 == 0) := rfl

theorem F16.isNaN_eq (x : F16) :
    Half.isNaN 0x7C00 x.bits.toNat = BinaryFloat.isNaN x := by
  have := x.bits.isLt
  simp only [Half.isNaN, Half.and_7fff, BinaryFloat.isNaN, BinaryFloat.exponent,
    BinaryFloat.fraction, F16.magnitude_eq]
  generalize x.bits.toNat = a at *
  apply Bool.eq_iff_iff.mpr
  simp only [BinaryFormat.maxExponent, BinaryFormat.exponentBits, BinaryFormat.fractionBits,
    Nat.reducePow, Nat.reduceSub, decide_eq_true_eq, Bool.and_eq_true, beq_iff_eq, bne_iff_ne,
    ne_eq]
  omega

theorem BF16.isNaN_eq (x : BF16) :
    Half.isNaN 0x7F80 x.bits.toNat = BinaryFloat.isNaN x := by
  have := x.bits.isLt
  simp only [Half.isNaN, Half.and_7fff, BinaryFloat.isNaN, BinaryFloat.exponent,
    BinaryFloat.fraction, BF16.magnitude_eq]
  generalize x.bits.toNat = a at *
  apply Bool.eq_iff_iff.mpr
  simp only [BinaryFormat.maxExponent, BinaryFormat.exponentBits, BinaryFormat.fractionBits,
    Nat.reducePow, Nat.reduceSub, decide_eq_true_eq, Bool.and_eq_true, beq_iff_eq, bne_iff_ne,
    ne_eq]
  omega

theorem Half.or_and_7fff_ne (a b : Nat) :
    ((a ||| b) &&& 0x7FFF != 0) = !(a % 32768 == 0 && b % 32768 == 0) := by
  simp only [bne, Half.or_and_7fff]

set_option hygiene false in
/-- Reduce a comparison goal about two 16-bit encodings to arithmetic on their bits. -/
macro "half_cmp" nanX:ident nanY:ident magX:ident magY:ident signX:ident signY:ident
    zeroX:ident zeroY:ident : tactic => `(tactic| (
  have hx : x.bits.toNat < 65536 := x.bits.isLt
  have hy : y.bits.toNat < 65536 := y.bits.isLt
  simp only [Half.eq, Half.lt, Half.le, Half.gt, Half.ge, Half.partialCmp, $nanX:ident, $nanY:ident,
    Half.cmp_facts hx, Half.cmp_facts hy, Half.or_and_7fff, Half.or_and_7fff_ne, BinaryFloat.eq,
    BinaryFloat.lt, BinaryFloat.le, BinaryFloat.partialCmp, $magX:ident, $magY:ident,
    $signX:ident, $signY:ident, $zeroX:ident, $zeroY:ident, BinaryFloat.bits_beq,
    Half.compare_nat]
  cases x.isNaN <;> cases y.isNaN <;>
  by_cases ha : x.bits.toNat ≥ 32768 <;> by_cases hb : y.bits.toNat ≥ 32768 <;>
  simp [ha, hb] <;>
  first
  | (apply Bool.eq_iff_iff.mpr; simp <;> omega)
  | ((repeat' split) <;> simp_all <;> omega)))

theorem F16.eq_eq (x y : F16) :
    Half.eq 0x7C00 x.bits.toNat y.bits.toNat = BinaryFloat.eq x y := by
  half_cmp F16.isNaN_eq F16.isNaN_eq F16.magnitude_eq F16.magnitude_eq F16.sign_eq F16.sign_eq
    F16.isZero_eq F16.isZero_eq

theorem F16.lt_eq (x y : F16) :
    Half.lt 0x7C00 x.bits.toNat y.bits.toNat = BinaryFloat.lt x y := by
  half_cmp F16.isNaN_eq F16.isNaN_eq F16.magnitude_eq F16.magnitude_eq F16.sign_eq F16.sign_eq
    F16.isZero_eq F16.isZero_eq

theorem F16.le_eq (x y : F16) :
    Half.le 0x7C00 x.bits.toNat y.bits.toNat = BinaryFloat.le x y := by
  half_cmp F16.isNaN_eq F16.isNaN_eq F16.magnitude_eq F16.magnitude_eq F16.sign_eq F16.sign_eq
    F16.isZero_eq F16.isZero_eq

theorem F16.gt_eq (x y : F16) :
    Half.gt 0x7C00 x.bits.toNat y.bits.toNat = BinaryFloat.lt y x := by
  half_cmp F16.isNaN_eq F16.isNaN_eq F16.magnitude_eq F16.magnitude_eq F16.sign_eq F16.sign_eq
    F16.isZero_eq F16.isZero_eq

theorem F16.ge_eq (x y : F16) :
    Half.ge 0x7C00 x.bits.toNat y.bits.toNat = BinaryFloat.le y x := by
  half_cmp F16.isNaN_eq F16.isNaN_eq F16.magnitude_eq F16.magnitude_eq F16.sign_eq F16.sign_eq
    F16.isZero_eq F16.isZero_eq

theorem F16.partialCmp_eq (x y : F16) :
    Half.partialCmp 0x7C00 x.bits.toNat y.bits.toNat = BinaryFloat.partialCmp x y := by
  half_cmp F16.isNaN_eq F16.isNaN_eq F16.magnitude_eq F16.magnitude_eq F16.sign_eq F16.sign_eq
    F16.isZero_eq F16.isZero_eq

theorem BF16.eq_eq (x y : BF16) :
    Half.eq 0x7F80 x.bits.toNat y.bits.toNat = BinaryFloat.eq x y := by
  half_cmp BF16.isNaN_eq BF16.isNaN_eq BF16.magnitude_eq BF16.magnitude_eq BF16.sign_eq BF16.sign_eq
    BF16.isZero_eq BF16.isZero_eq

theorem BF16.lt_eq (x y : BF16) :
    Half.lt 0x7F80 x.bits.toNat y.bits.toNat = BinaryFloat.lt x y := by
  half_cmp BF16.isNaN_eq BF16.isNaN_eq BF16.magnitude_eq BF16.magnitude_eq BF16.sign_eq BF16.sign_eq
    BF16.isZero_eq BF16.isZero_eq

theorem BF16.le_eq (x y : BF16) :
    Half.le 0x7F80 x.bits.toNat y.bits.toNat = BinaryFloat.le x y := by
  half_cmp BF16.isNaN_eq BF16.isNaN_eq BF16.magnitude_eq BF16.magnitude_eq BF16.sign_eq BF16.sign_eq
    BF16.isZero_eq BF16.isZero_eq

theorem BF16.gt_eq (x y : BF16) :
    Half.gt 0x7F80 x.bits.toNat y.bits.toNat = BinaryFloat.lt y x := by
  half_cmp BF16.isNaN_eq BF16.isNaN_eq BF16.magnitude_eq BF16.magnitude_eq BF16.sign_eq BF16.sign_eq
    BF16.isZero_eq BF16.isZero_eq

theorem BF16.ge_eq (x y : BF16) :
    Half.ge 0x7F80 x.bits.toNat y.bits.toNat = BinaryFloat.le y x := by
  half_cmp BF16.isNaN_eq BF16.isNaN_eq BF16.magnitude_eq BF16.magnitude_eq BF16.sign_eq BF16.sign_eq
    BF16.isZero_eq BF16.isZero_eq

theorem BF16.partialCmp_eq (x y : BF16) :
    Half.partialCmp 0x7F80 x.bits.toNat y.bits.toNat = BinaryFloat.partialCmp x y := by
  half_cmp BF16.isNaN_eq BF16.isNaN_eq BF16.magnitude_eq BF16.magnitude_eq BF16.sign_eq BF16.sign_eq
    BF16.isZero_eq BF16.isZero_eq


/-! The registered `rust_fun` comparison models, restated over `BinaryFloat`. -/

theorem half.binary16.PartialEqF16.eq_spec (x y : F16) :
    half.binary16.PartialEqF16.eq x y = .ok (BinaryFloat.eq x y) := by
  simp only [half.binary16.PartialEqF16.eq, F16.infBits, F16.eq_eq]
theorem half.binary16.PartialOrdF16.partial_cmp_spec (x y : F16) :
    half.binary16.PartialOrdF16.partial_cmp x y = .ok (BinaryFloat.partialCmp x y) := by
  simp only [half.binary16.PartialOrdF16.partial_cmp, F16.infBits, F16.partialCmp_eq]
theorem half.binary16.PartialOrdF16.lt_spec (x y : F16) :
    half.binary16.PartialOrdF16.lt x y = .ok (BinaryFloat.lt x y) := by
  simp only [half.binary16.PartialOrdF16.lt, F16.infBits, F16.lt_eq]
theorem half.binary16.PartialOrdF16.le_spec (x y : F16) :
    half.binary16.PartialOrdF16.le x y = .ok (BinaryFloat.le x y) := by
  simp only [half.binary16.PartialOrdF16.le, F16.infBits, F16.le_eq]
theorem half.binary16.PartialOrdF16.gt_spec (x y : F16) :
    half.binary16.PartialOrdF16.gt x y = .ok (BinaryFloat.lt y x) := by
  simp only [half.binary16.PartialOrdF16.gt, F16.infBits, F16.gt_eq]
theorem half.binary16.PartialOrdF16.ge_spec (x y : F16) :
    half.binary16.PartialOrdF16.ge x y = .ok (BinaryFloat.le y x) := by
  simp only [half.binary16.PartialOrdF16.ge, F16.infBits, F16.ge_eq]
theorem F16.is_nan_spec (x : F16) : F16.is_nan x = .ok (BinaryFloat.isNaN x) := by
  simp only [F16.is_nan, F16.infBits, F16.isNaN_eq]

/-! The registered `rust_fun` comparison models, restated over `BinaryFloat`. -/

theorem half.bfloat.PartialEqBF16.eq_spec (x y : BF16) :
    half.bfloat.PartialEqBF16.eq x y = .ok (BinaryFloat.eq x y) := by
  simp only [half.bfloat.PartialEqBF16.eq, BF16.infBits, BF16.eq_eq]
theorem half.bfloat.PartialOrdBF16.partial_cmp_spec (x y : BF16) :
    half.bfloat.PartialOrdBF16.partial_cmp x y = .ok (BinaryFloat.partialCmp x y) := by
  simp only [half.bfloat.PartialOrdBF16.partial_cmp, BF16.infBits, BF16.partialCmp_eq]
theorem half.bfloat.PartialOrdBF16.lt_spec (x y : BF16) :
    half.bfloat.PartialOrdBF16.lt x y = .ok (BinaryFloat.lt x y) := by
  simp only [half.bfloat.PartialOrdBF16.lt, BF16.infBits, BF16.lt_eq]
theorem half.bfloat.PartialOrdBF16.le_spec (x y : BF16) :
    half.bfloat.PartialOrdBF16.le x y = .ok (BinaryFloat.le x y) := by
  simp only [half.bfloat.PartialOrdBF16.le, BF16.infBits, BF16.le_eq]
theorem half.bfloat.PartialOrdBF16.gt_spec (x y : BF16) :
    half.bfloat.PartialOrdBF16.gt x y = .ok (BinaryFloat.lt y x) := by
  simp only [half.bfloat.PartialOrdBF16.gt, BF16.infBits, BF16.gt_eq]
theorem half.bfloat.PartialOrdBF16.ge_spec (x y : BF16) :
    half.bfloat.PartialOrdBF16.ge x y = .ok (BinaryFloat.le y x) := by
  simp only [half.bfloat.PartialOrdBF16.ge, BF16.infBits, BF16.ge_eq]
theorem BF16.is_nan_spec (x : BF16) : BF16.is_nan x = .ok (BinaryFloat.isNaN x) := by
  simp only [BF16.is_nan, BF16.infBits, BF16.isNaN_eq]

end Aeneas.Std
