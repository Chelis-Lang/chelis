import Aeneas.Std.Core.Iter
import Aeneas.Std.Scalar.SaturatingOps
import Aeneas.Std.Scalar.WrappingOps

namespace Aeneas.Std

open Result

-- Keep the exhausted left receiver: dropping Rust's Option must not drop the
-- authoritative state needed to restore a borrowed iterator. Only a is fused.
structure core.iter.adapters.chain.Chain (A B : Type) where
  a : A
  b : B
  aActive : Bool

def core.iter.adapters.chain.Chain.recombine {A B : Type}
    (mergeA : A → A → A) (mergeB : B → B → B)
    (original current : core.iter.adapters.chain.Chain A B) :
    core.iter.adapters.chain.Chain A B :=
  { original with a := mergeA original.a current.a, b := mergeB original.b current.b }

attribute [rust_type "core::iter::adapters::chain::Chain" (body := .opaque)
  (stateMerge := some ("Aeneas.Std.core.iter.adapters.chain.Chain.recombine", [0, 1]))]
  core.iter.adapters.chain.Chain

structure core.iter.adapters.zip.Zip (A B : Type) where
  a : A
  b : B
  index : Usize := 0#usize
  len : Usize := 0#usize

def core.iter.adapters.zip.Zip.recombine {A B : Type}
    (mergeA : A → A → A) (mergeB : B → B → B)
    (original current : core.iter.adapters.zip.Zip A B) :
    core.iter.adapters.zip.Zip A B :=
  { original with a := mergeA original.a current.a, b := mergeB original.b current.b }

attribute [rust_type "core::iter::adapters::zip::Zip" (body := .opaque)
  (stateMerge := some ("Aeneas.Std.core.iter.adapters.zip.Zip.recombine", [0, 1]))]
  core.iter.adapters.zip.Zip

structure core.iter.adapters.skip.Skip (I : Type) where
  iter : I
  n : Usize

def core.iter.adapters.skip.Skip.recombine {I : Type}
    (mergeI : I → I → I) (original current : core.iter.adapters.skip.Skip I) :
    core.iter.adapters.skip.Skip I :=
  { original with iter := mergeI original.iter current.iter }

attribute [rust_type "core::iter::adapters::skip::Skip" (body := .opaque)
  (stateMerge := some ("Aeneas.Std.core.iter.adapters.skip.Skip.recombine", [0]))]
  core.iter.adapters.skip.Skip

-- Lifted Rust parameters: Self, U, Self::Item, U::IntoIter. The second
-- restoration function must compose with IntoIterator's actual giveback lens.
@[rust_fun "core::iter::traits::iterator::Iterator::chain"]
def core.iter.traits.iterator.Iterator.chain.default
  {Self U Item IntoIter : Type}
  (_iterInst : core.iter.traits.iterator.Iterator Self Item)
  (intoInst : core.iter.traits.collect.IntoIterator U Item IntoIter)
  (self : Self) (other : U) :
  Result (core.iter.adapters.chain.Chain Self IntoIter ×
    (core.iter.adapters.chain.Chain Self IntoIter → Self) ×
    (core.iter.adapters.chain.Chain Self IntoIter → U)) := do
  let (b, restore) ← intoInst.into_iter other
  ok (⟨self, b, true⟩, (·.a), fun state => restore state.b)

@[rust_fun "core::iter::traits::iterator::Iterator::zip"]
def core.iter.traits.iterator.Iterator.zip.default
  {Self U Item UItem IntoIter : Type}
  (iterInst : core.iter.traits.iterator.Iterator Self Item)
  (intoInst : core.iter.traits.collect.IntoIterator U UItem IntoIter)
  (self : Self) (other : U) :
  Result (core.iter.adapters.zip.Zip Self IntoIter ×
    (core.iter.adapters.zip.Zip Self IntoIter → Self) ×
    (core.iter.adapters.zip.Zip Self IntoIter → U)) := do
  let (b, restore) ← intoInst.into_iter other
  let len ←
    if iterInst.trusted_random_access && intoInst.iteratorInst.trusted_random_access then do
      let (aLen, _) ← iterInst.size_hint self
      let (bLen, _) ← intoInst.iteratorInst.size_hint b
      ok (if aLen.val ≤ bLen.val then aLen else bLen)
    else ok 0#usize
  ok ({ a := self, b, index := 0#usize, len }, (·.a), fun state => restore state.b)

@[rust_fun "core::iter::traits::iterator::Iterator::skip"]
def core.iter.traits.iterator.Iterator.skip.default
  {Self Item : Type}
  (_iterInst : core.iter.traits.iterator.Iterator Self Item)
  (self : Self) (n : Usize) :
  Result (core.iter.adapters.skip.Skip Self ×
    (core.iter.adapters.skip.Skip Self → Self)) :=
  ok (⟨self, n⟩, (·.iter))

@[rust_fun
  "core::iter::adapters::chain::{core::iter::traits::iterator::Iterator<core::iter::adapters::chain::Chain<@A, @B>, @Clause0_Item>}::next"]
def core.iter.adapters.chain.IteratorChain.next
  {A B Item : Type}
  (aInst : core.iter.traits.iterator.Iterator A Item)
  (bInst : core.iter.traits.iterator.Iterator B Item)
  (self : core.iter.adapters.chain.Chain A B) :
  Result (Option Item × core.iter.adapters.chain.Chain A B) := do
  if self.aActive then
    let (item, a) ← aInst.next self.a
    match item with
    | some item => ok (some item, { self with a })
    | none =>
      let (item, b) ← bInst.next self.b
      ok (item, ⟨a, b, false⟩)
  else
    let (item, b) ← bInst.next self.b
    ok (item, { self with b })

@[rust_fun
  "core::iter::adapters::chain::{core::iter::traits::iterator::Iterator<core::iter::adapters::chain::Chain<@A, @B>, @Clause0_Item>}::nth"]
def core.iter.adapters.chain.IteratorChain.nth
  {A B Item : Type}
  (aInst : core.iter.traits.iterator.Iterator A Item)
  (bInst : core.iter.traits.iterator.Iterator B Item)
  (self : core.iter.adapters.chain.Chain A B) (n : Usize) :
  Result (Option Item × core.iter.adapters.chain.Chain A B) := do
  if self.aActive then
    let (advanced, a) ← aInst.advance_by self.a n
    match advanced with
    | .Ok () =>
      let (item, a) ← aInst.next a
      match item with
      | some item => ok (some item, { self with a })
      | none =>
        let (item, b) ← bInst.nth self.b 0#usize
        ok (item, ⟨a, b, false⟩)
    | .Err remaining =>
      let (item, b) ← bInst.nth self.b remaining.val
      ok (item, ⟨a, b, false⟩)
  else
    let (item, b) ← bInst.nth self.b n
    ok (item, { self with b })

@[rust_fun
  "core::iter::adapters::chain::{core::iter::traits::iterator::Iterator<core::iter::adapters::chain::Chain<@A, @B>, @Clause0_Item>}::advance_by"]
def core.iter.adapters.chain.IteratorChain.advance_by
  {A B Item : Type}
  (aInst : core.iter.traits.iterator.Iterator A Item)
  (bInst : core.iter.traits.iterator.Iterator B Item)
  (self : core.iter.adapters.chain.Chain A B) (n : Usize) :
  Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) ×
    core.iter.adapters.chain.Chain A B) := do
  if self.aActive then
    let (advanced, a) ← aInst.advance_by self.a n
    match advanced with
    | .Ok () => ok (.Ok (), { self with a })
    | .Err remaining =>
      let (advanced, b) ← bInst.advance_by self.b remaining.val
      ok (advanced, ⟨a, b, false⟩)
  else
    let (advanced, b) ← bInst.advance_by self.b n
    ok (advanced, { self with b })

@[rust_fun
  "core::iter::adapters::chain::{core::iter::traits::iterator::Iterator<core::iter::adapters::chain::Chain<@A, @B>, @Clause0_Item>}::fold"]
def core.iter.adapters.chain.IteratorChain.fold
  {A B Acc F Item : Type}
  (aInst : core.iter.traits.iterator.Iterator A Item)
  (bInst : core.iter.traits.iterator.Iterator B Item)
  (fnInst : core.ops.function.FnMut F (Acc × Item) Acc)
  (self : core.iter.adapters.chain.Chain A B) (init : Acc) (f : F) :
  Result (Acc × core.iter.adapters.chain.Chain A B × F) := do
  let (acc, a, f) ← if self.aActive then aInst.fold fnInst self.a init f
                   else ok (init, self.a, f)
  let (acc, b, f) ← bInst.fold fnInst self.b acc f
  ok (acc, { self with a, b }, f)

@[rust_fun
  "core::iter::adapters::chain::{core::iter::traits::iterator::Iterator<core::iter::adapters::chain::Chain<@A, @B>, @Clause0_Item>}::try_fold"]
def core.iter.adapters.chain.IteratorChain.try_fold
  {A B Acc F R Item Residual : Type}
  (aInst : core.iter.traits.iterator.Iterator A Item)
  (bInst : core.iter.traits.iterator.Iterator B Item)
  (fnInst : core.ops.function.FnMut F (Acc × Item) R)
  (tryInst : core.ops.try_trait.Try R Acc Residual)
  (self : core.iter.adapters.chain.Chain A B) (init : Acc) (f : F) :
  Result (R × core.iter.adapters.chain.Chain A B × F) := do
  let (init, self, f) ←
    if self.aActive then do
      let (result, a, f) ← aInst.try_fold fnInst tryInst self.a init f
      match ← tryInst.branch result with
      | .Break residual =>
        let result ← tryInst.FromResidualInst.from_residual residual
        ok (Sum.inl result, { self with a }, f)
      | .Continue acc => ok (Sum.inr acc, { self with a, aActive := false }, f)
    else ok (Sum.inr init, self, f)
  match init with
  | .inl result => ok (result, self, f)
  | .inr acc =>
    let (result, b, f) ← bInst.try_fold fnInst tryInst self.b acc f
    let result ← match ← tryInst.branch result with
      | .Break residual => tryInst.FromResidualInst.from_residual residual
      | .Continue acc => tryInst.from_output acc
    ok (result, { self with b }, f)

@[rust_fun
  "core::iter::adapters::chain::{core::iter::traits::iterator::Iterator<core::iter::adapters::chain::Chain<@A, @B>, @Clause0_Item>}::size_hint"]
def core.iter.adapters.chain.IteratorChain.size_hint
  {A B Item : Type}
  (aInst : core.iter.traits.iterator.Iterator A Item)
  (bInst : core.iter.traits.iterator.Iterator B Item)
  (self : core.iter.adapters.chain.Chain A B) : Result (Usize × Option Usize) := do
  if self.aActive then
    let (a, aUpper) ← aInst.size_hint self.a
    let (b, bUpper) ← bInst.size_hint self.b
    let upper := match aUpper, bUpper with
      | some a, some b => Usize.checked_add a b
      | _, _ => none
    ok (UScalar.saturating_add a b, upper)
  else bInst.size_hint self.b

-- Chain overrides count and selects BOTH underlying count implementations.
@[rust_fun
  "core::iter::adapters::chain::{core::iter::traits::iterator::Iterator<core::iter::adapters::chain::Chain<@A, @B>, @Clause0_Item>}::count"]
def core.iter.adapters.chain.IteratorChain.count
  {A B Item : Type}
  (aInst : core.iter.traits.iterator.Iterator A Item)
  (bInst : core.iter.traits.iterator.Iterator B Item)
  (self : core.iter.adapters.chain.Chain A B) :
  Result (Usize × core.iter.adapters.chain.Chain A B) := do
  let (aCount, a) ← if self.aActive then aInst.count self.a else ok (0#usize, self.a)
  let (bCount, b) ← bInst.count self.b
  let count ← aCount + bCount
  ok (count, { self with a, b })

@[rust_fun
  "core::iter::adapters::chain::{core::iter::traits::iterator::Iterator<core::iter::adapters::chain::Chain<@A, @B>, @Clause0_Item>}::any"]
def core.iter.adapters.chain.IteratorChain.any
  {A B F Item : Type}
  (aInst : core.iter.traits.iterator.Iterator A Item)
  (bInst : core.iter.traits.iterator.Iterator B Item)
  (fnInst : core.ops.function.FnMut F Item Bool)
  (self : core.iter.adapters.chain.Chain A B) (f : F) :
  Result (Bool × core.iter.adapters.chain.Chain A B × F) :=
  core.iter.traits.iterator.anyFromTryFold
    (core.iter.adapters.chain.IteratorChain.try_fold aInst bInst) fnInst self f

@[rust_fun
  "core::iter::adapters::chain::{core::iter::traits::iterator::Iterator<core::iter::adapters::chain::Chain<@A, @B>, @Clause0_Item>}::find"]
def core.iter.adapters.chain.IteratorChain.find
  {A B F Item : Type}
  (aInst : core.iter.traits.iterator.Iterator A Item)
  (bInst : core.iter.traits.iterator.Iterator B Item)
  (fnInst : core.ops.function.FnMut F Item Bool)
  (self : core.iter.adapters.chain.Chain A B) (f : F) :
  Result (Option Item × core.iter.adapters.chain.Chain A B × F) := do
  let (item, self, f) ←
    if self.aActive then do
      let (item, a, f) ← aInst.find fnInst self.a f
      pure (item, { self with a, aActive := item.isSome }, f)
    else pure (none, self, f)
  match item with
  | some item => pure (some item, self, f)
  | none =>
    let (item, b, f) ← bInst.find fnInst self.b f
    pure (item, { self with b }, f)

@[rust_fun
  "core::iter::adapters::chain::{core::iter::traits::iterator::Iterator<core::iter::adapters::chain::Chain<@A, @B>, @Clause0_Item>}::enumerate"]
def core.iter.adapters.chain.IteratorChain.enumerate
  {A B Item : Type}
  (_aInst : core.iter.traits.iterator.Iterator A Item)
  (_bInst : core.iter.traits.iterator.Iterator B Item)
  (self : core.iter.adapters.chain.Chain A B) :
  Result (core.iter.adapters.enumerate.Enumerate (core.iter.adapters.chain.Chain A B)) :=
  core.iter.traits.iterator.Iterator.enumerate.default self

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::iter::adapters::chain::Chain<@A, @B>, @Clause0_Item>"]
def core.iter.traits.iterator.IteratorChain
  {A B Item : Type}
  (aInst : core.iter.traits.iterator.Iterator A Item)
  (bInst : core.iter.traits.iterator.Iterator B Item) :
  core.iter.traits.iterator.Iterator (core.iter.adapters.chain.Chain A B) Item := {
  next := core.iter.adapters.chain.IteratorChain.next aInst bInst
  nth := core.iter.adapters.chain.IteratorChain.nth aInst bInst
  advance_by := core.iter.adapters.chain.IteratorChain.advance_by aInst bInst
  fold := core.iter.adapters.chain.IteratorChain.fold aInst bInst
  try_fold := core.iter.adapters.chain.IteratorChain.try_fold aInst bInst
  size_hint := core.iter.adapters.chain.IteratorChain.size_hint aInst bInst
  trusted_len := aInst.trusted_len && bInst.trusted_len
  fused := aInst.fused && bInst.fused
  count := core.iter.adapters.chain.IteratorChain.count aInst bInst
  any := core.iter.adapters.chain.IteratorChain.any aInst bInst
  find := core.iter.adapters.chain.IteratorChain.find aInst bInst
  enumerate := core.iter.adapters.chain.IteratorChain.enumerate aInst bInst
}

-- Zip's general implementation evaluates the left next first. A right None
-- still consumes the left item, and neither side is implicitly fused.
def core.iter.adapters.zip.IteratorZip.nextGeneral
  {A B AItem BItem : Type}
  (aInst : core.iter.traits.iterator.Iterator A AItem)
  (bInst : core.iter.traits.iterator.Iterator B BItem)
  (self : core.iter.adapters.zip.Zip A B) :
  Result (Option (AItem × BItem) × core.iter.adapters.zip.Zip A B) := do
  let (item, a) ← aInst.next self.a
  match item with
  | none => ok (none, { self with a })
  | some x =>
    let (item, b) ← bInst.next self.b
    ok (item.map (fun y => (x, y)), { self with a, b })

def core.iter.adapters.zip.IteratorZip.get_unchecked
  {A B AItem BItem : Type}
  (aAccess : core.iter.traits.iterator.RandomAccess A AItem)
  (bAccess : core.iter.traits.iterator.RandomAccess B BItem)
  (self : core.iter.adapters.zip.Zip A B) (idx : Usize) :
  Result ((AItem × BItem) × core.iter.adapters.zip.Zip A B) := do
  let idx ← self.index + idx
  let (aItem, a) ← aAccess.get_unchecked self.a idx
  let (bItem, b) ← bAccess.get_unchecked self.b idx
  ok ((aItem, bItem), { self with a, b })

@[rust_fun
  "core::iter::adapters::zip::{core::iter::traits::iterator::Iterator<core::iter::adapters::zip::Zip<@A, @B>, (@Clause0_Item, @Clause1_Item)>}::next"]
def core.iter.adapters.zip.IteratorZip.next
  {A B AItem BItem : Type}
  (aInst : core.iter.traits.iterator.Iterator A AItem)
  (bInst : core.iter.traits.iterator.Iterator B BItem)
  (self : core.iter.adapters.zip.Zip A B) :
  Result (Option (AItem × BItem) × core.iter.adapters.zip.Zip A B) := do
  match aInst.random_access, bInst.random_access with
  | some aAccess, some bAccess =>
    if aAccess.is_full && bAccess.is_full then
      if self.index.val < self.len.val then
        let index ← self.index + 1#usize
        let (aItem, a) ← aAccess.get_unchecked self.a self.index
        let (bItem, b) ← bAccess.get_unchecked self.b self.index
        ok (some (aItem, bItem), { self with a, b, index })
      else ok (none, self)
    else core.iter.adapters.zip.IteratorZip.nextGeneral aInst bInst self
  | _, _ => core.iter.adapters.zip.IteratorZip.nextGeneral aInst bInst self

def core.iter.adapters.zip.IteratorZip.skipRandom
  {A B AItem BItem : Type}
  (aAccess : core.iter.traits.iterator.RandomAccess A AItem)
  (bAccess : core.iter.traits.iterator.RandomAccess B BItem)
  (self : core.iter.adapters.zip.Zip A B) :
  Nat → Result (core.iter.adapters.zip.Zip A B)
  | 0 => ok self
  | n + 1 => do
    let index ← self.index + 1#usize
    let a ←
      if aAccess.may_have_side_effect then do
        let (_, a) ← aAccess.get_unchecked self.a self.index
        ok a
      else ok self.a
    let b ←
      if bAccess.may_have_side_effect then do
        let (_, b) ← bAccess.get_unchecked self.b self.index
        ok b
      else ok self.b
    core.iter.adapters.zip.IteratorZip.skipRandom aAccess bAccess { self with a, b, index } n

@[rust_fun
  "core::iter::adapters::zip::{core::iter::traits::iterator::Iterator<core::iter::adapters::zip::Zip<@A, @B>, (@Clause0_Item, @Clause1_Item)>}::nth"]
def core.iter.adapters.zip.IteratorZip.nth
  {A B AItem BItem : Type}
  (aInst : core.iter.traits.iterator.Iterator A AItem)
  (bInst : core.iter.traits.iterator.Iterator B BItem)
  (self : core.iter.adapters.zip.Zip A B) (n : Usize) :
  Result (Option (AItem × BItem) × core.iter.adapters.zip.Zip A B) := do
  let (self, n) ←
    match aInst.random_access, bInst.random_access with
    | some aAccess, some bAccess =>
      if aAccess.is_full && bAccess.is_full then do
        let remaining ← self.len - self.index
        let delta := if n.val ≤ remaining.val then n else remaining
        let self ← core.iter.adapters.zip.IteratorZip.skipRandom aAccess bAccess self delta.val
        let n ← n - delta
        ok (self, n)
      else ok (self, n)
    | _, _ => ok (self, n)
  core.iter.traits.iterator.nthFromNext
    (core.iter.adapters.zip.IteratorZip.next aInst bInst) self n.val

@[rust_fun
  "core::iter::adapters::zip::{core::iter::traits::iterator::Iterator<core::iter::adapters::zip::Zip<@A, @B>, (@Clause0_Item, @Clause1_Item)>}::size_hint"]
def core.iter.adapters.zip.IteratorZip.size_hint
  {A B AItem BItem : Type}
  (aInst : core.iter.traits.iterator.Iterator A AItem)
  (bInst : core.iter.traits.iterator.Iterator B BItem)
  (self : core.iter.adapters.zip.Zip A B) : Result (Usize × Option Usize) := do
  if aInst.trusted_random_access && bInst.trusted_random_access then
    let remaining ← self.len - self.index
    ok (remaining, some remaining)
  else
    let (a, aUpper) ← aInst.size_hint self.a
    let (b, bUpper) ← bInst.size_hint self.b
    let lower := if a.val ≤ b.val then a else b
    if aInst.random_access.isSome && bInst.random_access.isSome then
      ok (lower, some lower)
    else
      let upper := match aUpper, bUpper with
        | some a, some b => some (if a.val ≤ b.val then a else b)
        | some a, none => some a
        | none, some b => some b
        | none, none => none
      ok (lower, upper)

-- TrustedLen's fold does not perform a terminal next call. The unsafe Rust
-- unwraps require each item promised by the trusted bound actually to exist.
def core.iter.adapters.zip.IteratorZip.foldN
  {A B Acc F AItem BItem : Type}
  (aInst : core.iter.traits.iterator.Iterator A AItem)
  (bInst : core.iter.traits.iterator.Iterator B BItem)
  (fnInst : core.ops.function.FnMut F (Acc × (AItem × BItem)) Acc)
  (self : core.iter.adapters.zip.Zip A B) (init : Acc) (f : F) :
  Nat → Result (Acc × core.iter.adapters.zip.Zip A B × F)
  | 0 => ok (init, self, f)
  | n + 1 => do
    let (aItem, a) ← aInst.next self.a
    let some aItem := aItem | fail .panic
    let (bItem, b) ← bInst.next self.b
    let some bItem := bItem | fail .panic
    let (acc, f) ← fnInst.call_mut f (init, (aItem, bItem))
    core.iter.adapters.zip.IteratorZip.foldN aInst bInst fnInst { self with a, b } acc f n

def core.iter.adapters.zip.IteratorZip.trustedFold
  {A B Acc F AItem BItem : Type}
  (aInst : core.iter.traits.iterator.Iterator A AItem)
  (bInst : core.iter.traits.iterator.Iterator B BItem)
  (fnInst : core.ops.function.FnMut F (Acc × (AItem × BItem)) Acc)
  (self : core.iter.adapters.zip.Zip A B) (init : Acc) (f : F) :
  Result (Acc × core.iter.adapters.zip.Zip A B × F) := do
  let (_, upper) ← core.iter.adapters.zip.IteratorZip.size_hint aInst bInst self
  match upper with
  | some n => core.iter.adapters.zip.IteratorZip.foldN aInst bInst fnInst self init f n.val
  | none =>
    let (acc, self, f) ← core.iter.adapters.zip.IteratorZip.foldN aInst bInst fnInst self init f Usize.max
    core.iter.adapters.zip.IteratorZip.trustedFold aInst bInst fnInst self acc f
partial_fixpoint

def core.iter.adapters.zip.IteratorZip.randomFold
  {A B Acc F AItem BItem : Type}
  (aAccess : core.iter.traits.iterator.RandomAccess A AItem)
  (bAccess : core.iter.traits.iterator.RandomAccess B BItem)
  (fnInst : core.ops.function.FnMut F (Acc × (AItem × BItem)) Acc)
  (self : core.iter.adapters.zip.Zip A B) (init : Acc) (f : F) (index : Usize) :
  Nat → Result (Acc × core.iter.adapters.zip.Zip A B × F)
  | 0 => ok (init, self, f)
  | n + 1 => do
    let (item, self) ← core.iter.adapters.zip.IteratorZip.get_unchecked aAccess bAccess self index
    let (acc, f) ← fnInst.call_mut f (init, item)
    let index ← index + 1#usize
    core.iter.adapters.zip.IteratorZip.randomFold aAccess bAccess fnInst self acc f index n

@[rust_fun
  "core::iter::adapters::zip::{core::iter::traits::iterator::Iterator<core::iter::adapters::zip::Zip<@A, @B>, (@Clause0_Item, @Clause1_Item)>}::fold"]
def core.iter.adapters.zip.IteratorZip.fold
  {A B Acc F AItem BItem : Type}
  (aInst : core.iter.traits.iterator.Iterator A AItem)
  (bInst : core.iter.traits.iterator.Iterator B BItem)
  (fnInst : core.ops.function.FnMut F (Acc × (AItem × BItem)) Acc)
  (self : core.iter.adapters.zip.Zip A B) (init : Acc) (f : F) :
  Result (Acc × core.iter.adapters.zip.Zip A B × F) := do
  match aInst.random_access, bInst.random_access with
  | some aAccess, some bAccess =>
    let (len, _) ← core.iter.adapters.zip.IteratorZip.size_hint aInst bInst self
    core.iter.adapters.zip.IteratorZip.randomFold aAccess bAccess fnInst self init f 0#usize len.val
  | _, _ =>
    if aInst.trusted_len && bInst.trusted_len then
      core.iter.adapters.zip.IteratorZip.trustedFold aInst bInst fnInst self init f
    else
      core.iter.traits.iterator.foldFromNext
        (core.iter.adapters.zip.IteratorZip.next aInst bInst) fnInst self init f

@[rust_fun
  "core::iter::adapters::zip::{core::iter::traits::iterator::Iterator<core::iter::adapters::zip::Zip<@A, @B>, (@Clause0_Item, @Clause1_Item)>}::try_fold"]
def core.iter.adapters.zip.IteratorZip.try_fold
  {A B Acc F R AItem BItem Residual : Type}
  (aInst : core.iter.traits.iterator.Iterator A AItem)
  (bInst : core.iter.traits.iterator.Iterator B BItem)
  (fnInst : core.ops.function.FnMut F (Acc × (AItem × BItem)) R)
  (tryInst : core.ops.try_trait.Try R Acc Residual)
  (self : core.iter.adapters.zip.Zip A B) (init : Acc) (f : F) :
  Result (R × core.iter.adapters.zip.Zip A B × F) :=
  core.iter.traits.iterator.tryFoldFromNext
    (core.iter.adapters.zip.IteratorZip.next aInst bInst) fnInst tryInst self init f

-- Zip inherits count through its own fold, not either input's count override.
@[rust_fun
  "core::iter::adapters::zip::{core::iter::traits::iterator::Iterator<core::iter::adapters::zip::Zip<@A, @B>, (@Clause0_Item, @Clause1_Item)>}::count"]
def core.iter.adapters.zip.IteratorZip.count
  {A B AItem BItem : Type}
  (aInst : core.iter.traits.iterator.Iterator A AItem)
  (bInst : core.iter.traits.iterator.Iterator B BItem)
  (self : core.iter.adapters.zip.Zip A B) :
  Result (Usize × core.iter.adapters.zip.Zip A B) :=
  core.iter.traits.iterator.countFromFold
    (core.iter.adapters.zip.IteratorZip.fold aInst bInst) self

@[rust_fun
  "core::iter::adapters::zip::{core::iter::traits::iterator::Iterator<core::iter::adapters::zip::Zip<@A, @B>, (@Clause0_Item, @Clause1_Item)>}::any"]
def core.iter.adapters.zip.IteratorZip.any
  {A B F AItem BItem : Type}
  (aInst : core.iter.traits.iterator.Iterator A AItem)
  (bInst : core.iter.traits.iterator.Iterator B BItem)
  (fnInst : core.ops.function.FnMut F (AItem × BItem) Bool)
  (self : core.iter.adapters.zip.Zip A B) (f : F) :
  Result (Bool × core.iter.adapters.zip.Zip A B × F) :=
  core.iter.traits.iterator.anyFromTryFold
    (core.iter.adapters.zip.IteratorZip.try_fold aInst bInst) fnInst self f

@[rust_fun
  "core::iter::adapters::zip::{core::iter::traits::iterator::Iterator<core::iter::adapters::zip::Zip<@A, @B>, (@Clause0_Item, @Clause1_Item)>}::enumerate"]
def core.iter.adapters.zip.IteratorZip.enumerate
  {A B AItem BItem : Type}
  (_aInst : core.iter.traits.iterator.Iterator A AItem)
  (_bInst : core.iter.traits.iterator.Iterator B BItem)
  (self : core.iter.adapters.zip.Zip A B) :
  Result (core.iter.adapters.enumerate.Enumerate (core.iter.adapters.zip.Zip A B)) :=
  core.iter.traits.iterator.Iterator.enumerate.default self

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::iter::adapters::zip::Zip<@A, @B>, (@Clause0_Item, @Clause1_Item)>"]
def core.iter.traits.iterator.IteratorZip
  {A B AItem BItem : Type}
  (aInst : core.iter.traits.iterator.Iterator A AItem)
  (bInst : core.iter.traits.iterator.Iterator B BItem) :
  core.iter.traits.iterator.Iterator (core.iter.adapters.zip.Zip A B) (AItem × BItem) := {
  next := core.iter.adapters.zip.IteratorZip.next aInst bInst
  nth := core.iter.adapters.zip.IteratorZip.nth aInst bInst
  fold := core.iter.adapters.zip.IteratorZip.fold aInst bInst
  try_fold := core.iter.adapters.zip.IteratorZip.try_fold aInst bInst
  size_hint := core.iter.adapters.zip.IteratorZip.size_hint aInst bInst
  trusted_len := aInst.trusted_len && bInst.trusted_len
  fused := aInst.fused && bInst.fused
  random_access := match aInst.random_access, bInst.random_access with
    | some aAccess, some bAccess => some {
        get_unchecked := core.iter.adapters.zip.IteratorZip.get_unchecked aAccess bAccess
        may_have_side_effect := aAccess.may_have_side_effect || bAccess.may_have_side_effect
        is_full := aAccess.is_full && bAccess.is_full
      }
    | _, _ => none
  count := core.iter.adapters.zip.IteratorZip.count aInst bInst
  any := core.iter.adapters.zip.IteratorZip.any aInst bInst
  enumerate := core.iter.adapters.zip.IteratorZip.enumerate aInst bInst
}

/-- `n` calls of `next_back` whose results are not used (`for _ in 0..n { it.next_back(); }`). -/
def core.iter.adapters.zip.DoubleEndedIteratorZip.dropBack
  {I Item : Type}
  (inst : core.iter.traits.double_ended.DoubleEndedIterator I Item) (it : I) :
  Nat → Result I
  | 0 => ok it
  | n + 1 => do
    let (_, it) ← inst.next_back it
    core.iter.adapters.zip.DoubleEndedIteratorZip.dropBack inst it n

/-- The general `ZipImpl::next_back` (core zip.rs 175-201, rustc 1.95). It gets the lengths
    with `ExactSizeIterator::len`, which panics when the hint is not exact. It trims the longer
    side with `next_back` to the length of the shorter side. Then it takes `a.next_back()` and
    then `b.next_back()`. One `Some` with one `None` is `unreachable!()`. -/
def core.iter.adapters.zip.DoubleEndedIteratorZip.nextBackGeneral
  {A B AItem BItem AItem' BItem' : Type}
  (aInst : core.iter.traits.double_ended.DoubleEndedIterator A AItem)
  (aExact : core.iter.traits.exact_size.ExactSizeIterator A AItem')
  (bInst : core.iter.traits.double_ended.DoubleEndedIterator B BItem)
  (bExact : core.iter.traits.exact_size.ExactSizeIterator B BItem')
  (self : core.iter.adapters.zip.Zip A B) :
  Result (Option (AItem × BItem) × core.iter.adapters.zip.Zip A B) := do
  let aSz ← aExact.len self.a
  let bSz ← bExact.len self.b
  let a ← if aSz.val > bSz.val then
      core.iter.adapters.zip.DoubleEndedIteratorZip.dropBack aInst self.a (aSz.val - bSz.val)
    else ok self.a
  let b ← if bSz.val > aSz.val then
      core.iter.adapters.zip.DoubleEndedIteratorZip.dropBack bInst self.b (bSz.val - aSz.val)
    else ok self.b
  let (x, a) ← aInst.next_back a
  let (y, b) ← bInst.next_back b
  match x, y with
  | some x, some y => ok (some (x, y), { self with a, b })
  | none, none => ok (none, { self with a, b })
  | _, _ => fail .panic

/-- `DoubleEndedIterator::next_back` of `Zip` (core zip.rs 118-128, rustc 1.95).
    When both sides are `TrustedRandomAccess` (`is_full`), the specialized version runs
    (zip.rs 354-410). It does nothing when `index = len`. Else it decreases `len` first.
    A side can have side effects. Then the first call trims the longer side to the old `len`
    with `next_back`. The condition is `sz_a != sz_b && (old_len == sz_a || old_len == sz_b)`.
    `size` is the lower bound of the hint.
    Then indexed access reads the item at the new `len` of both sides.
    In the other cases (`NoCoerce` only, or no random access) the general version runs. -/
@[rust_fun
  "core::iter::adapters::zip::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::zip::Zip<@A, @B>, (@Clause0_Clause0_Item, @Clause2_Clause0_Item)>}::next_back"]
def core.iter.adapters.zip.DoubleEndedIteratorZip.next_back
  {A B AItem BItem AItem' BItem' : Type}
  (aInst : core.iter.traits.double_ended.DoubleEndedIterator A AItem)
  (aExact : core.iter.traits.exact_size.ExactSizeIterator A AItem')
  (bInst : core.iter.traits.double_ended.DoubleEndedIterator B BItem)
  (bExact : core.iter.traits.exact_size.ExactSizeIterator B BItem')
  (self : core.iter.adapters.zip.Zip A B) :
  Result (Option (AItem × BItem) × core.iter.adapters.zip.Zip A B) := do
  match aInst.iteratorInst.random_access, bInst.iteratorInst.random_access with
  | some aAccess, some bAccess =>
    if aAccess.is_full && bAccess.is_full then
      if self.index.val < self.len.val then
        let oldLen := self.len
        let len ← self.len - 1#usize
        let (a, b) ←
          if aAccess.may_have_side_effect || bAccess.may_have_side_effect then do
            let (szA, _) ← aInst.iteratorInst.size_hint self.a
            let (szB, _) ← bInst.iteratorInst.size_hint self.b
            if szA.val ≠ szB.val && (oldLen.val = szA.val || oldLen.val = szB.val) then do
              let a ← if aAccess.may_have_side_effect && szA.val > oldLen.val then
                  core.iter.adapters.zip.DoubleEndedIteratorZip.dropBack aInst self.a
                    (szA.val - oldLen.val)
                else ok self.a
              let b ← if bAccess.may_have_side_effect && szB.val > oldLen.val then
                  core.iter.adapters.zip.DoubleEndedIteratorZip.dropBack bInst self.b
                    (szB.val - oldLen.val)
                else ok self.b
              ok (a, b)
            else ok (self.a, self.b)
          else ok (self.a, self.b)
        let (aItem, a) ← aAccess.get_unchecked a len
        let (bItem, b) ← bAccess.get_unchecked b len
        ok (some (aItem, bItem), { self with a, b, len })
      else ok (none, self)
    else
      core.iter.adapters.zip.DoubleEndedIteratorZip.nextBackGeneral aInst aExact bInst bExact self
  | _, _ =>
    core.iter.adapters.zip.DoubleEndedIteratorZip.nextBackGeneral aInst aExact bInst bExact self

/-- Core overrides only `next_back` (zip.rs 118-128). The other methods are the defaults of
    the trait. -/
@[reducible, rust_trait_impl
  "core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::zip::Zip<@A, @B>, (@Clause0_Clause0_Item, @Clause2_Clause0_Item)>"]
def core.iter.traits.double_ended.DoubleEndedIteratorZip
  {A B AItem BItem AItem' BItem' : Type}
  (aInst : core.iter.traits.double_ended.DoubleEndedIterator A AItem)
  (aExact : core.iter.traits.exact_size.ExactSizeIterator A AItem')
  (bInst : core.iter.traits.double_ended.DoubleEndedIterator B BItem)
  (bExact : core.iter.traits.exact_size.ExactSizeIterator B BItem') :
  core.iter.traits.double_ended.DoubleEndedIterator
    (core.iter.adapters.zip.Zip A B) (AItem × BItem) := {
  iteratorInst := core.iter.traits.iterator.IteratorZip aInst.iteratorInst bInst.iteratorInst
  next_back := core.iter.adapters.zip.DoubleEndedIteratorZip.next_back aInst aExact bInst bExact
}

@[rust_fun
  "core::iter::adapters::skip::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Item>}::nth"]
def core.iter.adapters.skip.IteratorSkip.nth
  {I Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (self : core.iter.adapters.skip.Skip I) (n : Usize) :
  Result (Option Item × core.iter.adapters.skip.Skip I) := do
  if self.n.val = 0 then
    let (item, iter) ← iterInst.nth self.iter n
    ok (item, ⟨iter, 0#usize⟩)
  else
    match Usize.checked_add self.n n with
    | some total =>
      let (item, iter) ← iterInst.nth self.iter total
      ok (item, ⟨iter, 0#usize⟩)
    | none =>
      let skip ← self.n - 1#usize
      let (item, iter) ← iterInst.nth self.iter skip
      match item with
      | none => ok (none, ⟨iter, 0#usize⟩)
      | some _ =>
        let (item, iter) ← iterInst.nth iter n
        ok (item, ⟨iter, 0#usize⟩)

@[rust_fun
  "core::iter::adapters::skip::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Item>}::next"]
def core.iter.adapters.skip.IteratorSkip.next
  {I Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (self : core.iter.adapters.skip.Skip I) :
  Result (Option Item × core.iter.adapters.skip.Skip I) := do
  let (item, iter) ← if self.n.val > 0 then iterInst.nth self.iter self.n
                    else iterInst.next self.iter
  ok (item, ⟨iter, 0#usize⟩)

@[rust_fun
  "core::iter::adapters::skip::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Item>}::advance_by"]
def core.iter.adapters.skip.IteratorSkip.advance_by
  {I Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (self : core.iter.adapters.skip.Skip I) (n : Usize) :
  Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) ×
    core.iter.adapters.skip.Skip I) := do
  let requested := UScalar.saturating_add self.n n
  let (result, iter) ← iterInst.advance_by self.iter requested
  let remaining := match result with | .Ok () => 0#usize | .Err n => n.val
  let advanced ← requested - remaining
  let n ← n - UScalar.saturating_sub advanced self.n
  let self := { iter, n := UScalar.saturating_sub self.n advanced :
    core.iter.adapters.skip.Skip I }
  if remaining.val = 0 ∧ n.val > 0 then
    let (result, iter) ← iterInst.advance_by self.iter n
    ok (result, { self with iter })
  else
    let result ← core.num.nonzero.NonZero.new n
    ok ((match result with | none => .Ok () | some n => .Err n), self)

@[rust_fun
  "core::iter::adapters::skip::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Item>}::fold"]
def core.iter.adapters.skip.IteratorSkip.fold
  {I Acc F Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (fnInst : core.ops.function.FnMut F (Acc × Item) Acc)
  (self : core.iter.adapters.skip.Skip I) (init : Acc) (f : F) :
  Result (Acc × core.iter.adapters.skip.Skip I × F) := do
  if self.n.val > 0 then
    let n ← self.n - 1#usize
    let (item, iter) ← iterInst.nth self.iter n
    match item with
    | none => ok (init, { self with iter }, f)
    | some _ =>
      let (acc, iter, f) ← iterInst.fold fnInst iter init f
      ok (acc, { self with iter }, f)
  else
    let (acc, iter, f) ← iterInst.fold fnInst self.iter init f
    ok (acc, { self with iter }, f)

@[rust_fun
  "core::iter::adapters::skip::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Item>}::try_fold"]
def core.iter.adapters.skip.IteratorSkip.try_fold
  {I Acc F R Item Residual : Type}
  (iterInst : core.iter.traits.iterator.Iterator I Item)
  (fnInst : core.ops.function.FnMut F (Acc × Item) R)
  (tryInst : core.ops.try_trait.Try R Acc Residual)
  (self : core.iter.adapters.skip.Skip I) (init : Acc) (f : F) :
  Result (R × core.iter.adapters.skip.Skip I × F) := do
  if self.n.val > 0 then
    let n ← self.n - 1#usize
    let (item, iter) ← iterInst.nth self.iter n
    match item with
    | none =>
      let result ← tryInst.from_output init
      ok (result, ⟨iter, 0#usize⟩, f)
    | some _ =>
      let (result, iter, f) ← iterInst.try_fold fnInst tryInst iter init f
      ok (result, ⟨iter, 0#usize⟩, f)
  else
    let (result, iter, f) ← iterInst.try_fold fnInst tryInst self.iter init f
    ok (result, ⟨iter, 0#usize⟩, f)

@[rust_fun
  "core::iter::adapters::skip::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Item>}::size_hint"]
def core.iter.adapters.skip.IteratorSkip.size_hint
  {I Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (self : core.iter.adapters.skip.Skip I) : Result (Usize × Option Usize) := do
  let (lower, upper) ← iterInst.size_hint self.iter
  ok (UScalar.saturating_sub lower self.n, upper.map (fun n => UScalar.saturating_sub n self.n))

@[rust_fun
  "core::iter::adapters::skip::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Item>}::count"]
def core.iter.adapters.skip.IteratorSkip.count
  {I Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (self : core.iter.adapters.skip.Skip I) :
  Result (Usize × core.iter.adapters.skip.Skip I) := do
  if self.n.val > 0 then
    let n ← self.n - 1#usize
    let (item, iter) ← iterInst.nth self.iter n
    match item with
    | none => ok (0#usize, { self with iter })
    | some _ =>
      let (count, iter) ← iterInst.count iter
      ok (count, { self with iter })
  else
    let (count, iter) ← iterInst.count self.iter
    ok (count, { self with iter })

-- Skip::try_fold takes n before skipping and invokes nth(n-1), unlike next's
-- nth(n). Preserve that distinction when nth is explicitly overridden.
@[rust_fun
  "core::iter::adapters::skip::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Item>}::any"]
def core.iter.adapters.skip.IteratorSkip.any
  {I F Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item)
  (fnInst : core.ops.function.FnMut F Item Bool)
  (self : core.iter.adapters.skip.Skip I) (f : F) :
  Result (Bool × core.iter.adapters.skip.Skip I × F) :=
  core.iter.traits.iterator.anyFromTryFold
    (core.iter.adapters.skip.IteratorSkip.try_fold iterInst) fnInst self f

@[rust_fun
  "core::iter::adapters::skip::{core::iter::traits::iterator::Iterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Item>}::enumerate"]
def core.iter.adapters.skip.IteratorSkip.enumerate
  {I Item : Type} (_iterInst : core.iter.traits.iterator.Iterator I Item)
  (self : core.iter.adapters.skip.Skip I) :
  Result (core.iter.adapters.enumerate.Enumerate (core.iter.adapters.skip.Skip I)) :=
  core.iter.traits.iterator.Iterator.enumerate.default self

def core.iter.adapters.skip.IteratorSkip.dropRandomPrefix
  {I Item : Type} (access : core.iter.traits.iterator.RandomAccess I Item)
  (iter : I) (index : Usize) : Nat → Result I
  | 0 => ok iter
  | n + 1 => do
    let (_, iter) ← access.get_unchecked iter index
    let index ← index + 1#usize
    core.iter.adapters.skip.IteratorSkip.dropRandomPrefix access iter index n

def core.iter.adapters.skip.IteratorSkip.get_unchecked
  {I Item : Type} (access : core.iter.traits.iterator.RandomAccess I Item)
  (self : core.iter.adapters.skip.Skip I) (idx : Usize) :
  Result (Item × core.iter.adapters.skip.Skip I) := do
  let iter ←
    if access.may_have_side_effect && idx.val == 0 then
      core.iter.adapters.skip.IteratorSkip.dropRandomPrefix access self.iter 0#usize self.n.val
    else ok self.iter
  let idx ← idx + self.n
  let (item, iter) ← access.get_unchecked iter idx
  ok (item, { self with iter })

@[reducible, rust_trait_impl
  "core::iter::traits::iterator::Iterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Item>"]
def core.iter.traits.iterator.IteratorSkip
  {I Item : Type} (iterInst : core.iter.traits.iterator.Iterator I Item) :
  core.iter.traits.iterator.Iterator (core.iter.adapters.skip.Skip I) Item := {
  next := core.iter.adapters.skip.IteratorSkip.next iterInst
  nth := core.iter.adapters.skip.IteratorSkip.nth iterInst
  advance_by := core.iter.adapters.skip.IteratorSkip.advance_by iterInst
  fold := core.iter.adapters.skip.IteratorSkip.fold iterInst
  try_fold := core.iter.adapters.skip.IteratorSkip.try_fold iterInst
  size_hint := core.iter.adapters.skip.IteratorSkip.size_hint iterInst
  trusted_len := iterInst.trusted_random_access
  fused := iterInst.fused
  random_access := iterInst.random_access.map fun access => {
    get_unchecked := core.iter.adapters.skip.IteratorSkip.get_unchecked access
    may_have_side_effect := access.may_have_side_effect
    is_full := access.is_full
  }
  count := core.iter.adapters.skip.IteratorSkip.count iterInst
  any := core.iter.adapters.skip.IteratorSkip.any iterInst
  enumerate := core.iter.adapters.skip.IteratorSkip.enumerate iterInst
}

/-! `DoubleEndedIterator for Skip<I>` (core skip.rs, rustc 1.95), for
    `I: DoubleEndedIterator + ExactSizeIterator` (clauses in that order). The
    back yields only the `self.len()` items that the front skip leaves, where
    `self.len()` is Skip's provided `ExactSizeIterator::len`: Skip's size_hint
    (the inner hint minus `n`, saturating), asserting that its bounds agree. -/

def core.iter.adapters.skip.DoubleEndedIteratorSkip.len {I Item : Type}
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (self : core.iter.adapters.skip.Skip I) : Result Usize := do
  let (lower, upper) ← core.iter.adapters.skip.IteratorSkip.size_hint backInst.iteratorInst self
  if upper == some lower then ok lower else fail .panic

/-- `if self.len() > 0 { self.iter.next_back() } else { None }` -/
@[rust_fun
  "core::iter::adapters::skip::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Clause0_Item>}::next_back"]
def core.iter.adapters.skip.DoubleEndedIteratorSkip.next_back {I Item : Type}
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (_exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item)
    (self : core.iter.adapters.skip.Skip I) :
    Result (Option Item × core.iter.adapters.skip.Skip I) := do
  let len ← core.iter.adapters.skip.DoubleEndedIteratorSkip.len backInst self
  if len.val > 0 then
    let (item, iter) ← backInst.next_back self.iter
    ok (item, { self with iter })
  else ok (none, self)

/-- Within the remaining `len` items, `nth_back(n)` of the inner iterator;
    beyond them, exhaust exactly those `len` items and return `None`. -/
@[rust_fun
  "core::iter::adapters::skip::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Clause0_Item>}::nth_back"]
def core.iter.adapters.skip.DoubleEndedIteratorSkip.nth_back {I Item : Type}
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (_exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item)
    (self : core.iter.adapters.skip.Skip I) (n : Usize) :
    Result (Option Item × core.iter.adapters.skip.Skip I) := do
  let len ← core.iter.adapters.skip.DoubleEndedIteratorSkip.len backInst self
  if n.val < len.val then
    let (item, iter) ← backInst.nth_back self.iter n
    ok (item, { self with iter })
  else if len.val > 0 then
    let (_, iter) ← backInst.nth_back self.iter (← len - 1#usize)
    ok (none, { self with iter })
  else ok (none, self)

/-- `try_rfold` folds the inner iterator from the back through `check(n, fold)`,
    which counts the `n = self.len()` items it may take and breaks with the
    fold's own result at the last one (`ControlFlow::from_try` otherwise). -/
@[rust_fun
  "core::iter::adapters::skip::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Clause0_Item>}::try_rfold"]
def core.iter.adapters.skip.DoubleEndedIteratorSkip.try_rfold {I Item B F R Residual : Type}
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (_exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item)
    (fnInst : core.ops.function.FnMut F (B × Item) R)
    (tryInst : core.ops.try_trait.Try R B Residual)
    (self : core.iter.adapters.skip.Skip I) (init : B) (f : F) :
    Result (R × core.iter.adapters.skip.Skip I × F) := do
  let n ← core.iter.adapters.skip.DoubleEndedIteratorSkip.len backInst self
  if n.val = 0 then return (← tryInst.from_output init, self, f)
  let call := fun (state : F × Usize) (args : B × Item) => do
    let n := UScalar.wrapping_sub state.2 1#usize
    let (r, f) ← fnInst.call_mut state.1 args
    if n.val = 0 then
      return ((.Break r : core.ops.control_flow.ControlFlow R B), (f, n))
    match ← tryInst.branch r with
    | .Continue acc => return ((.Continue acc : core.ops.control_flow.ControlFlow R B), (f, n))
    | .Break residual =>
      let r ← tryInst.FromResidualInst.from_residual residual
      return ((.Break r : core.ops.control_flow.ControlFlow R B), (f, n))
  let check : core.ops.function.FnMut (F × Usize) (B × Item)
      (core.ops.control_flow.ControlFlow R B) := {
    FnOnceInst := { call_once := call }
    call_mut := call
  }
  let (flow, iter, (f, _)) ← backInst.try_rfold check
    (core.iter.traits.iterator.controlFlowTry R B) self.iter init (f, n)
  let r ← match flow with
    | .Continue acc => tryInst.from_output acc
    | .Break r => ok r
  ok (r, { self with iter }, f)

/-- `impl_fold_via_try_fold! { rfold -> try_rfold }`: `try_rfold` with a
    fold that never short-circuits. -/
@[rust_fun
  "core::iter::adapters::skip::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Clause0_Item>}::rfold"]
def core.iter.adapters.skip.DoubleEndedIteratorSkip.rfold {I Item B F : Type}
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item)
    (fnInst : core.ops.function.FnMut F (B × Item) B)
    (self : core.iter.adapters.skip.Skip I) (init : B) (f : F) :
    Result (B × core.iter.adapters.skip.Skip I × F) := do
  let call := fun f args => do
    let (acc, f) ← fnInst.call_mut f args
    return ((.Continue acc : core.ops.control_flow.ControlFlow Empty B), f)
  let wrapped : core.ops.function.FnMut F (B × Item)
      (core.ops.control_flow.ControlFlow Empty B) := {
    FnOnceInst := { call_once := call }
    call_mut := call
  }
  let (r, self, f) ← core.iter.adapters.skip.DoubleEndedIteratorSkip.try_rfold backInst exactInst
    wrapped (core.iter.traits.iterator.controlFlowTry Empty B) self init f
  match r with
  | .Continue acc => ok (acc, self, f)
  | .Break impossible => nomatch impossible

/-- Advance the inner iterator by `min(self.len(), n)` from the back, asserting
    that it succeeds, and report the rest of `n`. -/
@[rust_fun
  "core::iter::adapters::skip::{core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Clause0_Item>}::advance_back_by"]
def core.iter.adapters.skip.DoubleEndedIteratorSkip.advance_back_by {I Item : Type}
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (_exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item)
    (self : core.iter.adapters.skip.Skip I) (n : Usize) :
    Result (core.result.Result Unit (core.num.nonzero.NonZero Usize) ×
      core.iter.adapters.skip.Skip I) := do
  let len ← core.iter.adapters.skip.DoubleEndedIteratorSkip.len backInst self
  let min := if n.val < len.val then n else len
  let (rem, iter) ← backInst.advance_back_by self.iter min
  match rem with
  | .Err _ => fail .panic
  | .Ok _ =>
    let rest ← core.num.nonzero.NonZero.new (← n - min)
    ok ((match rest with | none => .Ok () | some rest => .Err rest), { self with iter })

@[reducible, rust_trait_impl
  "core::iter::traits::double_ended::DoubleEndedIterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Clause0_Item>"]
def core.iter.traits.double_ended.DoubleEndedIteratorSkip {I Item : Type}
    (backInst : core.iter.traits.double_ended.DoubleEndedIterator I Item)
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item) :
    core.iter.traits.double_ended.DoubleEndedIterator (core.iter.adapters.skip.Skip I) Item := {
  iteratorInst := core.iter.traits.iterator.IteratorSkip backInst.iteratorInst
  next_back := core.iter.adapters.skip.DoubleEndedIteratorSkip.next_back backInst exactInst
  nth_back := core.iter.adapters.skip.DoubleEndedIteratorSkip.nth_back backInst exactInst
  advance_back_by := core.iter.adapters.skip.DoubleEndedIteratorSkip.advance_back_by backInst exactInst
  rfold := core.iter.adapters.skip.DoubleEndedIteratorSkip.rfold backInst exactInst
  try_rfold := core.iter.adapters.skip.DoubleEndedIteratorSkip.try_rfold backInst exactInst
}

/-- `ExactSizeIterator for Skip<I>` keeps the provided `len` (Skip's size_hint,
    asserting that its bounds agree). -/
@[reducible, rust_trait_impl
  "core::iter::traits::exact_size::ExactSizeIterator<core::iter::adapters::skip::Skip<@I>, @Clause0_Clause0_Item>"]
def core.iter.traits.exact_size.ExactSizeIteratorSkip {I Item : Type}
    (exactInst : core.iter.traits.exact_size.ExactSizeIterator I Item) :
    core.iter.traits.exact_size.ExactSizeIterator (core.iter.adapters.skip.Skip I) Item := {
  iteratorInst := core.iter.traits.iterator.IteratorSkip exactInst.iteratorInst
}

end Aeneas.Std
