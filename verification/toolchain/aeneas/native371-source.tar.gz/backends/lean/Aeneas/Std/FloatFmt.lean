import Aeneas.Std.Float
import Aeneas.Std.Scalar.Fmt

namespace Aeneas.Std.core.fmt

/-- Decimal exponent of a positive exact rational. Decimal lengths give an
    estimate which is either exact or one too large. -/
def decimalExponent (n d : Nat) : Int :=
  let e : Int := (digits n).length - ((digits d).length : Int)
  let below := if e ≥ 0 then n < d * 10 ^ e.toNat else n * 10 ^ (-e).toNat < d
  if below then e - 1 else e

def decimalRatio (coefficient : Nat) (exponent : Int) : Nat × Nat :=
  if exponent ≥ 0 then (coefficient * 10 ^ exponent.toNat, 1)
  else (coefficient, 10 ^ (-exponent).toNat)

def roundDecimal (n d : Nat) (exponent : Int) : Nat :=
  if exponent ≥ 0 then BinaryFloat.roundQuotient n (d * 10 ^ exponent.toNat)
  else BinaryFloat.roundQuotient (n * 10 ^ (-exponent).toNat) d

/-- Search increasing significant precision for the nearest decimal inside the
    original IEEE rounding interval. All four carriers need at most 17 digits.
    Exhausting the mathematically sufficient bound is an error, never fake text. -/
def shortestDecimal {f} (x : BinaryFloat f) (n d : Nat) (e : Int) :
    Nat → Nat → Result (Nat × Int)
  | 0, _ => .fail .panic
  | fuel + 1, precision =>
    let scale := e - (precision : Int) + 1
    -- Rust's shortest mode breaks exact decimal ties upward; its explicit
    -- precision mode above instead rounds ties to even.
    let (a, b) := if scale ≥ 0 then (n, d * 10 ^ scale.toNat)
      else (n * 10 ^ (-scale).toNat, d)
    let coefficient := a / b + if 2 * (a % b) ≥ b then 1 else 0
    let candidates := [coefficient, coefficient - 1, coefficient + 1]
    match candidates.find? (fun c =>
        let (a, b) := decimalRatio c scale
        (BinaryFloat.round f false a b).bits == x.abs.bits) with
    | some c => .ok (c, scale)
    | none => shortestDecimal x n d e fuel (precision + 1)

def trimDecimal : Nat → Nat → Int → Nat × Int
  | 0, c, e => (c, e)
  | fuel + 1, c, e =>
    if c != 0 && c % 10 == 0 then trimDecimal fuel (c / 10) (e + 1) else (c, e)

/-- The pinned flt2dec renderer retains Copy/Zero boundaries. In particular,
    decimal points and exponents are not part of an atomic digit-buffer write. -/
inductive FloatPart where
  | copy (text : String)
  | zero (count : Nat)

def FloatPart.length : FloatPart → Nat
  | .copy text => text.utf8ByteSize
  | .zero count => count

def writeFloatParts : List FloatPart → Formatter → Outcome
  | [], fmt => .ok (.Ok (), fmt)
  | part :: rest, fmt =>
    let written := match part with
      | .copy text => fmt.append text
      | .zero count =>
        thenFormat (writeRepeated (repeatChar '0' 64) (count / 64) fmt) (fun fmt =>
          if count % 64 == 0 then .ok (.Ok (), fmt)
          else fmt.append (repeatChar '0' (count % 64)))
    thenFormat written (writeFloatParts rest)

def Formatter.padFloat (fmt : Formatter) (sign : String) (parts : List FloatPart) : Outcome :=
  let content : Callback := fun fmt =>
    if sign.isEmpty then writeFloatParts parts fmt
    else thenFormat (fmt.append sign) (writeFloatParts parts)
  let o := fmt.options
  let length := parts.foldl (fun length part => length + part.length) 0
  if o.width == 0 then content fmt
  else if o.bit 24 then
    -- Unlike pad_integral, pad_formatted_parts writes even an empty sign here.
    thenFormat (fmt.append sign) (fun fmt =>
      let fmt := { fmt with options := o.zeroPadded }
      let padding := o.width - sign.utf8ByteSize - length
      if padding == 0 then do
        let (status, fmt) ← writeFloatParts parts fmt
        .ok (status, { fmt with options := o })
      else thenFormat (writeFill '0' padding fmt) (fun fmt =>
        thenFormat (writeFloatParts parts fmt) (fun fmt =>
          .ok (.Ok (), { fmt with options := o }))))
  else fmt.padWith (o.width - sign.utf8ByteSize - length) true content

def zeroDecimalParts (precision : Nat) : List FloatPart :=
  if precision == 0 then [.copy "0"] else [.copy "0.", .zero precision]

def fixedDecimalParts (text : String) (scale : Int) (minimumPrecision : Nat := 0) :
    List FloatPart :=
  let point := (text.length : Int) + scale
  if point ≤ 0 then
    [.copy "0.", .zero (-point).toNat, .copy text,
      .zero (minimumPrecision - text.length - (-point).toNat)]
  else if point < text.length then
    [.copy (String.ofList (text.toList.take point.toNat)), .copy ".",
      .copy (String.ofList (text.toList.drop point.toNat)),
      .zero (minimumPrecision - (text.length - point.toNat))]
  else
    [.copy text, .zero (point.toNat - text.length)] ++
      if minimumPrecision == 0 then [] else [.copy ".", .zero minimumPrecision]

/-- `flt2dec::digits_to_exp_str(buf, exp, minDigits, false, ..)` for the digits of `coefficient`
    (the value `coefficient * 10^scale`): the first digit; `.`, the other digits and the zeros up to
    `minDigits` digits when there are other digits or `minDigits > 1`; `e` or `e-` and the
    exponent. -/
def scientificDecimalParts (coefficient : Nat) (scale : Int) (minDigits : Nat := 0) :
    List FloatPart :=
  let text := digits coefficient
  let exponent := scale + (text.length : Int) - 1
  [.copy (String.ofList (text.toList.take 1))] ++
    (if text.length > 1 || minDigits > 1 then
      [.copy ".", .copy (String.ofList (text.toList.drop 1))] ++
        (if minDigits > text.length then [.zero (minDigits - text.length)] else [])
     else []) ++
    [.copy (if exponent < 0 then "e-" else "e"), .copy (digits exponent.natAbs)]

/-- Exact mode's buffer bound comes from flt2dec::estimate_max_buf_len and its
    decoded binary exponent. Extra requested precision is a separate Zero part,
    not an extension of the Copy buffer. -/
def exactDecimalParts {f} (x : BinaryFloat f) (n d precision : Nat) : List FloatPart :=
  if x.isZero then zeroDecimalParts precision
  else
    let binaryExponent : Int := ((max 1 x.exponent : Nat) : Int) - (f.bias : Int) -
      (f.fractionBits : Int) - (if x.exponent != 0 && x.fraction == 0 then 2 else 1)
    let maxLength := 21 + (if binaryExponent < 0 then 12 else 5) * binaryExponent.natAbs / 16
    let scale := max (-(precision : Int)) (decimalExponent n d + 1 - (maxLength : Int))
    let coefficient := roundDecimal n d scale
    if coefficient == 0 then zeroDecimalParts precision
    else
      let text := digits coefficient
      let dropped := text.length - maxLength
      fixedDecimalParts (if dropped == 0 then text else String.ofList (text.toList.take maxLength))
        (scale + (dropped : Int)) precision

/-- Rust Display is shortest fixed decimal; Debug uses one fractional digit in
    fixed notation and scientific notation below 1e-4 or at/above 1e16. Explicit
    precision uses correctly rounded fixed decimal for both traits. Half's own
    traits delegate to f32, so their callers cast before entering this model. -/
def floatFormat {f} (debug : Bool) (x : BinaryFloat f) (fmt : Formatter) : Outcome := do
  let sign := if x.isNaN then "" else if x.sign then "-" else if fmt.options.bit 21 then "+" else ""
  if x.isNaN then return ← fmt.padFloat sign [.copy "NaN"]
  if x.isInfinite then return ← fmt.padFloat sign [.copy "inf"]
  let (n, d) := x.ratio
  let parts ← if fmt.options.bit 28 then
      .ok (exactDecimalParts x n d fmt.options.precision)
    else if x.isZero then .ok (zeroDecimalParts (if debug then 1 else 0))
    else do
      let (c, e) ← shortestDecimal x n d (decimalExponent n d) 17 1
      let (c, e) := trimDecimal 17 c e
      let lower := BinaryFloat.round f false 1 10000
      let upper := BinaryFloat.round f false (10 ^ 16) 1
      if debug && (BinaryFloat.lt x.abs lower || BinaryFloat.le upper x.abs) then
        .ok (scientificDecimalParts c e)
      else .ok (fixedDecimalParts (digits c) e (if debug then 1 else 0))
  fmt.padFloat sign parts

@[rust_fun "core::fmt::float::{core::fmt::Debug<f32>}::fmt"]
def DebugF32.fmt (x : F32) (fmt : Formatter) : Outcome := floatFormat true x fmt
@[reducible, rust_trait_impl "core::fmt::Debug<f32>"]
def DebugF32 : Debug F32 := ⟨DebugF32.fmt⟩
@[rust_fun "core::fmt::float::{core::fmt::Display<f32>}::fmt"]
def DisplayF32.fmt (x : F32) (fmt : Formatter) : Outcome := floatFormat false x fmt
@[reducible, rust_trait_impl "core::fmt::Display<f32>"]
def DisplayF32 : Display F32 := ⟨DisplayF32.fmt⟩

@[rust_fun "core::fmt::float::{core::fmt::Debug<f64>}::fmt"]
def DebugF64.fmt (x : F64) (fmt : Formatter) : Outcome := floatFormat true x fmt
@[reducible, rust_trait_impl "core::fmt::Debug<f64>"]
def DebugF64 : Debug F64 := ⟨DebugF64.fmt⟩
@[rust_fun "core::fmt::float::{core::fmt::Display<f64>}::fmt"]
def DisplayF64.fmt (x : F64) (fmt : Formatter) : Outcome := floatFormat false x fmt
@[reducible, rust_trait_impl "core::fmt::Display<f64>"]
def DisplayF64 : Display F64 := ⟨DisplayF64.fmt⟩

/-- `impl LowerExp for f32/f64` (core/src/fmt/float.rs `float_to_exponential_common`, rustc 1.95):
    the sign as `Display`'s (`flt2dec::determine_sign`); NaN and the infinities as `Display`'s;
    without a precision, zero is `0e0` and any other value its shortest round-trip digits in
    exponential form (`to_shortest_exp_str` with the bounds `(0, 0)`); with a precision `p`, zero is
    `0e0`, or `0.`, `p` zeros and `e0`, and any other value is rounded half to even to `p + 1`
    significant digits (`to_exact_exp_str`: a carry keeps `p + 1` digits and raises the exponent).
    `p + 1` is a `u16` sum: the precision 65535 wraps it to 0, which `to_exact_exp_str` asserts
    against. -/
def lowerExpFormat {f} (x : BinaryFloat f) (fmt : Formatter) : Outcome := do
  let sign := if x.isNaN then "" else if x.sign then "-" else if fmt.options.bit 21 then "+" else ""
  if x.isNaN then return ← fmt.padFloat sign [.copy "NaN"]
  if x.isInfinite then return ← fmt.padFloat sign [.copy "inf"]
  let (n, d) := x.ratio
  let parts ← if fmt.options.bit 28 then do
      let ndigits := fmt.options.precision + 1
      if ndigits == 65536 then .fail .panic
      else if x.isZero then
        .ok (if ndigits > 1 then [.copy "0.", .zero (ndigits - 1), .copy "e0"] else [.copy "0e0"])
      else
        let scale := decimalExponent n d + 1 - (ndigits : Int)
        let c := roundDecimal n d scale
        let (c, scale) := if (digits c).length > ndigits then (c / 10, scale + 1) else (c, scale)
        .ok (scientificDecimalParts c scale ndigits)
    else if x.isZero then .ok [.copy "0e0"]
    else do
      let (c, e) ← shortestDecimal x n d (decimalExponent n d) 17 1
      let (c, e) := trimDecimal 17 c e
      .ok (scientificDecimalParts c e)
  fmt.padFloat sign parts

@[rust_fun "core::fmt::float::{core::fmt::LowerExp<f64>}::fmt"]
def LowerExpF64.fmt (x : F64) (fmt : Formatter) : Outcome := lowerExpFormat x fmt
@[reducible, rust_trait_impl "core::fmt::LowerExp<f64>"]
def LowerExpF64 : LowerExp F64 := ⟨LowerExpF64.fmt⟩

@[rust_fun "half::binary16::{core::fmt::Debug<half::binary16::f16>}::fmt"]
def DebugF16.fmt (x : F16) (fmt : Formatter) : Outcome := DebugF32.fmt (BinaryFloat.cast .binary32 x) fmt
@[reducible, rust_trait_impl "core::fmt::Debug<half::binary16::f16>"]
def DebugF16 : Debug F16 := ⟨DebugF16.fmt⟩
@[rust_fun "half::binary16::{core::fmt::Display<half::binary16::f16>}::fmt"]
def DisplayF16.fmt (x : F16) (fmt : Formatter) : Outcome := DisplayF32.fmt (BinaryFloat.cast .binary32 x) fmt
@[reducible, rust_trait_impl "core::fmt::Display<half::binary16::f16>"]
def DisplayF16 : Display F16 := ⟨DisplayF16.fmt⟩

@[rust_fun "half::bfloat::{core::fmt::Debug<half::bfloat::bf16>}::fmt"]
def DebugBF16.fmt (x : BF16) (fmt : Formatter) : Outcome := DebugF32.fmt (BinaryFloat.cast .binary32 x) fmt
@[reducible, rust_trait_impl "core::fmt::Debug<half::bfloat::bf16>"]
def DebugBF16 : Debug BF16 := ⟨DebugBF16.fmt⟩
@[rust_fun "half::bfloat::{core::fmt::Display<half::bfloat::bf16>}::fmt"]
def DisplayBF16.fmt (x : BF16) (fmt : Formatter) : Outcome := DisplayF32.fmt (BinaryFloat.cast .binary32 x) fmt
@[reducible, rust_trait_impl "core::fmt::Display<half::bfloat::bf16>"]
def DisplayBF16 : Display BF16 := ⟨DisplayBF16.fmt⟩

end Aeneas.Std.core.fmt
