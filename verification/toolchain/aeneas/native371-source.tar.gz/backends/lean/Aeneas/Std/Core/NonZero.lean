import Aeneas.Std.Scalar.Core
import Aeneas.Std.Scalar.CloneCopy
import Aeneas.Std.Core.Core

namespace Aeneas.Std

/-- Only the primitives admitted by Rust's sealed `ZeroablePrimitive` trait can
    inhabit this predicate. Signed negative values are nonzero too. -/
inductive core.num.nonzero.NonZeroValue : {T : Type} → T → Prop where
  | unsigned {ty : UScalarTy} {n : UScalar ty} (h : n.val ≠ 0) : NonZeroValue n
  | signed {ty : IScalarTy} {n : IScalar ty} (h : n.val ≠ 0) : NonZeroValue n
  | char {n : Char} (h : n.toNat ≠ 0) : NonZeroValue n

@[rust_type "core::num::nonzero::NonZero" (body := .opaque) (keepParams := [true, false])]
structure core.num.nonzero.NonZero (T : Type) where
  val : T
  nonzero : core.num.nonzero.NonZeroValue val

/-- The niche excludes precisely the zero bit pattern. For signed integers this
    includes every negative value, as in `niche_types.rs`'s unsigned range check. -/
abbrev core.num.niche_types.UnsignedNonZeroInner (ty : UScalarTy) :=
  { n : UScalar ty // n.val ≠ 0 }

abbrev core.num.niche_types.SignedNonZeroInner (ty : IScalarTy) :=
  { n : IScalar ty // n.val ≠ 0 }

@[rust_type "core::num::niche_types::NonZeroU8Inner" (body := .opaque)]
abbrev core.num.niche_types.NonZeroU8Inner := core.num.niche_types.UnsignedNonZeroInner .U8

@[rust_type "core::num::niche_types::NonZeroU16Inner" (body := .opaque)]
abbrev core.num.niche_types.NonZeroU16Inner := core.num.niche_types.UnsignedNonZeroInner .U16

@[rust_type "core::num::niche_types::NonZeroU32Inner" (body := .opaque)]
abbrev core.num.niche_types.NonZeroU32Inner := core.num.niche_types.UnsignedNonZeroInner .U32

@[rust_type "core::num::niche_types::NonZeroU64Inner" (body := .opaque)]
abbrev core.num.niche_types.NonZeroU64Inner := core.num.niche_types.UnsignedNonZeroInner .U64

@[rust_type "core::num::niche_types::NonZeroU128Inner" (body := .opaque)]
abbrev core.num.niche_types.NonZeroU128Inner := core.num.niche_types.UnsignedNonZeroInner .U128

@[rust_type "core::num::niche_types::NonZeroUsizeInner" (body := .opaque)]
abbrev core.num.niche_types.NonZeroUsizeInner := core.num.niche_types.UnsignedNonZeroInner .Usize

@[rust_type "core::num::niche_types::NonZeroI8Inner" (body := .opaque)]
abbrev core.num.niche_types.NonZeroI8Inner := core.num.niche_types.SignedNonZeroInner .I8

@[rust_type "core::num::niche_types::NonZeroI16Inner" (body := .opaque)]
abbrev core.num.niche_types.NonZeroI16Inner := core.num.niche_types.SignedNonZeroInner .I16

@[rust_type "core::num::niche_types::NonZeroI32Inner" (body := .opaque)]
abbrev core.num.niche_types.NonZeroI32Inner := core.num.niche_types.SignedNonZeroInner .I32

@[rust_type "core::num::niche_types::NonZeroI64Inner" (body := .opaque)]
abbrev core.num.niche_types.NonZeroI64Inner := core.num.niche_types.SignedNonZeroInner .I64

@[rust_type "core::num::niche_types::NonZeroI128Inner" (body := .opaque)]
abbrev core.num.niche_types.NonZeroI128Inner := core.num.niche_types.SignedNonZeroInner .I128

@[rust_type "core::num::niche_types::NonZeroIsizeInner" (body := .opaque)]
abbrev core.num.niche_types.NonZeroIsizeInner := core.num.niche_types.SignedNonZeroInner .Isize

@[rust_type "core::num::niche_types::NonZeroCharInner" (body := .opaque)]
abbrev core.num.niche_types.NonZeroCharInner := { n : Char // n.toNat ≠ 0 }

/-- Closed evidence for the primitive and its actual associated niche type;
    there is no operation accepting an arbitrary `T` and guessing its zero. -/
inductive core.num.nonzero.Primitive : Type → Type → Type where
  | unsigned (ty : UScalarTy) : Primitive (UScalar ty)
      (core.num.niche_types.UnsignedNonZeroInner ty)
  | signed (ty : IScalarTy) : Primitive (IScalar ty)
      (core.num.niche_types.SignedNonZeroInner ty)
  | char : Primitive Char core.num.niche_types.NonZeroCharInner

@[rust_trait "core::num::nonzero::private::Sealed"]
structure core.num.nonzero.«private».Sealed (Self : Type) where

@[rust_trait "core::num::nonzero::ZeroablePrimitive"
  (parentClauses := ["copyInst", "sealedInst", "innerCopyInst"])
  (auxiliaryFields := ["primitive"])]
structure core.num.nonzero.ZeroablePrimitive (Self NonZeroInner : Type) where
  copyInst : core.marker.Copy Self
  sealedInst : core.num.nonzero.«private».Sealed Self
  innerCopyInst : core.marker.Copy NonZeroInner
  /-- `none` denotes an invalid model dictionary, never a valid Rust instance.
      Every sealed source instance below supplies its exact primitive evidence. -/
  primitive : Option (core.num.nonzero.Primitive Self NonZeroInner) := none

@[rust_fun "core::clone::impls::{core::clone::Clone<char>}::clone"]
def core.clone.CloneChar.clone (self : Char) : Result Char := .ok self

@[reducible, rust_trait_impl "core::clone::Clone<char>"]
def core.clone.CloneChar : core.clone.Clone Char := {
  clone := core.clone.CloneChar.clone
}

@[reducible, rust_trait_impl "core::marker::Copy<char>"]
def core.marker.CopyChar : core.marker.Copy Char := { cloneInst := core.clone.CloneChar }

@[rust_fun
  "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroU8Inner>}::clone"]
def core.clone.CloneNonZeroU8Inner.clone (self : core.num.niche_types.NonZeroU8Inner) :
    Result core.num.niche_types.NonZeroU8Inner := .ok self

@[reducible, rust_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroU8Inner>"]
def core.clone.CloneNonZeroU8Inner : core.clone.Clone core.num.niche_types.NonZeroU8Inner := {
  clone := core.clone.CloneNonZeroU8Inner.clone
}

@[reducible, rust_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroU8Inner>"]
def core.marker.CopyNonZeroU8Inner : core.marker.Copy core.num.niche_types.NonZeroU8Inner := {
  cloneInst := core.clone.CloneNonZeroU8Inner
}

@[reducible, rust_trait_impl "core::num::nonzero::private::Sealed<u8>"]
def core.num.nonzero.«private».SealedU8 : core.num.nonzero.«private».Sealed U8 := {}

@[reducible, rust_trait_impl
  "core::num::nonzero::ZeroablePrimitive<u8, core::num::niche_types::NonZeroU8Inner>"]
def core.num.nonzero.ZeroablePrimitiveU8 :
    core.num.nonzero.ZeroablePrimitive U8 core.num.niche_types.NonZeroU8Inner := {
  copyInst := core.marker.CopyU8
  sealedInst := core.num.nonzero.«private».SealedU8
  innerCopyInst := core.marker.CopyNonZeroU8Inner
  primitive := some (.unsigned .U8)
}

@[rust_fun
  "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroU16Inner>}::clone"]
def core.clone.CloneNonZeroU16Inner.clone (self : core.num.niche_types.NonZeroU16Inner) :
    Result core.num.niche_types.NonZeroU16Inner := .ok self

@[reducible, rust_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroU16Inner>"]
def core.clone.CloneNonZeroU16Inner : core.clone.Clone core.num.niche_types.NonZeroU16Inner := {
  clone := core.clone.CloneNonZeroU16Inner.clone
}

@[reducible, rust_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroU16Inner>"]
def core.marker.CopyNonZeroU16Inner : core.marker.Copy core.num.niche_types.NonZeroU16Inner := {
  cloneInst := core.clone.CloneNonZeroU16Inner
}

@[reducible, rust_trait_impl "core::num::nonzero::private::Sealed<u16>"]
def core.num.nonzero.«private».SealedU16 : core.num.nonzero.«private».Sealed U16 := {}

@[reducible, rust_trait_impl
  "core::num::nonzero::ZeroablePrimitive<u16, core::num::niche_types::NonZeroU16Inner>"]
def core.num.nonzero.ZeroablePrimitiveU16 :
    core.num.nonzero.ZeroablePrimitive U16 core.num.niche_types.NonZeroU16Inner := {
  copyInst := core.marker.CopyU16
  sealedInst := core.num.nonzero.«private».SealedU16
  innerCopyInst := core.marker.CopyNonZeroU16Inner
  primitive := some (.unsigned .U16)
}

@[rust_fun
  "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroU32Inner>}::clone"]
def core.clone.CloneNonZeroU32Inner.clone (self : core.num.niche_types.NonZeroU32Inner) :
    Result core.num.niche_types.NonZeroU32Inner := .ok self

@[reducible, rust_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroU32Inner>"]
def core.clone.CloneNonZeroU32Inner : core.clone.Clone core.num.niche_types.NonZeroU32Inner := {
  clone := core.clone.CloneNonZeroU32Inner.clone
}

@[reducible, rust_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroU32Inner>"]
def core.marker.CopyNonZeroU32Inner : core.marker.Copy core.num.niche_types.NonZeroU32Inner := {
  cloneInst := core.clone.CloneNonZeroU32Inner
}

@[reducible, rust_trait_impl "core::num::nonzero::private::Sealed<u32>"]
def core.num.nonzero.«private».SealedU32 : core.num.nonzero.«private».Sealed U32 := {}

@[reducible, rust_trait_impl
  "core::num::nonzero::ZeroablePrimitive<u32, core::num::niche_types::NonZeroU32Inner>"]
def core.num.nonzero.ZeroablePrimitiveU32 :
    core.num.nonzero.ZeroablePrimitive U32 core.num.niche_types.NonZeroU32Inner := {
  copyInst := core.marker.CopyU32
  sealedInst := core.num.nonzero.«private».SealedU32
  innerCopyInst := core.marker.CopyNonZeroU32Inner
  primitive := some (.unsigned .U32)
}

@[rust_fun
  "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroU64Inner>}::clone"]
def core.clone.CloneNonZeroU64Inner.clone (self : core.num.niche_types.NonZeroU64Inner) :
    Result core.num.niche_types.NonZeroU64Inner := .ok self

@[reducible, rust_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroU64Inner>"]
def core.clone.CloneNonZeroU64Inner : core.clone.Clone core.num.niche_types.NonZeroU64Inner := {
  clone := core.clone.CloneNonZeroU64Inner.clone
}

@[reducible, rust_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroU64Inner>"]
def core.marker.CopyNonZeroU64Inner : core.marker.Copy core.num.niche_types.NonZeroU64Inner := {
  cloneInst := core.clone.CloneNonZeroU64Inner
}

@[reducible, rust_trait_impl "core::num::nonzero::private::Sealed<u64>"]
def core.num.nonzero.«private».SealedU64 : core.num.nonzero.«private».Sealed U64 := {}

@[reducible, rust_trait_impl
  "core::num::nonzero::ZeroablePrimitive<u64, core::num::niche_types::NonZeroU64Inner>"]
def core.num.nonzero.ZeroablePrimitiveU64 :
    core.num.nonzero.ZeroablePrimitive U64 core.num.niche_types.NonZeroU64Inner := {
  copyInst := core.marker.CopyU64
  sealedInst := core.num.nonzero.«private».SealedU64
  innerCopyInst := core.marker.CopyNonZeroU64Inner
  primitive := some (.unsigned .U64)
}

@[rust_fun
  "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroU128Inner>}::clone"]
def core.clone.CloneNonZeroU128Inner.clone (self : core.num.niche_types.NonZeroU128Inner) :
    Result core.num.niche_types.NonZeroU128Inner := .ok self

@[reducible, rust_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroU128Inner>"]
def core.clone.CloneNonZeroU128Inner : core.clone.Clone core.num.niche_types.NonZeroU128Inner := {
  clone := core.clone.CloneNonZeroU128Inner.clone
}

@[reducible, rust_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroU128Inner>"]
def core.marker.CopyNonZeroU128Inner : core.marker.Copy core.num.niche_types.NonZeroU128Inner := {
  cloneInst := core.clone.CloneNonZeroU128Inner
}

@[reducible, rust_trait_impl "core::num::nonzero::private::Sealed<u128>"]
def core.num.nonzero.«private».SealedU128 : core.num.nonzero.«private».Sealed U128 := {}

@[reducible, rust_trait_impl
  "core::num::nonzero::ZeroablePrimitive<u128, core::num::niche_types::NonZeroU128Inner>"]
def core.num.nonzero.ZeroablePrimitiveU128 :
    core.num.nonzero.ZeroablePrimitive U128 core.num.niche_types.NonZeroU128Inner := {
  copyInst := core.marker.CopyU128
  sealedInst := core.num.nonzero.«private».SealedU128
  innerCopyInst := core.marker.CopyNonZeroU128Inner
  primitive := some (.unsigned .U128)
}

@[rust_fun
  "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroUsizeInner>}::clone"]
def core.clone.CloneNonZeroUsizeInner.clone (self : core.num.niche_types.NonZeroUsizeInner) :
    Result core.num.niche_types.NonZeroUsizeInner := .ok self

@[reducible, rust_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroUsizeInner>"]
def core.clone.CloneNonZeroUsizeInner : core.clone.Clone core.num.niche_types.NonZeroUsizeInner := {
  clone := core.clone.CloneNonZeroUsizeInner.clone
}

@[reducible, rust_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroUsizeInner>"]
def core.marker.CopyNonZeroUsizeInner : core.marker.Copy core.num.niche_types.NonZeroUsizeInner := {
  cloneInst := core.clone.CloneNonZeroUsizeInner
}

@[reducible, rust_trait_impl "core::num::nonzero::private::Sealed<usize>"]
def core.num.nonzero.«private».SealedUsize : core.num.nonzero.«private».Sealed Usize := {}

@[reducible, rust_trait_impl
  "core::num::nonzero::ZeroablePrimitive<usize, core::num::niche_types::NonZeroUsizeInner>"]
def core.num.nonzero.ZeroablePrimitiveUsize :
    core.num.nonzero.ZeroablePrimitive Usize core.num.niche_types.NonZeroUsizeInner := {
  copyInst := core.marker.CopyUsize
  sealedInst := core.num.nonzero.«private».SealedUsize
  innerCopyInst := core.marker.CopyNonZeroUsizeInner
  primitive := some (.unsigned .Usize)
}

@[rust_fun
  "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroI8Inner>}::clone"]
def core.clone.CloneNonZeroI8Inner.clone (self : core.num.niche_types.NonZeroI8Inner) :
    Result core.num.niche_types.NonZeroI8Inner := .ok self

@[reducible, rust_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroI8Inner>"]
def core.clone.CloneNonZeroI8Inner : core.clone.Clone core.num.niche_types.NonZeroI8Inner := {
  clone := core.clone.CloneNonZeroI8Inner.clone
}

@[reducible, rust_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroI8Inner>"]
def core.marker.CopyNonZeroI8Inner : core.marker.Copy core.num.niche_types.NonZeroI8Inner := {
  cloneInst := core.clone.CloneNonZeroI8Inner
}

@[reducible, rust_trait_impl "core::num::nonzero::private::Sealed<i8>"]
def core.num.nonzero.«private».SealedI8 : core.num.nonzero.«private».Sealed I8 := {}

@[reducible, rust_trait_impl
  "core::num::nonzero::ZeroablePrimitive<i8, core::num::niche_types::NonZeroI8Inner>"]
def core.num.nonzero.ZeroablePrimitiveI8 :
    core.num.nonzero.ZeroablePrimitive I8 core.num.niche_types.NonZeroI8Inner := {
  copyInst := core.marker.CopyI8
  sealedInst := core.num.nonzero.«private».SealedI8
  innerCopyInst := core.marker.CopyNonZeroI8Inner
  primitive := some (.signed .I8)
}

@[rust_fun
  "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroI16Inner>}::clone"]
def core.clone.CloneNonZeroI16Inner.clone (self : core.num.niche_types.NonZeroI16Inner) :
    Result core.num.niche_types.NonZeroI16Inner := .ok self

@[reducible, rust_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroI16Inner>"]
def core.clone.CloneNonZeroI16Inner : core.clone.Clone core.num.niche_types.NonZeroI16Inner := {
  clone := core.clone.CloneNonZeroI16Inner.clone
}

@[reducible, rust_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroI16Inner>"]
def core.marker.CopyNonZeroI16Inner : core.marker.Copy core.num.niche_types.NonZeroI16Inner := {
  cloneInst := core.clone.CloneNonZeroI16Inner
}

@[reducible, rust_trait_impl "core::num::nonzero::private::Sealed<i16>"]
def core.num.nonzero.«private».SealedI16 : core.num.nonzero.«private».Sealed I16 := {}

@[reducible, rust_trait_impl
  "core::num::nonzero::ZeroablePrimitive<i16, core::num::niche_types::NonZeroI16Inner>"]
def core.num.nonzero.ZeroablePrimitiveI16 :
    core.num.nonzero.ZeroablePrimitive I16 core.num.niche_types.NonZeroI16Inner := {
  copyInst := core.marker.CopyI16
  sealedInst := core.num.nonzero.«private».SealedI16
  innerCopyInst := core.marker.CopyNonZeroI16Inner
  primitive := some (.signed .I16)
}

@[rust_fun
  "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroI32Inner>}::clone"]
def core.clone.CloneNonZeroI32Inner.clone (self : core.num.niche_types.NonZeroI32Inner) :
    Result core.num.niche_types.NonZeroI32Inner := .ok self

@[reducible, rust_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroI32Inner>"]
def core.clone.CloneNonZeroI32Inner : core.clone.Clone core.num.niche_types.NonZeroI32Inner := {
  clone := core.clone.CloneNonZeroI32Inner.clone
}

@[reducible, rust_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroI32Inner>"]
def core.marker.CopyNonZeroI32Inner : core.marker.Copy core.num.niche_types.NonZeroI32Inner := {
  cloneInst := core.clone.CloneNonZeroI32Inner
}

@[reducible, rust_trait_impl "core::num::nonzero::private::Sealed<i32>"]
def core.num.nonzero.«private».SealedI32 : core.num.nonzero.«private».Sealed I32 := {}

@[reducible, rust_trait_impl
  "core::num::nonzero::ZeroablePrimitive<i32, core::num::niche_types::NonZeroI32Inner>"]
def core.num.nonzero.ZeroablePrimitiveI32 :
    core.num.nonzero.ZeroablePrimitive I32 core.num.niche_types.NonZeroI32Inner := {
  copyInst := core.marker.CopyI32
  sealedInst := core.num.nonzero.«private».SealedI32
  innerCopyInst := core.marker.CopyNonZeroI32Inner
  primitive := some (.signed .I32)
}

@[rust_fun
  "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroI64Inner>}::clone"]
def core.clone.CloneNonZeroI64Inner.clone (self : core.num.niche_types.NonZeroI64Inner) :
    Result core.num.niche_types.NonZeroI64Inner := .ok self

@[reducible, rust_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroI64Inner>"]
def core.clone.CloneNonZeroI64Inner : core.clone.Clone core.num.niche_types.NonZeroI64Inner := {
  clone := core.clone.CloneNonZeroI64Inner.clone
}

@[reducible, rust_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroI64Inner>"]
def core.marker.CopyNonZeroI64Inner : core.marker.Copy core.num.niche_types.NonZeroI64Inner := {
  cloneInst := core.clone.CloneNonZeroI64Inner
}

@[reducible, rust_trait_impl "core::num::nonzero::private::Sealed<i64>"]
def core.num.nonzero.«private».SealedI64 : core.num.nonzero.«private».Sealed I64 := {}

@[reducible, rust_trait_impl
  "core::num::nonzero::ZeroablePrimitive<i64, core::num::niche_types::NonZeroI64Inner>"]
def core.num.nonzero.ZeroablePrimitiveI64 :
    core.num.nonzero.ZeroablePrimitive I64 core.num.niche_types.NonZeroI64Inner := {
  copyInst := core.marker.CopyI64
  sealedInst := core.num.nonzero.«private».SealedI64
  innerCopyInst := core.marker.CopyNonZeroI64Inner
  primitive := some (.signed .I64)
}

@[rust_fun
  "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroI128Inner>}::clone"]
def core.clone.CloneNonZeroI128Inner.clone (self : core.num.niche_types.NonZeroI128Inner) :
    Result core.num.niche_types.NonZeroI128Inner := .ok self

@[reducible, rust_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroI128Inner>"]
def core.clone.CloneNonZeroI128Inner : core.clone.Clone core.num.niche_types.NonZeroI128Inner := {
  clone := core.clone.CloneNonZeroI128Inner.clone
}

@[reducible, rust_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroI128Inner>"]
def core.marker.CopyNonZeroI128Inner : core.marker.Copy core.num.niche_types.NonZeroI128Inner := {
  cloneInst := core.clone.CloneNonZeroI128Inner
}

@[reducible, rust_trait_impl "core::num::nonzero::private::Sealed<i128>"]
def core.num.nonzero.«private».SealedI128 : core.num.nonzero.«private».Sealed I128 := {}

@[reducible, rust_trait_impl
  "core::num::nonzero::ZeroablePrimitive<i128, core::num::niche_types::NonZeroI128Inner>"]
def core.num.nonzero.ZeroablePrimitiveI128 :
    core.num.nonzero.ZeroablePrimitive I128 core.num.niche_types.NonZeroI128Inner := {
  copyInst := core.marker.CopyI128
  sealedInst := core.num.nonzero.«private».SealedI128
  innerCopyInst := core.marker.CopyNonZeroI128Inner
  primitive := some (.signed .I128)
}

@[rust_fun
  "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroIsizeInner>}::clone"]
def core.clone.CloneNonZeroIsizeInner.clone (self : core.num.niche_types.NonZeroIsizeInner) :
    Result core.num.niche_types.NonZeroIsizeInner := .ok self

@[reducible, rust_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroIsizeInner>"]
def core.clone.CloneNonZeroIsizeInner : core.clone.Clone core.num.niche_types.NonZeroIsizeInner := {
  clone := core.clone.CloneNonZeroIsizeInner.clone
}

@[reducible, rust_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroIsizeInner>"]
def core.marker.CopyNonZeroIsizeInner : core.marker.Copy core.num.niche_types.NonZeroIsizeInner := {
  cloneInst := core.clone.CloneNonZeroIsizeInner
}

@[reducible, rust_trait_impl "core::num::nonzero::private::Sealed<isize>"]
def core.num.nonzero.«private».SealedIsize : core.num.nonzero.«private».Sealed Isize := {}

@[reducible, rust_trait_impl
  "core::num::nonzero::ZeroablePrimitive<isize, core::num::niche_types::NonZeroIsizeInner>"]
def core.num.nonzero.ZeroablePrimitiveIsize :
    core.num.nonzero.ZeroablePrimitive Isize core.num.niche_types.NonZeroIsizeInner := {
  copyInst := core.marker.CopyIsize
  sealedInst := core.num.nonzero.«private».SealedIsize
  innerCopyInst := core.marker.CopyNonZeroIsizeInner
  primitive := some (.signed .Isize)
}

@[rust_fun
  "core::num::niche_types::{core::clone::Clone<core::num::niche_types::NonZeroCharInner>}::clone"]
def core.clone.CloneNonZeroCharInner.clone (self : core.num.niche_types.NonZeroCharInner) :
    Result core.num.niche_types.NonZeroCharInner := .ok self

@[reducible, rust_trait_impl "core::clone::Clone<core::num::niche_types::NonZeroCharInner>"]
def core.clone.CloneNonZeroCharInner : core.clone.Clone core.num.niche_types.NonZeroCharInner := {
  clone := core.clone.CloneNonZeroCharInner.clone
}

@[reducible, rust_trait_impl "core::marker::Copy<core::num::niche_types::NonZeroCharInner>"]
def core.marker.CopyNonZeroCharInner : core.marker.Copy core.num.niche_types.NonZeroCharInner := {
  cloneInst := core.clone.CloneNonZeroCharInner
}

@[reducible, rust_trait_impl "core::num::nonzero::private::Sealed<char>"]
def core.num.nonzero.«private».SealedChar : core.num.nonzero.«private».Sealed Char := {}

@[reducible, rust_trait_impl
  "core::num::nonzero::ZeroablePrimitive<char, core::num::niche_types::NonZeroCharInner>"]
def core.num.nonzero.ZeroablePrimitiveChar :
    core.num.nonzero.ZeroablePrimitive Char core.num.niche_types.NonZeroCharInner := {
  copyInst := core.marker.CopyChar
  sealedInst := core.num.nonzero.«private».SealedChar
  innerCopyInst := core.marker.CopyNonZeroCharInner
  primitive := some (.char)
}

/-- Safe counterpart of Rust's niche-preserving transmute. Pattern matching on
    closed evidence exposes the real scalar operation, not a zero-test flag. -/
def core.num.nonzero.Primitive.new {T Inner : Type}
    (primitive : core.num.nonzero.Primitive T Inner) (n : T) :
    Option (core.num.nonzero.NonZero T) :=
  match primitive with
  | .unsigned _ =>
    if h : n.val = 0 then none else some ⟨n, .unsigned h⟩
  | .signed _ =>
    if h : n.val = 0 then none else some ⟨n, .signed h⟩
  | .char =>
    if h : n.toNat = 0 then none else some ⟨n, .char h⟩

@[rust_fun
  "core::num::nonzero::{core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>}::new"
  (keepParams := [true, true]) (keepTraitClauses := [true])]
def core.num.nonzero.NonZero.newGeneric {T Inner : Type}
    (primitiveInst : core.num.nonzero.ZeroablePrimitive T Inner) (n : T) :
    Result (Option (core.num.nonzero.NonZero T)) :=
  match primitiveInst.primitive with
  | some primitive => .ok (primitive.new n)
  | none => .fail .panic

@[rust_fun
  "core::num::nonzero::{core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>}::new_unchecked"
  (keepParams := [true, true]) (keepTraitClauses := [true])]
def core.num.nonzero.NonZero.newUncheckedGeneric {T Inner : Type}
    (primitiveInst : core.num.nonzero.ZeroablePrimitive T Inner) (n : T) :
    Result (core.num.nonzero.NonZero T) := do
  match ← core.num.nonzero.NonZero.newGeneric primitiveInst n with
  | some n => return n
  | none => .fail .panic

@[rust_fun
  "core::num::nonzero::{core::num::nonzero::NonZero<@T, @Clause0_NonZeroInner>}::get"
  (keepParams := [true, true]) (keepTraitClauses := [true])]
def core.num.nonzero.NonZero.getGeneric {T Inner : Type}
    (_primitiveInst : core.num.nonzero.ZeroablePrimitive T Inner)
    (self : core.num.nonzero.NonZero T) : Result T :=
  .ok self.val

/-- Concrete convenience constructor for the iterator advance-by error API.
    Rust calls use the single generic registration above. -/
def core.num.nonzero.NonZero.new (n : Usize) :
    Result (Option (core.num.nonzero.NonZero Usize)) :=
  core.num.nonzero.NonZero.newGeneric core.num.nonzero.ZeroablePrimitiveUsize n

def core.num.nonzero.NonZero.new_unchecked (n : Usize) :
    Result (core.num.nonzero.NonZero Usize) :=
  core.num.nonzero.NonZero.newUncheckedGeneric core.num.nonzero.ZeroablePrimitiveUsize n

def core.num.nonzero.NonZero.get (self : core.num.nonzero.NonZero Usize) : Result Usize :=
  core.num.nonzero.NonZero.getGeneric core.num.nonzero.ZeroablePrimitiveUsize self

end Aeneas.Std
