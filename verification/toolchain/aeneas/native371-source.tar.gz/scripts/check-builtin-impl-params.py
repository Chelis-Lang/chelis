#!/usr/bin/env python3
"""Audit: does every `rust_trait_impl` definition of the Aeneas Lean library bind its type and const-generic
parameters with the explicitness Aeneas prints them with?

Aeneas prints a trait impl reference with the impl's kept type/const-generic arguments that no trait clause
determines (PureUtils.compute_explicit_info: a parameter occurring in a trait clause is implicit), then the kept
trait clauses. So a library definition must bind as explicit `( : Type)` / `( : Usize)` exactly the parameters
that occur in none of its instance binders (the kept clauses), and as implicit `{ }` the others.

usage: scripts/check-builtin-impl-params.py [backends/lean dir] (default: the one of this repository)
Prints one line per mismatch (file:line name param lean=implicit|explicit aeneas=...), then the entries with
keepTraitClauses (a parameter occurring only in a dropped clause is implicit for Aeneas although no binder of the
definition determines it: listed for review), and a summary. Exit status 1 if any mismatch.
"""
import glob
import os
import re
import sys

OPEN = {"(": ")", "{": "}", "[": "]", "⦃": "⦄"}

# Parameters of a pattern which are not parameters of the Rust impls it matches (so Aeneas never prints them):
# `Default for [T; N]` is one impl per literal length (see the remark on core.default.DefaultArray).
NOT_RUST_PARAMS = {("core.default.DefaultArray", "N")}


def header_binders(text, start):
    """The binders of the definition header starting at `start` (just after the name), up to the top-level ':'."""
    i, binders = start, []
    while i < len(text):
        c = text[i]
        if c in OPEN:
            depth, j = 1, i + 1
            while depth:
                if text[j] == c:
                    depth += 1
                elif text[j] == OPEN[c]:
                    depth -= 1
                j += 1
            binders.append((c, text[i + 1:j - 1]))
            i = j
        elif c == ":" or text.startswith(":=", i):
            return binders
        else:
            i += 1
    return binders


def main():
    root = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "backends", "lean")
    mismatches, reviews, count = [], [], 0
    for path in sorted(glob.glob(f"{root}/Aeneas/**/*.lean", recursive=True)):
        text = open(path).read()
        for m in re.finditer(r'rust_trait_impl\s+"([^"]*)"', text):
            # the attributes may contain brackets (keepParams := [..]): they end at the next declaration
            d = re.compile(r"^\s*(?:noncomputable\s+|private\s+|protected\s+)*(def|instance|abbrev)\s+(\S+)", re.M)
            dm = d.search(text, m.end())
            if dm is None:
                continue
            attrs = text[m.end():dm.start()]
            name = dm.group(2)
            line = text.count("\n", 0, dm.start()) + 1
            count += 1
            binders = header_binders(text, dm.end())
            params, clauses = [], []
            for kind, body in binders:
                if ":" not in body:
                    continue
                names, ty = body.split(":", 1)
                ty = ty.strip()
                if kind in "({" and re.fullmatch(r"Type(\s+[a-z_0-9]+|\*)?|Usize", ty):
                    params += [(n, kind) for n in names.split()]
                else:
                    clauses.append(ty)
            for n, kind in params:
                if (name, n) in NOT_RUST_PARAMS:
                    continue
                in_clause = any(re.search(r"(?<![\w.])" + re.escape(n) + r"(?![\w.])", t) for t in clauses)
                lean = "explicit" if kind == "(" else "implicit"
                aeneas = "implicit" if in_clause else "explicit"
                if lean != aeneas:
                    mismatches.append(f"{path}:{line}: {name} {n}: lean={lean} aeneas={aeneas} [{m.group(1)}]")
            if "keepTraitClauses" in attrs:
                reviews.append(f"{path}:{line}: {name} [{m.group(1)}] {' '.join(attrs.split())[:160]}")
    for x in mismatches:
        print("MISMATCH", x)
    for x in reviews:
        print("REVIEW", x)
    print(f"{count} rust_trait_impl definitions, {len(mismatches)} mismatches, {len(reviews)} with keepTraitClauses")
    return 1 if mismatches else 0


if __name__ == "__main__":
    sys.exit(main())
